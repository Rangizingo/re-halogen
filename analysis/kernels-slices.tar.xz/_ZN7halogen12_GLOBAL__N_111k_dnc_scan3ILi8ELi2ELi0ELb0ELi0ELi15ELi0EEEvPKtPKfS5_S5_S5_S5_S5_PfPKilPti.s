000000000011da00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000011DA00: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 00000011DA04: F4100200 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 00000011DA0C: F4080100 F8000048
	s_lshl_b32 s28, s3, 4                                      // 00000011DA14: 841C8403
	s_ashr_i32 s3, s2, 31                                      // 00000011DA18: 86039F02
	s_ashr_i32 s29, s28, 31                                    // 00000011DA1C: 861D9F1C
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000011DA20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011DA28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000011DA2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000011DA30: BF89FC07
	s_load_b32 s26, s[22:23], null                             // 00000011DA34: F400068B F8000000
	s_lshl_b64 s[22:23], s[4:5], 2                             // 00000011DA3C: 84968204
	s_add_u32 s4, s20, s22                                     // 00000011DA40: 80041614
	s_addc_u32 s5, s21, s23                                    // 00000011DA44: 82051715
	s_lshl_b64 s[24:25], s[2:3], 16                            // 00000011DA48: 84989002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011DA4C: BF870009
	s_add_u32 s4, s4, s24                                      // 00000011DA50: 80041804
	s_addc_u32 s5, s5, s25                                     // 00000011DA54: 82051905
	s_waitcnt lgkmcnt(0)                                       // 00000011DA58: BF89FC07
	s_mul_i32 s30, s26, 0x9000000                              // 00000011DA5C: 961EFF1A 09000000
	s_mul_hi_i32 s31, s26, 0x9000000                           // 00000011DA64: 971FFF1A 09000000
	s_add_u32 s4, s4, s30                                      // 00000011DA6C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 00000011DA70: 82051F05
	s_lshl_b64 s[26:27], s[28:29], 2                           // 00000011DA74: 849A821C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000011DA78: BF8700B9
	s_add_u32 s4, s4, s26                                      // 00000011DA7C: 80041A04
	s_addc_u32 s5, s5, s27                                     // 00000011DA80: 82051B05
	.long 0xd7000402                                           // 00000011DA84: D7000402
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000011DA88: 02020204
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 00000011DA8C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 00000011DA94: BE840080
	s_nop 0                                                    // 00000011DA98: BF800000
	s_nop 0                                                    // 00000011DA9C: BF800000
	s_nop 0                                                    // 00000011DAA0: BF800000
	s_nop 0                                                    // 00000011DAA4: BF800000
	s_nop 0                                                    // 00000011DAA8: BF800000
	s_nop 0                                                    // 00000011DAAC: BF800000
	s_nop 0                                                    // 00000011DAB0: BF800000
	s_nop 0                                                    // 00000011DAB4: BF800000
	s_nop 0                                                    // 00000011DAB8: BF800000
	s_nop 0                                                    // 00000011DABC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000011DAC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000011DAC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DACC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000011DAD0: 300C1089
	.long 0xd7006a06                                           // 00000011DAD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000011DAD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011DADC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000011DAE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000011DAE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000011DAF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000011DAF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000011DAFC: D6FE7C06 040610FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 00000011DB08: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000011DB0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000011DB10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000011DB18: 917E047E
	s_cbranch_execnz 65512                                     // 00000011DB1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011DB20: 8C7E047E
	s_load_b32 s33, s[0:1], 0x58                               // 00000011DB24: F4000840 F8000058
	v_or_b32_e32 v26, 0xffffff80, v0                           // 00000011DB2C: 383400FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000011DB34: 32040084
	s_mov_b32 s0, 0                                            // 00000011DB38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000011DB3C: BF89FC07
	s_barrier                                                  // 00000011DB40: BFBD0000
	buffer_gl0_inv                                             // 00000011DB44: E0AC0000 00000000
	s_cmp_gt_i32 s33, 0                                        // 00000011DB4C: BF028021
	s_cbranch_scc1 12                                          // 00000011DB50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000011DB54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000011DB5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011DB64: BF870002
	v_lshl_add_u32 v25, v5, 2, v3                              // 00000011DB68: D6460019 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000011DB70: 7E060280
	v_lshlrev_b32_e32 v27, 2, v5                               // 00000011DB74: 30360A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000011DB78: 916A007E
	s_cbranch_vccz 2                                           // 00000011DB7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 879                                               // 00000011DB80: BFA0036F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf40>
	v_lshlrev_b32_e32 v27, 2, v5                               // 00000011DB84: 30360A82
	s_add_i32 s0, s33, 63                                      // 00000011DB88: 8100BF21
	s_add_i32 s34, s2, 0xbd0                                   // 00000011DB8C: 8122FF02 00000BD0
	s_lshr_b32 s35, s0, 6                                      // 00000011DB94: 85238600
	s_add_u32 s14, s14, s26                                    // 00000011DB98: 800E1A0E
	s_addc_u32 s15, s15, s27                                   // 00000011DB9C: 820F1B0F
	s_lshl_b32 s0, s2, 7                                       // 00000011DBA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v28, 2, v0      // 00000011DBA4: CA220080 031C0082
	s_ashr_i32 s1, s0, 31                                      // 00000011DBAC: 86019F00
	v_lshlrev_b32_e32 v6, 1, v5                                // 00000011DBB0: 300C0A81
	s_lshl_b64 s[4:5], s[0:1], 1                               // 00000011DBB4: 84848100
	v_lshlrev_b32_e32 v14, 8, v2                               // 00000011DBB8: 301C0488
	s_add_u32 s6, s6, s4                                       // 00000011DBBC: 80060406
	s_addc_u32 s7, s7, s5                                      // 00000011DBC0: 82070507
	s_lshl_b64 s[4:5], s[28:29], 1                             // 00000011DBC4: 8484811C
	v_mad_u32_u24 v25, 0x44, v2, v27                           // 00000011DBC8: D60B0019 046E04FF 00000044
	s_add_u32 s6, s6, s4                                       // 00000011DBD4: 80060406
	.long 0xd7000420                                           // 00000011DBD8: D7000420
	v_cndmask_b32_e32 v1, s14, v27, vcc_lo                     // 00000011DBDC: 0202360E
	s_addc_u32 s7, s7, s5                                      // 00000011DBE0: 82070507
	v_add_co_ci_u32_e64 v33, null, s15, 0, s4                  // 00000011DBE4: D5207C21 0011000F
	s_lshl_b64 s[4:5], s[2:3], 9                               // 00000011DBEC: 84848902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000011DBF0: BF8700B9
	v_dual_mov_b32 v13, s5 :: v_dual_add_nc_u32 v30, 0x3810, v28// 00000011DBF4: CA200005 0D1E38FF 00003810
	v_or_b32_e32 v12, s4, v28                                  // 00000011DC00: 38183804
	.long 0xd7000406                                           // 00000011DC04: D7000406
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000011DC08: 02020C06
	v_add_co_ci_u32_e64 v7, null, s7, 0, s4                    // 00000011DC0C: D5207C07 00110007
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC14: BF870093
	.long 0xd7000408                                           // 00000011DC18: D7000408
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 00000011DC1C: 02021810
	v_add_co_ci_u32_e64 v9, null, s17, v13, s4                 // 00000011DC20: D5207C09 00121A11
	.long 0xd700040a                                           // 00000011DC28: D700040A
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000011DC2C: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011DC30: BF8700D1
	v_add_co_ci_u32_e64 v11, null, s9, v13, s4                 // 00000011DC34: D5207C0B 00121A09
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000011DC3C: 84848E02
	v_add_nc_u32_e32 v29, 0x3710, v28                          // 00000011DC40: 4A3A38FF 00003710
	s_add_u32 s6, s18, s4                                      // 00000011DC48: 80060412
	.long 0xd700040c                                           // 00000011DC4C: D700040C
	v_cndmask_b32_e32 v1, s10, v12, vcc_lo                     // 00000011DC50: 0202180A
	v_add_co_ci_u32_e64 v13, null, s11, v13, s4                // 00000011DC54: D5207C0D 00121A0B
	s_addc_u32 s5, s19, s5                                     // 00000011DC5C: 82050513
	.long 0xd700040e                                           // 00000011DC60: D700040E
	v_cndmask_b32_e32 v1, s6, v14, vcc_lo                      // 00000011DC64: 02021C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011DC68: BF870001
	v_add_co_ci_u32_e64 v15, null, s5, 0, s4                   // 00000011DC6C: D5207C0F 00110005
	.long 0xd7000410                                           // 00000011DC74: D7000410
	v_cndmask_b32_e32 v1, 0xc000, v12, vcc_lo                  // 00000011DC78: 020218FF 0000C000
	.long 0xd44c0000                                           // 00000011DC80: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000011DC84: 020200FF 00000100
	.long 0xd44c0001                                           // 00000011DC8C: D44C0001
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 00000011DC90: 020200A0
	v_add_nc_u32_e32 v31, 1, v2                                // 00000011DC94: 4A3E0481
	v_add_nc_u32_e32 v4, 0x2200, v25                           // 00000011DC98: 4A0832FF 00002200
	v_or_b32_e32 v5, 0x2200, v1                                // 00000011DCA0: 380A02FF 00002200
	v_mul_u32_u24_e32 v34, 0x204, v2                           // 00000011DCA8: 164404FF 00000204
	v_add_co_ci_u32_e64 v17, null, 0, v13, s4                  // 00000011DCB0: D5207C11 00121A80
	s_mov_b32 s6, 0                                            // 00000011DCB8: BE860080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000011DCBC: 7C9800C0
	s_mul_i32 s4, s6, 0xc00                                    // 00000011DCC0: 9604FF06 00000C00
	s_lshl_b32 s8, s6, 6                                       // 00000011DCC8: 84088606
	s_add_i32 s4, s34, s4                                      // 00000011DCCC: 81040422
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011DCD0: BF870499
	s_ashr_i32 s5, s4, 31                                      // 00000011DCD4: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000011DCD8: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011DCDC: BF870009
	s_add_u32 s4, s12, s4                                      // 00000011DCE0: 8004040C
	s_addc_u32 s5, s13, s5                                     // 00000011DCE4: 8205050D
	global_load_b32 v18, v3, s[4:5]                            // 00000011DCE8: DC520000 12040003
	s_waitcnt vmcnt(0)                                         // 00000011DCF0: BF8903F7
	v_readfirstlane_b32 s7, v18                                // 00000011DCF4: 7E0E0512
	s_and_saveexec_b32 s5, vcc_lo                              // 00000011DCF8: BE85206A
	s_cbranch_execz 77                                         // 00000011DCFC: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x434>
	v_or_b32_e32 v18, s8, v0                                   // 00000011DD00: 38240008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DD04: BF870091
	v_mad_u64_u32 v[18:19], null, v18, 48, s[2:3]              // 00000011DD08: D6FE7C12 00096112
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000011DD10: 3426249F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DD14: BF870091
	.long 0xd73c0012                                           // 00000011DD18: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 00000011DD1C: 02022482
	.long 0xd7000412                                           // 00000011DD20: D7000412
	v_cndmask_b32_e32 v1, s12, v18, vcc_lo                     // 00000011DD24: 0202240C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011DD28: BF8700C1
	v_add_co_ci_u32_e64 v19, null, s13, v19, s4                // 00000011DD2C: D5207C13 0012260D
	global_load_b32 v18, v[18:19], off                         // 00000011DD34: DC520000 127C0012
	s_waitcnt vmcnt(0)                                         // 00000011DD3C: BF8903F7
	v_sub_f32_e32 v19, s7, v18                                 // 00000011DD40: 08262407
	v_dual_mul_f32 v21, 0x3fb8aa3b, v18 :: v_dual_mul_f32 v20, 0x3fb8aa3b, v19// 00000011DD44: C8C624FF 151426FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000011DD50: BF8701A1
	v_fma_f32 v24, 0x3fb8aa3b, v18, -v21                       // 00000011DD54: D6130018 845624FF 3FB8AA3B
	v_rndne_f32_e32 v35, v21                                   // 00000011DD60: 7E464715
	v_fma_f32 v22, 0x3fb8aa3b, v19, -v20                       // 00000011DD64: D6130016 845226FF 3FB8AA3B
	v_rndne_f32_e32 v23, v20                                   // 00000011DD70: 7E2E4714
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011DD74: BF870113
	v_dual_fmac_f32 v24, 0x32a5705f, v18 :: v_dual_sub_f32 v21, v21, v35// 00000011DD78: C80A24FF 18144715 32A5705F
	v_sub_f32_e32 v20, v20, v23                                // 00000011DD84: 08282F14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011DD88: BF870122
	v_dual_fmac_f32 v22, 0x32a5705f, v19 :: v_dual_add_f32 v21, v21, v24// 00000011DD8C: C80826FF 16143115 32A5705F
	.long 0xd41b0004                                           // 00000011DD98: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v19, vcc_lo              // 00000011DD9C: 020226FF C2CE8ED0
	v_add_f32_e32 v20, v20, v22                                // 00000011DDA4: 06282D14
	v_cvt_i32_f32_e32 v22, v23                                 // 00000011DDA8: 7E2C1117
	v_cvt_i32_f32_e32 v23, v35                                 // 00000011DDAC: 7E2E1123
	v_exp_f32_e32 v21, v21                                     // 00000011DDB0: 7E2A4B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000011DDB4: BF870313
	v_exp_f32_e32 v20, v20                                     // 00000011DDB8: 7E284B14
	.long 0xd71c0015                                           // 00000011DDBC: D71C0015
	v_cndmask_b32_e32 v1, v21, v23, vcc_lo                     // 00000011DDC0: 02022F15
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDC4: BF870095
	.long 0xd71c0014                                           // 00000011DDC8: D71C0014
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000011DDCC: 02022D14
	v_cndmask_b32_e64 v20, 0, v20, s4                          // 00000011DDD0: D5010014 00122880
	.long 0xd41b0004                                           // 00000011DDD8: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v18, vcc_lo              // 00000011DDDC: 020224FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011DDE4: BF8700A1
	v_cndmask_b32_e64 v21, 0, v21, s4                          // 00000011DDE8: D5010015 00122A80
	.long 0xd41e0004                                           // 00000011DDF0: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v19, vcc_lo              // 00000011DDF4: 020226FF 42B17218
	v_cndmask_b32_e64 v19, 0x7f800000, v20, s4                 // 00000011DDFC: D5010013 001228FF 7F800000
	.long 0xd41e0004                                           // 00000011DE08: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v18, vcc_lo              // 00000011DE0C: 020224FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011DE14: BF870001
	v_cndmask_b32_e64 v18, 0x7f800000, v21, s4                 // 00000011DE18: D5010012 00122AFF 7F800000
	ds_store_b32 v29, v19                                      // 00000011DE24: D8340000 0000131D
	ds_store_b32 v30, v18                                      // 00000011DE2C: D8340000 0000121E
	s_or_b32 exec_lo, exec_lo, s5                              // 00000011DE34: 8C7E057E
	v_or_b32_e32 v22, s8, v2                                   // 00000011DE38: 382C0408
	v_dual_mov_b32 v19, v9 :: v_dual_mov_b32 v18, v8           // 00000011DE3C: CA100109 13120108
	s_mov_b32 s5, 0                                            // 00000011DE44: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000011DE48: BF89FC07
	s_barrier                                                  // 00000011DE4C: BFBD0000
	buffer_gl0_inv                                             // 00000011DE50: E0AC0000 00000000
	s_branch 15                                                // 00000011DE58: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x498>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011DE5C: 8C7E097E
	.long 0xd7000412                                           // 00000011DE60: D7000412
	v_cndmask_b32_e32 v1, 0xc000, v18, vcc_lo                  // 00000011DE64: 020224FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011DE6C: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 00000011DE70: D5207C13 00122680
	s_add_i32 s4, s5, 2                                        // 00000011DE78: 81048205
	s_cmp_lt_u32 s5, 62                                        // 00000011DE7C: BF0ABE05
	s_mov_b32 s5, s4                                           // 00000011DE80: BE850004
	s_waitcnt lgkmcnt(0)                                       // 00000011DE84: BF89FC07
	s_barrier                                                  // 00000011DE88: BFBD0000
	buffer_gl0_inv                                             // 00000011DE8C: E0AC0000 00000000
	s_cbranch_scc0 161                                         // 00000011DE94: BFA100A1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x71c>
	s_and_saveexec_b32 s9, s0                                  // 00000011DE98: BE892000
	s_cbranch_execz 30                                         // 00000011DE9C: BFA5001E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x518>
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v20, v18         // 00000011DEA0: CA100113 15140112
	v_dual_mov_b32 v23, v28 :: v_dual_mov_b32 v24, v26         // 00000011DEA8: CA10011C 1718011A
	s_mov_b32 s10, 0                                           // 00000011DEB0: BE8A0080
	s_nop 0                                                    // 00000011DEB4: BF800000
	s_nop 0                                                    // 00000011DEB8: BF800000
	s_nop 0                                                    // 00000011DEBC: BF800000
	global_load_b32 v35, v[20:21], off                         // 00000011DEC0: DC520000 237C0014
	.long 0xd7000b18                                           // 00000011DEC8: D7000B18
	v_cndmask_b32_e32 v1, 0x80, v24, vcc_lo                    // 00000011DECC: 020230FF 00000080
	.long 0xd7000414                                           // 00000011DED4: D7000414
	v_cndmask_b32_e32 v1, 0x6000, v20, vcc_lo                  // 00000011DED8: 020228FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011DEE0: BF8704A1
	v_add_co_ci_u32_e64 v21, null, 0, v21, s4                  // 00000011DEE4: D5207C15 00122A80
	s_xor_b32 s4, s11, -1                                      // 00000011DEEC: 8D04C10B
	s_and_b32 s4, exec_lo, s4                                  // 00000011DEF0: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011DEF4: BF870009
	s_or_b32 s10, s4, s10                                      // 00000011DEF8: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000011DEFC: BF8903F7
	ds_store_b32 v23, v35 offset:13056                         // 00000011DF00: D8343300 00002317
	v_add_nc_u32_e32 v23, 0x204, v23                           // 00000011DF08: 4A2E2EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000011DF10: 917E0A7E
	s_cbranch_execnz 65514                                     // 00000011DF14: BFA6FFEA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c0>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011DF18: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 00000011DF1C: BF89FC07
	s_barrier                                                  // 00000011DF20: BFBD0000
	buffer_gl0_inv                                             // 00000011DF24: E0AC0000 00000000
	s_and_saveexec_b32 s9, s1                                  // 00000011DF2C: BE892001
	s_cbranch_execz 65482                                      // 00000011DF30: BFA5FFCA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45c>
	v_or_b32_e32 v20, s5, v22                                  // 00000011DF34: 38282C05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF38: BF870091
	v_mad_u64_u32 v[20:21], null, v20, 48, s[2:3]              // 00000011DF3C: D6FE7C14 00096114
	.long 0xd73c0014                                           // 00000011DF44: D73C0014
	v_cndmask_b32_e32 v1, 9, v20, vcc_lo                       // 00000011DF48: 02022889
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF4C: BF870091
	.long 0xd7000414                                           // 00000011DF50: D7000414
	v_cndmask_b32_e32 v1, v32, v20, vcc_lo                     // 00000011DF54: 02022920
	v_add_co_ci_u32_e64 v21, null, v33, v21, s4                // 00000011DF58: D5207C15 00122B21
	s_movk_i32 s4, 0xfe00                                      // 00000011DF60: B004FE00
	global_load_b32 v21, v[20:21], off                         // 00000011DF64: DC520000 157C0014
	v_mov_b32_e32 v20, v1                                      // 00000011DF6C: 7E280301
	v_add_nc_u32_e32 v47, s4, v34                              // 00000011DF70: 4A5E4404
	s_add_i32 s4, s4, 64                                       // 00000011DF74: 8104C004
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF78: BF870099
	s_cmp_eq_u32 s4, 0                                         // 00000011DF7C: BF068004
	v_add_nc_u32_e32 v35, 0x3500, v47                          // 00000011DF80: 4A465EFF 00003500
	v_add_nc_u32_e32 v39, 0x3508, v47                          // 00000011DF88: 4A4E5EFF 00003508
	v_add_nc_u32_e32 v43, 0x3510, v47                          // 00000011DF90: 4A565EFF 00003510
	v_add_nc_u32_e32 v45, 0x3518, v47                          // 00000011DF98: 4A5A5EFF 00003518
	ds_load_2addr_b32 v[23:24], v20 offset1:17                 // 00000011DFA0: D8DC1100 17000014
	ds_load_2addr_b32 v[35:36], v35 offset1:1                  // 00000011DFA8: D8DC0100 23000023
	ds_load_2addr_b32 v[37:38], v20 offset0:34 offset1:51      // 00000011DFB0: D8DC3322 25000014
	ds_load_2addr_b32 v[39:40], v39 offset1:1                  // 00000011DFB8: D8DC0100 27000027
	ds_load_2addr_b32 v[41:42], v20 offset0:68 offset1:85      // 00000011DFC0: D8DC5544 29000014
	ds_load_2addr_b32 v[43:44], v43 offset1:1                  // 00000011DFC8: D8DC0100 2B00002B
	ds_load_2addr_b32 v[45:46], v45 offset1:1                  // 00000011DFD0: D8DC0100 2D00002D
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 00000011DFD8: BF890057
	v_fma_f32 v21, -v35, v23, v21                              // 00000011DFDC: D6130015 24562F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000011DFE4: BF870151
	v_fma_f32 v21, -v36, v24, v21                              // 00000011DFE8: D6130015 24563124
	ds_load_2addr_b32 v[23:24], v20 offset0:102 offset1:119    // 00000011DFF0: D8DC7766 17000014
	s_waitcnt lgkmcnt(4)                                       // 00000011DFF8: BF89FC47
	v_fma_f32 v21, -v39, v37, v21                              // 00000011DFFC: D6130015 24564B27
	v_add_nc_u32_e32 v37, 0x3520, v47                          // 00000011E004: 4A4A5EFF 00003520
	v_fma_f32 v21, -v40, v38, v21                              // 00000011E00C: D6130015 24564D28
	ds_load_2addr_b32 v[35:36], v20 offset0:136 offset1:153    // 00000011E014: D8DC9988 23000014
	ds_load_2addr_b32 v[37:38], v37 offset1:1                  // 00000011E01C: D8DC0100 25000025
	s_waitcnt lgkmcnt(4)                                       // 00000011E024: BF89FC47
	v_fma_f32 v21, -v43, v41, v21                              // 00000011E028: D6130015 2456532B
	v_add_nc_u32_e32 v41, 0x3528, v47                          // 00000011E030: 4A525EFF 00003528
	v_add_nc_u32_e32 v43, 0x3530, v47                          // 00000011E038: 4A565EFF 00003530
	s_delay_alu instid0(VALU_DEP_3)                            // 00000011E040: BF870003
	v_fma_f32 v21, -v44, v42, v21                              // 00000011E044: D6130015 2456552C
	ds_load_2addr_b32 v[39:40], v20 offset0:170 offset1:187    // 00000011E04C: D8DCBBAA 27000014
	ds_load_2addr_b32 v[41:42], v41 offset1:1                  // 00000011E054: D8DC0100 29000029
	s_waitcnt lgkmcnt(4)                                       // 00000011E05C: BF89FC47
	v_fma_f32 v21, -v45, v23, v21                              // 00000011E060: D6130015 24562F2D
	v_add_nc_u32_e32 v45, 0x3538, v47                          // 00000011E068: 4A5A5EFF 00003538
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011E070: BF870002
	v_fma_f32 v21, -v46, v24, v21                              // 00000011E074: D6130015 2456312E
	ds_load_2addr_b32 v[23:24], v20 offset0:204 offset1:221    // 00000011E07C: D8DCDDCC 17000014
	ds_load_2addr_b32 v[43:44], v43 offset1:1                  // 00000011E084: D8DC0100 2B00002B
	ds_load_2addr_b32 v[45:46], v45 offset1:1                  // 00000011E08C: D8DC0100 2D00002D
	s_waitcnt lgkmcnt(5)                                       // 00000011E094: BF89FC57
	v_fma_f32 v21, -v37, v35, v21                              // 00000011E098: D6130015 24564725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011E0A0: BF8700D1
	v_fma_f32 v21, -v38, v36, v21                              // 00000011E0A4: D6130015 24564926
	ds_load_2addr_b32 v[35:36], v20 offset0:238 offset1:255    // 00000011E0AC: D8DCFFEE 23000014
	v_add_nc_u32_e32 v20, 0x440, v20                           // 00000011E0B4: 4A2828FF 00000440
	s_waitcnt lgkmcnt(4)                                       // 00000011E0BC: BF89FC47
	v_fma_f32 v21, -v41, v39, v21                              // 00000011E0C0: D6130015 24564F29
	v_fma_f32 v21, -v42, v40, v21                              // 00000011E0C8: D6130015 2456512A
	s_waitcnt lgkmcnt(2)                                       // 00000011E0D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0D4: BF870091
	v_fma_f32 v21, -v43, v23, v21                              // 00000011E0D8: D6130015 24562F2B
	v_fma_f32 v21, -v44, v24, v21                              // 00000011E0E0: D6130015 2456312C
	s_waitcnt lgkmcnt(0)                                       // 00000011E0E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0EC: BF870091
	v_fma_f32 v21, -v45, v35, v21                              // 00000011E0F0: D6130015 2456472D
	v_fma_f32 v21, -v46, v36, v21                              // 00000011E0F8: D6130015 2456492E
	s_cbranch_scc0 65435                                       // 00000011E100: BFA1FF9B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	v_mad_u64_u32 v[23:24], null, 0x44, s5, v[4:5]             // 00000011E104: D6FE7C17 04100AFF 00000044
	ds_store_b32 v23, v21                                      // 00000011E110: D8340000 00001517
	s_branch 65360                                             // 00000011E118: BFA0FF50 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45c>
	v_dual_mov_b32 v19, v15 :: v_dual_mov_b32 v18, v14         // 00000011E11C: CA10010F 1312010E
	v_dual_mov_b32 v21, v11 :: v_dual_mov_b32 v20, v10         // 00000011E124: CA10010B 1514010A
	v_mov_b32_e32 v24, v31                                     // 00000011E12C: 7E30031F
	s_mov_b32 s9, 0                                            // 00000011E130: BE890080
	s_branch 21                                                // 00000011E134: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x78c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000011E138: 8C7E0A7E
	.long 0xd7000414                                           // 00000011E13C: D7000414
	v_cndmask_b32_e32 v1, 0xc000, v20, vcc_lo                  // 00000011E140: 020228FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E148: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v21, s4                  // 00000011E14C: D5207C15 00122A80
	.long 0xd7000412                                           // 00000011E154: D7000412
	v_cndmask_b32_e32 v1, 0x200, v18, vcc_lo                   // 00000011E158: 020224FF 00000200
	v_add_nc_u32_e32 v24, 2, v24                               // 00000011E160: 4A303082
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 00000011E164: D5207C13 00122680
	s_add_i32 s4, s9, 2                                        // 00000011E16C: 81048209
	s_cmp_gt_u32 s9, 61                                        // 00000011E170: BF08BD09
	s_mov_b32 s9, s4                                           // 00000011E174: BE890004
	s_waitcnt_vscnt null, 0x0                                  // 00000011E178: BC7C0000
	s_barrier                                                  // 00000011E17C: BFBD0000
	buffer_gl0_inv                                             // 00000011E180: E0AC0000 00000000
	s_cbranch_scc1 189                                         // 00000011E188: BFA200BD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa80>
	s_and_saveexec_b32 s5, s0                                  // 00000011E18C: BE852000
	s_cbranch_execz 33                                         // 00000011E190: BFA50021 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v23, v21 :: v_dual_mov_b32 v22, v20         // 00000011E194: CA100115 17160114
	v_dual_mov_b32 v35, v28 :: v_dual_mov_b32 v36, v26         // 00000011E19C: CA10011C 2324011A
	s_mov_b32 s10, 0                                           // 00000011E1A4: BE8A0080
	s_nop 0                                                    // 00000011E1A8: BF800000
	s_nop 0                                                    // 00000011E1AC: BF800000
	s_nop 0                                                    // 00000011E1B0: BF800000
	s_nop 0                                                    // 00000011E1B4: BF800000
	s_nop 0                                                    // 00000011E1B8: BF800000
	s_nop 0                                                    // 00000011E1BC: BF800000
	global_load_b32 v37, v[22:23], off                         // 00000011E1C0: DC520000 257C0016
	.long 0xd7000b24                                           // 00000011E1C8: D7000B24
	v_cndmask_b32_e32 v1, 0x80, v36, vcc_lo                    // 00000011E1CC: 020248FF 00000080
	.long 0xd7000416                                           // 00000011E1D4: D7000416
	v_cndmask_b32_e32 v1, 0x6000, v22, vcc_lo                  // 00000011E1D8: 02022CFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011E1E0: BF8704A1
	v_add_co_ci_u32_e64 v23, null, 0, v23, s4                  // 00000011E1E4: D5207C17 00122E80
	s_xor_b32 s4, s11, -1                                      // 00000011E1EC: 8D04C10B
	s_and_b32 s4, exec_lo, s4                                  // 00000011E1F0: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011E1F4: BF870009
	s_or_b32 s10, s4, s10                                      // 00000011E1F8: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000011E1FC: BF8903F7
	ds_store_b32 v35, v37 offset:13056                         // 00000011E200: D8343300 00002523
	v_add_nc_u32_e32 v35, 0x204, v35                           // 00000011E208: 4A4646FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000011E210: 917E0A7E
	s_cbranch_execnz 65514                                     // 00000011E214: BFA6FFEA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7c0>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000011E218: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 00000011E21C: BF89FC07
	s_barrier                                                  // 00000011E220: BFBD0000
	buffer_gl0_inv                                             // 00000011E224: E0AC0000 00000000
	s_and_saveexec_b32 s10, s1                                 // 00000011E22C: BE8A2001
	s_cbranch_execz 65473                                      // 00000011E230: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x738>
	v_or_b32_e32 v22, s9, v2                                   // 00000011E234: 382C0409
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E238: BF870091
	v_or_b32_e32 v35, s8, v22                                  // 00000011E23C: 38462C08
	.long 0xd4440004                                           // 00000011E240: D4440004
	v_cndmask_b32_e32 v1, s33, v35, vcc_lo                     // 00000011E244: 02024621
	s_and_b32 exec_lo, exec_lo, s4                             // 00000011E248: 8B7E047E
	s_cbranch_execz 65466                                      // 00000011E24C: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x738>
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v23, v1            // 00000011E250: CA100080 24160101
	s_movk_i32 s4, 0xfe00                                      // 00000011E258: B004FE00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011E25C: BF8704A9
	v_add_nc_u32_e32 v51, s4, v34                              // 00000011E260: 4A664404
	s_add_i32 s4, s4, 64                                       // 00000011E264: 8104C004
	s_cmp_eq_u32 s4, 0                                         // 00000011E268: BF068004
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E26C: BF870001
	v_add_nc_u32_e32 v39, 0x3500, v51                          // 00000011E270: 4A4E66FF 00003500
	ds_load_2addr_b32 v[37:38], v23 offset1:17                 // 00000011E278: D8DC1100 25000017
	ds_load_2addr_b32 v[39:40], v39 offset1:1                  // 00000011E280: D8DC0100 27000027
	s_waitcnt lgkmcnt(0)                                       // 00000011E288: BF89FC07
	v_dual_fmac_f32 v36, v39, v37 :: v_dual_add_nc_u32 v43, 0x3508, v51// 00000011E28C: C8204B27 242A66FF 00003508
	ds_load_2addr_b32 v[41:42], v23 offset0:34 offset1:51      // 00000011E298: D8DC3322 29000017
	ds_load_2addr_b32 v[43:44], v43 offset1:1                  // 00000011E2A0: D8DC0100 2B00002B
	v_dual_fmac_f32 v36, v40, v38 :: v_dual_add_nc_u32 v47, 0x3510, v51// 00000011E2A8: C8204D28 242E66FF 00003510
	ds_load_2addr_b32 v[37:38], v23 offset0:102 offset1:119    // 00000011E2B4: D8DC7766 25000017
	s_waitcnt lgkmcnt(1)                                       // 00000011E2BC: BF89FC17
	v_fmac_f32_e32 v36, v43, v41                               // 00000011E2C0: 5648532B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E2C4: BF870001
	v_dual_fmac_f32 v36, v44, v42 :: v_dual_add_nc_u32 v49, 0x3518, v51// 00000011E2C8: C820552C 243066FF 00003518
	ds_load_2addr_b32 v[45:46], v23 offset0:68 offset1:85      // 00000011E2D4: D8DC5544 2D000017
	ds_load_2addr_b32 v[47:48], v47 offset1:1                  // 00000011E2DC: D8DC0100 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset1:1                  // 00000011E2E4: D8DC0100 31000031
	s_waitcnt lgkmcnt(1)                                       // 00000011E2EC: BF89FC17
	v_dual_fmac_f32 v36, v47, v45 :: v_dual_add_nc_u32 v41, 0x3520, v51// 00000011E2F0: C8205B2F 242866FF 00003520
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E2FC: BF870001
	v_fmac_f32_e32 v36, v48, v46                               // 00000011E300: 56485D30
	ds_load_2addr_b32 v[39:40], v23 offset0:136 offset1:153    // 00000011E304: D8DC9988 27000017
	ds_load_2addr_b32 v[41:42], v41 offset1:1                  // 00000011E30C: D8DC0100 29000029
	s_waitcnt lgkmcnt(2)                                       // 00000011E314: BF89FC27
	v_dual_fmac_f32 v36, v49, v37 :: v_dual_add_nc_u32 v45, 0x3528, v51// 00000011E318: C8204B31 242C66FF 00003528
	ds_load_2addr_b32 v[43:44], v23 offset0:170 offset1:187    // 00000011E324: D8DCBBAA 2B000017
	ds_load_2addr_b32 v[45:46], v45 offset1:1                  // 00000011E32C: D8DC0100 2D00002D
	v_dual_fmac_f32 v36, v50, v38 :: v_dual_add_nc_u32 v47, 0x3530, v51// 00000011E334: C8204D32 242E66FF 00003530
	s_waitcnt lgkmcnt(2)                                       // 00000011E340: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E344: BF870091
	v_fmac_f32_e32 v36, v41, v39                               // 00000011E348: 56484F29
	v_dual_fmac_f32 v36, v42, v40 :: v_dual_add_nc_u32 v49, 0x3538, v51// 00000011E34C: C820512A 243066FF 00003538
	ds_load_2addr_b32 v[37:38], v23 offset0:204 offset1:221    // 00000011E358: D8DCDDCC 25000017
	ds_load_2addr_b32 v[47:48], v47 offset1:1                  // 00000011E360: D8DC0100 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset1:1                  // 00000011E368: D8DC0100 31000031
	ds_load_2addr_b32 v[39:40], v23 offset0:238 offset1:255    // 00000011E370: D8DCFFEE 27000017
	v_add_nc_u32_e32 v23, 0x440, v23                           // 00000011E378: 4A2E2EFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 00000011E380: BF89FC47
	v_fmac_f32_e32 v36, v45, v43                               // 00000011E384: 5648572D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011E388: BF8700A1
	v_fmac_f32_e32 v36, v46, v44                               // 00000011E38C: 5648592E
	s_waitcnt lgkmcnt(2)                                       // 00000011E390: BF89FC27
	v_fmac_f32_e32 v36, v47, v37                               // 00000011E394: 56484B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011E398: BF8700A1
	v_fmac_f32_e32 v36, v48, v38                               // 00000011E39C: 56484D30
	s_waitcnt lgkmcnt(0)                                       // 00000011E3A0: BF89FC07
	v_fmac_f32_e32 v36, v49, v39                               // 00000011E3A4: 56484F31
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E3A8: BF870001
	v_fmac_f32_e32 v36, v50, v40                               // 00000011E3AC: 56485132
	s_cbranch_scc0 65450                                       // 00000011E3B0: BFA1FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x85c>
	v_dual_mov_b32 v37, v1 :: v_dual_lshlrev_b32 v22, 2, v22   // 00000011E3B4: CA220101 25162C82
	s_mov_b32 s11, 0                                           // 00000011E3BC: BE8B0080
	ds_load_b32 v38, v22 offset:14352                          // 00000011E3C0: D8D83810 26000016
	v_dual_mov_b32 v23, v19 :: v_dual_mov_b32 v22, v18         // 00000011E3C8: CA100113 17160112
	s_waitcnt lgkmcnt(0)                                       // 00000011E3D0: BF89FC07
	v_mul_f32_e32 v36, v36, v38                                // 00000011E3D4: 10484D24
	v_mov_b32_e32 v38, v24                                     // 00000011E3D8: 7E4C0318
	s_nop 0                                                    // 00000011E3DC: BF800000
	s_nop 0                                                    // 00000011E3E0: BF800000
	s_nop 0                                                    // 00000011E3E4: BF800000
	s_nop 0                                                    // 00000011E3E8: BF800000
	s_nop 0                                                    // 00000011E3EC: BF800000
	s_nop 0                                                    // 00000011E3F0: BF800000
	s_nop 0                                                    // 00000011E3F4: BF800000
	s_nop 0                                                    // 00000011E3F8: BF800000
	s_nop 0                                                    // 00000011E3FC: BF800000
	global_load_b32 v39, v[22:23], off                         // 00000011E400: DC520000 277C0016
	ds_load_b32 v40, v37 offset:8704                           // 00000011E408: D8D82200 28000025
	v_add_nc_u32_e32 v38, -1, v38                              // 00000011E410: 4A4C4CC1
	.long 0xd7000416                                           // 00000011E414: D7000416
	v_cndmask_b32_e32 v0, v22, v132, vcc_lo                    // 00000011E418: 02010916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011E41C: BF870191
	v_add_co_ci_u32_e64 v23, null, 0, v23, s4                  // 00000011E420: D5207C17 00122E80
	.long 0xd44a0005                                           // 00000011E428: D44A0005
	v_cndmask_b32_e32 v1, 0, v38, vcc_lo                       // 00000011E42C: 02024C80
	v_add_nc_u32_e32 v37, 0x44, v37                            // 00000011E430: 4A4A4AFF 00000044
	s_or_b32 s11, s5, s11                                      // 00000011E438: 8C0B0B05
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011E43C: BF890007
	v_fmac_f32_e32 v36, v39, v40                               // 00000011E440: 56485127
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000011E444: 917E0B7E
	s_cbranch_execnz 65517                                     // 00000011E448: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa00>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000011E44C: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E450: BF870121
	v_bfe_u32 v37, v36, 16, 1                                  // 00000011E454: D6100025 02052124
	v_mad_u64_u32 v[22:23], null, 0x3000, v35, v[6:7]          // 00000011E45C: D6FE7C16 041A46FF 00003000
	v_add3_u32 v35, v36, v37, 0x7fff                           // 00000011E468: D6550023 03FE4B24 00007FFF
	global_store_d16_hi_b16 v[22:23], v35, off                 // 00000011E474: DC960000 007C2316
	s_branch 65326                                             // 00000011E47C: BFA0FF2E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x738>
	s_mul_f32 s4, s7, 0x3fb8aa3b                               // 00000011E480: A204FF07 3FB8AA3B
	v_mov_b32_e32 v20, v26                                     // 00000011E488: 7E28031A
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011E48C: BF8704CA
	s_xor_b32 s5, s4, 0x80000000                               // 00000011E490: 8D05FF04 80000000
	s_rndne_f32 s8, s4                                         // 00000011E498: BE886304
	s_fmamk_f32 s5, s7, 0x3fb8aa3b, s5                         // 00000011E49C: A3050507 3FB8AA3B
	s_cmp_nlt_f32 s7, 0xc2ce8ed0                               // 00000011E4A4: BF4EFF07 C2CE8ED0
	s_sub_f32 s4, s4, s8                                       // 00000011E4AC: A0840804
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000011E4B0: BF870599
	s_fmamk_f32 s5, s7, 0x32a5705f, s5                         // 00000011E4B4: A3050507 32A5705F
	s_add_f32 s4, s4, s5                                       // 00000011E4BC: A0040504
	s_mov_b32 s5, 0                                            // 00000011E4C0: BE850080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000011E4C4: BF87000A
	v_exp_f32_e32 v18, s4                                      // 00000011E4C8: 7E244A04
	s_cvt_i32_f32 s4, s8                                       // 00000011E4CC: BE846608
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000011E4D0: BF870585
	.long 0xd71c0012                                           // 00000011E4D4: D71C0012
	v_cndmask_b32_e32 v0, v18, v4, vcc_lo                      // 00000011E4D8: 02000912
	s_cselect_b32 s4, -1, 0                                    // 00000011E4DC: 980480C1
	s_cmp_ngt_f32 s7, 0x42b17218                               // 00000011E4E0: BF4BFF07 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000011E4E8: BF870131
	v_cndmask_b32_e64 v19, 0, v18, s4                          // 00000011E4EC: D5010013 00122480
	s_cselect_b32 s4, -1, 0                                    // 00000011E4F4: 980480C1
	v_mov_b32_e32 v18, v25                                     // 00000011E4F8: 7E240319
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s4                 // 00000011E4FC: D5010013 001226FF 7F800000
	ds_load_b32 v21, v18                                       // 00000011E508: D8D80000 15000012
	s_waitcnt lgkmcnt(0)                                       // 00000011E510: BF89FC07
	v_dual_mul_f32 v21, v19, v21 :: v_dual_add_nc_u32 v20, 0x80, v20// 00000011E514: C8E02B13 151428FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011E520: BF8704C1
	.long 0xd4490004                                           // 00000011E524: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v20, vcc_lo                   // 00000011E528: 020228FF 0000077F
	ds_store_b32 v18, v21                                      // 00000011E530: D8340000 00001512
	v_add_nc_u32_e32 v18, 0x220, v18                           // 00000011E538: 4A2424FF 00000220
	s_or_b32 s5, s4, s5                                        // 00000011E540: 8C050504
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000011E544: 917E057E
	s_cbranch_execnz 65519                                     // 00000011E548: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb08>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000011E54C: 8C7E057E
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 00000011E550: CA100111 13120110
	v_dual_mov_b32 v21, v13 :: v_dual_mov_b32 v20, v12         // 00000011E558: CA10010D 1514010C
	v_mov_b32_e32 v35, 0                                       // 00000011E560: 7E460280
	s_mov_b32 s5, 0                                            // 00000011E564: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000011E568: BF89FC07
	s_barrier                                                  // 00000011E56C: BFBD0000
	buffer_gl0_inv                                             // 00000011E570: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 00000011E578: BE872000
	s_cbranch_execz 41                                         // 00000011E57C: BFA50029 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc24>
	v_dual_mov_b32 v23, v21 :: v_dual_mov_b32 v22, v20         // 00000011E580: CA100115 17160114
	v_dual_mov_b32 v24, v35 :: v_dual_mov_b32 v37, v26         // 00000011E588: CA100123 1824011A
	v_mov_b32_e32 v36, v28                                     // 00000011E590: 7E48031C
	s_mov_b32 s8, 0                                            // 00000011E594: BE880080
	s_nop 0                                                    // 00000011E598: BF800000
	s_nop 0                                                    // 00000011E59C: BF800000
	s_nop 0                                                    // 00000011E5A0: BF800000
	s_nop 0                                                    // 00000011E5A4: BF800000
	s_nop 0                                                    // 00000011E5A8: BF800000
	s_nop 0                                                    // 00000011E5AC: BF800000
	s_nop 0                                                    // 00000011E5B0: BF800000
	s_nop 0                                                    // 00000011E5B4: BF800000
	s_nop 0                                                    // 00000011E5B8: BF800000
	s_nop 0                                                    // 00000011E5BC: BF800000
	global_load_b32 v38, v[22:23], off                         // 00000011E5C0: DC520000 267C0016
	ds_load_b32 v39, v24 offset:14096                          // 00000011E5C8: D8D83710 27000018
	.long 0xd7000925                                           // 00000011E5D0: D7000925
	v_cndmask_b32_e32 v1, 0x80, v37, vcc_lo                    // 00000011E5D4: 02024AFF 00000080
	.long 0xd7000416                                           // 00000011E5DC: D7000416
	v_cndmask_b32_e32 v1, 0x6000, v22, vcc_lo                  // 00000011E5E0: 02022CFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011E5E8: BF8704C1
	v_add_co_ci_u32_e64 v23, null, 0, v23, s4                  // 00000011E5EC: D5207C17 00122E80
	s_xor_b32 s4, s9, -1                                       // 00000011E5F4: 8D04C109
	v_add_nc_u32_e32 v24, 4, v24                               // 00000011E5F8: 4A303084
	s_and_b32 s4, exec_lo, s4                                  // 00000011E5FC: 8B04047E
	s_or_b32 s8, s4, s8                                        // 00000011E600: 8C080804
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011E604: BF890007
	v_mul_f32_e32 v38, v38, v39                                // 00000011E608: 104C4F26
	ds_store_b32 v36, v38 offset:13056                         // 00000011E60C: D8343300 00002624
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000011E614: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000011E61C: 917E087E
	s_cbranch_execnz 65511                                     // 00000011E620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbc0>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000011E624: 8C7E077E
	v_mad_u64_u32 v[22:23], null, 0x44, s5, v[5:6]             // 00000011E628: D6FE7C16 04140AFF 00000044
	s_waitcnt lgkmcnt(0)                                       // 00000011E634: BF89FC07
	s_barrier                                                  // 00000011E638: BFBD0000
	buffer_gl0_inv                                             // 00000011E63C: E0AC0000 00000000
	v_mov_b32_e32 v36, v0                                      // 00000011E644: 7E480300
	s_mov_b32 s7, 0                                            // 00000011E648: BE870080
	ds_load_2addr_b32 v[23:24], v22 offset1:17                 // 00000011E64C: D8DC1100 17000016
	s_nop 0                                                    // 00000011E654: BF800000
	s_nop 0                                                    // 00000011E658: BF800000
	s_nop 0                                                    // 00000011E65C: BF800000
	s_nop 0                                                    // 00000011E660: BF800000
	s_nop 0                                                    // 00000011E664: BF800000
	s_nop 0                                                    // 00000011E668: BF800000
	s_nop 0                                                    // 00000011E66C: BF800000
	s_nop 0                                                    // 00000011E670: BF800000
	s_nop 0                                                    // 00000011E674: BF800000
	s_nop 0                                                    // 00000011E678: BF800000
	s_nop 0                                                    // 00000011E67C: BF800000
	v_lshrrev_b32_e32 v37, 4, v36                              // 00000011E680: 324A4884
	.long 0xd4490004                                           // 00000011E684: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v36, vcc_lo                   // 00000011E688: 020248FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011E690: BF870002
	v_lshlrev_b32_e32 v39, 2, v37                              // 00000011E694: 304E4A82
	v_mad_u64_u32 v[37:38], null, 0x44, v37, v[1:2]            // 00000011E698: D6FE7C25 04064AFF 00000044
	s_or_b32 s7, s4, s7                                        // 00000011E6A4: 8C070704
	v_add_nc_u32_e32 v38, 0x3200, v39                          // 00000011E6A8: 4A4C4EFF 00003200
	ds_load_b32 v40, v37                                       // 00000011E6B0: D8D80000 28000025
	ds_load_2addr_b32 v[38:39], v38 offset0:64 offset1:193     // 00000011E6B8: D8DCC140 26000026
	s_waitcnt lgkmcnt(0)                                       // 00000011E6C0: BF89FC07
	v_fmac_f32_e32 v40, v38, v23                               // 00000011E6C4: 56502F26
	v_add_nc_u32_e32 v38, 0x80, v36                            // 00000011E6C8: 4A4C48FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E6D0: BF870112
	v_fmac_f32_e32 v40, v39, v24                               // 00000011E6D4: 56503127
	v_mov_b32_e32 v36, v38                                     // 00000011E6D8: 7E480326
	ds_store_b32 v37, v40                                      // 00000011E6DC: D8340000 00002825
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000011E6E4: 917E077E
	s_cbranch_execnz 65509                                     // 00000011E6E8: BFA6FFE5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc80>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000011E6EC: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 00000011E6F0: BF89FC07
	s_barrier                                                  // 00000011E6F4: BFBD0000
	buffer_gl0_inv                                             // 00000011E6F8: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 00000011E700: BE872000
	s_cbranch_execz 39                                         // 00000011E704: BFA50027 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xda4>
	v_dual_mov_b32 v24, v19 :: v_dual_mov_b32 v23, v18         // 00000011E708: CA100113 18160112
	v_dual_mov_b32 v36, v28 :: v_dual_mov_b32 v37, v35         // 00000011E710: CA10011C 24240123
	v_mov_b32_e32 v38, v26                                     // 00000011E718: 7E4C031A
	s_mov_b32 s8, 0                                            // 00000011E71C: BE880080
	s_nop 0                                                    // 00000011E720: BF800000
	s_nop 0                                                    // 00000011E724: BF800000
	s_nop 0                                                    // 00000011E728: BF800000
	s_nop 0                                                    // 00000011E72C: BF800000
	s_nop 0                                                    // 00000011E730: BF800000
	s_nop 0                                                    // 00000011E734: BF800000
	s_nop 0                                                    // 00000011E738: BF800000
	s_nop 0                                                    // 00000011E73C: BF800000
	global_load_b32 v39, v[23:24], off                         // 00000011E740: DC520000 277C0017
	ds_load_b32 v40, v37 offset:14104                          // 00000011E748: D8D83718 28000025
	.long 0xd7000926                                           // 00000011E750: D7000926
	v_cndmask_b32_e32 v1, 0x80, v38, vcc_lo                    // 00000011E754: 02024CFF 00000080
	.long 0xd7000417                                           // 00000011E75C: D7000417
	v_cndmask_b32_e32 v1, 0x6000, v23, vcc_lo                  // 00000011E760: 02022EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011E768: BF8704C1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s4                  // 00000011E76C: D5207C18 00123080
	s_xor_b32 s4, s9, -1                                       // 00000011E774: 8D04C109
	v_add_nc_u32_e32 v37, 4, v37                               // 00000011E778: 4A4A4A84
	s_and_b32 s4, exec_lo, s4                                  // 00000011E77C: 8B04047E
	s_or_b32 s8, s4, s8                                        // 00000011E780: 8C080804
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011E784: BF890007
	v_mul_f32_e32 v39, v39, v40                                // 00000011E788: 104E5127
	ds_store_b32 v36, v39 offset:13056                         // 00000011E78C: D8343300 00002724
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000011E794: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000011E79C: 917E087E
	s_cbranch_execnz 65511                                     // 00000011E7A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd40>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000011E7A4: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 00000011E7A8: BF89FC07
	s_barrier                                                  // 00000011E7AC: BFBD0000
	buffer_gl0_inv                                             // 00000011E7B0: E0AC0000 00000000
	ds_load_2addr_b32 v[22:23], v22 offset0:34 offset1:51      // 00000011E7B8: D8DC3322 16000016
	v_mov_b32_e32 v24, v0                                      // 00000011E7C0: 7E300300
	s_mov_b32 s7, 0                                            // 00000011E7C4: BE870080
	s_nop 0                                                    // 00000011E7C8: BF800000
	s_nop 0                                                    // 00000011E7CC: BF800000
	s_nop 0                                                    // 00000011E7D0: BF800000
	s_nop 0                                                    // 00000011E7D4: BF800000
	s_nop 0                                                    // 00000011E7D8: BF800000
	s_nop 0                                                    // 00000011E7DC: BF800000
	s_nop 0                                                    // 00000011E7E0: BF800000
	s_nop 0                                                    // 00000011E7E4: BF800000
	s_nop 0                                                    // 00000011E7E8: BF800000
	s_nop 0                                                    // 00000011E7EC: BF800000
	s_nop 0                                                    // 00000011E7F0: BF800000
	s_nop 0                                                    // 00000011E7F4: BF800000
	s_nop 0                                                    // 00000011E7F8: BF800000
	s_nop 0                                                    // 00000011E7FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E800: BF870121
	v_lshrrev_b32_e32 v36, 4, v24                              // 00000011E804: 32483084
	.long 0xd4490004                                           // 00000011E808: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v24, vcc_lo                   // 00000011E80C: 020230FF 0000077F
	v_lshlrev_b32_e32 v38, 2, v36                              // 00000011E814: 304C4882
	v_mad_u64_u32 v[36:37], null, 0x44, v36, v[1:2]            // 00000011E818: D6FE7C24 040648FF 00000044
	s_or_b32 s7, s4, s7                                        // 00000011E824: 8C070704
	v_add_nc_u32_e32 v37, 0x3200, v38                          // 00000011E828: 4A4A4CFF 00003200
	ds_load_b32 v39, v36                                       // 00000011E830: D8D80000 27000024
	ds_load_2addr_b32 v[37:38], v37 offset0:64 offset1:193     // 00000011E838: D8DCC140 25000025
	s_waitcnt lgkmcnt(0)                                       // 00000011E840: BF89FC07
	v_fmac_f32_e32 v39, v37, v22                               // 00000011E844: 564E2D25
	v_add_nc_u32_e32 v37, 0x80, v24                            // 00000011E848: 4A4A30FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E850: BF870001
	v_dual_fmac_f32 v39, v38, v23 :: v_dual_mov_b32 v24, v37   // 00000011E854: C8102F26 27180125
	ds_store_b32 v36, v39                                      // 00000011E85C: D8340000 00002724
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000011E864: 917E077E
	s_cbranch_execnz 65509                                     // 00000011E868: BFA6FFE5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe00>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000011E86C: 8C7E077E
	.long 0xd7000414                                           // 00000011E870: D7000414
	v_cndmask_b32_e32 v1, 0x18000, v20, vcc_lo                 // 00000011E874: 020228FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E87C: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v21, s4                  // 00000011E880: D5207C15 00122A80
	.long 0xd7000412                                           // 00000011E888: D7000412
	v_cndmask_b32_e32 v1, 0x18000, v18, vcc_lo                 // 00000011E88C: 020224FF 00018000
	v_add_nc_u32_e32 v35, 16, v35                              // 00000011E894: 4A464690
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 00000011E898: D5207C13 00122680
	s_or_b32 s7, s5, 2                                         // 00000011E8A0: 8C078205
	s_add_i32 s5, s5, 4                                        // 00000011E8A4: 81058405
	s_cmp_gt_u32 s7, 61                                        // 00000011E8A8: BF08BD07
	s_cbranch_scc0 65326                                       // 00000011E8AC: BFA1FF2E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb68>
	.long 0xd7000408                                           // 00000011E8B0: D7000408
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000011E8B4: 020210FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011E8BC: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, s4                    // 00000011E8C0: D5207C09 00121280
	.long 0xd700040a                                           // 00000011E8C8: D700040A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 00000011E8CC: 020214FF 00180000
	v_add_co_ci_u32_e64 v11, null, 0, v11, s4                  // 00000011E8D4: D5207C0B 00121680
	.long 0xd700040e                                           // 00000011E8DC: D700040E
	v_cndmask_b32_e32 v1, 0xc0000, v14, vcc_lo                 // 00000011E8E0: 02021CFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011E8E8: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v15, s4                  // 00000011E8EC: D5207C0F 00121E80
	.long 0xd700040c                                           // 00000011E8F4: D700040C
	v_cndmask_b32_e32 v1, 0x180000, v12, vcc_lo                // 00000011E8F8: 020218FF 00180000
	v_add_co_ci_u32_e64 v13, null, 0, v13, s4                  // 00000011E900: D5207C0D 00121A80
	.long 0xd7000410                                           // 00000011E908: D7000410
	v_cndmask_b32_e32 v1, 0x180000, v16, vcc_lo                // 00000011E90C: 020220FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011E914: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, s4                  // 00000011E918: D5207C11 00122280
	s_add_i32 s6, s6, 1                                        // 00000011E920: 81068106
	s_waitcnt lgkmcnt(0)                                       // 00000011E924: BF89FC07
	s_cmp_eq_u32 s6, s35                                       // 00000011E928: BF062306
	s_barrier                                                  // 00000011E92C: BFBD0000
	buffer_gl0_inv                                             // 00000011E930: E0AC0000 00000000
	s_cbranch_scc0 64737                                       // 00000011E938: BFA1FCE1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c0>
	v_mov_b32_e32 v4, v26                                      // 00000011E93C: 7E08031A
	s_add_u32 s0, s30, s24                                     // 00000011E940: 8000181E
	.long 0xd73c0000                                           // 00000011E944: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000011E948: 02020489
	s_addc_u32 s1, s31, s25                                    // 00000011E94C: 8201191F
	s_add_u32 s2, s26, s22                                     // 00000011E950: 8002161A
	s_addc_u32 s3, s27, s23                                    // 00000011E954: 8203171B
	s_add_u32 s0, s2, s0                                       // 00000011E958: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000011E95C: 82010103
	.long 0xd7006a00                                           // 00000011E960: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000011E964: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000011E968: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000011E96C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000011E974: BE810080
	.long 0xd7006a00                                           // 00000011E978: D7006A00
	v_cndmask_b32_e32 v1, v0, v27, vcc_lo                      // 00000011E97C: 02023700
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000011E980: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E988: BF870092
	.long 0xd7006a00                                           // 00000011E98C: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000011E990: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000011E994: D5207C01 01AA0215
	s_nop 0                                                    // 00000011E99C: BF800000
	s_nop 0                                                    // 00000011E9A0: BF800000
	s_nop 0                                                    // 00000011E9A4: BF800000
	s_nop 0                                                    // 00000011E9A8: BF800000
	s_nop 0                                                    // 00000011E9AC: BF800000
	s_nop 0                                                    // 00000011E9B0: BF800000
	s_nop 0                                                    // 00000011E9B4: BF800000
	s_nop 0                                                    // 00000011E9B8: BF800000
	s_nop 0                                                    // 00000011E9BC: BF800000
	ds_load_b32 v2, v25                                        // 00000011E9C0: D8D80000 02000019
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000011E9C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v25, 0x220, v25                           // 00000011E9D0: 4A3232FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011E9D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000011E9DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000011E9E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000011E9E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000011E9EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000011E9F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000011E9F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000011EA00: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000011EA08: 917E017E
	s_cbranch_execnz 65516                                     // 00000011EA0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi2ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_endpgm                                                   // 00000011EA10: BFB00000
		...

