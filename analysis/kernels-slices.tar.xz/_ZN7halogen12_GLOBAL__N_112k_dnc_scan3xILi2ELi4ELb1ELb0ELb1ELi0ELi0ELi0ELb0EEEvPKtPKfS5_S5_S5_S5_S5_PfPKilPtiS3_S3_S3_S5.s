00000000001bcc00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001BCC00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001BCC08: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001BCC0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001BCC10: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001BCC14: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001BCC18: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001BCC1C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001BCC20: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001BCC24: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001BCC2C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001BCC30: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001BCC38: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001BCC3C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001BCC40: 82081311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000001BCC44: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BCC48: BF870009
	s_add_u32 s5, s5, s20                                      // 0000001BCC4C: 80051405
	s_addc_u32 s8, s8, s21                                     // 0000001BCC50: 82081508
	s_waitcnt lgkmcnt(0)                                       // 0000001BCC54: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001BCC58: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001BCC60: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001BCC68: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001BCC6C: 82050F08
	s_lshl_b64 s[34:35], s[6:7], 2                             // 0000001BCC70: 84A28206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BCC74: BF8700B9
	s_add_u32 s4, s4, s34                                      // 0000001BCC78: 80042204
	s_addc_u32 s5, s5, s35                                     // 0000001BCC7C: 82052305
	.long 0xd7000403                                           // 0000001BCC80: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001BCC84: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001BCC88: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001BCC90: BE840080
	s_nop 0                                                    // 0000001BCC94: BF800000
	s_nop 0                                                    // 0000001BCC98: BF800000
	s_nop 0                                                    // 0000001BCC9C: BF800000
	s_nop 0                                                    // 0000001BCCA0: BF800000
	s_nop 0                                                    // 0000001BCCA4: BF800000
	s_nop 0                                                    // 0000001BCCA8: BF800000
	s_nop 0                                                    // 0000001BCCAC: BF800000
	s_nop 0                                                    // 0000001BCCB0: BF800000
	s_nop 0                                                    // 0000001BCCB4: BF800000
	s_nop 0                                                    // 0000001BCCB8: BF800000
	s_nop 0                                                    // 0000001BCCBC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001BCCC0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCCC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001BCCC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001BCCCC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001BCCD4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001BCCD8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001BCCDC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001BCCE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001BCCE8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001BCCF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001BCCF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001BCD00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001BCD04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001BCD08: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001BCD0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001BCD14: 917E047E
	s_cbranch_execnz 65513                                     // 0000001BCD18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001BCD1C: 8C7E047E
	s_load_b32 s58, s[0:1], 0x58                               // 0000001BCD20: F4000E80 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 0000001BCD28: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001BCD30: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 0000001BCD34: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001BCD38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001BCD40: 32080084
	s_mov_b32 s4, 0                                            // 0000001BCD44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001BCD48: BF89FC07
	s_barrier                                                  // 0000001BCD4C: BFBD0000
	buffer_gl0_inv                                             // 0000001BCD50: E0AC0000 00000000
	s_cmp_gt_i32 s58, 0                                        // 0000001BCD58: BF02803A
	s_cbranch_scc1 14                                          // 0000001BCD5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 0000001BCD60: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s34                                      // 0000001BCD6C: 7E020222
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001BCD70: 380C00FF FFFFFF80
	v_and_or_b32 v123, v4, 4, v3                               // 0000001BCD78: D657007B 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BCD80: BF870004
	v_dual_mov_b32 v129, v107 :: v_dual_mov_b32 v2, s35        // 0000001BCD84: CA10016B 81020023
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001BCD8C: 916A047E
	s_cbranch_vccz 1                                           // 0000001BCD90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 8147                                              // 0000001BCD94: BFA01FD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x80e4>
	s_clause 0x2                                               // 0000001BCD98: BF850002
	s_load_b256 s[24:31], s[0:1], 0x60                         // 0000001BCD9C: F40C0600 F8000060
	s_load_b64 s[56:57], s[0:1], null                          // 0000001BCDA4: F4040E00 F8000000
	s_load_b128 s[52:55], s[0:1], 0x18                         // 0000001BCDAC: F4080D00 F8000018
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000001BCDB4: 84888202
	s_mul_hi_i32 s5, s2, 0x55555556                            // 0000001BCDB8: 9705FF02 55555556
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 0000001BCDC0: CA220080 6B020082
	v_lshlrev_b32_e32 v6, 1, v0                                // 0000001BCDC8: 300C0081
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001BCDCC: 32020085
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001BCDD0: D6100007 02050900
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BCDD8: BF870004
	v_or_b32_e32 v120, 0xf000, v2                              // 0000001BCDDC: 38F004FF 0000F000
	v_add_nc_u32_e32 v121, 0xf100, v2                          // 0000001BCDE4: 4AF204FF 0000F100
	v_mov_b32_e32 v129, v107                                   // 0000001BCDEC: 7F02036B
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001BCDF0: 161002FF 00002100
	s_load_b256 s[44:51], s[0:1], 0x80                         // 0000001BCDF8: F40C0B00 F8000080
	s_mov_b32 s12, 0xcc00                                      // 0000001BCE00: BE8C00FF 0000CC00
	v_and_b32_e32 v106, 0x200, v5                              // 0000001BCE08: 36D40AFF 00000200
	.long 0xd4490004                                           // 0000001BCE10: D4490004
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001BCE14: 020200BF
	v_and_or_b32 v123, v4, 4, v3                               // 0000001BCE18: D657007B 040D0904
	v_dual_mov_b32 v151, 0xf054 :: v_dual_lshlrev_b32 v140, 1, v0// 0000001BCE20: CA2200FF 978C0081 0000F054
	s_waitcnt lgkmcnt(0)                                       // 0000001BCE2C: BF89FC07
	s_add_u32 s59, s30, s8                                     // 0000001BCE30: 803B081E
	s_addc_u32 s60, s31, s9                                    // 0000001BCE34: 823C091F
	s_lshr_b32 s9, s5, 31                                      // 0000001BCE38: 85099F05
	s_add_i32 s8, s58, 63                                      // 0000001BCE3C: 8108BF3A
	s_add_i32 s5, s5, s9                                       // 0000001BCE40: 81050905
	s_add_i32 s62, s58, -1                                     // 0000001BCE44: 813EC13A
	s_lshr_b32 s63, s8, 6                                      // 0000001BCE48: 853F8608
	s_lshl_b32 s8, s5, 7                                       // 0000001BCE4C: 84088705
	s_mul_i32 s5, s62, 0x5000                                  // 0000001BCE50: 9605FF3E 00005000
	s_add_i32 s61, s2, 0xbd0                                   // 0000001BCE58: 813DFF02 00000BD0
	s_mul_hi_u32 s10, s62, 0x5000                              // 0000001BCE60: 968AFF3E 00005000
	s_ashr_i32 s9, s8, 31                                      // 0000001BCE68: 86099F08
	s_add_u32 s5, s56, s5                                      // 0000001BCE6C: 80050538
	s_addc_u32 s10, s57, s10                                   // 0000001BCE70: 820A0A39
	s_lshl_b64 s[30:31], s[8:9], 1                             // 0000001BCE74: 849E8108
	s_mul_hi_u32 s8, s62, 0xc0                                 // 0000001BCE78: 9688FF3E 000000C0
	s_add_u32 s5, s5, s30                                      // 0000001BCE80: 80051E05
	s_addc_u32 s9, s10, s31                                    // 0000001BCE84: 82091F0A
	.long 0xd7000502                                           // 0000001BCE88: D7000502
	v_cndmask_b32_e32 v1, s5, v6, vcc_lo                       // 0000001BCE8C: 02020C05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BCE90: BF8700B1
	v_add_co_ci_u32_e64 v6, null, s9, 0, s5                    // 0000001BCE94: D5207C06 00150009
	s_mul_i32 s9, s62, 0xc0                                    // 0000001BCE9C: 9609FF3E 000000C0
	.long 0xd700057a                                           // 0000001BCEA4: D700057A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000001BCEA8: 020204FF 00001000
	v_add_co_ci_u32_e64 v124, null, 0, v6, s5                  // 0000001BCEB0: D5207C7C 00160C80
	v_dual_mov_b32 v141, 0xf004 :: v_dual_lshlrev_b32 v2, 4, v1// 0000001BCEB8: CA2200FF 8D020284 0000F004
	v_dual_mov_b32 v143, 0xf014 :: v_dual_and_b32 v6, 15, v0   // 0000001BCEC4: CA2400FF 8F06008F 0000F014
	s_add_u32 s64, s59, s9                                     // 0000001BCED0: 8040093B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCED4: BF870122
	v_or_b32_e32 v130, v7, v2                                  // 0000001BCED8: 39040507
	s_addc_u32 s65, s60, s8                                    // 0000001BCEDC: 8241083C
	v_or_b32_e32 v126, v2, v6                                  // 0000001BCEE0: 38FC0D02
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001BCEE4: D60B0002 04220CFF 00000210
	s_add_u32 s10, s54, s34                                    // 0000001BCEF0: 800A2236
	v_dual_mov_b32 v145, 0xf024 :: v_dual_lshlrev_b32 v8, 2, v6// 0000001BCEF4: CA2200FF 91080C82 0000F024
	s_addc_u32 s11, s55, s35                                   // 0000001BCF00: 820B2337
	s_lshl_b32 s8, s2, 7                                       // 0000001BCF04: 84088702
	v_lshl_or_b32 v133, v7, 2, v2                              // 0000001BCF08: D6560085 04090507
	v_dual_mov_b32 v147, 0xf034 :: v_dual_lshlrev_b32 v2, 7, v126// 0000001BCF10: CA2200FF 9302FC87 0000F034
	s_movk_i32 s5, 0x90                                        // 0000001BCF1C: B0050090
	s_ashr_i32 s9, s8, 31                                      // 0000001BCF20: 86099F08
	v_mad_u32_u24 v125, v0, s5, 0x8400                         // 0000001BCF24: D60B007D 03FC0B00 00008400
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001BCF30: 84888108
	v_mad_u32_u24 v132, v6, s5, 0x8400                         // 0000001BCF34: D60B0084 03FC0B06 00008400
	.long 0xd7000586                                           // 0000001BCF40: D7000586
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000001BCF44: 0202100A
	s_add_u32 s8, s22, s8                                      // 0000001BCF48: 80080816
	v_add_co_ci_u32_e64 v135, null, s11, 0, s5                 // 0000001BCF4C: D5207C87 0015000B
	.long 0xd7000589                                           // 0000001BCF54: D7000589
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000001BCF58: 0202041C
	v_dual_mov_b32 v149, 0xf044 :: v_dual_lshlrev_b32 v2, 1, v6// 0000001BCF5C: CA2200FF 95020C81 0000F044
	s_addc_u32 s9, s23, s9                                     // 0000001BCF68: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001BCF6C: 84868106
	v_mad_u32_u24 v128, 0x90, v6, s12                          // 0000001BCF70: D60B0080 00320CFF 00000090
	s_add_u32 s8, s8, s6                                       // 0000001BCF7C: 80080608
	s_addc_u32 s7, s9, s7                                      // 0000001BCF80: 82070709
	.long 0xd700086c                                           // 0000001BCF84: D700086C
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001BCF88: 02020408
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCF8C: BF870001
	v_add_co_ci_u32_e64 v109, null, s7, 0, s8                  // 0000001BCF90: D5207C6D 00210007
	s_load_b64 s[8:9], s[0:1], 0xa0                            // 0000001BCF98: F4040200 F80000A0
	s_add_u32 s0, s34, s20                                     // 0000001BCFA0: 80001422
	v_mad_u32_u24 v131, 0x900, v1, v128                        // 0000001BCFA4: D60B0083 060202FF 00000900
	v_add_co_ci_u32_e64 v138, null, s29, 0, s5                 // 0000001BCFB0: D5207C8A 0015001D
	.long 0xd44d0005                                           // 0000001BCFB8: D44D0005
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001BCFBC: 02020280
	s_addc_u32 s1, s35, s21                                    // 0000001BCFC0: 82011523
	.long 0xd7000001                                           // 0000001BCFC4: D7000001
	v_cndmask_b32_e32 v1, s0, v106, vcc_lo                     // 0000001BCFC8: 0202D400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BCFCC: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001BCFD0: D5207C02 00010001
	v_mul_u32_u24_e32 v127, 0x210, v6                          // 0000001BCFD8: 16FE0CFF 00000210
	.long 0xd7000001                                           // 0000001BCFE0: D7000001
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 0000001BCFE4: 0202ED01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BCFE8: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001BCFEC: D5207C02 00020480
	v_lshl_add_u32 v136, v130, 1, v128                         // 0000001BCFF4: D6460088 06010382
	.long 0xd700006e                                           // 0000001BCFFC: D700006E
	v_cndmask_b32_e32 v1, s48, v1, vcc_lo                      // 0000001BD000: 02020230
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD004: BF8700A1
	v_add_co_ci_u32_e64 v111, null, s49, v2, s0                // 0000001BD008: D5207C6F 00020431
	.long 0xd7000070                                           // 0000001BD010: D7000070
	v_cndmask_b32_e32 v1, s50, v1, vcc_lo                      // 0000001BD014: 02020232
	v_add_co_ci_u32_e64 v113, null, s51, v2, s0                // 0000001BD018: D5207C71 00020433
	s_waitcnt lgkmcnt(0)                                       // 0000001BD020: BF89FC07
	.long 0xd7000072                                           // 0000001BD024: D7000072
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000001BD028: 02020208
	.long 0xd4490006                                           // 0000001BD02C: D4490006
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001BD030: 020200FF 0000005F
	v_lshl_or_b32 v139, v130, 2, 0xf100                        // 0000001BD038: D656008B 03FD0582 0000F100
	v_add_co_ci_u32_e64 v115, null, s9, v2, s0                 // 0000001BD044: D5207C73 00020409
	v_mov_b32_e32 v142, 0xf00c                                 // 0000001BD04C: 7F1C02FF 0000F00C
	v_mov_b32_e32 v144, 0xf01c                                 // 0000001BD054: 7F2002FF 0000F01C
	v_mov_b32_e32 v146, 0xf02c                                 // 0000001BD05C: 7F2402FF 0000F02C
	v_mov_b32_e32 v148, 0xf03c                                 // 0000001BD064: 7F2802FF 0000F03C
	v_mov_b32_e32 v150, 0xf04c                                 // 0000001BD06C: 7F2C02FF 0000F04C
	v_mov_b32_e32 v152, 0xf05c                                 // 0000001BD074: 7F3002FF 0000F05C
	v_mov_b32_e32 v153, 0xf064                                 // 0000001BD07C: 7F3202FF 0000F064
	v_mov_b32_e32 v154, 0xf06c                                 // 0000001BD084: 7F3402FF 0000F06C
	v_mov_b32_e32 v155, 0xf074                                 // 0000001BD08C: 7F3602FF 0000F074
	v_mov_b32_e32 v156, 0xf07c                                 // 0000001BD094: 7F3802FF 0000F07C
	v_mov_b32_e32 v157, 0xf084                                 // 0000001BD09C: 7F3A02FF 0000F084
	v_mov_b32_e32 v158, 0xf08c                                 // 0000001BD0A4: 7F3C02FF 0000F08C
	v_mov_b32_e32 v159, 0xf094                                 // 0000001BD0AC: 7F3E02FF 0000F094
	v_mov_b32_e32 v160, 0xf09c                                 // 0000001BD0B4: 7F4002FF 0000F09C
	v_mov_b32_e32 v161, 0xf0a4                                 // 0000001BD0BC: 7F4202FF 0000F0A4
	v_mov_b32_e32 v162, 0xf0ac                                 // 0000001BD0C4: 7F4402FF 0000F0AC
	v_mov_b32_e32 v163, 0xf0b4                                 // 0000001BD0CC: 7F4602FF 0000F0B4
	v_mov_b32_e32 v164, 0xf0bc                                 // 0000001BD0D4: 7F4802FF 0000F0BC
	v_mov_b32_e32 v165, 0xf0c4                                 // 0000001BD0DC: 7F4A02FF 0000F0C4
	v_mov_b32_e32 v166, 0xf0cc                                 // 0000001BD0E4: 7F4C02FF 0000F0CC
	v_mov_b32_e32 v167, 0xf0d4                                 // 0000001BD0EC: 7F4E02FF 0000F0D4
	v_mov_b32_e32 v168, 0xf0dc                                 // 0000001BD0F4: 7F5002FF 0000F0DC
	v_mov_b32_e32 v169, 0xf0e4                                 // 0000001BD0FC: 7F5202FF 0000F0E4
	v_mov_b32_e32 v170, 0xf0ec                                 // 0000001BD104: 7F5402FF 0000F0EC
	v_mov_b32_e32 v171, 0xf0f4                                 // 0000001BD10C: 7F5602FF 0000F0F4
	s_mov_b32 s36, 0                                           // 0000001BD114: BEA40080
	s_mov_b32 s22, 0x41800000                                  // 0000001BD118: BE9600FF 41800000
	s_mov_b32 s37, s36                                         // 0000001BD120: BEA50024
	s_mov_b32 s38, s36                                         // 0000001BD124: BEA60024
	s_mov_b32 s39, s36                                         // 0000001BD128: BEA70024
	s_mov_b32 s40, s36                                         // 0000001BD12C: BEA80024
	s_mov_b32 s41, s36                                         // 0000001BD130: BEA90024
	s_mov_b32 s42, s36                                         // 0000001BD134: BEAA0024
	s_mov_b32 s43, s36                                         // 0000001BD138: BEAB0024
	s_mov_b32 s23, s36                                         // 0000001BD13C: BE970024
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001BD140: 7C9800C0
	s_branch 4                                                 // 0000001BD144: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x558>
	s_add_i32 s23, s23, 1                                      // 0000001BD148: 81178117
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD14C: BF870009
	s_cmp_eq_u32 s23, s63                                      // 0000001BD150: BF063F17
	s_cbranch_scc1 7904                                        // 0000001BD154: BFA21EE0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x80d8>
	s_mul_i32 s0, s23, 0xc00                                   // 0000001BD158: 9600FF17 00000C00
	s_lshl_b32 s7, s23, 6                                      // 0000001BD160: 84078617
	s_add_i32 s0, s61, s0                                      // 0000001BD164: 8100003D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001BD168: BF870499
	s_ashr_i32 s1, s0, 31                                      // 0000001BD16C: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001BD170: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD174: BF870009
	s_add_u32 s0, s52, s0                                      // 0000001BD178: 80000034
	s_addc_u32 s1, s53, s1                                     // 0000001BD17C: 82010135
	global_load_b32 v1, v107, s[0:1]                           // 0000001BD180: DC520000 0100006B
	s_waitcnt vmcnt(0)                                         // 0000001BD188: BF8903F7
	v_readfirstlane_b32 s28, v1                                // 0000001BD18C: 7E380501
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001BD190: BE81206A
	s_cbranch_execz 77                                         // 0000001BD194: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6cc>
	v_or_b32_e32 v1, s7, v0                                    // 0000001BD198: 38020007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD19C: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001BD1A0: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001BD1A8: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD1AC: BF870091
	.long 0xd73c0001                                           // 0000001BD1B0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001BD1B4: 02020282
	.long 0xd7000001                                           // 0000001BD1B8: D7000001
	v_cndmask_b32_e32 v1, s52, v1, vcc_lo                      // 0000001BD1BC: 02020234
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001BD1C0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s53, v2, s0                  // 0000001BD1C4: D5207C02 00020435
	global_load_b32 v1, v[1:2], off                            // 0000001BD1CC: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001BD1D4: BF8903F7
	v_sub_f32_e32 v2, s28, v1                                  // 0000001BD1D8: 0804021C
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001BD1DC: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BD1E8: BF8701A1
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001BD1EC: D6130007 841202FF 3FB8AA3B
	v_rndne_f32_e32 v8, v4                                     // 0000001BD1F8: 7E104704
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001BD1FC: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001BD208: 7E0C4703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD20C: BF870113
	v_dual_fmac_f32 v7, 0x32a5705f, v1 :: v_dual_sub_f32 v4, v4, v8// 0000001BD210: C80A02FF 07041104 32A5705F
	v_sub_f32_e32 v3, v3, v6                                   // 0000001BD21C: 08060D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD220: BF870124
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001BD224: 560A04FF 32A5705F
	.long 0xd41b0000                                           // 0000001BD22C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v2, vcc_lo               // 0000001BD230: 020204FF C2CE8ED0
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v3, v3, v5     // 0000001BD238: C9080F04 04020B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001BD240: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001BD244: 7E0C1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BD248: BF870193
	v_exp_f32_e32 v4, v4                                       // 0000001BD24C: 7E084B04
	v_exp_f32_e32 v3, v3                                       // 0000001BD250: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BD254: BF870296
	.long 0xd71c0004                                           // 0000001BD258: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001BD25C: 02020D04
	.long 0xd71c0003                                           // 0000001BD260: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001BD264: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD268: BF8700A1
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 0000001BD26C: D5010003 00020680
	.long 0xd41b0000                                           // 0000001BD274: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v1, vcc_lo               // 0000001BD278: 020202FF C2CE8ED0
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 0000001BD280: D5010004 00020880
	.long 0xd41e0000                                           // 0000001BD288: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v2, vcc_lo               // 0000001BD28C: 020204FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD294: BF8700A1
	v_cndmask_b32_e64 v2, 0x7f800000, v3, s0                   // 0000001BD298: D5010002 000206FF 7F800000
	.long 0xd41e0000                                           // 0000001BD2A4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v1, vcc_lo               // 0000001BD2A8: 020202FF 42B17218
	v_cndmask_b32_e64 v1, 0x7f800000, v4, s0                   // 0000001BD2B0: D5010001 000208FF 7F800000
	ds_store_b32 v120, v2                                      // 0000001BD2BC: D8340000 00000278
	ds_store_b32 v121, v1                                      // 0000001BD2C4: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BD2CC: 8C7E017E
	s_mul_i32 s0, s23, 0x140000                                // 0000001BD2D0: 9600FF17 00140000
	s_sub_i32 s14, s58, s7                                     // 0000001BD2D8: 818E073A
	s_mul_hi_u32 s1, s23, 0x140000                             // 0000001BD2DC: 9681FF17 00140000
	s_add_u32 s0, s56, s0                                      // 0000001BD2E4: 80000038
	s_addc_u32 s1, s57, s1                                     // 0000001BD2E8: 82010139
	s_add_u32 s0, s0, s30                                      // 0000001BD2EC: 80001E00
	s_addc_u32 s1, s1, s31                                     // 0000001BD2F0: 82011F01
	.long 0xd7000009                                           // 0000001BD2F4: D7000009
	v_cndmask_b32_e32 v1, s0, v140, vcc_lo                     // 0000001BD2F8: 02031800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BD2FC: BF8700B1
	v_add_co_ci_u32_e64 v64, null, s1, 0, s0                   // 0000001BD300: D5207C40 00010001
	s_mul_hi_u32 s1, s23, 0x3000                               // 0000001BD308: 9681FF17 00003000
	.long 0xd7000001                                           // 0000001BD310: D7000001
	v_cndmask_b32_e32 v1, 0x1000, v9, vcc_lo                   // 0000001BD314: 020212FF 00001000
	v_add_co_ci_u32_e64 v2, null, 0, v64, s0                   // 0000001BD31C: D5207C02 00028080
	s_mul_i32 s0, s23, 0x3000                                  // 0000001BD324: 9600FF17 00003000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000001BD32C: BF8704C9
	s_add_u32 s47, s59, s0                                     // 0000001BD330: 802F003B
	s_addc_u32 s29, s60, s1                                    // 0000001BD334: 821D013C
	s_cmp_gt_i32 s14, 0                                        // 0000001BD338: BF02800E
	s_cselect_b32 s0, -1, 0                                    // 0000001BD33C: 980080C1
	v_cndmask_b32_e64 v2, v124, v2, s0                         // 0000001BD340: D5010002 0002057C
	v_cndmask_b32_e64 v1, v122, v1, s0                         // 0000001BD348: D5010001 0002037A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD350: 8B007E00
	.long 0xd7000004                                           // 0000001BD354: D7000004
	v_cndmask_b32_e32 v1, 0x6000, v9, vcc_lo                   // 0000001BD358: 020212FF 00006000
	s_cselect_b32 s9, s29, s65                                 // 0000001BD360: 9809411D
	s_cselect_b32 s8, s47, s64                                 // 0000001BD364: 9808402F
	s_add_u32 s1, s47, 0xc0                                    // 0000001BD368: 8001FF2F 000000C0
	v_add_co_ci_u32_e64 v3, null, 0, v64, s0                   // 0000001BD370: D5207C03 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BD378: 820A801D
	s_cmp_gt_i32 s14, 1                                        // 0000001BD37C: BF02810E
	global_load_d16_b16 v1, v[1:2], off                        // 0000001BD380: DC820000 017C0001
	s_cselect_b32 s0, -1, 0                                    // 0000001BD388: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD38C: BF870009
	v_cndmask_b32_e64 v3, v124, v3, s0                         // 0000001BD390: D5010003 0002077C
	v_cndmask_b32_e64 v2, v122, v4, s0                         // 0000001BD398: D5010002 0002097A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD3A0: 8B007E00
	.long 0xd7000005                                           // 0000001BD3A4: D7000005
	v_cndmask_b32_e32 v1, 0xb000, v9, vcc_lo                   // 0000001BD3A8: 020212FF 0000B000
	s_cselect_b32 s11, s10, s65                                // 0000001BD3B0: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BD3B4: 980A4001
	s_add_u32 s1, s47, 0x180                                   // 0000001BD3B8: 8001FF2F 00000180
	v_add_co_ci_u32_e64 v4, null, 0, v64, s0                   // 0000001BD3C0: D5207C04 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BD3C8: 820C801D
	s_cmp_gt_i32 s14, 2                                        // 0000001BD3CC: BF02820E
	global_load_d16_b16 v2, v[2:3], off                        // 0000001BD3D0: DC820000 027C0002
	s_cselect_b32 s0, -1, 0                                    // 0000001BD3D8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD3DC: BF870009
	v_cndmask_b32_e64 v4, v124, v4, s0                         // 0000001BD3E0: D5010004 0002097C
	v_cndmask_b32_e64 v3, v122, v5, s0                         // 0000001BD3E8: D5010003 00020B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD3F0: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BD3F4: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BD3F8: 980C4001
	s_add_u32 s1, s47, 0x240                                   // 0000001BD3FC: 8001FF2F 00000240
	s_addc_u32 s48, s29, 0                                     // 0000001BD404: 8230801D
	.long 0xd7000006                                           // 0000001BD408: D7000006
	v_cndmask_b32_e32 v1, 0x10000, v9, vcc_lo                  // 0000001BD40C: 020212FF 00010000
	s_cmp_gt_i32 s14, 3                                        // 0000001BD414: BF02830E
	v_add_co_ci_u32_e64 v5, null, 0, v64, s0                   // 0000001BD418: D5207C05 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BD420: 980080C1
	global_load_d16_b16 v3, v[3:4], off                        // 0000001BD424: DC820000 037C0003
	s_and_b32 s49, s0, exec_lo                                 // 0000001BD42C: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BD430: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BD434: 98304001
	.long 0xd7000108                                           // 0000001BD438: D7000108
	v_cndmask_b32_e32 v1, 0x15000, v9, vcc_lo                  // 0000001BD43C: 020212FF 00015000
	s_add_u32 s50, s47, 0x300                                  // 0000001BD444: 8032FF2F 00000300
	v_add_co_ci_u32_e64 v7, null, 0, v64, s1                   // 0000001BD44C: D5207C07 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD454: 8201801D
	s_cmp_gt_i32 s14, 4                                        // 0000001BD458: BF02840E
	v_cndmask_b32_e64 v5, v124, v5, s0                         // 0000001BD45C: D5010005 00020B7C
	v_cndmask_b32_e64 v4, v122, v6, s0                         // 0000001BD464: D5010004 00020D7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD46C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD470: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BD474: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BD478: 98334101
	.long 0xd700010a                                           // 0000001BD47C: D700010A
	v_cndmask_b32_e32 v1, 0x1a000, v9, vcc_lo                  // 0000001BD480: 020212FF 0001A000
	s_cselect_b32 s50, s50, s64                                // 0000001BD488: 98324032
	s_add_u32 s54, s47, 0x3c0                                  // 0000001BD48C: 8036FF2F 000003C0
	v_add_co_ci_u32_e64 v11, null, 0, v64, s1                  // 0000001BD494: D5207C0B 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD49C: 8201801D
	s_cmp_gt_i32 s14, 5                                        // 0000001BD4A0: BF02850E
	v_cndmask_b32_e64 v7, v124, v7, s0                         // 0000001BD4A4: D5010007 00020F7C
	v_cndmask_b32_e64 v6, v122, v8, s0                         // 0000001BD4AC: D5010006 0002117A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD4B4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD4B8: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BD4BC: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BD4C0: 98374101
	.long 0xd7000108                                           // 0000001BD4C4: D7000108
	v_cndmask_b32_e32 v1, 0x1f000, v9, vcc_lo                  // 0000001BD4C8: 020212FF 0001F000
	s_cselect_b32 s54, s54, s64                                // 0000001BD4D0: 98364036
	s_add_u32 s66, s47, 0x480                                  // 0000001BD4D4: 8042FF2F 00000480
	v_add_co_ci_u32_e64 v12, null, 0, v64, s1                  // 0000001BD4DC: D5207C0C 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD4E4: 8201801D
	s_cmp_gt_i32 s14, 6                                        // 0000001BD4E8: BF02860E
	v_cndmask_b32_e64 v11, v124, v11, s0                       // 0000001BD4EC: D501000B 0002177C
	v_cndmask_b32_e64 v10, v122, v10, s0                       // 0000001BD4F4: D501000A 0002157A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD4FC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD500: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BD504: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BD508: 98434101
	.long 0xd700010e                                           // 0000001BD50C: D700010E
	v_cndmask_b32_e32 v1, 0x24000, v9, vcc_lo                  // 0000001BD510: 020212FF 00024000
	s_cselect_b32 s66, s66, s64                                // 0000001BD518: 98424042
	s_add_u32 s68, s47, 0x540                                  // 0000001BD51C: 8044FF2F 00000540
	v_add_co_ci_u32_e64 v15, null, 0, v64, s1                  // 0000001BD524: D5207C0F 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD52C: 8201801D
	s_cmp_gt_i32 s14, 7                                        // 0000001BD530: BF02870E
	v_cndmask_b32_e64 v13, v124, v12, s0                       // 0000001BD534: D501000D 0002197C
	v_cndmask_b32_e64 v12, v122, v8, s0                        // 0000001BD53C: D501000C 0002117A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD544: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD548: BF870009
	v_cndmask_b32_e64 v15, v124, v15, s0                       // 0000001BD54C: D501000F 00021F7C
	v_cndmask_b32_e64 v14, v122, v14, s0                       // 0000001BD554: D501000E 00021D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD55C: 8B007E00
	global_load_d16_b16 v8, v[4:5], off                        // 0000001BD560: DC820000 087C0004
	global_load_d16_b16 v7, v[6:7], off                        // 0000001BD568: DC820000 077C0006
	global_load_d16_b16 v6, v[10:11], off                      // 0000001BD570: DC820000 067C000A
	global_load_d16_b16 v5, v[12:13], off                      // 0000001BD578: DC820000 057C000C
	global_load_d16_b16 v4, v[14:15], off                      // 0000001BD580: DC820000 047C000E
	.long 0xd700000a                                           // 0000001BD588: D700000A
	v_cndmask_b32_e32 v1, 0x29000, v9, vcc_lo                  // 0000001BD58C: 020212FF 00029000
	s_cselect_b32 s69, s1, s65                                 // 0000001BD594: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BD598: 98444044
	s_add_u32 s1, s47, 0x600                                   // 0000001BD59C: 8001FF2F 00000600
	s_addc_u32 s70, s29, 0                                     // 0000001BD5A4: 8246801D
	v_add_co_ci_u32_e64 v11, null, 0, v64, s0                  // 0000001BD5A8: D5207C0B 00028080
	s_cmp_gt_i32 s14, 8                                        // 0000001BD5B0: BF02880E
	s_clause 0x7                                               // 0000001BD5B4: BF850007
	global_load_b32 v73, v107, s[8:9]                          // 0000001BD5B8: DC520000 4908006B
	global_load_b32 v71, v107, s[10:11]                        // 0000001BD5C0: DC520000 470A006B
	global_load_b32 v72, v107, s[12:13]                        // 0000001BD5C8: DC520000 480C006B
	global_load_b32 v67, v107, s[48:49]                        // 0000001BD5D0: DC520000 4330006B
	global_load_b32 v68, v107, s[50:51]                        // 0000001BD5D8: DC520000 4432006B
	global_load_b32 v69, v107, s[54:55]                        // 0000001BD5E0: DC520000 4536006B
	global_load_b32 v70, v107, s[66:67]                        // 0000001BD5E8: DC520000 4642006B
	global_load_b32 v66, v107, s[68:69]                        // 0000001BD5F0: DC520000 4244006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BD5F8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD5FC: BF870009
	v_cndmask_b32_e64 v11, v124, v11, s0                       // 0000001BD600: D501000B 0002177C
	v_cndmask_b32_e64 v10, v122, v10, s0                       // 0000001BD608: D501000A 0002157A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD610: 8B007E00
	.long 0xd700000d                                           // 0000001BD614: D700000D
	v_cndmask_b32_e32 v1, 0x2e000, v9, vcc_lo                  // 0000001BD618: 020212FF 0002E000
	s_cselect_b32 s9, s70, s65                                 // 0000001BD620: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BD624: 98084001
	s_add_u32 s1, s47, 0x6c0                                   // 0000001BD628: 8001FF2F 000006C0
	v_add_co_ci_u32_e64 v12, null, 0, v64, s0                  // 0000001BD630: D5207C0C 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BD638: 820A801D
	s_cmp_gt_i32 s14, 9                                        // 0000001BD63C: BF02890E
	global_load_d16_b16 v10, v[10:11], off                     // 0000001BD640: DC820000 0A7C000A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD648: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD64C: BF870009
	v_cndmask_b32_e64 v12, v124, v12, s0                       // 0000001BD650: D501000C 0002197C
	v_cndmask_b32_e64 v11, v122, v13, s0                       // 0000001BD658: D501000B 00021B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD660: 8B007E00
	.long 0xd700000e                                           // 0000001BD664: D700000E
	v_cndmask_b32_e32 v1, 0x33000, v9, vcc_lo                  // 0000001BD668: 020212FF 00033000
	s_cselect_b32 s11, s10, s65                                // 0000001BD670: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BD674: 980A4001
	s_add_u32 s1, s47, 0x780                                   // 0000001BD678: 8001FF2F 00000780
	v_add_co_ci_u32_e64 v13, null, 0, v64, s0                  // 0000001BD680: D5207C0D 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BD688: 820C801D
	s_cmp_gt_i32 s14, 10                                       // 0000001BD68C: BF028A0E
	global_load_d16_b16 v11, v[11:12], off                     // 0000001BD690: DC820000 0B7C000B
	s_cselect_b32 s0, -1, 0                                    // 0000001BD698: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD69C: BF870009
	v_cndmask_b32_e64 v13, v124, v13, s0                       // 0000001BD6A0: D501000D 00021B7C
	v_cndmask_b32_e64 v12, v122, v14, s0                       // 0000001BD6A8: D501000C 00021D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD6B0: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BD6B4: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BD6B8: 980C4001
	s_add_u32 s1, s47, 0x840                                   // 0000001BD6BC: 8001FF2F 00000840
	s_addc_u32 s48, s29, 0                                     // 0000001BD6C4: 8230801D
	.long 0xd700000f                                           // 0000001BD6C8: D700000F
	v_cndmask_b32_e32 v1, 0x38000, v9, vcc_lo                  // 0000001BD6CC: 020212FF 00038000
	s_cmp_gt_i32 s14, 11                                       // 0000001BD6D4: BF028B0E
	v_add_co_ci_u32_e64 v14, null, 0, v64, s0                  // 0000001BD6D8: D5207C0E 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BD6E0: 980080C1
	global_load_d16_b16 v12, v[12:13], off                     // 0000001BD6E4: DC820000 0C7C000C
	s_and_b32 s49, s0, exec_lo                                 // 0000001BD6EC: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BD6F0: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BD6F4: 98304001
	.long 0xd7000111                                           // 0000001BD6F8: D7000111
	v_cndmask_b32_e32 v1, 0x3d000, v9, vcc_lo                  // 0000001BD6FC: 020212FF 0003D000
	s_add_u32 s50, s47, 0x900                                  // 0000001BD704: 8032FF2F 00000900
	v_add_co_ci_u32_e64 v16, null, 0, v64, s1                  // 0000001BD70C: D5207C10 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD714: 8201801D
	s_cmp_gt_i32 s14, 12                                       // 0000001BD718: BF028C0E
	v_cndmask_b32_e64 v14, v124, v14, s0                       // 0000001BD71C: D501000E 00021D7C
	v_cndmask_b32_e64 v13, v122, v15, s0                       // 0000001BD724: D501000D 00021F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD72C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD730: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BD734: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BD738: 98334101
	.long 0xd7000112                                           // 0000001BD73C: D7000112
	v_cndmask_b32_e32 v1, 0x42000, v9, vcc_lo                  // 0000001BD740: 020212FF 00042000
	s_cselect_b32 s50, s50, s64                                // 0000001BD748: 98324032
	s_add_u32 s54, s47, 0x9c0                                  // 0000001BD74C: 8036FF2F 000009C0
	v_add_co_ci_u32_e64 v19, null, 0, v64, s1                  // 0000001BD754: D5207C13 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD75C: 8201801D
	s_cmp_gt_i32 s14, 13                                       // 0000001BD760: BF028D0E
	v_cndmask_b32_e64 v16, v124, v16, s0                       // 0000001BD764: D5010010 0002217C
	v_cndmask_b32_e64 v15, v122, v17, s0                       // 0000001BD76C: D501000F 0002237A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD774: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD778: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BD77C: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BD780: 98374101
	.long 0xd7000111                                           // 0000001BD784: D7000111
	v_cndmask_b32_e32 v1, 0x47000, v9, vcc_lo                  // 0000001BD788: 020212FF 00047000
	s_cselect_b32 s54, s54, s64                                // 0000001BD790: 98364036
	s_add_u32 s66, s47, 0xa80                                  // 0000001BD794: 8042FF2F 00000A80
	v_add_co_ci_u32_e64 v20, null, 0, v64, s1                  // 0000001BD79C: D5207C14 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD7A4: 8201801D
	s_cmp_gt_i32 s14, 14                                       // 0000001BD7A8: BF028E0E
	v_cndmask_b32_e64 v19, v124, v19, s0                       // 0000001BD7AC: D5010013 0002277C
	v_cndmask_b32_e64 v18, v122, v18, s0                       // 0000001BD7B4: D5010012 0002257A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD7BC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD7C0: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BD7C4: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BD7C8: 98434101
	.long 0xd7000116                                           // 0000001BD7CC: D7000116
	v_cndmask_b32_e32 v1, 0x4c000, v9, vcc_lo                  // 0000001BD7D0: 020212FF 0004C000
	s_cselect_b32 s66, s66, s64                                // 0000001BD7D8: 98424042
	s_add_u32 s68, s47, 0xb40                                  // 0000001BD7DC: 8044FF2F 00000B40
	v_add_co_ci_u32_e64 v23, null, 0, v64, s1                  // 0000001BD7E4: D5207C17 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD7EC: 8201801D
	s_cmp_gt_i32 s14, 15                                       // 0000001BD7F0: BF028F0E
	v_cndmask_b32_e64 v21, v124, v20, s0                       // 0000001BD7F4: D5010015 0002297C
	v_cndmask_b32_e64 v20, v122, v17, s0                       // 0000001BD7FC: D5010014 0002237A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD804: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD808: BF870009
	v_cndmask_b32_e64 v23, v124, v23, s0                       // 0000001BD80C: D5010017 00022F7C
	v_cndmask_b32_e64 v22, v122, v22, s0                       // 0000001BD814: D5010016 00022D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD81C: 8B007E00
	global_load_d16_b16 v17, v[13:14], off                     // 0000001BD820: DC820000 117C000D
	global_load_d16_b16 v16, v[15:16], off                     // 0000001BD828: DC820000 107C000F
	global_load_d16_b16 v15, v[18:19], off                     // 0000001BD830: DC820000 0F7C0012
	global_load_d16_b16 v13, v[20:21], off                     // 0000001BD838: DC820000 0D7C0014
	global_load_d16_b16 v14, v[22:23], off                     // 0000001BD840: DC820000 0E7C0016
	.long 0xd7000012                                           // 0000001BD848: D7000012
	v_cndmask_b32_e32 v1, 0x51000, v9, vcc_lo                  // 0000001BD84C: 020212FF 00051000
	s_cselect_b32 s69, s1, s65                                 // 0000001BD854: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BD858: 98444044
	s_add_u32 s1, s47, 0xc00                                   // 0000001BD85C: 8001FF2F 00000C00
	s_addc_u32 s70, s29, 0                                     // 0000001BD864: 8246801D
	v_add_co_ci_u32_e64 v19, null, 0, v64, s0                  // 0000001BD868: D5207C13 00028080
	s_cmp_gt_i32 s14, 16                                       // 0000001BD870: BF02900E
	s_clause 0x7                                               // 0000001BD874: BF850007
	global_load_b32 v78, v107, s[8:9]                          // 0000001BD878: DC520000 4E08006B
	global_load_b32 v79, v107, s[10:11]                        // 0000001BD880: DC520000 4F0A006B
	global_load_b32 v80, v107, s[12:13]                        // 0000001BD888: DC520000 500C006B
	global_load_b32 v81, v107, s[48:49]                        // 0000001BD890: DC520000 5130006B
	global_load_b32 v77, v107, s[50:51]                        // 0000001BD898: DC520000 4D32006B
	global_load_b32 v74, v107, s[54:55]                        // 0000001BD8A0: DC520000 4A36006B
	global_load_b32 v75, v107, s[66:67]                        // 0000001BD8A8: DC520000 4B42006B
	global_load_b32 v76, v107, s[68:69]                        // 0000001BD8B0: DC520000 4C44006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BD8B8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD8BC: BF870009
	v_cndmask_b32_e64 v19, v124, v19, s0                       // 0000001BD8C0: D5010013 0002277C
	v_cndmask_b32_e64 v18, v122, v18, s0                       // 0000001BD8C8: D5010012 0002257A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD8D0: 8B007E00
	.long 0xd7000015                                           // 0000001BD8D4: D7000015
	v_cndmask_b32_e32 v1, 0x56000, v9, vcc_lo                  // 0000001BD8D8: 020212FF 00056000
	s_cselect_b32 s9, s70, s65                                 // 0000001BD8E0: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BD8E4: 98084001
	s_add_u32 s1, s47, 0xcc0                                   // 0000001BD8E8: 8001FF2F 00000CC0
	v_add_co_ci_u32_e64 v20, null, 0, v64, s0                  // 0000001BD8F0: D5207C14 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BD8F8: 820A801D
	s_cmp_gt_i32 s14, 17                                       // 0000001BD8FC: BF02910E
	global_load_d16_b16 v18, v[18:19], off                     // 0000001BD900: DC820000 127C0012
	s_cselect_b32 s0, -1, 0                                    // 0000001BD908: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD90C: BF870009
	v_cndmask_b32_e64 v20, v124, v20, s0                       // 0000001BD910: D5010014 0002297C
	v_cndmask_b32_e64 v19, v122, v21, s0                       // 0000001BD918: D5010013 00022B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD920: 8B007E00
	.long 0xd7000016                                           // 0000001BD924: D7000016
	v_cndmask_b32_e32 v1, 0x5b000, v9, vcc_lo                  // 0000001BD928: 020212FF 0005B000
	s_cselect_b32 s11, s10, s65                                // 0000001BD930: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BD934: 980A4001
	s_add_u32 s1, s47, 0xd80                                   // 0000001BD938: 8001FF2F 00000D80
	v_add_co_ci_u32_e64 v21, null, 0, v64, s0                  // 0000001BD940: D5207C15 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BD948: 820C801D
	s_cmp_gt_i32 s14, 18                                       // 0000001BD94C: BF02920E
	global_load_d16_b16 v19, v[19:20], off                     // 0000001BD950: DC820000 137C0013
	s_cselect_b32 s0, -1, 0                                    // 0000001BD958: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD95C: BF870009
	v_cndmask_b32_e64 v21, v124, v21, s0                       // 0000001BD960: D5010015 00022B7C
	v_cndmask_b32_e64 v20, v122, v22, s0                       // 0000001BD968: D5010014 00022D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BD970: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BD974: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BD978: 980C4001
	s_add_u32 s1, s47, 0xe40                                   // 0000001BD97C: 8001FF2F 00000E40
	s_addc_u32 s48, s29, 0                                     // 0000001BD984: 8230801D
	.long 0xd7000017                                           // 0000001BD988: D7000017
	v_cndmask_b32_e32 v1, 0x60000, v9, vcc_lo                  // 0000001BD98C: 020212FF 00060000
	s_cmp_gt_i32 s14, 19                                       // 0000001BD994: BF02930E
	v_add_co_ci_u32_e64 v22, null, 0, v64, s0                  // 0000001BD998: D5207C16 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BD9A0: 980080C1
	global_load_d16_b16 v20, v[20:21], off                     // 0000001BD9A4: DC820000 147C0014
	s_and_b32 s49, s0, exec_lo                                 // 0000001BD9AC: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BD9B0: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BD9B4: 98304001
	.long 0xd7000119                                           // 0000001BD9B8: D7000119
	v_cndmask_b32_e32 v1, 0x65000, v9, vcc_lo                  // 0000001BD9BC: 020212FF 00065000
	s_add_u32 s50, s47, 0xf00                                  // 0000001BD9C4: 8032FF2F 00000F00
	v_add_co_ci_u32_e64 v24, null, 0, v64, s1                  // 0000001BD9CC: D5207C18 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BD9D4: 8201801D
	s_cmp_gt_i32 s14, 20                                       // 0000001BD9D8: BF02940E
	v_cndmask_b32_e64 v22, v124, v22, s0                       // 0000001BD9DC: D5010016 00022D7C
	v_cndmask_b32_e64 v21, v122, v23, s0                       // 0000001BD9E4: D5010015 00022F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BD9EC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BD9F0: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BD9F4: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BD9F8: 98334101
	.long 0xd700011a                                           // 0000001BD9FC: D700011A
	v_cndmask_b32_e32 v1, 0x6a000, v9, vcc_lo                  // 0000001BDA00: 020212FF 0006A000
	s_cselect_b32 s50, s50, s64                                // 0000001BDA08: 98324032
	s_add_u32 s54, s47, 0xfc0                                  // 0000001BDA0C: 8036FF2F 00000FC0
	v_add_co_ci_u32_e64 v27, null, 0, v64, s1                  // 0000001BDA14: D5207C1B 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDA1C: 8201801D
	s_cmp_gt_i32 s14, 21                                       // 0000001BDA20: BF02950E
	v_cndmask_b32_e64 v24, v124, v24, s0                       // 0000001BDA24: D5010018 0002317C
	v_cndmask_b32_e64 v23, v122, v25, s0                       // 0000001BDA2C: D5010017 0002337A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDA34: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDA38: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BDA3C: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BDA40: 98374101
	.long 0xd7000119                                           // 0000001BDA44: D7000119
	v_cndmask_b32_e32 v1, 0x6f000, v9, vcc_lo                  // 0000001BDA48: 020212FF 0006F000
	s_cselect_b32 s54, s54, s64                                // 0000001BDA50: 98364036
	s_add_u32 s66, s47, 0x1080                                 // 0000001BDA54: 8042FF2F 00001080
	v_add_co_ci_u32_e64 v28, null, 0, v64, s1                  // 0000001BDA5C: D5207C1C 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDA64: 8201801D
	s_cmp_gt_i32 s14, 22                                       // 0000001BDA68: BF02960E
	v_cndmask_b32_e64 v27, v124, v27, s0                       // 0000001BDA6C: D501001B 0002377C
	v_cndmask_b32_e64 v26, v122, v26, s0                       // 0000001BDA74: D501001A 0002357A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDA7C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDA80: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BDA84: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BDA88: 98434101
	.long 0xd700011e                                           // 0000001BDA8C: D700011E
	v_cndmask_b32_e32 v1, 0x74000, v9, vcc_lo                  // 0000001BDA90: 020212FF 00074000
	s_cselect_b32 s66, s66, s64                                // 0000001BDA98: 98424042
	s_add_u32 s68, s47, 0x1140                                 // 0000001BDA9C: 8044FF2F 00001140
	v_add_co_ci_u32_e64 v31, null, 0, v64, s1                  // 0000001BDAA4: D5207C1F 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDAAC: 8201801D
	s_cmp_gt_i32 s14, 23                                       // 0000001BDAB0: BF02970E
	v_cndmask_b32_e64 v29, v124, v28, s0                       // 0000001BDAB4: D501001D 0002397C
	v_cndmask_b32_e64 v28, v122, v25, s0                       // 0000001BDABC: D501001C 0002337A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDAC4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDAC8: BF870009
	v_cndmask_b32_e64 v31, v124, v31, s0                       // 0000001BDACC: D501001F 00023F7C
	v_cndmask_b32_e64 v30, v122, v30, s0                       // 0000001BDAD4: D501001E 00023D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDADC: 8B007E00
	global_load_d16_b16 v25, v[21:22], off                     // 0000001BDAE0: DC820000 197C0015
	global_load_d16_b16 v24, v[23:24], off                     // 0000001BDAE8: DC820000 187C0017
	global_load_d16_b16 v23, v[26:27], off                     // 0000001BDAF0: DC820000 177C001A
	global_load_d16_b16 v22, v[28:29], off                     // 0000001BDAF8: DC820000 167C001C
	global_load_d16_b16 v21, v[30:31], off                     // 0000001BDB00: DC820000 157C001E
	.long 0xd700001a                                           // 0000001BDB08: D700001A
	v_cndmask_b32_e32 v1, 0x79000, v9, vcc_lo                  // 0000001BDB0C: 020212FF 00079000
	s_cselect_b32 s69, s1, s65                                 // 0000001BDB14: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BDB18: 98444044
	s_add_u32 s1, s47, 0x1200                                  // 0000001BDB1C: 8001FF2F 00001200
	s_addc_u32 s70, s29, 0                                     // 0000001BDB24: 8246801D
	v_add_co_ci_u32_e64 v27, null, 0, v64, s0                  // 0000001BDB28: D5207C1B 00028080
	s_cmp_gt_i32 s14, 24                                       // 0000001BDB30: BF02980E
	s_clause 0x7                                               // 0000001BDB34: BF850007
	global_load_b32 v89, v107, s[8:9]                          // 0000001BDB38: DC520000 5908006B
	global_load_b32 v88, v107, s[10:11]                        // 0000001BDB40: DC520000 580A006B
	global_load_b32 v84, v107, s[12:13]                        // 0000001BDB48: DC520000 540C006B
	global_load_b32 v85, v107, s[48:49]                        // 0000001BDB50: DC520000 5530006B
	global_load_b32 v86, v107, s[50:51]                        // 0000001BDB58: DC520000 5632006B
	global_load_b32 v87, v107, s[54:55]                        // 0000001BDB60: DC520000 5736006B
	global_load_b32 v83, v107, s[66:67]                        // 0000001BDB68: DC520000 5342006B
	global_load_b32 v82, v107, s[68:69]                        // 0000001BDB70: DC520000 5244006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BDB78: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDB7C: BF870009
	v_cndmask_b32_e64 v27, v124, v27, s0                       // 0000001BDB80: D501001B 0002377C
	v_cndmask_b32_e64 v26, v122, v26, s0                       // 0000001BDB88: D501001A 0002357A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDB90: 8B007E00
	.long 0xd700001d                                           // 0000001BDB94: D700001D
	v_cndmask_b32_e32 v1, 0x7e000, v9, vcc_lo                  // 0000001BDB98: 020212FF 0007E000
	s_cselect_b32 s9, s70, s65                                 // 0000001BDBA0: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BDBA4: 98084001
	s_add_u32 s1, s47, 0x12c0                                  // 0000001BDBA8: 8001FF2F 000012C0
	v_add_co_ci_u32_e64 v28, null, 0, v64, s0                  // 0000001BDBB0: D5207C1C 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BDBB8: 820A801D
	s_cmp_gt_i32 s14, 25                                       // 0000001BDBBC: BF02990E
	global_load_d16_b16 v26, v[26:27], off                     // 0000001BDBC0: DC820000 1A7C001A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDBC8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDBCC: BF870009
	v_cndmask_b32_e64 v28, v124, v28, s0                       // 0000001BDBD0: D501001C 0002397C
	v_cndmask_b32_e64 v27, v122, v29, s0                       // 0000001BDBD8: D501001B 00023B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDBE0: 8B007E00
	.long 0xd700001e                                           // 0000001BDBE4: D700001E
	v_cndmask_b32_e32 v1, 0x83000, v9, vcc_lo                  // 0000001BDBE8: 020212FF 00083000
	s_cselect_b32 s11, s10, s65                                // 0000001BDBF0: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BDBF4: 980A4001
	s_add_u32 s1, s47, 0x1380                                  // 0000001BDBF8: 8001FF2F 00001380
	v_add_co_ci_u32_e64 v29, null, 0, v64, s0                  // 0000001BDC00: D5207C1D 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BDC08: 820C801D
	s_cmp_gt_i32 s14, 26                                       // 0000001BDC0C: BF029A0E
	global_load_d16_b16 v27, v[27:28], off                     // 0000001BDC10: DC820000 1B7C001B
	s_cselect_b32 s0, -1, 0                                    // 0000001BDC18: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDC1C: BF870009
	v_cndmask_b32_e64 v29, v124, v29, s0                       // 0000001BDC20: D501001D 00023B7C
	v_cndmask_b32_e64 v28, v122, v30, s0                       // 0000001BDC28: D501001C 00023D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDC30: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BDC34: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BDC38: 980C4001
	s_add_u32 s1, s47, 0x1440                                  // 0000001BDC3C: 8001FF2F 00001440
	s_addc_u32 s48, s29, 0                                     // 0000001BDC44: 8230801D
	.long 0xd700001f                                           // 0000001BDC48: D700001F
	v_cndmask_b32_e32 v1, 0x88000, v9, vcc_lo                  // 0000001BDC4C: 020212FF 00088000
	s_cmp_gt_i32 s14, 27                                       // 0000001BDC54: BF029B0E
	v_add_co_ci_u32_e64 v30, null, 0, v64, s0                  // 0000001BDC58: D5207C1E 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BDC60: 980080C1
	global_load_d16_b16 v28, v[28:29], off                     // 0000001BDC64: DC820000 1C7C001C
	s_and_b32 s49, s0, exec_lo                                 // 0000001BDC6C: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BDC70: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BDC74: 98304001
	.long 0xd7000121                                           // 0000001BDC78: D7000121
	v_cndmask_b32_e32 v1, 0x8d000, v9, vcc_lo                  // 0000001BDC7C: 020212FF 0008D000
	s_add_u32 s50, s47, 0x1500                                 // 0000001BDC84: 8032FF2F 00001500
	v_add_co_ci_u32_e64 v32, null, 0, v64, s1                  // 0000001BDC8C: D5207C20 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDC94: 8201801D
	s_cmp_gt_i32 s14, 28                                       // 0000001BDC98: BF029C0E
	v_cndmask_b32_e64 v30, v124, v30, s0                       // 0000001BDC9C: D501001E 00023D7C
	v_cndmask_b32_e64 v29, v122, v31, s0                       // 0000001BDCA4: D501001D 00023F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDCAC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDCB0: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BDCB4: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BDCB8: 98334101
	.long 0xd7000122                                           // 0000001BDCBC: D7000122
	v_cndmask_b32_e32 v1, 0x92000, v9, vcc_lo                  // 0000001BDCC0: 020212FF 00092000
	s_cselect_b32 s50, s50, s64                                // 0000001BDCC8: 98324032
	s_add_u32 s54, s47, 0x15c0                                 // 0000001BDCCC: 8036FF2F 000015C0
	v_add_co_ci_u32_e64 v35, null, 0, v64, s1                  // 0000001BDCD4: D5207C23 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDCDC: 8201801D
	s_cmp_gt_i32 s14, 29                                       // 0000001BDCE0: BF029D0E
	v_cndmask_b32_e64 v32, v124, v32, s0                       // 0000001BDCE4: D5010020 0002417C
	v_cndmask_b32_e64 v31, v122, v33, s0                       // 0000001BDCEC: D501001F 0002437A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDCF4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDCF8: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BDCFC: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BDD00: 98374101
	.long 0xd7000121                                           // 0000001BDD04: D7000121
	v_cndmask_b32_e32 v1, 0x97000, v9, vcc_lo                  // 0000001BDD08: 020212FF 00097000
	s_cselect_b32 s54, s54, s64                                // 0000001BDD10: 98364036
	s_add_u32 s66, s47, 0x1680                                 // 0000001BDD14: 8042FF2F 00001680
	v_add_co_ci_u32_e64 v36, null, 0, v64, s1                  // 0000001BDD1C: D5207C24 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDD24: 8201801D
	s_cmp_gt_i32 s14, 30                                       // 0000001BDD28: BF029E0E
	v_cndmask_b32_e64 v35, v124, v35, s0                       // 0000001BDD2C: D5010023 0002477C
	v_cndmask_b32_e64 v34, v122, v34, s0                       // 0000001BDD34: D5010022 0002457A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDD3C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDD40: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BDD44: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BDD48: 98434101
	.long 0xd7000126                                           // 0000001BDD4C: D7000126
	v_cndmask_b32_e32 v1, 0x9c000, v9, vcc_lo                  // 0000001BDD50: 020212FF 0009C000
	s_cselect_b32 s66, s66, s64                                // 0000001BDD58: 98424042
	s_add_u32 s68, s47, 0x1740                                 // 0000001BDD5C: 8044FF2F 00001740
	v_add_co_ci_u32_e64 v39, null, 0, v64, s1                  // 0000001BDD64: D5207C27 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDD6C: 8201801D
	s_cmp_gt_i32 s14, 31                                       // 0000001BDD70: BF029F0E
	v_cndmask_b32_e64 v37, v124, v36, s0                       // 0000001BDD74: D5010025 0002497C
	v_cndmask_b32_e64 v36, v122, v33, s0                       // 0000001BDD7C: D5010024 0002437A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDD84: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDD88: BF870009
	v_cndmask_b32_e64 v39, v124, v39, s0                       // 0000001BDD8C: D5010027 00024F7C
	v_cndmask_b32_e64 v38, v122, v38, s0                       // 0000001BDD94: D5010026 00024D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDD9C: 8B007E00
	global_load_d16_b16 v33, v[29:30], off                     // 0000001BDDA0: DC820000 217C001D
	global_load_d16_b16 v32, v[31:32], off                     // 0000001BDDA8: DC820000 207C001F
	global_load_d16_b16 v31, v[34:35], off                     // 0000001BDDB0: DC820000 1F7C0022
	global_load_d16_b16 v29, v[36:37], off                     // 0000001BDDB8: DC820000 1D7C0024
	global_load_d16_b16 v30, v[38:39], off                     // 0000001BDDC0: DC820000 1E7C0026
	.long 0xd7000022                                           // 0000001BDDC8: D7000022
	v_cndmask_b32_e32 v1, 0xa1000, v9, vcc_lo                  // 0000001BDDCC: 020212FF 000A1000
	s_cselect_b32 s69, s1, s65                                 // 0000001BDDD4: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BDDD8: 98444044
	s_add_u32 s1, s47, 0x1800                                  // 0000001BDDDC: 8001FF2F 00001800
	s_addc_u32 s70, s29, 0                                     // 0000001BDDE4: 8246801D
	v_add_co_ci_u32_e64 v35, null, 0, v64, s0                  // 0000001BDDE8: D5207C23 00028080
	s_cmp_gt_i32 s14, 32                                       // 0000001BDDF0: BF02A00E
	s_clause 0x7                                               // 0000001BDDF4: BF850007
	global_load_b32 v95, v107, s[8:9]                          // 0000001BDDF8: DC520000 5F08006B
	global_load_b32 v96, v107, s[10:11]                        // 0000001BDE00: DC520000 600A006B
	global_load_b32 v97, v107, s[12:13]                        // 0000001BDE08: DC520000 610C006B
	global_load_b32 v94, v107, s[48:49]                        // 0000001BDE10: DC520000 5E30006B
	global_load_b32 v90, v107, s[50:51]                        // 0000001BDE18: DC520000 5A32006B
	global_load_b32 v91, v107, s[54:55]                        // 0000001BDE20: DC520000 5B36006B
	global_load_b32 v92, v107, s[66:67]                        // 0000001BDE28: DC520000 5C42006B
	global_load_b32 v93, v107, s[68:69]                        // 0000001BDE30: DC520000 5D44006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BDE38: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDE3C: BF870009
	v_cndmask_b32_e64 v35, v124, v35, s0                       // 0000001BDE40: D5010023 0002477C
	v_cndmask_b32_e64 v34, v122, v34, s0                       // 0000001BDE48: D5010022 0002457A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDE50: 8B007E00
	.long 0xd7000025                                           // 0000001BDE54: D7000025
	v_cndmask_b32_e32 v1, 0xa6000, v9, vcc_lo                  // 0000001BDE58: 020212FF 000A6000
	s_cselect_b32 s9, s70, s65                                 // 0000001BDE60: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BDE64: 98084001
	s_add_u32 s1, s47, 0x18c0                                  // 0000001BDE68: 8001FF2F 000018C0
	v_add_co_ci_u32_e64 v36, null, 0, v64, s0                  // 0000001BDE70: D5207C24 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BDE78: 820A801D
	s_cmp_gt_i32 s14, 33                                       // 0000001BDE7C: BF02A10E
	global_load_d16_b16 v34, v[34:35], off                     // 0000001BDE80: DC820000 227C0022
	s_cselect_b32 s0, -1, 0                                    // 0000001BDE88: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDE8C: BF870009
	v_cndmask_b32_e64 v36, v124, v36, s0                       // 0000001BDE90: D5010024 0002497C
	v_cndmask_b32_e64 v35, v122, v37, s0                       // 0000001BDE98: D5010023 00024B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDEA0: 8B007E00
	.long 0xd7000026                                           // 0000001BDEA4: D7000026
	v_cndmask_b32_e32 v1, 0xab000, v9, vcc_lo                  // 0000001BDEA8: 020212FF 000AB000
	s_cselect_b32 s11, s10, s65                                // 0000001BDEB0: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BDEB4: 980A4001
	s_add_u32 s1, s47, 0x1980                                  // 0000001BDEB8: 8001FF2F 00001980
	v_add_co_ci_u32_e64 v37, null, 0, v64, s0                  // 0000001BDEC0: D5207C25 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BDEC8: 820C801D
	s_cmp_gt_i32 s14, 34                                       // 0000001BDECC: BF02A20E
	global_load_d16_b16 v35, v[35:36], off                     // 0000001BDED0: DC820000 237C0023
	s_cselect_b32 s0, -1, 0                                    // 0000001BDED8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDEDC: BF870009
	v_cndmask_b32_e64 v37, v124, v37, s0                       // 0000001BDEE0: D5010025 00024B7C
	v_cndmask_b32_e64 v36, v122, v38, s0                       // 0000001BDEE8: D5010024 00024D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BDEF0: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BDEF4: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BDEF8: 980C4001
	s_add_u32 s1, s47, 0x1a40                                  // 0000001BDEFC: 8001FF2F 00001A40
	s_addc_u32 s48, s29, 0                                     // 0000001BDF04: 8230801D
	.long 0xd7000027                                           // 0000001BDF08: D7000027
	v_cndmask_b32_e32 v1, 0xb0000, v9, vcc_lo                  // 0000001BDF0C: 020212FF 000B0000
	s_cmp_gt_i32 s14, 35                                       // 0000001BDF14: BF02A30E
	v_add_co_ci_u32_e64 v38, null, 0, v64, s0                  // 0000001BDF18: D5207C26 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BDF20: 980080C1
	global_load_d16_b16 v36, v[36:37], off                     // 0000001BDF24: DC820000 247C0024
	s_and_b32 s49, s0, exec_lo                                 // 0000001BDF2C: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BDF30: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BDF34: 98304001
	.long 0xd7000129                                           // 0000001BDF38: D7000129
	v_cndmask_b32_e32 v1, 0xb5000, v9, vcc_lo                  // 0000001BDF3C: 020212FF 000B5000
	s_add_u32 s50, s47, 0x1b00                                 // 0000001BDF44: 8032FF2F 00001B00
	v_add_co_ci_u32_e64 v40, null, 0, v64, s1                  // 0000001BDF4C: D5207C28 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDF54: 8201801D
	s_cmp_gt_i32 s14, 36                                       // 0000001BDF58: BF02A40E
	v_cndmask_b32_e64 v38, v124, v38, s0                       // 0000001BDF5C: D5010026 00024D7C
	v_cndmask_b32_e64 v37, v122, v39, s0                       // 0000001BDF64: D5010025 00024F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDF6C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDF70: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BDF74: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BDF78: 98334101
	.long 0xd700012a                                           // 0000001BDF7C: D700012A
	v_cndmask_b32_e32 v1, 0xba000, v9, vcc_lo                  // 0000001BDF80: 020212FF 000BA000
	s_cselect_b32 s50, s50, s64                                // 0000001BDF88: 98324032
	s_add_u32 s54, s47, 0x1bc0                                 // 0000001BDF8C: 8036FF2F 00001BC0
	v_add_co_ci_u32_e64 v43, null, 0, v64, s1                  // 0000001BDF94: D5207C2B 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDF9C: 8201801D
	s_cmp_gt_i32 s14, 37                                       // 0000001BDFA0: BF02A50E
	v_cndmask_b32_e64 v40, v124, v40, s0                       // 0000001BDFA4: D5010028 0002517C
	v_cndmask_b32_e64 v39, v122, v41, s0                       // 0000001BDFAC: D5010027 0002537A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDFB4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BDFB8: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BDFBC: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BDFC0: 98374101
	.long 0xd7000129                                           // 0000001BDFC4: D7000129
	v_cndmask_b32_e32 v1, 0xbf000, v9, vcc_lo                  // 0000001BDFC8: 020212FF 000BF000
	s_cselect_b32 s54, s54, s64                                // 0000001BDFD0: 98364036
	s_add_u32 s66, s47, 0x1c80                                 // 0000001BDFD4: 8042FF2F 00001C80
	v_add_co_ci_u32_e64 v44, null, 0, v64, s1                  // 0000001BDFDC: D5207C2C 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BDFE4: 8201801D
	s_cmp_gt_i32 s14, 38                                       // 0000001BDFE8: BF02A60E
	v_cndmask_b32_e64 v43, v124, v43, s0                       // 0000001BDFEC: D501002B 0002577C
	v_cndmask_b32_e64 v42, v122, v42, s0                       // 0000001BDFF4: D501002A 0002557A
	s_cselect_b32 s0, -1, 0                                    // 0000001BDFFC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE000: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BE004: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BE008: 98434101
	.long 0xd700012e                                           // 0000001BE00C: D700012E
	v_cndmask_b32_e32 v1, 0xc4000, v9, vcc_lo                  // 0000001BE010: 020212FF 000C4000
	s_cselect_b32 s66, s66, s64                                // 0000001BE018: 98424042
	s_add_u32 s68, s47, 0x1d40                                 // 0000001BE01C: 8044FF2F 00001D40
	v_add_co_ci_u32_e64 v47, null, 0, v64, s1                  // 0000001BE024: D5207C2F 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE02C: 8201801D
	s_cmp_gt_i32 s14, 39                                       // 0000001BE030: BF02A70E
	v_cndmask_b32_e64 v45, v124, v44, s0                       // 0000001BE034: D501002D 0002597C
	v_cndmask_b32_e64 v44, v122, v41, s0                       // 0000001BE03C: D501002C 0002537A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE044: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE048: BF870009
	v_cndmask_b32_e64 v47, v124, v47, s0                       // 0000001BE04C: D501002F 00025F7C
	v_cndmask_b32_e64 v46, v122, v46, s0                       // 0000001BE054: D501002E 00025D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE05C: 8B007E00
	global_load_d16_b16 v41, v[37:38], off                     // 0000001BE060: DC820000 297C0025
	global_load_d16_b16 v40, v[39:40], off                     // 0000001BE068: DC820000 287C0027
	global_load_d16_b16 v39, v[42:43], off                     // 0000001BE070: DC820000 277C002A
	global_load_d16_b16 v37, v[44:45], off                     // 0000001BE078: DC820000 257C002C
	global_load_d16_b16 v38, v[46:47], off                     // 0000001BE080: DC820000 267C002E
	.long 0xd700002a                                           // 0000001BE088: D700002A
	v_cndmask_b32_e32 v1, 0xc9000, v9, vcc_lo                  // 0000001BE08C: 020212FF 000C9000
	s_cselect_b32 s69, s1, s65                                 // 0000001BE094: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BE098: 98444044
	s_add_u32 s1, s47, 0x1e00                                  // 0000001BE09C: 8001FF2F 00001E00
	s_addc_u32 s70, s29, 0                                     // 0000001BE0A4: 8246801D
	v_add_co_ci_u32_e64 v43, null, 0, v64, s0                  // 0000001BE0A8: D5207C2B 00028080
	s_cmp_gt_i32 s14, 40                                       // 0000001BE0B0: BF02A80E
	s_clause 0x7                                               // 0000001BE0B4: BF850007
	global_load_b32 v104, v107, s[8:9]                         // 0000001BE0B8: DC520000 6808006B
	global_load_b32 v101, v107, s[10:11]                       // 0000001BE0C0: DC520000 650A006B
	global_load_b32 v102, v107, s[12:13]                       // 0000001BE0C8: DC520000 660C006B
	global_load_b32 v103, v107, s[48:49]                       // 0000001BE0D0: DC520000 6730006B
	global_load_b32 v105, v107, s[50:51]                       // 0000001BE0D8: DC520000 6932006B
	global_load_b32 v100, v107, s[54:55]                       // 0000001BE0E0: DC520000 6436006B
	global_load_b32 v98, v107, s[66:67]                        // 0000001BE0E8: DC520000 6242006B
	global_load_b32 v99, v107, s[68:69]                        // 0000001BE0F0: DC520000 6344006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BE0F8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE0FC: BF870009
	v_cndmask_b32_e64 v43, v124, v43, s0                       // 0000001BE100: D501002B 0002577C
	v_cndmask_b32_e64 v42, v122, v42, s0                       // 0000001BE108: D501002A 0002557A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE110: 8B007E00
	.long 0xd700002d                                           // 0000001BE114: D700002D
	v_cndmask_b32_e32 v1, 0xce000, v9, vcc_lo                  // 0000001BE118: 020212FF 000CE000
	s_cselect_b32 s9, s70, s65                                 // 0000001BE120: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BE124: 98084001
	s_add_u32 s1, s47, 0x1ec0                                  // 0000001BE128: 8001FF2F 00001EC0
	v_add_co_ci_u32_e64 v44, null, 0, v64, s0                  // 0000001BE130: D5207C2C 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BE138: 820A801D
	s_cmp_gt_i32 s14, 41                                       // 0000001BE13C: BF02A90E
	global_load_d16_b16 v42, v[42:43], off                     // 0000001BE140: DC820000 2A7C002A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE148: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE14C: BF870009
	v_cndmask_b32_e64 v44, v124, v44, s0                       // 0000001BE150: D501002C 0002597C
	v_cndmask_b32_e64 v43, v122, v45, s0                       // 0000001BE158: D501002B 00025B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE160: 8B007E00
	.long 0xd700002e                                           // 0000001BE164: D700002E
	v_cndmask_b32_e32 v1, 0xd3000, v9, vcc_lo                  // 0000001BE168: 020212FF 000D3000
	s_cselect_b32 s11, s10, s65                                // 0000001BE170: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BE174: 980A4001
	s_add_u32 s1, s47, 0x1f80                                  // 0000001BE178: 8001FF2F 00001F80
	v_add_co_ci_u32_e64 v45, null, 0, v64, s0                  // 0000001BE180: D5207C2D 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BE188: 820C801D
	s_cmp_gt_i32 s14, 42                                       // 0000001BE18C: BF02AA0E
	global_load_d16_b16 v43, v[43:44], off                     // 0000001BE190: DC820000 2B7C002B
	s_cselect_b32 s0, -1, 0                                    // 0000001BE198: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE19C: BF870009
	v_cndmask_b32_e64 v45, v124, v45, s0                       // 0000001BE1A0: D501002D 00025B7C
	v_cndmask_b32_e64 v44, v122, v46, s0                       // 0000001BE1A8: D501002C 00025D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE1B0: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BE1B4: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BE1B8: 980C4001
	s_add_u32 s1, s47, 0x2040                                  // 0000001BE1BC: 8001FF2F 00002040
	s_addc_u32 s48, s29, 0                                     // 0000001BE1C4: 8230801D
	.long 0xd700002f                                           // 0000001BE1C8: D700002F
	v_cndmask_b32_e32 v1, 0xd8000, v9, vcc_lo                  // 0000001BE1CC: 020212FF 000D8000
	s_cmp_gt_i32 s14, 43                                       // 0000001BE1D4: BF02AB0E
	v_add_co_ci_u32_e64 v46, null, 0, v64, s0                  // 0000001BE1D8: D5207C2E 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BE1E0: 980080C1
	global_load_d16_b16 v44, v[44:45], off                     // 0000001BE1E4: DC820000 2C7C002C
	s_and_b32 s49, s0, exec_lo                                 // 0000001BE1EC: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BE1F0: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BE1F4: 98304001
	.long 0xd7000131                                           // 0000001BE1F8: D7000131
	v_cndmask_b32_e32 v1, 0xdd000, v9, vcc_lo                  // 0000001BE1FC: 020212FF 000DD000
	s_add_u32 s50, s47, 0x2100                                 // 0000001BE204: 8032FF2F 00002100
	v_add_co_ci_u32_e64 v48, null, 0, v64, s1                  // 0000001BE20C: D5207C30 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE214: 8201801D
	s_cmp_gt_i32 s14, 44                                       // 0000001BE218: BF02AC0E
	v_cndmask_b32_e64 v46, v124, v46, s0                       // 0000001BE21C: D501002E 00025D7C
	v_cndmask_b32_e64 v45, v122, v47, s0                       // 0000001BE224: D501002D 00025F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE22C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE230: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BE234: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BE238: 98334101
	.long 0xd7000132                                           // 0000001BE23C: D7000132
	v_cndmask_b32_e32 v1, 0xe2000, v9, vcc_lo                  // 0000001BE240: 020212FF 000E2000
	s_cselect_b32 s50, s50, s64                                // 0000001BE248: 98324032
	s_add_u32 s54, s47, 0x21c0                                 // 0000001BE24C: 8036FF2F 000021C0
	v_add_co_ci_u32_e64 v51, null, 0, v64, s1                  // 0000001BE254: D5207C33 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE25C: 8201801D
	s_cmp_gt_i32 s14, 45                                       // 0000001BE260: BF02AD0E
	v_cndmask_b32_e64 v48, v124, v48, s0                       // 0000001BE264: D5010030 0002617C
	v_cndmask_b32_e64 v47, v122, v49, s0                       // 0000001BE26C: D501002F 0002637A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE274: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE278: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BE27C: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BE280: 98374101
	.long 0xd7000131                                           // 0000001BE284: D7000131
	v_cndmask_b32_e32 v1, 0xe7000, v9, vcc_lo                  // 0000001BE288: 020212FF 000E7000
	s_cselect_b32 s54, s54, s64                                // 0000001BE290: 98364036
	s_add_u32 s66, s47, 0x2280                                 // 0000001BE294: 8042FF2F 00002280
	v_add_co_ci_u32_e64 v52, null, 0, v64, s1                  // 0000001BE29C: D5207C34 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE2A4: 8201801D
	s_cmp_gt_i32 s14, 46                                       // 0000001BE2A8: BF02AE0E
	v_cndmask_b32_e64 v51, v124, v51, s0                       // 0000001BE2AC: D5010033 0002677C
	v_cndmask_b32_e64 v50, v122, v50, s0                       // 0000001BE2B4: D5010032 0002657A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE2BC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE2C0: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BE2C4: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BE2C8: 98434101
	.long 0xd7000136                                           // 0000001BE2CC: D7000136
	v_cndmask_b32_e32 v1, 0xec000, v9, vcc_lo                  // 0000001BE2D0: 020212FF 000EC000
	s_cselect_b32 s66, s66, s64                                // 0000001BE2D8: 98424042
	s_add_u32 s68, s47, 0x2340                                 // 0000001BE2DC: 8044FF2F 00002340
	v_add_co_ci_u32_e64 v55, null, 0, v64, s1                  // 0000001BE2E4: D5207C37 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE2EC: 8201801D
	s_cmp_gt_i32 s14, 47                                       // 0000001BE2F0: BF02AF0E
	v_cndmask_b32_e64 v53, v124, v52, s0                       // 0000001BE2F4: D5010035 0002697C
	v_cndmask_b32_e64 v52, v122, v49, s0                       // 0000001BE2FC: D5010034 0002637A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE304: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE308: BF870009
	v_cndmask_b32_e64 v55, v124, v55, s0                       // 0000001BE30C: D5010037 00026F7C
	v_cndmask_b32_e64 v54, v122, v54, s0                       // 0000001BE314: D5010036 00026D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE31C: 8B007E00
	global_load_d16_b16 v49, v[45:46], off                     // 0000001BE320: DC820000 317C002D
	global_load_d16_b16 v48, v[47:48], off                     // 0000001BE328: DC820000 307C002F
	global_load_d16_b16 v47, v[50:51], off                     // 0000001BE330: DC820000 2F7C0032
	global_load_d16_b16 v46, v[52:53], off                     // 0000001BE338: DC820000 2E7C0034
	global_load_d16_b16 v45, v[54:55], off                     // 0000001BE340: DC820000 2D7C0036
	.long 0xd7000032                                           // 0000001BE348: D7000032
	v_cndmask_b32_e32 v1, 0xf1000, v9, vcc_lo                  // 0000001BE34C: 020212FF 000F1000
	s_cselect_b32 s69, s1, s65                                 // 0000001BE354: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BE358: 98444044
	s_add_u32 s1, s47, 0x2400                                  // 0000001BE35C: 8001FF2F 00002400
	s_addc_u32 s70, s29, 0                                     // 0000001BE364: 8246801D
	v_add_co_ci_u32_e64 v51, null, 0, v64, s0                  // 0000001BE368: D5207C33 00028080
	s_cmp_gt_i32 s14, 48                                       // 0000001BE370: BF02B00E
	s_clause 0x7                                               // 0000001BE374: BF850007
	global_load_b32 v196, v107, s[8:9]                         // 0000001BE378: DC520000 C408006B
	global_load_b32 v197, v107, s[10:11]                       // 0000001BE380: DC520000 C50A006B
	global_load_b32 v195, v107, s[12:13]                       // 0000001BE388: DC520000 C30C006B
	global_load_b32 v191, v107, s[48:49]                       // 0000001BE390: DC520000 BF30006B
	global_load_b32 v192, v107, s[50:51]                       // 0000001BE398: DC520000 C032006B
	global_load_b32 v193, v107, s[54:55]                       // 0000001BE3A0: DC520000 C136006B
	global_load_b32 v194, v107, s[66:67]                       // 0000001BE3A8: DC520000 C242006B
	global_load_b32 v190, v107, s[68:69]                       // 0000001BE3B0: DC520000 BE44006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BE3B8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE3BC: BF870009
	v_cndmask_b32_e64 v51, v124, v51, s0                       // 0000001BE3C0: D5010033 0002677C
	v_cndmask_b32_e64 v50, v122, v50, s0                       // 0000001BE3C8: D5010032 0002657A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE3D0: 8B007E00
	.long 0xd7000035                                           // 0000001BE3D4: D7000035
	v_cndmask_b32_e32 v1, 0xf6000, v9, vcc_lo                  // 0000001BE3D8: 020212FF 000F6000
	s_cselect_b32 s9, s70, s65                                 // 0000001BE3E0: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BE3E4: 98084001
	s_add_u32 s1, s47, 0x24c0                                  // 0000001BE3E8: 8001FF2F 000024C0
	v_add_co_ci_u32_e64 v52, null, 0, v64, s0                  // 0000001BE3F0: D5207C34 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BE3F8: 820A801D
	s_cmp_gt_i32 s14, 49                                       // 0000001BE3FC: BF02B10E
	global_load_d16_b16 v50, v[50:51], off                     // 0000001BE400: DC820000 327C0032
	s_cselect_b32 s0, -1, 0                                    // 0000001BE408: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE40C: BF870009
	v_cndmask_b32_e64 v52, v124, v52, s0                       // 0000001BE410: D5010034 0002697C
	v_cndmask_b32_e64 v51, v122, v53, s0                       // 0000001BE418: D5010033 00026B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE420: 8B007E00
	.long 0xd7000036                                           // 0000001BE424: D7000036
	v_cndmask_b32_e32 v1, 0xfb000, v9, vcc_lo                  // 0000001BE428: 020212FF 000FB000
	s_cselect_b32 s11, s10, s65                                // 0000001BE430: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BE434: 980A4001
	s_add_u32 s1, s47, 0x2580                                  // 0000001BE438: 8001FF2F 00002580
	v_add_co_ci_u32_e64 v53, null, 0, v64, s0                  // 0000001BE440: D5207C35 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BE448: 820C801D
	s_cmp_gt_i32 s14, 50                                       // 0000001BE44C: BF02B20E
	global_load_d16_b16 v51, v[51:52], off                     // 0000001BE450: DC820000 337C0033
	s_cselect_b32 s0, -1, 0                                    // 0000001BE458: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE45C: BF870009
	v_cndmask_b32_e64 v53, v124, v53, s0                       // 0000001BE460: D5010035 00026B7C
	v_cndmask_b32_e64 v52, v122, v54, s0                       // 0000001BE468: D5010034 00026D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE470: 8B007E00
	s_cselect_b32 s13, s12, s65                                // 0000001BE474: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BE478: 980C4001
	s_add_u32 s1, s47, 0x2640                                  // 0000001BE47C: 8001FF2F 00002640
	s_addc_u32 s48, s29, 0                                     // 0000001BE484: 8230801D
	.long 0xd7000037                                           // 0000001BE488: D7000037
	v_cndmask_b32_e32 v1, 0x100000, v9, vcc_lo                 // 0000001BE48C: 020212FF 00100000
	s_cmp_gt_i32 s14, 51                                       // 0000001BE494: BF02B30E
	v_add_co_ci_u32_e64 v54, null, 0, v64, s0                  // 0000001BE498: D5207C36 00028080
	s_cselect_b32 s0, -1, 0                                    // 0000001BE4A0: 980080C1
	global_load_d16_b16 v52, v[52:53], off                     // 0000001BE4A4: DC820000 347C0034
	s_and_b32 s49, s0, exec_lo                                 // 0000001BE4AC: 8B317E00
	s_cselect_b32 s49, s48, s65                                // 0000001BE4B0: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BE4B4: 98304001
	.long 0xd7000139                                           // 0000001BE4B8: D7000139
	v_cndmask_b32_e32 v1, 0x105000, v9, vcc_lo                 // 0000001BE4BC: 020212FF 00105000
	s_add_u32 s50, s47, 0x2700                                 // 0000001BE4C4: 8032FF2F 00002700
	v_add_co_ci_u32_e64 v56, null, 0, v64, s1                  // 0000001BE4CC: D5207C38 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE4D4: 8201801D
	s_cmp_gt_i32 s14, 52                                       // 0000001BE4D8: BF02B40E
	v_cndmask_b32_e64 v54, v124, v54, s0                       // 0000001BE4DC: D5010036 00026D7C
	v_cndmask_b32_e64 v53, v122, v55, s0                       // 0000001BE4E4: D5010035 00026F7A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE4EC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE4F0: BF870009
	s_and_b32 s51, s0, exec_lo                                 // 0000001BE4F4: 8B337E00
	s_cselect_b32 s51, s1, s65                                 // 0000001BE4F8: 98334101
	.long 0xd700013a                                           // 0000001BE4FC: D700013A
	v_cndmask_b32_e32 v1, 0x10a000, v9, vcc_lo                 // 0000001BE500: 020212FF 0010A000
	s_cselect_b32 s50, s50, s64                                // 0000001BE508: 98324032
	s_add_u32 s54, s47, 0x27c0                                 // 0000001BE50C: 8036FF2F 000027C0
	v_add_co_ci_u32_e64 v59, null, 0, v64, s1                  // 0000001BE514: D5207C3B 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE51C: 8201801D
	s_cmp_gt_i32 s14, 53                                       // 0000001BE520: BF02B50E
	v_cndmask_b32_e64 v56, v124, v56, s0                       // 0000001BE524: D5010038 0002717C
	v_cndmask_b32_e64 v55, v122, v57, s0                       // 0000001BE52C: D5010037 0002737A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE534: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE538: BF870009
	s_and_b32 s55, s0, exec_lo                                 // 0000001BE53C: 8B377E00
	s_cselect_b32 s55, s1, s65                                 // 0000001BE540: 98374101
	.long 0xd7000139                                           // 0000001BE544: D7000139
	v_cndmask_b32_e32 v1, 0x10f000, v9, vcc_lo                 // 0000001BE548: 020212FF 0010F000
	s_cselect_b32 s54, s54, s64                                // 0000001BE550: 98364036
	s_add_u32 s66, s47, 0x2880                                 // 0000001BE554: 8042FF2F 00002880
	v_add_co_ci_u32_e64 v60, null, 0, v64, s1                  // 0000001BE55C: D5207C3C 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE564: 8201801D
	s_cmp_gt_i32 s14, 54                                       // 0000001BE568: BF02B60E
	v_cndmask_b32_e64 v59, v124, v59, s0                       // 0000001BE56C: D501003B 0002777C
	v_cndmask_b32_e64 v58, v122, v58, s0                       // 0000001BE574: D501003A 0002757A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE57C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE580: BF870009
	s_and_b32 s67, s0, exec_lo                                 // 0000001BE584: 8B437E00
	s_cselect_b32 s67, s1, s65                                 // 0000001BE588: 98434101
	.long 0xd700013e                                           // 0000001BE58C: D700013E
	v_cndmask_b32_e32 v1, 0x114000, v9, vcc_lo                 // 0000001BE590: 020212FF 00114000
	s_cselect_b32 s66, s66, s64                                // 0000001BE598: 98424042
	s_add_u32 s68, s47, 0x2940                                 // 0000001BE59C: 8044FF2F 00002940
	v_add_co_ci_u32_e64 v63, null, 0, v64, s1                  // 0000001BE5A4: D5207C3F 00068080
	s_addc_u32 s1, s29, 0                                      // 0000001BE5AC: 8201801D
	s_cmp_gt_i32 s14, 55                                       // 0000001BE5B0: BF02B70E
	v_cndmask_b32_e64 v61, v124, v60, s0                       // 0000001BE5B4: D501003D 0002797C
	v_cndmask_b32_e64 v60, v122, v57, s0                       // 0000001BE5BC: D501003C 0002737A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE5C4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE5C8: BF870009
	v_cndmask_b32_e64 v63, v124, v63, s0                       // 0000001BE5CC: D501003F 00027F7C
	v_cndmask_b32_e64 v62, v122, v62, s0                       // 0000001BE5D4: D501003E 00027D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE5DC: 8B007E00
	global_load_d16_b16 v57, v[53:54], off                     // 0000001BE5E0: DC820000 397C0035
	global_load_d16_b16 v56, v[55:56], off                     // 0000001BE5E8: DC820000 387C0037
	global_load_d16_b16 v55, v[58:59], off                     // 0000001BE5F0: DC820000 377C003A
	global_load_d16_b16 v53, v[60:61], off                     // 0000001BE5F8: DC820000 357C003C
	global_load_d16_b16 v54, v[62:63], off                     // 0000001BE600: DC820000 367C003E
	.long 0xd700003a                                           // 0000001BE608: D700003A
	v_cndmask_b32_e32 v1, 0x119000, v9, vcc_lo                 // 0000001BE60C: 020212FF 00119000
	s_cselect_b32 s69, s1, s65                                 // 0000001BE614: 98454101
	s_cselect_b32 s68, s68, s64                                // 0000001BE618: 98444044
	s_add_u32 s1, s47, 0x2a00                                  // 0000001BE61C: 8001FF2F 00002A00
	s_addc_u32 s70, s29, 0                                     // 0000001BE624: 8246801D
	v_add_co_ci_u32_e64 v59, null, 0, v64, s0                  // 0000001BE628: D5207C3B 00028080
	s_cmp_gt_i32 s14, 56                                       // 0000001BE630: BF02B80E
	s_clause 0x7                                               // 0000001BE634: BF850007
	global_load_b32 v202, v107, s[8:9]                         // 0000001BE638: DC520000 CA08006B
	global_load_b32 v203, v107, s[10:11]                       // 0000001BE640: DC520000 CB0A006B
	global_load_b32 v204, v107, s[12:13]                       // 0000001BE648: DC520000 CC0C006B
	global_load_b32 v205, v107, s[48:49]                       // 0000001BE650: DC520000 CD30006B
	global_load_b32 v201, v107, s[50:51]                       // 0000001BE658: DC520000 C932006B
	global_load_b32 v198, v107, s[54:55]                       // 0000001BE660: DC520000 C636006B
	global_load_b32 v199, v107, s[66:67]                       // 0000001BE668: DC520000 C742006B
	global_load_b32 v200, v107, s[68:69]                       // 0000001BE670: DC520000 C844006B
	s_cselect_b32 s0, -1, 0                                    // 0000001BE678: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE67C: BF870009
	v_cndmask_b32_e64 v59, v124, v59, s0                       // 0000001BE680: D501003B 0002777C
	v_cndmask_b32_e64 v58, v122, v58, s0                       // 0000001BE688: D501003A 0002757A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE690: 8B007E00
	.long 0xd700003d                                           // 0000001BE694: D700003D
	v_cndmask_b32_e32 v1, 0x11e000, v9, vcc_lo                 // 0000001BE698: 020212FF 0011E000
	s_cselect_b32 s9, s70, s65                                 // 0000001BE6A0: 98094146
	s_cselect_b32 s8, s1, s64                                  // 0000001BE6A4: 98084001
	s_add_u32 s1, s47, 0x2ac0                                  // 0000001BE6A8: 8001FF2F 00002AC0
	v_add_co_ci_u32_e64 v60, null, 0, v64, s0                  // 0000001BE6B0: D5207C3C 00028080
	s_addc_u32 s10, s29, 0                                     // 0000001BE6B8: 820A801D
	s_cmp_gt_i32 s14, 57                                       // 0000001BE6BC: BF02B90E
	global_load_d16_b16 v58, v[58:59], off                     // 0000001BE6C0: DC820000 3A7C003A
	s_cselect_b32 s0, -1, 0                                    // 0000001BE6C8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE6CC: BF870009
	v_cndmask_b32_e64 v60, v124, v60, s0                       // 0000001BE6D0: D501003C 0002797C
	v_cndmask_b32_e64 v59, v122, v61, s0                       // 0000001BE6D8: D501003B 00027B7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE6E0: 8B007E00
	.long 0xd700003e                                           // 0000001BE6E4: D700003E
	v_cndmask_b32_e32 v1, 0x123000, v9, vcc_lo                 // 0000001BE6E8: 020212FF 00123000
	s_cselect_b32 s11, s10, s65                                // 0000001BE6F0: 980B410A
	s_cselect_b32 s10, s1, s64                                 // 0000001BE6F4: 980A4001
	s_add_u32 s1, s47, 0x2b80                                  // 0000001BE6F8: 8001FF2F 00002B80
	v_add_co_ci_u32_e64 v61, null, 0, v64, s0                  // 0000001BE700: D5207C3D 00028080
	s_addc_u32 s12, s29, 0                                     // 0000001BE708: 820C801D
	s_cmp_gt_i32 s14, 58                                       // 0000001BE70C: BF02BA0E
	global_load_d16_b16 v59, v[59:60], off                     // 0000001BE710: DC820000 3B7C003B
	s_cselect_b32 s0, -1, 0                                    // 0000001BE718: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE71C: BF870009
	v_cndmask_b32_e64 v61, v124, v61, s0                       // 0000001BE720: D501003D 00027B7C
	v_cndmask_b32_e64 v60, v122, v62, s0                       // 0000001BE728: D501003C 00027D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE730: 8B007E00
	.long 0xd700003e                                           // 0000001BE734: D700003E
	v_cndmask_b32_e32 v1, 0x128000, v9, vcc_lo                 // 0000001BE738: 020212FF 00128000
	s_cselect_b32 s13, s12, s65                                // 0000001BE740: 980D410C
	s_cselect_b32 s12, s1, s64                                 // 0000001BE744: 980C4001
	s_add_u32 s1, s47, 0x2c40                                  // 0000001BE748: 8001FF2F 00002C40
	v_add_co_ci_u32_e64 v63, null, 0, v64, s0                  // 0000001BE750: D5207C3F 00028080
	s_addc_u32 s48, s29, 0                                     // 0000001BE758: 8230801D
	s_cmp_gt_i32 s14, 59                                       // 0000001BE75C: BF02BB0E
	global_load_d16_b16 v61, v[60:61], off                     // 0000001BE760: DC820000 3D7C003C
	s_cselect_b32 s0, -1, 0                                    // 0000001BE768: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE76C: BF870009
	v_cndmask_b32_e64 v63, v124, v63, s0                       // 0000001BE770: D501003F 00027F7C
	v_cndmask_b32_e64 v62, v122, v62, s0                       // 0000001BE778: D501003E 00027D7A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE780: 8B007E00
	.long 0xd7000041                                           // 0000001BE784: D7000041
	v_cndmask_b32_e32 v1, 0x12d000, v9, vcc_lo                 // 0000001BE788: 020212FF 0012D000
	s_cselect_b32 s49, s48, s65                                // 0000001BE790: 98314130
	s_cselect_b32 s48, s1, s64                                 // 0000001BE794: 98304001
	s_add_u32 s1, s47, 0x2d00                                  // 0000001BE798: 8001FF2F 00002D00
	v_add_co_ci_u32_e64 v116, null, 0, v64, s0                 // 0000001BE7A0: D5207C74 00028080
	s_addc_u32 s50, s29, 0                                     // 0000001BE7A8: 8232801D
	s_cmp_gt_i32 s14, 60                                       // 0000001BE7AC: BF02BC0E
	global_load_d16_b16 v60, v[62:63], off                     // 0000001BE7B0: DC820000 3C7C003E
	s_cselect_b32 s0, -1, 0                                    // 0000001BE7B8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE7BC: BF870009
	v_cndmask_b32_e64 v63, v124, v116, s0                      // 0000001BE7C0: D501003F 0002E97C
	v_cndmask_b32_e64 v62, v122, v65, s0                       // 0000001BE7C8: D501003E 0002837A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE7D0: 8B007E00
	.long 0xd7000041                                           // 0000001BE7D4: D7000041
	v_cndmask_b32_e32 v1, 0x132000, v9, vcc_lo                 // 0000001BE7D8: 020212FF 00132000
	s_cselect_b32 s51, s50, s65                                // 0000001BE7E0: 98334132
	s_cselect_b32 s50, s1, s64                                 // 0000001BE7E4: 98324001
	s_add_u32 s1, s47, 0x2dc0                                  // 0000001BE7E8: 8001FF2F 00002DC0
	v_add_co_ci_u32_e64 v116, null, 0, v64, s0                 // 0000001BE7F0: D5207C74 00028080
	s_addc_u32 s54, s29, 0                                     // 0000001BE7F8: 8236801D
	s_cmp_gt_i32 s14, 61                                       // 0000001BE7FC: BF02BD0E
	global_load_d16_b16 v62, v[62:63], off                     // 0000001BE800: DC820000 3E7C003E
	s_cselect_b32 s0, -1, 0                                    // 0000001BE808: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE80C: BF870009
	v_cndmask_b32_e64 v117, v124, v116, s0                     // 0000001BE810: D5010075 0002E97C
	v_cndmask_b32_e64 v116, v122, v65, s0                      // 0000001BE818: D5010074 0002837A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE820: 8B007E00
	.long 0xd7000041                                           // 0000001BE824: D7000041
	v_cndmask_b32_e32 v1, 0x137000, v9, vcc_lo                 // 0000001BE828: 020212FF 00137000
	s_cselect_b32 s55, s54, s65                                // 0000001BE830: 98374136
	s_cselect_b32 s54, s1, s64                                 // 0000001BE834: 98364001
	s_add_u32 s1, s47, 0x2e80                                  // 0000001BE838: 8001FF2F 00002E80
	v_add_co_ci_u32_e64 v172, null, 0, v64, s0                 // 0000001BE840: D5207CAC 00028080
	s_addc_u32 s66, s29, 0                                     // 0000001BE848: 8242801D
	s_cmp_gt_i32 s14, 62                                       // 0000001BE84C: BF02BE0E
	global_load_d16_b16 v63, v[116:117], off                   // 0000001BE850: DC820000 3F7C0074
	s_cselect_b32 s0, -1, 0                                    // 0000001BE858: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE85C: BF870009
	v_cndmask_b32_e64 v117, v124, v172, s0                     // 0000001BE860: D5010075 0003597C
	v_cndmask_b32_e64 v116, v122, v65, s0                      // 0000001BE868: D5010074 0002837A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE870: 8B007E00
	.long 0xd7000009                                           // 0000001BE874: D7000009
	v_cndmask_b32_e32 v1, 0x13c000, v9, vcc_lo                 // 0000001BE878: 020212FF 0013C000
	s_cselect_b32 s67, s66, s65                                // 0000001BE880: 98434142
	s_cselect_b32 s66, s1, s64                                 // 0000001BE884: 98424001
	s_add_u32 s47, s47, 0x2f40                                 // 0000001BE888: 802FFF2F 00002F40
	v_add_co_ci_u32_e64 v65, null, 0, v64, s0                  // 0000001BE890: D5207C41 00028080
	s_addc_u32 s1, s29, 0                                      // 0000001BE898: 8201801D
	s_cmp_gt_i32 s14, 63                                       // 0000001BE89C: BF02BF0E
	global_load_d16_b16 v64, v[116:117], off                   // 0000001BE8A0: DC820000 407C0074
	s_cselect_b32 s0, -1, 0                                    // 0000001BE8A8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BE8AC: BF870009
	v_cndmask_b32_e64 v117, v124, v65, s0                      // 0000001BE8B0: D5010075 0002837C
	v_cndmask_b32_e64 v116, v122, v9, s0                       // 0000001BE8B8: D5010074 0002137A
	s_and_b32 s0, s0, exec_lo                                  // 0000001BE8C0: 8B007E00
	s_cselect_b32 s1, s1, s65                                  // 0000001BE8C4: 98014101
	s_cselect_b32 s0, s47, s64                                 // 0000001BE8C8: 9800402F
	s_clause 0x7                                               // 0000001BE8CC: BF850007
	global_load_b32 v213, v107, s[8:9]                         // 0000001BE8D0: DC520000 D508006B
	global_load_b32 v212, v107, s[10:11]                       // 0000001BE8D8: DC520000 D40A006B
	global_load_b32 v211, v107, s[12:13]                       // 0000001BE8E0: DC520000 D30C006B
	global_load_b32 v208, v107, s[48:49]                       // 0000001BE8E8: DC520000 D030006B
	global_load_b32 v209, v107, s[50:51]                       // 0000001BE8F0: DC520000 D132006B
	global_load_b32 v210, v107, s[54:55]                       // 0000001BE8F8: DC520000 D236006B
	global_load_b32 v207, v107, s[66:67]                       // 0000001BE900: DC520000 CF42006B
	global_load_b32 v206, v107, s[0:1]                         // 0000001BE908: DC520000 CE00006B
	global_load_d16_b16 v65, v[116:117], off                   // 0000001BE910: DC820000 417C0074
	.long 0x7e123880                                           // 0000001BE918: 7E123880
	s_cmp_gt_i32 s58, s7                                       // 0000001BE91C: BF02073A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001BE920: BF890007
	s_barrier                                                  // 0000001BE924: BFBD0000
	buffer_gl0_inv                                             // 0000001BE928: E0AC0000 00000000
	s_cbranch_scc0 10                                          // 0000001BE930: BFA1000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1d5c>
	ds_load_b32 v9, v107 offset:61440                          // 0000001BE934: D8D8F000 0900006B
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000001BE93C: 30020290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BE940: BF8700A1
	v_mul_f32_e32 v1, v73, v1                                  // 0000001BE944: 10020349
	s_waitcnt lgkmcnt(0)                                       // 0000001BE948: BF89FC07
	v_mul_f32_e32 v1, v1, v9                                   // 0000001BE94C: 10021301
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BE950: BF870001
	v_fma_mixlo_f16 v9, v1, s22, 0                             // 0000001BE954: CC210009 02002D01
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000001BE95C: 300A0A90
	v_lshlrev_b32_e32 v1, 16, v2                               // 0000001BE960: 30020490
	s_or_b32 s0, s7, 1                                         // 0000001BE964: 8C008107
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE968: BF870119
	s_cmp_lt_i32 s0, s58                                       // 0000001BE96C: BF043A00
	v_mul_f32_e32 v70, v70, v5                                 // 0000001BE970: 108C0B46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BE974: BF8701B2
	v_dual_mul_f32 v71, v71, v1 :: v_dual_lshlrev_b32 v2, 16, v3// 0000001BE978: C8E20347 47020690
	v_lshlrev_b32_e32 v3, 16, v8                               // 0000001BE980: 30061090
	v_lshlrev_b32_e32 v5, 16, v14                              // 0000001BE984: 300A1C90
	v_dual_mul_f32 v72, v72, v2 :: v_dual_lshlrev_b32 v1, 16, v7// 0000001BE988: C8E20548 48000E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE990: BF870113
	v_dual_mul_f32 v67, v67, v3 :: v_dual_lshlrev_b32 v2, 16, v6// 0000001BE994: C8E20743 43020C90
	v_dual_mul_f32 v68, v68, v1 :: v_dual_lshlrev_b32 v7, 16, v24// 0000001BE99C: C8E20344 44063090
	v_lshlrev_b32_e32 v1, 16, v4                               // 0000001BE9A4: 30020890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BE9A8: BF8701A3
	v_mul_f32_e32 v69, v69, v2                                 // 0000001BE9AC: 108A0545
	s_cselect_b32 s0, -1, 0                                    // 0000001BE9B0: 980080C1
	v_mul_f32_e32 v184, v86, v7                                // 0000001BE9B4: 11700F56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BE9B8: BF870243
	v_dual_mul_f32 v66, v66, v1 :: v_dual_lshlrev_b32 v7, 16, v27// 0000001BE9BC: C8E20342 42063690
	v_lshlrev_b32_e32 v1, 16, v10                              // 0000001BE9C4: 30021490
	v_lshlrev_b32_e32 v2, 16, v11                              // 0000001BE9C8: 30041690
	v_lshlrev_b32_e32 v4, 16, v17                              // 0000001BE9CC: 30082290
	v_dual_mul_f32 v179, v96, v7 :: v_dual_lshlrev_b32 v6, 16, v18// 0000001BE9D0: C8E20F60 B3062490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001BE9D8: BF8701C4
	v_mul_f32_e32 v17, v78, v1                                 // 0000001BE9DC: 1022034E
	v_lshlrev_b32_e32 v1, 16, v16                              // 0000001BE9E0: 30022090
	v_mul_f32_e32 v73, v79, v2                                 // 0000001BE9E4: 1092054F
	v_dual_mul_f32 v79, v81, v4 :: v_dual_lshlrev_b32 v2, 16, v13// 0000001BE9E8: C8E20951 4F021A90
	v_dual_mul_f32 v77, v77, v1 :: v_dual_lshlrev_b32 v8, 16, v23// 0000001BE9F0: C8E2034D 4D082E90
	v_lshlrev_b32_e32 v1, 16, v15                              // 0000001BE9F8: 30021E90
	v_lshlrev_b32_e32 v3, 16, v12                              // 0000001BE9FC: 30061890
	v_lshlrev_b32_e32 v7, 16, v29                              // 0000001BEA00: 300E3A90
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BEA04: BF870004
	v_mul_f32_e32 v181, v87, v8                                // 0000001BEA08: 116A1157
	v_lshlrev_b32_e32 v8, 16, v28                              // 0000001BEA0C: 30103890
	v_mul_f32_e32 v4, v74, v1                                  // 0000001BEA10: 1008034A
	v_dual_mul_f32 v78, v80, v3 :: v_dual_mul_f32 v3, v75, v2  // 0000001BEA14: C8C60750 4E02054B
	v_dual_mul_f32 v1, v89, v6 :: v_dual_lshlrev_b32 v6, 16, v25// 0000001BEA1C: C8E20D59 01063290
	v_dual_mul_f32 v2, v76, v5 :: v_dual_lshlrev_b32 v5, 16, v19// 0000001BEA24: C8E20B4C 02042690
	v_dual_mul_f32 v176, v97, v8 :: v_dual_mul_f32 v177, v92, v7// 0000001BEA2C: C8C61161 B0B00F5C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEA34: BF870223
	v_mul_f32_e32 v186, v85, v6                                // 0000001BEA38: 11740D55
	v_lshlrev_b32_e32 v6, 16, v26                              // 0000001BEA3C: 300C3490
	v_dual_mul_f32 v188, v88, v5 :: v_dual_lshlrev_b32 v11, 16, v63// 0000001BEA40: C8E20B58 BC0A7E90
	v_lshlrev_b32_e32 v7, 16, v41                              // 0000001BEA48: 300E5290
	v_lshlrev_b32_e32 v8, 16, v30                              // 0000001BEA4C: 30103C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BEA50: BF870234
	v_mul_f32_e32 v182, v95, v6                                // 0000001BEA54: 116C0D5F
	v_lshlrev_b32_e32 v6, 16, v31                              // 0000001BEA58: 300C3E90
	v_dual_mul_f32 v26, v210, v11 :: v_dual_lshlrev_b32 v5, 16, v20// 0000001BEA5C: C8E217D2 1A042890
	v_dual_mul_f32 v175, v93, v8 :: v_dual_lshlrev_b32 v10, 16, v62// 0000001BEA64: C8E2115D AF0A7C90
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001BEA6C: BF870002
	v_dual_mul_f32 v178, v91, v6 :: v_dual_mul_f32 v189, v84, v5// 0000001BEA70: C8C60D5B B2BC0B54
	v_lshlrev_b32_e32 v5, 16, v22                              // 0000001BEA78: 300A2C90
	v_lshlrev_b32_e32 v6, 16, v36                              // 0000001BEA7C: 300C4890
	v_lshlrev_b32_e32 v8, 16, v40                              // 0000001BEA80: 30105090
	ds_load_2addr_b32 v[11:12], v143 offset1:1                 // 0000001BEA84: D8DC0100 0B00008F
	ds_load_2addr_b32 v[13:14], v144 offset1:1                 // 0000001BEA8C: D8DC0100 0D000090
	s_or_b32 s1, s7, 2                                         // 0000001BEA94: 8C018207
	v_mul_f32_e32 v185, v83, v5                                // 0000001BEA98: 11720B53
	v_dual_mul_f32 v172, v102, v6 :: v_dual_lshlrev_b32 v5, 16, v21// 0000001BEA9C: C8E20D66 AC042A90
	v_lshlrev_b32_e32 v6, 16, v38                              // 0000001BEAA4: 300C4C90
	v_mul_f32_e32 v30, v209, v10                               // 0000001BEAA8: 103C15D1
	s_cmp_lt_i32 s1, s58                                       // 0000001BEAAC: BF043A01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEAB0: BF870193
	v_mul_f32_e32 v187, v82, v5                                // 0000001BEAB4: 11760B52
	v_dual_mul_f32 v116, v99, v6 :: v_dual_lshlrev_b32 v5, 16, v33// 0000001BEAB8: C8E20D63 74044290
	v_lshlrev_b32_e32 v6, 16, v48                              // 0000001BEAC0: 300C6090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BEAC4: BF870112
	v_dual_mul_f32 v180, v94, v5 :: v_dual_lshlrev_b32 v5, 16, v32// 0000001BEAC8: C8E20B5E B4044090
	v_mul_f32_e32 v99, v192, v6                                // 0000001BEAD0: 10C60DC0
	.long 0x7e0c3932                                           // 0000001BEAD4: 7E0C3932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001BEAD8: BF870133
	v_mul_f32_e32 v183, v90, v5                                // 0000001BEADC: 116E0B5A
	v_lshlrev_b32_e32 v5, 16, v34                              // 0000001BEAE0: 300A4490
	v_lshlrev_b32_e32 v10, 16, v64                             // 0000001BEAE4: 30148090
	v_dual_mul_f32 v174, v104, v5 :: v_dual_lshlrev_b32 v5, 16, v35// 0000001BEAE8: C8E20B68 AE044690
	v_dual_mul_f32 v104, v103, v7 :: v_dual_lshlrev_b32 v7, 16, v42// 0000001BEAF0: C8E20F67 68065490
	v_dual_mul_f32 v103, v105, v8 :: v_dual_lshlrev_b32 v8, 16, v43// 0000001BEAF8: C8E21169 67085690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEB00: BF870223
	v_mul_f32_e32 v173, v101, v5                               // 0000001BEB04: 115A0B65
	v_lshlrev_b32_e32 v5, 16, v39                              // 0000001BEB08: 300A4E90
	v_mul_f32_e32 v101, v196, v7                               // 0000001BEB0C: 10CA0FC4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEB10: BF870194
	v_dual_mul_f32 v40, v197, v8 :: v_dual_lshlrev_b32 v7, 16, v47// 0000001BEB14: C8E211C5 28065E90
	v_dual_mul_f32 v105, v100, v5 :: v_dual_lshlrev_b32 v8, 16, v46// 0000001BEB1C: C8E20B64 69085C90
	v_lshlrev_b32_e32 v5, 16, v37                              // 0000001BEB24: 300A4A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEB28: BF870223
	v_mul_f32_e32 v37, v193, v7                                // 0000001BEB2C: 104A0FC1
	v_lshlrev_b32_e32 v7, 16, v52                              // 0000001BEB30: 300E6890
	v_mul_f32_e32 v34, v194, v8                                // 0000001BEB34: 104411C2
	v_lshlrev_b32_e32 v8, 16, v57                              // 0000001BEB38: 30107290
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BEB3C: BF8701A3
	v_mul_f32_e32 v33, v204, v7                                // 0000001BEB40: 10420FCC
	v_lshlrev_b32_e32 v7, 16, v54                              // 0000001BEB44: 300E6C90
	v_mul_f32_e32 v27, v205, v8                                // 0000001BEB48: 103611CD
	v_lshlrev_b32_e32 v8, 16, v58                              // 0000001BEB4C: 30107490
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BEB50: BF8701A3
	v_mul_f32_e32 v28, v200, v7                                // 0000001BEB54: 10380FC8
	v_lshlrev_b32_e32 v7, 16, v59                              // 0000001BEB58: 300E7690
	v_dual_mul_f32 v25, v213, v8 :: v_dual_add_nc_u32 v196, s7, v126// 0000001BEB5C: C8E011D5 19C4FC07
	v_lshlrev_b32_e32 v8, 16, v61                              // 0000001BEB64: 30107A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BEB68: BF870233
	v_dual_mul_f32 v38, v212, v7 :: v_dual_mul_f32 v117, v98, v5// 0000001BEB6C: C8C60FD4 26740B62
	v_lshlrev_b32_e32 v5, 16, v44                              // 0000001BEB74: 300A5890
	v_lshlrev_b32_e32 v7, 16, v60                              // 0000001BEB78: 300E7890
	v_mul_f32_e32 v39, v211, v8                                // 0000001BEB7C: 104E11D3
	.long 0xd443000d                                           // 0000001BEB80: D443000D
	v_cndmask_b32_e32 v1, s58, v196, vcc_lo                    // 0000001BEB84: 0203883A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BEB88: BF870004
	v_mul_f32_e32 v102, v195, v5                               // 0000001BEB8C: 10CC0BC3
	v_lshlrev_b32_e32 v5, 16, v49                              // 0000001BEB90: 300A6290
	ds_load_2addr_b32 v[192:193], v151 offset1:1               // 0000001BEB94: D8DC0100 C0000097
	ds_load_2addr_b32 v[194:195], v152 offset1:1               // 0000001BEB9C: D8DC0100 C2000098
	v_mul_f32_e32 v31, v208, v7                                // 0000001BEBA4: 103E0FD0
	ds_load_2addr_b32 v[7:8], v142 offset1:1                   // 0000001BEBA8: D8DC0100 0700008E
	v_mul_f32_e32 v100, v191, v5                               // 0000001BEBB0: 10C80BBF
	v_lshlrev_b32_e32 v5, 16, v45                              // 0000001BEBB4: 300A5A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BEBB8: BF8701B1
	v_dual_mul_f32 v50, v190, v5 :: v_dual_lshlrev_b32 v5, 16, v6// 0000001BEBBC: C8E20BBE 32040C90
	v_dual_mul_f32 v51, v207, v10 :: v_dual_lshlrev_b32 v6, 16, v51// 0000001BEBC4: C8E215CF 33066690
	v_lshlrev_b32_e32 v10, 16, v65                             // 0000001BEBCC: 30148290
	v_mul_f32_e32 v49, v202, v5                                // 0000001BEBD0: 10620BCA
	v_lshlrev_b32_e32 v5, 16, v56                              // 0000001BEBD4: 300A7090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BEBD8: BF870214
	v_dual_mul_f32 v35, v203, v6 :: v_dual_lshlrev_b32 v6, 16, v53// 0000001BEBDC: C8E20DCB 23066A90
	v_mul_f32_e32 v52, v206, v10                               // 0000001BEBE4: 106815CE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEBE8: BF870193
	v_dual_mul_f32 v32, v201, v5 :: v_dual_lshlrev_b32 v5, 16, v55// 0000001BEBEC: C8E20BC9 20046E90
	v_mul_f32_e32 v29, v199, v6                                // 0000001BEBF4: 103A0DC7
	ds_load_2addr_b32 v[54:55], v149 offset1:1                 // 0000001BEBF8: D8DC0100 36000095
	v_mul_f32_e32 v36, v198, v5                                // 0000001BEC00: 10480BC6
	ds_load_2addr_b32 v[5:6], v141 offset1:1                   // 0000001BEC04: D8DC0100 0500008D
	ds_load_2addr_b32 v[190:191], v150 offset1:1               // 0000001BEC0C: D8DC0100 BE000096
	s_waitcnt lgkmcnt(2)                                       // 0000001BEC14: BF89FC27
	v_dual_mul_f32 v54, v188, v54 :: v_dual_mul_f32 v55, v189, v55// 0000001BEC18: C8C66DBC 36366FBD
	s_waitcnt lgkmcnt(1)                                       // 0000001BEC20: BF89FC17
	v_dual_mul_f32 v5, v71, v5 :: v_dual_mul_f32 v6, v72, v6   // 0000001BEC24: C8C60B47 05060D48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BEC2C: BF870091
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001BEC30: CC210005 02002D05
	v_cndmask_b16 v9, 0, v5, s0                                // 0000001BEC38: D65D4009 00020A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BEC40: BF870003
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001BEC44: CC210005 02002D06
	v_mul_f32_e32 v6, v67, v7                                  // 0000001BEC4C: 100C0F43
	s_cselect_b32 s0, -1, 0                                    // 0000001BEC50: 980080C1
	s_or_b32 s1, s7, 3                                         // 0000001BEC54: 8C018307
	v_mul_f32_e32 v7, v68, v8                                  // 0000001BEC58: 100E1144
	s_cmp_lt_i32 s1, s58                                       // 0000001BEC5C: BF043A01
	v_cndmask_b16 v10, 0, v5, s0                               // 0000001BEC60: D65D000A 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001BEC68: CC210005 02002D06
	s_cselect_b32 s0, -1, 0                                    // 0000001BEC70: 980080C1
	s_or_b32 s1, s7, 4                                         // 0000001BEC74: 8C018407
	v_mul_f32_e32 v6, v69, v11                                 // 0000001BEC78: 100C1745
	s_cmp_lt_i32 s1, s58                                       // 0000001BEC7C: BF043A01
	v_cndmask_b16 v10, 0, v5, s0                               // 0000001BEC80: D65D400A 00020A80
	s_cselect_b32 s1, -1, 0                                    // 0000001BEC88: 980180C1
	s_or_b32 s0, s7, 5                                         // 0000001BEC8C: 8C008507
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001BEC90: CC210005 02002D06
	v_mul_f32_e32 v6, v70, v12                                 // 0000001BEC98: 100C1946
	v_dual_mul_f32 v8, v66, v13 :: v_dual_mul_f32 v13, v17, v14// 0000001BEC9C: C8C61B42 080C1D11
	ds_load_2addr_b32 v[16:17], v147 offset1:1                 // 0000001BECA4: D8DC0100 10000093
	ds_load_2addr_b32 v[18:19], v148 offset1:1                 // 0000001BECAC: D8DC0100 12000094
	s_cmp_lt_i32 s0, s58                                       // 0000001BECB4: BF043A00
	v_fma_mixhi_f16 v5, v7, s22, 0                             // 0000001BECB8: CC220005 02002D07
	s_cselect_b32 s0, -1, 0                                    // 0000001BECC0: 980080C1
	ds_load_2addr_b32 v[14:15], v146 offset1:1                 // 0000001BECC4: D8DC0100 0E000092
	v_cndmask_b16 v11, 0, v5, s0                               // 0000001BECCC: D65D400B 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001BECD4: CC210005 02002D06
	ds_load_2addr_b32 v[6:7], v145 offset1:1                   // 0000001BECDC: D8DC0100 06000091
	v_cndmask_b16 v11, 0, v5, s1                               // 0000001BECE4: D65D100B 00060A80
	s_or_b32 s1, s7, 6                                         // 0000001BECEC: 8C018607
	s_waitcnt lgkmcnt(4)                                       // 0000001BECF0: BF89FC47
	v_mul_f32_e32 v56, v184, v191                              // 0000001BECF4: 10717FB8
	s_cmp_lt_i32 s1, s58                                       // 0000001BECF8: BF043A01
	v_fma_mixhi_f16 v5, v13, s22, 0                            // 0000001BECFC: CC220005 02002D0D
	s_cselect_b32 s0, -1, 0                                    // 0000001BED04: 980080C1
	s_or_b32 s1, s7, 7                                         // 0000001BED08: 8C018707
	v_cndmask_b16 v12, 0, v5, s0                               // 0000001BED0C: D65D000C 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001BED14: BF043A01
	v_fma_mixlo_f16 v5, v8, s22, 0                             // 0000001BED18: CC210005 02002D08
	s_cselect_b32 s0, -1, 0                                    // 0000001BED20: 980080C1
	s_or_b32 s1, s7, 8                                         // 0000001BED24: 8C018807
	s_waitcnt lgkmcnt(2)                                       // 0000001BED28: BF89FC27
	v_mul_f32_e32 v53, v1, v19                                 // 0000001BED2C: 106A2701
	s_cmp_lt_i32 s1, s58                                       // 0000001BED30: BF043A01
	v_cndmask_b16 v12, 0, v5, s0                               // 0000001BED34: D65D400C 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001BED3C: 980080C1
	s_or_b32 s1, s7, 9                                         // 0000001BED40: 8C018907
	v_fma_mixlo_f16 v53, v53, s22, 0                           // 0000001BED44: CC210035 02002D35
	v_fma_mixhi_f16 v53, v54, s22, 0                           // 0000001BED4C: CC220035 02002D36
	v_fma_mixlo_f16 v54, v55, s22, 0                           // 0000001BED54: CC210036 02002D37
	v_mul_f32_e32 v55, v186, v190                              // 0000001BED5C: 106F7DBA
	v_mul_f32_e32 v186, v187, v194                             // 0000001BED60: 117585BB
	v_cndmask_b16 v13, 0, v5, s0                               // 0000001BED64: D65D100D 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001BED6C: BF043A01
	v_mul_f32_e32 v4, v4, v16                                  // 0000001BED70: 10082104
	v_fma_mixhi_f16 v54, v55, s22, 0                           // 0000001BED74: CC220036 02002D37
	v_fma_mixlo_f16 v55, v56, s22, 0                           // 0000001BED7C: CC210037 02002D38
	v_mul_f32_e32 v56, v181, v192                              // 0000001BED84: 107181B5
	v_mul_f32_e32 v181, v185, v193                             // 0000001BED88: 116B83B9
	ds_load_2addr_b32 v[184:185], v153 offset1:1               // 0000001BED8C: D8DC0100 B8000099
	s_cselect_b32 s0, -1, 0                                    // 0000001BED94: 980080C1
	s_or_b32 s1, s7, 10                                        // 0000001BED98: 8C018A07
	v_fma_mixhi_f16 v55, v56, s22, 0                           // 0000001BED9C: CC220037 02002D38
	v_fma_mixhi_f16 v56, v186, s22, 0                          // 0000001BEDA4: CC220038 02002DBA
	ds_load_2addr_b32 v[186:187], v154 offset1:1               // 0000001BEDAC: D8DC0100 BA00009A
	s_waitcnt lgkmcnt(2)                                       // 0000001BEDB4: BF89FC27
	v_dual_mul_f32 v5, v73, v6 :: v_dual_mul_f32 v6, v78, v7   // 0000001BEDB8: C8C60D49 05060F4E
	v_mul_f32_e32 v7, v79, v14                                 // 0000001BEDC0: 100E1D4F
	s_cmp_lt_i32 s1, s58                                       // 0000001BEDC4: BF043A01
	v_mul_f32_e32 v3, v3, v17                                  // 0000001BEDC8: 10062303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BEDCC: BF870003
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001BEDD0: CC210005 02002D05
	s_cselect_b32 s1, -1, 0                                    // 0000001BEDD8: 980180C1
	v_fma_mixhi_f16 v5, v6, s22, 0                             // 0000001BEDDC: CC220005 02002D06
	s_or_b32 s8, s7, 11                                        // 0000001BEDE4: 8C088B07
	v_mul_f32_e32 v6, v77, v15                                 // 0000001BEDE8: 100C1F4D
	v_cndmask_b16 v13, 0, v5, s0                               // 0000001BEDEC: D65D400D 00020A80
	v_fma_mixlo_f16 v5, v7, s22, 0                             // 0000001BEDF4: CC210005 02002D07
	s_cmp_lt_i32 s8, s58                                       // 0000001BEDFC: BF043A08
	v_cndmask_b16 v14, 0, v5, s1                               // 0000001BEE00: D65D100E 00060A80
	s_cselect_b32 s0, -1, 0                                    // 0000001BEE08: 980080C1
	s_or_b32 s1, s7, 12                                        // 0000001BEE0C: 8C018C07
	v_cndmask_b16 v14, 0, v5, s0                               // 0000001BEE10: D65D400E 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001BEE18: CC210005 02002D06
	v_min_i32_e32 v6, s62, v196                                // 0000001BEE20: 220D883E
	s_cmp_lt_i32 s1, s58                                       // 0000001BEE24: BF043A01
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001BEE28: CC210004 02002D04
	s_cselect_b32 s0, -1, 0                                    // 0000001BEE30: 980080C1
	s_or_b32 s1, s7, 13                                        // 0000001BEE34: 8C018D07
	v_cndmask_b16 v15, 0, v5, s0                               // 0000001BEE38: D65D000F 00020A80
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001BEE40: D6FF7C05 00096106
	s_cmp_lt_i32 s1, s58                                       // 0000001BEE48: BF043A01
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001BEE4C: CC210003 02002D03
	s_cselect_b32 s0, -1, 0                                    // 0000001BEE54: 980080C1
	s_or_b32 s1, s7, 14                                        // 0000001BEE58: 8C018E07
	v_cndmask_b16 v15, 0, v4, s0                               // 0000001BEE5C: D65D400F 00020880
	s_cmp_lt_i32 s1, s58                                       // 0000001BEE64: BF043A01
	v_mul_f32_e32 v2, v2, v18                                  // 0000001BEE68: 10042502
	.long 0xd73c0061                                           // 0000001BEE6C: D73C0061
	v_cndmask_b32_e32 v1, 8, v5, vcc_lo                        // 0000001BEE70: 02020A88
	s_cselect_b32 s0, -1, 0                                    // 0000001BEE74: 980080C1
	s_or_b32 s1, s7, 15                                        // 0000001BEE78: 8C018F07
	v_cndmask_b16 v16, 0, v3, s0                               // 0000001BEE7C: D65D0010 00020680
	v_fma_mixhi_f16 v16, v2, s22, 0                            // 0000001BEE84: CC220010 02002D02
	s_cmp_lt_i32 s1, s58                                       // 0000001BEE8C: BF043A01
	.long 0xd7000005                                           // 0000001BEE90: D7000005
	v_cndmask_b32_e32 v1, s26, v97, vcc_lo                     // 0000001BEE94: 0202C21A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BEE98: BF870001
	v_add_co_ci_u32_e64 v6, null, s27, v98, s0                 // 0000001BEE9C: D5207C06 0002C41B
	s_clause 0xf                                               // 0000001BEEA4: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001BEEA8: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001BEEB0: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001BEEB8: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001BEEC0: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001BEEC8: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001BEED0: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001BEED8: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001BEEE0: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001BEEE8: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001BEEF0: DC5E0090 3D7C0005
	global_load_b128 v[41:44], v[5:6], off offset:160          // 0000001BEEF8: DC5E00A0 297C0005
	global_load_b128 v[45:48], v[5:6], off offset:176          // 0000001BEF00: DC5E00B0 2D7C0005
	global_load_b128 v[17:20], v[5:6], off offset:192          // 0000001BEF08: DC5E00C0 117C0005
	global_load_b128 v[21:24], v[5:6], off offset:208          // 0000001BEF10: DC5E00D0 157C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001BEF18: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001BEF20: DC5E00F0 057C0005
	s_cselect_b32 s1, -1, 0                                    // 0000001BEF28: 980180C1
	s_or_b32 s0, s7, 16                                        // 0000001BEF2C: 8C009007
	v_cndmask_b16 v16, 0, v16, s1                              // 0000001BEF30: D65D5010 00062080
	s_cmp_lt_i32 s0, s58                                       // 0000001BEF38: BF043A00
	v_fma_mixlo_f16 v56, v181, s22, 0                          // 0000001BEF3C: CC210038 02002DB5
	s_cselect_b32 s0, -1, 0                                    // 0000001BEF44: 980080C1
	v_mul_f32_e32 v190, v182, v195                             // 0000001BEF48: 117D87B6
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001BEF4C: D65D0035 00026A80
	s_or_b32 s0, s7, 17                                        // 0000001BEF54: 8C009107
	ds_load_2addr_b32 v[181:182], v155 offset1:1               // 0000001BEF58: D8DC0100 B500009B
	ds_load_2addr_b32 v[188:189], v156 offset1:1               // 0000001BEF60: D8DC0100 BC00009C
	s_cmp_lt_i32 s0, s58                                       // 0000001BEF68: BF043A00
	ds_store_b128 v125, v[9:12]                                // 0000001BEF6C: DB7C0000 0000097D
	ds_store_b128 v125, v[13:16] offset:16                     // 0000001BEF74: DB7C0010 00000D7D
	s_cselect_b32 s0, -1, 0                                    // 0000001BEF7C: 980080C1
	s_or_b32 s1, s7, 18                                        // 0000001BEF80: 8C019207
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001BEF84: D65D5035 00026A80
	s_cmp_lt_i32 s1, s58                                       // 0000001BEF8C: BF043A01
	ds_load_2addr_b32 v[11:12], v158 offset1:1                 // 0000001BEF90: D8DC0100 0B00009E
	s_cselect_b32 s0, -1, 0                                    // 0000001BEF98: 980080C1
	s_or_b32 s1, s7, 19                                        // 0000001BEF9C: 8C019307
	v_cndmask_b16 v54, 0, v54, s0                              // 0000001BEFA0: D65D0036 00026C80
	s_cmp_lt_i32 s1, s58                                       // 0000001BEFA8: BF043A01
	s_waitcnt lgkmcnt(6)                                       // 0000001BEFAC: BF89FC67
	v_mul_f32_e32 v184, v179, v184                             // 0000001BEFB0: 117171B3
	s_cselect_b32 s0, -1, 0                                    // 0000001BEFB4: 980080C1
	s_or_b32 s1, s7, 20                                        // 0000001BEFB8: 8C019407
	v_cndmask_b16 v54, 0, v54, s0                              // 0000001BEFBC: D65D5036 00026C80
	s_cmp_lt_i32 s1, s58                                       // 0000001BEFC4: BF043A01
	v_fma_mixlo_f16 v179, v190, s22, 0                         // 0000001BEFC8: CC2100B3 02002DBE
	s_cselect_b32 s1, -1, 0                                    // 0000001BEFD0: 980180C1
	s_or_b32 s8, s7, 21                                        // 0000001BEFD4: 8C089507
	v_cndmask_b16 v55, 0, v55, s1                              // 0000001BEFD8: D65D0037 00066E80
	s_cmp_lt_i32 s8, s58                                       // 0000001BEFE0: BF043A08
	v_mul_f32_e32 v176, v176, v185                             // 0000001BEFE4: 116173B0
	s_cselect_b32 s0, -1, 0                                    // 0000001BEFE8: 980080C1
	s_or_b32 s8, s7, 22                                        // 0000001BEFEC: 8C089607
	v_cndmask_b16 v55, 0, v55, s0                              // 0000001BEFF0: D65D5037 00026E80
	s_cmp_lt_i32 s8, s58                                       // 0000001BEFF8: BF043A08
	v_fma_mixhi_f16 v179, v184, s22, 0                         // 0000001BEFFC: CC2200B3 02002DB8
	s_cselect_b32 s1, -1, 0                                    // 0000001BF004: 980180C1
	s_or_b32 s8, s7, 23                                        // 0000001BF008: 8C089707
	v_cndmask_b16 v56, 0, v56, s1                              // 0000001BF00C: D65D0038 00067080
	s_cmp_lt_i32 s8, s58                                       // 0000001BF014: BF043A08
	s_waitcnt lgkmcnt(5)                                       // 0000001BF018: BF89FC57
	v_mul_f32_e32 v180, v180, v186                             // 0000001BF01C: 116975B4
	s_cselect_b32 s0, -1, 0                                    // 0000001BF020: 980080C1
	s_or_b32 s8, s7, 24                                        // 0000001BF024: 8C089807
	v_cndmask_b16 v56, 0, v56, s0                              // 0000001BF028: D65D5038 00027080
	s_cmp_lt_i32 s8, s58                                       // 0000001BF030: BF043A08
	v_fma_mixlo_f16 v176, v176, s22, 0                         // 0000001BF034: CC2100B0 02002DB0
	s_cselect_b32 s0, -1, 0                                    // 0000001BF03C: 980080C1
	s_or_b32 s1, s7, 25                                        // 0000001BF040: 8C019907
	v_cndmask_b16 v179, 0, v179, s0                            // 0000001BF044: D65D00B3 00036680
	s_cmp_lt_i32 s1, s58                                       // 0000001BF04C: BF043A01
	v_mul_f32_e32 v183, v183, v187                             // 0000001BF050: 116F77B7
	s_cselect_b32 s1, -1, 0                                    // 0000001BF054: 980180C1
	s_or_b32 s8, s7, 26                                        // 0000001BF058: 8C089A07
	v_cndmask_b16 v179, 0, v179, s1                            // 0000001BF05C: D65D50B3 00076680
	s_cmp_lt_i32 s8, s58                                       // 0000001BF064: BF043A08
	v_fma_mixhi_f16 v176, v180, s22, 0                         // 0000001BF068: CC2200B0 02002DB4
	s_cselect_b32 s0, -1, 0                                    // 0000001BF070: 980080C1
	s_or_b32 s8, s7, 27                                        // 0000001BF074: 8C089B07
	v_cndmask_b16 v180, 0, v176, s0                            // 0000001BF078: D65D00B4 00036080
	s_cmp_lt_i32 s8, s58                                       // 0000001BF080: BF043A08
	v_fma_mixlo_f16 v176, v183, s22, 0                         // 0000001BF084: CC2100B0 02002DB7
	s_cselect_b32 s1, -1, 0                                    // 0000001BF08C: 980180C1
	s_or_b32 s8, s7, 28                                        // 0000001BF090: 8C089C07
	s_waitcnt lgkmcnt(4)                                       // 0000001BF094: BF89FC47
	v_mul_f32_e32 v178, v178, v181                             // 0000001BF098: 11656BB2
	s_cmp_lt_i32 s8, s58                                       // 0000001BF09C: BF043A08
	v_mul_f32_e32 v177, v177, v182                             // 0000001BF0A0: 11636DB1
	s_cselect_b32 s0, -1, 0                                    // 0000001BF0A4: 980080C1
	s_or_b32 s8, s7, 29                                        // 0000001BF0A8: 8C089D07
	v_cndmask_b16 v180, 0, v176, s1                            // 0000001BF0AC: D65D50B4 00076080
	s_cmp_lt_i32 s8, s58                                       // 0000001BF0B4: BF043A08
	v_cndmask_b16 v181, 0, v176, s0                            // 0000001BF0B8: D65D00B5 00036080
	s_cselect_b32 s0, -1, 0                                    // 0000001BF0C0: 980080C1
	s_or_b32 s1, s7, 30                                        // 0000001BF0C4: 8C019E07
	s_waitcnt lgkmcnt(3)                                       // 0000001BF0C8: BF89FC37
	v_mul_f32_e32 v182, v175, v188                             // 0000001BF0CC: 116D79AF
	s_cmp_lt_i32 s1, s58                                       // 0000001BF0D0: BF043A01
	v_fma_mixlo_f16 v176, v178, s22, 0                         // 0000001BF0D4: CC2100B0 02002DB2
	s_cselect_b32 s1, -1, 0                                    // 0000001BF0DC: 980180C1
	v_fma_mixlo_f16 v175, v177, s22, 0                         // 0000001BF0E0: CC2100AF 02002DB1
	ds_load_2addr_b32 v[177:178], v157 offset1:1               // 0000001BF0E8: D8DC0100 B100009D
	s_or_b32 s8, s7, 31                                        // 0000001BF0F0: 8C089F07
	v_fma_mixhi_f16 v175, v182, s22, 0                         // 0000001BF0F4: CC2200AF 02002DB6
	s_cmp_lt_i32 s8, s58                                       // 0000001BF0FC: BF043A08
	v_cndmask_b16 v181, 0, v176, s0                            // 0000001BF100: D65D40B5 00036080
	s_cselect_b32 s0, -1, 0                                    // 0000001BF108: 980080C1
	v_cndmask_b16 v182, 0, v175, s1                            // 0000001BF10C: D65D00B6 00075E80
	v_cndmask_b16 v182, 0, v175, s0                            // 0000001BF114: D65D50B6 00035E80
	ds_store_b128 v125, v[53:56] offset:32                     // 0000001BF11C: DB7C0020 0000357D
	ds_store_b128 v125, v[179:182] offset:48                   // 0000001BF124: DB7C0030 0000B37D
	s_waitcnt lgkmcnt(3)                                       // 0000001BF12C: BF89FC37
	v_dual_mul_f32 v11, v104, v11 :: v_dual_mul_f32 v12, v103, v12// 0000001BF130: C8C61768 0B0C1967
	ds_load_2addr_b32 v[55:56], v163 offset1:1                 // 0000001BF138: D8DC0100 370000A3
	ds_load_2addr_b32 v[103:104], v164 offset1:1               // 0000001BF140: D8DC0100 670000A4
	v_mul_f32_e32 v9, v174, v189                               // 0000001BF148: 10137BAE
	s_or_b32 s0, s7, 32                                        // 0000001BF14C: 8C00A007
	ds_load_2addr_b32 v[13:14], v159 offset1:1                 // 0000001BF150: D8DC0100 0D00009F
	ds_load_2addr_b32 v[15:16], v160 offset1:1                 // 0000001BF158: D8DC0100 0F0000A0
	s_cmp_lt_i32 s0, s58                                       // 0000001BF160: BF043A00
	v_fma_mixlo_f16 v9, v9, s22, 0                             // 0000001BF164: CC210009 02002D09
	s_cselect_b32 s0, -1, 0                                    // 0000001BF16C: 980080C1
	s_waitcnt lgkmcnt(6)                                       // 0000001BF170: BF89FC67
	v_dual_mul_f32 v10, v173, v177 :: v_dual_mul_f32 v53, v172, v178// 0000001BF174: C8C763AD 0A3565AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BF17C: BF870122
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001BF180: D65D0009 00021280
	s_or_b32 s0, s7, 33                                        // 0000001BF188: 8C00A107
	v_fma_mixhi_f16 v9, v10, s22, 0                            // 0000001BF18C: CC220009 02002D0A
	s_cmp_lt_i32 s0, s58                                       // 0000001BF194: BF043A00
	v_fma_mixhi_f16 v10, v11, s22, 0                           // 0000001BF198: CC22000A 02002D0B
	s_cselect_b32 s0, -1, 0                                    // 0000001BF1A0: 980080C1
	s_or_b32 s1, s7, 34                                        // 0000001BF1A4: 8C01A207
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001BF1A8: D65D5009 00021280
	s_cmp_lt_i32 s1, s58                                       // 0000001BF1B0: BF043A01
	s_waitcnt lgkmcnt(3)                                       // 0000001BF1B4: BF89FC37
	v_mul_f32_e32 v34, v34, v56                                // 0000001BF1B8: 10447122
	v_fma_mixlo_f16 v10, v53, s22, 0                           // 0000001BF1BC: CC21000A 02002D35
	s_cselect_b32 s0, -1, 0                                    // 0000001BF1C4: 980080C1
	s_or_b32 s1, s7, 35                                        // 0000001BF1C8: 8C01A307
	ds_load_2addr_b32 v[53:54], v161 offset1:1                 // 0000001BF1CC: D8DC0100 350000A1
	s_cmp_lt_i32 s1, s58                                       // 0000001BF1D4: BF043A01
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001BF1D8: D65D000A 00021480
	s_cselect_b32 s0, -1, 0                                    // 0000001BF1E0: 980080C1
	s_or_b32 s1, s7, 36                                        // 0000001BF1E4: 8C01A407
	v_fma_mixlo_f16 v11, v12, s22, 0                           // 0000001BF1E8: CC21000B 02002D0C
	s_cmp_lt_i32 s1, s58                                       // 0000001BF1F0: BF043A01
	s_waitcnt lgkmcnt(2)                                       // 0000001BF1F4: BF89FC27
	v_mul_f32_e32 v12, v105, v13                               // 0000001BF1F8: 10181B69
	s_cselect_b32 s1, -1, 0                                    // 0000001BF1FC: 980180C1
	s_or_b32 s8, s7, 37                                        // 0000001BF200: 8C08A507
	v_mul_f32_e32 v13, v117, v14                               // 0000001BF204: 101A1D75
	s_cmp_lt_i32 s8, s58                                       // 0000001BF208: BF043A08
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001BF20C: D65D500A 00021480
	s_cselect_b32 s0, -1, 0                                    // 0000001BF214: 980080C1
	s_or_b32 s8, s7, 38                                        // 0000001BF218: 8C08A607
	s_waitcnt lgkmcnt(1)                                       // 0000001BF21C: BF89FC17
	v_mul_f32_e32 v14, v116, v15                               // 0000001BF220: 101C1F74
	s_cmp_lt_i32 s8, s58                                       // 0000001BF224: BF043A08
	v_fma_mixhi_f16 v11, v12, s22, 0                           // 0000001BF228: CC22000B 02002D0C
	v_fma_mixlo_f16 v12, v13, s22, 0                           // 0000001BF230: CC21000C 02002D0D
	v_mul_f32_e32 v13, v101, v16                               // 0000001BF238: 101A2165
	ds_load_2addr_b32 v[15:16], v162 offset1:1                 // 0000001BF23C: D8DC0100 0F0000A2
	v_cndmask_b16 v11, 0, v11, s1                              // 0000001BF244: D65D000B 00061680
	s_cselect_b32 s1, -1, 0                                    // 0000001BF24C: 980180C1
	s_or_b32 s8, s7, 39                                        // 0000001BF250: 8C08A707
	v_fma_mixhi_f16 v12, v14, s22, 0                           // 0000001BF254: CC22000C 02002D0E
	s_cmp_lt_i32 s8, s58                                       // 0000001BF25C: BF043A08
	v_cndmask_b16 v11, 0, v11, s0                              // 0000001BF260: D65D500B 00021680
	v_cndmask_b16 v12, 0, v12, s1                              // 0000001BF268: D65D000C 00061880
	s_cselect_b32 s0, -1, 0                                    // 0000001BF270: 980080C1
	s_or_b32 s1, s7, 40                                        // 0000001BF274: 8C01A807
	v_fma_mixlo_f16 v13, v13, s22, 0                           // 0000001BF278: CC21000D 02002D0D
	s_cmp_lt_i32 s1, s58                                       // 0000001BF280: BF043A01
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001BF284: D65D500C 00021880
	s_cselect_b32 s0, -1, 0                                    // 0000001BF28C: 980080C1
	s_waitcnt lgkmcnt(1)                                       // 0000001BF290: BF89FC17
	v_mul_f32_e32 v14, v40, v53                                // 0000001BF294: 101C6B28
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001BF298: D65D000D 00021A80
	s_or_b32 s0, s7, 41                                        // 0000001BF2A0: 8C00A907
	v_mul_f32_e32 v40, v102, v54                               // 0000001BF2A4: 10506D66
	s_cmp_lt_i32 s0, s58                                       // 0000001BF2A8: BF043A00
	v_fma_mixhi_f16 v13, v14, s22, 0                           // 0000001BF2AC: CC22000D 02002D0E
	s_cselect_b32 s0, -1, 0                                    // 0000001BF2B4: 980080C1
	s_or_b32 s1, s7, 42                                        // 0000001BF2B8: 8C01AA07
	v_fma_mixlo_f16 v14, v40, s22, 0                           // 0000001BF2BC: CC21000E 02002D28
	s_cmp_lt_i32 s1, s58                                       // 0000001BF2C4: BF043A01
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001BF2C8: D65D500D 00021A80
	s_cselect_b32 s0, -1, 0                                    // 0000001BF2D0: 980080C1
	s_or_b32 s1, s7, 43                                        // 0000001BF2D4: 8C01AB07
	s_waitcnt lgkmcnt(0)                                       // 0000001BF2D8: BF89FC07
	v_dual_mul_f32 v15, v100, v15 :: v_dual_mul_f32 v16, v99, v16// 0000001BF2DC: C8C61F64 0F102163
	s_cmp_lt_i32 s1, s58                                       // 0000001BF2E4: BF043A01
	v_cndmask_b16 v14, 0, v14, s0                              // 0000001BF2E8: D65D000E 00021C80
	s_cselect_b32 s0, -1, 0                                    // 0000001BF2F0: 980080C1
	s_or_b32 s1, s7, 44                                        // 0000001BF2F4: 8C01AC07
	ds_load_2addr_b32 v[53:54], v165 offset1:1                 // 0000001BF2F8: D8DC0100 350000A5
	s_cmp_lt_i32 s1, s58                                       // 0000001BF300: BF043A01
	v_fma_mixhi_f16 v14, v15, s22, 0                           // 0000001BF304: CC22000E 02002D0F
	v_fma_mixlo_f16 v15, v16, s22, 0                           // 0000001BF30C: CC21000F 02002D10
	v_mul_f32_e32 v16, v37, v55                                // 0000001BF314: 10206F25
	s_cselect_b32 s1, -1, 0                                    // 0000001BF318: 980180C1
	s_or_b32 s8, s7, 45                                        // 0000001BF31C: 8C08AD07
	v_mul_f32_e32 v37, v50, v103                               // 0000001BF320: 104ACF32
	s_cmp_lt_i32 s8, s58                                       // 0000001BF324: BF043A08
	v_fma_mixhi_f16 v15, v16, s22, 0                           // 0000001BF328: CC22000F 02002D10
	v_fma_mixlo_f16 v16, v34, s22, 0                           // 0000001BF330: CC210010 02002D22
	v_mul_f32_e32 v34, v49, v104                               // 0000001BF338: 1044D131
	ds_load_2addr_b32 v[49:50], v166 offset1:1                 // 0000001BF33C: D8DC0100 310000A6
	v_cndmask_b16 v14, 0, v14, s0                              // 0000001BF344: D65D500E 00021C80
	s_cselect_b32 s0, -1, 0                                    // 0000001BF34C: 980080C1
	s_or_b32 s8, s7, 46                                        // 0000001BF350: 8C08AE07
	v_cndmask_b16 v15, 0, v15, s1                              // 0000001BF354: D65D000F 00061E80
	s_cmp_lt_i32 s8, s58                                       // 0000001BF35C: BF043A08
	ds_load_2addr_b32 v[55:56], v167 offset1:1                 // 0000001BF360: D8DC0100 370000A7
	ds_load_2addr_b32 v[99:100], v168 offset1:1                // 0000001BF368: D8DC0100 630000A8
	s_cselect_b32 s1, -1, 0                                    // 0000001BF370: 980180C1
	s_or_b32 s8, s7, 47                                        // 0000001BF374: 8C08AF07
	v_fma_mixhi_f16 v16, v37, s22, 0                           // 0000001BF378: CC220010 02002D25
	s_cmp_lt_i32 s8, s58                                       // 0000001BF380: BF043A08
	v_cndmask_b16 v15, 0, v15, s0                              // 0000001BF384: D65D500F 00021E80
	v_cndmask_b16 v16, 0, v16, s1                              // 0000001BF38C: D65D0010 00062080
	s_cselect_b32 s0, -1, 0                                    // 0000001BF394: 980080C1
	s_or_b32 s1, s7, 48                                        // 0000001BF398: 8C01B007
	v_fma_mixlo_f16 v34, v34, s22, 0                           // 0000001BF39C: CC210022 02002D22
	s_cmp_lt_i32 s1, s58                                       // 0000001BF3A4: BF043A01
	v_cndmask_b16 v16, 0, v16, s0                              // 0000001BF3A8: D65D5010 00022080
	s_cselect_b32 s0, -1, 0                                    // 0000001BF3B0: 980080C1
	s_waitcnt lgkmcnt(3)                                       // 0000001BF3B4: BF89FC37
	v_mul_f32_e32 v35, v35, v53                                // 0000001BF3B8: 10466B23
	v_cndmask_b16 v34, 0, v34, s0                              // 0000001BF3BC: D65D0022 00024480
	s_or_b32 s0, s7, 49                                        // 0000001BF3C4: 8C00B107
	v_mul_f32_e32 v37, v33, v54                                // 0000001BF3C8: 104A6D21
	s_cmp_lt_i32 s0, s58                                       // 0000001BF3CC: BF043A00
	v_fma_mixlo_f16 v33, v35, s22, 0                           // 0000001BF3D0: CC210021 02002D23
	s_cselect_b32 s0, -1, 0                                    // 0000001BF3D8: 980080C1
	s_or_b32 s1, s7, 50                                        // 0000001BF3DC: 8C01B207
	v_fma_mixhi_f16 v33, v37, s22, 0                           // 0000001BF3E0: CC220021 02002D25
	s_waitcnt lgkmcnt(2)                                       // 0000001BF3E8: BF89FC27
	v_mul_f32_e32 v27, v27, v49                                // 0000001BF3EC: 1036631B
	s_cmp_lt_i32 s1, s58                                       // 0000001BF3F0: BF043A01
	v_cndmask_b16 v34, 0, v33, s0                              // 0000001BF3F4: D65D4022 00024280
	s_cselect_b32 s0, -1, 0                                    // 0000001BF3FC: 980080C1
	s_or_b32 s1, s7, 51                                        // 0000001BF400: 8C01B307
	v_cndmask_b16 v35, 0, v33, s0                              // 0000001BF404: D65D1023 00024280
	v_mul_f32_e32 v32, v32, v50                                // 0000001BF40C: 10406520
	v_fma_mixlo_f16 v27, v27, s22, 0                           // 0000001BF410: CC21001B 02002D1B
	s_waitcnt lgkmcnt(1)                                       // 0000001BF418: BF89FC17
	v_mul_f32_e32 v33, v36, v55                                // 0000001BF41C: 10426F24
	s_cmp_lt_i32 s1, s58                                       // 0000001BF420: BF043A01
	v_mul_f32_e32 v29, v29, v56                                // 0000001BF424: 103A711D
	s_cselect_b32 s0, -1, 0                                    // 0000001BF428: 980080C1
	s_or_b32 s1, s7, 52                                        // 0000001BF42C: 8C01B407
	v_fma_mixhi_f16 v27, v32, s22, 0                           // 0000001BF430: CC22001B 02002D20
	s_cmp_lt_i32 s1, s58                                       // 0000001BF438: BF043A01
	v_cndmask_b16 v35, 0, v27, s0                              // 0000001BF43C: D65D4023 00023680
	v_fma_mixlo_f16 v27, v33, s22, 0                           // 0000001BF444: CC21001B 02002D21
	ds_load_2addr_b32 v[32:33], v169 offset1:1                 // 0000001BF44C: D8DC0100 200000A9
	ds_load_2addr_b32 v[53:54], v171 offset1:1                 // 0000001BF454: D8DC0100 350000AB
	s_cselect_b32 s1, -1, 0                                    // 0000001BF45C: 980180C1
	s_or_b32 s8, s7, 53                                        // 0000001BF460: 8C08B507
	s_waitcnt lgkmcnt(2)                                       // 0000001BF464: BF89FC27
	v_mul_f32_e32 v28, v28, v99                                // 0000001BF468: 1038C71C
	s_cmp_lt_i32 s8, s58                                       // 0000001BF46C: BF043A08
	ds_load_2addr_b32 v[49:50], v170 offset1:1                 // 0000001BF470: D8DC0100 310000AA
	s_cselect_b32 s0, -1, 0                                    // 0000001BF478: 980080C1
	v_cndmask_b16 v36, 0, v27, s1                              // 0000001BF47C: D65D1024 00063680
	v_cndmask_b16 v36, 0, v27, s0                              // 0000001BF484: D65D4024 00023680
	s_or_b32 s0, s7, 54                                        // 0000001BF48C: 8C00B607
	v_fma_mixlo_f16 v27, v29, s22, 0                           // 0000001BF490: CC21001B 02002D1D
	s_cmp_lt_i32 s0, s58                                       // 0000001BF498: BF043A00
	v_fma_mixhi_f16 v27, v28, s22, 0                           // 0000001BF49C: CC22001B 02002D1C
	s_cselect_b32 s0, -1, 0                                    // 0000001BF4A4: 980080C1
	s_or_b32 s1, s7, 55                                        // 0000001BF4A8: 8C01B707
	v_cndmask_b16 v37, 0, v27, s0                              // 0000001BF4AC: D65D0025 00023680
	s_cmp_lt_i32 s1, s58                                       // 0000001BF4B4: BF043A01
	v_mul_f32_e32 v25, v25, v100                               // 0000001BF4B8: 1032C919
	s_cselect_b32 s0, -1, 0                                    // 0000001BF4BC: 980080C1
	s_or_b32 s1, s7, 56                                        // 0000001BF4C0: 8C01B807
	v_cndmask_b16 v37, 0, v27, s0                              // 0000001BF4C4: D65D5025 00023680
	s_cmp_lt_i32 s1, s58                                       // 0000001BF4CC: BF043A01
	s_waitcnt lgkmcnt(2)                                       // 0000001BF4D0: BF89FC27
	v_mul_f32_e32 v27, v38, v32                                // 0000001BF4D4: 10364126
	s_cselect_b32 s0, -1, 0                                    // 0000001BF4D8: 980080C1
	s_or_b32 s1, s7, 57                                        // 0000001BF4DC: 8C01B907
	v_mul_f32_e32 v28, v39, v33                                // 0000001BF4E0: 10384327
	s_cmp_lt_i32 s1, s58                                       // 0000001BF4E4: BF043A01
	ds_load_b32 v32, v107 offset:61692                         // 0000001BF4E8: D8D8F0FC 2000006B
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001BF4F0: CC210019 02002D19
	s_cselect_b32 s1, -1, 0                                    // 0000001BF4F8: 980180C1
	s_or_b32 s8, s7, 58                                        // 0000001BF4FC: 8C08BA07
	v_fma_mixhi_f16 v25, v27, s22, 0                           // 0000001BF500: CC220019 02002D1B
	v_fma_mixlo_f16 v28, v28, s22, 0                           // 0000001BF508: CC21001C 02002D1C
	s_cmp_lt_i32 s8, s58                                       // 0000001BF510: BF043A08
	v_cndmask_b16 v27, 0, v25, s0                              // 0000001BF514: D65D001B 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001BF51C: 980080C1
	v_cndmask_b16 v27, 0, v25, s1                              // 0000001BF520: D65D501B 00063280
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001BF528: D65D001C 00023880
	s_or_b32 s0, s7, 59                                        // 0000001BF530: 8C00BB07
	s_waitcnt lgkmcnt(1)                                       // 0000001BF534: BF89FC17
	v_mul_f32_e32 v25, v31, v49                                // 0000001BF538: 1032631F
	v_mul_f32_e32 v29, v30, v50                                // 0000001BF53C: 103A651E
	s_cmp_lt_i32 s0, s58                                       // 0000001BF540: BF043A00
	s_cselect_b32 s0, -1, 0                                    // 0000001BF544: 980080C1
	s_or_b32 s1, s7, 60                                        // 0000001BF548: 8C01BC07
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001BF54C: CC210019 02002D19
	v_fma_mixhi_f16 v25, v29, s22, 0                           // 0000001BF554: CC220019 02002D1D
	s_cmp_lt_i32 s1, s58                                       // 0000001BF55C: BF043A01
	s_waitcnt lgkmcnt(0)                                       // 0000001BF560: BF89FC07
	v_mul_f32_e32 v30, v52, v32                                // 0000001BF564: 103C4134
	s_cselect_b32 s1, -1, 0                                    // 0000001BF568: 980180C1
	s_or_b32 s8, s7, 61                                        // 0000001BF56C: 8C08BD07
	v_cndmask_b16 v28, 0, v25, s0                              // 0000001BF570: D65D401C 00023280
	s_cmp_lt_i32 s8, s58                                       // 0000001BF578: BF043A08
	v_cndmask_b16 v29, 0, v25, s1                              // 0000001BF57C: D65D101D 00063280
	v_mul_f32_e32 v25, v26, v53                                // 0000001BF584: 10326B1A
	s_cselect_b32 s0, -1, 0                                    // 0000001BF588: 980080C1
	s_or_b32 s1, s7, 62                                        // 0000001BF58C: 8C01BE07
	v_mul_f32_e32 v26, v51, v54                                // 0000001BF590: 10346D33
	s_cmp_lt_i32 s1, s58                                       // 0000001BF594: BF043A01
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001BF598: CC210019 02002D19
	s_cselect_b32 s1, -1, 0                                    // 0000001BF5A0: 980180C1
	s_or_b32 s8, s7, 63                                        // 0000001BF5A4: 8C08BF07
	v_fma_mixhi_f16 v25, v26, s22, 0                           // 0000001BF5A8: CC220019 02002D1A
	v_fma_mixlo_f16 v26, v30, s22, 0                           // 0000001BF5B0: CC21001A 02002D1E
	s_cmp_lt_i32 s8, s58                                       // 0000001BF5B8: BF043A08
	v_cndmask_b16 v29, 0, v25, s0                              // 0000001BF5BC: D65D401D 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001BF5C4: 980080C1
	v_cndmask_b16 v30, 0, v25, s1                              // 0000001BF5C8: D65D101E 00063280
	v_cndmask_b16 v30, 0, v26, s0                              // 0000001BF5D0: D65D401E 00023480
	ds_store_b128 v125, v[9:12] offset:64                      // 0000001BF5D8: DB7C0040 0000097D
	ds_store_b128 v125, v[13:16] offset:80                     // 0000001BF5E0: DB7C0050 00000D7D
	ds_store_b128 v125, v[34:37] offset:96                     // 0000001BF5E8: DB7C0060 0000227D
	ds_store_b128 v125, v[27:30] offset:112                    // 0000001BF5F0: DB7C0070 00001B7D
	s_and_saveexec_b32 s0, s13                                 // 0000001BF5F8: BE80200D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BF5FC: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 0000001BF600: 8D00007E
	s_cbranch_execz 67                                         // 0000001BF604: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2b14>
	s_waitcnt vmcnt(1)                                         // 0000001BF608: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001BF60C: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BF610: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001BF614: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001BF618: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001BF61C: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001BF620: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001BF624: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001BF628: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001BF62C: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001BF630: 7E100301
	v_mov_b32_e32 v17, v1                                      // 0000001BF634: 7E220301
	v_mov_b32_e32 v18, v1                                      // 0000001BF638: 7E240301
	v_mov_b32_e32 v19, v1                                      // 0000001BF63C: 7E260301
	v_mov_b32_e32 v20, v1                                      // 0000001BF640: 7E280301
	v_mov_b32_e32 v21, v1                                      // 0000001BF644: 7E2A0301
	v_mov_b32_e32 v22, v1                                      // 0000001BF648: 7E2C0301
	v_mov_b32_e32 v23, v1                                      // 0000001BF64C: 7E2E0301
	v_mov_b32_e32 v24, v1                                      // 0000001BF650: 7E300301
	v_mov_b32_e32 v41, v1                                      // 0000001BF654: 7E520301
	v_mov_b32_e32 v42, v1                                      // 0000001BF658: 7E540301
	v_mov_b32_e32 v43, v1                                      // 0000001BF65C: 7E560301
	v_mov_b32_e32 v44, v1                                      // 0000001BF660: 7E580301
	v_mov_b32_e32 v45, v1                                      // 0000001BF664: 7E5A0301
	v_mov_b32_e32 v46, v1                                      // 0000001BF668: 7E5C0301
	v_mov_b32_e32 v47, v1                                      // 0000001BF66C: 7E5E0301
	v_mov_b32_e32 v48, v1                                      // 0000001BF670: 7E600301
	v_mov_b32_e32 v57, v1                                      // 0000001BF674: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001BF678: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001BF67C: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001BF680: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001BF684: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001BF688: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001BF68C: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001BF690: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001BF694: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001BF698: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001BF69C: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001BF6A0: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001BF6A4: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001BF6A8: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001BF6AC: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001BF6B0: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001BF6B4: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001BF6B8: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001BF6BC: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001BF6C0: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001BF6C4: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001BF6C8: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001BF6CC: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001BF6D0: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001BF6D4: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001BF6D8: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001BF6DC: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001BF6E0: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001BF6E4: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001BF6E8: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001BF6EC: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001BF6F0: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001BF6F4: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001BF6F8: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001BF6FC: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001BF700: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001BF704: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001BF708: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001BF70C: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001BF710: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001BF714: 8C7E007E
	ds_load_b128 v[9:12], v127                                 // 0000001BF718: DBFC0000 0900007F
	ds_load_b128 v[13:16], v127 offset:16                      // 0000001BF720: DBFC0010 0D00007F
	ds_load_b128 v[25:28], v127 offset:32                      // 0000001BF728: DBFC0020 1900007F
	ds_load_b128 v[29:32], v127 offset:48                      // 0000001BF730: DBFC0030 1D00007F
	ds_load_b128 v[33:36], v127 offset:8448                    // 0000001BF738: DBFC2100 2100007F
	ds_load_b128 v[37:40], v127 offset:8464                    // 0000001BF740: DBFC2110 2500007F
	ds_load_b128 v[49:52], v127 offset:8480                    // 0000001BF748: DBFC2120 3100007F
	ds_load_b128 v[53:56], v127 offset:8496                    // 0000001BF750: DBFC2130 3500007F
	ds_load_b128 v[99:102], v127 offset:16896                  // 0000001BF758: DBFC4200 6300007F
	ds_load_b128 v[180:183], v127 offset:16912                 // 0000001BF760: DBFC4210 B400007F
	v_dual_mov_b32 v179, s43 :: v_dual_mov_b32 v178, s42       // 0000001BF768: CA10002B B3B2002A
	v_dual_mov_b32 v177, s41 :: v_dual_mov_b32 v176, s40       // 0000001BF770: CA100029 B1B00028
	v_dual_mov_b32 v175, s39 :: v_dual_mov_b32 v174, s38       // 0000001BF778: CA100027 AFAE0026
	v_dual_mov_b32 v173, s37 :: v_dual_mov_b32 v172, s36       // 0000001BF780: CA100025 ADAC0024
	ds_load_b128 v[184:187], v127 offset:16928                 // 0000001BF788: DBFC4220 B800007F
	ds_load_b128 v[188:191], v127 offset:16944                 // 0000001BF790: DBFC4230 BC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001BF798: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s22, 0                             // 0000001BF79C: CC210009 02002D09
	v_fma_mixhi_f16 v9, v10, s22, 0                            // 0000001BF7A4: CC220009 02002D0A
	v_fma_mixlo_f16 v10, v11, s22, 0                           // 0000001BF7AC: CC21000A 02002D0B
	v_fma_mixhi_f16 v10, v12, s22, 0                           // 0000001BF7B4: CC22000A 02002D0C
	s_waitcnt lgkmcnt(10)                                      // 0000001BF7BC: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s22, 0                           // 0000001BF7C0: CC21000B 02002D0D
	v_fma_mixhi_f16 v11, v14, s22, 0                           // 0000001BF7C8: CC22000B 02002D0E
	v_fma_mixlo_f16 v12, v15, s22, 0                           // 0000001BF7D0: CC21000C 02002D0F
	v_fma_mixhi_f16 v12, v16, s22, 0                           // 0000001BF7D8: CC22000C 02002D10
	s_waitcnt lgkmcnt(9)                                       // 0000001BF7E0: BF89FC97
	v_fma_mixlo_f16 v13, v25, s22, 0                           // 0000001BF7E4: CC21000D 02002D19
	v_fma_mixhi_f16 v13, v26, s22, 0                           // 0000001BF7EC: CC22000D 02002D1A
	v_fma_mixlo_f16 v14, v27, s22, 0                           // 0000001BF7F4: CC21000E 02002D1B
	v_fma_mixhi_f16 v14, v28, s22, 0                           // 0000001BF7FC: CC22000E 02002D1C
	s_waitcnt lgkmcnt(8)                                       // 0000001BF804: BF89FC87
	v_fma_mixlo_f16 v15, v29, s22, 0                           // 0000001BF808: CC21000F 02002D1D
	v_fma_mixhi_f16 v15, v30, s22, 0                           // 0000001BF810: CC22000F 02002D1E
	v_fma_mixlo_f16 v16, v31, s22, 0                           // 0000001BF818: CC210010 02002D1F
	v_fma_mixhi_f16 v16, v32, s22, 0                           // 0000001BF820: CC220010 02002D20
	s_waitcnt lgkmcnt(7)                                       // 0000001BF828: BF89FC77
	v_fma_mixlo_f16 v33, v33, s22, 0                           // 0000001BF82C: CC210021 02002D21
	v_fma_mixhi_f16 v33, v34, s22, 0                           // 0000001BF834: CC220021 02002D22
	v_fma_mixlo_f16 v34, v35, s22, 0                           // 0000001BF83C: CC210022 02002D23
	v_fma_mixhi_f16 v34, v36, s22, 0                           // 0000001BF844: CC220022 02002D24
	s_waitcnt lgkmcnt(6)                                       // 0000001BF84C: BF89FC67
	v_fma_mixlo_f16 v35, v37, s22, 0                           // 0000001BF850: CC210023 02002D25
	v_fma_mixhi_f16 v35, v38, s22, 0                           // 0000001BF858: CC220023 02002D26
	v_fma_mixlo_f16 v36, v39, s22, 0                           // 0000001BF860: CC210024 02002D27
	v_fma_mixhi_f16 v36, v40, s22, 0                           // 0000001BF868: CC220024 02002D28
	s_waitcnt lgkmcnt(5)                                       // 0000001BF870: BF89FC57
	v_fma_mixlo_f16 v37, v49, s22, 0                           // 0000001BF874: CC210025 02002D31
	v_fma_mixhi_f16 v37, v50, s22, 0                           // 0000001BF87C: CC220025 02002D32
	v_fma_mixlo_f16 v38, v51, s22, 0                           // 0000001BF884: CC210026 02002D33
	v_fma_mixhi_f16 v38, v52, s22, 0                           // 0000001BF88C: CC220026 02002D34
	s_waitcnt lgkmcnt(4)                                       // 0000001BF894: BF89FC47
	v_fma_mixlo_f16 v39, v53, s22, 0                           // 0000001BF898: CC210027 02002D35
	v_fma_mixhi_f16 v39, v54, s22, 0                           // 0000001BF8A0: CC220027 02002D36
	v_fma_mixlo_f16 v40, v55, s22, 0                           // 0000001BF8A8: CC210028 02002D37
	v_fma_mixhi_f16 v40, v56, s22, 0                           // 0000001BF8B0: CC220028 02002D38
	s_waitcnt vmcnt(14)                                        // 0000001BF8B8: BF893BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[9:16], v[172:179]// 0000001BF8BC: CC404031 1EB21359
	s_waitcnt lgkmcnt(3)                                       // 0000001BF8C4: BF89FC37
	v_fma_mixlo_f16 v9, v99, s22, 0                            // 0000001BF8C8: CC210009 02002D63
	v_fma_mixhi_f16 v9, v100, s22, 0                           // 0000001BF8D0: CC220009 02002D64
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[33:40], v[172:179]// 0000001BF8D8: CC404019 1EB24359
	ds_load_b128 v[33:36], v127 offset:25344                   // 0000001BF8E0: DBFC6300 2100007F
	ds_load_b128 v[37:40], v127 offset:25360                   // 0000001BF8E8: DBFC6310 2500007F
	v_fma_mixlo_f16 v10, v101, s22, 0                          // 0000001BF8F0: CC21000A 02002D65
	v_fma_mixhi_f16 v10, v102, s22, 0                          // 0000001BF8F8: CC22000A 02002D66
	ds_load_b128 v[99:102], v127 offset:25376                  // 0000001BF900: DBFC6320 6300007F
	ds_load_b128 v[192:195], v127 offset:25392                 // 0000001BF908: DBFC6330 C000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001BF910: BF89FC67
	v_fma_mixlo_f16 v11, v180, s22, 0                          // 0000001BF914: CC21000B 02002DB4
	v_fma_mixhi_f16 v11, v181, s22, 0                          // 0000001BF91C: CC22000B 02002DB5
	v_fma_mixlo_f16 v12, v182, s22, 0                          // 0000001BF924: CC21000C 02002DB6
	v_fma_mixhi_f16 v12, v183, s22, 0                          // 0000001BF92C: CC22000C 02002DB7
	s_waitcnt lgkmcnt(5)                                       // 0000001BF934: BF89FC57
	v_fma_mixlo_f16 v13, v184, s22, 0                          // 0000001BF938: CC21000D 02002DB8
	v_fma_mixhi_f16 v13, v185, s22, 0                          // 0000001BF940: CC22000D 02002DB9
	s_waitcnt lgkmcnt(4)                                       // 0000001BF948: BF89FC47
	v_fma_mixlo_f16 v15, v188, s22, 0                          // 0000001BF94C: CC21000F 02002DBC
	v_fma_mixhi_f16 v15, v189, s22, 0                          // 0000001BF954: CC22000F 02002DBD
	v_fma_mixlo_f16 v16, v190, s22, 0                          // 0000001BF95C: CC210010 02002DBE
	v_fma_mixhi_f16 v16, v191, s22, 0                          // 0000001BF964: CC220010 02002DBF
	ds_load_b128 v[188:191], v127 offset:64                    // 0000001BF96C: DBFC0040 BC00007F
	ds_load_b128 v[196:199], v127 offset:80                    // 0000001BF974: DBFC0050 C400007F
	v_fma_mixlo_f16 v14, v186, s22, 0                          // 0000001BF97C: CC21000E 02002DBA
	v_fma_mixhi_f16 v14, v187, s22, 0                          // 0000001BF984: CC22000E 02002DBB
	s_waitcnt lgkmcnt(5)                                       // 0000001BF98C: BF89FC57
	v_fma_mixlo_f16 v180, v33, s22, 0                          // 0000001BF990: CC2100B4 02002D21
	v_fma_mixhi_f16 v180, v34, s22, 0                          // 0000001BF998: CC2200B4 02002D22
	v_fma_mixlo_f16 v181, v35, s22, 0                          // 0000001BF9A0: CC2100B5 02002D23
	v_fma_mixhi_f16 v181, v36, s22, 0                          // 0000001BF9A8: CC2200B5 02002D24
	s_waitcnt lgkmcnt(4)                                       // 0000001BF9B0: BF89FC47
	v_fma_mixlo_f16 v182, v37, s22, 0                          // 0000001BF9B4: CC2100B6 02002D25
	v_fma_mixhi_f16 v182, v38, s22, 0                          // 0000001BF9BC: CC2200B6 02002D26
	v_fma_mixlo_f16 v183, v39, s22, 0                          // 0000001BF9C4: CC2100B7 02002D27
	ds_load_b128 v[33:36], v127 offset:96                      // 0000001BF9CC: DBFC0060 2100007F
	v_fma_mixhi_f16 v183, v40, s22, 0                          // 0000001BF9D4: CC2200B7 02002D28
	s_waitcnt lgkmcnt(4)                                       // 0000001BF9DC: BF89FC47
	v_fma_mixlo_f16 v184, v99, s22, 0                          // 0000001BF9E0: CC2100B8 02002D63
	v_fma_mixhi_f16 v184, v100, s22, 0                         // 0000001BF9E8: CC2200B8 02002D64
	v_fma_mixlo_f16 v185, v101, s22, 0                         // 0000001BF9F0: CC2100B9 02002D65
	ds_load_b128 v[37:40], v127 offset:112                     // 0000001BF9F8: DBFC0070 2500007F
	v_fma_mixhi_f16 v185, v102, s22, 0                         // 0000001BFA00: CC2200B9 02002D66
	ds_load_b128 v[99:102], v127 offset:8512                   // 0000001BFA08: DBFC2140 6300007F
	s_waitcnt lgkmcnt(5)                                       // 0000001BFA10: BF89FC57
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001BFA14: CC2100BA 02002DC0
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001BFA1C: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001BFA24: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001BFA2C: CC2200BB 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001BFA34: BF89FC47
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001BFA38: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001BFA40: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001BFA48: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001BFA50: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(3)                                       // 0000001BFA58: BF89FC37
	v_fma_mixlo_f16 v190, v196, s22, 0                         // 0000001BFA5C: CC2100BE 02002DC4
	v_fma_mixhi_f16 v190, v197, s22, 0                         // 0000001BFA64: CC2200BE 02002DC5
	v_fma_mixlo_f16 v191, v198, s22, 0                         // 0000001BFA6C: CC2100BF 02002DC6
	v_fma_mixhi_f16 v191, v199, s22, 0                         // 0000001BFA74: CC2200BF 02002DC7
	s_waitcnt lgkmcnt(2)                                       // 0000001BFA7C: BF89FC27
	v_fma_mixlo_f16 v192, v33, s22, 0                          // 0000001BFA80: CC2100C0 02002D21
	v_fma_mixhi_f16 v192, v34, s22, 0                          // 0000001BFA88: CC2200C0 02002D22
	ds_load_b128 v[196:199], v127 offset:8528                  // 0000001BFA90: DBFC2150 C400007F
	v_fma_mixlo_f16 v193, v35, s22, 0                          // 0000001BFA98: CC2100C1 02002D23
	v_fma_mixhi_f16 v193, v36, s22, 0                          // 0000001BFAA0: CC2200C1 02002D24
	s_waitcnt lgkmcnt(2)                                       // 0000001BFAA8: BF89FC27
	v_fma_mixlo_f16 v194, v37, s22, 0                          // 0000001BFAAC: CC2100C2 02002D25
	v_fma_mixhi_f16 v194, v38, s22, 0                          // 0000001BFAB4: CC2200C2 02002D26
	v_fma_mixlo_f16 v195, v39, s22, 0                          // 0000001BFABC: CC2100C3 02002D27
	v_fma_mixhi_f16 v195, v40, s22, 0                          // 0000001BFAC4: CC2200C3 02002D28
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[9:16], v[172:179]// 0000001BFACC: CC404021 1EB21359
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[180:187], v[172:179]// 0000001BFAD4: CC404009 1EB36959
	ds_load_b128 v[172:175], v127 offset:16960                 // 0000001BFADC: DBFC4240 AC00007F
	s_waitcnt lgkmcnt(2)                                       // 0000001BFAE4: BF89FC27
	v_fma_mixlo_f16 v89, v99, s22, 0                           // 0000001BFAE8: CC210059 02002D63
	v_fma_mixhi_f16 v89, v100, s22, 0                          // 0000001BFAF0: CC220059 02002D64
	v_fma_mixlo_f16 v90, v101, s22, 0                          // 0000001BFAF8: CC21005A 02002D65
	v_fma_mixhi_f16 v90, v102, s22, 0                          // 0000001BFB00: CC22005A 02002D66
	ds_load_b128 v[99:102], v127 offset:16976                  // 0000001BFB08: DBFC4250 6300007F
	ds_load_b128 v[200:203], v127 offset:8544                  // 0000001BFB10: DBFC2160 C800007F
	ds_load_b128 v[204:207], v127 offset:8560                  // 0000001BFB18: DBFC2170 CC00007F
	ds_load_b128 v[176:179], v127 offset:16992                 // 0000001BFB20: DBFC4260 B000007F
	ds_load_b128 v[180:183], v127 offset:17008                 // 0000001BFB28: DBFC4270 B400007F
	ds_load_b128 v[184:187], v127 offset:25408                 // 0000001BFB30: DBFC6340 B800007F
	s_waitcnt vmcnt(12)                                        // 0000001BFB38: BF8933F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[188:195], v[49:56]// 0000001BFB3C: CC404031 1CC77951
	ds_load_b128 v[188:191], v127 offset:25424                 // 0000001BFB44: DBFC6350 BC00007F
	ds_load_b128 v[192:195], v127 offset:25456                 // 0000001BFB4C: DBFC6370 C000007F
	s_waitcnt lgkmcnt(9)                                       // 0000001BFB54: BF89FC97
	v_fma_mixlo_f16 v91, v196, s22, 0                          // 0000001BFB58: CC21005B 02002DC4
	v_fma_mixhi_f16 v91, v197, s22, 0                          // 0000001BFB60: CC22005B 02002DC5
	v_fma_mixlo_f16 v92, v198, s22, 0                          // 0000001BFB68: CC21005C 02002DC6
	v_fma_mixhi_f16 v92, v199, s22, 0                          // 0000001BFB70: CC22005C 02002DC7
	ds_load_b128 v[196:199], v127 offset:128                   // 0000001BFB78: DBFC0080 C400007F
	ds_load_b128 v[208:211], v127 offset:176                   // 0000001BFB80: DBFC00B0 D000007F
	s_waitcnt lgkmcnt(10)                                      // 0000001BFB88: BF89FCA7
	v_fma_mixlo_f16 v172, v172, s22, 0                         // 0000001BFB8C: CC2100AC 02002DAC
	v_fma_mixhi_f16 v172, v173, s22, 0                         // 0000001BFB94: CC2200AC 02002DAD
	v_fma_mixlo_f16 v173, v174, s22, 0                         // 0000001BFB9C: CC2100AD 02002DAE
	v_fma_mixhi_f16 v173, v175, s22, 0                         // 0000001BFBA4: CC2200AD 02002DAF
	s_waitcnt lgkmcnt(9)                                       // 0000001BFBAC: BF89FC97
	v_fma_mixlo_f16 v174, v99, s22, 0                          // 0000001BFBB0: CC2100AE 02002D63
	v_fma_mixhi_f16 v174, v100, s22, 0                         // 0000001BFBB8: CC2200AE 02002D64
	v_fma_mixlo_f16 v175, v101, s22, 0                         // 0000001BFBC0: CC2100AF 02002D65
	v_fma_mixhi_f16 v175, v102, s22, 0                         // 0000001BFBC8: CC2200AF 02002D66
	ds_load_b128 v[99:102], v127 offset:25440                  // 0000001BFBD0: DBFC6360 6300007F
	s_waitcnt lgkmcnt(9)                                       // 0000001BFBD8: BF89FC97
	v_fma_mixlo_f16 v93, v200, s22, 0                          // 0000001BFBDC: CC21005D 02002DC8
	v_fma_mixhi_f16 v93, v201, s22, 0                          // 0000001BFBE4: CC22005D 02002DC9
	v_fma_mixlo_f16 v94, v202, s22, 0                          // 0000001BFBEC: CC21005E 02002DCA
	v_fma_mixhi_f16 v94, v203, s22, 0                          // 0000001BFBF4: CC22005E 02002DCB
	s_waitcnt lgkmcnt(7)                                       // 0000001BFBFC: BF89FC77
	v_fma_mixlo_f16 v176, v176, s22, 0                         // 0000001BFC00: CC2100B0 02002DB0
	v_fma_mixhi_f16 v176, v177, s22, 0                         // 0000001BFC08: CC2200B0 02002DB1
	v_fma_mixlo_f16 v177, v178, s22, 0                         // 0000001BFC10: CC2100B1 02002DB2
	s_waitcnt lgkmcnt(6)                                       // 0000001BFC18: BF89FC67
	v_fma_mixlo_f16 v178, v180, s22, 0                         // 0000001BFC1C: CC2100B2 02002DB4
	s_waitcnt lgkmcnt(5)                                       // 0000001BFC24: BF89FC57
	v_fma_mixlo_f16 v180, v184, s22, 0                         // 0000001BFC28: CC2100B4 02002DB8
	v_fma_mixhi_f16 v180, v185, s22, 0                         // 0000001BFC30: CC2200B4 02002DB9
	ds_load_b128 v[200:203], v127 offset:144                   // 0000001BFC38: DBFC0090 C800007F
	v_fma_mixlo_f16 v95, v204, s22, 0                          // 0000001BFC40: CC21005F 02002DCC
	v_fma_mixhi_f16 v95, v205, s22, 0                          // 0000001BFC48: CC22005F 02002DCD
	v_fma_mixlo_f16 v96, v206, s22, 0                          // 0000001BFC50: CC210060 02002DCE
	v_fma_mixhi_f16 v96, v207, s22, 0                          // 0000001BFC58: CC220060 02002DCF
	v_fma_mixhi_f16 v177, v179, s22, 0                         // 0000001BFC60: CC2200B1 02002DB3
	v_fma_mixhi_f16 v178, v181, s22, 0                         // 0000001BFC68: CC2200B2 02002DB5
	v_fma_mixlo_f16 v179, v182, s22, 0                         // 0000001BFC70: CC2100B3 02002DB6
	v_fma_mixhi_f16 v179, v183, s22, 0                         // 0000001BFC78: CC2200B3 02002DB7
	s_waitcnt lgkmcnt(1)                                       // 0000001BFC80: BF89FC17
	v_fma_mixlo_f16 v184, v99, s22, 0                          // 0000001BFC84: CC2100B8 02002D63
	v_fma_mixhi_f16 v184, v100, s22, 0                         // 0000001BFC8C: CC2200B8 02002D64
	v_fma_mixlo_f16 v185, v101, s22, 0                         // 0000001BFC94: CC2100B9 02002D65
	v_fma_mixhi_f16 v185, v102, s22, 0                         // 0000001BFC9C: CC2200B9 02002D66
	ds_load_b128 v[99:102], v127 offset:8576                   // 0000001BFCA4: DBFC2180 6300007F
	v_fma_mixlo_f16 v181, v186, s22, 0                         // 0000001BFCAC: CC2100B5 02002DBA
	v_fma_mixhi_f16 v181, v187, s22, 0                         // 0000001BFCB4: CC2200B5 02002DBB
	v_fma_mixlo_f16 v182, v188, s22, 0                         // 0000001BFCBC: CC2100B6 02002DBC
	v_fma_mixhi_f16 v182, v189, s22, 0                         // 0000001BFCC4: CC2200B6 02002DBD
	v_fma_mixlo_f16 v183, v190, s22, 0                         // 0000001BFCCC: CC2100B7 02002DBE
	v_fma_mixhi_f16 v183, v191, s22, 0                         // 0000001BFCD4: CC2200B7 02002DBF
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001BFCDC: CC2100BA 02002DC0
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001BFCE4: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001BFCEC: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001BFCF4: CC2200BB 02002DC3
	v_fma_mixlo_f16 v188, v196, s22, 0                         // 0000001BFCFC: CC2100BC 02002DC4
	v_fma_mixhi_f16 v188, v197, s22, 0                         // 0000001BFD04: CC2200BC 02002DC5
	v_fma_mixlo_f16 v189, v198, s22, 0                         // 0000001BFD0C: CC2100BD 02002DC6
	v_fma_mixhi_f16 v189, v199, s22, 0                         // 0000001BFD14: CC2200BD 02002DC7
	s_waitcnt lgkmcnt(1)                                       // 0000001BFD1C: BF89FC17
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001BFD20: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001BFD28: CC2200BE 02002DC9
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001BFD30: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001BFD38: CC2200BF 02002DCB
	ds_load_b128 v[196:199], v127 offset:8592                  // 0000001BFD40: DBFC2190 C400007F
	ds_load_b128 v[200:203], v127 offset:8608                  // 0000001BFD48: DBFC21A0 C800007F
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001BFD50: CC404019 1C66B351
	ds_load_b128 v[89:92], v127 offset:8624                    // 0000001BFD58: DBFC21B0 5900007F
	v_wmma_f32_16x16x16_f16 v[33:40], v[81:88], v[172:179], v[33:40]// 0000001BFD60: CC404021 1C875951
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[180:187], v[9:16]// 0000001BFD68: CC404009 1C276951
	ds_load_b128 v[93:96], v127 offset:17024                   // 0000001BFD70: DBFC4280 5D00007F
	s_waitcnt lgkmcnt(4)                                       // 0000001BFD78: BF89FC47
	v_fma_mixlo_f16 v81, v99, s22, 0                           // 0000001BFD7C: CC210051 02002D63
	v_fma_mixhi_f16 v81, v100, s22, 0                          // 0000001BFD84: CC220051 02002D64
	v_fma_mixlo_f16 v82, v101, s22, 0                          // 0000001BFD8C: CC210052 02002D65
	v_fma_mixhi_f16 v82, v102, s22, 0                          // 0000001BFD94: CC220052 02002D66
	ds_load_b128 v[99:102], v127 offset:17040                  // 0000001BFD9C: DBFC4290 6300007F
	ds_load_b128 v[204:207], v127 offset:160                   // 0000001BFDA4: DBFC00A0 CC00007F
	ds_load_b128 v[172:175], v127 offset:17056                 // 0000001BFDAC: DBFC42A0 AC00007F
	ds_load_b128 v[176:179], v127 offset:17072                 // 0000001BFDB4: DBFC42B0 B000007F
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001BFDBC: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001BFDC4: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001BFDCC: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001BFDD4: CC2200C3 02002DD3
	ds_load_b128 v[180:183], v127 offset:25472                 // 0000001BFDDC: DBFC6380 B400007F
	ds_load_b128 v[184:187], v127 offset:25488                 // 0000001BFDE4: DBFC6390 B800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001BFDEC: BF89FC97
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001BFDF0: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001BFDF8: CC220053 02002DC5
	s_waitcnt lgkmcnt(7)                                       // 0000001BFE00: BF89FC77
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001BFE04: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001BFE0C: CC220058 02002D5C
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001BFE14: CC220057 02002D5A
	s_waitcnt lgkmcnt(6)                                       // 0000001BFE1C: BF89FC67
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001BFE20: CC21005A 02002D5F
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001BFE28: CC210054 02002DC6
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001BFE30: CC220054 02002DC7
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001BFE38: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001BFE40: CC220055 02002DC9
	s_waitcnt lgkmcnt(5)                                       // 0000001BFE48: BF89FC57
	v_fma_mixlo_f16 v91, v99, s22, 0                           // 0000001BFE4C: CC21005B 02002D63
	v_fma_mixhi_f16 v91, v100, s22, 0                          // 0000001BFE54: CC22005B 02002D64
	v_fma_mixlo_f16 v92, v101, s22, 0                          // 0000001BFE5C: CC21005C 02002D65
	v_fma_mixhi_f16 v92, v102, s22, 0                          // 0000001BFE64: CC22005C 02002D66
	ds_load_b128 v[99:102], v127 offset:25504                  // 0000001BFE6C: DBFC63A0 6300007F
	s_waitcnt lgkmcnt(5)                                       // 0000001BFE74: BF89FC57
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001BFE78: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001BFE80: CC2200C0 02002DCD
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001BFE88: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001BFE90: CC2200C1 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001BFE98: BF89FC37
	v_fma_mixlo_f16 v95, v176, s22, 0                          // 0000001BFE9C: CC21005F 02002DB0
	v_fma_mixhi_f16 v95, v177, s22, 0                          // 0000001BFEA4: CC22005F 02002DB1
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001BFEAC: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001BFEB4: CC220056 02002DCB
	s_waitcnt vmcnt(10)                                        // 0000001BFEBC: BF892BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[188:195], v[49:56]// 0000001BFEC0: CC404031 1CC77949
	ds_load_b128 v[188:191], v127 offset:25520                 // 0000001BFEC8: DBFC63B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:192                   // 0000001BFED0: DBFC00C0 C000007F
	ds_load_b128 v[196:199], v127 offset:208                   // 0000001BFED8: DBFC00D0 C400007F
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001BFEE0: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001BFEE8: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001BFEF0: CC220059 02002D5E
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001BFEF8: CC22005A 02002D60
	v_fma_mixlo_f16 v93, v172, s22, 0                          // 0000001BFF00: CC21005D 02002DAC
	v_fma_mixhi_f16 v93, v173, s22, 0                          // 0000001BFF08: CC22005D 02002DAD
	v_fma_mixlo_f16 v94, v174, s22, 0                          // 0000001BFF10: CC21005E 02002DAE
	s_waitcnt lgkmcnt(3)                                       // 0000001BFF18: BF89FC37
	v_fma_mixlo_f16 v176, v99, s22, 0                          // 0000001BFF1C: CC2100B0 02002D63
	v_fma_mixhi_f16 v176, v100, s22, 0                         // 0000001BFF24: CC2200B0 02002D64
	v_fma_mixlo_f16 v177, v101, s22, 0                         // 0000001BFF2C: CC2100B1 02002D65
	v_fma_mixhi_f16 v177, v102, s22, 0                         // 0000001BFF34: CC2200B1 02002D66
	ds_load_b128 v[99:102], v127 offset:8640                   // 0000001BFF3C: DBFC21C0 6300007F
	v_fma_mixhi_f16 v94, v175, s22, 0                          // 0000001BFF44: CC22005E 02002DAF
	v_fma_mixlo_f16 v96, v178, s22, 0                          // 0000001BFF4C: CC210060 02002DB2
	v_fma_mixhi_f16 v96, v179, s22, 0                          // 0000001BFF54: CC220060 02002DB3
	v_fma_mixlo_f16 v172, v180, s22, 0                         // 0000001BFF5C: CC2100AC 02002DB4
	v_fma_mixhi_f16 v172, v181, s22, 0                         // 0000001BFF64: CC2200AC 02002DB5
	v_fma_mixlo_f16 v173, v182, s22, 0                         // 0000001BFF6C: CC2100AD 02002DB6
	v_fma_mixhi_f16 v173, v183, s22, 0                         // 0000001BFF74: CC2200AD 02002DB7
	v_fma_mixlo_f16 v174, v184, s22, 0                         // 0000001BFF7C: CC2100AE 02002DB8
	v_fma_mixhi_f16 v174, v185, s22, 0                         // 0000001BFF84: CC2200AE 02002DB9
	v_fma_mixlo_f16 v175, v186, s22, 0                         // 0000001BFF8C: CC2100AF 02002DBA
	v_fma_mixhi_f16 v175, v187, s22, 0                         // 0000001BFF94: CC2200AF 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001BFF9C: BF89FC37
	v_fma_mixlo_f16 v178, v188, s22, 0                         // 0000001BFFA0: CC2100B2 02002DBC
	v_fma_mixhi_f16 v178, v189, s22, 0                         // 0000001BFFA8: CC2200B2 02002DBD
	v_fma_mixlo_f16 v179, v190, s22, 0                         // 0000001BFFB0: CC2100B3 02002DBE
	v_fma_mixhi_f16 v179, v191, s22, 0                         // 0000001BFFB8: CC2200B3 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001BFFC0: BF89FC27
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001BFFC4: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001BFFCC: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001BFFD4: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001BFFDC: CC2200B5 02002DC3
	ds_load_b128 v[188:191], v127 offset:8656                  // 0000001BFFE4: DBFC21D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:8672                  // 0000001BFFEC: DBFC21E0 C000007F
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001BFFF4: CC404019 1C66A349
	ds_load_b128 v[81:84], v127 offset:8688                    // 0000001BFFFC: DBFC21F0 5100007F
	v_wmma_f32_16x16x16_f16 v[33:40], v[73:80], v[89:96], v[33:40]// 0000001C0004: CC404021 1C86B349
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[172:179], v[9:16]// 0000001C000C: CC404009 1C275949
	ds_load_b128 v[85:88], v127 offset:17088                   // 0000001C0014: DBFC42C0 5500007F
	ds_load_b128 v[89:92], v127 offset:17104                   // 0000001C001C: DBFC42D0 5900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C0024: BF89FC57
	v_fma_mixlo_f16 v73, v99, s22, 0                           // 0000001C0028: CC210049 02002D63
	v_fma_mixhi_f16 v73, v100, s22, 0                          // 0000001C0030: CC220049 02002D64
	v_fma_mixlo_f16 v74, v101, s22, 0                          // 0000001C0038: CC21004A 02002D65
	v_fma_mixhi_f16 v74, v102, s22, 0                          // 0000001C0040: CC22004A 02002D66
	ds_load_b128 v[93:96], v127 offset:17120                   // 0000001C0048: DBFC42E0 5D00007F
	ds_load_b128 v[99:102], v127 offset:17136                  // 0000001C0050: DBFC42F0 6300007F
	ds_load_b128 v[200:203], v127 offset:224                   // 0000001C0058: DBFC00E0 C800007F
	ds_load_b128 v[204:207], v127 offset:240                   // 0000001C0060: DBFC00F0 CC00007F
	ds_load_b128 v[172:175], v127 offset:25536                 // 0000001C0068: DBFC63C0 AC00007F
	ds_load_b128 v[176:179], v127 offset:25552                 // 0000001C0070: DBFC63D0 B000007F
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001C0078: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001C0080: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001C0088: CC2100B7 02002DC6
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001C0090: CC2200B7 02002DC7
	s_waitcnt lgkmcnt(10)                                      // 0000001C0098: BF89FCA7
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001C009C: CC21004B 02002DBC
	s_waitcnt lgkmcnt(8)                                       // 0000001C00A4: BF89FC87
	v_fma_mixhi_f16 v79, v82, s22, 0                           // 0000001C00A8: CC22004F 02002D52
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001C00B0: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001C00B8: CC21004C 02002DBE
	s_waitcnt lgkmcnt(7)                                       // 0000001C00C0: BF89FC77
	v_fma_mixlo_f16 v82, v87, s22, 0                           // 0000001C00C4: CC210052 02002D57
	v_fma_mixhi_f16 v82, v88, s22, 0                           // 0000001C00CC: CC220052 02002D58
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001C00D4: CC22004C 02002DBF
	v_fma_mixlo_f16 v80, v83, s22, 0                           // 0000001C00DC: CC210050 02002D53
	s_waitcnt lgkmcnt(6)                                       // 0000001C00E4: BF89FC67
	v_fma_mixlo_f16 v83, v89, s22, 0                           // 0000001C00E8: CC210053 02002D59
	ds_load_b128 v[188:191], v127 offset:272                   // 0000001C00F0: DBFC0110 BC00007F
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001C00F8: CC21004D 02002DC0
	s_waitcnt lgkmcnt(5)                                       // 0000001C0100: BF89FC57
	v_fma_mixlo_f16 v87, v99, s22, 0                           // 0000001C0104: CC210057 02002D63
	v_fma_mixhi_f16 v87, v100, s22, 0                          // 0000001C010C: CC220057 02002D64
	v_fma_mixlo_f16 v88, v101, s22, 0                          // 0000001C0114: CC210058 02002D65
	v_fma_mixhi_f16 v88, v102, s22, 0                          // 0000001C011C: CC220058 02002D66
	ds_load_b128 v[99:102], v127 offset:256                    // 0000001C0124: DBFC0100 6300007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C012C: BF89FC57
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001C0130: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001C0138: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001C0140: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001C0148: CC2200B9 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001C0150: BF89FC47
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001C0154: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001C015C: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001C0164: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001C016C: CC2200BB 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001C0174: BF89FC37
	v_fma_mixlo_f16 v89, v172, s22, 0                          // 0000001C0178: CC210059 02002DAC
	v_fma_mixhi_f16 v89, v173, s22, 0                          // 0000001C0180: CC220059 02002DAD
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001C0188: CC22004D 02002DC1
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001C0190: CC21004E 02002DC2
	s_waitcnt vmcnt(8)                                         // 0000001C0198: BF8923F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[180:187], v[49:56]// 0000001C019C: CC404031 1CC76941
	ds_load_b128 v[180:183], v127 offset:25568                 // 0000001C01A4: DBFC63E0 B400007F
	ds_load_b128 v[184:187], v127 offset:25584                 // 0000001C01AC: DBFC63F0 B800007F
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001C01B4: CC22004E 02002DC3
	v_fma_mixlo_f16 v79, v81, s22, 0                           // 0000001C01BC: CC21004F 02002D51
	v_fma_mixhi_f16 v80, v84, s22, 0                           // 0000001C01C4: CC220050 02002D54
	v_fma_mixlo_f16 v81, v85, s22, 0                           // 0000001C01CC: CC210051 02002D55
	s_waitcnt lgkmcnt(2)                                       // 0000001C01D4: BF89FC27
	v_fma_mixlo_f16 v172, v99, s22, 0                          // 0000001C01D8: CC2100AC 02002D63
	v_fma_mixhi_f16 v172, v100, s22, 0                         // 0000001C01E0: CC2200AC 02002D64
	v_fma_mixlo_f16 v173, v101, s22, 0                         // 0000001C01E8: CC2100AD 02002D65
	v_fma_mixhi_f16 v173, v102, s22, 0                         // 0000001C01F0: CC2200AD 02002D66
	ds_load_b128 v[99:102], v127 offset:8704                   // 0000001C01F8: DBFC2200 6300007F
	v_fma_mixhi_f16 v81, v86, s22, 0                           // 0000001C0200: CC220051 02002D56
	v_fma_mixhi_f16 v83, v90, s22, 0                           // 0000001C0208: CC220053 02002D5A
	v_fma_mixlo_f16 v84, v91, s22, 0                           // 0000001C0210: CC210054 02002D5B
	v_fma_mixhi_f16 v84, v92, s22, 0                           // 0000001C0218: CC220054 02002D5C
	v_fma_mixlo_f16 v85, v93, s22, 0                           // 0000001C0220: CC210055 02002D5D
	v_fma_mixhi_f16 v85, v94, s22, 0                           // 0000001C0228: CC220055 02002D5E
	v_fma_mixlo_f16 v86, v95, s22, 0                           // 0000001C0230: CC210056 02002D5F
	v_fma_mixhi_f16 v86, v96, s22, 0                           // 0000001C0238: CC220056 02002D60
	v_fma_mixlo_f16 v90, v174, s22, 0                          // 0000001C0240: CC21005A 02002DAE
	v_fma_mixhi_f16 v90, v175, s22, 0                          // 0000001C0248: CC22005A 02002DAF
	v_fma_mixlo_f16 v91, v176, s22, 0                          // 0000001C0250: CC21005B 02002DB0
	v_fma_mixhi_f16 v91, v177, s22, 0                          // 0000001C0258: CC22005B 02002DB1
	v_fma_mixlo_f16 v92, v178, s22, 0                          // 0000001C0260: CC21005C 02002DB2
	ds_load_b128 v[192:195], v127 offset:288                   // 0000001C0268: DBFC0120 C000007F
	v_fma_mixhi_f16 v92, v179, s22, 0                          // 0000001C0270: CC22005C 02002DB3
	s_waitcnt lgkmcnt(3)                                       // 0000001C0278: BF89FC37
	v_fma_mixlo_f16 v93, v180, s22, 0                          // 0000001C027C: CC21005D 02002DB4
	v_fma_mixhi_f16 v93, v181, s22, 0                          // 0000001C0284: CC22005D 02002DB5
	v_fma_mixlo_f16 v94, v182, s22, 0                          // 0000001C028C: CC21005E 02002DB6
	ds_load_b128 v[178:181], v127 offset:304                   // 0000001C0294: DBFC0130 B200007F
	v_fma_mixhi_f16 v94, v183, s22, 0                          // 0000001C029C: CC22005E 02002DB7
	s_waitcnt lgkmcnt(3)                                       // 0000001C02A4: BF89FC37
	v_fma_mixlo_f16 v95, v184, s22, 0                          // 0000001C02A8: CC21005F 02002DB8
	v_fma_mixhi_f16 v95, v185, s22, 0                          // 0000001C02B0: CC22005F 02002DB9
	v_fma_mixlo_f16 v96, v186, s22, 0                          // 0000001C02B8: CC210060 02002DBA
	v_fma_mixhi_f16 v96, v187, s22, 0                          // 0000001C02C0: CC220060 02002DBB
	v_fma_mixlo_f16 v174, v188, s22, 0                         // 0000001C02C8: CC2100AE 02002DBC
	v_fma_mixhi_f16 v174, v189, s22, 0                         // 0000001C02D0: CC2200AE 02002DBD
	ds_load_b128 v[182:185], v127 offset:8720                  // 0000001C02D8: DBFC2210 B600007F
	ds_load_b128 v[186:189], v127 offset:8736                  // 0000001C02E0: DBFC2220 BA00007F
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[73:80], v[25:32]// 0000001C02E8: CC404019 1C669341
	ds_load_b128 v[73:76], v127 offset:8752                    // 0000001C02F0: DBFC2230 4900007F
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[81:88], v[33:40]// 0000001C02F8: CC404021 1C86A341
	v_wmma_f32_16x16x16_f16 v[9:16], v[65:72], v[89:96], v[9:16]// 0000001C0300: CC404009 1C26B341
	ds_load_b128 v[77:80], v127 offset:17152                   // 0000001C0308: DBFC4300 4D00007F
	ds_load_b128 v[81:84], v127 offset:17168                   // 0000001C0310: DBFC4310 5100007F
	s_waitcnt lgkmcnt(7)                                       // 0000001C0318: BF89FC77
	v_fma_mixlo_f16 v65, v99, s22, 0                           // 0000001C031C: CC210041 02002D63
	v_fma_mixhi_f16 v65, v100, s22, 0                          // 0000001C0324: CC220041 02002D64
	v_fma_mixlo_f16 v66, v101, s22, 0                          // 0000001C032C: CC210042 02002D65
	v_fma_mixhi_f16 v66, v102, s22, 0                          // 0000001C0334: CC220042 02002D66
	ds_load_b128 v[85:88], v127 offset:17184                   // 0000001C033C: DBFC4320 5500007F
	ds_load_b128 v[89:92], v127 offset:17200                   // 0000001C0344: DBFC4330 5900007F
	ds_load_b128 v[93:96], v127 offset:25600                   // 0000001C034C: DBFC6400 5D00007F
	ds_load_b128 v[99:102], v127 offset:25616                  // 0000001C0354: DBFC6410 6300007F
	v_fma_mixlo_f16 v175, v190, s22, 0                         // 0000001C035C: CC2100AF 02002DBE
	v_fma_mixhi_f16 v175, v191, s22, 0                         // 0000001C0364: CC2200AF 02002DBF
	s_waitcnt lgkmcnt(10)                                      // 0000001C036C: BF89FCA7
	v_fma_mixlo_f16 v176, v192, s22, 0                         // 0000001C0370: CC2100B0 02002DC0
	v_fma_mixhi_f16 v176, v193, s22, 0                         // 0000001C0378: CC2200B0 02002DC1
	v_fma_mixlo_f16 v177, v194, s22, 0                         // 0000001C0380: CC2100B1 02002DC2
	v_fma_mixhi_f16 v177, v195, s22, 0                         // 0000001C0388: CC2200B1 02002DC3
	s_waitcnt lgkmcnt(9)                                       // 0000001C0390: BF89FC97
	v_fma_mixlo_f16 v178, v178, s22, 0                         // 0000001C0394: CC2100B2 02002DB2
	v_fma_mixhi_f16 v178, v179, s22, 0                         // 0000001C039C: CC2200B2 02002DB3
	v_fma_mixlo_f16 v179, v180, s22, 0                         // 0000001C03A4: CC2100B3 02002DB4
	v_fma_mixhi_f16 v179, v181, s22, 0                         // 0000001C03AC: CC2200B3 02002DB5
	s_waitcnt lgkmcnt(8)                                       // 0000001C03B4: BF89FC87
	v_fma_mixlo_f16 v67, v182, s22, 0                          // 0000001C03B8: CC210043 02002DB6
	v_fma_mixhi_f16 v67, v183, s22, 0                          // 0000001C03C0: CC220043 02002DB7
	s_waitcnt lgkmcnt(6)                                       // 0000001C03C8: BF89FC67
	v_fma_mixhi_f16 v71, v74, s22, 0                           // 0000001C03CC: CC220047 02002D4A
	v_fma_mixlo_f16 v72, v75, s22, 0                           // 0000001C03D4: CC210048 02002D4B
	s_waitcnt vmcnt(6)                                         // 0000001C03DC: BF891BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[172:179], v[49:56]// 0000001C03E0: CC404031 1CC75939
	v_fma_mixhi_f16 v72, v76, s22, 0                           // 0000001C03E8: CC220048 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001C03F0: BF89FC57
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001C03F4: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001C03FC: CC22004A 02002D50
	s_waitcnt lgkmcnt(4)                                       // 0000001C0404: BF89FC47
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001C0408: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001C0410: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001C0418: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001C0420: CC22004C 02002D54
	ds_load_b128 v[172:175], v127 offset:25632                 // 0000001C0428: DBFC6420 AC00007F
	ds_load_b128 v[176:179], v127 offset:25648                 // 0000001C0430: DBFC6430 B000007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C0438: BF89FC47
	v_fma_mixlo_f16 v79, v89, s22, 0                           // 0000001C043C: CC21004F 02002D59
	v_fma_mixhi_f16 v79, v90, s22, 0                           // 0000001C0444: CC22004F 02002D5A
	v_fma_mixlo_f16 v80, v91, s22, 0                           // 0000001C044C: CC210050 02002D5B
	v_fma_mixhi_f16 v80, v92, s22, 0                           // 0000001C0454: CC220050 02002D5C
	ds_load_b128 v[89:92], v127 offset:320                     // 0000001C045C: DBFC0140 5900007F
	ds_load_b128 v[180:183], v127 offset:336                   // 0000001C0464: DBFC0150 B400007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C046C: BF89FC57
	v_fma_mixlo_f16 v81, v93, s22, 0                           // 0000001C0470: CC210051 02002D5D
	v_fma_mixhi_f16 v81, v94, s22, 0                           // 0000001C0478: CC220051 02002D5E
	v_fma_mixlo_f16 v82, v95, s22, 0                           // 0000001C0480: CC210052 02002D5F
	v_fma_mixhi_f16 v82, v96, s22, 0                           // 0000001C0488: CC220052 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001C0490: BF89FC47
	v_fma_mixlo_f16 v83, v99, s22, 0                           // 0000001C0494: CC210053 02002D63
	v_fma_mixhi_f16 v83, v100, s22, 0                          // 0000001C049C: CC220053 02002D64
	v_fma_mixlo_f16 v84, v101, s22, 0                          // 0000001C04A4: CC210054 02002D65
	ds_load_b128 v[93:96], v127 offset:352                     // 0000001C04AC: DBFC0160 5D00007F
	v_fma_mixhi_f16 v84, v102, s22, 0                          // 0000001C04B4: CC220054 02002D66
	ds_load_b128 v[99:102], v127 offset:368                    // 0000001C04BC: DBFC0170 6300007F
	v_fma_mixlo_f16 v68, v184, s22, 0                          // 0000001C04C4: CC210044 02002DB8
	v_fma_mixhi_f16 v68, v185, s22, 0                          // 0000001C04CC: CC220044 02002DB9
	v_fma_mixlo_f16 v69, v186, s22, 0                          // 0000001C04D4: CC210045 02002DBA
	v_fma_mixhi_f16 v69, v187, s22, 0                          // 0000001C04DC: CC220045 02002DBB
	v_fma_mixlo_f16 v70, v188, s22, 0                          // 0000001C04E4: CC210046 02002DBC
	v_fma_mixhi_f16 v70, v189, s22, 0                          // 0000001C04EC: CC220046 02002DBD
	v_fma_mixlo_f16 v71, v73, s22, 0                           // 0000001C04F4: CC210047 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001C04FC: CC210049 02002D4D
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001C0504: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001C050C: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001C0514: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001C051C: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001C0524: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001C052C: BF89FC57
	v_fma_mixlo_f16 v85, v172, s22, 0                          // 0000001C0530: CC210055 02002DAC
	v_fma_mixhi_f16 v85, v173, s22, 0                          // 0000001C0538: CC220055 02002DAD
	v_fma_mixlo_f16 v86, v174, s22, 0                          // 0000001C0540: CC210056 02002DAE
	v_fma_mixhi_f16 v86, v175, s22, 0                          // 0000001C0548: CC220056 02002DAF
	s_waitcnt lgkmcnt(4)                                       // 0000001C0550: BF89FC47
	v_fma_mixlo_f16 v87, v176, s22, 0                          // 0000001C0554: CC210057 02002DB0
	v_fma_mixhi_f16 v87, v177, s22, 0                          // 0000001C055C: CC220057 02002DB1
	v_fma_mixlo_f16 v88, v178, s22, 0                          // 0000001C0564: CC210058 02002DB2
	v_fma_mixhi_f16 v88, v179, s22, 0                          // 0000001C056C: CC220058 02002DB3
	s_waitcnt lgkmcnt(3)                                       // 0000001C0574: BF89FC37
	v_fma_mixlo_f16 v89, v89, s22, 0                           // 0000001C0578: CC210059 02002D59
	v_fma_mixhi_f16 v89, v90, s22, 0                           // 0000001C0580: CC220059 02002D5A
	v_fma_mixlo_f16 v90, v91, s22, 0                           // 0000001C0588: CC21005A 02002D5B
	v_fma_mixhi_f16 v90, v92, s22, 0                           // 0000001C0590: CC22005A 02002D5C
	s_waitcnt lgkmcnt(2)                                       // 0000001C0598: BF89FC27
	v_fma_mixlo_f16 v91, v180, s22, 0                          // 0000001C059C: CC21005B 02002DB4
	v_fma_mixhi_f16 v91, v181, s22, 0                          // 0000001C05A4: CC22005B 02002DB5
	v_fma_mixlo_f16 v92, v182, s22, 0                          // 0000001C05AC: CC21005C 02002DB6
	v_fma_mixhi_f16 v92, v183, s22, 0                          // 0000001C05B4: CC22005C 02002DB7
	s_waitcnt lgkmcnt(1)                                       // 0000001C05BC: BF89FC17
	v_fma_mixlo_f16 v93, v93, s22, 0                           // 0000001C05C0: CC21005D 02002D5D
	v_fma_mixhi_f16 v93, v94, s22, 0                           // 0000001C05C8: CC22005D 02002D5E
	v_fma_mixlo_f16 v94, v95, s22, 0                           // 0000001C05D0: CC21005E 02002D5F
	v_fma_mixhi_f16 v94, v96, s22, 0                           // 0000001C05D8: CC22005E 02002D60
	s_waitcnt lgkmcnt(0)                                       // 0000001C05E0: BF89FC07
	v_fma_mixlo_f16 v95, v99, s22, 0                           // 0000001C05E4: CC21005F 02002D63
	v_fma_mixhi_f16 v95, v100, s22, 0                          // 0000001C05EC: CC22005F 02002D64
	v_fma_mixlo_f16 v96, v101, s22, 0                          // 0000001C05F4: CC210060 02002D65
	v_fma_mixhi_f16 v96, v102, s22, 0                          // 0000001C05FC: CC220060 02002D66
	ds_load_b128 v[172:175], v127 offset:8768                  // 0000001C0604: DBFC2240 AC00007F
	ds_load_b128 v[176:179], v127 offset:8784                  // 0000001C060C: DBFC2250 B000007F
	ds_load_b128 v[180:183], v127 offset:8800                  // 0000001C0614: DBFC2260 B400007F
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[65:72], v[25:32]// 0000001C061C: CC404019 1C668339
	ds_load_b128 v[65:68], v127 offset:8816                    // 0000001C0624: DBFC2270 4100007F
	v_wmma_f32_16x16x16_f16 v[33:40], v[57:64], v[73:80], v[33:40]// 0000001C062C: CC404021 1C869339
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001C0634: CC404009 1C26A339
	s_waitcnt vmcnt(4)                                         // 0000001C063C: BF8913F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[41:48], v[89:96], v[49:56]// 0000001C0640: CC404031 1CC6B329
	ds_load_b128 v[69:72], v127 offset:17216                   // 0000001C0648: DBFC4340 4500007F
	ds_load_b128 v[73:76], v127 offset:17232                   // 0000001C0650: DBFC4350 4900007F
	ds_load_b128 v[77:80], v127 offset:17248                   // 0000001C0658: DBFC4360 4D00007F
	ds_load_b128 v[81:84], v127 offset:17264                   // 0000001C0660: DBFC4370 5100007F
	ds_load_b128 v[85:88], v127 offset:25664                   // 0000001C0668: DBFC6440 5500007F
	ds_load_b128 v[89:92], v127 offset:25680                   // 0000001C0670: DBFC6450 5900007F
	ds_load_b128 v[93:96], v127 offset:25696                   // 0000001C0678: DBFC6460 5D00007F
	ds_load_b128 v[99:102], v127 offset:25712                  // 0000001C0680: DBFC6470 6300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001C0688: BF89FCB7
	v_fma_mixlo_f16 v57, v172, s22, 0                          // 0000001C068C: CC210039 02002DAC
	v_fma_mixhi_f16 v57, v173, s22, 0                          // 0000001C0694: CC220039 02002DAD
	v_fma_mixlo_f16 v58, v174, s22, 0                          // 0000001C069C: CC21003A 02002DAE
	v_fma_mixhi_f16 v58, v175, s22, 0                          // 0000001C06A4: CC22003A 02002DAF
	s_waitcnt lgkmcnt(8)                                       // 0000001C06AC: BF89FC87
	v_fma_mixhi_f16 v63, v66, s22, 0                           // 0000001C06B0: CC22003F 02002D42
	v_fma_mixlo_f16 v64, v67, s22, 0                           // 0000001C06B8: CC210040 02002D43
	v_fma_mixhi_f16 v64, v68, s22, 0                           // 0000001C06C0: CC220040 02002D44
	ds_load_b128 v[172:175], v127 offset:400                   // 0000001C06C8: DBFC0190 AC00007F
	s_waitcnt lgkmcnt(8)                                       // 0000001C06D0: BF89FC87
	v_fma_mixlo_f16 v66, v71, s22, 0                           // 0000001C06D4: CC210042 02002D47
	v_fma_mixhi_f16 v66, v72, s22, 0                           // 0000001C06DC: CC220042 02002D48
	s_waitcnt lgkmcnt(7)                                       // 0000001C06E4: BF89FC77
	v_fma_mixlo_f16 v67, v73, s22, 0                           // 0000001C06E8: CC210043 02002D49
	v_fma_mixhi_f16 v67, v74, s22, 0                           // 0000001C06F0: CC220043 02002D4A
	v_fma_mixlo_f16 v68, v75, s22, 0                           // 0000001C06F8: CC210044 02002D4B
	v_fma_mixhi_f16 v68, v76, s22, 0                           // 0000001C0700: CC220044 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001C0708: BF89FC57
	v_fma_mixlo_f16 v71, v81, s22, 0                           // 0000001C070C: CC210047 02002D51
	v_fma_mixhi_f16 v71, v82, s22, 0                           // 0000001C0714: CC220047 02002D52
	v_fma_mixlo_f16 v72, v83, s22, 0                           // 0000001C071C: CC210048 02002D53
	v_fma_mixhi_f16 v72, v84, s22, 0                           // 0000001C0724: CC220048 02002D54
	ds_load_b128 v[81:84], v127 offset:384                     // 0000001C072C: DBFC0180 5100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C0734: BF89FC57
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001C0738: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001C0740: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001C0748: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001C0750: CC22004A 02002D58
	s_waitcnt lgkmcnt(4)                                       // 0000001C0758: BF89FC47
	v_fma_mixlo_f16 v75, v89, s22, 0                           // 0000001C075C: CC21004B 02002D59
	v_fma_mixhi_f16 v75, v90, s22, 0                           // 0000001C0764: CC22004B 02002D5A
	v_fma_mixlo_f16 v76, v91, s22, 0                           // 0000001C076C: CC21004C 02002D5B
	ds_load_b128 v[85:88], v127 offset:416                     // 0000001C0774: DBFC01A0 5500007F
	v_fma_mixhi_f16 v76, v92, s22, 0                           // 0000001C077C: CC22004C 02002D5C
	ds_load_b128 v[89:92], v127 offset:432                     // 0000001C0784: DBFC01B0 5900007F
	v_fma_mixlo_f16 v59, v176, s22, 0                          // 0000001C078C: CC21003B 02002DB0
	v_fma_mixhi_f16 v59, v177, s22, 0                          // 0000001C0794: CC22003B 02002DB1
	v_fma_mixlo_f16 v60, v178, s22, 0                          // 0000001C079C: CC21003C 02002DB2
	v_fma_mixhi_f16 v60, v179, s22, 0                          // 0000001C07A4: CC22003C 02002DB3
	v_fma_mixlo_f16 v61, v180, s22, 0                          // 0000001C07AC: CC21003D 02002DB4
	v_fma_mixhi_f16 v61, v181, s22, 0                          // 0000001C07B4: CC22003D 02002DB5
	v_fma_mixlo_f16 v62, v182, s22, 0                          // 0000001C07BC: CC21003E 02002DB6
	v_fma_mixhi_f16 v62, v183, s22, 0                          // 0000001C07C4: CC22003E 02002DB7
	v_fma_mixlo_f16 v63, v65, s22, 0                           // 0000001C07CC: CC21003F 02002D41
	v_fma_mixlo_f16 v65, v69, s22, 0                           // 0000001C07D4: CC210041 02002D45
	v_fma_mixhi_f16 v65, v70, s22, 0                           // 0000001C07DC: CC220041 02002D46
	v_fma_mixlo_f16 v69, v77, s22, 0                           // 0000001C07E4: CC210045 02002D4D
	v_fma_mixhi_f16 v69, v78, s22, 0                           // 0000001C07EC: CC220045 02002D4E
	v_fma_mixlo_f16 v70, v79, s22, 0                           // 0000001C07F4: CC210046 02002D4F
	v_fma_mixhi_f16 v70, v80, s22, 0                           // 0000001C07FC: CC220046 02002D50
	s_waitcnt lgkmcnt(5)                                       // 0000001C0804: BF89FC57
	v_fma_mixlo_f16 v77, v93, s22, 0                           // 0000001C0808: CC21004D 02002D5D
	v_fma_mixhi_f16 v77, v94, s22, 0                           // 0000001C0810: CC22004D 02002D5E
	v_fma_mixlo_f16 v78, v95, s22, 0                           // 0000001C0818: CC21004E 02002D5F
	v_fma_mixhi_f16 v78, v96, s22, 0                           // 0000001C0820: CC22004E 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001C0828: BF89FC47
	v_fma_mixlo_f16 v79, v99, s22, 0                           // 0000001C082C: CC21004F 02002D63
	v_fma_mixhi_f16 v79, v100, s22, 0                          // 0000001C0834: CC22004F 02002D64
	v_fma_mixlo_f16 v80, v101, s22, 0                          // 0000001C083C: CC210050 02002D65
	v_fma_mixhi_f16 v80, v102, s22, 0                          // 0000001C0844: CC220050 02002D66
	s_waitcnt lgkmcnt(2)                                       // 0000001C084C: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001C0850: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001C0858: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001C0860: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001C0868: CC220052 02002D54
	v_fma_mixlo_f16 v83, v172, s22, 0                          // 0000001C0870: CC210053 02002DAC
	v_fma_mixhi_f16 v83, v173, s22, 0                          // 0000001C0878: CC220053 02002DAD
	v_fma_mixlo_f16 v84, v174, s22, 0                          // 0000001C0880: CC210054 02002DAE
	v_fma_mixhi_f16 v84, v175, s22, 0                          // 0000001C0888: CC220054 02002DAF
	s_waitcnt lgkmcnt(1)                                       // 0000001C0890: BF89FC17
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001C0894: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001C089C: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001C08A4: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001C08AC: CC220056 02002D58
	s_waitcnt lgkmcnt(0)                                       // 0000001C08B4: BF89FC07
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001C08B8: CC210057 02002D59
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001C08C0: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001C08C8: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001C08D0: CC220058 02002D5C
	ds_load_b128 v[93:96], v127 offset:8832                    // 0000001C08D8: DBFC2280 5D00007F
	ds_load_b128 v[99:102], v127 offset:8848                   // 0000001C08E0: DBFC2290 6300007F
	ds_load_b128 v[172:175], v127 offset:8864                  // 0000001C08E8: DBFC22A0 AC00007F
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 0000001C08F0: CC404019 1C667329
	ds_load_b128 v[57:60], v127 offset:8880                    // 0000001C08F8: DBFC22B0 3900007F
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[65:72], v[33:40]// 0000001C0900: CC404021 1C868329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[73:80], v[9:16]// 0000001C0908: CC404009 1C269329
	s_waitcnt vmcnt(2)                                         // 0000001C0910: BF890BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[17:24], v[81:88], v[49:56]// 0000001C0914: CC404031 1CC6A311
	ds_load_b128 v[61:64], v127 offset:17280                   // 0000001C091C: DBFC4380 3D00007F
	ds_load_b128 v[65:68], v127 offset:17296                   // 0000001C0924: DBFC4390 4100007F
	ds_load_b128 v[69:72], v127 offset:17312                   // 0000001C092C: DBFC43A0 4500007F
	ds_load_b128 v[73:76], v127 offset:17328                   // 0000001C0934: DBFC43B0 4900007F
	ds_load_b128 v[77:80], v127 offset:25728                   // 0000001C093C: DBFC6480 4D00007F
	ds_load_b128 v[81:84], v127 offset:25744                   // 0000001C0944: DBFC6490 5100007F
	ds_load_b128 v[85:88], v127 offset:25760                   // 0000001C094C: DBFC64A0 5500007F
	ds_load_b128 v[89:92], v127 offset:25776                   // 0000001C0954: DBFC64B0 5900007F
	s_waitcnt lgkmcnt(11)                                      // 0000001C095C: BF89FCB7
	v_fma_mixlo_f16 v41, v93, s22, 0                           // 0000001C0960: CC210029 02002D5D
	v_fma_mixhi_f16 v41, v94, s22, 0                           // 0000001C0968: CC220029 02002D5E
	v_fma_mixlo_f16 v42, v95, s22, 0                           // 0000001C0970: CC21002A 02002D5F
	v_fma_mixhi_f16 v42, v96, s22, 0                           // 0000001C0978: CC22002A 02002D60
	s_waitcnt lgkmcnt(10)                                      // 0000001C0980: BF89FCA7
	v_fma_mixlo_f16 v43, v99, s22, 0                           // 0000001C0984: CC21002B 02002D63
	v_fma_mixhi_f16 v43, v100, s22, 0                          // 0000001C098C: CC22002B 02002D64
	v_fma_mixlo_f16 v44, v101, s22, 0                          // 0000001C0994: CC21002C 02002D65
	v_fma_mixhi_f16 v44, v102, s22, 0                          // 0000001C099C: CC22002C 02002D66
	s_waitcnt lgkmcnt(9)                                       // 0000001C09A4: BF89FC97
	v_fma_mixlo_f16 v45, v172, s22, 0                          // 0000001C09A8: CC21002D 02002DAC
	v_fma_mixhi_f16 v45, v173, s22, 0                          // 0000001C09B0: CC22002D 02002DAD
	v_fma_mixlo_f16 v46, v174, s22, 0                          // 0000001C09B8: CC21002E 02002DAE
	v_fma_mixhi_f16 v46, v175, s22, 0                          // 0000001C09C0: CC22002E 02002DAF
	s_waitcnt lgkmcnt(8)                                       // 0000001C09C8: BF89FC87
	v_fma_mixlo_f16 v47, v57, s22, 0                           // 0000001C09CC: CC21002F 02002D39
	v_fma_mixhi_f16 v47, v58, s22, 0                           // 0000001C09D4: CC22002F 02002D3A
	v_fma_mixlo_f16 v48, v59, s22, 0                           // 0000001C09DC: CC210030 02002D3B
	v_fma_mixhi_f16 v48, v60, s22, 0                           // 0000001C09E4: CC220030 02002D3C
	s_waitcnt lgkmcnt(7)                                       // 0000001C09EC: BF89FC77
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001C09F0: CC210039 02002D3D
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001C09F8: CC220039 02002D3E
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001C0A00: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001C0A08: CC22003A 02002D40
	s_waitcnt lgkmcnt(6)                                       // 0000001C0A10: BF89FC67
	v_fma_mixlo_f16 v59, v65, s22, 0                           // 0000001C0A14: CC21003B 02002D41
	v_fma_mixhi_f16 v59, v66, s22, 0                           // 0000001C0A1C: CC22003B 02002D42
	v_fma_mixlo_f16 v60, v67, s22, 0                           // 0000001C0A24: CC21003C 02002D43
	v_fma_mixhi_f16 v60, v68, s22, 0                           // 0000001C0A2C: CC22003C 02002D44
	s_waitcnt lgkmcnt(5)                                       // 0000001C0A34: BF89FC57
	v_fma_mixlo_f16 v61, v69, s22, 0                           // 0000001C0A38: CC21003D 02002D45
	v_fma_mixhi_f16 v61, v70, s22, 0                           // 0000001C0A40: CC22003D 02002D46
	v_fma_mixlo_f16 v62, v71, s22, 0                           // 0000001C0A48: CC21003E 02002D47
	v_fma_mixhi_f16 v62, v72, s22, 0                           // 0000001C0A50: CC22003E 02002D48
	s_waitcnt lgkmcnt(4)                                       // 0000001C0A58: BF89FC47
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001C0A5C: CC21003F 02002D49
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001C0A64: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001C0A6C: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001C0A74: CC220040 02002D4C
	ds_load_b128 v[73:76], v127 offset:448                     // 0000001C0A7C: DBFC01C0 4900007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C0A84: BF89FC47
	v_fma_mixlo_f16 v65, v77, s22, 0                           // 0000001C0A88: CC210041 02002D4D
	v_fma_mixhi_f16 v65, v78, s22, 0                           // 0000001C0A90: CC220041 02002D4E
	v_fma_mixlo_f16 v66, v79, s22, 0                           // 0000001C0A98: CC210042 02002D4F
	v_fma_mixhi_f16 v66, v80, s22, 0                           // 0000001C0AA0: CC220042 02002D50
	ds_load_b128 v[77:80], v127 offset:464                     // 0000001C0AA8: DBFC01D0 4D00007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C0AB0: BF89FC47
	v_fma_mixlo_f16 v67, v81, s22, 0                           // 0000001C0AB4: CC210043 02002D51
	v_fma_mixhi_f16 v67, v82, s22, 0                           // 0000001C0ABC: CC220043 02002D52
	v_fma_mixlo_f16 v68, v83, s22, 0                           // 0000001C0AC4: CC210044 02002D53
	v_fma_mixhi_f16 v68, v84, s22, 0                           // 0000001C0ACC: CC220044 02002D54
	ds_load_b128 v[81:84], v127 offset:480                     // 0000001C0AD4: DBFC01E0 5100007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C0ADC: BF89FC47
	v_fma_mixlo_f16 v69, v85, s22, 0                           // 0000001C0AE0: CC210045 02002D55
	v_fma_mixhi_f16 v69, v86, s22, 0                           // 0000001C0AE8: CC220045 02002D56
	v_fma_mixlo_f16 v70, v87, s22, 0                           // 0000001C0AF0: CC210046 02002D57
	v_fma_mixhi_f16 v70, v88, s22, 0                           // 0000001C0AF8: CC220046 02002D58
	ds_load_b128 v[85:88], v127 offset:496                     // 0000001C0B00: DBFC01F0 5500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C0B08: BF89FC47
	v_fma_mixlo_f16 v71, v89, s22, 0                           // 0000001C0B0C: CC210047 02002D59
	v_fma_mixhi_f16 v71, v90, s22, 0                           // 0000001C0B14: CC220047 02002D5A
	v_fma_mixlo_f16 v72, v91, s22, 0                           // 0000001C0B1C: CC210048 02002D5B
	v_fma_mixhi_f16 v72, v92, s22, 0                           // 0000001C0B24: CC220048 02002D5C
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[41:48], v[25:32]// 0000001C0B2C: CC404019 1C665311
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[57:64], v[33:40]// 0000001C0B34: CC404021 1C867311
	s_waitcnt lgkmcnt(3)                                       // 0000001C0B3C: BF89FC37
	v_fma_mixlo_f16 v73, v73, s22, 0                           // 0000001C0B40: CC210049 02002D49
	v_fma_mixhi_f16 v73, v74, s22, 0                           // 0000001C0B48: CC220049 02002D4A
	v_wmma_f32_16x16x16_f16 v[9:16], v[17:24], v[65:72], v[9:16]// 0000001C0B50: CC404009 1C268311
	ds_load_b128 v[17:20], v127 offset:17344                   // 0000001C0B58: DBFC43C0 1100007F
	ds_load_b128 v[21:24], v127 offset:17360                   // 0000001C0B60: DBFC43D0 1500007F
	v_fma_mixlo_f16 v74, v75, s22, 0                           // 0000001C0B68: CC21004A 02002D4B
	v_fma_mixhi_f16 v74, v76, s22, 0                           // 0000001C0B70: CC22004A 02002D4C
	s_waitcnt lgkmcnt(4)                                       // 0000001C0B78: BF89FC47
	v_fma_mixlo_f16 v75, v77, s22, 0                           // 0000001C0B7C: CC21004B 02002D4D
	v_fma_mixhi_f16 v75, v78, s22, 0                           // 0000001C0B84: CC22004B 02002D4E
	v_fma_mixlo_f16 v76, v79, s22, 0                           // 0000001C0B8C: CC21004C 02002D4F
	v_fma_mixhi_f16 v76, v80, s22, 0                           // 0000001C0B94: CC22004C 02002D50
	s_waitcnt lgkmcnt(3)                                       // 0000001C0B9C: BF89FC37
	v_fma_mixlo_f16 v77, v81, s22, 0                           // 0000001C0BA0: CC21004D 02002D51
	v_fma_mixhi_f16 v77, v82, s22, 0                           // 0000001C0BA8: CC22004D 02002D52
	v_fma_mixlo_f16 v78, v83, s22, 0                           // 0000001C0BB0: CC21004E 02002D53
	v_fma_mixhi_f16 v78, v84, s22, 0                           // 0000001C0BB8: CC22004E 02002D54
	s_waitcnt lgkmcnt(2)                                       // 0000001C0BC0: BF89FC27
	v_fma_mixlo_f16 v79, v85, s22, 0                           // 0000001C0BC4: CC21004F 02002D55
	v_fma_mixhi_f16 v79, v86, s22, 0                           // 0000001C0BCC: CC22004F 02002D56
	v_fma_mixlo_f16 v80, v87, s22, 0                           // 0000001C0BD4: CC210050 02002D57
	v_fma_mixhi_f16 v80, v88, s22, 0                           // 0000001C0BDC: CC220050 02002D58
	ds_load_b128 v[89:92], v127 offset:8896                    // 0000001C0BE4: DBFC22C0 5900007F
	ds_load_b128 v[93:96], v127 offset:8912                    // 0000001C0BEC: DBFC22D0 5D00007F
	ds_load_b128 v[81:84], v127 offset:8928                    // 0000001C0BF4: DBFC22E0 5100007F
	ds_load_b128 v[85:88], v127 offset:8944                    // 0000001C0BFC: DBFC22F0 5500007F
	s_waitcnt vmcnt(0)                                         // 0000001C0C04: BF8903F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[73:80], v[49:56]// 0000001C0C08: CC404031 1CC69301
	ds_load_b128 v[61:64], v127 offset:17376                   // 0000001C0C10: DBFC43E0 3D00007F
	ds_load_b128 v[65:68], v127 offset:17392                   // 0000001C0C18: DBFC43F0 4100007F
	ds_load_b128 v[69:72], v127 offset:25792                   // 0000001C0C20: DBFC64C0 4500007F
	ds_load_b128 v[73:76], v127 offset:25808                   // 0000001C0C28: DBFC64D0 4900007F
	s_waitcnt lgkmcnt(9)                                       // 0000001C0C30: BF89FC97
	v_fma_mixlo_f16 v57, v17, s22, 0                           // 0000001C0C34: CC210039 02002D11
	v_fma_mixhi_f16 v57, v18, s22, 0                           // 0000001C0C3C: CC220039 02002D12
	v_fma_mixlo_f16 v58, v19, s22, 0                           // 0000001C0C44: CC21003A 02002D13
	v_fma_mixhi_f16 v58, v20, s22, 0                           // 0000001C0C4C: CC22003A 02002D14
	s_waitcnt lgkmcnt(8)                                       // 0000001C0C54: BF89FC87
	v_fma_mixlo_f16 v59, v21, s22, 0                           // 0000001C0C58: CC21003B 02002D15
	v_fma_mixhi_f16 v59, v22, s22, 0                           // 0000001C0C60: CC22003B 02002D16
	ds_load_b128 v[17:20], v127 offset:25824                   // 0000001C0C68: DBFC64E0 1100007F
	v_fma_mixlo_f16 v60, v23, s22, 0                           // 0000001C0C70: CC21003C 02002D17
	v_fma_mixhi_f16 v60, v24, s22, 0                           // 0000001C0C78: CC22003C 02002D18
	ds_load_b128 v[21:24], v127 offset:25840                   // 0000001C0C80: DBFC64F0 1500007F
	v_add_nc_u32_e32 v172, s7, v130                            // 0000001C0C88: 4B590407
	s_waitcnt lgkmcnt(9)                                       // 0000001C0C8C: BF89FC97
	v_fma_mixlo_f16 v41, v89, s22, 0                           // 0000001C0C90: CC210029 02002D59
	v_fma_mixhi_f16 v41, v90, s22, 0                           // 0000001C0C98: CC220029 02002D5A
	v_fma_mixlo_f16 v42, v91, s22, 0                           // 0000001C0CA0: CC21002A 02002D5B
	v_fma_mixhi_f16 v42, v92, s22, 0                           // 0000001C0CA8: CC22002A 02002D5C
	s_waitcnt lgkmcnt(8)                                       // 0000001C0CB0: BF89FC87
	v_fma_mixlo_f16 v43, v93, s22, 0                           // 0000001C0CB4: CC21002B 02002D5D
	v_fma_mixhi_f16 v43, v94, s22, 0                           // 0000001C0CBC: CC22002B 02002D5E
	v_fma_mixlo_f16 v44, v95, s22, 0                           // 0000001C0CC4: CC21002C 02002D5F
	v_fma_mixhi_f16 v44, v96, s22, 0                           // 0000001C0CCC: CC22002C 02002D60
	s_waitcnt lgkmcnt(7)                                       // 0000001C0CD4: BF89FC77
	v_fma_mixlo_f16 v45, v81, s22, 0                           // 0000001C0CD8: CC21002D 02002D51
	v_fma_mixhi_f16 v45, v82, s22, 0                           // 0000001C0CE0: CC22002D 02002D52
	v_fma_mixlo_f16 v46, v83, s22, 0                           // 0000001C0CE8: CC21002E 02002D53
	v_fma_mixhi_f16 v46, v84, s22, 0                           // 0000001C0CF0: CC22002E 02002D54
	s_waitcnt lgkmcnt(6)                                       // 0000001C0CF8: BF89FC67
	v_fma_mixlo_f16 v47, v85, s22, 0                           // 0000001C0CFC: CC21002F 02002D55
	v_fma_mixhi_f16 v47, v86, s22, 0                           // 0000001C0D04: CC22002F 02002D56
	v_fma_mixlo_f16 v48, v87, s22, 0                           // 0000001C0D0C: CC210030 02002D57
	v_fma_mixhi_f16 v48, v88, s22, 0                           // 0000001C0D14: CC220030 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001C0D1C: BF89FC57
	v_fma_mixlo_f16 v61, v61, s22, 0                           // 0000001C0D20: CC21003D 02002D3D
	v_fma_mixhi_f16 v61, v62, s22, 0                           // 0000001C0D28: CC22003D 02002D3E
	v_fma_mixlo_f16 v62, v63, s22, 0                           // 0000001C0D30: CC21003E 02002D3F
	v_fma_mixhi_f16 v62, v64, s22, 0                           // 0000001C0D38: CC22003E 02002D40
	s_waitcnt lgkmcnt(4)                                       // 0000001C0D40: BF89FC47
	v_fma_mixlo_f16 v63, v65, s22, 0                           // 0000001C0D44: CC21003F 02002D41
	v_fma_mixhi_f16 v63, v66, s22, 0                           // 0000001C0D4C: CC22003F 02002D42
	v_fma_mixlo_f16 v64, v67, s22, 0                           // 0000001C0D54: CC210040 02002D43
	v_fma_mixhi_f16 v64, v68, s22, 0                           // 0000001C0D5C: CC220040 02002D44
	s_waitcnt lgkmcnt(3)                                       // 0000001C0D64: BF89FC37
	v_fma_mixlo_f16 v65, v69, s22, 0                           // 0000001C0D68: CC210041 02002D45
	v_fma_mixhi_f16 v65, v70, s22, 0                           // 0000001C0D70: CC220041 02002D46
	v_fma_mixlo_f16 v66, v71, s22, 0                           // 0000001C0D78: CC210042 02002D47
	v_fma_mixhi_f16 v66, v72, s22, 0                           // 0000001C0D80: CC220042 02002D48
	s_waitcnt lgkmcnt(2)                                       // 0000001C0D88: BF89FC27
	v_fma_mixlo_f16 v67, v73, s22, 0                           // 0000001C0D8C: CC210043 02002D49
	v_fma_mixhi_f16 v67, v74, s22, 0                           // 0000001C0D94: CC220043 02002D4A
	v_fma_mixlo_f16 v68, v75, s22, 0                           // 0000001C0D9C: CC210044 02002D4B
	v_fma_mixhi_f16 v68, v76, s22, 0                           // 0000001C0DA4: CC220044 02002D4C
	s_waitcnt lgkmcnt(1)                                       // 0000001C0DAC: BF89FC17
	v_fma_mixlo_f16 v69, v17, s22, 0                           // 0000001C0DB0: CC210045 02002D11
	v_fma_mixhi_f16 v69, v18, s22, 0                           // 0000001C0DB8: CC220045 02002D12
	v_fma_mixlo_f16 v70, v19, s22, 0                           // 0000001C0DC0: CC210046 02002D13
	v_fma_mixhi_f16 v70, v20, s22, 0                           // 0000001C0DC8: CC220046 02002D14
	s_waitcnt lgkmcnt(0)                                       // 0000001C0DD0: BF89FC07
	v_fma_mixlo_f16 v71, v21, s22, 0                           // 0000001C0DD4: CC210047 02002D15
	v_fma_mixhi_f16 v71, v22, s22, 0                           // 0000001C0DDC: CC220047 02002D16
	v_fma_mixlo_f16 v72, v23, s22, 0                           // 0000001C0DE4: CC210048 02002D17
	v_fma_mixhi_f16 v72, v24, s22, 0                           // 0000001C0DEC: CC220048 02002D18
	.long 0x7e223880                                           // 0000001C0DF4: 7E223880
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[41:48], v[25:32]// 0000001C0DF8: CC404019 1C665301
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[57:64], v[33:40]// 0000001C0E00: CC404021 1C867301
	.long 0xd4440000                                           // 0000001C0E08: D4440000
	v_cndmask_b32_e32 v1, s58, v172, vcc_lo                    // 0000001C0E0C: 0203583A
	v_wmma_f32_16x16x16_f16 v[9:16], v[1:8], v[65:72], v[9:16] // 0000001C0E10: CC404009 1C268301
	.long 0x7e023911                                           // 0000001C0E18: 7E023911
	s_and_saveexec_b32 s7, s0                                  // 0000001C0E1C: BE872000
	s_cbranch_execz 17                                         // 0000001C0E20: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4268>
	v_mad_u64_u32 v[1:2], null, v172, 48, s[2:3]               // 0000001C0E24: D6FE7C01 000961AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C0E2C: BF870091
	.long 0xd73c0001                                           // 0000001C0E30: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C0E34: 02020289
	.long 0xd7000101                                           // 0000001C0E38: D7000101
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C0E3C: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C0E40: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s1                 // 0000001C0E44: D5207C02 00060587
	global_load_b32 v1, v[1:2], off                            // 0000001C0E4C: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C0E54: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v49                         // 0000001C0E58: 560262FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C0E60: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001C0E68: 8C7E077E
	v_add_nc_u32_e32 v173, 2, v172                             // 0000001C0E6C: 4B5B5882
	ds_store_b16 v136, v1                                      // 0000001C0E70: D87C0000 00000188
	.long 0xd4440001                                           // 0000001C0E78: D4440001
	v_cndmask_b32_e32 v1, s58, v173, vcc_lo                    // 0000001C0E7C: 02035A3A
	s_and_saveexec_b32 s8, s1                                  // 0000001C0E80: BE882001
	s_cbranch_execz 17                                         // 0000001C0E84: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x42cc>
	v_mad_u64_u32 v[1:2], null, v173, 48, s[2:3]               // 0000001C0E88: D6FE7C01 000961AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C0E90: BF870091
	.long 0xd73c0001                                           // 0000001C0E94: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C0E98: 02020289
	.long 0xd7000701                                           // 0000001C0E9C: D7000701
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C0EA0: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C0EA4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s7                 // 0000001C0EA8: D5207C02 001E0587
	global_load_b32 v1, v[1:2], off                            // 0000001C0EB0: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C0EB8: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v50                         // 0000001C0EBC: 560264FF BB800000
	v_fma_mixlo_f16 v17, v1, s22, 0                            // 0000001C0EC4: CC210011 02002D01
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001C0ECC: 8C7E087E
	v_add_nc_u32_e32 v174, 4, v172                             // 0000001C0ED0: 4B5D5884
	.long 0x7e023880                                           // 0000001C0ED4: 7E023880
	ds_store_b16 v136, v17 offset:4                            // 0000001C0ED8: D87C0004 00001188
	.long 0xd4440007                                           // 0000001C0EE0: D4440007
	v_cndmask_b32_e32 v1, s58, v174, vcc_lo                    // 0000001C0EE4: 02035C3A
	.long 0x7f023901                                           // 0000001C0EE8: 7F023901
	s_and_saveexec_b32 s9, s7                                  // 0000001C0EEC: BE892007
	s_cbranch_execz 17                                         // 0000001C0EF0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4338>
	v_mad_u64_u32 v[2:3], null, v174, 48, s[2:3]               // 0000001C0EF4: D6FE7C02 000961AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C0EFC: BF870091
	.long 0xd73c0002                                           // 0000001C0F00: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C0F04: 02020489
	.long 0xd7000802                                           // 0000001C0F08: D7000802
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C0F0C: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C0F10: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s8                 // 0000001C0F14: D5207C03 00220787
	global_load_b32 v2, v[2:3], off                            // 0000001C0F1C: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C0F24: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v51                         // 0000001C0F28: 560466FF BB800000
	v_fma_mixhi_f16 v1, v2, s22, 0                             // 0000001C0F30: CC220001 02002D02
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001C0F38: 8C7E097E
	v_add_nc_u32_e32 v175, 6, v172                             // 0000001C0F3C: 4B5F5886
	ds_store_b16_d16_hi v136, v1 offset:8                      // 0000001C0F40: DA840008 00000188
	.long 0xd4440008                                           // 0000001C0F48: D4440008
	v_cndmask_b32_e32 v1, s58, v175, vcc_lo                    // 0000001C0F4C: 02035E3A
	s_and_saveexec_b32 s10, s8                                 // 0000001C0F50: BE8A2008
	s_cbranch_execz 17                                         // 0000001C0F54: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x439c>
	v_mad_u64_u32 v[1:2], null, v175, 48, s[2:3]               // 0000001C0F58: D6FE7C01 000961AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C0F60: BF870091
	.long 0xd73c0001                                           // 0000001C0F64: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C0F68: 02020289
	.long 0xd7000901                                           // 0000001C0F6C: D7000901
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C0F70: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C0F74: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s9                 // 0000001C0F78: D5207C02 00260587
	global_load_b32 v1, v[1:2], off                            // 0000001C0F80: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C0F88: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v52                         // 0000001C0F8C: 560268FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C0F94: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001C0F9C: 8C7E0A7E
	v_add_nc_u32_e32 v176, 8, v172                             // 0000001C0FA0: 4B615888
	.long 0x7f023880                                           // 0000001C0FA4: 7F023880
	ds_store_b16 v136, v1 offset:12                            // 0000001C0FA8: D87C000C 00000188
	.long 0xd4440009                                           // 0000001C0FB0: D4440009
	v_cndmask_b32_e32 v1, s58, v176, vcc_lo                    // 0000001C0FB4: 0203603A
	.long 0x7e043981                                           // 0000001C0FB8: 7E043981
	s_and_saveexec_b32 s11, s9                                 // 0000001C0FBC: BE8B2009
	s_cbranch_execz 17                                         // 0000001C0FC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4408>
	v_mad_u64_u32 v[2:3], null, v176, 48, s[2:3]               // 0000001C0FC4: D6FE7C02 000961B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C0FCC: BF870091
	.long 0xd73c0002                                           // 0000001C0FD0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C0FD4: 02020489
	.long 0xd7000a02                                           // 0000001C0FD8: D7000A02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C0FDC: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C0FE0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s10                // 0000001C0FE4: D5207C03 002A0787
	global_load_b32 v2, v[2:3], off                            // 0000001C0FEC: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C0FF4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v53                         // 0000001C0FF8: 56046AFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C1000: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001C1008: 8C7E0B7E
	v_add_nc_u32_e32 v177, 10, v172                            // 0000001C100C: 4B63588A
	ds_store_b16 v136, v2 offset:16                            // 0000001C1010: D87C0010 00000288
	.long 0xd444000a                                           // 0000001C1018: D444000A
	v_cndmask_b32_e32 v1, s58, v177, vcc_lo                    // 0000001C101C: 0203623A
	s_and_saveexec_b32 s12, s10                                // 0000001C1020: BE8C200A
	s_cbranch_execz 17                                         // 0000001C1024: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x446c>
	v_mad_u64_u32 v[1:2], null, v177, 48, s[2:3]               // 0000001C1028: D6FE7C01 000961B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1030: BF870091
	.long 0xd73c0001                                           // 0000001C1034: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1038: 02020289
	.long 0xd7000b01                                           // 0000001C103C: D7000B01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1040: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1044: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s11                // 0000001C1048: D5207C02 002E0587
	global_load_b32 v1, v[1:2], off                            // 0000001C1050: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1058: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v54                         // 0000001C105C: 56026CFF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C1064: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001C106C: 8C7E0C7E
	v_add_nc_u32_e32 v178, 12, v172                            // 0000001C1070: 4B65588C
	.long 0x7e023880                                           // 0000001C1074: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:20                     // 0000001C1078: DA840014 00000188
	.long 0xd444000b                                           // 0000001C1080: D444000B
	v_cndmask_b32_e32 v1, s58, v178, vcc_lo                    // 0000001C1084: 0203643A
	.long 0x7e043901                                           // 0000001C1088: 7E043901
	s_and_saveexec_b32 s14, s11                                // 0000001C108C: BE8E200B
	s_cbranch_execz 17                                         // 0000001C1090: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44d8>
	v_mad_u64_u32 v[2:3], null, v178, 48, s[2:3]               // 0000001C1094: D6FE7C02 000961B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C109C: BF870091
	.long 0xd73c0002                                           // 0000001C10A0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C10A4: 02020489
	.long 0xd7000c02                                           // 0000001C10A8: D7000C02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C10AC: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C10B0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s12                // 0000001C10B4: D5207C03 00320787
	global_load_b32 v2, v[2:3], off                            // 0000001C10BC: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C10C4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v55                         // 0000001C10C8: 56046EFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C10D0: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001C10D8: 8C7E0E7E
	v_add_nc_u32_e32 v179, 14, v172                            // 0000001C10DC: 4B67588E
	ds_store_b16 v136, v2 offset:24                            // 0000001C10E0: D87C0018 00000288
	.long 0xd444000c                                           // 0000001C10E8: D444000C
	v_cndmask_b32_e32 v1, s58, v179, vcc_lo                    // 0000001C10EC: 0203663A
	s_and_saveexec_b32 s29, s12                                // 0000001C10F0: BE9D200C
	s_cbranch_execz 17                                         // 0000001C10F4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x453c>
	v_mad_u64_u32 v[1:2], null, v179, 48, s[2:3]               // 0000001C10F8: D6FE7C01 000961B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1100: BF870091
	.long 0xd73c0001                                           // 0000001C1104: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1108: 02020289
	.long 0xd7000e01                                           // 0000001C110C: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1110: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1114: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1118: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off                            // 0000001C1120: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1128: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v56                         // 0000001C112C: 560270FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C1134: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C113C: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C1140: 7F023880
	ds_store_b16 v136, v1 offset:28                            // 0000001C1144: D87C001C 00000188
	.long 0x7e043981                                           // 0000001C114C: 7E043981
	s_and_saveexec_b32 s29, s0                                 // 0000001C1150: BE9D2000
	s_cbranch_execz 17                                         // 0000001C1154: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x459c>
	v_mad_u64_u32 v[2:3], null, v172, 48, s[2:3]               // 0000001C1158: D6FE7C02 000961AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1160: BF870091
	.long 0xd73c0002                                           // 0000001C1164: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1168: 02020489
	.long 0xd7000e02                                           // 0000001C116C: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1170: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1174: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1178: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001C1180: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1188: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v25                         // 0000001C118C: 560432FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C1194: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C119C: 8C7E1D7E
	ds_store_b16 v136, v2 offset:2304                          // 0000001C11A0: D87C0900 00000288
	s_and_saveexec_b32 s29, s1                                 // 0000001C11A8: BE9D2001
	s_cbranch_execz 17                                         // 0000001C11AC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45f4>
	v_mad_u64_u32 v[1:2], null, v173, 48, s[2:3]               // 0000001C11B0: D6FE7C01 000961AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C11B8: BF870091
	.long 0xd73c0001                                           // 0000001C11BC: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C11C0: 02020289
	.long 0xd7000e01                                           // 0000001C11C4: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C11C8: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C11CC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C11D0: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001C11D8: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C11E0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v26                         // 0000001C11E4: 560234FF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C11EC: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C11F4: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C11F8: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:2308                   // 0000001C11FC: DA840904 00000188
	.long 0x7e043901                                           // 0000001C1204: 7E043901
	s_and_saveexec_b32 s29, s7                                 // 0000001C1208: BE9D2007
	s_cbranch_execz 17                                         // 0000001C120C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4654>
	v_mad_u64_u32 v[2:3], null, v174, 48, s[2:3]               // 0000001C1210: D6FE7C02 000961AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1218: BF870091
	.long 0xd73c0002                                           // 0000001C121C: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1220: 02020489
	.long 0xd7000e02                                           // 0000001C1224: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1228: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C122C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1230: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001C1238: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1240: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v27                         // 0000001C1244: 560436FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C124C: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1254: 8C7E1D7E
	ds_store_b16 v136, v2 offset:2312                          // 0000001C1258: D87C0908 00000288
	s_and_saveexec_b32 s29, s8                                 // 0000001C1260: BE9D2008
	s_cbranch_execz 17                                         // 0000001C1264: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x46ac>
	v_mad_u64_u32 v[1:2], null, v175, 48, s[2:3]               // 0000001C1268: D6FE7C01 000961AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1270: BF870091
	.long 0xd73c0001                                           // 0000001C1274: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1278: 02020289
	.long 0xd7000e01                                           // 0000001C127C: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1280: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1284: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1288: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001C1290: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1298: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v28                         // 0000001C129C: 560238FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C12A4: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C12AC: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C12B0: 7F023880
	ds_store_b16 v136, v1 offset:2316                          // 0000001C12B4: D87C090C 00000188
	.long 0x7e043981                                           // 0000001C12BC: 7E043981
	s_and_saveexec_b32 s29, s9                                 // 0000001C12C0: BE9D2009
	s_cbranch_execz 17                                         // 0000001C12C4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x470c>
	v_mad_u64_u32 v[2:3], null, v176, 48, s[2:3]               // 0000001C12C8: D6FE7C02 000961B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C12D0: BF870091
	.long 0xd73c0002                                           // 0000001C12D4: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C12D8: 02020489
	.long 0xd7000e02                                           // 0000001C12DC: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C12E0: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C12E4: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C12E8: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001C12F0: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C12F8: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v29                         // 0000001C12FC: 56043AFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C1304: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C130C: 8C7E1D7E
	ds_store_b16 v136, v2 offset:2320                          // 0000001C1310: D87C0910 00000288
	s_and_saveexec_b32 s29, s10                                // 0000001C1318: BE9D200A
	s_cbranch_execz 17                                         // 0000001C131C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4764>
	v_mad_u64_u32 v[1:2], null, v177, 48, s[2:3]               // 0000001C1320: D6FE7C01 000961B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1328: BF870091
	.long 0xd73c0001                                           // 0000001C132C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1330: 02020289
	.long 0xd7000e01                                           // 0000001C1334: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1338: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C133C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1340: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001C1348: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1350: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v30                         // 0000001C1354: 56023CFF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C135C: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1364: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C1368: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:2324                   // 0000001C136C: DA840914 00000188
	.long 0x7e043901                                           // 0000001C1374: 7E043901
	s_and_saveexec_b32 s29, s11                                // 0000001C1378: BE9D200B
	s_cbranch_execz 17                                         // 0000001C137C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x47c4>
	v_mad_u64_u32 v[2:3], null, v178, 48, s[2:3]               // 0000001C1380: D6FE7C02 000961B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1388: BF870091
	.long 0xd73c0002                                           // 0000001C138C: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1390: 02020489
	.long 0xd7000e02                                           // 0000001C1394: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1398: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C139C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C13A0: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001C13A8: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C13B0: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v31                         // 0000001C13B4: 56043EFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C13BC: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C13C4: 8C7E1D7E
	ds_store_b16 v136, v2 offset:2328                          // 0000001C13C8: D87C0918 00000288
	s_and_saveexec_b32 s29, s12                                // 0000001C13D0: BE9D200C
	s_cbranch_execz 17                                         // 0000001C13D4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x481c>
	v_mad_u64_u32 v[1:2], null, v179, 48, s[2:3]               // 0000001C13D8: D6FE7C01 000961B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C13E0: BF870091
	.long 0xd73c0001                                           // 0000001C13E4: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C13E8: 02020289
	.long 0xd7000e01                                           // 0000001C13EC: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C13F0: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C13F4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C13F8: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001C1400: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1408: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v32                         // 0000001C140C: 560240FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C1414: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C141C: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C1420: 7F023880
	ds_store_b16 v136, v1 offset:2332                          // 0000001C1424: D87C091C 00000188
	.long 0x7e043981                                           // 0000001C142C: 7E043981
	s_and_saveexec_b32 s29, s0                                 // 0000001C1430: BE9D2000
	s_cbranch_execz 17                                         // 0000001C1434: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x487c>
	v_mad_u64_u32 v[2:3], null, v172, 48, s[2:3]               // 0000001C1438: D6FE7C02 000961AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1440: BF870091
	.long 0xd73c0002                                           // 0000001C1444: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1448: 02020489
	.long 0xd7000e02                                           // 0000001C144C: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1450: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1454: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1458: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001C1460: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1468: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v33                         // 0000001C146C: 560442FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C1474: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C147C: 8C7E1D7E
	ds_store_b16 v136, v2 offset:4608                          // 0000001C1480: D87C1200 00000288
	s_and_saveexec_b32 s29, s1                                 // 0000001C1488: BE9D2001
	s_cbranch_execz 17                                         // 0000001C148C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x48d4>
	v_mad_u64_u32 v[1:2], null, v173, 48, s[2:3]               // 0000001C1490: D6FE7C01 000961AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1498: BF870091
	.long 0xd73c0001                                           // 0000001C149C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C14A0: 02020289
	.long 0xd7000e01                                           // 0000001C14A4: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C14A8: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C14AC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C14B0: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001C14B8: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C14C0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v34                         // 0000001C14C4: 560244FF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C14CC: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C14D4: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C14D8: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:4612                   // 0000001C14DC: DA841204 00000188
	.long 0x7e043901                                           // 0000001C14E4: 7E043901
	s_and_saveexec_b32 s29, s7                                 // 0000001C14E8: BE9D2007
	s_cbranch_execz 17                                         // 0000001C14EC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4934>
	v_mad_u64_u32 v[2:3], null, v174, 48, s[2:3]               // 0000001C14F0: D6FE7C02 000961AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C14F8: BF870091
	.long 0xd73c0002                                           // 0000001C14FC: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1500: 02020489
	.long 0xd7000e02                                           // 0000001C1504: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1508: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C150C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1510: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001C1518: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1520: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v35                         // 0000001C1524: 560446FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C152C: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1534: 8C7E1D7E
	ds_store_b16 v136, v2 offset:4616                          // 0000001C1538: D87C1208 00000288
	s_and_saveexec_b32 s29, s8                                 // 0000001C1540: BE9D2008
	s_cbranch_execz 17                                         // 0000001C1544: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x498c>
	v_mad_u64_u32 v[1:2], null, v175, 48, s[2:3]               // 0000001C1548: D6FE7C01 000961AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1550: BF870091
	.long 0xd73c0001                                           // 0000001C1554: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1558: 02020289
	.long 0xd7000e01                                           // 0000001C155C: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1560: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1564: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1568: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001C1570: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1578: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v36                         // 0000001C157C: 560248FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C1584: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C158C: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C1590: 7F023880
	ds_store_b16 v136, v1 offset:4620                          // 0000001C1594: D87C120C 00000188
	.long 0x7e043981                                           // 0000001C159C: 7E043981
	s_and_saveexec_b32 s29, s9                                 // 0000001C15A0: BE9D2009
	s_cbranch_execz 17                                         // 0000001C15A4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x49ec>
	v_mad_u64_u32 v[2:3], null, v176, 48, s[2:3]               // 0000001C15A8: D6FE7C02 000961B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C15B0: BF870091
	.long 0xd73c0002                                           // 0000001C15B4: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C15B8: 02020489
	.long 0xd7000e02                                           // 0000001C15BC: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C15C0: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C15C4: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C15C8: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001C15D0: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C15D8: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v37                         // 0000001C15DC: 56044AFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C15E4: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C15EC: 8C7E1D7E
	ds_store_b16 v136, v2 offset:4624                          // 0000001C15F0: D87C1210 00000288
	s_and_saveexec_b32 s29, s10                                // 0000001C15F8: BE9D200A
	s_cbranch_execz 17                                         // 0000001C15FC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4a44>
	v_mad_u64_u32 v[1:2], null, v177, 48, s[2:3]               // 0000001C1600: D6FE7C01 000961B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1608: BF870091
	.long 0xd73c0001                                           // 0000001C160C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1610: 02020289
	.long 0xd7000e01                                           // 0000001C1614: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1618: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C161C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1620: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001C1628: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1630: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v38                         // 0000001C1634: 56024CFF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C163C: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1644: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C1648: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:4628                   // 0000001C164C: DA841214 00000188
	.long 0x7e043901                                           // 0000001C1654: 7E043901
	s_and_saveexec_b32 s29, s11                                // 0000001C1658: BE9D200B
	s_cbranch_execz 17                                         // 0000001C165C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4aa4>
	v_mad_u64_u32 v[2:3], null, v178, 48, s[2:3]               // 0000001C1660: D6FE7C02 000961B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1668: BF870091
	.long 0xd73c0002                                           // 0000001C166C: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1670: 02020489
	.long 0xd7000e02                                           // 0000001C1674: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1678: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C167C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1680: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001C1688: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1690: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v39                         // 0000001C1694: 56044EFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C169C: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C16A4: 8C7E1D7E
	ds_store_b16 v136, v2 offset:4632                          // 0000001C16A8: D87C1218 00000288
	s_and_saveexec_b32 s29, s12                                // 0000001C16B0: BE9D200C
	s_cbranch_execz 17                                         // 0000001C16B4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4afc>
	v_mad_u64_u32 v[1:2], null, v179, 48, s[2:3]               // 0000001C16B8: D6FE7C01 000961B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C16C0: BF870091
	.long 0xd73c0001                                           // 0000001C16C4: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C16C8: 02020289
	.long 0xd7000e01                                           // 0000001C16CC: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C16D0: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C16D4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C16D8: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001C16E0: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C16E8: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v40                         // 0000001C16EC: 560250FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C16F4: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C16FC: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C1700: 7F023880
	ds_store_b16 v136, v1 offset:4636                          // 0000001C1704: D87C121C 00000188
	.long 0x7e043981                                           // 0000001C170C: 7E043981
	s_and_saveexec_b32 s29, s0                                 // 0000001C1710: BE9D2000
	s_cbranch_execz 17                                         // 0000001C1714: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4b5c>
	v_mad_u64_u32 v[2:3], null, v172, 48, s[2:3]               // 0000001C1718: D6FE7C02 000961AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1720: BF870091
	.long 0xd73c0002                                           // 0000001C1724: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1728: 02020489
	.long 0xd7000e02                                           // 0000001C172C: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1730: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1734: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1738: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001C1740: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1748: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v9                          // 0000001C174C: 560412FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C1754: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C175C: 8C7E1D7E
	ds_store_b16 v136, v2 offset:6912                          // 0000001C1760: D87C1B00 00000288
	s_and_saveexec_b32 s29, s1                                 // 0000001C1768: BE9D2001
	s_cbranch_execz 17                                         // 0000001C176C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4bb4>
	v_mad_u64_u32 v[1:2], null, v173, 48, s[2:3]               // 0000001C1770: D6FE7C01 000961AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1778: BF870091
	.long 0xd73c0001                                           // 0000001C177C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1780: 02020289
	.long 0xd7000e01                                           // 0000001C1784: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1788: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C178C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1790: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001C1798: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C17A0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v10                         // 0000001C17A4: 560214FF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C17AC: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C17B4: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C17B8: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:6916                   // 0000001C17BC: DA841B04 00000188
	.long 0x7e043901                                           // 0000001C17C4: 7E043901
	s_and_saveexec_b32 s29, s7                                 // 0000001C17C8: BE9D2007
	s_cbranch_execz 17                                         // 0000001C17CC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c14>
	v_mad_u64_u32 v[2:3], null, v174, 48, s[2:3]               // 0000001C17D0: D6FE7C02 000961AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C17D8: BF870091
	.long 0xd73c0002                                           // 0000001C17DC: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C17E0: 02020489
	.long 0xd7000e02                                           // 0000001C17E4: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C17E8: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C17EC: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C17F0: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001C17F8: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1800: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v11                         // 0000001C1804: 560416FF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C180C: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1814: 8C7E1D7E
	ds_store_b16 v136, v2 offset:6920                          // 0000001C1818: D87C1B08 00000288
	s_and_saveexec_b32 s29, s8                                 // 0000001C1820: BE9D2008
	s_cbranch_execz 17                                         // 0000001C1824: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c6c>
	v_mad_u64_u32 v[1:2], null, v175, 48, s[2:3]               // 0000001C1828: D6FE7C01 000961AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1830: BF870091
	.long 0xd73c0001                                           // 0000001C1834: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C1838: 02020289
	.long 0xd7000e01                                           // 0000001C183C: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C1840: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1844: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1848: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001C1850: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1858: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v12                         // 0000001C185C: 560218FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C1864: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C186C: 8C7E1D7E
	.long 0x7f023880                                           // 0000001C1870: 7F023880
	ds_store_b16 v136, v1 offset:6924                          // 0000001C1874: D87C1B0C 00000188
	.long 0x7e043981                                           // 0000001C187C: 7E043981
	s_and_saveexec_b32 s29, s9                                 // 0000001C1880: BE9D2009
	s_cbranch_execz 17                                         // 0000001C1884: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4ccc>
	v_mad_u64_u32 v[2:3], null, v176, 48, s[2:3]               // 0000001C1888: D6FE7C02 000961B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1890: BF870091
	.long 0xd73c0002                                           // 0000001C1894: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1898: 02020489
	.long 0xd7000e02                                           // 0000001C189C: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C18A0: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C18A4: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C18A8: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001C18B0: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C18B8: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v13                         // 0000001C18BC: 56041AFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C18C4: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C18CC: 8C7E1D7E
	ds_store_b16 v136, v2 offset:6928                          // 0000001C18D0: D87C1B10 00000288
	s_and_saveexec_b32 s29, s10                                // 0000001C18D8: BE9D200A
	s_cbranch_execz 17                                         // 0000001C18DC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d24>
	v_mad_u64_u32 v[1:2], null, v177, 48, s[2:3]               // 0000001C18E0: D6FE7C01 000961B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C18E8: BF870091
	.long 0xd73c0001                                           // 0000001C18EC: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C18F0: 02020289
	.long 0xd7000e01                                           // 0000001C18F4: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C18F8: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C18FC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C1900: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001C1908: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C1910: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v14                         // 0000001C1914: 56021CFF BB800000
	v_fma_mixhi_f16 v1, v1, s22, 0                             // 0000001C191C: CC220001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1924: 8C7E1D7E
	.long 0x7e023880                                           // 0000001C1928: 7E023880
	ds_store_b16_d16_hi v136, v1 offset:6932                   // 0000001C192C: DA841B14 00000188
	.long 0x7e043901                                           // 0000001C1934: 7E043901
	s_and_saveexec_b32 s29, s11                                // 0000001C1938: BE9D200B
	s_cbranch_execz 17                                         // 0000001C193C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d84>
	v_mad_u64_u32 v[2:3], null, v178, 48, s[2:3]               // 0000001C1940: D6FE7C02 000961B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C1948: BF870091
	.long 0xd73c0002                                           // 0000001C194C: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001C1950: 02020489
	.long 0xd7000e02                                           // 0000001C1954: D7000E02
	v_cndmask_b32_e32 v1, v134, v2, vcc_lo                     // 0000001C1958: 02020586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C195C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v135, v3, s14                // 0000001C1960: D5207C03 003A0787
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001C1968: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001C1970: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v15                         // 0000001C1974: 56041EFF BB800000
	v_fma_mixlo_f16 v2, v2, s22, 0                             // 0000001C197C: CC210002 02002D02
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C1984: 8C7E1D7E
	ds_store_b16 v136, v2 offset:6936                          // 0000001C1988: D87C1B18 00000288
	s_and_saveexec_b32 s29, s12                                // 0000001C1990: BE9D200C
	s_cbranch_execz 17                                         // 0000001C1994: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4ddc>
	v_mad_u64_u32 v[1:2], null, v179, 48, s[2:3]               // 0000001C1998: D6FE7C01 000961B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C19A0: BF870091
	.long 0xd73c0001                                           // 0000001C19A4: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001C19A8: 02020289
	.long 0xd7000e01                                           // 0000001C19AC: D7000E01
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001C19B0: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C19B4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v135, v2, s14                // 0000001C19B8: D5207C02 003A0587
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001C19C0: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C19C8: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v16                         // 0000001C19CC: 560220FF BB800000
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C19D4: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s29                             // 0000001C19DC: 8C7E1D7E
	.long 0xd7000e02                                           // 0000001C19E0: D7000E02
	v_cndmask_b32_e32 v1, s24, v97, vcc_lo                     // 0000001C19E4: 0202C218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C19E8: BF870001
	v_add_co_ci_u32_e64 v3, null, s25, v98, s14                // 0000001C19EC: D5207C03 003AC419
	ds_store_b16 v136, v1 offset:6940                          // 0000001C19F4: D87C1B1C 00000188
	s_waitcnt lgkmcnt(0)                                       // 0000001C19FC: BF89FC07
	s_barrier                                                  // 0000001C1A00: BFBD0000
	buffer_gl0_inv                                             // 0000001C1A04: E0AC0000 00000000
	s_clause 0xf                                               // 0000001C1A0C: BF85000F
	global_load_b128 v[97:100], v[2:3], off                    // 0000001C1A10: DC5E0000 617C0002
	global_load_b128 v[101:104], v[2:3], off offset:16         // 0000001C1A18: DC5E0010 657C0002
	global_load_b128 v[89:92], v[2:3], off offset:32           // 0000001C1A20: DC5E0020 597C0002
	global_load_b128 v[93:96], v[2:3], off offset:48           // 0000001C1A28: DC5E0030 5D7C0002
	global_load_b128 v[81:84], v[2:3], off offset:64           // 0000001C1A30: DC5E0040 517C0002
	global_load_b128 v[85:88], v[2:3], off offset:80           // 0000001C1A38: DC5E0050 557C0002
	global_load_b128 v[73:76], v[2:3], off offset:96           // 0000001C1A40: DC5E0060 497C0002
	global_load_b128 v[77:80], v[2:3], off offset:112          // 0000001C1A48: DC5E0070 4D7C0002
	global_load_b128 v[57:60], v[2:3], off offset:128          // 0000001C1A50: DC5E0080 397C0002
	global_load_b128 v[61:64], v[2:3], off offset:144          // 0000001C1A58: DC5E0090 3D7C0002
	global_load_b128 v[49:52], v[2:3], off offset:160          // 0000001C1A60: DC5E00A0 317C0002
	global_load_b128 v[53:56], v[2:3], off offset:176          // 0000001C1A68: DC5E00B0 357C0002
	global_load_b128 v[41:44], v[2:3], off offset:192          // 0000001C1A70: DC5E00C0 297C0002
	global_load_b128 v[45:48], v[2:3], off offset:208          // 0000001C1A78: DC5E00D0 2D7C0002
	global_load_b128 v[33:36], v[2:3], off offset:224          // 0000001C1A80: DC5E00E0 217C0002
	global_load_b128 v[37:40], v[2:3], off offset:240          // 0000001C1A88: DC5E00F0 257C0002
	s_and_saveexec_b32 s14, s13                                // 0000001C1A90: BE8E200D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C1A94: BF870009
	s_xor_b32 s13, exec_lo, s14                                // 0000001C1A98: 8D0D0E7E
	s_cbranch_execz 81                                         // 0000001C1A9C: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4fe4>
	s_waitcnt vmcnt(15)                                        // 0000001C1AA0: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001C1AA4: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C1AA8: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001C1AAC: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001C1AB0: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001C1AB4: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001C1AB8: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001C1ABC: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001C1AC0: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001C1AC4: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001C1AC8: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001C1ACC: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001C1AD0: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001C1AD4: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001C1AD8: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001C1ADC: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001C1AE0: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001C1AE4: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001C1AE8: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001C1AEC: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001C1AF0: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001C1AF4: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001C1AF8: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001C1AFC: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001C1B00: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001C1B04: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001C1B08: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001C1B0C: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001C1B10: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001C1B14: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001C1B18: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001C1B1C: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001C1B20: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001C1B24: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001C1B28: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001C1B2C: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001C1B30: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001C1B34: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001C1B38: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001C1B3C: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001C1B40: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001C1B44: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001C1B48: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001C1B4C: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001C1B50: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001C1B54: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001C1B58: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001C1B5C: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001C1B60: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001C1B64: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001C1B68: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001C1B6C: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001C1B70: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001C1B74: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001C1B78: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001C1B7C: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001C1B80: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001C1B84: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001C1B88: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001C1B8C: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001C1B90: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001C1B94: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001C1B98: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001C1B9C: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001C1BA0: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001C1BA4: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001C1BA8: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001C1BAC: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001C1BB0: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001C1BB4: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001C1BB8: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001C1BBC: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001C1BC0: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001C1BC4: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001C1BC8: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001C1BCC: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001C1BD0: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001C1BD4: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001C1BD8: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001C1BDC: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001C1BE0: 7E500361
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C1BE4: 8C7E0D7E
	ds_load_b128 v[1:4], v127                                  // 0000001C1BE8: DBFC0000 0100007F
	ds_load_b128 v[5:8], v127 offset:16                        // 0000001C1BF0: DBFC0010 0500007F
	ds_load_b128 v[9:12], v127 offset:32                       // 0000001C1BF8: DBFC0020 0900007F
	ds_load_b128 v[13:16], v127 offset:48                      // 0000001C1C00: DBFC0030 0D00007F
	ds_load_b128 v[17:20], v127 offset:8448                    // 0000001C1C08: DBFC2100 1100007F
	ds_load_b128 v[21:24], v127 offset:8464                    // 0000001C1C10: DBFC2110 1500007F
	ds_load_b128 v[25:28], v127 offset:8480                    // 0000001C1C18: DBFC2120 1900007F
	ds_load_b128 v[29:32], v127 offset:8496                    // 0000001C1C20: DBFC2130 1D00007F
	ds_load_b128 v[180:183], v127 offset:16896                 // 0000001C1C28: DBFC4200 B400007F
	ds_load_b128 v[184:187], v127 offset:16912                 // 0000001C1C30: DBFC4210 B800007F
	ds_load_b128 v[188:191], v127 offset:16928                 // 0000001C1C38: DBFC4220 BC00007F
	ds_load_b128 v[192:195], v127 offset:16944                 // 0000001C1C40: DBFC4230 C000007F
	ds_load_b128 v[196:199], v127 offset:25376                 // 0000001C1C48: DBFC6320 C400007F
	v_dual_mov_b32 v72, s43 :: v_dual_mov_b32 v71, s42         // 0000001C1C50: CA10002B 4846002A
	v_dual_mov_b32 v70, s41 :: v_dual_mov_b32 v69, s40         // 0000001C1C58: CA100029 46440028
	v_dual_mov_b32 v68, s39 :: v_dual_mov_b32 v67, s38         // 0000001C1C60: CA100027 44420026
	v_dual_mov_b32 v66, s37 :: v_dual_mov_b32 v65, s36         // 0000001C1C68: CA100025 42400024
	s_waitcnt lgkmcnt(12)                                      // 0000001C1C70: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001C1C74: CC210001 02002D01
	v_fma_mixhi_f16 v1, v2, s22, 0                             // 0000001C1C7C: CC220001 02002D02
	v_fma_mixlo_f16 v2, v3, s22, 0                             // 0000001C1C84: CC210002 02002D03
	v_fma_mixhi_f16 v2, v4, s22, 0                             // 0000001C1C8C: CC220002 02002D04
	s_waitcnt lgkmcnt(11)                                      // 0000001C1C94: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s22, 0                             // 0000001C1C98: CC210003 02002D05
	v_fma_mixhi_f16 v3, v6, s22, 0                             // 0000001C1CA0: CC220003 02002D06
	v_fma_mixlo_f16 v4, v7, s22, 0                             // 0000001C1CA8: CC210004 02002D07
	v_fma_mixhi_f16 v4, v8, s22, 0                             // 0000001C1CB0: CC220004 02002D08
	s_waitcnt lgkmcnt(10)                                      // 0000001C1CB8: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s22, 0                             // 0000001C1CBC: CC210005 02002D09
	v_fma_mixhi_f16 v5, v10, s22, 0                            // 0000001C1CC4: CC220005 02002D0A
	v_fma_mixlo_f16 v6, v11, s22, 0                            // 0000001C1CCC: CC210006 02002D0B
	v_fma_mixhi_f16 v6, v12, s22, 0                            // 0000001C1CD4: CC220006 02002D0C
	s_waitcnt lgkmcnt(9)                                       // 0000001C1CDC: BF89FC97
	v_fma_mixlo_f16 v7, v13, s22, 0                            // 0000001C1CE0: CC210007 02002D0D
	v_fma_mixhi_f16 v7, v14, s22, 0                            // 0000001C1CE8: CC220007 02002D0E
	v_fma_mixlo_f16 v8, v15, s22, 0                            // 0000001C1CF0: CC210008 02002D0F
	v_fma_mixhi_f16 v8, v16, s22, 0                            // 0000001C1CF8: CC220008 02002D10
	s_waitcnt lgkmcnt(8)                                       // 0000001C1D00: BF89FC87
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001C1D04: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001C1D0C: CC220011 02002D12
	v_fma_mixlo_f16 v18, v19, s22, 0                           // 0000001C1D14: CC210012 02002D13
	v_fma_mixhi_f16 v18, v20, s22, 0                           // 0000001C1D1C: CC220012 02002D14
	s_waitcnt lgkmcnt(7)                                       // 0000001C1D24: BF89FC77
	v_fma_mixlo_f16 v19, v21, s22, 0                           // 0000001C1D28: CC210013 02002D15
	v_fma_mixhi_f16 v19, v22, s22, 0                           // 0000001C1D30: CC220013 02002D16
	v_fma_mixlo_f16 v20, v23, s22, 0                           // 0000001C1D38: CC210014 02002D17
	v_fma_mixhi_f16 v20, v24, s22, 0                           // 0000001C1D40: CC220014 02002D18
	s_waitcnt lgkmcnt(6)                                       // 0000001C1D48: BF89FC67
	v_fma_mixlo_f16 v21, v25, s22, 0                           // 0000001C1D4C: CC210015 02002D19
	v_fma_mixhi_f16 v21, v26, s22, 0                           // 0000001C1D54: CC220015 02002D1A
	v_fma_mixlo_f16 v22, v27, s22, 0                           // 0000001C1D5C: CC210016 02002D1B
	v_fma_mixhi_f16 v22, v28, s22, 0                           // 0000001C1D64: CC220016 02002D1C
	s_waitcnt lgkmcnt(5)                                       // 0000001C1D6C: BF89FC57
	v_fma_mixlo_f16 v23, v29, s22, 0                           // 0000001C1D70: CC210017 02002D1D
	v_fma_mixhi_f16 v23, v30, s22, 0                           // 0000001C1D78: CC220017 02002D1E
	v_fma_mixlo_f16 v24, v31, s22, 0                           // 0000001C1D80: CC210018 02002D1F
	v_fma_mixhi_f16 v24, v32, s22, 0                           // 0000001C1D88: CC220018 02002D20
	s_waitcnt vmcnt(14)                                        // 0000001C1D90: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001C1D94: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001C1D9C: BF89FC37
	v_fma_mixlo_f16 v4, v186, s22, 0                           // 0000001C1DA0: CC210004 02002DBA
	v_fma_mixhi_f16 v4, v187, s22, 0                           // 0000001C1DA8: CC220004 02002DBB
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001C1DB0: CC404009 1D062361
	ds_load_b128 v[17:20], v127 offset:25344                   // 0000001C1DB8: DBFC6300 1100007F
	ds_load_b128 v[21:24], v127 offset:25360                   // 0000001C1DC0: DBFC6310 1500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C1DC8: BF89FC47
	v_fma_mixlo_f16 v5, v188, s22, 0                           // 0000001C1DCC: CC210005 02002DBC
	v_fma_mixhi_f16 v5, v189, s22, 0                           // 0000001C1DD4: CC220005 02002DBD
	ds_load_b128 v[186:189], v127 offset:25392                 // 0000001C1DDC: DBFC6330 BA00007F
	v_fma_mixlo_f16 v3, v184, s22, 0                           // 0000001C1DE4: CC210003 02002DB8
	v_fma_mixlo_f16 v6, v190, s22, 0                           // 0000001C1DEC: CC210006 02002DBE
	v_fma_mixhi_f16 v6, v191, s22, 0                           // 0000001C1DF4: CC220006 02002DBF
	s_waitcnt lgkmcnt(4)                                       // 0000001C1DFC: BF89FC47
	v_fma_mixlo_f16 v7, v192, s22, 0                           // 0000001C1E00: CC210007 02002DC0
	v_fma_mixhi_f16 v7, v193, s22, 0                           // 0000001C1E08: CC220007 02002DC1
	v_fma_mixlo_f16 v8, v194, s22, 0                           // 0000001C1E10: CC210008 02002DC2
	v_fma_mixhi_f16 v8, v195, s22, 0                           // 0000001C1E18: CC220008 02002DC3
	ds_load_b128 v[190:193], v127 offset:64                    // 0000001C1E20: DBFC0040 BE00007F
	ds_load_b128 v[200:203], v127 offset:80                    // 0000001C1E28: DBFC0050 C800007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C1E30: BF89FC57
	v_fma_mixlo_f16 v184, v196, s22, 0                         // 0000001C1E34: CC2100B8 02002DC4
	v_fma_mixhi_f16 v184, v197, s22, 0                         // 0000001C1E3C: CC2200B8 02002DC5
	ds_load_b128 v[194:197], v127 offset:96                    // 0000001C1E44: DBFC0060 C200007F
	ds_load_b128 v[204:207], v127 offset:112                   // 0000001C1E4C: DBFC0070 CC00007F
	v_fma_mixlo_f16 v1, v180, s22, 0                           // 0000001C1E54: CC210001 02002DB4
	v_fma_mixhi_f16 v1, v181, s22, 0                           // 0000001C1E5C: CC220001 02002DB5
	v_fma_mixlo_f16 v2, v182, s22, 0                           // 0000001C1E64: CC210002 02002DB6
	v_fma_mixhi_f16 v2, v183, s22, 0                           // 0000001C1E6C: CC220002 02002DB7
	v_fma_mixhi_f16 v3, v185, s22, 0                           // 0000001C1E74: CC220003 02002DB9
	s_waitcnt lgkmcnt(6)                                       // 0000001C1E7C: BF89FC67
	v_fma_mixlo_f16 v180, v17, s22, 0                          // 0000001C1E80: CC2100B4 02002D11
	v_fma_mixhi_f16 v180, v18, s22, 0                          // 0000001C1E88: CC2200B4 02002D12
	v_fma_mixlo_f16 v181, v19, s22, 0                          // 0000001C1E90: CC2100B5 02002D13
	v_fma_mixhi_f16 v181, v20, s22, 0                          // 0000001C1E98: CC2200B5 02002D14
	s_waitcnt lgkmcnt(5)                                       // 0000001C1EA0: BF89FC57
	v_fma_mixlo_f16 v182, v21, s22, 0                          // 0000001C1EA4: CC2100B6 02002D15
	v_fma_mixhi_f16 v182, v22, s22, 0                          // 0000001C1EAC: CC2200B6 02002D16
	v_fma_mixlo_f16 v183, v23, s22, 0                          // 0000001C1EB4: CC2100B7 02002D17
	v_fma_mixhi_f16 v183, v24, s22, 0                          // 0000001C1EBC: CC2200B7 02002D18
	v_fma_mixlo_f16 v185, v198, s22, 0                         // 0000001C1EC4: CC2100B9 02002DC6
	v_fma_mixhi_f16 v185, v199, s22, 0                         // 0000001C1ECC: CC2200B9 02002DC7
	s_waitcnt lgkmcnt(4)                                       // 0000001C1ED4: BF89FC47
	v_fma_mixlo_f16 v186, v186, s22, 0                         // 0000001C1ED8: CC2100BA 02002DBA
	v_fma_mixhi_f16 v186, v187, s22, 0                         // 0000001C1EE0: CC2200BA 02002DBB
	v_fma_mixlo_f16 v187, v188, s22, 0                         // 0000001C1EE8: CC2100BB 02002DBC
	v_fma_mixhi_f16 v187, v189, s22, 0                         // 0000001C1EF0: CC2200BB 02002DBD
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001C1EF8: CC404011 1D060361
	ds_load_b128 v[208:211], v127 offset:17008                 // 0000001C1F00: DBFC4270 D000007F
	ds_load_b128 v[212:215], v127 offset:25408                 // 0000001C1F08: DBFC6340 D400007F
	ds_load_b128 v[216:219], v127 offset:25424                 // 0000001C1F10: DBFC6350 D800007F
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[180:187], v[65:72]// 0000001C1F18: CC404001 1D076961
	ds_load_b128 v[180:183], v127 offset:8512                  // 0000001C1F20: DBFC2140 B400007F
	ds_load_b128 v[184:187], v127 offset:8528                  // 0000001C1F28: DBFC2150 B800007F
	s_waitcnt lgkmcnt(8)                                       // 0000001C1F30: BF89FC87
	v_fma_mixlo_f16 v97, v190, s22, 0                          // 0000001C1F34: CC210061 02002DBE
	v_fma_mixhi_f16 v97, v191, s22, 0                          // 0000001C1F3C: CC220061 02002DBF
	v_fma_mixlo_f16 v98, v192, s22, 0                          // 0000001C1F44: CC210062 02002DC0
	v_fma_mixhi_f16 v98, v193, s22, 0                          // 0000001C1F4C: CC220062 02002DC1
	s_waitcnt lgkmcnt(7)                                       // 0000001C1F54: BF89FC77
	v_fma_mixlo_f16 v99, v200, s22, 0                          // 0000001C1F58: CC210063 02002DC8
	v_fma_mixhi_f16 v99, v201, s22, 0                          // 0000001C1F60: CC220063 02002DC9
	v_fma_mixlo_f16 v100, v202, s22, 0                         // 0000001C1F68: CC210064 02002DCA
	v_fma_mixhi_f16 v100, v203, s22, 0                         // 0000001C1F70: CC220064 02002DCB
	ds_load_b128 v[188:191], v127 offset:8544                  // 0000001C1F78: DBFC2160 BC00007F
	s_waitcnt lgkmcnt(7)                                       // 0000001C1F80: BF89FC77
	v_fma_mixlo_f16 v101, v194, s22, 0                         // 0000001C1F84: CC210065 02002DC2
	v_fma_mixhi_f16 v101, v195, s22, 0                         // 0000001C1F8C: CC220065 02002DC3
	v_fma_mixlo_f16 v102, v196, s22, 0                         // 0000001C1F94: CC210066 02002DC4
	v_fma_mixhi_f16 v102, v197, s22, 0                         // 0000001C1F9C: CC220066 02002DC5
	ds_load_b128 v[192:195], v127 offset:8560                  // 0000001C1FA4: DBFC2170 C000007F
	s_waitcnt lgkmcnt(7)                                       // 0000001C1FAC: BF89FC77
	v_fma_mixlo_f16 v103, v204, s22, 0                         // 0000001C1FB0: CC210067 02002DCC
	v_fma_mixhi_f16 v103, v205, s22, 0                         // 0000001C1FB8: CC220067 02002DCD
	v_fma_mixlo_f16 v104, v206, s22, 0                         // 0000001C1FC0: CC210068 02002DCE
	v_fma_mixhi_f16 v104, v207, s22, 0                         // 0000001C1FC8: CC220068 02002DCF
	ds_load_b128 v[196:199], v127 offset:16960                 // 0000001C1FD0: DBFC4240 C400007F
	ds_load_b128 v[200:203], v127 offset:16976                 // 0000001C1FD8: DBFC4250 C800007F
	ds_load_b128 v[204:207], v127 offset:16992                 // 0000001C1FE0: DBFC4260 CC00007F
	s_waitcnt lgkmcnt(6)                                       // 0000001C1FE8: BF89FC67
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001C1FEC: CC2100B4 02002DB4
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001C1FF4: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001C1FFC: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001C2004: CC2200B5 02002DB7
	s_waitcnt lgkmcnt(5)                                       // 0000001C200C: BF89FC57
	v_fma_mixhi_f16 v182, v185, s22, 0                         // 0000001C2010: CC2200B6 02002DB9
	v_fma_mixlo_f16 v183, v186, s22, 0                         // 0000001C2018: CC2100B7 02002DBA
	ds_load_b128 v[220:223], v127 offset:25440                 // 0000001C2020: DBFC6360 DC00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C2028: BF89FC57
	v_fma_mixhi_f16 v185, v191, s22, 0                         // 0000001C202C: CC2200B9 02002DBF
	v_fma_mixlo_f16 v182, v184, s22, 0                         // 0000001C2034: CC2100B6 02002DB8
	v_fma_mixhi_f16 v183, v187, s22, 0                         // 0000001C203C: CC2200B7 02002DBB
	v_fma_mixlo_f16 v184, v188, s22, 0                         // 0000001C2044: CC2100B8 02002DBC
	v_fma_mixhi_f16 v184, v189, s22, 0                         // 0000001C204C: CC2200B8 02002DBD
	s_waitcnt lgkmcnt(4)                                       // 0000001C2054: BF89FC47
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001C2058: CC2100BA 02002DC0
	v_fma_mixlo_f16 v185, v190, s22, 0                         // 0000001C2060: CC2100B9 02002DBE
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001C2068: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001C2070: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001C2078: CC2200BB 02002DC3
	s_waitcnt lgkmcnt(3)                                       // 0000001C2080: BF89FC37
	v_fma_mixlo_f16 v188, v196, s22, 0                         // 0000001C2084: CC2100BC 02002DC4
	s_waitcnt lgkmcnt(2)                                       // 0000001C208C: BF89FC27
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001C2090: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001C2098: CC2200BF 02002DCB
	s_waitcnt lgkmcnt(1)                                       // 0000001C20A0: BF89FC17
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001C20A4: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001C20AC: CC2200C0 02002DCD
	ds_load_b128 v[202:205], v127 offset:25456                 // 0000001C20B4: DBFC6370 CA00007F
	v_fma_mixhi_f16 v188, v197, s22, 0                         // 0000001C20BC: CC2200BC 02002DC5
	v_fma_mixlo_f16 v189, v198, s22, 0                         // 0000001C20C4: CC2100BD 02002DC6
	v_fma_mixhi_f16 v189, v199, s22, 0                         // 0000001C20CC: CC2200BD 02002DC7
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001C20D4: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001C20DC: CC2200BE 02002DC9
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001C20E4: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001C20EC: CC2200C1 02002DCF
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001C20F4: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001C20FC: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001C2104: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001C210C: CC2200C3 02002DD3
	v_fma_mixlo_f16 v196, v212, s22, 0                         // 0000001C2114: CC2100C4 02002DD4
	v_fma_mixhi_f16 v196, v213, s22, 0                         // 0000001C211C: CC2200C4 02002DD5
	v_fma_mixlo_f16 v197, v214, s22, 0                         // 0000001C2124: CC2100C5 02002DD6
	v_fma_mixhi_f16 v197, v215, s22, 0                         // 0000001C212C: CC2200C5 02002DD7
	v_fma_mixlo_f16 v198, v216, s22, 0                         // 0000001C2134: CC2100C6 02002DD8
	v_fma_mixhi_f16 v198, v217, s22, 0                         // 0000001C213C: CC2200C6 02002DD9
	v_fma_mixlo_f16 v199, v218, s22, 0                         // 0000001C2144: CC2100C7 02002DDA
	v_fma_mixhi_f16 v199, v219, s22, 0                         // 0000001C214C: CC2200C7 02002DDB
	s_waitcnt lgkmcnt(1)                                       // 0000001C2154: BF89FC17
	v_fma_mixlo_f16 v200, v220, s22, 0                         // 0000001C2158: CC2100C8 02002DDC
	v_fma_mixhi_f16 v200, v221, s22, 0                         // 0000001C2160: CC2200C8 02002DDD
	v_fma_mixlo_f16 v201, v222, s22, 0                         // 0000001C2168: CC2100C9 02002DDE
	v_fma_mixhi_f16 v201, v223, s22, 0                         // 0000001C2170: CC2200C9 02002DDF
	s_waitcnt lgkmcnt(0)                                       // 0000001C2178: BF89FC07
	v_fma_mixlo_f16 v202, v202, s22, 0                         // 0000001C217C: CC2100CA 02002DCA
	v_fma_mixhi_f16 v202, v203, s22, 0                         // 0000001C2184: CC2200CA 02002DCB
	v_fma_mixlo_f16 v203, v204, s22, 0                         // 0000001C218C: CC2100CB 02002DCC
	v_fma_mixhi_f16 v203, v205, s22, 0                         // 0000001C2194: CC2200CB 02002DCD
	ds_load_b128 v[206:209], v127 offset:128                   // 0000001C219C: DBFC0080 CE00007F
	ds_load_b128 v[210:213], v127 offset:144                   // 0000001C21A4: DBFC0090 D200007F
	ds_load_b128 v[214:217], v127 offset:160                   // 0000001C21AC: DBFC00A0 D600007F
	s_waitcnt vmcnt(12)                                        // 0000001C21B4: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001C21B8: CC404019 1C66C359
	ds_load_b128 v[97:100], v127 offset:176                    // 0000001C21C0: DBFC00B0 6100007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[180:187], v[9:16]// 0000001C21C8: CC404009 1C276959
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[188:195], v[17:24]// 0000001C21D0: CC404011 1C477959
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[196:203], v[1:8]// 0000001C21D8: CC404001 1C078959
	ds_load_b128 v[101:104], v127 offset:8576                  // 0000001C21E0: DBFC2180 6500007F
	ds_load_b128 v[180:183], v127 offset:8592                  // 0000001C21E8: DBFC2190 B400007F
	ds_load_b128 v[184:187], v127 offset:8608                  // 0000001C21F0: DBFC21A0 B800007F
	ds_load_b128 v[188:191], v127 offset:8624                  // 0000001C21F8: DBFC21B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17024                 // 0000001C2200: DBFC4280 C000007F
	ds_load_b128 v[196:199], v127 offset:17040                 // 0000001C2208: DBFC4290 C400007F
	ds_load_b128 v[200:203], v127 offset:17056                 // 0000001C2210: DBFC42A0 C800007F
	s_mul_i32 s13, s23, 48                                     // 0000001C2218: 960DB017
	s_mul_hi_u32 s14, s23, 48                                  // 0000001C221C: 968EB017
	s_add_u32 s48, s13, s2                                     // 0000001C2220: 8030020D
	s_addc_u32 s49, s14, s3                                    // 0000001C2224: 8231030E
	ds_load_b128 v[220:223], v127 offset:25648                 // 0000001C2228: DBFC6430 DC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001C2230: BF89FCB7
	v_fma_mixlo_f16 v89, v206, s22, 0                          // 0000001C2234: CC210059 02002DCE
	v_fma_mixhi_f16 v89, v207, s22, 0                          // 0000001C223C: CC220059 02002DCF
	v_fma_mixlo_f16 v90, v208, s22, 0                          // 0000001C2244: CC21005A 02002DD0
	v_fma_mixhi_f16 v90, v209, s22, 0                          // 0000001C224C: CC22005A 02002DD1
	s_waitcnt lgkmcnt(10)                                      // 0000001C2254: BF89FCA7
	v_fma_mixlo_f16 v91, v210, s22, 0                          // 0000001C2258: CC21005B 02002DD2
	v_fma_mixhi_f16 v91, v211, s22, 0                          // 0000001C2260: CC22005B 02002DD3
	s_waitcnt lgkmcnt(8)                                       // 0000001C2268: BF89FC87
	v_fma_mixhi_f16 v95, v98, s22, 0                           // 0000001C226C: CC22005F 02002D62
	v_fma_mixlo_f16 v96, v99, s22, 0                           // 0000001C2274: CC210060 02002D63
	v_fma_mixhi_f16 v96, v100, s22, 0                          // 0000001C227C: CC220060 02002D64
	s_waitcnt lgkmcnt(7)                                       // 0000001C2284: BF89FC77
	v_fma_mixlo_f16 v98, v103, s22, 0                          // 0000001C2288: CC210062 02002D67
	v_fma_mixhi_f16 v98, v104, s22, 0                          // 0000001C2290: CC220062 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001C2298: BF89FC67
	v_fma_mixlo_f16 v99, v180, s22, 0                          // 0000001C229C: CC210063 02002DB4
	v_fma_mixhi_f16 v99, v181, s22, 0                          // 0000001C22A4: CC220063 02002DB5
	v_fma_mixlo_f16 v100, v182, s22, 0                         // 0000001C22AC: CC210064 02002DB6
	v_fma_mixhi_f16 v100, v183, s22, 0                         // 0000001C22B4: CC220064 02002DB7
	s_waitcnt lgkmcnt(4)                                       // 0000001C22BC: BF89FC47
	v_fma_mixlo_f16 v103, v188, s22, 0                         // 0000001C22C0: CC210067 02002DBC
	ds_load_b128 v[204:207], v127 offset:17072                 // 0000001C22C8: DBFC42B0 CC00007F
	v_fma_mixhi_f16 v103, v189, s22, 0                         // 0000001C22D0: CC220067 02002DBD
	v_fma_mixlo_f16 v104, v190, s22, 0                         // 0000001C22D8: CC210068 02002DBE
	v_fma_mixhi_f16 v104, v191, s22, 0                         // 0000001C22E0: CC220068 02002DBF
	ds_load_b128 v[188:191], v127 offset:25472                 // 0000001C22E8: DBFC6380 BC00007F
	ds_load_b128 v[208:211], v127 offset:25488                 // 0000001C22F0: DBFC6390 D000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001C22F8: BF89FC67
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001C22FC: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001C2304: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001C230C: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001C2314: CC2200B5 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001C231C: BF89FC57
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001C2320: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001C2328: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001C2330: CC2100B7 02002DC6
	ds_load_b128 v[192:195], v127 offset:25504                 // 0000001C2338: DBFC63A0 C000007F
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001C2340: CC2200B7 02002DC7
	ds_load_b128 v[196:199], v127 offset:25520                 // 0000001C2348: DBFC63B0 C400007F
	v_fma_mixlo_f16 v92, v212, s22, 0                          // 0000001C2350: CC21005C 02002DD4
	v_fma_mixhi_f16 v92, v213, s22, 0                          // 0000001C2358: CC22005C 02002DD5
	v_fma_mixlo_f16 v93, v214, s22, 0                          // 0000001C2360: CC21005D 02002DD6
	v_fma_mixhi_f16 v93, v215, s22, 0                          // 0000001C2368: CC22005D 02002DD7
	v_fma_mixlo_f16 v94, v216, s22, 0                          // 0000001C2370: CC21005E 02002DD8
	v_fma_mixhi_f16 v94, v217, s22, 0                          // 0000001C2378: CC22005E 02002DD9
	v_fma_mixlo_f16 v95, v97, s22, 0                           // 0000001C2380: CC21005F 02002D61
	v_fma_mixlo_f16 v97, v101, s22, 0                          // 0000001C2388: CC210061 02002D65
	v_fma_mixhi_f16 v97, v102, s22, 0                          // 0000001C2390: CC220061 02002D66
	v_fma_mixlo_f16 v101, v184, s22, 0                         // 0000001C2398: CC210065 02002DB8
	v_fma_mixhi_f16 v101, v185, s22, 0                         // 0000001C23A0: CC220065 02002DB9
	v_fma_mixlo_f16 v102, v186, s22, 0                         // 0000001C23A8: CC210066 02002DBA
	v_fma_mixhi_f16 v102, v187, s22, 0                         // 0000001C23B0: CC220066 02002DBB
	s_waitcnt lgkmcnt(6)                                       // 0000001C23B8: BF89FC67
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001C23BC: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001C23C4: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001C23CC: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001C23D4: CC2200B9 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001C23DC: BF89FC47
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001C23E0: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001C23E8: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001C23F0: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001C23F8: CC2200BB 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001C2400: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001C2404: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001C240C: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001C2414: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001C241C: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001C2424: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001C2428: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001C2430: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001C2438: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001C2440: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001C2448: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001C244C: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001C2454: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001C245C: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001C2464: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001C246C: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001C2470: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001C2478: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001C2480: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001C2488: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:192                   // 0000001C2490: DBFC00C0 C800007F
	ds_load_b128 v[204:207], v127 offset:208                   // 0000001C2498: DBFC00D0 CC00007F
	ds_load_b128 v[208:211], v127 offset:224                   // 0000001C24A0: DBFC00E0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001C24A8: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001C24AC: CC404019 1C66B351
	ds_load_b128 v[89:92], v127 offset:240                     // 0000001C24B4: DBFC00F0 5900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001C24BC: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[180:187], v[17:24]// 0000001C24C4: CC404011 1C476951
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[188:195], v[1:8]// 0000001C24CC: CC404001 1C077951
	ds_load_b128 v[93:96], v127 offset:8640                    // 0000001C24D4: DBFC21C0 5D00007F
	ds_load_b128 v[97:100], v127 offset:8656                   // 0000001C24DC: DBFC21D0 6100007F
	ds_load_b128 v[101:104], v127 offset:8672                  // 0000001C24E4: DBFC21E0 6500007F
	ds_load_b128 v[180:183], v127 offset:8688                  // 0000001C24EC: DBFC21F0 B400007F
	ds_load_b128 v[184:187], v127 offset:17088                 // 0000001C24F4: DBFC42C0 B800007F
	ds_load_b128 v[188:191], v127 offset:17104                 // 0000001C24FC: DBFC42D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17120                 // 0000001C2504: DBFC42E0 C000007F
	ds_load_b128 v[196:199], v127 offset:17136                 // 0000001C250C: DBFC42F0 C400007F
	s_lshl_b64 s[48:49], s[48:49], 13                          // 0000001C2514: 84B08D30
	ds_load_b128 v[212:215], v127 offset:25616                 // 0000001C2518: DBFC6410 D400007F
	.long 0xd7000d74                                           // 0000001C2520: D7000D74
	v_cndmask_b32_e32 v0, v137, v48, vcc_lo                    // 0000001C2524: 02006189
	s_waitcnt lgkmcnt(12)                                      // 0000001C2528: BF89FCC7
	v_fma_mixlo_f16 v81, v200, s22, 0                          // 0000001C252C: CC210051 02002DC8
	v_fma_mixhi_f16 v81, v201, s22, 0                          // 0000001C2534: CC220051 02002DC9
	v_fma_mixlo_f16 v82, v202, s22, 0                          // 0000001C253C: CC210052 02002DCA
	v_fma_mixhi_f16 v82, v203, s22, 0                          // 0000001C2544: CC220052 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001C254C: BF89FC97
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001C2550: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001C2558: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001C2560: CC220058 02002D5C
	ds_load_b128 v[200:203], v127 offset:25552                 // 0000001C2568: DBFC63D0 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001C2570: BF89FC97
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001C2574: CC21005A 02002D5F
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001C257C: CC22005A 02002D60
	s_waitcnt lgkmcnt(8)                                       // 0000001C2584: BF89FC87
	v_fma_mixlo_f16 v91, v97, s22, 0                           // 0000001C2588: CC21005B 02002D61
	v_fma_mixhi_f16 v91, v98, s22, 0                           // 0000001C2590: CC22005B 02002D62
	v_fma_mixlo_f16 v92, v99, s22, 0                           // 0000001C2598: CC21005C 02002D63
	v_fma_mixhi_f16 v92, v100, s22, 0                          // 0000001C25A0: CC22005C 02002D64
	s_waitcnt lgkmcnt(6)                                       // 0000001C25A8: BF89FC67
	v_fma_mixlo_f16 v95, v180, s22, 0                          // 0000001C25AC: CC21005F 02002DB4
	v_fma_mixhi_f16 v95, v181, s22, 0                          // 0000001C25B4: CC22005F 02002DB5
	v_fma_mixlo_f16 v96, v182, s22, 0                          // 0000001C25BC: CC210060 02002DB6
	v_fma_mixhi_f16 v96, v183, s22, 0                          // 0000001C25C4: CC220060 02002DB7
	ds_load_b128 v[180:183], v127 offset:25536                 // 0000001C25CC: DBFC63C0 B400007F
	s_waitcnt lgkmcnt(6)                                       // 0000001C25D4: BF89FC67
	v_fma_mixlo_f16 v97, v184, s22, 0                          // 0000001C25D8: CC210061 02002DB8
	v_fma_mixhi_f16 v97, v185, s22, 0                          // 0000001C25E0: CC220061 02002DB9
	v_fma_mixlo_f16 v98, v186, s22, 0                          // 0000001C25E8: CC210062 02002DBA
	v_fma_mixhi_f16 v98, v187, s22, 0                          // 0000001C25F0: CC220062 02002DBB
	s_waitcnt lgkmcnt(5)                                       // 0000001C25F8: BF89FC57
	v_fma_mixlo_f16 v99, v188, s22, 0                          // 0000001C25FC: CC210063 02002DBC
	v_fma_mixhi_f16 v99, v189, s22, 0                          // 0000001C2604: CC220063 02002DBD
	v_fma_mixlo_f16 v100, v190, s22, 0                         // 0000001C260C: CC210064 02002DBE
	v_fma_mixhi_f16 v100, v191, s22, 0                         // 0000001C2614: CC220064 02002DBF
	ds_load_b128 v[184:187], v127 offset:25568                 // 0000001C261C: DBFC63E0 B800007F
	ds_load_b128 v[188:191], v127 offset:25584                 // 0000001C2624: DBFC63F0 BC00007F
	v_fma_mixlo_f16 v83, v204, s22, 0                          // 0000001C262C: CC210053 02002DCC
	v_fma_mixhi_f16 v83, v205, s22, 0                          // 0000001C2634: CC220053 02002DCD
	v_fma_mixlo_f16 v84, v206, s22, 0                          // 0000001C263C: CC210054 02002DCE
	v_fma_mixhi_f16 v84, v207, s22, 0                          // 0000001C2644: CC220054 02002DCF
	v_fma_mixlo_f16 v85, v208, s22, 0                          // 0000001C264C: CC210055 02002DD0
	v_fma_mixhi_f16 v85, v209, s22, 0                          // 0000001C2654: CC220055 02002DD1
	v_fma_mixlo_f16 v86, v210, s22, 0                          // 0000001C265C: CC210056 02002DD2
	v_fma_mixhi_f16 v86, v211, s22, 0                          // 0000001C2664: CC220056 02002DD3
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001C266C: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001C2674: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001C267C: CC220059 02002D5E
	v_fma_mixlo_f16 v93, v101, s22, 0                          // 0000001C2684: CC21005D 02002D65
	v_fma_mixhi_f16 v93, v102, s22, 0                          // 0000001C268C: CC22005D 02002D66
	v_fma_mixlo_f16 v94, v103, s22, 0                          // 0000001C2694: CC21005E 02002D67
	v_fma_mixhi_f16 v94, v104, s22, 0                          // 0000001C269C: CC22005E 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001C26A4: BF89FC67
	v_fma_mixlo_f16 v101, v192, s22, 0                         // 0000001C26A8: CC210065 02002DC0
	v_fma_mixhi_f16 v101, v193, s22, 0                         // 0000001C26B0: CC220065 02002DC1
	v_fma_mixlo_f16 v102, v194, s22, 0                         // 0000001C26B8: CC210066 02002DC2
	v_fma_mixhi_f16 v102, v195, s22, 0                         // 0000001C26C0: CC220066 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001C26C8: BF89FC57
	v_fma_mixlo_f16 v103, v196, s22, 0                         // 0000001C26CC: CC210067 02002DC4
	v_fma_mixhi_f16 v103, v197, s22, 0                         // 0000001C26D4: CC220067 02002DC5
	v_fma_mixlo_f16 v104, v198, s22, 0                         // 0000001C26DC: CC210068 02002DC6
	v_fma_mixhi_f16 v104, v199, s22, 0                         // 0000001C26E4: CC220068 02002DC7
	s_waitcnt vmcnt(8)                                         // 0000001C26EC: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001C26F0: CC404019 1C66A349
	ds_load_b128 v[81:84], v127 offset:8704                    // 0000001C26F8: DBFC2200 5100007F
	ds_load_b128 v[85:88], v127 offset:8720                    // 0000001C2700: DBFC2210 5500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001C2708: BF89FC47
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001C270C: CC2100B4 02002DB4
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001C2714: CC404011 1C46C349
	ds_load_b128 v[102:105], v127 offset:8736                  // 0000001C271C: DBFC2220 6600007F
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001C2724: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001C272C: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001C2734: CC2200B5 02002DB7
	v_fma_mixlo_f16 v182, v200, s22, 0                         // 0000001C273C: CC2100B6 02002DC8
	v_fma_mixhi_f16 v182, v201, s22, 0                         // 0000001C2744: CC2200B6 02002DC9
	v_fma_mixlo_f16 v183, v202, s22, 0                         // 0000001C274C: CC2100B7 02002DCA
	v_fma_mixhi_f16 v183, v203, s22, 0                         // 0000001C2754: CC2200B7 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001C275C: BF89FC47
	v_fma_mixlo_f16 v184, v184, s22, 0                         // 0000001C2760: CC2100B8 02002DB8
	v_fma_mixhi_f16 v184, v185, s22, 0                         // 0000001C2768: CC2200B8 02002DB9
	v_fma_mixlo_f16 v185, v186, s22, 0                         // 0000001C2770: CC2100B9 02002DBA
	v_fma_mixhi_f16 v185, v187, s22, 0                         // 0000001C2778: CC2200B9 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001C2780: BF89FC37
	v_fma_mixlo_f16 v186, v188, s22, 0                         // 0000001C2784: CC2100BA 02002DBC
	v_fma_mixhi_f16 v186, v189, s22, 0                         // 0000001C278C: CC2200BA 02002DBD
	v_fma_mixlo_f16 v187, v190, s22, 0                         // 0000001C2794: CC2100BB 02002DBE
	v_fma_mixhi_f16 v187, v191, s22, 0                         // 0000001C279C: CC2200BB 02002DBF
	v_add_co_ci_u32_e64 v117, null, s49, v138, s13             // 0000001C27A4: D5207C75 00371431
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001C27AC: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001C27B4: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001C27B8: CC210051 02002D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[180:187], v[1:8]// 0000001C27C0: CC404001 1C076949
	s_clause 0x1                                               // 0000001C27C8: BF850001
	global_load_b128 v[184:187], v[116:117], off offset:16     // 0000001C27CC: DC5E0010 B87C0074
	global_load_b128 v[180:183], v[116:117], off               // 0000001C27D4: DC5E0000 B47C0074
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001C27DC: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001C27E4: CC210052 02002D53
	ds_load_b128 v[188:191], v127 offset:8752                  // 0000001C27EC: DBFC2230 BC00007F
	s_waitcnt lgkmcnt(2)                                       // 0000001C27F4: BF89FC27
	v_fma_mixlo_f16 v83, v85, s22, 0                           // 0000001C27F8: CC210053 02002D55
	v_fma_mixhi_f16 v83, v86, s22, 0                           // 0000001C2800: CC220053 02002D56
	s_waitcnt lgkmcnt(1)                                       // 0000001C2808: BF89FC17
	v_fma_mixlo_f16 v85, v102, s22, 0                          // 0000001C280C: CC210055 02002D66
	v_fma_mixhi_f16 v85, v103, s22, 0                          // 0000001C2814: CC220055 02002D67
	v_fma_mixlo_f16 v86, v104, s22, 0                          // 0000001C281C: CC210056 02002D68
	s_clause 0x3                                               // 0000001C2824: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 0000001C2828: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 0000001C2830: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 0000001C2838: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 0000001C2840: DC5E0060 597C0074
	ds_load_b128 v[192:195], v127 offset:256                   // 0000001C2848: DBFC0100 C000007F
	ds_load_b128 v[196:199], v127 offset:272                   // 0000001C2850: DBFC0110 C400007F
	ds_load_b128 v[200:203], v127 offset:288                   // 0000001C2858: DBFC0120 C800007F
	ds_load_b128 v[204:207], v127 offset:304                   // 0000001C2860: DBFC0130 CC00007F
	ds_load_b128 v[208:211], v127 offset:25600                 // 0000001C2868: DBFC6400 D000007F
	ds_load_b128 v[216:219], v127 offset:25632                 // 0000001C2870: DBFC6420 D800007F
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001C2878: CC220052 02002D54
	v_fma_mixlo_f16 v84, v87, s22, 0                           // 0000001C2880: CC210054 02002D57
	v_fma_mixhi_f16 v84, v88, s22, 0                           // 0000001C2888: CC220054 02002D58
	v_fma_mixhi_f16 v86, v105, s22, 0                          // 0000001C2890: CC220056 02002D69
	s_waitcnt lgkmcnt(6)                                       // 0000001C2898: BF89FC67
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001C289C: CC210057 02002DBC
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001C28A4: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001C28AC: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001C28B4: CC220058 02002DBF
	s_waitcnt lgkmcnt(5)                                       // 0000001C28BC: BF89FC57
	v_fma_mixlo_f16 v73, v192, s22, 0                          // 0000001C28C0: CC210049 02002DC0
	v_fma_mixhi_f16 v73, v193, s22, 0                          // 0000001C28C8: CC220049 02002DC1
	v_fma_mixlo_f16 v74, v194, s22, 0                          // 0000001C28D0: CC21004A 02002DC2
	v_fma_mixhi_f16 v74, v195, s22, 0                          // 0000001C28D8: CC22004A 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001C28E0: BF89FC47
	v_fma_mixlo_f16 v75, v196, s22, 0                          // 0000001C28E4: CC21004B 02002DC4
	v_fma_mixhi_f16 v75, v197, s22, 0                          // 0000001C28EC: CC22004B 02002DC5
	v_fma_mixlo_f16 v76, v198, s22, 0                          // 0000001C28F4: CC21004C 02002DC6
	v_fma_mixhi_f16 v76, v199, s22, 0                          // 0000001C28FC: CC22004C 02002DC7
	s_waitcnt lgkmcnt(3)                                       // 0000001C2904: BF89FC37
	v_fma_mixlo_f16 v77, v200, s22, 0                          // 0000001C2908: CC21004D 02002DC8
	v_fma_mixhi_f16 v77, v201, s22, 0                          // 0000001C2910: CC22004D 02002DC9
	v_fma_mixlo_f16 v78, v202, s22, 0                          // 0000001C2918: CC21004E 02002DCA
	v_fma_mixhi_f16 v78, v203, s22, 0                          // 0000001C2920: CC22004E 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001C2928: BF89FC27
	v_fma_mixlo_f16 v79, v204, s22, 0                          // 0000001C292C: CC21004F 02002DCC
	v_fma_mixhi_f16 v79, v205, s22, 0                          // 0000001C2934: CC22004F 02002DCD
	v_fma_mixlo_f16 v80, v206, s22, 0                          // 0000001C293C: CC210050 02002DCE
	v_fma_mixhi_f16 v80, v207, s22, 0                          // 0000001C2944: CC220050 02002DCF
	ds_load_b128 v[192:195], v127 offset:17152                 // 0000001C294C: DBFC4300 C000007F
	ds_load_b128 v[196:199], v127 offset:17168                 // 0000001C2954: DBFC4310 C400007F
	ds_load_b128 v[200:203], v127 offset:17184                 // 0000001C295C: DBFC4320 C800007F
	ds_load_b128 v[204:207], v127 offset:17200                 // 0000001C2964: DBFC4330 CC00007F
	s_waitcnt vmcnt(12)                                        // 0000001C296C: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001C2970: CC404019 1C669339
	ds_load_b128 v[73:76], v127 offset:368                     // 0000001C2978: DBFC0170 4900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001C2980: CC404009 1C26A339
	ds_load_b128 v[77:80], v127 offset:8768                    // 0000001C2988: DBFC2240 4D00007F
	ds_load_b128 v[81:84], v127 offset:8784                    // 0000001C2990: DBFC2250 5100007F
	ds_load_b128 v[85:88], v127 offset:8800                    // 0000001C2998: DBFC2260 5500007F
	s_waitcnt lgkmcnt(7)                                       // 0000001C29A0: BF89FC77
	v_fma_mixlo_f16 v188, v192, s22, 0                         // 0000001C29A4: CC2100BC 02002DC0
	v_fma_mixhi_f16 v188, v193, s22, 0                         // 0000001C29AC: CC2200BC 02002DC1
	v_fma_mixlo_f16 v189, v194, s22, 0                         // 0000001C29B4: CC2100BD 02002DC2
	v_fma_mixhi_f16 v189, v195, s22, 0                         // 0000001C29BC: CC2200BD 02002DC3
	s_waitcnt lgkmcnt(6)                                       // 0000001C29C4: BF89FC67
	v_fma_mixlo_f16 v190, v196, s22, 0                         // 0000001C29C8: CC2100BE 02002DC4
	v_fma_mixhi_f16 v190, v197, s22, 0                         // 0000001C29D0: CC2200BE 02002DC5
	v_fma_mixlo_f16 v191, v198, s22, 0                         // 0000001C29D8: CC2100BF 02002DC6
	v_fma_mixhi_f16 v191, v199, s22, 0                         // 0000001C29E0: CC2200BF 02002DC7
	s_waitcnt lgkmcnt(5)                                       // 0000001C29E8: BF89FC57
	v_fma_mixlo_f16 v192, v200, s22, 0                         // 0000001C29EC: CC2100C0 02002DC8
	v_fma_mixhi_f16 v192, v201, s22, 0                         // 0000001C29F4: CC2200C0 02002DC9
	v_fma_mixlo_f16 v193, v202, s22, 0                         // 0000001C29FC: CC2100C1 02002DCA
	v_fma_mixhi_f16 v193, v203, s22, 0                         // 0000001C2A04: CC2200C1 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001C2A0C: BF89FC47
	v_fma_mixlo_f16 v194, v204, s22, 0                         // 0000001C2A10: CC2100C2 02002DCC
	v_fma_mixhi_f16 v194, v205, s22, 0                         // 0000001C2A18: CC2200C2 02002DCD
	v_fma_mixlo_f16 v195, v206, s22, 0                         // 0000001C2A20: CC2100C3 02002DCE
	v_fma_mixhi_f16 v195, v207, s22, 0                         // 0000001C2A28: CC2200C3 02002DCF
	v_fma_mixlo_f16 v196, v208, s22, 0                         // 0000001C2A30: CC2100C4 02002DD0
	v_fma_mixhi_f16 v196, v209, s22, 0                         // 0000001C2A38: CC2200C4 02002DD1
	v_fma_mixlo_f16 v197, v210, s22, 0                         // 0000001C2A40: CC2100C5 02002DD2
	v_fma_mixhi_f16 v197, v211, s22, 0                         // 0000001C2A48: CC2200C5 02002DD3
	v_fma_mixlo_f16 v198, v212, s22, 0                         // 0000001C2A50: CC2100C6 02002DD4
	v_fma_mixhi_f16 v198, v213, s22, 0                         // 0000001C2A58: CC2200C6 02002DD5
	v_fma_mixlo_f16 v199, v214, s22, 0                         // 0000001C2A60: CC2100C7 02002DD6
	v_fma_mixhi_f16 v199, v215, s22, 0                         // 0000001C2A68: CC2200C7 02002DD7
	v_fma_mixlo_f16 v200, v216, s22, 0                         // 0000001C2A70: CC2100C8 02002DD8
	v_fma_mixhi_f16 v200, v217, s22, 0                         // 0000001C2A78: CC2200C8 02002DD9
	v_fma_mixlo_f16 v201, v218, s22, 0                         // 0000001C2A80: CC2100C9 02002DDA
	v_fma_mixhi_f16 v201, v219, s22, 0                         // 0000001C2A88: CC2200C9 02002DDB
	v_fma_mixlo_f16 v202, v220, s22, 0                         // 0000001C2A90: CC2100CA 02002DDC
	v_fma_mixhi_f16 v202, v221, s22, 0                         // 0000001C2A98: CC2200CA 02002DDD
	v_fma_mixlo_f16 v203, v222, s22, 0                         // 0000001C2AA0: CC2100CB 02002DDE
	v_fma_mixhi_f16 v203, v223, s22, 0                         // 0000001C2AA8: CC2200CB 02002DDF
	ds_load_b128 v[204:207], v127 offset:320                   // 0000001C2AB0: DBFC0140 CC00007F
	ds_load_b128 v[208:211], v127 offset:336                   // 0000001C2AB8: DBFC0150 D000007F
	ds_load_b128 v[212:215], v127 offset:352                   // 0000001C2AC0: DBFC0160 D400007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[188:195], v[17:24]// 0000001C2AC8: CC404011 1C477939
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[196:203], v[1:8]// 0000001C2AD0: CC404001 1C078939
	ds_load_b128 v[188:191], v127 offset:8816                  // 0000001C2AD8: DBFC2270 BC00007F
	ds_load_b128 v[192:195], v127 offset:17216                 // 0000001C2AE0: DBFC4340 C000007F
	ds_load_b128 v[196:199], v127 offset:17232                 // 0000001C2AE8: DBFC4350 C400007F
	s_waitcnt lgkmcnt(9)                                       // 0000001C2AF0: BF89FC97
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001C2AF4: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001C2AFC: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001C2B04: CC220040 02002D4C
	s_waitcnt lgkmcnt(8)                                       // 0000001C2B0C: BF89FC87
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001C2B10: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001C2B18: CC22004A 02002D50
	s_waitcnt lgkmcnt(7)                                       // 0000001C2B20: BF89FC77
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001C2B24: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001C2B2C: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001C2B34: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001C2B3C: CC22004C 02002D54
	ds_load_b128 v[200:203], v127 offset:17248                 // 0000001C2B44: DBFC4360 C800007F
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001C2B4C: CC21003F 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001C2B54: CC210049 02002D4D
	s_waitcnt lgkmcnt(6)                                       // 0000001C2B5C: BF89FC67
	v_fma_mixlo_f16 v57, v204, s22, 0                          // 0000001C2B60: CC210039 02002DCC
	v_fma_mixhi_f16 v57, v205, s22, 0                          // 0000001C2B68: CC220039 02002DCD
	v_fma_mixlo_f16 v58, v206, s22, 0                          // 0000001C2B70: CC21003A 02002DCE
	v_fma_mixhi_f16 v58, v207, s22, 0                          // 0000001C2B78: CC22003A 02002DCF
	s_waitcnt lgkmcnt(5)                                       // 0000001C2B80: BF89FC57
	v_fma_mixlo_f16 v59, v208, s22, 0                          // 0000001C2B84: CC21003B 02002DD0
	v_fma_mixhi_f16 v59, v209, s22, 0                          // 0000001C2B8C: CC22003B 02002DD1
	v_fma_mixlo_f16 v60, v210, s22, 0                          // 0000001C2B94: CC21003C 02002DD2
	v_fma_mixhi_f16 v60, v211, s22, 0                          // 0000001C2B9C: CC22003C 02002DD3
	s_waitcnt lgkmcnt(3)                                       // 0000001C2BA4: BF89FC37
	v_fma_mixlo_f16 v79, v188, s22, 0                          // 0000001C2BA8: CC21004F 02002DBC
	ds_load_b128 v[204:207], v127 offset:17264                 // 0000001C2BB0: DBFC4370 CC00007F
	v_fma_mixhi_f16 v79, v189, s22, 0                          // 0000001C2BB8: CC22004F 02002DBD
	v_fma_mixlo_f16 v80, v190, s22, 0                          // 0000001C2BC0: CC210050 02002DBE
	v_fma_mixhi_f16 v80, v191, s22, 0                          // 0000001C2BC8: CC220050 02002DBF
	ds_load_b128 v[188:191], v127 offset:25664                 // 0000001C2BD0: DBFC6440 BC00007F
	ds_load_b128 v[208:211], v127 offset:25680                 // 0000001C2BD8: DBFC6450 D000007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C2BE0: BF89FC57
	v_fma_mixlo_f16 v81, v192, s22, 0                          // 0000001C2BE4: CC210051 02002DC0
	v_fma_mixhi_f16 v81, v193, s22, 0                          // 0000001C2BEC: CC220051 02002DC1
	v_fma_mixlo_f16 v82, v194, s22, 0                          // 0000001C2BF4: CC210052 02002DC2
	v_fma_mixhi_f16 v82, v195, s22, 0                          // 0000001C2BFC: CC220052 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001C2C04: BF89FC47
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001C2C08: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001C2C10: CC220053 02002DC5
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001C2C18: CC210054 02002DC6
	ds_load_b128 v[192:195], v127 offset:25696                 // 0000001C2C20: DBFC6460 C000007F
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001C2C28: CC220054 02002DC7
	ds_load_b128 v[196:199], v127 offset:25712                 // 0000001C2C30: DBFC6470 C400007F
	v_fma_mixlo_f16 v61, v212, s22, 0                          // 0000001C2C38: CC21003D 02002DD4
	v_fma_mixhi_f16 v61, v213, s22, 0                          // 0000001C2C40: CC22003D 02002DD5
	v_fma_mixlo_f16 v62, v214, s22, 0                          // 0000001C2C48: CC21003E 02002DD6
	v_fma_mixhi_f16 v62, v215, s22, 0                          // 0000001C2C50: CC22003E 02002DD7
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001C2C58: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001C2C60: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001C2C68: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001C2C70: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001C2C78: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001C2C80: BF89FC57
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001C2C84: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001C2C8C: CC220055 02002DC9
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001C2C94: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001C2C9C: CC220056 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001C2CA4: BF89FC47
	v_fma_mixlo_f16 v87, v204, s22, 0                          // 0000001C2CA8: CC210057 02002DCC
	v_fma_mixhi_f16 v87, v205, s22, 0                          // 0000001C2CB0: CC220057 02002DCD
	v_fma_mixlo_f16 v88, v206, s22, 0                          // 0000001C2CB8: CC210058 02002DCE
	v_fma_mixhi_f16 v88, v207, s22, 0                          // 0000001C2CC0: CC220058 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001C2CC8: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001C2CCC: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001C2CD4: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001C2CDC: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001C2CE4: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001C2CEC: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001C2CF0: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001C2CF8: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001C2D00: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001C2D08: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001C2D10: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001C2D14: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001C2D1C: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001C2D24: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001C2D2C: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001C2D34: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001C2D38: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001C2D40: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001C2D48: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001C2D50: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:384                   // 0000001C2D58: DBFC0180 C800007F
	ds_load_b128 v[204:207], v127 offset:400                   // 0000001C2D60: DBFC0190 CC00007F
	ds_load_b128 v[208:211], v127 offset:416                   // 0000001C2D68: DBFC01A0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001C2D70: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001C2D74: CC404019 1C667331
	ds_load_b128 v[57:60], v127 offset:432                     // 0000001C2D7C: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001C2D84: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001C2D8C: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[188:195], v[1:8]// 0000001C2D94: CC404001 1C077931
	ds_load_b128 v[61:64], v127 offset:8832                    // 0000001C2D9C: DBFC2280 3D00007F
	ds_load_b128 v[73:76], v127 offset:8848                    // 0000001C2DA4: DBFC2290 4900007F
	ds_load_b128 v[77:80], v127 offset:8864                    // 0000001C2DAC: DBFC22A0 4D00007F
	ds_load_b128 v[81:84], v127 offset:8880                    // 0000001C2DB4: DBFC22B0 5100007F
	ds_load_b128 v[85:88], v127 offset:17280                   // 0000001C2DBC: DBFC4380 5500007F
	ds_load_b128 v[188:191], v127 offset:17296                 // 0000001C2DC4: DBFC4390 BC00007F
	ds_load_b128 v[192:195], v127 offset:17312                 // 0000001C2DCC: DBFC43A0 C000007F
	ds_load_b128 v[196:199], v127 offset:17328                 // 0000001C2DD4: DBFC43B0 C400007F
	ds_load_b128 v[215:218], v127 offset:25840                 // 0000001C2DDC: DBFC64F0 D700007F
	s_waitcnt lgkmcnt(12)                                      // 0000001C2DE4: BF89FCC7
	v_fma_mixlo_f16 v49, v200, s22, 0                          // 0000001C2DE8: CC210031 02002DC8
	v_fma_mixhi_f16 v49, v201, s22, 0                          // 0000001C2DF0: CC220031 02002DC9
	v_fma_mixlo_f16 v50, v202, s22, 0                          // 0000001C2DF8: CC210032 02002DCA
	v_fma_mixhi_f16 v50, v203, s22, 0                          // 0000001C2E00: CC220032 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001C2E08: BF89FC97
	v_fma_mixhi_f16 v55, v58, s22, 0                           // 0000001C2E0C: CC220037 02002D3A
	v_fma_mixlo_f16 v56, v59, s22, 0                           // 0000001C2E14: CC210038 02002D3B
	v_fma_mixhi_f16 v56, v60, s22, 0                           // 0000001C2E1C: CC220038 02002D3C
	ds_load_b128 v[200:203], v127 offset:25744                 // 0000001C2E24: DBFC6490 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001C2E2C: BF89FC97
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001C2E30: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001C2E38: CC22003A 02002D40
	s_waitcnt lgkmcnt(8)                                       // 0000001C2E40: BF89FC87
	v_fma_mixlo_f16 v59, v73, s22, 0                           // 0000001C2E44: CC21003B 02002D49
	v_fma_mixhi_f16 v59, v74, s22, 0                           // 0000001C2E4C: CC22003B 02002D4A
	v_fma_mixlo_f16 v60, v75, s22, 0                           // 0000001C2E54: CC21003C 02002D4B
	v_fma_mixhi_f16 v60, v76, s22, 0                           // 0000001C2E5C: CC22003C 02002D4C
	s_waitcnt lgkmcnt(6)                                       // 0000001C2E64: BF89FC67
	v_fma_mixlo_f16 v63, v81, s22, 0                           // 0000001C2E68: CC21003F 02002D51
	v_fma_mixhi_f16 v63, v82, s22, 0                           // 0000001C2E70: CC22003F 02002D52
	v_fma_mixlo_f16 v64, v83, s22, 0                           // 0000001C2E78: CC210040 02002D53
	v_fma_mixhi_f16 v64, v84, s22, 0                           // 0000001C2E80: CC220040 02002D54
	ds_load_b128 v[81:84], v127 offset:25728                   // 0000001C2E88: DBFC6480 5100007F
	s_waitcnt lgkmcnt(6)                                       // 0000001C2E90: BF89FC67
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001C2E94: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001C2E9C: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001C2EA4: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001C2EAC: CC22004A 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001C2EB4: BF89FC57
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001C2EB8: CC21004B 02002DBC
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001C2EC0: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001C2EC8: CC21004C 02002DBE
	ds_load_b128 v[85:88], v127 offset:25760                   // 0000001C2ED0: DBFC64A0 5500007F
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001C2ED8: CC22004C 02002DBF
	ds_load_b128 v[188:191], v127 offset:25776                 // 0000001C2EE0: DBFC64B0 BC00007F
	v_fma_mixlo_f16 v55, v57, s22, 0                           // 0000001C2EE8: CC210037 02002D39
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001C2EF0: CC210039 02002D3D
	v_fma_mixlo_f16 v61, v77, s22, 0                           // 0000001C2EF8: CC21003D 02002D4D
	v_fma_mixhi_f16 v61, v78, s22, 0                           // 0000001C2F00: CC22003D 02002D4E
	s_waitcnt lgkmcnt(6)                                       // 0000001C2F08: BF89FC67
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001C2F0C: CC21004D 02002DC0
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001C2F14: CC22004D 02002DC1
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001C2F1C: CC21004E 02002DC2
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001C2F24: CC22004E 02002DC3
	ds_load_b128 v[192:195], v127 offset:448                   // 0000001C2F2C: DBFC01C0 C000007F
	s_waitcnt lgkmcnt(3)                                       // 0000001C2F34: BF89FC37
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001C2F38: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001C2F40: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001C2F48: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001C2F50: CC220052 02002D54
	v_fma_mixlo_f16 v83, v200, s22, 0                          // 0000001C2F58: CC210053 02002DC8
	v_fma_mixhi_f16 v83, v201, s22, 0                          // 0000001C2F60: CC220053 02002DC9
	v_fma_mixlo_f16 v84, v202, s22, 0                          // 0000001C2F68: CC210054 02002DCA
	v_fma_mixhi_f16 v84, v203, s22, 0                          // 0000001C2F70: CC220054 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001C2F78: BF89FC27
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001C2F7C: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001C2F84: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001C2F8C: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001C2F94: CC220056 02002D58
	s_waitcnt lgkmcnt(1)                                       // 0000001C2F9C: BF89FC17
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001C2FA0: CC210057 02002DBC
	ds_load_b128 v[200:203], v127 offset:480                   // 0000001C2FA8: DBFC01E0 C800007F
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001C2FB0: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001C2FB8: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001C2FC0: CC220058 02002DBF
	ds_load_b128 v[188:191], v127 offset:496                   // 0000001C2FC8: DBFC01F0 BC00007F
	v_fma_mixlo_f16 v51, v204, s22, 0                          // 0000001C2FD0: CC210033 02002DCC
	v_fma_mixhi_f16 v51, v205, s22, 0                          // 0000001C2FD8: CC220033 02002DCD
	v_fma_mixlo_f16 v52, v206, s22, 0                          // 0000001C2FE0: CC210034 02002DCE
	v_fma_mixhi_f16 v52, v207, s22, 0                          // 0000001C2FE8: CC220034 02002DCF
	v_fma_mixlo_f16 v53, v208, s22, 0                          // 0000001C2FF0: CC210035 02002DD0
	v_fma_mixhi_f16 v53, v209, s22, 0                          // 0000001C2FF8: CC220035 02002DD1
	v_fma_mixlo_f16 v54, v210, s22, 0                          // 0000001C3000: CC210036 02002DD2
	v_fma_mixhi_f16 v54, v211, s22, 0                          // 0000001C3008: CC220036 02002DD3
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001C3010: CC220039 02002D3E
	v_fma_mixlo_f16 v62, v79, s22, 0                           // 0000001C3018: CC21003E 02002D4F
	v_fma_mixhi_f16 v62, v80, s22, 0                           // 0000001C3020: CC22003E 02002D50
	v_fma_mixlo_f16 v79, v196, s22, 0                          // 0000001C3028: CC21004F 02002DC4
	v_fma_mixhi_f16 v79, v197, s22, 0                          // 0000001C3030: CC22004F 02002DC5
	v_fma_mixlo_f16 v80, v198, s22, 0                          // 0000001C3038: CC210050 02002DC6
	v_fma_mixhi_f16 v80, v199, s22, 0                          // 0000001C3040: CC220050 02002DC7
	ds_load_b128 v[196:199], v127 offset:464                   // 0000001C3048: DBFC01D0 C400007F
	s_waitcnt vmcnt(8)                                         // 0000001C3050: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001C3054: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001C305C: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001C3064: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001C306C: CC404011 1C469329
	ds_load_b128 v[49:52], v127 offset:8896                    // 0000001C3074: DBFC22C0 3100007F
	ds_load_b128 v[53:56], v127 offset:8912                    // 0000001C307C: DBFC22D0 3500007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C3084: BF89FC57
	v_fma_mixlo_f16 v41, v192, s22, 0                          // 0000001C3088: CC210029 02002DC0
	v_fma_mixhi_f16 v41, v193, s22, 0                          // 0000001C3090: CC220029 02002DC1
	v_fma_mixlo_f16 v42, v194, s22, 0                          // 0000001C3098: CC21002A 02002DC2
	v_fma_mixhi_f16 v42, v195, s22, 0                          // 0000001C30A0: CC22002A 02002DC3
	ds_load_b128 v[57:60], v127 offset:8928                    // 0000001C30A8: DBFC22E0 3900007F
	ds_load_b128 v[61:64], v127 offset:8944                    // 0000001C30B0: DBFC22F0 3D00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001C30B8: BF89FC57
	v_fma_mixlo_f16 v47, v188, s22, 0                          // 0000001C30BC: CC21002F 02002DBC
	v_fma_mixhi_f16 v47, v189, s22, 0                          // 0000001C30C4: CC22002F 02002DBD
	v_fma_mixlo_f16 v48, v190, s22, 0                          // 0000001C30CC: CC210030 02002DBE
	v_fma_mixhi_f16 v48, v191, s22, 0                          // 0000001C30D4: CC220030 02002DBF
	ds_load_b128 v[73:76], v127 offset:17344                   // 0000001C30DC: DBFC43C0 4900007F
	ds_load_b128 v[77:80], v127 offset:17360                   // 0000001C30E4: DBFC43D0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17376                   // 0000001C30EC: DBFC43E0 5100007F
	ds_load_b128 v[85:88], v127 offset:17392                   // 0000001C30F4: DBFC43F0 5500007F
	ds_load_b128 v[188:191], v127 offset:25792                 // 0000001C30FC: DBFC64C0 BC00007F
	ds_load_b128 v[192:195], v127 offset:25808                 // 0000001C3104: DBFC64D0 C000007F
	ds_load_b128 v[211:214], v127 offset:25824                 // 0000001C310C: DBFC64E0 D300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001C3114: BF89FCB7
	v_fma_mixlo_f16 v43, v196, s22, 0                          // 0000001C3118: CC21002B 02002DC4
	v_fma_mixhi_f16 v43, v197, s22, 0                          // 0000001C3120: CC22002B 02002DC5
	v_fma_mixlo_f16 v44, v198, s22, 0                          // 0000001C3128: CC21002C 02002DC6
	v_fma_mixhi_f16 v44, v199, s22, 0                          // 0000001C3130: CC22002C 02002DC7
	v_fma_mixlo_f16 v45, v200, s22, 0                          // 0000001C3138: CC21002D 02002DC8
	v_fma_mixhi_f16 v45, v201, s22, 0                          // 0000001C3140: CC22002D 02002DC9
	v_fma_mixlo_f16 v46, v202, s22, 0                          // 0000001C3148: CC21002E 02002DCA
	v_fma_mixhi_f16 v46, v203, s22, 0                          // 0000001C3150: CC22002E 02002DCB
	s_waitcnt lgkmcnt(10)                                      // 0000001C3158: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s22, 0                           // 0000001C315C: CC210031 02002D31
	v_fma_mixhi_f16 v49, v50, s22, 0                           // 0000001C3164: CC220031 02002D32
	v_fma_mixlo_f16 v50, v51, s22, 0                           // 0000001C316C: CC210032 02002D33
	v_fma_mixhi_f16 v50, v52, s22, 0                           // 0000001C3174: CC220032 02002D34
	s_waitcnt lgkmcnt(9)                                       // 0000001C317C: BF89FC97
	v_fma_mixlo_f16 v51, v53, s22, 0                           // 0000001C3180: CC210033 02002D35
	v_fma_mixhi_f16 v51, v54, s22, 0                           // 0000001C3188: CC220033 02002D36
	v_fma_mixlo_f16 v52, v55, s22, 0                           // 0000001C3190: CC210034 02002D37
	v_fma_mixhi_f16 v52, v56, s22, 0                           // 0000001C3198: CC220034 02002D38
	s_waitcnt lgkmcnt(8)                                       // 0000001C31A0: BF89FC87
	v_fma_mixlo_f16 v53, v57, s22, 0                           // 0000001C31A4: CC210035 02002D39
	v_fma_mixhi_f16 v53, v58, s22, 0                           // 0000001C31AC: CC220035 02002D3A
	v_fma_mixlo_f16 v54, v59, s22, 0                           // 0000001C31B4: CC210036 02002D3B
	s_waitcnt lgkmcnt(7)                                       // 0000001C31BC: BF89FC77
	v_fma_mixlo_f16 v55, v61, s22, 0                           // 0000001C31C0: CC210037 02002D3D
	v_fma_mixhi_f16 v55, v62, s22, 0                           // 0000001C31C8: CC220037 02002D3E
	v_fma_mixlo_f16 v56, v63, s22, 0                           // 0000001C31D0: CC210038 02002D3F
	v_fma_mixhi_f16 v56, v64, s22, 0                           // 0000001C31D8: CC220038 02002D40
	s_waitcnt lgkmcnt(6)                                       // 0000001C31E0: BF89FC67
	v_fma_mixlo_f16 v57, v73, s22, 0                           // 0000001C31E4: CC210039 02002D49
	v_fma_mixhi_f16 v57, v74, s22, 0                           // 0000001C31EC: CC220039 02002D4A
	v_fma_mixlo_f16 v58, v75, s22, 0                           // 0000001C31F4: CC21003A 02002D4B
	v_fma_mixhi_f16 v58, v76, s22, 0                           // 0000001C31FC: CC22003A 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001C3204: BF89FC57
	v_fma_mixlo_f16 v59, v77, s22, 0                           // 0000001C3208: CC21003B 02002D4D
	s_waitcnt lgkmcnt(4)                                       // 0000001C3210: BF89FC47
	v_fma_mixlo_f16 v61, v81, s22, 0                           // 0000001C3214: CC21003D 02002D51
	v_fma_mixhi_f16 v61, v82, s22, 0                           // 0000001C321C: CC22003D 02002D52
	v_fma_mixlo_f16 v62, v83, s22, 0                           // 0000001C3224: CC21003E 02002D53
	v_fma_mixhi_f16 v62, v84, s22, 0                           // 0000001C322C: CC22003E 02002D54
	s_waitcnt lgkmcnt(3)                                       // 0000001C3234: BF89FC37
	v_fma_mixlo_f16 v63, v85, s22, 0                           // 0000001C3238: CC21003F 02002D55
	v_fma_mixhi_f16 v63, v86, s22, 0                           // 0000001C3240: CC22003F 02002D56
	v_fma_mixlo_f16 v64, v87, s22, 0                           // 0000001C3248: CC210040 02002D57
	v_fma_mixhi_f16 v64, v88, s22, 0                           // 0000001C3250: CC220040 02002D58
	s_waitcnt lgkmcnt(2)                                       // 0000001C3258: BF89FC27
	v_fma_mixlo_f16 v73, v188, s22, 0                          // 0000001C325C: CC210049 02002DBC
	v_fma_mixhi_f16 v73, v189, s22, 0                          // 0000001C3264: CC220049 02002DBD
	v_fma_mixlo_f16 v74, v190, s22, 0                          // 0000001C326C: CC21004A 02002DBE
	v_fma_mixhi_f16 v74, v191, s22, 0                          // 0000001C3274: CC22004A 02002DBF
	s_waitcnt lgkmcnt(1)                                       // 0000001C327C: BF89FC17
	v_fma_mixlo_f16 v75, v192, s22, 0                          // 0000001C3280: CC21004B 02002DC0
	v_fma_mixhi_f16 v75, v193, s22, 0                          // 0000001C3288: CC22004B 02002DC1
	v_fma_mixlo_f16 v76, v194, s22, 0                          // 0000001C3290: CC21004C 02002DC2
	v_fma_mixhi_f16 v76, v195, s22, 0                          // 0000001C3298: CC22004C 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001C32A0: BF89FC07
	v_fma_mixlo_f16 v77, v211, s22, 0                          // 0000001C32A4: CC21004D 02002DD3
	ds_load_b128 v[81:84], v128                                // 0000001C32AC: DBFC0000 51000080
	ds_load_b128 v[85:88], v128 offset:16                      // 0000001C32B4: DBFC0010 55000080
	ds_load_b128 v[192:195], v128 offset:2320                  // 0000001C32BC: DBFC0910 C0000080
	ds_load_b128 v[188:191], v128 offset:2304                  // 0000001C32C4: DBFC0900 BC000080
	ds_load_b128 v[200:203], v128 offset:4624                  // 0000001C32CC: DBFC1210 C8000080
	ds_load_b128 v[196:199], v128 offset:4608                  // 0000001C32D4: DBFC1200 C4000080
	ds_load_b128 v[208:211], v128 offset:6928                  // 0000001C32DC: DBFC1B10 D0000080
	ds_load_b128 v[204:207], v128 offset:6912                  // 0000001C32E4: DBFC1B00 CC000080
	v_fma_mixhi_f16 v54, v60, s22, 0                           // 0000001C32EC: CC220036 02002D3C
	v_fma_mixhi_f16 v59, v78, s22, 0                           // 0000001C32F4: CC22003B 02002D4E
	v_fma_mixlo_f16 v60, v79, s22, 0                           // 0000001C32FC: CC21003C 02002D4F
	v_fma_mixhi_f16 v60, v80, s22, 0                           // 0000001C3304: CC22003C 02002D50
	v_fma_mixhi_f16 v77, v212, s22, 0                          // 0000001C330C: CC22004D 02002DD4
	v_fma_mixlo_f16 v78, v213, s22, 0                          // 0000001C3314: CC21004E 02002DD5
	v_fma_mixhi_f16 v78, v214, s22, 0                          // 0000001C331C: CC22004E 02002DD6
	v_fma_mixlo_f16 v79, v215, s22, 0                          // 0000001C3324: CC21004F 02002DD7
	v_fma_mixhi_f16 v79, v216, s22, 0                          // 0000001C332C: CC22004F 02002DD8
	v_fma_mixlo_f16 v80, v217, s22, 0                          // 0000001C3334: CC210050 02002DD9
	v_fma_mixhi_f16 v80, v218, s22, 0                          // 0000001C333C: CC220050 02002DDA
	s_waitcnt vmcnt(6)                                         // 0000001C3344: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001C3348: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001C3350: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001C3358: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001C3360: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[180:187], v[81:88], v[65:72]// 0000001C3364: CC404039 1D06A3B4
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001C336C: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001C3374: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[180:187], v[188:195], v[65:72]// 0000001C3378: CC404031 1D0779B4
	s_waitcnt lgkmcnt(2)                                       // 0000001C3380: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[180:187], v[196:203], v[65:72]// 0000001C3384: CC404029 1D0789B4
	s_waitcnt lgkmcnt(0)                                       // 0000001C338C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[180:187], v[204:211], v[65:72]// 0000001C3390: CC404021 1D0799B4
	s_and_saveexec_b32 s13, s5                                 // 0000001C3398: BE8D2005
	s_cbranch_execnz 734                                       // 0000001C339C: BFA602DE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7318>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33A0: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 0000001C33A4: BE8D2004
	s_cbranch_execnz 767                                       // 0000001C33A8: BFA602FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73a8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33AC: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 0000001C33B0: BE8D2006
	s_cbranch_execnz 795                                       // 0000001C33B4: BFA6031B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7424>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33B8: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C33BC: BE8D2000
	s_cbranch_execnz 825                                       // 0000001C33C0: BFA60339 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74a8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33C4: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C33C8: BE8D2001
	s_cbranch_execnz 844                                       // 0000001C33CC: BFA6034C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7500>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33D0: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C33D4: BE8D2007
	s_cbranch_execnz 863                                       // 0000001C33D8: BFA6035F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7558>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33DC: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C33E0: BE8D2008
	s_cbranch_execnz 882                                       // 0000001C33E4: BFA60372 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75b0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33E8: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C33EC: BE8D2009
	s_cbranch_execnz 901                                       // 0000001C33F0: BFA60385 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7608>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C33F4: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C33F8: BE8D200A
	s_cbranch_execnz 920                                       // 0000001C33FC: BFA60398 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7660>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3400: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C3404: BE8D200B
	s_cbranch_execnz 939                                       // 0000001C3408: BFA603AB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76b8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C340C: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C3410: BE8D200C
	s_cbranch_execnz 958                                       // 0000001C3414: BFA603BE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7710>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3418: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C341C: BE8D2000
	s_cbranch_execnz 976                                       // 0000001C3420: BFA603D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7764>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3424: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C3428: BE8D2001
	s_cbranch_execnz 995                                       // 0000001C342C: BFA603E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77bc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3430: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C3434: BE8D2007
	s_cbranch_execnz 1014                                      // 0000001C3438: BFA603F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7814>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C343C: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C3440: BE8D2008
	s_cbranch_execnz 1033                                      // 0000001C3444: BFA60409 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x786c>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3448: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C344C: BE8D2009
	s_cbranch_execnz 1052                                      // 0000001C3450: BFA6041C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78c4>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3454: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C3458: BE8D200A
	s_cbranch_execnz 1071                                      // 0000001C345C: BFA6042F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x791c>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3460: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C3464: BE8D200B
	s_cbranch_execnz 1090                                      // 0000001C3468: BFA60442 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7974>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C346C: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C3470: BE8D200C
	s_cbranch_execnz 1109                                      // 0000001C3474: BFA60455 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79cc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3478: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C347C: BE8D2000
	s_cbranch_execnz 1127                                      // 0000001C3480: BFA60467 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a20>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3484: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C3488: BE8D2001
	s_cbranch_execnz 1146                                      // 0000001C348C: BFA6047A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a78>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3490: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C3494: BE8D2007
	s_cbranch_execnz 1165                                      // 0000001C3498: BFA6048D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ad0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C349C: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C34A0: BE8D2008
	s_cbranch_execnz 1184                                      // 0000001C34A4: BFA604A0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b28>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34A8: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C34AC: BE8D2009
	s_cbranch_execnz 1203                                      // 0000001C34B0: BFA604B3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b80>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34B4: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C34B8: BE8D200A
	s_cbranch_execnz 1222                                      // 0000001C34BC: BFA604C6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bd8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34C0: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C34C4: BE8D200B
	s_cbranch_execnz 1241                                      // 0000001C34C8: BFA604D9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c30>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34CC: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C34D0: BE8D200C
	s_cbranch_execnz 1260                                      // 0000001C34D4: BFA604EC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c88>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34D8: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C34DC: BE8D2000
	s_cbranch_execnz 1278                                      // 0000001C34E0: BFA604FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7cdc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C34E4: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 0000001C34E8: BE802001
	s_cbranch_execnz 1297                                      // 0000001C34EC: BFA60511 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d34>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C34F0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001C34F4: BE802007
	s_cbranch_execnz 1316                                      // 0000001C34F8: BFA60524 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d8c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C34FC: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001C3500: BE802008
	s_cbranch_execnz 1335                                      // 0000001C3504: BFA60537 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7de4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C3508: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001C350C: BE802009
	s_cbranch_execnz 1354                                      // 0000001C3510: BFA6054A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C3514: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001C3518: BE80200A
	s_cbranch_execnz 1373                                      // 0000001C351C: BFA6055D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e94>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C3520: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001C3524: BE80200B
	s_cbranch_execnz 1392                                      // 0000001C3528: BFA60570 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7eec>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C352C: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001C3530: BE80200C
	s_cbranch_execz 18                                         // 0000001C3534: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6980>
	ds_load_b32 v1, v139 offset:56                             // 0000001C3538: D8D80038 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C3540: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001C3544: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v179, v[108:109]       // 0000001C3548: D6FE7C01 05B366FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C3554: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001C3558: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001C3560: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C3568: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001C356C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C3578: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C3580: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 0000001C3584: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001C3588: BC7C0000
	s_barrier                                                  // 0000001C358C: BFBD0000
	buffer_gl0_inv                                             // 0000001C3590: E0AC0000 00000000
	ds_load_b128 v[1:4], v131                                  // 0000001C3598: DBFC0000 01000083
	ds_load_b128 v[5:8], v131 offset:16                        // 0000001C35A0: DBFC0010 05000083
	ds_load_b128 v[25:28], v132                                // 0000001C35A8: DBFC0000 19000084
	ds_load_b128 v[29:32], v132 offset:16                      // 0000001C35B0: DBFC0010 1D000084
	ds_load_b128 v[9:12], v131 offset:32                       // 0000001C35B8: DBFC0020 09000083
	ds_load_b128 v[13:16], v131 offset:48                      // 0000001C35C0: DBFC0030 0D000083
	ds_load_b128 v[33:36], v132 offset:2304                    // 0000001C35C8: DBFC0900 21000084
	ds_load_b128 v[37:40], v132 offset:2320                    // 0000001C35D0: DBFC0910 25000084
	ds_load_b128 v[41:44], v132 offset:4608                    // 0000001C35D8: DBFC1200 29000084
	ds_load_b128 v[45:48], v132 offset:4624                    // 0000001C35E0: DBFC1210 2D000084
	ds_load_b128 v[49:52], v132 offset:6912                    // 0000001C35E8: DBFC1B00 31000084
	ds_load_b128 v[53:56], v132 offset:6928                    // 0000001C35F0: DBFC1B10 35000084
	ds_load_b128 v[57:60], v132 offset:9216                    // 0000001C35F8: DBFC2400 39000084
	ds_load_b128 v[61:64], v132 offset:9232                    // 0000001C3600: DBFC2410 3D000084
	ds_load_b128 v[65:68], v132 offset:11520                   // 0000001C3608: DBFC2D00 41000084
	ds_load_b128 v[69:72], v132 offset:11536                   // 0000001C3610: DBFC2D10 45000084
	ds_load_b128 v[73:76], v132 offset:13824                   // 0000001C3618: DBFC3600 49000084
	ds_load_b128 v[77:80], v132 offset:13840                   // 0000001C3620: DBFC3610 4D000084
	ds_load_b128 v[81:84], v132 offset:16128                   // 0000001C3628: DBFC3F00 51000084
	ds_load_b128 v[85:88], v132 offset:16144                   // 0000001C3630: DBFC3F10 55000084
	ds_load_b128 v[89:92], v132 offset:32                      // 0000001C3638: DBFC0020 59000084
	ds_load_b128 v[93:96], v132 offset:48                      // 0000001C3640: DBFC0030 5D000084
	v_dual_mov_b32 v17, s36 :: v_dual_mov_b32 v18, s37         // 0000001C3648: CA100024 11120025
	v_dual_mov_b32 v19, s38 :: v_dual_mov_b32 v20, s39         // 0000001C3650: CA100026 13140027
	v_dual_mov_b32 v21, s40 :: v_dual_mov_b32 v22, s41         // 0000001C3658: CA100028 15160029
	v_dual_mov_b32 v23, s42 :: v_dual_mov_b32 v24, s43         // 0000001C3660: CA10002A 1718002B
	s_mul_f32 s0, s28, 0x3fb8aa3b                              // 0000001C3668: A200FF1C 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001C3670: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001C3674: 8D01FF00 80000000
	s_rndne_f32 s7, s0                                         // 0000001C367C: BE876300
	s_waitcnt lgkmcnt(14)                                      // 0000001C3680: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[172:179], v[33:40], v[1:8], v[17:24]// 0000001C3684: CC4040AC 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001C368C: CC404061 1C460319
	ds_load_b128 v[25:28], v132 offset:2336                    // 0000001C3694: DBFC0920 19000084
	ds_load_b128 v[29:32], v132 offset:2352                    // 0000001C369C: DBFC0930 1D000084
	s_waitcnt lgkmcnt(14)                                      // 0000001C36A4: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001C36A8: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001C36B0: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001C36B4: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001C36BC: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001C36C0: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001C36C8: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001C36CC: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001C36D4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001C36D8: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001C36E0: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001C36E4: CC404049 1C460351
	ds_load_b128 v[1:4], v132 offset:4640                      // 0000001C36EC: DBFC1220 01000084
	ds_load_b128 v[5:8], v132 offset:4656                      // 0000001C36F4: DBFC1230 05000084
	ds_load_b128 v[17:20], v132 offset:6944                    // 0000001C36FC: DBFC1B20 11000084
	ds_load_b128 v[21:24], v132 offset:6960                    // 0000001C3704: DBFC1B30 15000084
	ds_load_b128 v[81:84], v132 offset:9248                    // 0000001C370C: DBFC2420 51000084
	ds_load_b128 v[85:88], v132 offset:9264                    // 0000001C3714: DBFC2430 55000084
	s_waitcnt lgkmcnt(8)                                       // 0000001C371C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001C3720: CC404061 1D861359
	s_fmamk_f32 s1, s28, 0x3fb8aa3b, s1                        // 0000001C3728: A301011C 3FB8AA3B
	s_sub_f32 s0, s0, s7                                       // 0000001C3730: A0800700
	s_cmp_nlt_f32 s28, 0xc2ce8ed0                              // 0000001C3734: BF4EFF1C C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001C373C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[172:179], v[25:32], v[9:16], v[172:179]// 0000001C3740: CC4040AC 1EB21319
	ds_load_b128 v[25:28], v132 offset:11552                   // 0000001C3748: DBFC2D20 19000084
	ds_load_b128 v[29:32], v132 offset:11568                   // 0000001C3750: DBFC2D30 1D000084
	s_fmamk_f32 s1, s28, 0x32a5705f, s1                        // 0000001C3758: A301011C 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001C3760: BF87059B
	s_add_f32 s0, s0, s1                                       // 0000001C3764: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001C3768: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001C376C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001C3770: CC404021 1C861301
	ds_load_b128 v[1:4], v132 offset:13856                     // 0000001C3778: DBFC3620 01000084
	ds_load_b128 v[5:8], v132 offset:13872                     // 0000001C3780: DBFC3630 05000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3788: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001C378C: CC404029 1CA61311
	ds_load_b128 v[17:20], v132 offset:16160                   // 0000001C3794: DBFC3F20 11000084
	ds_load_b128 v[21:24], v132 offset:16176                   // 0000001C379C: DBFC3F30 15000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C37A4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001C37A8: CC404031 1CC61351
	ds_load_b128 v[85:88], v131 offset:80                      // 0000001C37B0: DBFC0050 55000083
	ds_load_b128 v[81:84], v131 offset:64                      // 0000001C37B8: DBFC0040 51000083
	s_cvt_i32_f32 s0, s7                                       // 0000001C37C0: BE806607
	s_waitcnt lgkmcnt(6)                                       // 0000001C37C4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001C37C8: CC404039 1CE61319
	ds_load_b128 v[29:32], v132 offset:80                      // 0000001C37D0: DBFC0050 1D000084
	ds_load_b128 v[25:28], v132 offset:64                      // 0000001C37D8: DBFC0040 19000084
	.long 0xd71c005b                                           // 0000001C37E0: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001C37E4: 0200015B
	s_cselect_b32 s0, -1, 0                                    // 0000001C37E8: 980080C1
	s_cmp_ngt_f32 s28, 0x42b17218                              // 0000001C37EC: BF4BFF1C 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000001C37F4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001C37F8: CC404041 1D061301
	ds_load_b128 v[5:8], v132 offset:2384                      // 0000001C3800: DBFC0950 05000084
	ds_load_b128 v[1:4], v132 offset:2368                      // 0000001C3808: DBFC0940 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3810: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001C3814: CC404049 1D261311
	ds_load_b128 v[13:16], v132 offset:4688                    // 0000001C381C: DBFC1250 0D000084
	ds_load_b128 v[9:12], v132 offset:4672                     // 0000001C3824: DBFC1240 09000084
	ds_load_b128 v[21:24], v132 offset:6992                    // 0000001C382C: DBFC1B50 15000084
	ds_load_b128 v[17:20], v132 offset:6976                    // 0000001C3834: DBFC1B40 11000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C383C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001C3840: CC404061 1D86A319
	ds_load_b128 v[29:32], v132 offset:9296                    // 0000001C3848: DBFC2450 1D000084
	ds_load_b128 v[25:28], v132 offset:9280                    // 0000001C3850: DBFC2440 19000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3858: BF89FC67
	v_wmma_f32_16x16x16_f16 v[172:179], v[1:8], v[81:88], v[172:179]// 0000001C385C: CC4040AC 1EB2A301
	ds_load_b128 v[5:8], v132 offset:11600                     // 0000001C3864: DBFC2D50 05000084
	ds_load_b128 v[1:4], v132 offset:11584                     // 0000001C386C: DBFC2D40 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3874: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001C3878: CC404021 1C86A309
	ds_load_b128 v[13:16], v132 offset:13904                   // 0000001C3880: DBFC3650 0D000084
	ds_load_b128 v[9:12], v132 offset:13888                    // 0000001C3888: DBFC3640 09000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3890: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001C3894: CC404029 1CA6A311
	ds_load_b128 v[21:24], v132 offset:16208                   // 0000001C389C: DBFC3F50 15000084
	ds_load_b128 v[17:20], v132 offset:16192                   // 0000001C38A4: DBFC3F40 11000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C38AC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001C38B0: CC404031 1CC6A319
	ds_load_b128 v[29:32], v131 offset:112                     // 0000001C38B8: DBFC0070 1D000083
	ds_load_b128 v[25:28], v131 offset:96                      // 0000001C38C0: DBFC0060 19000083
	s_waitcnt lgkmcnt(6)                                       // 0000001C38C8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001C38CC: CC404039 1CE6A301
	ds_load_b128 v[5:8], v132 offset:112                       // 0000001C38D4: DBFC0070 05000084
	ds_load_b128 v[1:4], v132 offset:96                        // 0000001C38DC: DBFC0060 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C38E4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001C38E8: CC404041 1D06A309
	ds_load_b128 v[13:16], v132 offset:2416                    // 0000001C38F0: DBFC0970 0D000084
	ds_load_b128 v[9:12], v132 offset:2400                     // 0000001C38F8: DBFC0960 09000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3900: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001C3904: CC404049 1D26A311
	ds_load_b128 v[21:24], v132 offset:4720                    // 0000001C390C: DBFC1270 15000084
	ds_load_b128 v[17:20], v132 offset:4704                    // 0000001C3914: DBFC1260 11000084
	ds_load_b128 v[85:88], v132 offset:7024                    // 0000001C391C: DBFC1B70 55000084
	ds_load_b128 v[81:84], v132 offset:7008                    // 0000001C3924: DBFC1B60 51000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C392C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001C3930: CC404061 1D863301
	ds_load_b128 v[5:8], v132 offset:9328                      // 0000001C3938: DBFC2470 05000084
	ds_load_b128 v[1:4], v132 offset:9312                      // 0000001C3940: DBFC2460 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001C3948: BF89FC67
	v_wmma_f32_16x16x16_f16 v[172:179], v[9:16], v[25:32], v[172:179]// 0000001C394C: CC4040AC 1EB23309
	ds_load_b128 v[13:16], v132 offset:11632                   // 0000001C3954: DBFC2D70 0D000084
	ds_load_b128 v[9:12], v132 offset:11616                    // 0000001C395C: DBFC2D60 09000084
	ds_load_2addr_b32 v[89:90], v133 offset1:2                 // 0000001C3964: D8DC0200 59000085
	s_waitcnt lgkmcnt(7)                                       // 0000001C396C: BF89FC77
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001C3970: CC404021 1C863311
	ds_load_b128 v[21:24], v132 offset:13936                   // 0000001C3978: DBFC3670 15000084
	ds_load_b128 v[17:20], v132 offset:13920                   // 0000001C3980: DBFC3660 11000084
	s_waitcnt lgkmcnt(7)                                       // 0000001C3988: BF89FC77
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001C398C: CC404029 1CA63351
	ds_load_b128 v[85:88], v132 offset:16240                   // 0000001C3994: DBFC3F70 55000084
	ds_load_b128 v[81:84], v132 offset:16224                   // 0000001C399C: DBFC3F60 51000084
	s_waitcnt lgkmcnt(7)                                       // 0000001C39A4: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001C39A8: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v133 offset0:4 offset1:6         // 0000001C39B0: D8DC0604 01000085
	ds_load_2addr_b32 v[3:4], v133 offset0:8 offset1:10        // 0000001C39B8: D8DC0A08 03000085
	ds_load_2addr_b32 v[5:6], v133 offset0:12 offset1:14       // 0000001C39C0: D8DC0E0C 05000085
	s_waitcnt lgkmcnt(8)                                       // 0000001C39C8: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001C39CC: CC404039 1CE63309
	ds_load_2addr_b32 v[9:10], v133 offset0:20 offset1:22      // 0000001C39D4: D8DC1614 09000085
	ds_load_2addr_b32 v[11:12], v133 offset0:24 offset1:26     // 0000001C39DC: D8DC1A18 0B000085
	ds_load_2addr_b32 v[13:14], v133 offset0:28 offset1:30     // 0000001C39E4: D8DC1E1C 0D000085
	ds_load_2addr_b32 v[7:8], v133 offset0:16 offset1:18       // 0000001C39EC: D8DC1210 07000085
	s_waitcnt lgkmcnt(9)                                       // 0000001C39F4: BF89FC97
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001C39F8: CC404041 1D063311
	s_waitcnt lgkmcnt(7)                                       // 0000001C3A00: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001C3A04: CC404049 1D263351
	v_cndmask_b32_e64 v31, 0, v91, s0                          // 0000001C3A0C: D501001F 0002B680
	s_cselect_b32 s0, -1, 0                                    // 0000001C3A14: 980080C1
	ds_load_2addr_b32 v[15:16], v133 offset0:32 offset1:34     // 0000001C3A18: D8DC2220 0F000085
	ds_load_2addr_b32 v[17:18], v133 offset0:36 offset1:38     // 0000001C3A20: D8DC2624 11000085
	ds_load_2addr_b32 v[19:20], v133 offset0:40 offset1:42     // 0000001C3A28: D8DC2A28 13000085
	ds_load_2addr_b32 v[21:22], v133 offset0:44 offset1:46     // 0000001C3A30: D8DC2E2C 15000085
	ds_load_2addr_b32 v[23:24], v133 offset0:48 offset1:50     // 0000001C3A38: D8DC3230 17000085
	v_cndmask_b32_e64 v91, 0x7f800000, v31, s0                 // 0000001C3A40: D501005B 00023EFF 7F800000
	ds_load_2addr_b32 v[25:26], v133 offset0:52 offset1:54     // 0000001C3A4C: D8DC3634 19000085
	ds_load_2addr_b32 v[27:28], v133 offset0:56 offset1:58     // 0000001C3A54: D8DC3A38 1B000085
	ds_load_2addr_b32 v[29:30], v133 offset0:60 offset1:62     // 0000001C3A5C: D8DC3E3C 1D000085
	ds_load_2addr_b32 v[31:32], v133 offset0:64 offset1:66     // 0000001C3A64: D8DC4240 1F000085
	ds_load_2addr_b32 v[81:82], v133 offset0:68 offset1:70     // 0000001C3A6C: D8DC4644 51000085
	ds_load_2addr_b32 v[83:84], v133 offset0:72 offset1:74     // 0000001C3A74: D8DC4A48 53000085
	ds_load_2addr_b32 v[85:86], v133 offset0:76 offset1:78     // 0000001C3A7C: D8DC4E4C 55000085
	s_cmp_lg_u32 s23, s44                                      // 0000001C3A84: BF072C17
	v_mul_f32_e32 v90, v91, v90                                // 0000001C3A88: 10B4B55B
	s_waitcnt lgkmcnt(18)                                      // 0000001C3A8C: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001C3A90: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001C3A94: 10B8035B
	s_waitcnt lgkmcnt(16)                                      // 0000001C3A98: BF89FD07
	v_mul_f32_e32 v105, v91, v6                                // 0000001C3A9C: 10D20D5B
	v_mul_f32_e32 v96, v91, v5                                 // 0000001C3AA0: 10C00B5B
	v_dual_mul_f32 v89, v91, v89 :: v_dual_fmac_f32 v90, 0x3b800000, v98// 0000001C3AA4: C8C0B35B 595AC4FF 3B800000
	v_mul_f32_e32 v95, v91, v4                                 // 0000001C3AB0: 10BE095B
	v_dual_mul_f32 v94, v91, v3 :: v_dual_fmac_f32 v93, 0x3b800000, v100// 0000001C3AB4: C8C0075B 5E5CC8FF 3B800000
	v_dual_fmac_f32 v92, 0x3b800000, v99 :: v_dual_fmac_f32 v105, 0x3b800000, v104// 0000001C3AC0: C800C6FF 5C68D0FF 3B800000
	v_fmac_f32_e32 v96, 0x3b800000, v103                       // 0000001C3ACC: 56C0CEFF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001C3AD4: BF89FCF7
	v_mul_f32_e32 v100, v91, v10                               // 0000001C3AD8: 10C8155B
	v_mul_f32_e32 v99, v91, v9                                 // 0000001C3ADC: 10C6135B
	s_waitcnt lgkmcnt(13)                                      // 0000001C3AE0: BF89FCD7
	v_mul_f32_e32 v104, v91, v14                               // 0000001C3AE4: 10D01D5B
	v_mul_f32_e32 v103, v91, v13                               // 0000001C3AE8: 10CE1B5B
	v_fmac_f32_e32 v89, 0x3b800000, v97                        // 0000001C3AEC: 56B2C2FF 3B800000
	v_dual_fmac_f32 v95, 0x3b800000, v102 :: v_dual_fmac_f32 v94, 0x3b800000, v101// 0000001C3AF4: C800CCFF 5F5ECAFF 3B800000
	v_fmac_f32_e32 v100, 0x3b800000, v175                      // 0000001C3B00: 56C95EFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001C3B08: BF89FCC7
	v_dual_mul_f32 v98, v91, v8 :: v_dual_fmac_f32 v99, 0x3b800000, v174// 0000001C3B0C: C8C0115B 62635CFF 3B800000
	v_mul_f32_e32 v97, v91, v7                                 // 0000001C3B18: 10C20F5B
	v_fmac_f32_e32 v104, 0x3b800000, v179                      // 0000001C3B1C: 56D166FF 3B800000
	v_dual_mul_f32 v102, v91, v12 :: v_dual_fmac_f32 v103, 0x3b800000, v178// 0000001C3B24: C8C0195B 666764FF 3B800000
	v_mul_f32_e32 v101, v91, v11                               // 0000001C3B30: 10CA175B
	ds_load_2addr_b32 v[1:2], v133 offset0:80 offset1:82       // 0000001C3B34: D8DC5250 01000085
	ds_load_2addr_b32 v[3:4], v133 offset0:84 offset1:86       // 0000001C3B3C: D8DC5654 03000085
	ds_load_2addr_b32 v[5:6], v133 offset0:88 offset1:90       // 0000001C3B44: D8DC5A58 05000085
	ds_load_2addr_b32 v[87:88], v133 offset0:92 offset1:94     // 0000001C3B4C: D8DC5E5C 57000085
	v_dual_fmac_f32 v98, 0x3b800000, v173 :: v_dual_fmac_f32 v97, 0x3b800000, v172// 0000001C3B54: C8015AFF 626158FF 3B800000
	v_dual_fmac_f32 v102, 0x3b800000, v177 :: v_dual_fmac_f32 v101, 0x3b800000, v176// 0000001C3B60: C80162FF 666560FF 3B800000
	ds_load_2addr_b32 v[7:8], v133 offset0:96 offset1:98       // 0000001C3B6C: D8DC6260 07000085
	ds_load_2addr_b32 v[9:10], v133 offset0:100 offset1:102    // 0000001C3B74: D8DC6664 09000085
	ds_load_2addr_b32 v[11:12], v133 offset0:104 offset1:106   // 0000001C3B7C: D8DC6A68 0B000085
	ds_load_2addr_b32 v[13:14], v133 offset0:108 offset1:110   // 0000001C3B84: D8DC6E6C 0D000085
	s_waitcnt lgkmcnt(19)                                      // 0000001C3B8C: BF89FD37
	v_mul_f32_e32 v117, v91, v16                               // 0000001C3B90: 10EA215B
	v_mul_f32_e32 v116, v91, v15                               // 0000001C3B94: 10E81F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001C3B98: BF89FD27
	v_mul_f32_e32 v173, v91, v18                               // 0000001C3B9C: 115A255B
	v_mul_f32_e32 v172, v91, v17                               // 0000001C3BA0: 1158235B
	s_waitcnt lgkmcnt(17)                                      // 0000001C3BA4: BF89FD17
	v_mul_f32_e32 v175, v91, v20                               // 0000001C3BA8: 115E295B
	v_mul_f32_e32 v174, v91, v19                               // 0000001C3BAC: 115C275B
	s_waitcnt lgkmcnt(16)                                      // 0000001C3BB0: BF89FD07
	v_mul_f32_e32 v177, v91, v22                               // 0000001C3BB4: 11622D5B
	v_mul_f32_e32 v176, v91, v21                               // 0000001C3BB8: 11602B5B
	ds_load_2addr_b32 v[15:16], v133 offset0:112 offset1:114   // 0000001C3BBC: D8DC7270 0F000085
	ds_load_2addr_b32 v[17:18], v133 offset0:116 offset1:118   // 0000001C3BC4: D8DC7674 11000085
	ds_load_2addr_b32 v[19:20], v133 offset0:120 offset1:122   // 0000001C3BCC: D8DC7A78 13000085
	ds_load_2addr_b32 v[21:22], v133 offset0:124 offset1:126   // 0000001C3BD4: D8DC7E7C 15000085
	v_dual_fmac_f32 v117, 0x3b800000, v34 :: v_dual_fmac_f32 v116, 0x3b800000, v33// 0000001C3BDC: C80044FF 757442FF 3B800000
	v_dual_fmac_f32 v173, 0x3b800000, v36 :: v_dual_fmac_f32 v172, 0x3b800000, v35// 0000001C3BE8: C80048FF ADAC46FF 3B800000
	v_dual_fmac_f32 v175, 0x3b800000, v38 :: v_dual_fmac_f32 v174, 0x3b800000, v37// 0000001C3BF4: C8004CFF AFAE4AFF 3B800000
	v_dual_fmac_f32 v177, 0x3b800000, v40 :: v_dual_fmac_f32 v176, 0x3b800000, v39// 0000001C3C00: C80050FF B1B04EFF 3B800000
	s_waitcnt lgkmcnt(19)                                      // 0000001C3C0C: BF89FD37
	v_mul_f32_e32 v24, v91, v24                                // 0000001C3C10: 1030315B
	v_mul_f32_e32 v23, v91, v23                                // 0000001C3C14: 102E2F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001C3C18: BF89FD27
	v_mul_f32_e32 v26, v91, v26                                // 0000001C3C1C: 1034355B
	v_mul_f32_e32 v25, v91, v25                                // 0000001C3C20: 1032335B
	s_waitcnt lgkmcnt(17)                                      // 0000001C3C24: BF89FD17
	v_mul_f32_e32 v28, v91, v28                                // 0000001C3C28: 1038395B
	v_mul_f32_e32 v27, v91, v27                                // 0000001C3C2C: 1036375B
	s_waitcnt lgkmcnt(16)                                      // 0000001C3C30: BF89FD07
	v_mul_f32_e32 v30, v91, v30                                // 0000001C3C34: 103C3D5B
	v_mul_f32_e32 v29, v91, v29                                // 0000001C3C38: 103A3B5B
	s_waitcnt lgkmcnt(15)                                      // 0000001C3C3C: BF89FCF7
	v_mul_f32_e32 v32, v91, v32                                // 0000001C3C40: 1040415B
	v_mul_f32_e32 v31, v91, v31                                // 0000001C3C44: 103E3F5B
	s_waitcnt lgkmcnt(14)                                      // 0000001C3C48: BF89FCE7
	v_mul_f32_e32 v34, v91, v82                                // 0000001C3C4C: 1044A55B
	v_mul_f32_e32 v33, v91, v81                                // 0000001C3C50: 1042A35B
	s_waitcnt lgkmcnt(13)                                      // 0000001C3C54: BF89FCD7
	v_mul_f32_e32 v36, v91, v84                                // 0000001C3C58: 1048A95B
	v_mul_f32_e32 v35, v91, v83                                // 0000001C3C5C: 1046A75B
	s_waitcnt lgkmcnt(12)                                      // 0000001C3C60: BF89FCC7
	v_mul_f32_e32 v38, v91, v86                                // 0000001C3C64: 104CAD5B
	v_mul_f32_e32 v37, v91, v85                                // 0000001C3C68: 104AAB5B
	s_waitcnt lgkmcnt(11)                                      // 0000001C3C6C: BF89FCB7
	v_mul_f32_e32 v2, v91, v2                                  // 0000001C3C70: 1004055B
	v_mul_f32_e32 v1, v91, v1                                  // 0000001C3C74: 1002035B
	s_waitcnt lgkmcnt(10)                                      // 0000001C3C78: BF89FCA7
	v_mul_f32_e32 v4, v91, v4                                  // 0000001C3C7C: 1008095B
	v_mul_f32_e32 v3, v91, v3                                  // 0000001C3C80: 1006075B
	s_waitcnt lgkmcnt(9)                                       // 0000001C3C84: BF89FC97
	v_mul_f32_e32 v6, v91, v6                                  // 0000001C3C88: 100C0D5B
	v_mul_f32_e32 v5, v91, v5                                  // 0000001C3C8C: 100A0B5B
	s_waitcnt lgkmcnt(8)                                       // 0000001C3C90: BF89FC87
	v_mul_f32_e32 v40, v91, v88                                // 0000001C3C94: 1050B15B
	v_mul_f32_e32 v39, v91, v87                                // 0000001C3C98: 104EAF5B
	s_waitcnt lgkmcnt(7)                                       // 0000001C3C9C: BF89FC77
	v_mul_f32_e32 v8, v91, v8                                  // 0000001C3CA0: 1010115B
	v_mul_f32_e32 v7, v91, v7                                  // 0000001C3CA4: 100E0F5B
	s_waitcnt lgkmcnt(6)                                       // 0000001C3CA8: BF89FC67
	v_mul_f32_e32 v10, v91, v10                                // 0000001C3CAC: 1014155B
	v_mul_f32_e32 v9, v91, v9                                  // 0000001C3CB0: 1012135B
	s_waitcnt lgkmcnt(5)                                       // 0000001C3CB4: BF89FC57
	v_mul_f32_e32 v12, v91, v12                                // 0000001C3CB8: 1018195B
	v_mul_f32_e32 v11, v91, v11                                // 0000001C3CBC: 1016175B
	s_waitcnt lgkmcnt(4)                                       // 0000001C3CC0: BF89FC47
	v_mul_f32_e32 v14, v91, v14                                // 0000001C3CC4: 101C1D5B
	v_mul_f32_e32 v13, v91, v13                                // 0000001C3CC8: 101A1B5B
	s_waitcnt lgkmcnt(3)                                       // 0000001C3CCC: BF89FC37
	v_mul_f32_e32 v16, v91, v16                                // 0000001C3CD0: 1020215B
	v_mul_f32_e32 v15, v91, v15                                // 0000001C3CD4: 101E1F5B
	s_waitcnt lgkmcnt(2)                                       // 0000001C3CD8: BF89FC27
	v_mul_f32_e32 v18, v91, v18                                // 0000001C3CDC: 1024255B
	v_mul_f32_e32 v17, v91, v17                                // 0000001C3CE0: 1022235B
	s_waitcnt lgkmcnt(1)                                       // 0000001C3CE4: BF89FC17
	v_mul_f32_e32 v20, v91, v20                                // 0000001C3CE8: 1028295B
	v_mul_f32_e32 v19, v91, v19                                // 0000001C3CEC: 1026275B
	s_waitcnt lgkmcnt(0)                                       // 0000001C3CF0: BF89FC07
	v_mul_f32_e32 v22, v91, v22                                // 0000001C3CF4: 102C2D5B
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001C3CF8: C8C02B5B 151854FF 3B800000
	v_dual_fmac_f32 v23, 0x3b800000, v41 :: v_dual_fmac_f32 v26, 0x3b800000, v44// 0000001C3D04: C80052FF 171A58FF 3B800000
	v_dual_fmac_f32 v25, 0x3b800000, v43 :: v_dual_fmac_f32 v28, 0x3b800000, v46// 0000001C3D10: C80056FF 191C5CFF 3B800000
	v_dual_fmac_f32 v27, 0x3b800000, v45 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001C3D1C: C8005AFF 1B1E60FF 3B800000
	v_dual_fmac_f32 v29, 0x3b800000, v47 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001C3D28: C8005EFF 1D2064FF 3B800000
	v_dual_fmac_f32 v31, 0x3b800000, v49 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001C3D34: C80062FF 1F2268FF 3B800000
	v_dual_fmac_f32 v33, 0x3b800000, v51 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001C3D40: C80066FF 21246CFF 3B800000
	v_dual_fmac_f32 v35, 0x3b800000, v53 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001C3D4C: C8006AFF 232670FF 3B800000
	v_dual_fmac_f32 v37, 0x3b800000, v55 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001C3D58: C8006EFF 250274FF 3B800000
	v_dual_fmac_f32 v1, 0x3b800000, v57 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001C3D64: C80072FF 010478FF 3B800000
	v_dual_fmac_f32 v3, 0x3b800000, v59 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001C3D70: C80076FF 03067CFF 3B800000
	v_dual_fmac_f32 v5, 0x3b800000, v61 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001C3D7C: C8007AFF 052880FF 3B800000
	v_dual_fmac_f32 v39, 0x3b800000, v63 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001C3D88: C8007EFF 270884FF 3B800000
	v_dual_fmac_f32 v7, 0x3b800000, v65 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001C3D94: C80082FF 070A88FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v67 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001C3DA0: C80086FF 090C8CFF 3B800000
	v_dual_fmac_f32 v11, 0x3b800000, v69 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001C3DAC: C8008AFF 0B0E90FF 3B800000
	v_dual_fmac_f32 v13, 0x3b800000, v71 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001C3DB8: C8008EFF 0D1094FF 3B800000
	v_dual_fmac_f32 v15, 0x3b800000, v73 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001C3DC4: C80092FF 0F1298FF 3B800000
	v_dual_fmac_f32 v17, 0x3b800000, v75 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001C3DD0: C80096FF 11149CFF 3B800000
	v_dual_fmac_f32 v19, 0x3b800000, v77 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001C3DDC: C8009AFF 1316A0FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001C3DE8: 562A9EFF 3B800000
	ds_store_2addr_b32 v133, v89, v90 offset1:2                // 0000001C3DF0: D8380200 005A5985
	ds_store_2addr_b32 v133, v92, v93 offset0:4 offset1:6      // 0000001C3DF8: D8380604 005D5C85
	ds_store_2addr_b32 v133, v94, v95 offset0:8 offset1:10     // 0000001C3E00: D8380A08 005F5E85
	ds_store_2addr_b32 v133, v96, v105 offset0:12 offset1:14   // 0000001C3E08: D8380E0C 00696085
	ds_store_2addr_b32 v133, v97, v98 offset0:16 offset1:18    // 0000001C3E10: D8381210 00626185
	ds_store_2addr_b32 v133, v99, v100 offset0:20 offset1:22   // 0000001C3E18: D8381614 00646385
	ds_store_2addr_b32 v133, v101, v102 offset0:24 offset1:26  // 0000001C3E20: D8381A18 00666585
	ds_store_2addr_b32 v133, v103, v104 offset0:28 offset1:30  // 0000001C3E28: D8381E1C 00686785
	ds_store_2addr_b32 v133, v116, v117 offset0:32 offset1:34  // 0000001C3E30: D8382220 00757485
	ds_store_2addr_b32 v133, v172, v173 offset0:36 offset1:38  // 0000001C3E38: D8382624 00ADAC85
	ds_store_2addr_b32 v133, v174, v175 offset0:40 offset1:42  // 0000001C3E40: D8382A28 00AFAE85
	ds_store_2addr_b32 v133, v176, v177 offset0:44 offset1:46  // 0000001C3E48: D8382E2C 00B1B085
	ds_store_2addr_b32 v133, v23, v24 offset0:48 offset1:50    // 0000001C3E50: D8383230 00181785
	ds_store_2addr_b32 v133, v25, v26 offset0:52 offset1:54    // 0000001C3E58: D8383634 001A1985
	ds_store_2addr_b32 v133, v27, v28 offset0:56 offset1:58    // 0000001C3E60: D8383A38 001C1B85
	ds_store_2addr_b32 v133, v29, v30 offset0:60 offset1:62    // 0000001C3E68: D8383E3C 001E1D85
	ds_store_2addr_b32 v133, v31, v32 offset0:64 offset1:66    // 0000001C3E70: D8384240 00201F85
	ds_store_2addr_b32 v133, v33, v34 offset0:68 offset1:70    // 0000001C3E78: D8384644 00222185
	ds_store_2addr_b32 v133, v35, v36 offset0:72 offset1:74    // 0000001C3E80: D8384A48 00242385
	ds_store_2addr_b32 v133, v37, v38 offset0:76 offset1:78    // 0000001C3E88: D8384E4C 00262585
	ds_store_2addr_b32 v133, v1, v2 offset0:80 offset1:82      // 0000001C3E90: D8385250 00020185
	ds_store_2addr_b32 v133, v3, v4 offset0:84 offset1:86      // 0000001C3E98: D8385654 00040385
	ds_store_2addr_b32 v133, v5, v6 offset0:88 offset1:90      // 0000001C3EA0: D8385A58 00060585
	ds_store_2addr_b32 v133, v39, v40 offset0:92 offset1:94    // 0000001C3EA8: D8385E5C 00282785
	ds_store_2addr_b32 v133, v7, v8 offset0:96 offset1:98      // 0000001C3EB0: D8386260 00080785
	ds_store_2addr_b32 v133, v9, v10 offset0:100 offset1:102   // 0000001C3EB8: D8386664 000A0985
	ds_store_2addr_b32 v133, v11, v12 offset0:104 offset1:106  // 0000001C3EC0: D8386A68 000C0B85
	ds_store_2addr_b32 v133, v13, v14 offset0:108 offset1:110  // 0000001C3EC8: D8386E6C 000E0D85
	ds_store_2addr_b32 v133, v15, v16 offset0:112 offset1:114  // 0000001C3ED0: D8387270 00100F85
	ds_store_2addr_b32 v133, v17, v18 offset0:116 offset1:118  // 0000001C3ED8: D8387674 00121185
	ds_store_2addr_b32 v133, v19, v20 offset0:120 offset1:122  // 0000001C3EE0: D8387A78 00141385
	ds_store_2addr_b32 v133, v21, v22 offset0:124 offset1:126  // 0000001C3EE8: D8387E7C 00161585
	s_waitcnt lgkmcnt(0)                                       // 0000001C3EF0: BF89FC07
	s_barrier                                                  // 0000001C3EF4: BFBD0000
	buffer_gl0_inv                                             // 0000001C3EF8: E0AC0000 00000000
	s_cbranch_scc0 785                                         // 0000001C3F00: BFA10311 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f48>
	s_cmp_lg_u32 s23, s45                                      // 0000001C3F04: BF072D17
	s_cbranch_scc0 820                                         // 0000001C3F08: BFA10334 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7fdc>
	s_cmp_lg_u32 s23, s46                                      // 0000001C3F0C: BF072E17
	s_cbranch_scc1 58509                                       // 0000001C3F10: BFA2E48D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	s_branch 849                                               // 0000001C3F14: BFA00351 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x805c>
	s_clause 0x1                                               // 0000001C3F18: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 0000001C3F1C: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 0000001C3F24: DC5E0020 417C0074
	ds_load_b128 v[73:76], v128 offset:32                      // 0000001C3F2C: DBFC0020 49000080
	ds_load_b128 v[77:80], v128 offset:48                      // 0000001C3F34: DBFC0030 4D000080
	ds_load_b128 v[85:88], v128 offset:2352                    // 0000001C3F3C: DBFC0930 55000080
	ds_load_b128 v[81:84], v128 offset:2336                    // 0000001C3F44: DBFC0920 51000080
	ds_load_b128 v[184:187], v128 offset:4656                  // 0000001C3F4C: DBFC1230 B8000080
	ds_load_b128 v[180:183], v128 offset:4640                  // 0000001C3F54: DBFC1220 B4000080
	ds_load_b128 v[192:195], v128 offset:6960                  // 0000001C3F5C: DBFC1B30 C0000080
	ds_load_b128 v[188:191], v128 offset:6944                  // 0000001C3F64: DBFC1B20 BC000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001C3F6C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001C3F70: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001C3F78: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001C3F7C: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001C3F84: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[180:187], v[41:48]// 0000001C3F88: CC404029 1CA76941
	s_waitcnt lgkmcnt(0)                                       // 0000001C3F90: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[188:195], v[33:40]// 0000001C3F94: CC404021 1C877941
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C3F9C: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 0000001C3FA0: BE8D2004
	s_cbranch_execz 64769                                      // 0000001C3FA4: BFA5FD01 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67ac>
	ds_load_b128 v[65:68], v128 offset:64                      // 0000001C3FA8: DBFC0040 41000080
	ds_load_b128 v[69:72], v128 offset:80                      // 0000001C3FB0: DBFC0050 45000080
	ds_load_b128 v[77:80], v128 offset:2384                    // 0000001C3FB8: DBFC0950 4D000080
	ds_load_b128 v[73:76], v128 offset:2368                    // 0000001C3FC0: DBFC0940 49000080
	ds_load_b128 v[85:88], v128 offset:4688                    // 0000001C3FC8: DBFC1250 55000080
	ds_load_b128 v[81:84], v128 offset:4672                    // 0000001C3FD0: DBFC1240 51000080
	ds_load_b128 v[184:187], v128 offset:6992                  // 0000001C3FD8: DBFC1B50 B8000080
	ds_load_b128 v[180:183], v128 offset:6976                  // 0000001C3FE0: DBFC1B40 B4000080
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001C3FE8: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001C3FEC: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001C3FF4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001C3FF8: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001C4000: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001C4004: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001C400C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[180:187], v[33:40]// 0000001C4010: CC404021 1C876961
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4018: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 0000001C401C: BE8D2006
	s_cbranch_execz 64741                                      // 0000001C4020: BFA5FCE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67b8>
	ds_load_b128 v[65:68], v128 offset:96                      // 0000001C4024: DBFC0060 41000080
	ds_load_b128 v[69:72], v128 offset:112                     // 0000001C402C: DBFC0070 45000080
	ds_load_b128 v[77:80], v128 offset:2416                    // 0000001C4034: DBFC0970 4D000080
	ds_load_b128 v[73:76], v128 offset:2400                    // 0000001C403C: DBFC0960 49000080
	ds_load_b128 v[85:88], v128 offset:4720                    // 0000001C4044: DBFC1270 55000080
	ds_load_b128 v[81:84], v128 offset:4704                    // 0000001C404C: DBFC1260 51000080
	s_waitcnt vmcnt(3)                                         // 0000001C4054: BF890FF7
	ds_load_b128 v[101:104], v128 offset:7024                  // 0000001C4058: DBFC1B70 65000080
	s_waitcnt vmcnt(2)                                         // 0000001C4060: BF890BF7
	ds_load_b128 v[97:100], v128 offset:7008                   // 0000001C4064: DBFC1B60 61000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001C406C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001C4070: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001C4078: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001C407C: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001C4084: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001C4088: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001C4090: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001C4094: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C409C: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C40A0: BE8D2000
	s_cbranch_execz 64711                                      // 0000001C40A4: BFA5FCC7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67c4>
	ds_load_b32 v65, v139                                      // 0000001C40A8: D8D80000 4100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C40B0: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001C40B4: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v172, v[108:109]     // 0000001C40BC: D6FE7C41 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C40C8: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001C40CC: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001C40D4: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C40DC: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001C40E0: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001C40EC: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C40F4: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C40F8: BE8D2001
	s_cbranch_execz 64692                                      // 0000001C40FC: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	ds_load_b32 v25, v139 offset:8                             // 0000001C4100: D8D80008 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4108: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001C410C: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4114: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001C4118: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v173, v[108:109]     // 0000001C4120: D6FE7C19 05B35AFF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001C412C: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4134: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001C4138: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001C4144: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C414C: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C4150: BE8D2007
	s_cbranch_execz 64673                                      // 0000001C4154: BFA5FCA1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67dc>
	ds_load_b32 v25, v139 offset:16                            // 0000001C4158: D8D80010 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4160: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001C4164: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C416C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001C4170: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v174, v[108:109]     // 0000001C4178: D6FE7C19 05B35CFF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001C4184: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C418C: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001C4190: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C419C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C41A4: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C41A8: BE8D2008
	s_cbranch_execz 64654                                      // 0000001C41AC: BFA5FC8E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67e8>
	ds_load_b32 v25, v139 offset:24                            // 0000001C41B0: D8D80018 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C41B8: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001C41BC: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C41C4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001C41C8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v175, v[108:109]     // 0000001C41D0: D6FE7C19 05B35EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001C41DC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C41E4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001C41E8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C41F4: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C41FC: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C4200: BE8D2009
	s_cbranch_execz 64635                                      // 0000001C4204: BFA5FC7B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f4>
	ds_load_b32 v25, v139 offset:32                            // 0000001C4208: D8D80020 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4210: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001C4214: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C421C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001C4220: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v176, v[108:109]     // 0000001C4228: D6FE7C19 05B360FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001C4234: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C423C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001C4240: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C424C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4254: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C4258: BE8D200A
	s_cbranch_execz 64616                                      // 0000001C425C: BFA5FC68 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	ds_load_b32 v25, v139 offset:40                            // 0000001C4260: D8D80028 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4268: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001C426C: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4274: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001C4278: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v177, v[108:109]     // 0000001C4280: D6FE7C19 05B362FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001C428C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4294: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001C4298: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C42A4: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C42AC: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C42B0: BE8D200B
	s_cbranch_execz 64597                                      // 0000001C42B4: BFA5FC55 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x680c>
	ds_load_b32 v25, v139 offset:48                            // 0000001C42B8: D8D80030 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C42C0: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001C42C4: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C42CC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001C42D0: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v178, v[108:109]     // 0000001C42D8: D6FE7C19 05B364FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001C42E4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C42EC: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001C42F0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C42FC: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4304: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C4308: BE8D200C
	s_cbranch_execz 64578                                      // 0000001C430C: BFA5FC42 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6818>
	ds_load_b32 v25, v139 offset:56                            // 0000001C4310: D8D80038 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4318: BF89FC07
	v_fmac_f32_e32 v64, v32, v25                               // 0000001C431C: 56803320
	v_mad_u64_u32 v[25:26], null, 0x3000, v179, v[108:109]     // 0000001C4320: D6FE7C19 05B366FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C432C: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v64                         // 0000001C4330: 103680FF 3B800000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001C4338: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4340: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001C4344: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001C4350: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4358: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C435C: BE8D2000
	s_cbranch_execz 64560                                      // 0000001C4360: BFA5FC30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6824>
	ds_load_b32 v25, v139                                      // 0000001C4364: D8D80000 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C436C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001C4370: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v172, v[108:109]     // 0000001C4378: D6FE7C19 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C4384: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001C4388: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001C4390: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4398: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001C439C: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001C43A8: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C43B0: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C43B4: BE8D2001
	s_cbranch_execz 64541                                      // 0000001C43B8: BFA5FC1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6830>
	ds_load_b32 v9, v139 offset:8                              // 0000001C43BC: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C43C4: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001C43C8: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C43D0: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001C43D4: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001C43DC: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001C43E8: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C43F0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001C43F4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001C4400: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4408: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C440C: BE8D2007
	s_cbranch_execz 64522                                      // 0000001C4410: BFA5FC0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x683c>
	ds_load_b32 v9, v139 offset:16                             // 0000001C4414: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C441C: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001C4420: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4428: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C442C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001C4434: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001C4440: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4448: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001C444C: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C4458: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4460: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C4464: BE8D2008
	s_cbranch_execz 64503                                      // 0000001C4468: BFA5FBF7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6848>
	ds_load_b32 v9, v139 offset:24                             // 0000001C446C: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4474: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001C4478: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4480: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4484: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001C448C: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C4498: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C44A0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C44A4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C44B0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C44B8: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C44BC: BE8D2009
	s_cbranch_execz 64484                                      // 0000001C44C0: BFA5FBE4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6854>
	ds_load_b32 v9, v139 offset:32                             // 0000001C44C4: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C44CC: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001C44D0: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C44D8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C44DC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001C44E4: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C44F0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C44F8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C44FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C4508: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4510: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C4514: BE8D200A
	s_cbranch_execz 64465                                      // 0000001C4518: BFA5FBD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6860>
	ds_load_b32 v9, v139 offset:40                             // 0000001C451C: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4524: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001C4528: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4530: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4534: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001C453C: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C4548: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4550: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4554: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C4560: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4568: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C456C: BE8D200B
	s_cbranch_execz 64446                                      // 0000001C4570: BFA5FBBE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x686c>
	ds_load_b32 v9, v139 offset:48                             // 0000001C4574: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C457C: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001C4580: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4588: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C458C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001C4594: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C45A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C45A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C45AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C45B8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C45C0: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C45C4: BE8D200C
	s_cbranch_execz 64427                                      // 0000001C45C8: BFA5FBAB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6878>
	ds_load_b32 v9, v139 offset:56                             // 0000001C45CC: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C45D4: BF89FC07
	v_fmac_f32_e32 v56, v16, v9                                // 0000001C45D8: 56701310
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001C45DC: D6FE7C09 05B366FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C45E8: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v56                         // 0000001C45EC: 101670FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C45F4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C45FC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4600: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001C460C: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4614: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C4618: BE8D2000
	s_cbranch_execz 64409                                      // 0000001C461C: BFA5FB99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6884>
	ds_load_b32 v9, v139                                       // 0000001C4620: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4628: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001C462C: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4634: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4638: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001C4640: D6FE7C09 05B358FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C464C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4654: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4658: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C4664: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C466C: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001C4670: BE8D2001
	s_cbranch_execz 64390                                      // 0000001C4674: BFA5FB86 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6890>
	ds_load_b32 v9, v139 offset:8                              // 0000001C4678: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4680: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001C4684: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C468C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4690: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001C4698: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C46A4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C46AC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C46B0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C46BC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C46C4: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001C46C8: BE8D2007
	s_cbranch_execz 64371                                      // 0000001C46CC: BFA5FB73 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x689c>
	ds_load_b32 v9, v139 offset:16                             // 0000001C46D0: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C46D8: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001C46DC: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C46E4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C46E8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001C46F0: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C46FC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4704: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4708: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C4714: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C471C: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001C4720: BE8D2008
	s_cbranch_execz 64352                                      // 0000001C4724: BFA5FB60 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68a8>
	ds_load_b32 v9, v139 offset:24                             // 0000001C4728: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4730: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001C4734: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C473C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4740: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001C4748: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C4754: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C475C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4760: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C476C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4774: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001C4778: BE8D2009
	s_cbranch_execz 64333                                      // 0000001C477C: BFA5FB4D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68b4>
	ds_load_b32 v9, v139 offset:32                             // 0000001C4780: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4788: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001C478C: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4794: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4798: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001C47A0: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C47AC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C47B4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C47B8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C47C4: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C47CC: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001C47D0: BE8D200A
	s_cbranch_execz 64314                                      // 0000001C47D4: BFA5FB3A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68c0>
	ds_load_b32 v9, v139 offset:40                             // 0000001C47D8: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C47E0: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001C47E4: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C47EC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C47F0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001C47F8: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C4804: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C480C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4810: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C481C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4824: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001C4828: BE8D200B
	s_cbranch_execz 64295                                      // 0000001C482C: BFA5FB27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68cc>
	ds_load_b32 v9, v139 offset:48                             // 0000001C4830: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4838: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001C483C: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4844: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001C4848: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001C4850: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C485C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4864: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C4868: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C4874: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C487C: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001C4880: BE8D200C
	s_cbranch_execz 64276                                      // 0000001C4884: BFA5FB14 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68d8>
	ds_load_b32 v9, v139 offset:56                             // 0000001C4888: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4890: BF89FC07
	v_fmac_f32_e32 v48, v24, v9                                // 0000001C4894: 56601318
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001C4898: D6FE7C09 05B366FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C48A4: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 0000001C48A8: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001C48B0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C48B8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001C48BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001C48C8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C48D0: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001C48D4: BE8D2000
	s_cbranch_execz 64258                                      // 0000001C48D8: BFA5FB02 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68e4>
	ds_load_b32 v9, v139                                       // 0000001C48DC: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C48E4: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001C48E8: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001C48F0: D6FE7C09 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C48FC: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001C4900: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001C4908: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4910: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001C4914: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001C4920: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001C4928: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 0000001C492C: BE802001
	s_cbranch_execz 64239                                      // 0000001C4930: BFA5FAEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68f0>
	ds_load_b32 v1, v139 offset:8                              // 0000001C4934: D8D80008 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C493C: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001C4940: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4948: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001C494C: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v173, v[108:109]       // 0000001C4954: D6FE7C01 05B35AFF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001C4960: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4968: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001C496C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001C4978: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C4980: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001C4984: BE802007
	s_cbranch_execz 64220                                      // 0000001C4988: BFA5FADC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68fc>
	ds_load_b32 v1, v139 offset:16                             // 0000001C498C: D8D80010 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4994: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001C4998: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C49A0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001C49A4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v174, v[108:109]       // 0000001C49AC: D6FE7C01 05B35CFF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001C49B8: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C49C0: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001C49C4: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C49D0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C49D8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001C49DC: BE802008
	s_cbranch_execz 64201                                      // 0000001C49E0: BFA5FAC9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6908>
	ds_load_b32 v1, v139 offset:24                             // 0000001C49E4: D8D80018 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C49EC: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001C49F0: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C49F8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001C49FC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v175, v[108:109]       // 0000001C4A04: D6FE7C01 05B35EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001C4A10: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4A18: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001C4A1C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C4A28: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C4A30: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001C4A34: BE802009
	s_cbranch_execz 64182                                      // 0000001C4A38: BFA5FAB6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6914>
	ds_load_b32 v1, v139 offset:32                             // 0000001C4A3C: D8D80020 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4A44: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001C4A48: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4A50: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001C4A54: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v176, v[108:109]       // 0000001C4A5C: D6FE7C01 05B360FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001C4A68: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4A70: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001C4A74: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C4A80: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C4A88: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001C4A8C: BE80200A
	s_cbranch_execz 64163                                      // 0000001C4A90: BFA5FAA3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6920>
	ds_load_b32 v1, v139 offset:40                             // 0000001C4A94: D8D80028 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4A9C: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001C4AA0: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4AA8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001C4AAC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v177, v[108:109]       // 0000001C4AB4: D6FE7C01 05B362FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001C4AC0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4AC8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001C4ACC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C4AD8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C4AE0: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001C4AE4: BE80200B
	s_cbranch_execz 64144                                      // 0000001C4AE8: BFA5FA90 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x692c>
	ds_load_b32 v1, v139 offset:48                             // 0000001C4AEC: D8D80030 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001C4AF4: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001C4AF8: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4B00: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001C4B04: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v178, v[108:109]       // 0000001C4B0C: D6FE7C01 05B364FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001C4B18: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C4B20: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001C4B24: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001C4B30: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C4B38: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001C4B3C: BE80200C
	s_cbranch_execnz 64125                                     // 0000001C4B40: BFA6FA7D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6938>
	s_branch 64142                                             // 0000001C4B44: BFA0FA8E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6980>
	v_mov_b32_e32 v3, v123                                     // 0000001C4B48: 7E06037B
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v2, v111         // 0000001C4B4C: CA10016E 0102016F
	v_mov_b32_e32 v4, v119                                     // 0000001C4B54: 7E080377
	s_mov_b32 s7, 0                                            // 0000001C4B58: BE870080
	s_nop 0                                                    // 0000001C4B5C: BF800000
	s_nop 0                                                    // 0000001C4B60: BF800000
	s_nop 0                                                    // 0000001C4B64: BF800000
	s_nop 0                                                    // 0000001C4B68: BF800000
	s_nop 0                                                    // 0000001C4B6C: BF800000
	s_nop 0                                                    // 0000001C4B70: BF800000
	s_nop 0                                                    // 0000001C4B74: BF800000
	s_nop 0                                                    // 0000001C4B78: BF800000
	s_nop 0                                                    // 0000001C4B7C: BF800000
	ds_load_b32 v5, v3                                         // 0000001C4B80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001C4B88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001C4B90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C4B94: BF8700D2
	.long 0xd4490000                                           // 0000001C4B98: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001C4B9C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001C4BA4: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001C4BA8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001C4BAC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001C4BB4: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001C4BB8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001C4BC0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001C4BC8: 917E077E
	s_cbranch_execnz 65516                                     // 0000001C4BCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f80>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001C4BD0: 8C7E077E
	s_cmp_lg_u32 s23, s45                                      // 0000001C4BD4: BF072D17
	s_cbranch_scc1 64716                                       // 0000001C4BD8: BFA2FCCC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x730c>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 0000001C4BDC: CA100170 01040177
	v_dual_mov_b32 v3, v123 :: v_dual_mov_b32 v2, v113         // 0000001C4BE4: CA10017B 03020171
	s_mov_b32 s7, 0                                            // 0000001C4BEC: BE870080
	s_nop 0                                                    // 0000001C4BF0: BF800000
	s_nop 0                                                    // 0000001C4BF4: BF800000
	s_nop 0                                                    // 0000001C4BF8: BF800000
	s_nop 0                                                    // 0000001C4BFC: BF800000
	ds_load_b32 v5, v3                                         // 0000001C4C00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001C4C08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001C4C10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C4C14: BF8700D2
	.long 0xd4490000                                           // 0000001C4C18: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001C4C1C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001C4C24: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001C4C28: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001C4C2C: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001C4C34: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001C4C38: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001C4C40: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001C4C48: 917E077E
	s_cbranch_execnz 65516                                     // 0000001C4C4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8000>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001C4C50: 8C7E077E
	s_cmp_lg_u32 s23, s46                                      // 0000001C4C54: BF072E17
	s_cbranch_scc1 57659                                       // 0000001C4C58: BFA2E13B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	v_mov_b32_e32 v3, v123                                     // 0000001C4C5C: 7E06037B
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v2, v115         // 0000001C4C60: CA100172 01020173
	v_mov_b32_e32 v4, v119                                     // 0000001C4C68: 7E080377
	s_mov_b32 s7, 0                                            // 0000001C4C6C: BE870080
	s_nop 0                                                    // 0000001C4C70: BF800000
	s_nop 0                                                    // 0000001C4C74: BF800000
	s_nop 0                                                    // 0000001C4C78: BF800000
	s_nop 0                                                    // 0000001C4C7C: BF800000
	ds_load_b32 v5, v3                                         // 0000001C4C80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001C4C88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001C4C90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C4C94: BF8700D2
	.long 0xd4490000                                           // 0000001C4C98: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001C4C9C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001C4CA4: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001C4CA8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001C4CAC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001C4CB4: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001C4CB8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001C4CC0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001C4CC8: 917E077E
	s_cbranch_execnz 65516                                     // 0000001C4CCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8080>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001C4CD0: 8C7E077E
	s_branch 57628                                             // 0000001C4CD4: BFA0E11C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v2, s35           // 0000001C4CD8: CA100022 01020023
	v_mov_b32_e32 v6, v119                                     // 0000001C4CE0: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C4CE4: BF870092
	.long 0xd7006a00                                           // 0000001C4CE8: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001C4CEC: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001C4CF0: D5207C01 01AA0413
	s_add_u32 s0, s33, s20                                     // 0000001C4CF8: 80001421
	s_addc_u32 s1, s15, s21                                    // 0000001C4CFC: 8201150F
	.long 0xd7006a00                                           // 0000001C4D00: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001C4D04: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C4D08: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001C4D0C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001C4D14: BE810080
	.long 0xd7006a00                                           // 0000001C4D18: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001C4D1C: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001C4D20: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C4D28: BF870092
	.long 0xd7006a00                                           // 0000001C4D2C: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 0000001C4D30: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v129, vcc_lo             // 0000001C4D34: D5207C01 01AB0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C4D3C: BF870092
	.long 0xd7006a00                                           // 0000001C4D40: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001C4D44: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001C4D48: D5207C01 01AA0211
	s_nop 0                                                    // 0000001C4D50: BF800000
	s_nop 0                                                    // 0000001C4D54: BF800000
	s_nop 0                                                    // 0000001C4D58: BF800000
	s_nop 0                                                    // 0000001C4D5C: BF800000
	s_nop 0                                                    // 0000001C4D60: BF800000
	s_nop 0                                                    // 0000001C4D64: BF800000
	s_nop 0                                                    // 0000001C4D68: BF800000
	s_nop 0                                                    // 0000001C4D6C: BF800000
	s_nop 0                                                    // 0000001C4D70: BF800000
	s_nop 0                                                    // 0000001C4D74: BF800000
	s_nop 0                                                    // 0000001C4D78: BF800000
	s_nop 0                                                    // 0000001C4D7C: BF800000
	ds_load_b32 v2, v123                                       // 0000001C4D80: D8D80000 0200007B
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001C4D88: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v123, 8, v123                             // 0000001C4D90: 4AF6F688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C4D94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001C4D98: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001C4DA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001C4DA4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001C4DA8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001C4DB0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001C4DB4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001C4DBC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001C4DC4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001C4DC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8180>
	s_nop 0                                                    // 0000001C4DCC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001C4DD0: BFB60003
	s_endpgm                                                   // 0000001C4DD4: BFB00000
		...

