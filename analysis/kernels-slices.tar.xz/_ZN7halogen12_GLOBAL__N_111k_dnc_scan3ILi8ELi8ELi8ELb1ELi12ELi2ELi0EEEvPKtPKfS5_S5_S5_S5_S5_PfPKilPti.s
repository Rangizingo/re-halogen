00000000000ae900 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000AE900: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000AE904: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000AE90C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000AE914: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000AE918: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000AE91C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000AE920: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000AE928: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000AE92C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000AE930: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000AE934: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000AE93C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000AE940: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000AE944: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000AE948: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AE94C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000AE950: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000AE954: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000AE958: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000AE95C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000AE964: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000AE96C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000AE970: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000AE974: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000AE978: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000AE97C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000AE980: 821E191E
	.long 0xd7001f02                                           // 0000000AE984: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000AE988: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000AE98C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000AE994: BE9E0080
	s_nop 0                                                    // 0000000AE998: BF800000
	s_nop 0                                                    // 0000000AE99C: BF800000
	s_nop 0                                                    // 0000000AE9A0: BF800000
	s_nop 0                                                    // 0000000AE9A4: BF800000
	s_nop 0                                                    // 0000000AE9A8: BF800000
	s_nop 0                                                    // 0000000AE9AC: BF800000
	s_nop 0                                                    // 0000000AE9B0: BF800000
	s_nop 0                                                    // 0000000AE9B4: BF800000
	s_nop 0                                                    // 0000000AE9B8: BF800000
	s_nop 0                                                    // 0000000AE9BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000AE9C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000AE9C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE9CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000AE9D0: 300C1089
	.long 0xd7006a06                                           // 0000000AE9D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000AE9D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AE9DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000AE9E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000AE9E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000AE9F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000AE9F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000AE9FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000AEA08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000AEA0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000AEA10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000AEA18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000AEA1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000AEA20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000AEA24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000AEA2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000AEA34: 32040084
	s_mov_b32 s0, 0                                            // 0000000AEA38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000AEA3C: BF89FC07
	s_barrier                                                  // 0000000AEA40: BFBD0000
	buffer_gl0_inv                                             // 0000000AEA44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000AEA4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000AEA50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000AEA54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000AEA5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AEA64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000AEA68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000AEA70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000AEA74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000AEA78: 916A007E
	s_cbranch_vccz 2                                           // 0000000AEA7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 0000000AEA80: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000AEA84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000AEA88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000AEA8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000AEA94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000AEA98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000AEA9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000AEAA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000AEAA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000AEAAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000AEAB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000AEAB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000AEAB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000AEABC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000AEAC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000AEAC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000AEAC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000AEAD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000AEAD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000AEADC: B00A0204
	.long 0xd7000b2c                                           // 0000000AEAE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000AEAE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000AEAE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000AEAEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000AEAF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000AEB00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000AEB04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000AEB10: 3816500A
	.long 0xd7000a05                                           // 0000000AEB14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000AEB18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AEB1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000AEB20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000AEB28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000AEB2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEB30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000AEB34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000AEB3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000AEB40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000AEB44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000AEB4C: 84848E02
	.long 0xd700010b                                           // 0000000AEB50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000AEB54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000AEB58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000AEB5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000AEB64: 8205050F
	.long 0xd700010d                                           // 0000000AEB68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000AEB6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEB70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000AEB74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000AEB7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000AEB80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000AEB88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000AEB90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000AEB94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEB9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000AEBA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000AEBA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000AEBAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000AEBB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000AEBBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000AEBC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEBC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000AEBCC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000AEBD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000AEBD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000AEBE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000AEBE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000AEBEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AEBF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000AEBF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000AEC00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000AEC04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000AEC0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000AEC14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000AEC18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000AEC20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000AEC24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000AEC2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000AEC34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000AEC3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000AEC44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000AEC4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000AEC54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000AEC5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000AEC64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000AEC6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000AEC74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000AEC7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000AEC84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000AEC8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000AEC94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000AEC9C: BE850080
	s_mov_b32 s6, 0x41800000                                   // 0000000AECA0: BE8600FF 41800000
	s_mov_b32 s7, 0x3d800000                                   // 0000000AECA8: BE8700FF 3D800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000AECB0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000AECB4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AECBC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000AECC0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000AECC4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AECC8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000AECCC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000AECD0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000AECD4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000AECD8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000AECDC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000AECE4: BE84206A
	s_cbranch_execz 77                                         // 0000000AECE8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000AECEC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AECF0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000AECF4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000AECFC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED00: BF870091
	.long 0xd73c001d                                           // 0000000AED04: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000AED08: 02023A82
	.long 0xd700011d                                           // 0000000AED0C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000AED10: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000AED14: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000AED18: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000AED20: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000AED28: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000AED2C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000AED30: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000AED3C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000AED40: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000AED4C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000AED50: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000AED5C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AED60: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000AED64: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000AED70: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AED74: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000AED78: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000AED80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000AED84: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000AED8C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000AED94: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000AED98: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AED9C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000AEDA0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000AEDA4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AEDA8: BF870296
	.long 0xd71c0020                                           // 0000000AEDAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000AEDB0: 02024520
	.long 0xd71c001f                                           // 0000000AEDB4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000AEDB8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEDBC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000AEDC0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000AEDC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000AEDCC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000AEDD4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000AEDDC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000AEDE0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEDE8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000AEDEC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000AEDF8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000AEDFC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000AEE04: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000AEE10: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000AEE18: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AEE20: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000AEE24: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000AEE2C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000AEE30: BF89FC07
	s_barrier                                                  // 0000000AEE34: BFBD0000
	buffer_gl0_inv                                             // 0000000AEE38: E0AC0000 00000000
	s_branch 15                                                // 0000000AEE40: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AEE44: 8C7E047E
	.long 0xd700011d                                           // 0000000AEE48: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000AEE4C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AEE54: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000AEE58: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000AEE60: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000AEE64: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000AEE68: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000AEE6C: BF89FC07
	s_barrier                                                  // 0000000AEE70: BFBD0000
	buffer_gl0_inv                                             // 0000000AEE74: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000AEE7C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000AEE80: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000AEE88: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000AEE90: BE8D0080
	s_nop 0                                                    // 0000000AEE94: BF800000
	s_nop 0                                                    // 0000000AEE98: BF800000
	s_nop 0                                                    // 0000000AEE9C: BF800000
	s_nop 0                                                    // 0000000AEEA0: BF800000
	s_nop 0                                                    // 0000000AEEA4: BF800000
	s_nop 0                                                    // 0000000AEEA8: BF800000
	s_nop 0                                                    // 0000000AEEAC: BF800000
	s_nop 0                                                    // 0000000AEEB0: BF800000
	s_nop 0                                                    // 0000000AEEB4: BF800000
	s_nop 0                                                    // 0000000AEEB8: BF800000
	s_nop 0                                                    // 0000000AEEBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000AEEC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000AEEC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000AEED0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000AEED4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AEEDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000AEEE0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000AEEE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000AEEEC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000AEEF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000AEEF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000AEEFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000AEF04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000AEF0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000AEF10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000AEF14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000AEF18: BF89FC07
	s_barrier                                                  // 0000000AEF1C: BFBD0000
	buffer_gl0_inv                                             // 0000000AEF20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000AEF28: BE842000
	s_cbranch_execz 65477                                      // 0000000AEF2C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000AEF30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000AEF38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000AEF40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000AEF48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000AEF50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000AEF58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000AEF60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000AEF68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000AEF70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000AEF78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000AEF80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000AEF88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000AEF90: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000AEF98: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEFA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000AEFA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000AEFAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000AEFB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEFB4: BF870091
	.long 0xd7000146                                           // 0000000AEFB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000AEFBC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000AEFC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000AEFC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000AEFD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000AEFD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AEFDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000AEFE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000AEFE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000AEFEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000AEFF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000AEFFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000AF004: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000AF00C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000AF014: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF018: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000AF01C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000AF024: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000AF02C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF030: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000AF034: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000AF03C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000AF044: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF048: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000AF04C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000AF054: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000AF05C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF060: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF064: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000AF06C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000AF074: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000AF07C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000AF084: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000AF08C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000AF094: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000AF09C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000AF0A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF0AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000AF0B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000AF0BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000AF0C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000AF0D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000AF0D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000AF0E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000AF0E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000AF0F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000AF0F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF0FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000AF100: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000AF108: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000AF110: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000AF118: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000AF120: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000AF128: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000AF130: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000AF138: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000AF140: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000AF148: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000AF150: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF154: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000AF158: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000AF160: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000AF168: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF16C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF170: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF178: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF180: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF184: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000AF188: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000AF190: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000AF198: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF19C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF1A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000AF1A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000AF1B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000AF1B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000AF1C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000AF1C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000AF1D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000AF1D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000AF1E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF1E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF1F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF1F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF1F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF200: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF208: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF20C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000AF210: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000AF218: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000AF220: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF224: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000AF228: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000AF230: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000AF238: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF23C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000AF240: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000AF248: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000AF250: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000AF258: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000AF260: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000AF268: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000AF270: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000AF278: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000AF280: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000AF288: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF290: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF294: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF298: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF2A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF2A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF2AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF2B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF2B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF2C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF2C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000AF2C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000AF2D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF2D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF2DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF2E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000AF2E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000AF2F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000AF2F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000AF300: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000AF308: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000AF310: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000AF318: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000AF320: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF328: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF330: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF334: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF338: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF340: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF348: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF34C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000AF350: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000AF358: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000AF360: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF364: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000AF368: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF370: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF378: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF37C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000AF380: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000AF388: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000AF390: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000AF398: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000AF3A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000AF3A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000AF3B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000AF3B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000AF3C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000AF3C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF3D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF3D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF3D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF3E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF3E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF3EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF3F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF3F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF400: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF404: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000AF408: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF410: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF418: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF41C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF420: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000AF428: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000AF430: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000AF438: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000AF440: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000AF448: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000AF450: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000AF458: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000AF460: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF468: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF470: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF474: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF478: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF480: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF488: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF48C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000AF490: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000AF498: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000AF4A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF4A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000AF4A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF4B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF4B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF4BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000AF4C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000AF4C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000AF4D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000AF4D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000AF4E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000AF4E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000AF4F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000AF4F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000AF500: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000AF508: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF510: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF514: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF518: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF520: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF528: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF52C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF530: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF538: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF540: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF544: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000AF548: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF550: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF558: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF55C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF560: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000AF568: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000AF570: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000AF578: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000AF580: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000AF588: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000AF590: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000AF598: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000AF5A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF5A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF5B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF5B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF5B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF5C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF5C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF5CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000AF5D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000AF5D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000AF5E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF5E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000AF5E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF5F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF5F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF5FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000AF600: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000AF608: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000AF610: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000AF618: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000AF620: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000AF628: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000AF630: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000AF638: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000AF640: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000AF648: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF650: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF654: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF658: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF660: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF668: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF66C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF670: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF678: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF680: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF684: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000AF688: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF690: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF698: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF69C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF6A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000AF6A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000AF6B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000AF6B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000AF6C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000AF6C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000AF6D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000AF6D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000AF6E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF6E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF6F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF6F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF6F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF700: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF708: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF70C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000AF710: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000AF718: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000AF720: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF724: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000AF728: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF730: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF738: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF73C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000AF740: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000AF748: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000AF750: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000AF758: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000AF760: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000AF768: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000AF770: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000AF778: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000AF780: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000AF788: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF790: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF794: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF798: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF7A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF7A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF7AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF7B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF7B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF7C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF7C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000AF7C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF7D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF7D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF7DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000AF7E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000AF7E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000AF7F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000AF7F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000AF800: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000AF808: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000AF810: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000AF818: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000AF820: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000AF828: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000AF830: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF834: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000AF838: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000AF840: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000AF848: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF84C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000AF850: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000AF858: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000AF860: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF864: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000AF868: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF870: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF878: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF87C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000AF880: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000AF888: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000AF890: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000AF898: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000AF8A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000AF8A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000AF8B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000AF8B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000AF8C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000AF8C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000AF8D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF8D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000AF8D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000AF8E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000AF8E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF8EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000AF8F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000AF8F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000AF900: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF904: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000AF908: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000AF910: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000AF918: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF91C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000AF920: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000AF928: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000AF930: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF934: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000AF938: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000AF940: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000AF948: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AF94C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000AF950: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000AF958: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000AF964: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000AF96C: D8340000 0000201F
	s_branch 64819                                             // 0000000AF974: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000AF978: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000AF97C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000AF984: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000AF988: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000AF98C: BE8C0080
	s_branch 21                                                // 0000000AF990: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000AF994: 8C7E0D7E
	.long 0xd700011f                                           // 0000000AF998: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000AF99C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AF9A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000AF9A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000AF9B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000AF9B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000AF9BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000AF9C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000AF9C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000AF9CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000AF9D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000AF9D4: BC7C0000
	s_barrier                                                  // 0000000AF9D8: BFBD0000
	buffer_gl0_inv                                             // 0000000AF9DC: E0AC0000 00000000
	s_cbranch_scc1 198                                         // 0000000AF9E4: BFA200C6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AF9E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000AF9EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000AF9F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000AF9F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000AF9FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000AFA00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000AFA08: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000AFA10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000AFA14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AFA1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000AFA20: D5207C22 00064480
	.long 0xd4490004                                           // 0000000AFA28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000AFA2C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000AFA34: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000AFA38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000AFA3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000AFA44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000AFA4C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000AFA50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000AFA54: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000AFA58: BF89FC07
	s_barrier                                                  // 0000000AFA5C: BFBD0000
	buffer_gl0_inv                                             // 0000000AFA60: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000AFA68: BE8D2000
	s_cbranch_execz 65481                                      // 0000000AFA6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000AFA70: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA74: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000AFA78: 3848420B
	.long 0xd4440001                                           // 0000000AFA7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000AFA80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000AFA84: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000AFA88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 0000000AFA8C: 7E780280
	s_mov_b32 s1, 0                                            // 0000000AFA90: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AFA94: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000AFA98: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 0000000AFAA0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000AFAA4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset1:1                  // 0000000AFAA8: D8DC0100 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:2 offset1:3        // 0000000AFAB0: D8DC0302 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 0000000AFAB8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:6 offset1:7        // 0000000AFAC0: D8DC0706 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 0000000AFAC8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000AFAD4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 0000000AFAD8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[64:65], v61 offset0:34 offset1:51      // 0000000AFAE0: D8DC3322 4000003D
	ds_load_2addr_b32 v[66:67], v61 offset0:68 offset1:85      // 0000000AFAE8: D8DC5544 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:102 offset1:119    // 0000000AFAF0: D8DC7766 4400003D
	s_waitcnt lgkmcnt(7)                                       // 0000000AFAF8: BF89FC77
	v_fma_mixlo_f16 v61, v70, s6, 0                            // 0000000AFAFC: CC21003D 02000D46
	s_waitcnt lgkmcnt(6)                                       // 0000000AFB04: BF89FC67
	v_fma_mixlo_f16 v70, v72, s6, 0                            // 0000000AFB08: CC210046 02000D48
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AFB10: BF870002
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB14: CC20003D 8A000F3D
	s_waitcnt lgkmcnt(3)                                       // 0000000AFB1C: BF89FC37
	v_fma_mixlo_f16 v34, v62, s6, 0                            // 0000000AFB20: CC210022 02000D3E
	v_fma_mixlo_f16 v62, v63, s6, 0                            // 0000000AFB28: CC21003E 02000D3F
	v_fma_mixlo_f16 v63, v71, s6, 0                            // 0000000AFB30: CC21003F 02000D47
	s_waitcnt lgkmcnt(2)                                       // 0000000AFB38: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000AFB3C: CC210040 02000D40
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB44: CC200022 8A000F22
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB4C: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB54: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000AFB5C: BF870214
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB60: CC200040 8A000F40
	v_fmac_f32_e32 v60, v61, v34                               // 0000000AFB68: 5678453D
	v_fma_mixlo_f16 v34, v65, s6, 0                            // 0000000AFB6C: CC210022 02000D41
	v_fma_mixlo_f16 v61, v73, s6, 0                            // 0000000AFB74: CC21003D 02000D49
	v_fma_mix_f32 v65, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFB7C: CC200041 8A000F46
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000AFB84: BF870004
	v_fmac_f32_e32 v60, v63, v62                               // 0000000AFB88: 56787D3F
	s_waitcnt lgkmcnt(1)                                       // 0000000AFB8C: BF89FC17
	v_fma_mixlo_f16 v62, v66, s6, 0                            // 0000000AFB90: CC21003E 02000D42
	v_fma_mixlo_f16 v63, v74, s6, 0                            // 0000000AFB98: CC21003F 02000D4A
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBA0: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBA8: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000AFBB0: 56788141
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000AFBB4: CC210040 02000D43
	v_fma_mixlo_f16 v65, v75, s6, 0                            // 0000000AFBBC: CC210041 02000D4B
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBC4: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBCC: CC20003F 8A000F3F
	v_fmac_f32_e32 v60, v61, v34                               // 0000000AFBD4: 5678453D
	s_waitcnt lgkmcnt(0)                                       // 0000000AFBD8: BF89FC07
	v_fma_mixlo_f16 v34, v68, s6, 0                            // 0000000AFBDC: CC210022 02000D44
	v_fma_mixlo_f16 v61, v76, s6, 0                            // 0000000AFBE4: CC21003D 02000D4C
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBEC: CC200040 8A000F40
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFBF4: CC200041 8A000F41
	v_fmac_f32_e32 v60, v63, v62                               // 0000000AFBFC: 56787D3F
	v_fma_mixlo_f16 v62, v69, s6, 0                            // 0000000AFC00: CC21003E 02000D45
	v_fma_mixlo_f16 v63, v77, s6, 0                            // 0000000AFC08: CC21003F 02000D4D
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFC10: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFC18: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000AFC20: 56788141
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFC24: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000AFC2C: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC34: BF870093
	v_fmac_f32_e32 v60, v61, v34                               // 0000000AFC38: 5678453D
	v_fmac_f32_e32 v60, v63, v62                               // 0000000AFC3C: 56787D3F
	s_cbranch_scc1 65428                                       // 0000000AFC40: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000AFC44: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000AFC48: 7E7A0301
	s_mov_b32 s14, 0                                           // 0000000AFC4C: BE8E0080
	ds_load_b32 v62, v33 offset:17440                          // 0000000AFC50: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000AFC58: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000AFC60: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000AFC64: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000AFC68: 7E7C0323
	s_nop 0                                                    // 0000000AFC6C: BF800000
	s_nop 0                                                    // 0000000AFC70: BF800000
	s_nop 0                                                    // 0000000AFC74: BF800000
	s_nop 0                                                    // 0000000AFC78: BF800000
	s_nop 0                                                    // 0000000AFC7C: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000AFC80: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000AFC88: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000AFC90: 4A7C7CC1
	.long 0xd7000121                                           // 0000000AFC94: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000AFC98: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AFC9C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000AFCA0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000AFCA8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000AFCAC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000AFCB0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000AFCB8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000AFCBC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000AFCC0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000AFCC4: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000AFCC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000AFCCC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFCD0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000AFCD4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000AFCDC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000AFCE8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000AFCF4: DC960000 007C2421
	s_branch 65317                                             // 0000000AFCFC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000AFD00: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000AFD08: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000AFD0C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000AFD10: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000AFD18: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000AFD1C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000AFD24: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000AFD2C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000AFD30: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000AFD34: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000AFD3C: A0010401
	s_mov_b32 s4, 0                                            // 0000000AFD40: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000AFD44: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000AFD48: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000AFD4C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000AFD50: BF870585
	.long 0xd71c001d                                           // 0000000AFD54: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000AFD58: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000AFD5C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000AFD60: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000AFD68: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000AFD6C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000AFD74: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000AFD78: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000AFD7C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000AFD88: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000AFD90: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AFD98: BF870001
	.long 0xd4490001                                           // 0000000AFD9C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000AFDA0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000AFDA8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000AFDAC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000AFDB0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000AFDB4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000AFDBC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000AFDC4: 917E047E
	s_cbranch_execnz 65519                                     // 0000000AFDC8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AFDCC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000AFDD0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000AFDD8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000AFDE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000AFDE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000AFDE8: BF89FC07
	s_barrier                                                  // 0000000AFDEC: BFBD0000
	buffer_gl0_inv                                             // 0000000AFDF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000AFDF8: BF800000
	s_nop 0                                                    // 0000000AFDFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000AFE00: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000AFE08: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000AFE10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000AFE18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000AFE1C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000AFE24: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000AFE28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000AFE30: BF870004
	.long 0xd4490004                                           // 0000000AFE34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000AFE38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000AFE40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000AFE44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000AFE48: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000AFE4C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000AFE54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000AFE5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000AFE60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000AFE64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000AFE68: BF89FC07
	s_barrier                                                  // 0000000AFE6C: BFBD0000
	buffer_gl0_inv                                             // 0000000AFE70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000AFE78: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000AFE80: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000AFE88: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000AFE90: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000AFE98: 7E780300
	s_mov_b32 s4, 0                                            // 0000000AFE9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000AFEA0: BF840001
	s_nop 0                                                    // 0000000AFEA4: BF800000
	s_nop 0                                                    // 0000000AFEA8: BF800000
	s_nop 0                                                    // 0000000AFEAC: BF800000
	s_nop 0                                                    // 0000000AFEB0: BF800000
	s_nop 0                                                    // 0000000AFEB4: BF800000
	s_nop 0                                                    // 0000000AFEB8: BF800000
	s_nop 0                                                    // 0000000AFEBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFEC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000AFEC4: 327A7884
	.long 0xd4490001                                           // 0000000AFEC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000AFECC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000AFED4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000AFED8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000AFEE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000AFEE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000AFEF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000AFEF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000AFF00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000AFF08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000AFF10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000AFF18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000AFF20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000AFF24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000AFF30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000AFF34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000AFF38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000AFF40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000AFF44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000AFF48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000AFF4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000AFF54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000AFF58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000AFF5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000AFF64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000AFF70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000AFF78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000AFF80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000AFF84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000AFF88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AFF8C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000AFF90: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000AFF98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000AFFA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000AFFA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000AFFA8: BF89FC07
	s_barrier                                                  // 0000000AFFAC: BFBD0000
	buffer_gl0_inv                                             // 0000000AFFB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000AFFB8: BF800000
	s_nop 0                                                    // 0000000AFFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000AFFC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000AFFC8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000AFFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000AFFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000AFFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000AFFE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000AFFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000AFFF0: BF870004
	.long 0xd4490004                                           // 0000000AFFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000AFFF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B0000: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B0004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B0008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B000C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B0014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B001C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B0020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B0024: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B0028: BF89FC07
	s_barrier                                                  // 0000000B002C: BFBD0000
	buffer_gl0_inv                                             // 0000000B0030: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000B0038: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000B0040: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000B0048: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000B0050: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000B0058: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B005C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B0060: BF840001
	s_nop 0                                                    // 0000000B0064: BF800000
	s_nop 0                                                    // 0000000B0068: BF800000
	s_nop 0                                                    // 0000000B006C: BF800000
	s_nop 0                                                    // 0000000B0070: BF800000
	s_nop 0                                                    // 0000000B0074: BF800000
	s_nop 0                                                    // 0000000B0078: BF800000
	s_nop 0                                                    // 0000000B007C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0080: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B0084: 327A7884
	.long 0xd4490001                                           // 0000000B0088: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B008C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B0094: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B0098: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B00A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B00A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B00B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B00B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B00C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B00C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B00D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B00D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B00E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B00E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B00F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B00F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B00F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B0100: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B0104: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B0108: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B010C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0110: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B0114: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B0118: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B011C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0120: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B0124: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B0130: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B0138: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0140: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B0144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000B0148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B014C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000B0150: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B0158: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B0160: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B0164: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B0168: BF89FC07
	s_barrier                                                  // 0000000B016C: BFBD0000
	buffer_gl0_inv                                             // 0000000B0170: E0AC0000 00000000
	s_nop 0                                                    // 0000000B0178: BF800000
	s_nop 0                                                    // 0000000B017C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B0180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000B0188: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B0190: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B0198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B019C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B01A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B01A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B01B0: BF870004
	.long 0xd4490004                                           // 0000000B01B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B01B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B01C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B01C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B01C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B01CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B01D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B01DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B01E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B01E4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000B01E8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000B01F0: BF89FC07
	s_barrier                                                  // 0000000B01F4: BFBD0000
	buffer_gl0_inv                                             // 0000000B01F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000B0200: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000B0204: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000B020C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000B0214: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000B021C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000B0224: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B0228: BF840001
	s_nop 0                                                    // 0000000B022C: BF800000
	s_nop 0                                                    // 0000000B0230: BF800000
	s_nop 0                                                    // 0000000B0234: BF800000
	s_nop 0                                                    // 0000000B0238: BF800000
	s_nop 0                                                    // 0000000B023C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B0240: 327C7A84
	.long 0xd4490001                                           // 0000000B0244: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B0248: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B0250: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B0254: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B0258: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B0264: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B0268: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B0270: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B0278: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B0280: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B0288: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B0290: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B0298: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B02A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B02A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B02A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B02AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B02B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B02C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B02C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B02C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B02CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B02D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B02D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B02D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B02DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B02E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B02E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B02F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B02F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0300: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B0304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000B0308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B030C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000B0310: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B0318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B0320: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B0324: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B0328: BF89FC07
	s_barrier                                                  // 0000000B032C: BFBD0000
	buffer_gl0_inv                                             // 0000000B0330: E0AC0000 00000000
	s_nop 0                                                    // 0000000B0338: BF800000
	s_nop 0                                                    // 0000000B033C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B0340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000B0348: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B0350: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B0358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B035C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B0364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B0368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B0370: BF870004
	.long 0xd4490004                                           // 0000000B0374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B0378: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B0380: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B0384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B0388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B038C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B0394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B039C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B03A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B03A4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000B03A8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000B03B0: BF89FC07
	s_barrier                                                  // 0000000B03B4: BFBD0000
	buffer_gl0_inv                                             // 0000000B03B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000B03C0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000B03C8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000B03D0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000B03D8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000B03E0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B03E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B03E8: BF840001
	s_nop 0                                                    // 0000000B03EC: BF800000
	s_nop 0                                                    // 0000000B03F0: BF800000
	s_nop 0                                                    // 0000000B03F4: BF800000
	s_nop 0                                                    // 0000000B03F8: BF800000
	s_nop 0                                                    // 0000000B03FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0400: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B0404: 327A7884
	.long 0xd4490001                                           // 0000000B0408: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B040C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B0414: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B0418: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B0424: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B0428: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B0430: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B0438: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B0440: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B0448: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B0450: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B0458: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B0460: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B0464: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B0470: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B0474: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B0478: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B0480: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B0484: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B0488: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B048C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0490: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B0494: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B0498: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B049C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B04A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B04A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B04B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B04B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B04C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B04C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000B04C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B04CC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000B04D0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B04D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B04E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B04E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B04E8: BF89FC07
	s_barrier                                                  // 0000000B04EC: BFBD0000
	buffer_gl0_inv                                             // 0000000B04F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000B04F8: BF800000
	s_nop 0                                                    // 0000000B04FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B0500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000B0508: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B0510: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B0518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B051C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B0524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B0528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B0530: BF870004
	.long 0xd4490004                                           // 0000000B0534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B0538: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B0540: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B0544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B0548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B054C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B0554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B055C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B0560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B0564: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000B0568: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000B0570: BF89FC07
	s_barrier                                                  // 0000000B0574: BFBD0000
	buffer_gl0_inv                                             // 0000000B0578: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000B0580: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000B0584: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000B058C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000B0594: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000B059C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000B05A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B05A8: BF840001
	s_nop 0                                                    // 0000000B05AC: BF800000
	s_nop 0                                                    // 0000000B05B0: BF800000
	s_nop 0                                                    // 0000000B05B4: BF800000
	s_nop 0                                                    // 0000000B05B8: BF800000
	s_nop 0                                                    // 0000000B05BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000B05C0: 327C7884
	.long 0xd4490001                                           // 0000000B05C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B05C8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B05D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B05D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B05D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B05E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B05E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B05F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B05F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B0600: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B0608: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B0610: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B0618: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B0620: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B0624: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B0628: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B062C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B0638: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B0640: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B0644: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B0648: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B064C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0650: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B0654: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B0658: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B065C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0660: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000B0664: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000B0670: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B0674: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000B0678: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000B067C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0684: 917E047E
	s_cbranch_execnz 65485                                     // 0000000B0688: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000B068C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B0690: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000B0694: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B069C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B06A4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B06A8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B06AC: BF89FC07
	s_barrier                                                  // 0000000B06B0: BFBD0000
	buffer_gl0_inv                                             // 0000000B06B4: E0AC0000 00000000
	s_nop 0                                                    // 0000000B06BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B06C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000B06C8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B06D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B06D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B06DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B06E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B06E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B06F0: BF870004
	.long 0xd4490004                                           // 0000000B06F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B06F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B0700: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B0704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B0708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B070C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B0714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B071C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B0720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B0724: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000B0728: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000B0730: BF89FC07
	s_barrier                                                  // 0000000B0734: BFBD0000
	buffer_gl0_inv                                             // 0000000B0738: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000B0740: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000B0748: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000B0750: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000B0758: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000B0760: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000B0764: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B0768: BF840001
	s_nop 0                                                    // 0000000B076C: BF800000
	s_nop 0                                                    // 0000000B0770: BF800000
	s_nop 0                                                    // 0000000B0774: BF800000
	s_nop 0                                                    // 0000000B0778: BF800000
	s_nop 0                                                    // 0000000B077C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0780: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B0784: 327C7A84
	.long 0xd4490001                                           // 0000000B0788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B078C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B0794: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B0798: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B07A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B07A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B07B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B07B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B07C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B07C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B07D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B07D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B07E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B07E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B07E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B07EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B07F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B0800: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B0804: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B0808: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B080C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0810: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B0814: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B0818: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B081C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0820: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B0824: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B0830: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B0838: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0840: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B0844: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000B0848: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B084C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000B0850: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B0858: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B0860: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B0864: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B0868: BF89FC07
	s_barrier                                                  // 0000000B086C: BFBD0000
	buffer_gl0_inv                                             // 0000000B0870: E0AC0000 00000000
	s_nop 0                                                    // 0000000B0878: BF800000
	s_nop 0                                                    // 0000000B087C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B0880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000B0888: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B0890: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B0898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B089C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B08A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B08A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B08B0: BF870004
	.long 0xd4490004                                           // 0000000B08B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B08B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B08C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B08C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B08C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B08CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B08D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B08DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B08E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B08E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B08E8: BF89FC07
	s_barrier                                                  // 0000000B08EC: BFBD0000
	buffer_gl0_inv                                             // 0000000B08F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000B08F8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000B0900: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000B0908: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000B0910: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000B0918: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000B091C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B0920: BF840001
	s_nop 0                                                    // 0000000B0924: BF800000
	s_nop 0                                                    // 0000000B0928: BF800000
	s_nop 0                                                    // 0000000B092C: BF800000
	s_nop 0                                                    // 0000000B0930: BF800000
	s_nop 0                                                    // 0000000B0934: BF800000
	s_nop 0                                                    // 0000000B0938: BF800000
	s_nop 0                                                    // 0000000B093C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0940: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B0944: 327C7A84
	.long 0xd4490001                                           // 0000000B0948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B094C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B0954: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B0958: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B0964: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B0968: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B0970: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B0978: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B0980: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B0988: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B0990: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B0998: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B09A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B09A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B09A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B09AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B09B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B09C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B09C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B09C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B09CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B09D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B09D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B09D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B09DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B09E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B09E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B09F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B09F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0A00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B0A04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000B0A08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B0A0C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000B0A10: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B0A18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B0A20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B0A24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B0A28: BF89FC07
	s_barrier                                                  // 0000000B0A2C: BFBD0000
	buffer_gl0_inv                                             // 0000000B0A30: E0AC0000 00000000
	s_nop 0                                                    // 0000000B0A38: BF800000
	s_nop 0                                                    // 0000000B0A3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B0A40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000B0A48: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B0A50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B0A58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B0A5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B0A64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B0A68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B0A70: BF870004
	.long 0xd4490004                                           // 0000000B0A74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B0A78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B0A80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B0A84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B0A88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B0A8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B0A94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B0A9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B0AA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B0AA4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000B0AA8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000B0AB0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000B0AB8: BF89FC07
	s_barrier                                                  // 0000000B0ABC: BFBD0000
	buffer_gl0_inv                                             // 0000000B0AC0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000B0AC8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000B0AD0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000B0AD8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000B0AE0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000B0AE8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B0AEC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B0AF0: BF840001
	s_nop 0                                                    // 0000000B0AF4: BF800000
	s_nop 0                                                    // 0000000B0AF8: BF800000
	s_nop 0                                                    // 0000000B0AFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0B00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B0B04: 327A7884
	.long 0xd4490001                                           // 0000000B0B08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B0B0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B0B14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B0B18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B0B24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B0B28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B0B30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B0B38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B0B40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B0B48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B0B50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B0B58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B0B60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B0B64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B0B70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B0B74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B0B78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B0B80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B0B84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B0B88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B0B8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B0B94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B0B98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B0B9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0BA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B0BA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B0BB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B0BB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B0BC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B0BC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 0000000B0BC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B0BCC: 8C7E047E
	.long 0xd7000107                                           // 0000000B0BD0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000B0BD4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B0BDC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000B0BE0: D5207C08 00061080
	.long 0xd7000109                                           // 0000000B0BE8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000B0BEC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000B0BF4: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000B0BFC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000B0C00: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B0C08: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000B0C0C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000B0C14: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000B0C18: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000B0C20: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000B0C28: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000B0C2C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B0C34: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000B0C38: D5207C10 00062080
	.long 0xd7000111                                           // 0000000B0C40: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000B0C44: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000B0C4C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000B0C54: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000B0C58: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B0C60: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000B0C64: D5207C14 00062880
	.long 0xd7000115                                           // 0000000B0C6C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000B0C70: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000B0C78: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000B0C80: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000B0C84: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B0C8C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000B0C90: D5207C18 00063080
	.long 0xd7000119                                           // 0000000B0C98: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000B0C9C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000B0CA4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000B0CAC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000B0CB0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B0CB8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000B0CBC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000B0CC4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000B0CC8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000B0CCC: BF062105
	s_barrier                                                  // 0000000B0CD0: BFBD0000
	buffer_gl0_inv                                             // 0000000B0CD4: E0AC0000 00000000
	s_cbranch_scc0 63477                                       // 0000000B0CDC: BFA1F7F5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000B0CE0: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000B0CE4: 8000141C
	.long 0xd73c0000                                           // 0000000B0CE8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000B0CEC: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000B0CF0: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000B0CF4: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000B0CF8: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000B0CFC: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000B0D00: 82010103
	.long 0xd7006a00                                           // 0000000B0D04: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000B0D08: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B0D0C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000B0D10: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000B0D18: BE810080
	.long 0xd7006a00                                           // 0000000B0D1C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000B0D20: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000B0D24: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D2C: BF870092
	.long 0xd7006a00                                           // 0000000B0D30: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000B0D34: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000B0D38: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000B0D40: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000B0D48: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000B0D50: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000B0D58: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B0D5C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000B0D64: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000B0D68: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000B0D6C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000B0D74: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000B0D78: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000B0D80: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000B0D88: 917E017E
	s_cbranch_execnz 65516                                     // 0000000B0D8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 0000000B0D90: BFB00000
		...

