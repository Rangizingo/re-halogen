00000000000b0e00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000B0E00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000B0E04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000B0E0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000B0E14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000B0E18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000B0E1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000B0E20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000B0E28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000B0E2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000B0E30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000B0E34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000B0E3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000B0E40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000B0E44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000B0E48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B0E4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000B0E50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000B0E54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000B0E58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000B0E5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000B0E64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000B0E6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000B0E70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000B0E74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B0E78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000B0E7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000B0E80: 821E191E
	.long 0xd7001f02                                           // 0000000B0E84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000B0E88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000B0E8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000B0E94: BE9E0080
	s_nop 0                                                    // 0000000B0E98: BF800000
	s_nop 0                                                    // 0000000B0E9C: BF800000
	s_nop 0                                                    // 0000000B0EA0: BF800000
	s_nop 0                                                    // 0000000B0EA4: BF800000
	s_nop 0                                                    // 0000000B0EA8: BF800000
	s_nop 0                                                    // 0000000B0EAC: BF800000
	s_nop 0                                                    // 0000000B0EB0: BF800000
	s_nop 0                                                    // 0000000B0EB4: BF800000
	s_nop 0                                                    // 0000000B0EB8: BF800000
	s_nop 0                                                    // 0000000B0EBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000B0EC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000B0EC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0ECC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000B0ED0: 300C1089
	.long 0xd7006a06                                           // 0000000B0ED4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000B0ED8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B0EDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000B0EE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B0EE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000B0EF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000B0EF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000B0EFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000B0F08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000B0F0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000B0F10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000B0F18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000B0F1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000B0F20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000B0F24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000B0F2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000B0F34: 32040084
	s_mov_b32 s0, 0                                            // 0000000B0F38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000B0F3C: BF89FC07
	s_barrier                                                  // 0000000B0F40: BFBD0000
	buffer_gl0_inv                                             // 0000000B0F44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000B0F4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000B0F50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000B0F54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000B0F5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B0F64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000B0F68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000B0F70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000B0F74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000B0F78: 916A007E
	s_cbranch_vccz 2                                           // 0000000B0F7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2616                                              // 0000000B0F80: BFA00A38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a64>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000B0F84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000B0F88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000B0F8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000B0F94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000B0F98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000B0F9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000B0FA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000B0FA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000B0FAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000B0FB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000B0FB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000B0FB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000B0FBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000B0FC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000B0FC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000B0FC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000B0FD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000B0FD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000B0FDC: B00A0204
	.long 0xd7000b2c                                           // 0000000B0FE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000B0FE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000B0FE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000B0FEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000B0FF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000B1000: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000B1004: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000B1010: 3816500A
	.long 0xd7000a05                                           // 0000000B1014: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000B1018: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B101C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000B1020: D5207C06 00290001
	.long 0xd7000107                                           // 0000000B1028: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000B102C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B1030: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000B1034: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000B103C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000B1040: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000B1044: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000B104C: 84848E02
	.long 0xd700010b                                           // 0000000B1050: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000B1054: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000B1058: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000B105C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000B1064: 8205050F
	.long 0xd700010d                                           // 0000000B1068: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000B106C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B1070: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000B1074: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000B107C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000B1080: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000B1088: D5207C10 00061880
	.long 0xd7000111                                           // 0000000B1090: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000B1094: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B109C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000B10A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000B10A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000B10AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000B10B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000B10BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000B10C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B10C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000B10CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000B10D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000B10D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000B10E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000B10E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000B10EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B10F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000B10F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000B1100: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000B1104: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000B110C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000B1114: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000B1118: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000B1120: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000B1124: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000B112C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000B1134: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000B113C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000B1144: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000B114C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000B1154: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000B115C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000B1164: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000B116C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000B1174: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000B117C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000B1184: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000B118C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000B1194: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000B119C: BE850080
	s_mov_b32 s6, 0x41800000                                   // 0000000B11A0: BE8600FF 41800000
	s_mov_b32 s7, 0x3d800000                                   // 0000000B11A8: BE8700FF 3D800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000B11B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000B11B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B11BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000B11C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000B11C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B11C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000B11CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000B11D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000B11D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000B11D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000B11DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000B11E4: BE84206A
	s_cbranch_execz 77                                         // 0000000B11E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000B11EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B11F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000B11F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000B11FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1200: BF870091
	.long 0xd73c001d                                           // 0000000B1204: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000B1208: 02023A82
	.long 0xd700011d                                           // 0000000B120C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000B1210: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B1214: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000B1218: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000B1220: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B1228: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000B122C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000B1230: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000B123C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000B1240: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000B124C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000B1250: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000B125C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B1260: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000B1264: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000B1270: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1274: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000B1278: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000B1280: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000B1284: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000B128C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000B1294: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000B1298: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B129C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000B12A0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000B12A4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B12A8: BF870296
	.long 0xd71c0020                                           // 0000000B12AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000B12B0: 02024520
	.long 0xd71c001f                                           // 0000000B12B4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000B12B8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B12BC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000B12C0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000B12C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000B12CC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000B12D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000B12DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000B12E0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B12E8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000B12EC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000B12F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000B12FC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000B1304: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000B1310: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000B1318: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B1320: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000B1324: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000B132C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B1330: BF89FC07
	s_barrier                                                  // 0000000B1334: BFBD0000
	buffer_gl0_inv                                             // 0000000B1338: E0AC0000 00000000
	s_branch 15                                                // 0000000B1340: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B1344: 8C7E047E
	.long 0xd700011d                                           // 0000000B1348: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000B134C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1354: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B1358: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B1360: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B1364: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B1368: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000B136C: BF89FC07
	s_barrier                                                  // 0000000B1370: BFBD0000
	buffer_gl0_inv                                             // 0000000B1374: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000B137C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000B1380: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000B1388: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000B1390: BE8D0080
	s_nop 0                                                    // 0000000B1394: BF800000
	s_nop 0                                                    // 0000000B1398: BF800000
	s_nop 0                                                    // 0000000B139C: BF800000
	s_nop 0                                                    // 0000000B13A0: BF800000
	s_nop 0                                                    // 0000000B13A4: BF800000
	s_nop 0                                                    // 0000000B13A8: BF800000
	s_nop 0                                                    // 0000000B13AC: BF800000
	s_nop 0                                                    // 0000000B13B0: BF800000
	s_nop 0                                                    // 0000000B13B4: BF800000
	s_nop 0                                                    // 0000000B13B8: BF800000
	s_nop 0                                                    // 0000000B13BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000B13C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000B13C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000B13D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000B13D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B13DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B13E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000B13E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000B13EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B13F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B13F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000B13FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000B1404: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B140C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B1410: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B1414: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B1418: BF89FC07
	s_barrier                                                  // 0000000B141C: BFBD0000
	buffer_gl0_inv                                             // 0000000B1420: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000B1428: BE842000
	s_cbranch_execz 65477                                      // 0000000B142C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000B1430: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000B1438: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000B1440: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000B1448: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000B1450: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000B1458: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000B1460: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000B1468: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000B1470: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000B1478: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000B1480: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000B1488: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000B1490: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000B1498: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B14A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000B14A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000B14AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000B14B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B14B4: BF870091
	.long 0xd7000146                                           // 0000000B14B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000B14BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000B14C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000B14C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000B14D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000B14D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B14DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000B14E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000B14E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000B14EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000B14F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000B14FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000B1504: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000B150C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000B1514: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1518: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000B151C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000B1524: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000B152C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1530: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000B1534: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000B153C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000B1544: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1548: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000B154C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000B1554: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000B155C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1560: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B1564: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000B156C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000B1574: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000B157C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000B1584: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000B158C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000B1594: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000B159C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000B15A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B15AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000B15B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B15B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000B15BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000B15C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B15CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000B15D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000B15D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000B15E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B15E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000B15E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000B15F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000B15F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B15FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000B1600: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000B1608: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000B1610: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000B1618: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000B1620: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000B1628: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000B1630: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000B1638: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000B1640: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000B1648: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000B1650: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1654: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000B1658: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000B1660: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000B1668: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B166C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B1670: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B1678: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1680: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1684: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000B1688: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000B1690: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000B1698: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B169C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B16A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000B16A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000B16B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000B16B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000B16C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000B16C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000B16D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000B16D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000B16E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B16E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B16F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B16F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B16F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1700: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1708: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B170C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000B1710: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000B1718: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000B1720: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1724: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000B1728: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000B1730: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000B1738: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B173C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000B1740: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000B1748: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000B1750: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000B1758: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000B1760: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000B1768: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000B1770: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000B1778: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000B1780: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000B1788: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000B1790: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1794: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B1798: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B17A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B17A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B17B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B17B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B17C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000B17C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000B17D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000B17D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B17DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B17E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000B17E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000B17F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000B17F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000B1800: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000B1808: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000B1810: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000B1818: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000B1820: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B1828: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B1830: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1834: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B1838: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1840: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1848: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B184C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000B1850: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000B1858: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000B1860: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1864: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000B1868: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1870: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1878: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B187C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000B1880: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000B1888: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000B1890: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000B1898: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000B18A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000B18A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000B18B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000B18B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000B18C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000B18C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000B18D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B18D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B18E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B18E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B18F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B18F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1900: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1904: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000B1908: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1910: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1918: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B191C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B1920: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000B1928: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000B1930: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000B1938: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000B1940: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000B1948: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000B1950: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000B1958: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000B1960: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B1968: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B1970: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1974: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B1978: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1980: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1988: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B198C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000B1990: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000B1998: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000B19A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B19A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000B19A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B19B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B19B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B19BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000B19C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000B19C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000B19D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000B19D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000B19E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000B19E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000B19F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000B19F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000B1A00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000B1A08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000B1A10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1A14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B1A18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B1A20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B1A28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1A2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B1A30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B1A38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1A40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1A44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000B1A48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1A50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1A58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1A5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B1A60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000B1A68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000B1A70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000B1A78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000B1A80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000B1A88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000B1A90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000B1A98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000B1AA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B1AA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B1AB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1AB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B1AB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1AC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1AC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1ACC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000B1AD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000B1AD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000B1AE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1AE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000B1AE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1AF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1AF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1AFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000B1B00: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000B1B08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000B1B10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000B1B18: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000B1B20: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000B1B28: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000B1B30: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000B1B38: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000B1B40: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000B1B48: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000B1B50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B54: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B1B58: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B1B60: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B1B68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B1B70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B1B78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1B80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B84: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000B1B88: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1B90: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1B98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1B9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B1BA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000B1BA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000B1BB0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000B1BB8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000B1BC0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000B1BC8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000B1BD0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000B1BD8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000B1BE0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B1BE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B1BF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1BF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B1BF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1C00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1C08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000B1C10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000B1C18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000B1C20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000B1C28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1C30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1C38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1C3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000B1C40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000B1C48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000B1C50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000B1C58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000B1C60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000B1C68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000B1C70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000B1C78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000B1C80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000B1C88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000B1C90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B1C98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B1CA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B1CA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1CAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B1CB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B1CB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1CC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1CC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000B1CC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1CD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1CD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1CDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000B1CE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000B1CE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000B1CF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000B1CF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000B1D00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000B1D08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000B1D10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000B1D18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000B1D20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000B1D28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000B1D30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000B1D38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000B1D40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000B1D48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000B1D50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000B1D58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000B1D60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000B1D68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1D70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1D78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1D7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000B1D80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000B1D88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000B1D90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000B1D98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000B1DA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000B1DA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000B1DB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000B1DB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000B1DC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000B1DC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000B1DD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1DD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000B1DD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000B1DE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000B1DE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1DEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000B1DF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000B1DF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000B1E00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000B1E08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000B1E10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000B1E18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E1C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000B1E20: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000B1E28: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000B1E30: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E34: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000B1E38: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000B1E40: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000B1E48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1E4C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000B1E50: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000B1E58: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000B1E64: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000B1E6C: D8340000 0000201F
	s_branch 64819                                             // 0000000B1E74: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000B1E78: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000B1E7C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000B1E84: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000B1E88: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000B1E8C: BE8C0080
	s_branch 21                                                // 0000000B1E90: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B1E94: 8C7E0D7E
	.long 0xd700011f                                           // 0000000B1E98: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000B1E9C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1EA4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B1EA8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000B1EB0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000B1EB4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000B1EBC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B1EC0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B1EC8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B1ECC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B1ED0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000B1ED4: BC7C0000
	s_barrier                                                  // 0000000B1ED8: BFBD0000
	buffer_gl0_inv                                             // 0000000B1EDC: E0AC0000 00000000
	s_cbranch_scc1 609                                         // 0000000B1EE4: BFA20261 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B1EE8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000B1EEC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000B1EF4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000B1EF8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000B1EFC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000B1F00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000B1F08: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000B1F10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000B1F14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B1F1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000B1F20: D5207C22 00064480
	.long 0xd4490004                                           // 0000000B1F28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000B1F2C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B1F34: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B1F38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000B1F3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000B1F44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B1F4C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B1F50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B1F54: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B1F58: BF89FC07
	s_barrier                                                  // 0000000B1F5C: BFBD0000
	buffer_gl0_inv                                             // 0000000B1F60: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000B1F68: BE8D2000
	s_cbranch_execz 65481                                      // 0000000B1F6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000B1F70: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F74: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000B1F78: 3848420B
	.long 0xd4440001                                           // 0000000B1F7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000B1F80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000B1F84: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000B1F88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000B1F8C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000B1F94: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000B1F9C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000B1FA4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000B1FAC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000B1FB4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000B1FBC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000B1FC4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000B1FCC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000B1FD0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000B1FD4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B1FDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B1FE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B1FE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B1FE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B1FEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B1FF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B1FF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B1FF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B1FFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B200C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000B2014: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000B201C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000B2024: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000B202C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000B2034: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000B203C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000B2044: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000B204C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000B2054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B205C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B206C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B207C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B208C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000B2094: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000B209C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000B20A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000B20AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000B20B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000B20BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000B20C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000B20CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000B20D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B20D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B20DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B20E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B20E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B20E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B20EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B20F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B20F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B20F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B20FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B210C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000B2114: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000B211C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000B2124: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000B212C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000B2134: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000B213C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000B2144: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000B214C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000B2154: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2158: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B215C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2160: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2164: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2168: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B216C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2170: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2174: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2178: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B217C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2180: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2184: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2188: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B218C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2190: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000B2194: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000B219C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000B21A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000B21AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000B21B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000B21BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000B21C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000B21CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000B21D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B21D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B21DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B21E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B21E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B21E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B21EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B21F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B21F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B21F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B21FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2200: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2204: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2208: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B220C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2210: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000B2214: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000B221C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000B2224: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000B222C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000B2234: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000B223C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000B2244: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000B224C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000B2254: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2258: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B225C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2260: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2264: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2268: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B226C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2270: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2274: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2278: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B227C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2280: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2284: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2288: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B228C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2290: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000B2294: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000B229C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000B22A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000B22AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000B22B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000B22BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000B22C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000B22CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000B22D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B22D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B22DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B22E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B22E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B22E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B22EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B22F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B22F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B22F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B22FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B230C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000B2314: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000B231C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000B2324: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000B232C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000B2334: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000B233C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000B2344: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000B234C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000B2354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B235C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B236C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B237C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B238C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000B2394: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000B239C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000B23A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000B23AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000B23B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000B23BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000B23C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000B23CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000B23D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B23D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B23DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B23E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B23E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B23E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B23EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B23F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B23F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B23F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B23FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B240C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000B2414: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000B241C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000B2424: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000B242C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000B2434: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000B243C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000B2444: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000B244C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000B2454: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2458: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B245C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2460: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2464: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2468: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B246C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2470: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2474: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2478: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B247C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2480: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2484: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2488: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B248C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2490: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000B2494: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000B249C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000B24A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000B24AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000B24B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000B24BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000B24C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000B24CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000B24D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B24D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B24DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B24E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B24E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B24E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B24EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B24F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B24F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B24F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B24FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2500: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2504: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2508: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B250C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2510: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000B2514: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000B251C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000B2524: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000B252C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000B2534: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000B253C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000B2544: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000B254C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000B2554: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2558: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B255C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2560: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2564: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2568: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B256C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2570: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2574: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2578: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B257C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2580: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2584: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2588: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B258C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2590: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000B2594: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000B259C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000B25A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000B25AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000B25B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000B25BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000B25C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000B25CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000B25D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B25D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B25DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B25E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B25E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B25E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B25EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B25F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B25F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B25F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B25FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B260C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2610: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000B2614: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000B261C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000B2624: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000B262C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000B2634: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000B263C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000B2644: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000B264C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000B2654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B2658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B265C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B2664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B266C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B2674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B267C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B268C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2690: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000B2694: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000B269C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000B26A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000B26AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000B26B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000B26BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000B26C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000B26CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000B26D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B26D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B26DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B26E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B26E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B26E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B26EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B26F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B26F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B26F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B26FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B2704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B2708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B270C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B2710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000B2714: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000B271C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000B2724: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000B272C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000B2734: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000B273C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000B2744: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000B274C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000B2754: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000B2758: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B275C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000B2760: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000B2768: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000B2770: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B2774: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000B2778: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000B277C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2780: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B2784: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B2788: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000B278C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2790: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B2794: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B2798: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000B279C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B27A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B27A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B27A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000B27AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B27B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000B27B4: 1078794C
	s_nop 0                                                    // 0000000B27B8: BF800000
	s_nop 0                                                    // 0000000B27BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000B27C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000B27C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000B27D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000B27D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000B27D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B27DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000B27E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000B27E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000B27EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000B27F0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000B27F8: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000B27FC: BF89FC07
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000B2800: CC210040 02000D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B2808: BF8700B1
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B280C: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000B2814: BF8903F7
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000B2818: CC21003F 02000D3F
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B2820: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B2828: BF870001
	v_fmac_f32_e32 v60, v63, v64                               // 0000000B282C: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000B2830: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000B2834: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000B2838: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B283C: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000B2840: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000B2848: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000B2854: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000B2860: DC960000 007C2421
	s_branch 64906                                             // 0000000B2868: BFA0FD8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000B286C: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000B2874: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000B2878: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000B287C: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000B2884: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000B2888: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000B2890: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000B2898: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000B289C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000B28A0: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000B28A8: A0010401
	s_mov_b32 s4, 0                                            // 0000000B28AC: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000B28B0: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000B28B4: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000B28B8: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000B28BC: BF870585
	.long 0xd71c001d                                           // 0000000B28C0: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000B28C4: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000B28C8: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000B28CC: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000B28D4: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000B28D8: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000B28E0: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000B28E4: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000B28E8: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000B28F4: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000B28FC: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B2904: BF870001
	.long 0xd4490001                                           // 0000000B2908: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000B290C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000B2914: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000B2918: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000B291C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000B2920: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000B2928: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B2930: 917E047E
	s_cbranch_execnz 65519                                     // 0000000B2934: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1af4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B2938: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000B293C: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000B2944: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000B294C: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B2950: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B2954: BF89FC07
	s_barrier                                                  // 0000000B2958: BFBD0000
	buffer_gl0_inv                                             // 0000000B295C: E0AC0000 00000000
	s_nop 0                                                    // 0000000B2964: BF800000
	s_nop 0                                                    // 0000000B2968: BF800000
	s_nop 0                                                    // 0000000B296C: BF800000
	s_nop 0                                                    // 0000000B2970: BF800000
	s_nop 0                                                    // 0000000B2974: BF800000
	s_nop 0                                                    // 0000000B2978: BF800000
	s_nop 0                                                    // 0000000B297C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B2980: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000B2988: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B2990: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B2998: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B299C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000B29A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B29A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B29B0: BF870004
	.long 0xd4490004                                           // 0000000B29B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B29B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B29C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B29C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B29C8: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000B29CC: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000B29D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B29DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B29E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B29E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B29E8: BF89FC07
	s_barrier                                                  // 0000000B29EC: BFBD0000
	buffer_gl0_inv                                             // 0000000B29F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000B29F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000B2A00: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000B2A08: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000B2A10: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000B2A18: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B2A1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B2A20: BF840001
	s_nop 0                                                    // 0000000B2A24: BF800000
	s_nop 0                                                    // 0000000B2A28: BF800000
	s_nop 0                                                    // 0000000B2A2C: BF800000
	s_nop 0                                                    // 0000000B2A30: BF800000
	s_nop 0                                                    // 0000000B2A34: BF800000
	s_nop 0                                                    // 0000000B2A38: BF800000
	s_nop 0                                                    // 0000000B2A3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2A40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B2A44: 327A7884
	.long 0xd4490001                                           // 0000000B2A48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B2A4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B2A54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B2A58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B2A64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B2A68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B2A70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B2A78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B2A80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B2A88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B2A90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B2A98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B2AA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B2AA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B2AB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B2AB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B2AB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B2AC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B2AC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B2AC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B2ACC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B2AD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B2AD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B2ADC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B2AE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B2AF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B2AF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B2B00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B2B04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_set_inst_prefetch_distance 0x2                           // 0000000B2B08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B2B0C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000B2B10: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B2B18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B2B20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B2B24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B2B28: BF89FC07
	s_barrier                                                  // 0000000B2B2C: BFBD0000
	buffer_gl0_inv                                             // 0000000B2B30: E0AC0000 00000000
	s_nop 0                                                    // 0000000B2B38: BF800000
	s_nop 0                                                    // 0000000B2B3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B2B40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000B2B48: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B2B50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B2B58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B2B5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B2B64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B2B68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B2B70: BF870004
	.long 0xd4490004                                           // 0000000B2B74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B2B78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B2B80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B2B84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B2B88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B2B8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B2B94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B2B9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B2BA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B2BA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B2BA8: BF89FC07
	s_barrier                                                  // 0000000B2BAC: BFBD0000
	buffer_gl0_inv                                             // 0000000B2BB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000B2BB8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000B2BC0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000B2BC8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000B2BD0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000B2BD8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B2BDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B2BE0: BF840001
	s_nop 0                                                    // 0000000B2BE4: BF800000
	s_nop 0                                                    // 0000000B2BE8: BF800000
	s_nop 0                                                    // 0000000B2BEC: BF800000
	s_nop 0                                                    // 0000000B2BF0: BF800000
	s_nop 0                                                    // 0000000B2BF4: BF800000
	s_nop 0                                                    // 0000000B2BF8: BF800000
	s_nop 0                                                    // 0000000B2BFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2C00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B2C04: 327A7884
	.long 0xd4490001                                           // 0000000B2C08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B2C0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B2C14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B2C18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B2C24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B2C28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B2C30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B2C38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B2C40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B2C48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B2C50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B2C58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B2C60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B2C64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B2C70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B2C74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B2C78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B2C80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B2C84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B2C88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B2C8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2C90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B2C94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B2C98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B2C9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2CA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B2CA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B2CB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B2CB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B2CC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B2CC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_set_inst_prefetch_distance 0x2                           // 0000000B2CC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B2CCC: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000B2CD0: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B2CD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B2CE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B2CE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B2CE8: BF89FC07
	s_barrier                                                  // 0000000B2CEC: BFBD0000
	buffer_gl0_inv                                             // 0000000B2CF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000B2CF8: BF800000
	s_nop 0                                                    // 0000000B2CFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B2D00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000B2D08: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B2D10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B2D18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B2D1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B2D24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B2D28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B2D30: BF870004
	.long 0xd4490004                                           // 0000000B2D34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B2D38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B2D40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B2D44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B2D48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B2D4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B2D54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B2D5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B2D60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B2D64: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000B2D68: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000B2D70: BF89FC07
	s_barrier                                                  // 0000000B2D74: BFBD0000
	buffer_gl0_inv                                             // 0000000B2D78: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000B2D80: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000B2D84: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000B2D8C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000B2D94: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000B2D9C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000B2DA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B2DA8: BF840001
	s_nop 0                                                    // 0000000B2DAC: BF800000
	s_nop 0                                                    // 0000000B2DB0: BF800000
	s_nop 0                                                    // 0000000B2DB4: BF800000
	s_nop 0                                                    // 0000000B2DB8: BF800000
	s_nop 0                                                    // 0000000B2DBC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B2DC0: 327C7A84
	.long 0xd4490001                                           // 0000000B2DC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B2DC8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B2DD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B2DD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B2DD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B2DE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B2DE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B2DF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B2DF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B2E00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B2E08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B2E10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B2E18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B2E20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B2E24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B2E28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B2E2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B2E38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B2E40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B2E44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B2E48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B2E4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B2E54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B2E58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B2E5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B2E64: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B2E70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B2E78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B2E80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B2E84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000B2E88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B2E8C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000B2E90: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B2E98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B2EA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B2EA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B2EA8: BF89FC07
	s_barrier                                                  // 0000000B2EAC: BFBD0000
	buffer_gl0_inv                                             // 0000000B2EB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000B2EB8: BF800000
	s_nop 0                                                    // 0000000B2EBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B2EC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000B2EC8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B2ED0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B2ED8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B2EDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B2EE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B2EE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B2EF0: BF870004
	.long 0xd4490004                                           // 0000000B2EF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B2EF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B2F00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B2F04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B2F08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B2F0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B2F14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B2F1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B2F20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B2F24: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000B2F28: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000B2F30: BF89FC07
	s_barrier                                                  // 0000000B2F34: BFBD0000
	buffer_gl0_inv                                             // 0000000B2F38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000B2F40: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000B2F48: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000B2F50: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000B2F58: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000B2F60: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B2F64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B2F68: BF840001
	s_nop 0                                                    // 0000000B2F6C: BF800000
	s_nop 0                                                    // 0000000B2F70: BF800000
	s_nop 0                                                    // 0000000B2F74: BF800000
	s_nop 0                                                    // 0000000B2F78: BF800000
	s_nop 0                                                    // 0000000B2F7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2F80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B2F84: 327A7884
	.long 0xd4490001                                           // 0000000B2F88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B2F8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B2F94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B2F98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B2FA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B2FA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B2FB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B2FB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B2FC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B2FC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B2FD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B2FD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B2FE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B2FE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B2FF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B2FF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B2FF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B3000: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B3004: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B3008: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B300C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3010: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B3014: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B3018: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B301C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3020: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B3024: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B3030: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B3038: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B3040: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B3044: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_set_inst_prefetch_distance 0x2                           // 0000000B3048: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B304C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000B3050: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B3058: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B3060: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B3064: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B3068: BF89FC07
	s_barrier                                                  // 0000000B306C: BFBD0000
	buffer_gl0_inv                                             // 0000000B3070: E0AC0000 00000000
	s_nop 0                                                    // 0000000B3078: BF800000
	s_nop 0                                                    // 0000000B307C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B3080: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000B3088: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B3090: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B3098: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B309C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B30A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B30A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B30B0: BF870004
	.long 0xd4490004                                           // 0000000B30B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B30B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B30C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B30C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B30C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B30CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B30D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B30DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B30E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B30E4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000B30E8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000B30F0: BF89FC07
	s_barrier                                                  // 0000000B30F4: BFBD0000
	buffer_gl0_inv                                             // 0000000B30F8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000B3100: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000B3104: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000B310C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000B3114: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000B311C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000B3124: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B3128: BF840001
	s_nop 0                                                    // 0000000B312C: BF800000
	s_nop 0                                                    // 0000000B3130: BF800000
	s_nop 0                                                    // 0000000B3134: BF800000
	s_nop 0                                                    // 0000000B3138: BF800000
	s_nop 0                                                    // 0000000B313C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000B3140: 327C7884
	.long 0xd4490001                                           // 0000000B3144: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B3148: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B3150: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B3154: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B3158: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B3164: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B3168: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B3170: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B3178: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B3180: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B3188: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B3190: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B3198: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B31A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B31A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B31A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B31AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B31B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B31C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B31C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B31C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B31CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B31D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B31D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B31D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B31DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B31E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000B31E4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000B31F0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B31F4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000B31F8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000B31FC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B3204: 917E047E
	s_cbranch_execnz 65485                                     // 0000000B3208: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 0000000B320C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B3210: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000B3214: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B321C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B3224: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B3228: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B322C: BF89FC07
	s_barrier                                                  // 0000000B3230: BFBD0000
	buffer_gl0_inv                                             // 0000000B3234: E0AC0000 00000000
	s_nop 0                                                    // 0000000B323C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B3240: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000B3248: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B3250: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B3258: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B325C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B3264: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B3268: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B3270: BF870004
	.long 0xd4490004                                           // 0000000B3274: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B3278: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B3280: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B3284: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B3288: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B328C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B3294: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B329C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B32A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B32A4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000B32A8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000B32B0: BF89FC07
	s_barrier                                                  // 0000000B32B4: BFBD0000
	buffer_gl0_inv                                             // 0000000B32B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000B32C0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000B32C8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000B32D0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000B32D8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000B32E0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000B32E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B32E8: BF840001
	s_nop 0                                                    // 0000000B32EC: BF800000
	s_nop 0                                                    // 0000000B32F0: BF800000
	s_nop 0                                                    // 0000000B32F4: BF800000
	s_nop 0                                                    // 0000000B32F8: BF800000
	s_nop 0                                                    // 0000000B32FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3300: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B3304: 327C7A84
	.long 0xd4490001                                           // 0000000B3308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B330C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B3314: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B3318: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B3324: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B3328: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B3330: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B3338: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B3340: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B3348: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B3350: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B3358: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B3360: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B3364: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B3368: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B336C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B3378: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B3380: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B3384: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B3388: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B338C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3390: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B3394: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B3398: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B339C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B33A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B33B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B33B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B33C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B33C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_set_inst_prefetch_distance 0x2                           // 0000000B33C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B33CC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000B33D0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B33D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B33E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B33E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B33E8: BF89FC07
	s_barrier                                                  // 0000000B33EC: BFBD0000
	buffer_gl0_inv                                             // 0000000B33F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000B33F8: BF800000
	s_nop 0                                                    // 0000000B33FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B3400: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000B3408: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B3410: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B3418: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B341C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B3424: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B3428: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B3430: BF870004
	.long 0xd4490004                                           // 0000000B3434: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B3438: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B3440: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B3444: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B3448: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B344C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B3454: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B345C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B3460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B3464: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B3468: BF89FC07
	s_barrier                                                  // 0000000B346C: BFBD0000
	buffer_gl0_inv                                             // 0000000B3470: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000B3478: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000B3480: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000B3488: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000B3490: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000B3498: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000B349C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B34A0: BF840001
	s_nop 0                                                    // 0000000B34A4: BF800000
	s_nop 0                                                    // 0000000B34A8: BF800000
	s_nop 0                                                    // 0000000B34AC: BF800000
	s_nop 0                                                    // 0000000B34B0: BF800000
	s_nop 0                                                    // 0000000B34B4: BF800000
	s_nop 0                                                    // 0000000B34B8: BF800000
	s_nop 0                                                    // 0000000B34BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B34C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000B34C4: 327C7A84
	.long 0xd4490001                                           // 0000000B34C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000B34CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000B34D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000B34D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B34E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000B34E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000B34F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000B34F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000B3500: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000B3508: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000B3510: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000B3518: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000B3520: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000B3524: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B3528: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000B352C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000B3538: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000B3540: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000B3544: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000B3548: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000B354C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3550: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000B3554: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000B3558: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000B355C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3560: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000B3564: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000B3570: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000B3578: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B3580: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B3584: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000B3588: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B358C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000B3590: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000B3598: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000B35A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000B35A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B35A8: BF89FC07
	s_barrier                                                  // 0000000B35AC: BFBD0000
	buffer_gl0_inv                                             // 0000000B35B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000B35B8: BF800000
	s_nop 0                                                    // 0000000B35BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B35C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000B35C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B35D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B35D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B35DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B35E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B35E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B35F0: BF870004
	.long 0xd4490004                                           // 0000000B35F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B35F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B3600: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B3604: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000B3608: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000B360C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B3614: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B361C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B3620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B3624: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000B3628: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000B3630: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000B3638: BF89FC07
	s_barrier                                                  // 0000000B363C: BFBD0000
	buffer_gl0_inv                                             // 0000000B3640: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000B3648: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000B3650: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000B3658: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000B3660: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000B3668: 7E780300
	s_mov_b32 s4, 0                                            // 0000000B366C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000B3670: BF840001
	s_nop 0                                                    // 0000000B3674: BF800000
	s_nop 0                                                    // 0000000B3678: BF800000
	s_nop 0                                                    // 0000000B367C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3680: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000B3684: 327A7884
	.long 0xd4490001                                           // 0000000B3688: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000B368C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000B3694: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000B3698: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B36A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000B36A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000B36B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000B36B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000B36C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000B36C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000B36D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000B36D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000B36E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000B36E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B36F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000B36F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000B36F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000B3700: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000B3704: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000B3708: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000B370C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3710: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000B3714: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000B3718: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000B371C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3720: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000B3724: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000B3730: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000B3738: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B3740: 917E047E
	s_cbranch_execnz 65486                                     // 0000000B3744: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2880>
	s_set_inst_prefetch_distance 0x2                           // 0000000B3748: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B374C: 8C7E047E
	.long 0xd7000107                                           // 0000000B3750: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000B3754: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B375C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000B3760: D5207C08 00061080
	.long 0xd7000109                                           // 0000000B3768: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000B376C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000B3774: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000B377C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000B3780: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B3788: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000B378C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000B3794: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000B3798: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000B37A0: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000B37A8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000B37AC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B37B4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000B37B8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000B37C0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000B37C4: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000B37CC: D5207C12 00062480
	.long 0xd7000113                                           // 0000000B37D4: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000B37D8: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B37E0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000B37E4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000B37EC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000B37F0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000B37F8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000B3800: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000B3804: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B380C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000B3810: D5207C18 00063080
	.long 0xd7000119                                           // 0000000B3818: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000B381C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000B3824: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000B382C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000B3830: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B3838: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000B383C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000B3844: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000B3848: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000B384C: BF062105
	s_barrier                                                  // 0000000B3850: BFBD0000
	buffer_gl0_inv                                             // 0000000B3854: E0AC0000 00000000
	s_cbranch_scc0 63061                                       // 0000000B385C: BFA1F655 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000B3860: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000B3864: 8000141C
	.long 0xd73c0000                                           // 0000000B3868: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000B386C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000B3870: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000B3874: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000B3878: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000B387C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000B3880: 82010103
	.long 0xd7006a00                                           // 0000000B3884: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000B3888: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B388C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000B3890: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000B3898: BE810080
	.long 0xd7006a00                                           // 0000000B389C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000B38A0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000B38A4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B38AC: BF870092
	.long 0xd7006a00                                           // 0000000B38B0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000B38B4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000B38B8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000B38C0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000B38C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000B38D0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000B38D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B38DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000B38E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000B38E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000B38EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000B38F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000B38F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000B3900: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000B3908: 917E017E
	s_cbranch_execnz 65516                                     // 0000000B390C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_endpgm                                                   // 0000000B3910: BFB00000
		...

