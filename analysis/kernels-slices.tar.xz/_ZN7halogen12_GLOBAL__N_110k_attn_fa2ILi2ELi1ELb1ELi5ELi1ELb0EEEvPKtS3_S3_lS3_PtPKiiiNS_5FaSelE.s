00000000000dc900 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000DC900: BF850001
	s_load_b256 s[12:19], s[0:1], 0x30                         // 0000000DC904: F40C0300 F8000030
	s_load_b128 s[4:7], s[0:1], 0x50                           // 0000000DC90C: F4080100 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 0000000DC914: 3706009F
	v_lshrrev_b32_e32 v155, 5, v0                              // 0000000DC918: 33360085
	s_mov_b32 s26, s3                                          // 0000000DC91C: BE9A0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DC920: BF870112
	.long 0xd44c0003                                           // 0000000DC924: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 0000000DC928: 02030690
	v_lshlrev_b32_e32 v132, 6, v155                            // 0000000DC92C: 31093686
	s_waitcnt lgkmcnt(0)                                       // 0000000DC930: BF89FC07
	s_load_b32 s30, s[12:13], null                             // 0000000DC934: F4000786 F8000000
	s_and_saveexec_b32 s8, s3                                  // 0000000DC93C: BE882003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DC940: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 0000000DC944: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000DC94C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 0000000DC958: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000DC960: 8C7E087E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 0000000DC964: 160200FF 000002AB
	s_lshl_b32 s27, s2, 5                                      // 0000000DC96C: 841B8502
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 0000000DC970: CA240080 8D9A008F
	s_cmp_eq_u64 s[18:19], 0                                   // 0000000DC978: BF108012
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DC97C: BF8704C2
	.long 0xd7381001                                           // 0000000DC980: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000DC984: 02020282
	.long 0x7f023880                                           // 0000000DC988: 7F023880
	v_mov_b32_e32 v142, 0                                      // 0000000DC98C: 7F1C0280
	s_cselect_b32 s24, -1, 0                                   // 0000000DC990: 981880C1
	s_and_b32 vcc_lo, exec_lo, s24                             // 0000000DC994: 8B6A187E
	.long 0xd7620001                                           // 0000000DC998: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 0000000DC99C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DC9A0: BF870091
	v_add_nc_u32_e32 v156, s27, v1                             // 0000000DC9A4: 4B38021B
	v_or_b32_e32 v129, v156, v154                              // 0000000DC9A8: 3903359C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DC9AC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000DC9B0: 3505029F
	s_cbranch_vccnz 10                                         // 0000000DC9B4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s7, v129, 0                    // 0000000DC9B8: D6FF7C01 02030207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DC9C0: BF870091
	.long 0xd73c0001                                           // 0000000DC9C4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000DC9C8: 02020282
	.long 0xd7006a8d                                           // 0000000DC9CC: D7006A8D
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 0000000DC9D0: 02020212
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DC9D4: BF870001
	v_add_co_ci_u32_e64 v142, null, s19, v2, vcc_lo            // 0000000DC9D8: D5207C8E 01AA0413
	s_clause 0x2                                               // 0000000DC9E0: BF850002
	s_load_b64 s[18:19], s[0:1], 0x38                          // 0000000DC9E4: F4040480 F8000038
	s_load_b128 s[20:23], s[0:1], 0x20                         // 0000000DC9EC: F4080500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 0000000DC9F4: F40C0200 F8000000
	v_mov_b32_e32 v158, 0                                      // 0000000DC9FC: 7F3C0280
	s_xor_b32 s0, s24, -1                                      // 0000000DCA00: 8D00C118
	s_waitcnt lgkmcnt(0)                                       // 0000000DCA04: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s18, v129                         // 0000000DCA08: 7C890212
	s_and_b32 s28, s0, vcc_lo                                  // 0000000DCA0C: 8B1C6A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DCA10: BF870009
	s_and_saveexec_b32 s0, s28                                 // 0000000DCA14: BE80201C
	s_cbranch_execz 9                                          // 0000000DCA18: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 0000000DCA1C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000DCA20: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DCA24: BF870091
	.long 0xd7006a01                                           // 0000000DCA28: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000000DCA2C: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000DCA30: D5207C02 01AA0405
	global_load_b32 v158, v[1:2], off                          // 0000000DCA38: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000DCA40: 8C7E007E
	s_cmp_eq_u64 s[16:17], 0                                   // 0000000DCA44: BF108010
	s_mov_b64 s[24:25], 0                                      // 0000000DCA48: BE980180
	s_cbranch_scc1 10                                          // 0000000DCA4C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s6, 31                                      // 0000000DCA50: 86009F06
	s_mul_hi_u32 s1, s6, s2                                    // 0000000DCA54: 96810206
	s_mul_i32 s0, s0, s2                                       // 0000000DCA58: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DCA5C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000DCA60: 81010001
	s_mul_i32 s0, s6, s2                                       // 0000000DCA64: 96000206
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000DCA68: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DCA6C: BF870009
	s_add_u32 s24, s16, s0                                     // 0000000DCA70: 80180010
	s_addc_u32 s25, s17, s1                                    // 0000000DCA74: 82190111
	.long 0xd7050001                                           // 0000000DCA78: D7050001
	v_cndmask_b32_e32 v0, v155, v150, vcc_lo                   // 0000000DCA7C: 02012D9B
	s_or_b32 s27, s27, 31                                      // 0000000DCA80: 8C1B9F1B
	s_add_i32 s0, s18, -1                                      // 0000000DCA84: 8100C112
	v_lshrrev_b32_e32 v157, 4, v131                            // 0000000DCA88: 333B0684
	s_min_i32 s0, s27, s0                                      // 0000000DCA8C: 8900001B
	.long 0xd7390001                                           // 0000000DCA90: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000DCA94: 02020288
	s_add_i32 s0, s30, s0                                      // 0000000DCA98: 8100001E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DCA9C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 0000000DCAA0: BF04CF00
	.long 0xd7050001                                           // 0000000DCAA4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000DCAA8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DCAAC: BF870091
	.long 0xd7040001                                           // 0000000DCAB0: D7040001
	v_cndmask_b32_e32 v1, v155, v1, vcc_lo                     // 0000000DCAB4: 0202039B
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000DCAB8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DCAC4: BF870001
	v_mov_b32_e32 v71, v72                                     // 0000000DCAC8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000DCACC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000DCAD0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000DCAD4: 7E860348
	v_mad_u64_u32 v[138:139], null, s26, 12, v[1:2]            // 0000000DCAD8: D6FE7C8A 0405181A
	v_mov_b32_e32 v70, v72                                     // 0000000DCAE0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000DCAE4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000DCAE8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000DCAEC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000DCAF0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000DCAF4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000DCAF8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000DCAFC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000DCB04: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000DCB08: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000DCB0C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DCB10: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000DCB14: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000DCB18: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000DCB1C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000DCB20: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000DCB24: 7EAA0348
	.long 0xd73c008b                                           // 0000000DCB28: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000DCB2C: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000DCB30: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000DCB34: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000DCB38: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000DCB3C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000DCB40: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000DCB44: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000DCB48: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000DCB4C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000DCB50: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000DCB54: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000DCB58: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000DCB5C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000DCB60: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000DCB64: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000DCB68: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000DCB6C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000DCB70: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000DCB74: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000DCB78: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000DCB7C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000DCB80: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000DCB84: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000DCB88: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000DCB8C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000DCB90: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000DCB94: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000DCB98: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000DCB9C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000DCBA0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000DCBA4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000DCBA8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000DCBAC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000DCBB0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000DCBB4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000DCBB8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000DCBBC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000DCBC0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000DCBC4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000DCBC8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000DCBCC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000DCBD0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000DCBD4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000DCBD8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000DCBDC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000DCBE0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000DCBE4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000DCBE8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000DCBEC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000DCBF0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000DCBF4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000DCBF8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000DCBFC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000DCC00: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000DCC04: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000DCC08: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000DCC0C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000DCC10: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000DCC14: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000DCC18: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000DCC1C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000DCC20: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000DCC24: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000DCC28: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000DCC2C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000DCC30: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000DCC34: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000DCC38: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000DCC3C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000DCC40: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000DCC44: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000DCC48: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000DCC4C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000DCC50: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000DCC54: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000DCC58: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000DCC5C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000DCC60: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000DCC64: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000DCC68: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000DCC6C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000DCC70: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000DCC74: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000DCC78: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000DCC7C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000DCC80: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000DCC84: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000DCC88: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000DCC8C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000DCC90: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000DCC94: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000DCC98: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000DCC9C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000DCCA0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000DCCA4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000DCCA8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000DCCAC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000DCCB0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000DCCB4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000DCCB8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000DCCBC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000DCCC0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000DCCC4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000DCCC8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000DCCCC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000DCCD0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000DCCD4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000DCCD8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000DCCDC: 7E020348
	s_cbranch_scc1 2544                                        // 0000000DCCE0: BFA209F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ba4>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[8:9]           // 0000000DCCE4: D6FF7C01 002302FF 00003000
	v_lshlrev_b32_e32 v4, 2, v131                              // 0000000DCCF0: 30090682
	s_movk_i32 s2, 0x440                                       // 0000000DCCF4: B0020440
	s_ashr_i32 s1, s0, 31                                      // 0000000DCCF8: 86019F00
	v_mad_u32_u24 v3, v155, s2, 0x3000                         // 0000000DCCFC: D60B0003 03FC059B 00003000
	s_lshr_b32 s1, s1, 28                                      // 0000000DCD08: 85019C01
	v_mad_u32_u24 v172, v154, 48, 0x9600                       // 0000000DCD0C: D60B00AC 03FD619A 00009600
	s_add_i32 s0, s0, s1                                       // 0000000DCD18: 81000100
	.long 0xd7006a8f                                           // 0000000DCD1C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000DCD20: 02031701
	v_add3_u32 v1, v129, s30, 1                                // 0000000DCD24: D6550001 02043D81
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000DCD2C: D5207C90 01AB1902
	v_mov_b32_e32 v129, 0                                      // 0000000DCD34: 7F020280
	s_ashr_i32 s16, s0, 4                                      // 0000000DCD38: 86108400
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000DCD3C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000DCD40: 3404029F
	.long 0xd44c0000                                           // 0000000DCD44: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000DCD48: 020200FF 00000200
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 0000000DCD50: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v164, 0x44, v131, v3                         // 0000000DCD5C: D60B00A4 040F06FF 00000044
	v_dual_mov_b32 v10, v129 :: v_dual_lshlrev_b32 v3, 4, v0   // 0000000DCD68: CA220181 0A020084
	v_lshrrev_b32_e32 v2, 30, v2                               // 0000000DCD70: 3204049E
	s_cmp_eq_u64 s[24:25], 0                                   // 0000000DCD74: BF108018
	v_add_nc_u32_e32 v159, s30, v156                           // 0000000DCD78: 4B3F381E
	s_cselect_b32 s17, -1, 0                                   // 0000000DCD7C: 981180C1
	s_cmp_lg_u64 s[24:25], 0                                   // 0000000DCD80: BF118018
	v_add_nc_u32_e32 v1, v1, v2                                // 0000000DCD84: 4A020501
	v_add_nc_u32_e32 v2, v132, v4                              // 0000000DCD88: 4A040984
	v_lshl_add_u32 v160, v154, 2, v5                           // 0000000DCD8C: D64600A0 0415059A
	v_lshlrev_b32_e32 v5, 9, v155                              // 0000000DCD94: 300B3689
	v_add_nc_u32_e32 v6, 0xed00, v132                          // 0000000DCD98: 4A0D08FF 0000ED00
	v_ashrrev_i32_e32 v161, 2, v1                              // 0000000DCDA0: 35420282
	v_lshrrev_b32_e32 v1, 1, v0                                // 0000000DCDA4: 32020081
	v_add_nc_u32_e32 v163, 0xe700, v2                          // 0000000DCDA8: 4B4604FF 0000E700
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v0, 0xf300, v2// 0000000DCDB0: CA200181 070004FF 0000F300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000000DCDBC: BF870143
	v_dual_mov_b32 v8, v129 :: v_dual_and_b32 v1, 0xf8, v1     // 0000000DCDC0: CA240181 080002FF 000000F8
	s_cselect_b32 s29, -1, 0                                   // 0000000DCDCC: 981D80C1
	s_ashr_i32 s27, s26, 31                                    // 0000000DCDD0: 861B9F1A
	v_dual_mov_b32 v11, v129 :: v_dual_and_b32 v130, 0x1f0, v3 // 0000000DCDD4: CA240181 0B8206FF 000001F0
	v_mul_u32_u24_e32 v2, 48, v1                               // 0000000DCDE0: 160402B0
	s_lshl_b64 s[4:5], s[26:27], 9                             // 0000000DCDE4: 8484891A
	s_add_i32 s19, s19, -1                                     // 0000000DCDE8: 8113C113
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v166, v6, v4     // 0000000DCDEC: CA200080 09A60906
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DCDF4: BF870002
	v_lshl_or_b32 v2, v154, 1, v2                              // 0000000DCDF8: D6560002 0409039A
	v_mov_b32_e32 v4, v129                                     // 0000000DCE00: 7E080381
	v_lshl_add_u32 v165, v131, 5, v5                           // 0000000DCE04: D64600A5 04150B83
	s_add_u32 s1, s10, s4                                      // 0000000DCE0C: 8001040A
	s_addc_u32 s6, s11, s5                                     // 0000000DCE10: 8206050B
	v_dual_mov_b32 v13, v129 :: v_dual_add_nc_u32 v170, 0x9600, v2// 0000000DCE14: CA200181 0DAA04FF 00009600
	v_mov_b32_e32 v2, v129                                     // 0000000DCE20: 7E040381
	v_add_nc_u32_e32 v162, v159, v131                          // 0000000DCE24: 4B45079F
	v_dual_mov_b32 v12, v129 :: v_dual_lshlrev_b32 v131, 1, v1 // 0000000DCE28: CA220181 0C820281
	v_mul_u32_u24_e32 v3, 0x210, v155                          // 0000000DCE30: 160736FF 00000210
	s_add_u32 s2, s12, s4                                      // 0000000DCE38: 8002040C
	.long 0xd70001ad                                           // 0000000DCE3C: D70001AD
	v_cndmask_b32_e32 v1, s1, v130, vcc_lo                     // 0000000DCE40: 02030401
	s_addc_u32 s4, s13, s5                                     // 0000000DCE44: 8204050D
	s_movk_i32 s5, 0x210                                       // 0000000DCE48: B0050210
	v_add_co_ci_u32_e64 v174, null, s6, 0, s1                  // 0000000DCE4C: D5207CAE 00050006
	.long 0xd70001af                                           // 0000000DCE54: D70001AF
	v_cndmask_b32_e32 v1, s2, v131, vcc_lo                     // 0000000DCE58: 02030602
	v_lshl_or_b32 v168, v154, 5, v5                            // 0000000DCE5C: D65600A8 04150B9A
	v_add3_u32 v169, v3, v130, 0xc600                          // 0000000DCE64: D65500A9 03FF0503 0000C600
	v_mov_b32_e32 v1, 0                                        // 0000000DCE70: 7E020280
	v_mov_b32_e32 v3, v129                                     // 0000000DCE74: 7E060381
	v_mov_b32_e32 v5, v129                                     // 0000000DCE78: 7E0A0381
	v_lshl_or_b32 v167, v157, 2, v6                            // 0000000DCE7C: D65600A7 0419059D
	v_mov_b32_e32 v6, v129                                     // 0000000DCE84: 7E0C0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 0000000DCE88: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 0000000DCE90: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 0000000DCE94: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 0000000DCE9C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 0000000DCEA4: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 0000000DCEA8: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 0000000DCEB0: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 0000000DCEB4: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 0000000DCEBC: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 0000000DCEC0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 0000000DCEC8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 0000000DCED0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 0000000DCED4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 0000000DCEDC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 0000000DCEE0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 0000000DCEE8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 0000000DCEEC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 0000000DCEF4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 0000000DCEFC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 0000000DCF00: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 0000000DCF08: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 0000000DCF0C: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 0000000DCF14: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 0000000DCF18: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 0000000DCF20: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 0000000DCF28: 7E560381
	v_mov_b32_e32 v44, v129                                    // 0000000DCF2C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 0000000DCF30: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000DCF34: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000DCF38: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000DCF3C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000DCF40: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000DCF44: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000DCF48: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000DCF4C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000DCF50: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000DCF54: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000DCF58: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000DCF5C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000DCF60: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000DCF64: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000DCF68: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000DCF6C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000DCF70: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000DCF74: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000DCF78: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000DCF7C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000DCF80: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000DCF84: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000DCF88: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000DCF8C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000DCF90: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000DCF94: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000DCF98: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000DCF9C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000DCFA0: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000DCFA4: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000DCFA8: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000DCFAC: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000DCFB0: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000DCFB4: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000DCFB8: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000DCFBC: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000DCFC0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000DCFC4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000DCFC8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000DCFCC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000DCFD0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000DCFD4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000DCFD8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000DCFDC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000DCFE0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000DCFE4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000DCFE8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000DCFEC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000DCFF0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000DCFF4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000DCFF8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000DCFFC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000DD000: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000DD004: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000DD008: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000DD00C: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000DD010: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000DD014: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000DD018: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000DD01C: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000DD020: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000DD024: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000DD028: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000DD02C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000DD030: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000DD034: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000DD038: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000DD03C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000DD040: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000DD044: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000DD048: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000DD04C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000DD050: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000DD054: 7E900381
	v_mad_u32_u24 v171, v154, s5, 0xc600                       // 0000000DD058: D60B00AB 03FC0B9A 0000C600
	v_add_co_ci_u32_e64 v176, null, s4, 0, s1                  // 0000000DD064: D5207CB0 00050004
	s_mov_b32 s11, 0                                           // 0000000DD06C: BE8B0080
	s_branch 116                                               // 0000000DD070: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x944>
	ds_load_b128 v[146:149], v172                              // 0000000DD074: DBFC0000 920000AC
	ds_load_b128 v[150:153], v172 offset:16                    // 0000000DD07C: DBFC0010 960000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD084: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 0000000DD088: CC414079 1DE72582
	ds_load_b128 v[150:153], v172 offset:784                   // 0000000DD090: DBFC0310 960000AC
	ds_load_b128 v[146:149], v172 offset:768                   // 0000000DD098: DBFC0300 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD0A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 0000000DD0A4: CC414071 1DC72582
	ds_load_b128 v[150:153], v172 offset:1552                  // 0000000DD0AC: DBFC0610 960000AC
	ds_load_b128 v[146:149], v172 offset:1536                  // 0000000DD0B4: DBFC0600 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD0BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 0000000DD0C0: CC414069 1DA72582
	ds_load_b128 v[150:153], v172 offset:2320                  // 0000000DD0C8: DBFC0910 960000AC
	ds_load_b128 v[146:149], v172 offset:2304                  // 0000000DD0D0: DBFC0900 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD0D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 0000000DD0DC: CC414061 1D872582
	ds_load_b128 v[150:153], v172 offset:3088                  // 0000000DD0E4: DBFC0C10 960000AC
	ds_load_b128 v[146:149], v172 offset:3072                  // 0000000DD0EC: DBFC0C00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD0F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 0000000DD0F8: CC414059 1D672582
	ds_load_b128 v[150:153], v172 offset:3856                  // 0000000DD100: DBFC0F10 960000AC
	ds_load_b128 v[146:149], v172 offset:3840                  // 0000000DD108: DBFC0F00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD110: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 0000000DD114: CC414051 1D472582
	ds_load_b128 v[150:153], v172 offset:4624                  // 0000000DD11C: DBFC1210 960000AC
	ds_load_b128 v[146:149], v172 offset:4608                  // 0000000DD124: DBFC1200 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD12C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 0000000DD130: CC414049 1D272582
	ds_load_b128 v[150:153], v172 offset:5392                  // 0000000DD138: DBFC1510 960000AC
	ds_load_b128 v[146:149], v172 offset:5376                  // 0000000DD140: DBFC1500 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD148: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 0000000DD14C: CC414041 1D072582
	ds_load_b128 v[150:153], v172 offset:6160                  // 0000000DD154: DBFC1810 960000AC
	ds_load_b128 v[146:149], v172 offset:6144                  // 0000000DD15C: DBFC1800 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD164: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 0000000DD168: CC414039 1CE72582
	ds_load_b128 v[150:153], v172 offset:6928                  // 0000000DD170: DBFC1B10 960000AC
	ds_load_b128 v[146:149], v172 offset:6912                  // 0000000DD178: DBFC1B00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD180: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 0000000DD184: CC414031 1CC72582
	ds_load_b128 v[150:153], v172 offset:7696                  // 0000000DD18C: DBFC1E10 960000AC
	ds_load_b128 v[146:149], v172 offset:7680                  // 0000000DD194: DBFC1E00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD19C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 0000000DD1A0: CC414029 1CA72582
	ds_load_b128 v[150:153], v172 offset:8464                  // 0000000DD1A8: DBFC2110 960000AC
	ds_load_b128 v[146:149], v172 offset:8448                  // 0000000DD1B0: DBFC2100 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD1B8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 0000000DD1BC: CC414021 1C872582
	ds_load_b128 v[150:153], v172 offset:9232                  // 0000000DD1C4: DBFC2410 960000AC
	ds_load_b128 v[146:149], v172 offset:9216                  // 0000000DD1CC: DBFC2400 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD1D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 0000000DD1D8: CC414019 1C672582
	ds_load_b128 v[150:153], v172 offset:10000                 // 0000000DD1E0: DBFC2710 960000AC
	ds_load_b128 v[146:149], v172 offset:9984                  // 0000000DD1E8: DBFC2700 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD1F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 0000000DD1F4: CC414011 1C472582
	ds_load_b128 v[150:153], v172 offset:10768                 // 0000000DD1FC: DBFC2A10 960000AC
	ds_load_b128 v[146:149], v172 offset:10752                 // 0000000DD204: DBFC2A00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD20C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 0000000DD210: CC414009 1C272582
	ds_load_b128 v[150:153], v172 offset:11536                 // 0000000DD218: DBFC2D10 960000AC
	ds_load_b128 v[146:149], v172 offset:11520                 // 0000000DD220: DBFC2D00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000DD228: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 0000000DD22C: CC414001 1C072582
	s_add_i32 s1, s11, 1                                       // 0000000DD234: 8101810B
	s_cmp_eq_u32 s11, s16                                      // 0000000DD238: BF06100B
	s_mov_b32 s11, s1                                          // 0000000DD23C: BE8B0001
	s_cbranch_scc1 2200                                        // 0000000DD240: BFA20898 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ba4>
	s_and_not1_b32 vcc_lo, exec_lo, s29                        // 0000000DD244: 916A1D7E
	s_mov_b32 s1, s17                                          // 0000000DD248: BE810011
	s_cbranch_vccz 3                                           // 0000000DD24C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000DD250: 916A017E
	s_cbranch_vccnz 65527                                      // 0000000DD254: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_branch 15                                                // 0000000DD258: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x998>
	s_lshr_b32 s1, s11, 3                                      // 0000000DD25C: 8501830B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DD260: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000DD264: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000DD26C: 7F040201
	global_load_b32 v130, v130, s[24:25]                       // 0000000DD270: DC520000 82180082
	s_waitcnt vmcnt(0)                                         // 0000000DD278: BF8903F7
	v_lshrrev_b32_e32 v130, s11, v130                          // 0000000DD27C: 3305040B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD280: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000DD284: 37050481
	.long 0xd44a0001                                           // 0000000DD288: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000DD28C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000DD290: 916A017E
	s_cbranch_vccnz 65511                                      // 0000000DD294: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_lshl_b32 s2, s11, 4                                      // 0000000DD298: 8402840B
	s_waitcnt vmcnt(0)                                         // 0000000DD29C: BF8903F7
	s_barrier                                                  // 0000000DD2A0: BFBD0000
	buffer_gl0_inv                                             // 0000000DD2A4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000DD2AC: BE812000
	s_cbranch_execz 64                                         // 0000000DD2B0: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab4>
	v_or_b32_e32 v130, s2, v155                                // 0000000DD2B4: 39053602
	v_or_b32_e32 v131, s2, v154                                // 0000000DD2B8: 39073402
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD2BC: BF870112
	v_min_i32_e32 v130, s19, v130                              // 0000000DD2C0: 23050413
	v_min_i32_e32 v132, s19, v131                              // 0000000DD2C4: 23090613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD2C8: BF870112
	v_ashrrev_i32_e32 v133, 31, v130                           // 0000000DD2CC: 350B049F
	v_ashrrev_i32_e32 v135, 31, v132                           // 0000000DD2D0: 350F089F
	.long 0xd72c0086                                           // 0000000DD2D4: D72C0086
	v_cndmask_b32_e32 v1, s15, v130, vcc_lo                    // 0000000DD2D8: 0203040F
	v_mad_u64_u32 v[130:131], null, s14, v130, 0               // 0000000DD2DC: D6FE7C82 0203040E
	.long 0xd72c0089                                           // 0000000DD2E4: D72C0089
	v_cndmask_b32_e32 v1, s15, v132, vcc_lo                    // 0000000DD2E8: 0203080F
	.long 0xd72c0088                                           // 0000000DD2EC: D72C0088
	v_cndmask_b32_e32 v1, s14, v133, vcc_lo                    // 0000000DD2F0: 02030A0E
	v_mad_u64_u32 v[132:133], null, s14, v132, 0               // 0000000DD2F4: D6FE7C84 0203080E
	.long 0xd72c0087                                           // 0000000DD2FC: D72C0087
	v_cndmask_b32_e32 v1, s14, v135, vcc_lo                    // 0000000DD300: 02030E0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD304: BF870113
	v_add3_u32 v131, v131, v136, v134                          // 0000000DD308: D6550083 061B1183
	v_add3_u32 v133, v133, v135, v137                          // 0000000DD310: D6550085 06270F85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD318: BF870112
	.long 0xd73c0082                                           // 0000000DD31C: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000DD320: 02030481
	.long 0xd73c0084                                           // 0000000DD324: D73C0084
	v_cndmask_b32_e32 v1, 1, v132, vcc_lo                      // 0000000DD328: 02030881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD32C: BF870092
	.long 0xd7006a82                                           // 0000000DD330: D7006A82
	v_cndmask_b32_e32 v1, v173, v130, vcc_lo                   // 0000000DD334: 020305AD
	v_add_co_ci_u32_e64 v131, null, v174, v131, vcc_lo         // 0000000DD338: D5207C83 01AB07AE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD340: BF870093
	.long 0xd7006a86                                           // 0000000DD344: D7006A86
	v_cndmask_b32_e32 v1, v175, v132, vcc_lo                   // 0000000DD348: 020309AF
	v_add_co_ci_u32_e64 v135, null, v176, v133, vcc_lo         // 0000000DD34C: D5207C87 01AB0BB0
	global_load_b128 v[130:133], v[130:131], off               // 0000000DD354: DC5E0000 827C0082
	global_load_b128 v[134:137], v[134:135], off               // 0000000DD35C: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 0000000DD364: BF8907F7
	ds_store_b128 v169, v[130:133]                             // 0000000DD368: DB7C0000 000082A9
	s_waitcnt vmcnt(0)                                         // 0000000DD370: BF8903F7
	ds_store_b16 v170, v134                                    // 0000000DD374: D87C0000 000086AA
	ds_store_b16_d16_hi v170, v134 offset:48                   // 0000000DD37C: DA840030 000086AA
	ds_store_b16 v170, v135 offset:96                          // 0000000DD384: D87C0060 000087AA
	ds_store_b16_d16_hi v170, v135 offset:144                  // 0000000DD38C: DA840090 000087AA
	ds_store_b16 v170, v136 offset:192                         // 0000000DD394: D87C00C0 000088AA
	ds_store_b16_d16_hi v170, v136 offset:240                  // 0000000DD39C: DA8400F0 000088AA
	ds_store_b16 v170, v137 offset:288                         // 0000000DD3A4: D87C0120 000089AA
	ds_store_b16_d16_hi v170, v137 offset:336                  // 0000000DD3AC: DA840150 000089AA
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DD3B4: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000DD3B8: BF89FC07
	s_barrier                                                  // 0000000DD3BC: BFBD0000
	buffer_gl0_inv                                             // 0000000DD3C0: E0AC0000 00000000
	s_clause 0x1                                               // 0000000DD3C8: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:16     // 0000000DD3CC: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 0000000DD3D4: DC5E0000 927C008F
	ds_load_b128 v[177:180], v171                              // 0000000DD3DC: DBFC0000 B10000AB
	ds_load_b128 v[181:184], v171 offset:16                    // 0000000DD3E4: DBFC0010 B50000AB
	v_mov_b32_e32 v136, v129                                   // 0000000DD3EC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000DD3F0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000DD3F4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000DD3F8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000DD3FC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000DD400: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000DD404: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000DD408: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DD40C: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000DD410: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000DD414: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000DD418: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000DD41C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000DD420: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000DD424: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000DD428: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD42C: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD430: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD434: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD43C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:48     // 0000000DD440: DC5E0030 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:32     // 0000000DD448: DC5E0020 927C008F
	ds_load_b128 v[177:180], v171 offset:32                    // 0000000DD450: DBFC0020 B10000AB
	ds_load_b128 v[181:184], v171 offset:48                    // 0000000DD458: DBFC0030 B50000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD460: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD464: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD46C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 0000000DD470: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 0000000DD478: DC5E0040 927C008F
	ds_load_b128 v[181:184], v171 offset:80                    // 0000000DD480: DBFC0050 B50000AB
	ds_load_b128 v[177:180], v171 offset:64                    // 0000000DD488: DBFC0040 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD490: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD494: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD49C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:112    // 0000000DD4A0: DC5E0070 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:96     // 0000000DD4A8: DC5E0060 927C008F
	ds_load_b128 v[181:184], v171 offset:112                   // 0000000DD4B0: DBFC0070 B50000AB
	ds_load_b128 v[177:180], v171 offset:96                    // 0000000DD4B8: DBFC0060 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD4C0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD4C4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD4CC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 0000000DD4D0: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 0000000DD4D8: DC5E0080 927C008F
	ds_load_b128 v[181:184], v171 offset:144                   // 0000000DD4E0: DBFC0090 B50000AB
	ds_load_b128 v[177:180], v171 offset:128                   // 0000000DD4E8: DBFC0080 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD4F0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD4F4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD4FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:176    // 0000000DD500: DC5E00B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:160    // 0000000DD508: DC5E00A0 927C008F
	ds_load_b128 v[181:184], v171 offset:176                   // 0000000DD510: DBFC00B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:160                   // 0000000DD518: DBFC00A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD520: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD524: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD52C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000DD530: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000DD538: DC5E00C0 927C008F
	ds_load_b128 v[181:184], v171 offset:208                   // 0000000DD540: DBFC00D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:192                   // 0000000DD548: DBFC00C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD550: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD554: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD55C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:240    // 0000000DD560: DC5E00F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:224    // 0000000DD568: DC5E00E0 927C008F
	ds_load_b128 v[181:184], v171 offset:240                   // 0000000DD570: DBFC00F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:224                   // 0000000DD578: DBFC00E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD580: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD584: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD58C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 0000000DD590: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 0000000DD598: DC5E0100 927C008F
	ds_load_b128 v[181:184], v171 offset:272                   // 0000000DD5A0: DBFC0110 B50000AB
	ds_load_b128 v[177:180], v171 offset:256                   // 0000000DD5A8: DBFC0100 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD5B0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD5B4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD5BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:304    // 0000000DD5C0: DC5E0130 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:288    // 0000000DD5C8: DC5E0120 927C008F
	ds_load_b128 v[181:184], v171 offset:304                   // 0000000DD5D0: DBFC0130 B50000AB
	ds_load_b128 v[177:180], v171 offset:288                   // 0000000DD5D8: DBFC0120 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD5E0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD5E4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD5EC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 0000000DD5F0: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 0000000DD5F8: DC5E0140 927C008F
	ds_load_b128 v[181:184], v171 offset:336                   // 0000000DD600: DBFC0150 B50000AB
	ds_load_b128 v[177:180], v171 offset:320                   // 0000000DD608: DBFC0140 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD610: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD614: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD61C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:368    // 0000000DD620: DC5E0170 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:352    // 0000000DD628: DC5E0160 927C008F
	ds_load_b128 v[181:184], v171 offset:368                   // 0000000DD630: DBFC0170 B50000AB
	ds_load_b128 v[177:180], v171 offset:352                   // 0000000DD638: DBFC0160 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD640: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD644: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD64C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000DD650: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000DD658: DC5E0180 927C008F
	ds_load_b128 v[181:184], v171 offset:400                   // 0000000DD660: DBFC0190 B50000AB
	ds_load_b128 v[177:180], v171 offset:384                   // 0000000DD668: DBFC0180 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD670: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD674: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD67C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:432    // 0000000DD680: DC5E01B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:416    // 0000000DD688: DC5E01A0 927C008F
	ds_load_b128 v[181:184], v171 offset:432                   // 0000000DD690: DBFC01B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:416                   // 0000000DD698: DBFC01A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD6A0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD6A4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD6AC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 0000000DD6B0: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 0000000DD6B8: DC5E01C0 927C008F
	ds_load_b128 v[181:184], v171 offset:464                   // 0000000DD6C0: DBFC01D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:448                   // 0000000DD6C8: DBFC01C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD6D0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD6D4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000DD6DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 0000000DD6E0: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 0000000DD6E8: DC5E01E0 927C008F
	ds_load_b128 v[181:184], v171 offset:496                   // 0000000DD6F0: DBFC01F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:480                   // 0000000DD6F8: DBFC01E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD700: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000DD704: CC414082 1E0B6392
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD70C: BF870111
	v_dual_mul_f32 v130, 0x3db8aa3b, v130 :: v_dual_mul_f32 v131, 0x3db8aa3b, v131// 0000000DD710: C8C704FF 828306FF 3DB8AA3B
	v_mul_f32_e32 v146, 0x3db8aa3b, v133                       // 0000000DD71C: 11250AFF 3DB8AA3B
	v_mov_b32_e32 v133, 0xffff                                 // 0000000DD724: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DD72C: BF870004
	v_mul_f32_e32 v132, 0x3db8aa3b, v132                       // 0000000DD730: 110908FF 3DB8AA3B
	v_dual_mul_f32 v134, 0x3db8aa3b, v134 :: v_dual_mul_f32 v135, 0x3db8aa3b, v135// 0000000DD738: C8C70CFF 86870EFF 3DB8AA3B
	v_dual_mul_f32 v136, 0x3db8aa3b, v136 :: v_dual_mul_f32 v137, 0x3db8aa3b, v137// 0000000DD744: C8C710FF 888912FF 3DB8AA3B
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 0000000DD750: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v146 offset0:68 offset1:102 // 0000000DD758: D8386644 009284A0
	ds_store_2addr_b32 v160, v134, v135 offset0:136 offset1:170// 0000000DD760: D838AA88 008786A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 0000000DD768: D838EECC 008988A0
	s_and_saveexec_b32 s4, s28                                 // 0000000DD770: BE84201C
	s_cbranch_execz 358                                        // 0000000DD774: BFA50166 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1410>
	s_lshl_b32 s5, s11, 2                                      // 0000000DD778: 8405820B
	s_mov_b32 s6, exec_lo                                      // 0000000DD77C: BE86007E
	.long 0xd4c1007e                                           // 0000000DD780: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000DD784: 02033D91
	s_cbranch_execz 43                                         // 0000000DD788: BFA5002B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf38>
	v_ashrrev_i32_e32 v146, 31, v145                           // 0000000DD78C: 3525229F
	s_mov_b32 s7, 0                                            // 0000000DD790: BE870080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD794: BF870091
	.long 0xd73c0082                                           // 0000000DD798: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 0000000DD79C: 02032282
	.long 0xd7006a82                                           // 0000000DD7A0: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000DD7A4: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD7A8: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000DD7AC: D5207C83 01AB078E
	s_branch 10                                                // 0000000DD7B4: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xee0>
	s_nop 0                                                    // 0000000DD7B8: BF800000
	s_nop 0                                                    // 0000000DD7BC: BF800000
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000DD7C0: 8C7E097E
	v_mov_b32_e32 v133, v145                                   // 0000000DD7C4: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 0000000DD7C8: 7F220384
	s_and_b32 s1, exec_lo, s8                                  // 0000000DD7CC: 8B01087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DD7D0: BF870499
	s_or_b32 s7, s1, s7                                        // 0000000DD7D4: 8C070701
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000DD7D8: 917E077E
	s_cbranch_execz 20                                         // 0000000DD7DC: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf30>
	global_load_b32 v132, v[130:131], off                      // 0000000DD7E0: DC520000 847C0082
	s_or_b32 s8, s8, exec_lo                                   // 0000000DD7E8: 8C087E08
	s_waitcnt vmcnt(0)                                         // 0000000DD7EC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s5, v132                          // 0000000DD7F0: 7C890805
	s_and_saveexec_b32 s9, vcc_lo                              // 0000000DD7F4: BE89206A
	s_cbranch_execz 65521                                      // 0000000DD7F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000DD7FC: CA20019E 91852281
	.long 0xd7000182                                           // 0000000DD804: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000DD808: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DD80C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000DD810: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000DD818: 7C95099E
	s_and_not1_b32 s1, s8, exec_lo                             // 0000000DD81C: 91017E08
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000000DD820: 8B087E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD824: BF870009
	s_or_b32 s8, s1, s8                                        // 0000000DD828: 8C080801
	s_branch 65508                                             // 0000000DD82C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000DD830: 8C7E077E
	v_mov_b32_e32 v145, v133                                   // 0000000DD834: 7F220385
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000DD838: 8C7E067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD83C: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 0000000DD840: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 0000000DD848: BE81007E
	.long 0xd4c1007e                                           // 0000000DD84C: D4C1007E
	v_cndmask_b32_e32 v1, s5, v161, vcc_lo                     // 0000000DD850: 02034205
	s_cbranch_execz 62                                         // 0000000DD854: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1050>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 0000000DD858: CA100080 85820191
	s_mov_b32 s6, exec_lo                                      // 0000000DD860: BE86007E
	.long 0xd4c1007e                                           // 0000000DD864: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000DD868: 02033D91
	s_cbranch_execz 54                                         // 0000000DD86C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1048>
	v_mov_b32_e32 v130, v145                                   // 0000000DD870: 7F040391
	s_mov_b32 s8, 0                                            // 0000000DD874: BE880080
	s_set_inst_prefetch_distance 0x1                           // 0000000DD878: BF840001
	s_branch 10                                                // 0000000DD87C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa8>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000000DD880: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DD884: BF870499
	s_and_b32 s12, exec_lo, s10                                // 0000000DD888: 8B0C0A7E
	s_or_b32 s8, s12, s8                                       // 0000000DD88C: 8C08080C
	s_and_not1_b32 s7, s7, exec_lo                             // 0000000DD890: 91077E07
	s_and_b32 s12, s9, exec_lo                                 // 0000000DD894: 8B0C7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD898: BF870009
	s_or_b32 s7, s7, s12                                       // 0000000DD89C: 8C070C07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000000DD8A0: 917E087E
	s_cbranch_execz 28                                         // 0000000DD8A4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1018>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000DD8A8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000DD8AC: 7F060382
	s_or_b32 s9, s9, exec_lo                                   // 0000000DD8B0: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 0000000DD8B4: 8C0A7E0A
	s_mov_b32 s12, exec_lo                                     // 0000000DD8B8: BE8C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000DD8BC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD8C0: BF870091
	.long 0xd73c0084                                           // 0000000DD8C4: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000DD8C8: 02030682
	.long 0xd7006a84                                           // 0000000DD8CC: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000DD8D0: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD8D4: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000DD8D8: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000DD8E0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000DD8E8: BF8903F7
	.long 0xd4c4007e                                           // 0000000DD8EC: D4C4007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 0000000DD8F0: 02030805
	s_cbranch_execz 65506                                      // 0000000DD8F4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000DD8F8: 4B050681
	s_and_not1_b32 s10, s10, exec_lo                           // 0000000DD8FC: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000DD900: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DD904: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000DD908: 7C95059E
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000000DD90C: 8B0D7E6A
	s_or_b32 s10, s10, s13                                     // 0000000DD910: 8C0A0D0A
	s_branch 65498                                             // 0000000DD914: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_set_inst_prefetch_distance 0x2                           // 0000000DD918: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000DD91C: 8C7E087E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 0000000DD920: CA100080 8582019E
	s_and_saveexec_b32 s8, s7                                  // 0000000DD928: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD92C: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 0000000DD930: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v132                          // 0000000DD934: 7C950805
	v_mov_b32_e32 v130, v131                                   // 0000000DD938: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000DD93C: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000DD944: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD948: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000DD94C: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD950: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DD954: 8C7E017E
	s_or_b32 s6, s5, 1                                         // 0000000DD958: 8C068105
	s_mov_b32 s1, exec_lo                                      // 0000000DD95C: BE81007E
	.long 0xd4c6007e                                           // 0000000DD960: D4C6007E
	v_cndmask_b32_e32 v1, s6, v161, vcc_lo                     // 0000000DD964: 02034206
	s_xor_b32 s1, exec_lo, s1                                  // 0000000DD968: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000000DD96C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000DD974: BE813001
	s_cbranch_execz 70                                         // 0000000DD978: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1194>
	s_mov_b32 s7, exec_lo                                      // 0000000DD97C: BE87007E
	.long 0xd4c1007e                                           // 0000000DD980: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000DD984: 02033D82
	s_cbranch_execz 64                                         // 0000000DD988: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x118c>
	s_mov_b32 s9, 0                                            // 0000000DD98C: BE890080
	s_set_inst_prefetch_distance 0x1                           // 0000000DD990: BF840001
	s_branch 20                                                // 0000000DD994: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10e8>
	s_nop 0                                                    // 0000000DD998: BF800000
	s_nop 0                                                    // 0000000DD99C: BF800000
	s_nop 0                                                    // 0000000DD9A0: BF800000
	s_nop 0                                                    // 0000000DD9A4: BF800000
	s_nop 0                                                    // 0000000DD9A8: BF800000
	s_nop 0                                                    // 0000000DD9AC: BF800000
	s_nop 0                                                    // 0000000DD9B0: BF800000
	s_nop 0                                                    // 0000000DD9B4: BF800000
	s_nop 0                                                    // 0000000DD9B8: BF800000
	s_nop 0                                                    // 0000000DD9BC: BF800000
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000DD9C0: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DD9C4: BF870499
	s_and_b32 s13, exec_lo, s12                                // 0000000DD9C8: 8B0D0C7E
	s_or_b32 s9, s13, s9                                       // 0000000DD9CC: 8C09090D
	s_and_not1_b32 s8, s8, exec_lo                             // 0000000DD9D0: 91087E08
	s_and_b32 s13, s10, exec_lo                                // 0000000DD9D4: 8B0D7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD9D8: BF870009
	s_or_b32 s8, s8, s13                                       // 0000000DD9DC: 8C080D08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000DD9E0: 917E097E
	s_cbranch_execz 27                                         // 0000000DD9E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1154>
	v_mov_b32_e32 v131, v130                                   // 0000000DD9E8: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 0000000DD9EC: 8C0A7E0A
	s_or_b32 s12, s12, exec_lo                                 // 0000000DD9F0: 8C0C7E0C
	s_mov_b32 s13, exec_lo                                     // 0000000DD9F4: BE8D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD9F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000DD9FC: 3509069F
	.long 0xd73c0086                                           // 0000000DDA00: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000DDA04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDA08: BF870091
	.long 0xd7006a86                                           // 0000000DDA0C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000DDA10: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000DDA14: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000DDA1C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000DDA24: BF8903F7
	.long 0xd4c6007e                                           // 0000000DDA28: D4C6007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 0000000DDA2C: 02030805
	s_cbranch_execz 65507                                      // 0000000DDA30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000DDA34: 4B050681
	s_and_not1_b32 s12, s12, exec_lo                           // 0000000DDA38: 910C7E0C
	s_and_not1_b32 s10, s10, exec_lo                           // 0000000DDA3C: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DDA40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000DDA44: 7C95059E
	s_and_b32 s26, vcc_lo, exec_lo                             // 0000000DDA48: 8B1A7E6A
	s_or_b32 s12, s12, s26                                     // 0000000DDA4C: 8C0C1A0C
	s_branch 65499                                             // 0000000DDA50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000DDA54: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000DDA58: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 0000000DDA5C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 0000000DDA60: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDA64: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 0000000DDA68: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 0000000DDA6C: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000DDA70: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDA7C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000DDA80: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000DDA84: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000DDA88: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDA8C: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000DDA90: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDA94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDA98: 8C7E017E
	s_or_b32 s6, s5, 2                                         // 0000000DDA9C: 8C068205
	s_mov_b32 s1, exec_lo                                      // 0000000DDAA0: BE81007E
	.long 0xd4c6007e                                           // 0000000DDAA4: D4C6007E
	v_cndmask_b32_e32 v1, s6, v161, vcc_lo                     // 0000000DDAA8: 02034206
	s_xor_b32 s1, exec_lo, s1                                  // 0000000DDAAC: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 0000000DDAB0: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000DDAB8: BE813001
	s_cbranch_execz 69                                         // 0000000DDABC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	s_mov_b32 s7, exec_lo                                      // 0000000DDAC0: BE87007E
	.long 0xd4c1007e                                           // 0000000DDAC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000DDAC8: 02033D82
	s_cbranch_execz 63                                         // 0000000DDACC: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12cc>
	s_mov_b32 s9, 0                                            // 0000000DDAD0: BE890080
	s_set_inst_prefetch_distance 0x1                           // 0000000DDAD4: BF840001
	s_branch 19                                                // 0000000DDAD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1228>
	s_nop 0                                                    // 0000000DDADC: BF800000
	s_nop 0                                                    // 0000000DDAE0: BF800000
	s_nop 0                                                    // 0000000DDAE4: BF800000
	s_nop 0                                                    // 0000000DDAE8: BF800000
	s_nop 0                                                    // 0000000DDAEC: BF800000
	s_nop 0                                                    // 0000000DDAF0: BF800000
	s_nop 0                                                    // 0000000DDAF4: BF800000
	s_nop 0                                                    // 0000000DDAF8: BF800000
	s_nop 0                                                    // 0000000DDAFC: BF800000
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000DDB00: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DDB04: BF870499
	s_and_b32 s13, exec_lo, s12                                // 0000000DDB08: 8B0D0C7E
	s_or_b32 s9, s13, s9                                       // 0000000DDB0C: 8C09090D
	s_and_not1_b32 s8, s8, exec_lo                             // 0000000DDB10: 91087E08
	s_and_b32 s13, s10, exec_lo                                // 0000000DDB14: 8B0D7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDB18: BF870009
	s_or_b32 s8, s8, s13                                       // 0000000DDB1C: 8C080D08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000DDB20: 917E097E
	s_cbranch_execz 27                                         // 0000000DDB24: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1294>
	v_mov_b32_e32 v131, v130                                   // 0000000DDB28: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 0000000DDB2C: 8C0A7E0A
	s_or_b32 s12, s12, exec_lo                                 // 0000000DDB30: 8C0C7E0C
	s_mov_b32 s13, exec_lo                                     // 0000000DDB34: BE8D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDB38: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000DDB3C: 3509069F
	.long 0xd73c0086                                           // 0000000DDB40: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000DDB44: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDB48: BF870091
	.long 0xd7006a86                                           // 0000000DDB4C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000DDB50: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000DDB54: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000DDB5C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000DDB64: BF8903F7
	.long 0xd4c4007e                                           // 0000000DDB68: D4C4007E
	v_cndmask_b32_e32 v1, s6, v132, vcc_lo                     // 0000000DDB6C: 02030806
	s_cbranch_execz 65507                                      // 0000000DDB70: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000DDB74: 4B050681
	s_and_not1_b32 s12, s12, exec_lo                           // 0000000DDB78: 910C7E0C
	s_and_not1_b32 s10, s10, exec_lo                           // 0000000DDB7C: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DDB80: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000DDB84: 7C95059E
	s_and_b32 s26, vcc_lo, exec_lo                             // 0000000DDB88: 8B1A7E6A
	s_or_b32 s12, s12, s26                                     // 0000000DDB8C: 8C0C1A0C
	s_branch 65499                                             // 0000000DDB90: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	s_set_inst_prefetch_distance 0x2                           // 0000000DDB94: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000DDB98: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 0000000DDB9C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 0000000DDBA0: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDBA4: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 0000000DDBA8: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 0000000DDBAC: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000DDBB0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDBBC: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000DDBC0: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000DDBC4: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000DDBC8: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDBCC: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000DDBD0: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDBD4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDBD8: 8C7E017E
	s_or_b32 s5, s5, 3                                         // 0000000DDBDC: 8C058305
	s_mov_b32 s1, exec_lo                                      // 0000000DDBE0: BE81007E
	.long 0xd4c6007e                                           // 0000000DDBE4: D4C6007E
	v_cndmask_b32_e32 v1, s5, v161, vcc_lo                     // 0000000DDBE8: 02034205
	s_xor_b32 s1, exec_lo, s1                                  // 0000000DDBEC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000DDBF0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000DDBF8: BE813001
	s_cbranch_execz 66                                         // 0000000DDBFC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1408>
	s_mov_b32 s6, exec_lo                                      // 0000000DDC00: BE86007E
	.long 0xd4c1007e                                           // 0000000DDC04: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000DDC08: 02033D82
	s_cbranch_execz 60                                         // 0000000DDC0C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_mov_b32 s8, 0                                            // 0000000DDC10: BE880080
	s_set_inst_prefetch_distance 0x1                           // 0000000DDC14: BF840001
	s_branch 19                                                // 0000000DDC18: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1368>
	s_nop 0                                                    // 0000000DDC1C: BF800000
	s_nop 0                                                    // 0000000DDC20: BF800000
	s_nop 0                                                    // 0000000DDC24: BF800000
	s_nop 0                                                    // 0000000DDC28: BF800000
	s_nop 0                                                    // 0000000DDC2C: BF800000
	s_nop 0                                                    // 0000000DDC30: BF800000
	s_nop 0                                                    // 0000000DDC34: BF800000
	s_nop 0                                                    // 0000000DDC38: BF800000
	s_nop 0                                                    // 0000000DDC3C: BF800000
	s_or_b32 exec_lo, exec_lo, s12                             // 0000000DDC40: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DDC44: BF870499
	s_and_b32 s12, exec_lo, s10                                // 0000000DDC48: 8B0C0A7E
	s_or_b32 s8, s12, s8                                       // 0000000DDC4C: 8C08080C
	s_and_not1_b32 s7, s7, exec_lo                             // 0000000DDC50: 91077E07
	s_and_b32 s12, s9, exec_lo                                 // 0000000DDC54: 8B0C7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDC58: BF870009
	s_or_b32 s7, s7, s12                                       // 0000000DDC5C: 8C070C07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000000DDC60: 917E087E
	s_cbranch_execz 26                                         // 0000000DDC64: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13d0>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000DDC68: 3507049F
	s_or_b32 s9, s9, exec_lo                                   // 0000000DDC6C: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 0000000DDC70: 8C0A7E0A
	s_mov_b32 s12, exec_lo                                     // 0000000DDC74: BE8C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDC78: BF870091
	.long 0xd73c0083                                           // 0000000DDC7C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000DDC80: 02030482
	.long 0xd7006a83                                           // 0000000DDC84: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000DDC88: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDC8C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000DDC90: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000DDC98: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000DDCA0: BF8903F7
	.long 0xd4c4007e                                           // 0000000DDCA4: D4C4007E
	v_cndmask_b32_e32 v1, s5, v131, vcc_lo                     // 0000000DDCA8: 02030605
	s_cbranch_execz 65508                                      // 0000000DDCAC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000DDCB0: 4B050481
	s_and_not1_b32 s10, s10, exec_lo                           // 0000000DDCB4: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000DDCB8: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DDCBC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000DDCC0: 7C95059E
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000000DDCC4: 8B0D7E6A
	s_or_b32 s10, s10, s13                                     // 0000000DDCC8: 8C0A0D0A
	s_branch 65500                                             // 0000000DDCCC: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	s_set_inst_prefetch_distance 0x2                           // 0000000DDCD0: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000DDCD4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000DDCD8: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDCDC: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 0000000DDCE0: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v131                          // 0000000DDCE4: 7C950605
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000DDCE8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDCF4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000DDCF8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000DDCFC: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDD00: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000DDD04: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDD08: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDD0C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DDD10: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DDD14: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 0000000DDD18: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 0000000DDD20: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 0000000DDD24: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000DDD28: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDD30: BF870001
	v_readfirstlane_b32 s1, v130                               // 0000000DDD34: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 0000000DDD38: BF0C8001
	s_mov_b32 s1, 0                                            // 0000000DDD3C: BE810080
	s_cbranch_scc1 8                                           // 0000000DDD40: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1464>
	s_or_b32 s1, s2, 15                                        // 0000000DDD44: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DDD48: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v159                          // 0000000DDD4C: 7C873E01
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 0000000DDD50: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 0000000DDD58: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 0000000DDD5C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000DDD60: 980180C1
	s_and_saveexec_b32 s12, s3                                 // 0000000DDD64: BE8C2003
	s_cbranch_execz 1304                                       // 0000000DDD68: BFA50518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x28cc>
	ds_load_b32 v130, v163                                     // 0000000DDD6C: D8D80000 820000A3
	s_xor_b32 s1, s1, -1                                       // 0000000DDD74: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDD78: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000DDD7C: 916A017E
	s_mov_b32 s1, -1                                           // 0000000DDD80: BE8100C1
	s_cbranch_vccnz 798                                        // 0000000DDD84: BFA4031E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2100>
	v_and_b32_e32 v131, 1, v133                                // 0000000DDD88: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000DDD8C: 7C874402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DDD90: BF8704C2
	.long 0xd44a0001                                           // 0000000DDD94: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000000DDD98: 02030681
	s_waitcnt lgkmcnt(0)                                       // 0000000DDD9C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 0000000DDDA0: 7F060382
	s_and_b32 s35, vcc_lo, s1                                  // 0000000DDDA4: 8B23016A
	s_and_saveexec_b32 s1, s35                                 // 0000000DDDA8: BE812023
	s_cbranch_execz 7                                          // 0000000DDDAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14cc>
	ds_load_b32 v131, v164                                     // 0000000DDDB0: D8D80000 830000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDDB8: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 0000000DDDBC: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDDC4: BF870001
	v_max_f32_e32 v131, v132, v131                             // 0000000DDDC8: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDDCC: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 0000000DDDD0: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 0000000DDDD4: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000DDDD8: BF8704A2
	.long 0xd44d0001                                           // 0000000DDDDC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDDE0: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000DDDE4: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 0000000DDDE8: BE812022
	s_cbranch_execz 7                                          // 0000000DDDEC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x150c>
	ds_load_b32 v132, v164 offset:4                            // 0000000DDDF0: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDDF8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDDFC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDE04: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDE08: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDE0C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000DDE10: 37090A84
	s_or_b32 s1, s2, 2                                         // 0000000DDE14: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDE18: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDE1C: 7C874401
	.long 0xd44d0001                                           // 0000000DDE20: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDE24: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 0000000DDE28: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDE2C: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000DDE30: BE81201F
	s_cbranch_execz 7                                          // 0000000DDE34: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1554>
	ds_load_b32 v132, v164 offset:8                            // 0000000DDE38: D8D80008 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDE40: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDE44: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDE4C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDE50: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDE54: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 0000000DDE58: 37090A88
	s_or_b32 s1, s2, 3                                         // 0000000DDE5C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDE60: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDE64: 7C874401
	.long 0xd44d0001                                           // 0000000DDE68: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDE6C: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000DDE70: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDE74: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000DDE78: BE812021
	s_cbranch_execz 7                                          // 0000000DDE7C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x159c>
	ds_load_b32 v132, v164 offset:12                           // 0000000DDE80: D8D8000C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDE88: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDE8C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDE94: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDE98: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDE9C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 0000000DDEA0: 37090A90
	s_or_b32 s1, s2, 4                                         // 0000000DDEA4: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDEA8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDEAC: 7C874401
	.long 0xd44d0001                                           // 0000000DDEB0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDEB4: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 0000000DDEB8: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDEBC: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000DDEC0: BE81201B
	s_cbranch_execz 7                                          // 0000000DDEC4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15e4>
	ds_load_b32 v132, v164 offset:16                           // 0000000DDEC8: D8D80010 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDED0: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDED4: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDEDC: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDEE0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDEE4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000DDEE8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 0000000DDEEC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDEF0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDEF4: 7C874401
	.long 0xd44d0001                                           // 0000000DDEF8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDEFC: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 0000000DDF00: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDF04: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000DDF08: BE81201E
	s_cbranch_execz 7                                          // 0000000DDF0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x162c>
	ds_load_b32 v132, v164 offset:20                           // 0000000DDF10: D8D80014 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDF18: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDF1C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDF24: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDF28: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDF2C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000DDF30: 37090AC0
	s_or_b32 s1, s2, 6                                         // 0000000DDF34: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDF38: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDF3C: 7C874401
	.long 0xd44d0001                                           // 0000000DDF40: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDF44: 02030880
	s_and_b32 s13, vcc_lo, s1                                  // 0000000DDF48: 8B0D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDF4C: BF870009
	s_and_saveexec_b32 s1, s13                                 // 0000000DDF50: BE81200D
	s_cbranch_execz 7                                          // 0000000DDF54: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1674>
	ds_load_b32 v132, v164 offset:24                           // 0000000DDF58: D8D80018 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDF60: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDF64: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDF6C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDF70: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDF74: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 0000000DDF78: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 0000000DDF80: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDF84: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDF88: 7C874401
	.long 0xd44d0001                                           // 0000000DDF8C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDF90: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 0000000DDF94: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDF98: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000DDF9C: BE81201A
	s_cbranch_execz 7                                          // 0000000DDFA0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	ds_load_b32 v132, v164 offset:28                           // 0000000DDFA4: D8D8001C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDFAC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDFB0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDFB8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DDFBC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DDFC0: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 0000000DDFC4: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 0000000DDFCC: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DDFD0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DDFD4: 7C874401
	.long 0xd44d0001                                           // 0000000DDFD8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DDFDC: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000DDFE0: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDFE4: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000DDFE8: BE812009
	s_cbranch_execz 7                                          // 0000000DDFEC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x170c>
	ds_load_b32 v132, v164 offset:32                           // 0000000DDFF0: D8D80020 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DDFF8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DDFFC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE004: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE008: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE00C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000DE010: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000DE018: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE01C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE020: 7C874401
	.long 0xd44d0001                                           // 0000000DE024: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE028: 02030880
	s_and_b32 s10, vcc_lo, s1                                  // 0000000DE02C: 8B0A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE030: BF870009
	s_and_saveexec_b32 s1, s10                                 // 0000000DE034: BE81200A
	s_cbranch_execz 7                                          // 0000000DE038: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1758>
	ds_load_b32 v132, v164 offset:36                           // 0000000DE03C: D8D80024 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE044: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE048: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE050: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE054: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE058: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000000DE05C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000000DE064: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE068: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE06C: 7C874401
	.long 0xd44d0001                                           // 0000000DE070: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE074: 02030880
	s_and_b32 s7, vcc_lo, s1                                   // 0000000DE078: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE07C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 0000000DE080: BE812007
	s_cbranch_execz 7                                          // 0000000DE084: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17a4>
	ds_load_b32 v132, v164 offset:40                           // 0000000DE088: D8D80028 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE090: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE094: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE09C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE0A0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE0A4: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 0000000DE0A8: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 0000000DE0B0: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE0B4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE0B8: 7C874401
	.long 0xd44d0001                                           // 0000000DE0BC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE0C0: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 0000000DE0C4: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE0C8: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000000DE0CC: BE812008
	s_cbranch_execz 7                                          // 0000000DE0D0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17f0>
	ds_load_b32 v132, v164 offset:44                           // 0000000DE0D4: D8D8002C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE0DC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE0E0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE0E8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE0EC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE0F0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000DE0F4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000DE0FC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE100: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE104: 7C874401
	.long 0xd44d0001                                           // 0000000DE108: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE10C: 02030880
	s_and_b32 s5, vcc_lo, s1                                   // 0000000DE110: 8B05016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE114: BF870009
	s_and_saveexec_b32 s1, s5                                  // 0000000DE118: BE812005
	s_cbranch_execz 7                                          // 0000000DE11C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x183c>
	ds_load_b32 v132, v164 offset:48                           // 0000000DE120: D8D80030 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE128: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE12C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE134: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE138: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE13C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000000DE140: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000000DE148: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE14C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE150: 7C874401
	.long 0xd44d0001                                           // 0000000DE154: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE158: 02030880
	s_and_b32 s6, vcc_lo, s1                                   // 0000000DE15C: 8B06016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE160: BF870009
	s_and_saveexec_b32 s1, s6                                  // 0000000DE164: BE812006
	s_cbranch_execz 7                                          // 0000000DE168: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1888>
	ds_load_b32 v132, v164 offset:52                           // 0000000DE16C: D8D80034 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE174: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE178: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE180: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE184: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE188: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000000DE18C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 0000000DE194: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE198: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000DE19C: 7C874401
	.long 0xd44d0001                                           // 0000000DE1A0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE1A4: 02030880
	s_and_b32 s4, vcc_lo, s1                                   // 0000000DE1A8: 8B04016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE1AC: BF870009
	s_and_saveexec_b32 s1, s4                                  // 0000000DE1B0: BE812004
	s_cbranch_execz 7                                          // 0000000DE1B4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d4>
	ds_load_b32 v132, v164 offset:56                           // 0000000DE1B8: D8D80038 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE1C0: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE1C4: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE1CC: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE1D0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DE1D4: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 0000000DE1D8: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000DE1E0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE1E4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000DE1E8: 7C874402
	.long 0xd44d0001                                           // 0000000DE1EC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000DE1F0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000DE1F4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DE1F8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000DE1FC: BE822001
	s_cbranch_execz 7                                          // 0000000DE200: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1920>
	ds_load_b32 v132, v164 offset:60                           // 0000000DE204: D8D8003C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE20C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000DE210: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE218: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000DE21C: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE220: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000DE224: CA100080 84840080
	s_and_saveexec_b32 s2, s35                                 // 0000000DE22C: BE822023
	s_cbranch_execz 18                                         // 0000000DE230: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x197c>
	ds_load_b32 v133, v164                                     // 0000000DE234: D8D80000 850000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE23C: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 0000000DE240: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE244: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v133                  // 0000000DE248: 7C290AFF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 0000000DE250: D5010086 01A9FE80 42800000
	v_add_f32_e32 v133, v133, v134                             // 0000000DE25C: 070B0D85
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 0000000DE260: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE26C: BF870292
	v_exp_f32_e32 v133, v133                                   // 0000000DE270: 7F0A4B85
	.long 0xd71c0085                                           // 0000000DE274: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 0000000DE278: 02030D85
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE27C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE280: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 0000000DE284: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 0000000DE28C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 0000000DE298: DA840000 000086A5
	s_and_saveexec_b32 s2, s34                                 // 0000000DE2A0: BE822022
	s_cbranch_execz 18                                         // 0000000DE2A4: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f0>
	ds_load_b32 v132, v164 offset:4                            // 0000000DE2A8: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE2B0: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 0000000DE2B4: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE2B8: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 0000000DE2BC: 7C2908FF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 0000000DE2C4: D5010086 01A9FE80 42800000
	v_add_f32_e32 v132, v132, v134                             // 0000000DE2D0: 07090D84
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 0000000DE2D4: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE2E0: BF870292
	v_exp_f32_e32 v132, v132                                   // 0000000DE2E4: 7F084B84
	.long 0xd71c0084                                           // 0000000DE2E8: D71C0084
	v_cndmask_b32_e32 v1, v132, v134, vcc_lo                   // 0000000DE2EC: 02030D84
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE2F0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE2F4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000DE2F8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000DE300: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000DE304: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000DE310: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 0000000DE314: DA840002 000088A5
	s_and_saveexec_b32 s2, s31                                 // 0000000DE31C: BE82201F
	s_cbranch_execz 18                                         // 0000000DE320: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a6c>
	ds_load_b32 v135, v164 offset:8                            // 0000000DE324: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE32C: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 0000000DE330: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE334: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v135                  // 0000000DE338: 7C290EFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 0000000DE340: D5010088 01A9FE80 42800000
	v_add_f32_e32 v135, v135, v136                             // 0000000DE34C: 070F1187
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 0000000DE350: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE35C: BF870292
	v_exp_f32_e32 v135, v135                                   // 0000000DE360: 7F0E4B87
	.long 0xd71c0087                                           // 0000000DE364: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 0000000DE368: 02031187
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE36C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE370: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000DE374: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000DE37C: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 0000000DE388: DA840004 000088A5
	s_and_saveexec_b32 s2, s33                                 // 0000000DE390: BE822021
	s_cbranch_execz 18                                         // 0000000DE394: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ae0>
	ds_load_b32 v134, v164 offset:12                           // 0000000DE398: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE3A0: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 0000000DE3A4: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE3A8: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v134                  // 0000000DE3AC: 7C290CFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 0000000DE3B4: D5010088 01A9FE80 42800000
	v_add_f32_e32 v134, v134, v136                             // 0000000DE3C0: 070D1186
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 0000000DE3C4: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE3D0: BF870292
	v_exp_f32_e32 v134, v134                                   // 0000000DE3D4: 7F0C4B86
	.long 0xd71c0086                                           // 0000000DE3D8: D71C0086
	v_cndmask_b32_e32 v1, v134, v136, vcc_lo                   // 0000000DE3DC: 02031186
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE3E0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE3E4: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000DE3E8: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000DE3F0: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 0000000DE3F4: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000DE400: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 0000000DE404: DA840006 000092A5
	s_and_saveexec_b32 s2, s27                                 // 0000000DE40C: BE82201B
	s_cbranch_execz 18                                         // 0000000DE410: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b5c>
	ds_load_b32 v137, v164 offset:16                           // 0000000DE414: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE41C: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 0000000DE420: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE424: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v137                  // 0000000DE428: 7C2912FF C2FC0000
	v_cndmask_b32_e64 v146, 0, 0x42800000, vcc_lo              // 0000000DE430: D5010092 01A9FE80 42800000
	v_add_f32_e32 v137, v137, v146                             // 0000000DE43C: 07132589
	v_cndmask_b32_e64 v146, 0, 0xffffffc0, vcc_lo              // 0000000DE440: D5010092 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE44C: BF870292
	v_exp_f32_e32 v137, v137                                   // 0000000DE450: 7F124B89
	.long 0xd71c0089                                           // 0000000DE454: D71C0089
	v_cndmask_b32_e32 v1, v137, v146, vcc_lo                   // 0000000DE458: 02032589
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE45C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE460: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000000DE464: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000000DE46C: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 0000000DE478: DA840008 000092A5
	s_and_saveexec_b32 s2, s30                                 // 0000000DE480: BE82201E
	s_cbranch_execz 18                                         // 0000000DE484: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bd0>
	ds_load_b32 v136, v164 offset:20                           // 0000000DE488: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE490: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 0000000DE494: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE498: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v136                  // 0000000DE49C: 7C2910FF C2FC0000
	v_cndmask_b32_e64 v146, 0, 0x42800000, vcc_lo              // 0000000DE4A4: D5010092 01A9FE80 42800000
	v_add_f32_e32 v136, v136, v146                             // 0000000DE4B0: 07112588
	v_cndmask_b32_e64 v146, 0, 0xffffffc0, vcc_lo              // 0000000DE4B4: D5010092 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE4C0: BF870292
	v_exp_f32_e32 v136, v136                                   // 0000000DE4C4: 7F104B88
	.long 0xd71c0088                                           // 0000000DE4C8: D71C0088
	v_cndmask_b32_e32 v1, v136, v146, vcc_lo                   // 0000000DE4CC: 02032588
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE4D0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE4D4: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 0000000DE4D8: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 0000000DE4E0: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 0000000DE4E4: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000000DE4F0: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 0000000DE4F4: DA84000A 000094A5
	s_and_saveexec_b32 s2, s13                                 // 0000000DE4FC: BE82200D
	s_cbranch_execz 18                                         // 0000000DE500: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c4c>
	ds_load_b32 v147, v164 offset:24                           // 0000000DE504: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE50C: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 0000000DE510: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE514: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v147                  // 0000000DE518: 7C2926FF C2FC0000
	v_cndmask_b32_e64 v148, 0, 0x42800000, vcc_lo              // 0000000DE520: D5010094 01A9FE80 42800000
	v_add_f32_e32 v147, v147, v148                             // 0000000DE52C: 07272993
	v_cndmask_b32_e64 v148, 0, 0xffffffc0, vcc_lo              // 0000000DE530: D5010094 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE53C: BF870292
	v_exp_f32_e32 v147, v147                                   // 0000000DE540: 7F264B93
	.long 0xd71c0093                                           // 0000000DE544: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 0000000DE548: 02032993
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE54C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE550: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 0000000DE554: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 0000000DE55C: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 0000000DE568: DA84000C 000094A5
	s_and_saveexec_b32 s2, s26                                 // 0000000DE570: BE82201A
	s_cbranch_execz 18                                         // 0000000DE574: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cc0>
	ds_load_b32 v146, v164 offset:28                           // 0000000DE578: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE580: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 0000000DE584: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE588: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v146                  // 0000000DE58C: 7C2924FF C2FC0000
	v_cndmask_b32_e64 v148, 0, 0x42800000, vcc_lo              // 0000000DE594: D5010094 01A9FE80 42800000
	v_add_f32_e32 v146, v146, v148                             // 0000000DE5A0: 07252992
	v_cndmask_b32_e64 v148, 0, 0xffffffc0, vcc_lo              // 0000000DE5A4: D5010094 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE5B0: BF870292
	v_exp_f32_e32 v146, v146                                   // 0000000DE5B4: 7F244B92
	.long 0xd71c0092                                           // 0000000DE5B8: D71C0092
	v_cndmask_b32_e32 v1, v146, v148, vcc_lo                   // 0000000DE5BC: 02032992
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE5C0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE5C4: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000000DE5C8: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000000DE5D0: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000000DE5D4: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000000DE5E0: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 0000000DE5E4: DA84000E 000096A5
	s_and_saveexec_b32 s2, s9                                  // 0000000DE5EC: BE822009
	s_cbranch_execz 18                                         // 0000000DE5F0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d3c>
	ds_load_b32 v149, v164 offset:32                           // 0000000DE5F4: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE5FC: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 0000000DE600: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE604: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v149                  // 0000000DE608: 7C292AFF C2FC0000
	v_cndmask_b32_e64 v150, 0, 0x42800000, vcc_lo              // 0000000DE610: D5010096 01A9FE80 42800000
	v_add_f32_e32 v149, v149, v150                             // 0000000DE61C: 072B2D95
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, vcc_lo              // 0000000DE620: D5010096 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE62C: BF870292
	v_exp_f32_e32 v149, v149                                   // 0000000DE630: 7F2A4B95
	.long 0xd71c0095                                           // 0000000DE634: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000000DE638: 02032D95
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE63C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE640: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 0000000DE644: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 0000000DE64C: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 0000000DE658: DA840010 000096A5
	s_and_saveexec_b32 s2, s10                                 // 0000000DE660: BE82200A
	s_cbranch_execz 18                                         // 0000000DE664: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1db0>
	ds_load_b32 v148, v164 offset:36                           // 0000000DE668: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE670: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 0000000DE674: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE678: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v148                  // 0000000DE67C: 7C2928FF C2FC0000
	v_cndmask_b32_e64 v150, 0, 0x42800000, vcc_lo              // 0000000DE684: D5010096 01A9FE80 42800000
	v_add_f32_e32 v148, v148, v150                             // 0000000DE690: 07292D94
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, vcc_lo              // 0000000DE694: D5010096 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE6A0: BF870292
	v_exp_f32_e32 v148, v148                                   // 0000000DE6A4: 7F284B94
	.long 0xd71c0094                                           // 0000000DE6A8: D71C0094
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                   // 0000000DE6AC: 02032D94
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE6B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE6B4: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 0000000DE6B8: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 0000000DE6C0: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 0000000DE6C4: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 0000000DE6D0: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 0000000DE6D4: DA840012 000098A5
	s_and_saveexec_b32 s2, s7                                  // 0000000DE6DC: BE822007
	s_cbranch_execz 18                                         // 0000000DE6E0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e2c>
	ds_load_b32 v151, v164 offset:40                           // 0000000DE6E4: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE6EC: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 0000000DE6F0: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE6F4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v151                  // 0000000DE6F8: 7C292EFF C2FC0000
	v_cndmask_b32_e64 v152, 0, 0x42800000, vcc_lo              // 0000000DE700: D5010098 01A9FE80 42800000
	v_add_f32_e32 v151, v151, v152                             // 0000000DE70C: 072F3197
	v_cndmask_b32_e64 v152, 0, 0xffffffc0, vcc_lo              // 0000000DE710: D5010098 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE71C: BF870292
	v_exp_f32_e32 v151, v151                                   // 0000000DE720: 7F2E4B97
	.long 0xd71c0097                                           // 0000000DE724: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000000DE728: 02033197
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE72C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE730: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 0000000DE734: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000000DE73C: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 0000000DE748: DA840014 000098A5
	s_and_saveexec_b32 s2, s8                                  // 0000000DE750: BE822008
	s_cbranch_execz 18                                         // 0000000DE754: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ea0>
	ds_load_b32 v150, v164 offset:44                           // 0000000DE758: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE760: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 0000000DE764: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE768: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v150                  // 0000000DE76C: 7C292CFF C2FC0000
	v_cndmask_b32_e64 v152, 0, 0x42800000, vcc_lo              // 0000000DE774: D5010098 01A9FE80 42800000
	v_add_f32_e32 v150, v150, v152                             // 0000000DE780: 072D3196
	v_cndmask_b32_e64 v152, 0, 0xffffffc0, vcc_lo              // 0000000DE784: D5010098 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE790: BF870292
	v_exp_f32_e32 v150, v150                                   // 0000000DE794: 7F2C4B96
	.long 0xd71c0096                                           // 0000000DE798: D71C0096
	v_cndmask_b32_e32 v1, v150, v152, vcc_lo                   // 0000000DE79C: 02033196
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE7A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE7A4: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 0000000DE7A8: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 0000000DE7B0: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 0000000DE7B4: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 0000000DE7C0: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 0000000DE7C4: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s5                                  // 0000000DE7CC: BE822005
	s_cbranch_execz 18                                         // 0000000DE7D0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f1c>
	ds_load_b32 v153, v164 offset:48                           // 0000000DE7D4: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE7DC: BF89FC07
	v_sub_f32_e32 v153, v153, v131                             // 0000000DE7E0: 09330799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE7E4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v153                  // 0000000DE7E8: 7C2932FF C2FC0000
	v_cndmask_b32_e64 v177, 0, 0x42800000, vcc_lo              // 0000000DE7F0: D50100B1 01A9FE80 42800000
	v_add_f32_e32 v153, v153, v177                             // 0000000DE7FC: 07336399
	v_cndmask_b32_e64 v177, 0, 0xffffffc0, vcc_lo              // 0000000DE800: D50100B1 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE80C: BF870292
	v_exp_f32_e32 v153, v153                                   // 0000000DE810: 7F324B99
	.long 0xd71c0099                                           // 0000000DE814: D71C0099
	v_cndmask_b32_e32 v1, v153, v177, vcc_lo                   // 0000000DE818: 02036399
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE81C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE820: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 0000000DE824: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 0000000DE82C: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 0000000DE838: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s6                                  // 0000000DE840: BE822006
	s_cbranch_execz 18                                         // 0000000DE844: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f90>
	ds_load_b32 v152, v164 offset:52                           // 0000000DE848: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE850: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 0000000DE854: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE858: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v152                  // 0000000DE85C: 7C2930FF C2FC0000
	v_cndmask_b32_e64 v177, 0, 0x42800000, vcc_lo              // 0000000DE864: D50100B1 01A9FE80 42800000
	v_add_f32_e32 v152, v152, v177                             // 0000000DE870: 07316398
	v_cndmask_b32_e64 v177, 0, 0xffffffc0, vcc_lo              // 0000000DE874: D50100B1 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE880: BF870292
	v_exp_f32_e32 v152, v152                                   // 0000000DE884: 7F304B98
	.long 0xd71c0098                                           // 0000000DE888: D71C0098
	v_cndmask_b32_e32 v1, v152, v177, vcc_lo                   // 0000000DE88C: 02036398
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE890: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE894: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 0000000DE898: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 0000000DE8A0: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 0000000DE8A4: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000DE8B0: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 0000000DE8B4: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s4                                  // 0000000DE8BC: BE822004
	s_cbranch_execz 18                                         // 0000000DE8C0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x200c>
	ds_load_b32 v178, v164 offset:56                           // 0000000DE8C4: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE8CC: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 0000000DE8D0: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE8D4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v178                  // 0000000DE8D8: 7C2964FF C2FC0000
	v_cndmask_b32_e64 v179, 0, 0x42800000, vcc_lo              // 0000000DE8E0: D50100B3 01A9FE80 42800000
	v_add_f32_e32 v178, v178, v179                             // 0000000DE8EC: 076567B2
	v_cndmask_b32_e64 v179, 0, 0xffffffc0, vcc_lo              // 0000000DE8F0: D50100B3 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE8FC: BF870292
	v_exp_f32_e32 v178, v178                                   // 0000000DE900: 7F644BB2
	.long 0xd71c00b2                                           // 0000000DE904: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 0000000DE908: 020367B2
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE90C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE910: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000DE914: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000DE91C: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 0000000DE928: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 0000000DE930: BE822001
	s_cbranch_execz 18                                         // 0000000DE934: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2080>
	ds_load_b32 v177, v164 offset:60                           // 0000000DE938: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000DE940: BF89FC07
	v_sub_f32_e32 v177, v177, v131                             // 0000000DE944: 096307B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DE948: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v177                  // 0000000DE94C: 7C2962FF C2FC0000
	v_cndmask_b32_e64 v179, 0, 0x42800000, vcc_lo              // 0000000DE954: D50100B3 01A9FE80 42800000
	v_add_f32_e32 v177, v177, v179                             // 0000000DE960: 076367B1
	v_cndmask_b32_e64 v179, 0, 0xffffffc0, vcc_lo              // 0000000DE964: D50100B3 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DE970: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000DE974: 7F624BB1
	.long 0xd71c00b1                                           // 0000000DE978: D71C00B1
	v_cndmask_b32_e32 v1, v177, v179, vcc_lo                   // 0000000DE97C: 020367B1
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DE980: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 0000000DE984: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE988: BF870122
	v_bfe_u32 v133, v177, 16, 1                                // 0000000DE98C: D6100085 020521B1
	s_mov_b32 s1, 0                                            // 0000000DE994: BE810080
	v_add_f32_e32 v132, v132, v135                             // 0000000DE998: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DE99C: BF870112
	v_add3_u32 v133, v177, v133, 0x7fff                        // 0000000DE9A0: D6550085 03FF0BB1 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 0000000DE9AC: 07090D84
	ds_store_b16_d16_hi v165, v133 offset:30                   // 0000000DE9B0: DA84001E 000085A5
	v_add_f32_e32 v132, v132, v137                             // 0000000DE9B8: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9BC: BF870091
	v_add_f32_e32 v132, v132, v136                             // 0000000DE9C0: 07091184
	v_add_f32_e32 v132, v132, v147                             // 0000000DE9C4: 07092784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9C8: BF870091
	v_add_f32_e32 v132, v132, v146                             // 0000000DE9CC: 07092584
	v_add_f32_e32 v132, v132, v149                             // 0000000DE9D0: 07092B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9D4: BF870091
	v_add_f32_e32 v132, v132, v148                             // 0000000DE9D8: 07092984
	v_add_f32_e32 v132, v132, v151                             // 0000000DE9DC: 07092F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9E0: BF870091
	v_add_f32_e32 v132, v132, v150                             // 0000000DE9E4: 07092D84
	v_add_f32_e32 v132, v132, v153                             // 0000000DE9E8: 07093384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9EC: BF870091
	v_add_f32_e32 v132, v132, v152                             // 0000000DE9F0: 07093184
	v_add_f32_e32 v132, v132, v178                             // 0000000DE9F4: 07096584
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE9F8: BF870001
	v_add_f32_e32 v132, v132, v177                             // 0000000DE9FC: 07096384
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000DEA00: 8B6A017E
	s_cbranch_vccz 465                                         // 0000000DEA04: BFA301D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x284c>
	ds_load_2addr_b32 v[132:133], v164 offset1:1               // 0000000DEA08: D8DC0100 840000A4
	ds_load_2addr_b32 v[134:135], v164 offset0:2 offset1:3     // 0000000DEA10: D8DC0302 860000A4
	ds_load_2addr_b32 v[136:137], v164 offset0:4 offset1:5     // 0000000DEA18: D8DC0504 880000A4
	ds_load_2addr_b32 v[146:147], v164 offset0:6 offset1:7     // 0000000DEA20: D8DC0706 920000A4
	ds_load_2addr_b32 v[148:149], v164 offset0:8 offset1:9     // 0000000DEA28: D8DC0908 940000A4
	ds_load_2addr_b32 v[150:151], v164 offset0:10 offset1:11   // 0000000DEA30: D8DC0B0A 960000A4
	ds_load_2addr_b32 v[152:153], v164 offset0:12 offset1:13   // 0000000DEA38: D8DC0D0C 980000A4
	ds_load_2addr_b32 v[177:178], v164 offset0:14 offset1:15   // 0000000DEA40: D8DC0F0E B10000A4
	.long 0xd59c40b3                                           // 0000000DEA48: D59C40B3
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000000DEA4C: 02010080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DEA50: BF870001
	.long 0xd59c48b5                                           // 0000000DEA54: D59C48B5
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEA58: 020101B3
	.long 0xd59c48b4                                           // 0000000DEA5C: D59C48B4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEA60: 020101B3
	.long 0xd59c48b7                                           // 0000000DEA64: D59C48B7
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEA68: 020101B3
	.long 0xd59c48b6                                           // 0000000DEA6C: D59C48B6
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEA70: 020101B3
	s_waitcnt lgkmcnt(7)                                       // 0000000DEA74: BF89FC77
	v_max3_f32 v131, v130, v132, v133                          // 0000000DEA78: D61C0083 06170982
	s_waitcnt lgkmcnt(6)                                       // 0000000DEA80: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DEA84: BF8700A1
	v_max3_f32 v131, v131, v134, v135                          // 0000000DEA88: D61C0083 061F0D83
	s_waitcnt lgkmcnt(5)                                       // 0000000DEA90: BF89FC57
	v_max3_f32 v131, v131, v136, v137                          // 0000000DEA94: D61C0083 06271183
	s_waitcnt lgkmcnt(4)                                       // 0000000DEA9C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DEAA0: BF8700A1
	v_max3_f32 v131, v131, v146, v147                          // 0000000DEAA4: D61C0083 064F2583
	s_waitcnt lgkmcnt(3)                                       // 0000000DEAAC: BF89FC37
	v_max3_f32 v131, v131, v148, v149                          // 0000000DEAB0: D61C0083 06572983
	s_waitcnt lgkmcnt(2)                                       // 0000000DEAB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DEABC: BF8700A1
	v_max3_f32 v131, v131, v150, v151                          // 0000000DEAC0: D61C0083 065F2D83
	s_waitcnt lgkmcnt(1)                                       // 0000000DEAC8: BF89FC17
	v_max3_f32 v131, v131, v152, v153                          // 0000000DEACC: D61C0083 06673183
	s_waitcnt lgkmcnt(0)                                       // 0000000DEAD4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEAD8: BF870091
	v_max3_f32 v131, v131, v177, v178                          // 0000000DEADC: D61C0083 06CB6383
	v_sub_f32_e32 v132, v132, v131                             // 0000000DEAE4: 09090784
	v_sub_f32_e32 v178, v178, v131                             // 0000000DEAE8: 096507B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DEAEC: BF8700A2
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 0000000DEAF0: 7C2908FF C2FC0000
	v_cndmask_b32_e64 v184, 0, 0x42800000, vcc_lo              // 0000000DEAF8: D50100B8 01A9FE80 42800000
	v_dual_sub_f32 v133, v133, v131 :: v_dual_add_f32 v132, v132, v184// 0000000DEB04: C9490785 85857184
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DEB0C: BF8701A1
	.long 0xd4140001                                           // 0000000DEB10: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v133, vcc_lo             // 0000000DEB14: 02030AFF C2FC0000
	v_cndmask_b32_e64 v184, 0, 0xffffffc0, vcc_lo              // 0000000DEB1C: D50100B8 01A9FE80 FFFFFFC0
	v_exp_f32_e32 v132, v132                                   // 0000000DEB28: 7F084B84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEB2C: BF870092
	v_cndmask_b32_e64 v185, 0, 0x42800000, s1                  // 0000000DEB30: D50100B9 0005FE80 42800000
	v_add_f32_e32 v133, v133, v185                             // 0000000DEB3C: 070B7385
	v_cndmask_b32_e64 v185, 0, 0xffffffc0, s1                  // 0000000DEB40: D50100B9 0005FE80 FFFFFFC0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEB4C: BF870195
	.long 0xd71c0084                                           // 0000000DEB50: D71C0084
	v_cndmask_b32_e32 v1, v132, v184, vcc_lo                   // 0000000DEB54: 02037184
	v_exp_f32_e32 v133, v133                                   // 0000000DEB58: 7F0A4B85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DEB5C: BF870291
	.long 0xd59c08b4                                           // 0000000DEB60: D59C08B4
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 0000000DEB64: 02010184
	.long 0xd71c0085                                           // 0000000DEB68: D71C0085
	v_cndmask_b32_e32 v1, v133, v185, vcc_lo                   // 0000000DEB6C: 02037385
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DEB70: BF870121
	v_dual_sub_f32 v147, v147, v131 :: v_dual_add_f32 v184, v132, v133// 0000000DEB74: C9490793 93B90B84
	v_sub_f32_e32 v149, v149, v131                             // 0000000DEB7C: 092B0795
	.long 0xd4140007                                           // 0000000DEB80: D4140007
	v_cndmask_b32_e32 v1, 0xc2fc0000, v147, vcc_lo             // 0000000DEB84: 020326FF C2FC0000
	.long 0xd59c08b3                                           // 0000000DEB8C: D59C08B3
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000000DEB90: 02010185
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEB94: BF870193
	.long 0xd4140009                                           // 0000000DEB98: D4140009
	v_cndmask_b32_e32 v1, 0xc2fc0000, v149, vcc_lo             // 0000000DEB9C: 02032AFF C2FC0000
	v_cndmask_b32_e64 v190, 0, 0x42800000, s7                  // 0000000DEBA4: D50100BE 001DFE80 42800000
	v_sub_f32_e32 v146, v146, v131                             // 0000000DEBB0: 09250792
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEBB4: BF870193
	v_cndmask_b32_e64 v192, 0, 0x42800000, s9                  // 0000000DEBB8: D50100C0 0025FE80 42800000
	v_dual_sub_f32 v148, v148, v131 :: v_dual_add_f32 v147, v147, v190// 0000000DEBC4: C9490794 94937D93
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DEBCC: BF870223
	.long 0xd4140008                                           // 0000000DEBD0: D4140008
	v_cndmask_b32_e32 v1, 0xc2fc0000, v146, vcc_lo             // 0000000DEBD4: 020324FF C2FC0000
	v_cndmask_b32_e64 v190, 0, 0xffffffc0, s7                  // 0000000DEBDC: D50100BE 001DFE80 FFFFFFC0
	v_add_f32_e32 v149, v149, v192                             // 0000000DEBE8: 072B8195
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DEBEC: BF8701B4
	.long 0xd414000a                                           // 0000000DEBF0: D414000A
	v_cndmask_b32_e32 v1, 0xc2fc0000, v148, vcc_lo             // 0000000DEBF4: 020328FF C2FC0000
	v_exp_f32_e32 v147, v147                                   // 0000000DEBFC: 7F264B93
	v_cndmask_b32_e64 v191, 0, 0x42800000, s8                  // 0000000DEC00: D50100BF 0021FE80 42800000
	v_exp_f32_e32 v149, v149                                   // 0000000DEC0C: 7F2A4B95
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DEC10: BF8701A2
	v_cndmask_b32_e64 v193, 0, 0x42800000, s10                 // 0000000DEC14: D50100C1 0029FE80 42800000
	v_sub_f32_e32 v137, v137, v131                             // 0000000DEC20: 09130789
	v_add_f32_e32 v146, v146, v191                             // 0000000DEC24: 07257F92
	v_cndmask_b32_e64 v191, 0, 0xffffffc0, s8                  // 0000000DEC28: D50100BF 0021FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DEC34: BF870214
	v_add_f32_e32 v148, v148, v193                             // 0000000DEC38: 07298394
	.long 0xd4140005                                           // 0000000DEC3C: D4140005
	v_cndmask_b32_e32 v1, 0xc2fc0000, v137, vcc_lo             // 0000000DEC40: 020312FF C2FC0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DEC48: BF870004
	v_exp_f32_e32 v146, v146                                   // 0000000DEC4C: 7F244B92
	.long 0xd71c0093                                           // 0000000DEC50: D71C0093
	v_cndmask_b32_e32 v1, v147, v190, vcc_lo                   // 0000000DEC54: 02037D93
	v_and_b32_e32 v180, 1, v180                                // 0000000DEC58: 37696881
	v_exp_f32_e32 v148, v148                                   // 0000000DEC5C: 7F284B94
	v_cndmask_b32_e64 v188, 0, 0x42800000, s5                  // 0000000DEC60: D50100BC 0015FE80 42800000
	v_sub_f32_e32 v136, v136, v131                             // 0000000DEC6C: 09110788
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEC70: BF870193
	v_add3_u32 v132, v132, v180, 0x7fff                        // 0000000DEC74: D6550084 03FF6984 00007FFF
	v_add_f32_e32 v137, v137, v188                             // 0000000DEC80: 07137989
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000DEC84: BF870233
	.long 0xd4140006                                           // 0000000DEC88: D4140006
	v_cndmask_b32_e32 v1, 0xc2fc0000, v136, vcc_lo             // 0000000DEC8C: 020310FF C2FC0000
	v_cndmask_b32_e64 v188, 0, 0xffffffc0, s5                  // 0000000DEC94: D50100BC 0015FE80 FFFFFFC0
	.long 0xd71c0092                                           // 0000000DECA0: D71C0092
	v_cndmask_b32_e32 v1, v146, v191, vcc_lo                   // 0000000DECA4: 02037F92
	v_exp_f32_e32 v137, v137                                   // 0000000DECA8: 7F124B89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DECAC: BF8701A3
	v_cndmask_b32_e64 v189, 0, 0x42800000, s6                  // 0000000DECB0: D50100BD 0019FE80 42800000
	v_sub_f32_e32 v135, v135, v131                             // 0000000DECBC: 090F0787
	.long 0xd59c08b7                                           // 0000000DECC0: D59C08B7
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 0000000DECC4: 02010192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DECC8: BF870193
	v_add_f32_e32 v136, v136, v189                             // 0000000DECCC: 07117B88
	.long 0xd4140002                                           // 0000000DECD0: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v135, vcc_lo             // 0000000DECD4: 02030EFF C2FC0000
	v_cndmask_b32_e64 v189, 0, 0xffffffc0, s6                  // 0000000DECDC: D50100BD 0019FE80 FFFFFFC0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DECE8: BF870215
	.long 0xd71c0089                                           // 0000000DECEC: D71C0089
	v_cndmask_b32_e32 v1, v137, v188, vcc_lo                   // 0000000DECF0: 02037989
	v_exp_f32_e32 v136, v136                                   // 0000000DECF4: 7F104B88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DECF8: BF870093
	v_cndmask_b32_e64 v186, 0, 0x42800000, s2                  // 0000000DECFC: D50100BA 0009FE80 42800000
	v_dual_sub_f32 v134, v134, v131 :: v_dual_add_f32 v135, v135, v186// 0000000DED08: C9490786 86877587
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000000DED10: BF8702A1
	.long 0xd4140004                                           // 0000000DED14: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v134, vcc_lo             // 0000000DED18: 02030CFF C2FC0000
	v_cndmask_b32_e64 v186, 0, 0xffffffc0, s2                  // 0000000DED20: D50100BA 0009FE80 FFFFFFC0
	.long 0xd71c0088                                           // 0000000DED2C: D71C0088
	v_cndmask_b32_e32 v1, v136, v189, vcc_lo                   // 0000000DED30: 02037B88
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DED34: BF870194
	v_exp_f32_e32 v135, v135                                   // 0000000DED38: 7F0E4B87
	v_cndmask_b32_e64 v187, 0, 0x42800000, s4                  // 0000000DED3C: D50100BB 0011FE80 42800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DED48: BF870112
	.long 0xd59c08b6                                           // 0000000DED4C: D59C08B6
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000DED50: 02010188
	v_add_f32_e32 v134, v134, v187                             // 0000000DED54: 070D7786
	v_cndmask_b32_e64 v187, 0, 0xffffffc0, s4                  // 0000000DED58: D50100BB 0011FE80 FFFFFFC0
	.long 0xd4140004                                           // 0000000DED64: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v178, vcc_lo             // 0000000DED68: 020364FF C2FC0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DED70: BF870294
	v_and_b32_e32 v182, 1, v182                                // 0000000DED74: 376D6C81
	.long 0xd71c0087                                           // 0000000DED78: D71C0087
	v_cndmask_b32_e32 v1, v135, v186, vcc_lo                   // 0000000DED7C: 02037587
	v_exp_f32_e32 v134, v134                                   // 0000000DED80: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DED84: BF870095
	.long 0xd71c0086                                           // 0000000DED88: D71C0086
	v_cndmask_b32_e32 v1, v134, v187, vcc_lo                   // 0000000DED8C: 02037786
	v_add_f32_e32 v184, v184, v134                             // 0000000DED90: 07710DB8
	.long 0xd59c08b5                                           // 0000000DED94: D59C08B5
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000DED98: 02010186
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DED9C: BF8701B2
	v_add_f32_e32 v184, v184, v135                             // 0000000DEDA0: 07710FB8
	v_and_b32_e32 v185, 1, v179                                // 0000000DEDA4: 37736681
	.long 0xd59c08b3                                           // 0000000DEDA8: D59C08B3
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000000DEDAC: 02010187
	v_dual_add_f32 v180, v184, v136 :: v_dual_and_b32 v181, 1, v181// 0000000DEDB0: C92511B8 B4B56A81
	v_and_b32_e32 v183, 1, v183                                // 0000000DEDB8: 376F6E81
	v_add3_u32 v136, v136, v182, 0x7fff                        // 0000000DEDBC: D6550088 03FF6D88 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000DEDC8: BF870003
	v_add3_u32 v181, v134, v181, 0x7fff                        // 0000000DEDCC: D65500B5 03FF6B86 00007FFF
	v_add3_u32 v133, v133, v185, 0x7fff                        // 0000000DEDD8: D6550085 03FF7385 00007FFF
	v_add_f32_e32 v180, v180, v137                             // 0000000DEDE4: 076913B4
	v_and_b32_e32 v186, 1, v179                                // 0000000DEDE8: 37756681
	.long 0xd59c08b3                                           // 0000000DEDEC: D59C08B3
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000DEDF0: 02010189
	v_add3_u32 v182, v146, v183, 0x7fff                        // 0000000DEDF4: D65500B6 03FF6F92 00007FFF
	.long 0xd59c0885                                           // 0000000DEE00: D59C0885
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 0000000DEE04: 02010184
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DEE08: BF870214
	v_add3_u32 v134, v135, v186, 0x7fff                        // 0000000DEE0C: D6550086 03FF7587 00007FFF
	v_and_b32_e32 v184, 1, v179                                // 0000000DEE18: 37716681
	.long 0xd59c08b3                                           // 0000000DEE1C: D59C08B3
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000000DEE20: 02010193
	.long 0xd59c0886                                           // 0000000DEE24: D59C0886
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000000DEE28: 020101B5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000000DEE2C: BF870253
	v_add3_u32 v135, v137, v184, 0x7fff                        // 0000000DEE30: D6550087 03FF7189 00007FFF
	v_dual_add_f32 v137, v180, v146 :: v_dual_sub_f32 v146, v150, v131// 0000000DEE3C: C90B25B4 89930796
	v_sub_f32_e32 v150, v151, v131                             // 0000000DEE44: 092D0797
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, s9                  // 0000000DEE48: D5010097 0025FE80 FFFFFFC0
	.long 0xd59c0887                                           // 0000000DEE54: D59C0887
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000DEE58: 02010188
	v_add_f32_e32 v137, v137, v147                             // 0000000DEE5C: 07132789
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v146                  // 0000000DEE60: 7C2924FF C2FC0000
	.long 0xd4140001                                           // 0000000DEE68: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v150, vcc_lo             // 0000000DEE6C: 02032CFF C2FC0000
	.long 0xd71c0095                                           // 0000000DEE74: D71C0095
	v_cndmask_b32_e32 v1, v149, v151, vcc_lo                   // 0000000DEE78: 02032F95
	v_cndmask_b32_e64 v180, 0, 0x42800000, vcc_lo              // 0000000DEE7C: D50100B4 01A9FE80 42800000
	v_and_b32_e32 v183, 1, v179                                // 0000000DEE88: 376F6681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DEE8C: BF870223
	.long 0xd59c08b3                                           // 0000000DEE90: D59C08B3
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 0000000DEE94: 02010195
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, vcc_lo              // 0000000DEE98: D5010097 01A9FE80 FFFFFFC0
	v_add_f32_e32 v146, v146, v180                             // 0000000DEEA4: 07256992
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DEEA8: BF870004
	v_add3_u32 v136, v147, v183, 0x7fff                        // 0000000DEEAC: D6550088 03FF6F93 00007FFF
	.long 0xd59c0888                                           // 0000000DEEB8: D59C0888
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 0000000DEEBC: 020101B6
	v_cndmask_b32_e64 v182, 0, 0x42800000, s1                  // 0000000DEEC0: D50100B6 0005FE80 42800000
	v_cndmask_b32_e64 v183, 0, 0xffffffc0, s10                 // 0000000DEECC: D50100B7 0029FE80 FFFFFFC0
	v_exp_f32_e32 v146, v146                                   // 0000000DEED8: 7F244B92
	v_and_b32_e32 v181, 1, v179                                // 0000000DEEDC: 376B6681
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, s1                  // 0000000DEEE0: D50100B4 0005FE80 FFFFFFC0
	v_add_f32_e32 v150, v150, v182                             // 0000000DEEEC: 072D6D96
	.long 0xd71c0094                                           // 0000000DEEF0: D71C0094
	v_cndmask_b32_e32 v1, v148, v183, vcc_lo                   // 0000000DEEF4: 02036F94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEEF8: BF870092
	v_exp_f32_e32 v147, v150                                   // 0000000DEEFC: 7F264B96
	.long 0xd59c0896                                           // 0000000DEF00: D59C0896
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 0000000DEF04: 02010194
	.long 0xd59c4896                                           // 0000000DEF08: D59C4896
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEF0C: 020101B3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000DEF10: BF870313
	v_add_f32_e32 v137, v137, v148                             // 0000000DEF14: 07132989
	.long 0xd71c0097                                           // 0000000DEF18: D71C0097
	v_cndmask_b32_e32 v1, v146, v151, vcc_lo                   // 0000000DEF1C: 02032F92
	v_add3_u32 v146, v149, v181, 0x7fff                        // 0000000DEF20: D6550092 03FF6B95 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DEF2C: BF870293
	v_dual_add_f32 v137, v137, v149 :: v_dual_and_b32 v150, 1, v150// 0000000DEF30: C9252B89 89972C81
	.long 0xd71c0093                                           // 0000000DEF38: D71C0093
	v_cndmask_b32_e32 v1, v147, v180, vcc_lo                   // 0000000DEF3C: 02036993
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DEF40: BF870224
	.long 0xd59c0895                                           // 0000000DEF44: D59C0895
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 0000000DEF48: 02010197
	.long 0xd59c4895                                           // 0000000DEF4C: D59C4895
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEF50: 020101B3
	v_add_f32_e32 v137, v137, v151                             // 0000000DEF54: 07132F89
	v_add3_u32 v132, v148, v150, 0x7fff                        // 0000000DEF58: D6550084 03FF2D94 00007FFF
	v_sub_f32_e32 v148, v153, v131                             // 0000000DEF64: 09290799
	.long 0xd59c08b3                                           // 0000000DEF68: D59C08B3
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000000DEF6C: 02010193
	v_and_b32_e32 v149, 1, v149                                // 0000000DEF70: 372B2A81
	v_add_f32_e32 v137, v137, v147                             // 0000000DEF74: 07132789
	.long 0xd59c0892                                           // 0000000DEF78: D59C0892
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 0000000DEF7C: 02010184
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v148                  // 0000000DEF80: 7C2928FF C2FC0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DEF88: BF8700A4
	v_add3_u32 v151, v151, v149, 0x7fff                        // 0000000DEF8C: D6550097 03FF2B97 00007FFF
	v_cndmask_b32_e64 v153, 0, 0x42800000, vcc_lo              // 0000000DEF98: D5010099 01A9FE80 42800000
	v_add_f32_e32 v148, v148, v153                             // 0000000DEFA4: 07293394
	v_cndmask_b32_e64 v153, 0, 0x42800000, s4                  // 0000000DEFA8: D5010099 0011FE80 42800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEFB4: BF870092
	v_exp_f32_e32 v148, v148                                   // 0000000DEFB8: 7F284B94
	v_add_f32_e32 v153, v178, v153                             // 0000000DEFBC: 073333B2
	v_cndmask_b32_e64 v178, 0, 0xffffffc0, vcc_lo              // 0000000DEFC0: D50100B2 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DEFCC: BF870002
	v_exp_f32_e32 v153, v153                                   // 0000000DEFD0: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000000DEFD4: BF870086
	.long 0xd71c0094                                           // 0000000DEFD8: D71C0094
	v_cndmask_b32_e32 v1, v148, v178, vcc_lo                   // 0000000DEFDC: 02036594
	v_sub_f32_e32 v150, v152, v131                             // 0000000DEFE0: 092D0798
	v_sub_f32_e32 v152, v177, v131                             // 0000000DEFE4: 093107B1
	.long 0xd59c48b2                                           // 0000000DEFE8: D59C48B2
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DEFEC: 020101B3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEFF0: BF870193
	.long 0xd4140001                                           // 0000000DEFF4: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v150, vcc_lo             // 0000000DEFF8: 02032CFF C2FC0000
	.long 0xd4140002                                           // 0000000DF000: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v152, vcc_lo             // 0000000DF004: 020330FF C2FC0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF00C: BF870112
	v_cndmask_b32_e64 v177, 0, 0x42800000, s1                  // 0000000DF010: D50100B1 0005FE80 42800000
	v_cndmask_b32_e64 v180, 0, 0x42800000, s2                  // 0000000DF01C: D50100B4 0009FE80 42800000
	v_cndmask_b32_e64 v181, 0, 0xffffffc0, s2                  // 0000000DF028: D50100B5 0009FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF034: BF870193
	v_add_f32_e32 v150, v150, v177                             // 0000000DF038: 072D6396
	v_add_f32_e32 v152, v152, v180                             // 0000000DF03C: 07316998
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, s1                  // 0000000DF040: D50100B4 0005FE80 FFFFFFC0
	v_and_b32_e32 v177, 1, v179                                // 0000000DF04C: 37636681
	.long 0xd59c08b3                                           // 0000000DF050: D59C08B3
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 0000000DF054: 02010194
	v_exp_f32_e32 v150, v150                                   // 0000000DF058: 7F2C4B96
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000000DF05C: BF8702A2
	v_add3_u32 v147, v147, v177, 0x7fff                        // 0000000DF060: D6550093 03FF6393 00007FFF
	.long 0xd59c0893                                           // 0000000DF06C: D59C0893
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 0000000DF070: 02010197
	.long 0xd71c0095                                           // 0000000DF074: D71C0095
	v_cndmask_b32_e32 v1, v150, v180, vcc_lo                   // 0000000DF078: 02036996
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, s4                  // 0000000DF07C: D5010096 0011FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF088: BF870112
	v_dual_add_f32 v137, v137, v149 :: v_dual_and_b32 v180, 1, v179// 0000000DF08C: C9252B89 89B56681
	.long 0xd71c0096                                           // 0000000DF094: D71C0096
	v_cndmask_b32_e32 v1, v153, v150, vcc_lo                   // 0000000DF098: 02032D99
	.long 0xd59c08b2                                           // 0000000DF09C: D59C08B2
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 0000000DF0A0: 02010195
	.long 0xd59c4899                                           // 0000000DF0A4: D59C4899
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000DF0A8: 020101B3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DF0AC: BF870214
	v_add_f32_e32 v137, v137, v148                             // 0000000DF0B0: 07132989
	.long 0xd59c08b3                                           // 0000000DF0B4: D59C08B3
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 0000000DF0B8: 02010196
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DF0BC: BF8701A4
	v_and_b32_e32 v178, 1, v178                                // 0000000DF0C0: 37656481
	v_add3_u32 v148, v148, v180, 0x7fff                        // 0000000DF0C4: D6550094 03FF6994 00007FFF
	v_and_b32_e32 v177, 1, v179                                // 0000000DF0D0: 37636681
	v_exp_f32_e32 v152, v152                                   // 0000000DF0D4: 7F304B98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF0D8: BF870113
	v_add3_u32 v178, v149, v178, 0x7fff                        // 0000000DF0DC: D65500B2 03FF6595 00007FFF
	v_add3_u32 v149, v150, v177, 0x7fff                        // 0000000DF0E8: D6550095 03FF6396 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DF0F4: BF870292
	.long 0xd59c0894                                           // 0000000DF0F8: D59C0894
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 0000000DF0FC: 020101B2
	.long 0xd71c0098                                           // 0000000DF100: D71C0098
	v_cndmask_b32_e32 v1, v152, v181, vcc_lo                   // 0000000DF104: 02036B98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF108: BF870111
	.long 0xd59c0899                                           // 0000000DF10C: D59C0899
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 0000000DF110: 02010198
	v_add_f32_e32 v137, v137, v152                             // 0000000DF114: 07133189
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF118: BF870091
	v_dual_add_f32 v132, v137, v150 :: v_dual_and_b32 v153, 1, v153// 0000000DF11C: C9252D89 84993281
	v_add3_u32 v153, v152, v153, 0x7fff                        // 0000000DF124: D6550099 03FF3398 00007FFF
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DF130: BF870001
	.long 0xd59c0895                                           // 0000000DF134: D59C0895
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 0000000DF138: 02010199
	ds_store_b128 v165, v[133:136]                             // 0000000DF13C: DB7C0000 000085A5
	ds_store_b128 v165, v[146:149] offset:16                   // 0000000DF144: DB7C0010 000092A5
	v_mov_b32_e32 v133, 0                                      // 0000000DF14C: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 0000000DF150: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 0000000DF154: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 0000000DF158: 7D2304FF EFA18F08
	s_cbranch_execz 15                                         // 0000000DF160: BFA5000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x28a0>
	v_sub_f32_e32 v130, v130, v131                             // 0000000DF164: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF168: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v130                  // 0000000DF16C: 7C2904FF C2FC0000
	v_cndmask_b32_e64 v133, 0, 0x42800000, vcc_lo              // 0000000DF174: D5010085 01A9FE80 42800000
	v_add_f32_e32 v130, v130, v133                             // 0000000DF180: 07050B82
	v_cndmask_b32_e64 v133, 0, 0xffffffc0, vcc_lo              // 0000000DF184: D5010085 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DF190: BF870292
	v_exp_f32_e32 v130, v130                                   // 0000000DF194: 7F044B82
	.long 0xd71c0085                                           // 0000000DF198: D71C0085
	v_cndmask_b32_e32 v1, v130, v133, vcc_lo                   // 0000000DF19C: 02030B82
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DF1A0: 8C7E017E
	ds_load_b32 v130, v0                                       // 0000000DF1A4: D8D80000 82000000
	s_waitcnt lgkmcnt(0)                                       // 0000000DF1AC: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 0000000DF1B0: 57090585
	ds_store_b32 v163, v131                                    // 0000000DF1B4: D8340000 000083A3
	ds_store_b32 v0, v132                                      // 0000000DF1BC: D8340000 00008400
	ds_store_b32 v166, v133                                    // 0000000DF1C4: D8340000 000085A6
	s_or_b32 exec_lo, exec_lo, s12                             // 0000000DF1CC: 8C7E0C7E
	ds_load_2addr_b32 v[152:153], v167 offset1:2               // 0000000DF1D0: D8DC0200 980000A7
	ds_load_2addr_b32 v[150:151], v167 offset0:4 offset1:6     // 0000000DF1D8: D8DC0604 960000A7
	ds_load_2addr_b32 v[148:149], v167 offset0:8 offset1:10    // 0000000DF1E0: D8DC0A08 940000A7
	ds_load_2addr_b32 v[146:147], v167 offset0:12 offset1:14   // 0000000DF1E8: D8DC0E0C 920000A7
	s_waitcnt lgkmcnt(3)                                       // 0000000DF1F0: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 0000000DF1F4: 7C2530F2
	.long 0xd4120001                                           // 0000000DF1F8: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000000DF1FC: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 0000000DF200: BF89FC27
	.long 0xd4120002                                           // 0000000DF204: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000DF208: 02032CF2
	.long 0xd4120004                                           // 0000000DF20C: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 0000000DF210: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000DF214: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000DF218: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 0000000DF21C: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 0000000DF220: 8B020201
	.long 0xd4120001                                           // 0000000DF224: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000000DF228: 02032AF2
	s_and_b32 s4, s2, s4                                       // 0000000DF22C: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000DF230: BF89FC07
	.long 0xd4120002                                           // 0000000DF234: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 0000000DF238: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000DF23C: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 0000000DF240: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 0000000DF244: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DF248: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000DF24C: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000DF250: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF254: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000DF258: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 0000000DF260: 7C9B0480
	ds_load_b128 v[130:133], v168                              // 0000000DF264: DBFC0000 820000A8
	ds_load_b128 v[134:137], v168 offset:16                    // 0000000DF26C: DBFC0010 860000A8
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 0000000DF274: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000DF278: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF27C: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 0000000DF280: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 0000000DF288: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 0000000DF28C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000DF290: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DF294: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000DF298: 8B6A017E
	s_cbranch_vccnz 63349                                      // 0000000DF29C: BFA4F775 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 0000000DF2A0: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 0000000DF2A8: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 0000000DF2B0: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 0000000DF2B8: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 0000000DF2C0: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 0000000DF2C8: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 0000000DF2D0: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 0000000DF2D8: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 0000000DF2E0: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 0000000DF2E8: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 0000000DF2F0: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 0000000DF2F8: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 0000000DF300: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 0000000DF308: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 0000000DF310: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 0000000DF318: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 0000000DF320: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 0000000DF328: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 0000000DF330: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 0000000DF338: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 0000000DF340: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 0000000DF348: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 0000000DF350: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 0000000DF358: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 0000000DF360: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 0000000DF368: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 0000000DF370: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 0000000DF378: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 0000000DF380: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 0000000DF388: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 0000000DF390: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 0000000DF398: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 0000000DF3A0: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 0000000DF3A8: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 0000000DF3B0: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 0000000DF3B8: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 0000000DF3C0: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 0000000DF3C8: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 0000000DF3D0: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 0000000DF3D8: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 0000000DF3E0: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 0000000DF3E8: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 0000000DF3F0: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 0000000DF3F8: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 0000000DF400: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 0000000DF408: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 0000000DF410: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 0000000DF418: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 0000000DF420: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 0000000DF428: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 0000000DF430: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 0000000DF438: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 0000000DF440: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 0000000DF448: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 0000000DF450: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 0000000DF458: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 0000000DF460: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 0000000DF468: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 0000000DF470: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 0000000DF478: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 0000000DF480: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 0000000DF488: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 0000000DF490: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 0000000DF498: C8C60F92 07081193
	s_branch 63220                                             // 0000000DF4A0: BFA0F6F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_lshlrev_b32_e32 v0, 2, v157                              // 0000000DF4A4: 30013A82
	.long 0xd700008b                                           // 0000000DF4A8: D700008B
	v_cndmask_b32_e32 v1, s22, v139, vcc_lo                    // 0000000DF4AC: 02031616
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF4B0: BF870191
	v_add_co_ci_u32_e64 v140, null, s23, v140, s0              // 0000000DF4B4: D5207C8C 00031817
	v_lshl_or_b32 v0, v155, 6, v0                              // 0000000DF4BC: D6560000 04010D9B
	v_lshlrev_b32_e32 v147, 1, v154                            // 0000000DF4C4: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000DF4C8: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 0000000DF4CC: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 0000000DF4D4: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000DF4DC: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000DF4E0: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000DF4E8: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000DF4F0: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000DF4F4: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000DF4F8: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000DF500: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 0000000DF504: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 0000000DF50C: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 0000000DF514: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000DF51C: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000DF520: 3505029F
	v_or_b32_e32 v0, v156, v157                                // 0000000DF524: 38013B9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF528: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 0000000DF52C: 11252191
	.long 0xd73c0083                                           // 0000000DF530: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000DF534: 02030281
	.long 0xd7000081                                           // 0000000DF538: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000DF53C: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DF540: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000DF544: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000000DF54C: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF554: BF870094
	.long 0xd7000083                                           // 0000000DF558: D7000083
	v_cndmask_b32_e32 v1, s20, v131, vcc_lo                    // 0000000DF55C: 02030614
	v_add_co_ci_u32_e64 v132, null, s21, v132, s0              // 0000000DF560: D5207C84 00030815
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DF568: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000000DF56C: 57252194
	.long 0xd4440000                                           // 0000000DF570: D4440000
	v_cndmask_b32_e32 v1, s18, v0, vcc_lo                      // 0000000DF574: 02020012
	v_fma_f32 v139, -v143, v146, v145                          // 0000000DF578: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF580: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000DF584: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000DF58C: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000DF590: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000DF594: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000DF59C: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000DF5A0: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000DF5A8: BE812000
	s_cbranch_execz 70                                         // 0000000DF5AC: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc8>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF5B0: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000DF5B4: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000DF5C0: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000DF5C4: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000DF5CC: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000DF5D0: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF5D4: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000DF5D8: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000DF5E0: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000DF5EC: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF5F0: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000DF5F4: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000DF5FC: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DF600: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000DF604: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DF608: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000DF60C: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000DF614: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF618: BF870095
	.long 0xd71c008d                                           // 0000000DF61C: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000DF620: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000DF624: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000DF628: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF630: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000DF634: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000DF63C: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF640: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000DF644: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000DF64C: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF650: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000DF654: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DF65C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000DF660: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF668: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DF66C: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000DF670: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF678: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DF67C: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000DF680: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF688: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000DF68C: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000DF694: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000DF69C: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF6A8: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000DF6AC: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000DF6B4: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000DF6C0: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000DF6C8: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000DF6CC: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000DF6D4: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DF6DC: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000DF6E0: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000DF6E4: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF6EC: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000DF6F0: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000DF6F4: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF6F8: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000DF6FC: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000DF704: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF708: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000DF70C: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000DF714: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000DF71C: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF720: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000DF724: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000DF72C: D4440001
	v_cndmask_b32_e32 v1, s18, v121, vcc_lo                    // 0000000DF730: 0202F212
	s_and_saveexec_b32 s2, s1                                  // 0000000DF734: BE822001
	s_cbranch_execz 69                                         // 0000000DF738: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f50>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000DF73C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000DF748: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DF74C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DF754: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DF758: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF75C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DF760: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DF768: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DF774: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DF778: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DF77C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DF780: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DF788: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DF790: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DF794: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DF798: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DF79C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7A0: BF870095
	.long 0xd71c008e                                           // 0000000DF7A4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DF7A8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DF7AC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DF7B0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7B8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DF7BC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DF7C4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7C8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000DF7CC: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DF7D4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7D8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DF7DC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DF7E4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000DF7E8: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7F0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DF7F4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DF7F8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF800: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DF804: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DF808: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF810: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DF814: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000DF81C: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000DF824: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF830: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000DF834: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000DF83C: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000DF848: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000DF850: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000DF854: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000DF858: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000DF860: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DF868: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000DF86C: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000DF870: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF878: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000DF87C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000DF880: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF884: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000DF888: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000DF890: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF894: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000DF898: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000DF8A0: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000DF8A8: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DF8AC: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000DF8B0: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000DF8B8: D4440002
	v_cndmask_b32_e32 v1, s18, v122, vcc_lo                    // 0000000DF8BC: 0202F412
	s_and_saveexec_b32 s3, s2                                  // 0000000DF8C0: BE832002
	s_cbranch_execz 69                                         // 0000000DF8C4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30dc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000DF8C8: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000DF8D4: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DF8D8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DF8E0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DF8E4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF8E8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DF8EC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DF8F4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DF900: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DF904: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DF908: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DF90C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DF914: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DF91C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DF920: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DF924: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DF928: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF92C: BF870095
	.long 0xd71c008e                                           // 0000000DF930: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DF934: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DF938: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DF93C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF944: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DF948: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DF950: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF954: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000DF958: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DF960: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF964: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DF968: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DF970: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000DF974: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF97C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DF980: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DF984: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF98C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DF990: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DF994: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF99C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DF9A0: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000DF9A8: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000DF9B0: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF9BC: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000DF9C0: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000DF9C8: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000DF9D4: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000DF9DC: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000DF9E0: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000DF9E8: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DF9F0: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000DF9F4: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000DF9F8: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFA00: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000DFA04: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000DFA08: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFA0C: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000DFA10: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000DFA18: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFA1C: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000DFA20: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000DFA28: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000DFA30: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DFA34: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000DFA38: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000DFA40: D4440003
	v_cndmask_b32_e32 v1, s18, v123, vcc_lo                    // 0000000DFA44: 0202F612
	s_and_saveexec_b32 s4, s3                                  // 0000000DFA48: BE842003
	s_cbranch_execz 69                                         // 0000000DFA4C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3264>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000DFA50: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000DFA5C: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DFA60: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DFA68: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DFA6C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFA70: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DFA74: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DFA7C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DFA88: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DFA8C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DFA90: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DFA94: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DFA9C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DFAA4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DFAA8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DFAAC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DFAB0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFAB4: BF870095
	.long 0xd71c008e                                           // 0000000DFAB8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DFABC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DFAC0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DFAC4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFACC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DFAD0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DFAD8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFADC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000DFAE0: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DFAE8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFAEC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DFAF0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DFAF8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000DFAFC: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB04: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DFB08: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DFB0C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB14: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DFB18: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DFB1C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB24: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DFB28: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000DFB30: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000DFB38: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB44: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000DFB48: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000DFB50: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000DFB5C: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DFB64: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000DFB68: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000DFB6C: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000DFB74: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DFB7C: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000DFB80: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000DFB84: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB8C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000DFB90: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000DFB94: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFB98: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000DFB9C: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000DFBA4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFBA8: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000DFBAC: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000DFBB4: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000DFBBC: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DFBC0: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000DFBC4: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000DFBCC: D4440004
	v_cndmask_b32_e32 v1, s18, v124, vcc_lo                    // 0000000DFBD0: 0202F812
	s_and_saveexec_b32 s5, s4                                  // 0000000DFBD4: BE852004
	s_cbranch_execz 69                                         // 0000000DFBD8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000DFBDC: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000DFBE8: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DFBEC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DFBF4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DFBF8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFBFC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DFC00: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DFC08: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DFC14: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DFC18: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DFC1C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DFC20: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DFC28: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DFC30: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DFC34: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DFC38: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DFC3C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFC40: BF870095
	.long 0xd71c008e                                           // 0000000DFC44: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DFC48: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DFC4C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DFC50: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFC58: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DFC5C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DFC64: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFC68: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000DFC6C: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DFC74: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFC78: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DFC7C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DFC84: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000DFC88: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFC90: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DFC94: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DFC98: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFCA0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DFCA4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DFCA8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFCB0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DFCB4: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000DFCBC: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000DFCC4: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFCD0: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000DFCD4: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000DFCDC: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000DFCE8: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000DFCF0: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000DFCF4: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000DFCFC: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DFD04: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000DFD08: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000DFD0C: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFD14: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000DFD18: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000DFD1C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFD20: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000DFD24: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000DFD2C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFD30: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000DFD34: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000DFD3C: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000DFD44: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DFD48: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000DFD4C: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000DFD54: D4440005
	v_cndmask_b32_e32 v1, s18, v125, vcc_lo                    // 0000000DFD58: 0202FA12
	s_and_saveexec_b32 s6, s5                                  // 0000000DFD5C: BE862005
	s_cbranch_execz 69                                         // 0000000DFD60: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3578>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000DFD64: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000DFD70: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DFD74: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DFD7C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DFD80: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFD84: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DFD88: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DFD90: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DFD9C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DFDA0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DFDA4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DFDA8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DFDB0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DFDB8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DFDBC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DFDC0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DFDC4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFDC8: BF870095
	.long 0xd71c008e                                           // 0000000DFDCC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DFDD0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DFDD4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DFDD8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFDE0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DFDE4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DFDEC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFDF0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000DFDF4: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DFDFC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE00: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DFE04: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DFE0C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000DFE10: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE18: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DFE1C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DFE20: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE28: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DFE2C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DFE30: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE38: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DFE3C: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000DFE44: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000DFE4C: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE58: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000DFE5C: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000DFE64: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000DFE70: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000DFE78: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000DFE7C: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000DFE80: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000DFE88: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DFE90: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000DFE94: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000DFE98: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFEA0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000DFEA4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000DFEA8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFEAC: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000DFEB0: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000DFEB8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFEBC: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000DFEC0: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000DFEC8: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000DFED0: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DFED4: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000DFED8: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000DFEE0: D4440006
	v_cndmask_b32_e32 v1, s18, v126, vcc_lo                    // 0000000DFEE4: 0202FC12
	s_and_saveexec_b32 s7, s6                                  // 0000000DFEE8: BE872006
	s_cbranch_execz 69                                         // 0000000DFEEC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3704>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000DFEF0: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000DFEFC: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000DFF00: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000DFF08: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000DFF0C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFF10: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000DFF14: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000DFF1C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000DFF28: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000DFF2C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000DFF30: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000DFF34: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000DFF3C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DFF44: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000DFF48: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000DFF4C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000DFF50: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFF54: BF870095
	.long 0xd71c008e                                           // 0000000DFF58: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000DFF5C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000DFF60: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000DFF64: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFF6C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000DFF70: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000DFF78: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFF7C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000DFF80: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000DFF88: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFF8C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000DFF90: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000DFF98: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000DFF9C: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFFA4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000DFFA8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000DFFAC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFFB4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000DFFB8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000DFFBC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFFC4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000DFFC8: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000DFFD0: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000DFFD8: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFFE4: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000DFFE8: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000DFFF0: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000DFFFC: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000E0004: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000E0008: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000E0010: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E0018: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000E001C: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000E0020: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0028: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000E002C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000E0030: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0034: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000E0038: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000E0040: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0044: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000E0048: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000E0050: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000E0058: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E005C: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000E0060: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000E0068: D4440007
	v_cndmask_b32_e32 v1, s18, v127, vcc_lo                    // 0000000E006C: 0202FE12
	s_and_saveexec_b32 s8, s7                                  // 0000000E0070: BE882007
	s_cbranch_execnz 363                                       // 0000000E0074: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0078: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E007C: BE882000
	s_cbranch_execnz 432                                       // 0000000E0080: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0084: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0088: BE882001
	s_cbranch_execnz 501                                       // 0000000E008C: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f64>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0090: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0094: BE882002
	s_cbranch_execnz 570                                       // 0000000E0098: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4084>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E009C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E00A0: BE882003
	s_cbranch_execnz 639                                       // 0000000E00A4: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E00AC: BE882004
	s_cbranch_execnz 708                                       // 0000000E00B0: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00B4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E00B8: BE882005
	s_cbranch_execnz 777                                       // 0000000E00BC: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E00C4: BE882006
	s_cbranch_execnz 846                                       // 0000000E00C8: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4504>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00CC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E00D0: BE882007
	s_cbranch_execnz 915                                       // 0000000E00D4: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4624>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00D8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E00DC: BE882000
	s_cbranch_execnz 984                                       // 0000000E00E0: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4744>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00E4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E00E8: BE882001
	s_cbranch_execnz 1053                                      // 0000000E00EC: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4864>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00F0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E00F4: BE882002
	s_cbranch_execnz 1122                                      // 0000000E00F8: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4984>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E00FC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0100: BE882003
	s_cbranch_execnz 1191                                      // 0000000E0104: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4aa4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0108: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E010C: BE882004
	s_cbranch_execnz 1260                                      // 0000000E0110: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0114: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0118: BE882005
	s_cbranch_execnz 1329                                      // 0000000E011C: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ce4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0120: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0124: BE882006
	s_cbranch_execnz 1398                                      // 0000000E0128: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e04>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E012C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0130: BE882007
	s_cbranch_execnz 1467                                      // 0000000E0134: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0138: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E013C: BE882000
	s_cbranch_execnz 1536                                      // 0000000E0140: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5044>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0144: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0148: BE882001
	s_cbranch_execnz 1605                                      // 0000000E014C: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5164>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0150: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0154: BE882002
	s_cbranch_execnz 1674                                      // 0000000E0158: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5284>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E015C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0160: BE882003
	s_cbranch_execnz 1743                                      // 0000000E0164: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0168: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E016C: BE882004
	s_cbranch_execnz 1812                                      // 0000000E0170: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0174: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0178: BE882005
	s_cbranch_execnz 1881                                      // 0000000E017C: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0180: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0184: BE882006
	s_cbranch_execnz 1950                                      // 0000000E0188: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5704>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E018C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0190: BE882007
	s_cbranch_execnz 2019                                      // 0000000E0194: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5824>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0198: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E019C: BE882000
	s_cbranch_execnz 2088                                      // 0000000E01A0: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5944>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01A4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E01A8: BE882001
	s_cbranch_execnz 2157                                      // 0000000E01AC: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a64>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E01B4: BE882002
	s_cbranch_execnz 2226                                      // 0000000E01B8: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b84>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01BC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E01C0: BE882003
	s_cbranch_execnz 2295                                      // 0000000E01C4: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ca4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01C8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E01CC: BE882004
	s_cbranch_execnz 2364                                      // 0000000E01D0: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01D4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E01D8: BE882005
	s_cbranch_execnz 2433                                      // 0000000E01DC: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ee4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01E0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E01E4: BE882006
	s_cbranch_execnz 2502                                      // 0000000E01E8: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6004>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E01F0: BE882007
	s_cbranch_execnz 2571                                      // 0000000E01F4: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6124>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E01F8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E01FC: BE882000
	s_cbranch_execnz 2640                                      // 0000000E0200: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6244>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0204: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0208: BE882001
	s_cbranch_execnz 2709                                      // 0000000E020C: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6364>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0210: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0214: BE882002
	s_cbranch_execnz 2778                                      // 0000000E0218: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6484>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E021C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0220: BE882003
	s_cbranch_execnz 2847                                      // 0000000E0224: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0228: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E022C: BE882004
	s_cbranch_execnz 2916                                      // 0000000E0230: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0234: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0238: BE882005
	s_cbranch_execnz 2985                                      // 0000000E023C: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0240: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0244: BE882006
	s_cbranch_execnz 3054                                      // 0000000E0248: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6904>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E024C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0250: BE882007
	s_cbranch_execnz 3123                                      // 0000000E0254: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0258: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E025C: BE882000
	s_cbranch_execnz 3192                                      // 0000000E0260: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0264: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0268: BE882001
	s_cbranch_execnz 3261                                      // 0000000E026C: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c64>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0270: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0274: BE882002
	s_cbranch_execnz 3330                                      // 0000000E0278: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d84>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E027C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0280: BE882003
	s_cbranch_execnz 3399                                      // 0000000E0284: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ea4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0288: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E028C: BE882004
	s_cbranch_execnz 3468                                      // 0000000E0290: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0294: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0298: BE882005
	s_cbranch_execnz 3537                                      // 0000000E029C: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02A0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E02A4: BE882006
	s_cbranch_execnz 3606                                      // 0000000E02A8: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7204>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E02B0: BE882007
	s_cbranch_execnz 3675                                      // 0000000E02B4: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7324>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02B8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E02BC: BE882000
	s_cbranch_execnz 3744                                      // 0000000E02C0: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7444>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02C4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E02C8: BE882001
	s_cbranch_execnz 3813                                      // 0000000E02CC: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7564>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02D0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E02D4: BE882002
	s_cbranch_execnz 3882                                      // 0000000E02D8: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7684>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02DC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E02E0: BE882003
	s_cbranch_execnz 3951                                      // 0000000E02E4: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02E8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E02EC: BE882004
	s_cbranch_execnz 4020                                      // 0000000E02F0: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E02F4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E02F8: BE882005
	s_cbranch_execnz 4089                                      // 0000000E02FC: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0300: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0304: BE882006
	s_cbranch_execnz 4158                                      // 0000000E0308: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b04>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E030C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0310: BE882007
	s_cbranch_execnz 4227                                      // 0000000E0314: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0318: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E031C: BE882000
	s_cbranch_execnz 4296                                      // 0000000E0320: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0324: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0328: BE882001
	s_cbranch_execnz 4365                                      // 0000000E032C: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e64>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0330: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0334: BE882002
	s_cbranch_execnz 4434                                      // 0000000E0338: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f84>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E033C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0340: BE882003
	s_cbranch_execnz 4503                                      // 0000000E0344: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0348: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E034C: BE882004
	s_cbranch_execnz 4572                                      // 0000000E0350: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0354: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0358: BE882005
	s_cbranch_execnz 4641                                      // 0000000E035C: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0360: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0364: BE882006
	s_cbranch_execnz 4710                                      // 0000000E0368: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8404>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E036C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0370: BE882007
	s_cbranch_execnz 4779                                      // 0000000E0374: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8524>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0378: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E037C: BE882000
	s_cbranch_execnz 4848                                      // 0000000E0380: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8644>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0384: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0388: BE882001
	s_cbranch_execnz 4917                                      // 0000000E038C: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8764>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0390: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0394: BE882002
	s_cbranch_execnz 4986                                      // 0000000E0398: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8884>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E039C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E03A0: BE882003
	s_cbranch_execnz 5055                                      // 0000000E03A4: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E03AC: BE882004
	s_cbranch_execnz 5124                                      // 0000000E03B0: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ac4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03B4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E03B8: BE882005
	s_cbranch_execnz 5193                                      // 0000000E03BC: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8be4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E03C4: BE882006
	s_cbranch_execnz 5262                                      // 0000000E03C8: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d04>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03CC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E03D0: BE882007
	s_cbranch_execnz 5331                                      // 0000000E03D4: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03D8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E03DC: BE882000
	s_cbranch_execnz 5400                                      // 0000000E03E0: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03E4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E03E8: BE882001
	s_cbranch_execnz 5469                                      // 0000000E03EC: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9064>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03F0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E03F4: BE882002
	s_cbranch_execnz 5538                                      // 0000000E03F8: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9184>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E03FC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0400: BE882003
	s_cbranch_execnz 5607                                      // 0000000E0404: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0408: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E040C: BE882004
	s_cbranch_execnz 5676                                      // 0000000E0410: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0414: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0418: BE882005
	s_cbranch_execnz 5745                                      // 0000000E041C: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0420: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0424: BE882006
	s_cbranch_execnz 5814                                      // 0000000E0428: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9604>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E042C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0430: BE882007
	s_cbranch_execnz 5883                                      // 0000000E0434: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9724>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0438: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E043C: BE882000
	s_cbranch_execnz 5952                                      // 0000000E0440: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9844>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0444: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0448: BE882001
	s_cbranch_execnz 6021                                      // 0000000E044C: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9964>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0450: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0454: BE882002
	s_cbranch_execnz 6090                                      // 0000000E0458: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a84>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E045C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0460: BE882003
	s_cbranch_execnz 6159                                      // 0000000E0464: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ba4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0468: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E046C: BE882004
	s_cbranch_execnz 6228                                      // 0000000E0470: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0474: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0478: BE882005
	s_cbranch_execnz 6297                                      // 0000000E047C: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9de4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0480: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0484: BE882006
	s_cbranch_execnz 6366                                      // 0000000E0488: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f04>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E048C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0490: BE882007
	s_cbranch_execnz 6435                                      // 0000000E0494: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa024>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0498: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E049C: BE882000
	s_cbranch_execnz 6504                                      // 0000000E04A0: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa144>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04A4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E04A8: BE882001
	s_cbranch_execnz 6573                                      // 0000000E04AC: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa264>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E04B4: BE882002
	s_cbranch_execnz 6642                                      // 0000000E04B8: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa384>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04BC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E04C0: BE882003
	s_cbranch_execnz 6711                                      // 0000000E04C4: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04C8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E04CC: BE882004
	s_cbranch_execnz 6780                                      // 0000000E04D0: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04D4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E04D8: BE882005
	s_cbranch_execnz 6849                                      // 0000000E04DC: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04E0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E04E4: BE882006
	s_cbranch_execnz 6918                                      // 0000000E04E8: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa804>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E04F0: BE882007
	s_cbranch_execnz 6987                                      // 0000000E04F4: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa924>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E04F8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E04FC: BE882000
	s_cbranch_execnz 7056                                      // 0000000E0500: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0504: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0508: BE882001
	s_cbranch_execnz 7125                                      // 0000000E050C: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab64>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0510: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0514: BE882002
	s_cbranch_execnz 7194                                      // 0000000E0518: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac84>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E051C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0520: BE882003
	s_cbranch_execnz 7263                                      // 0000000E0524: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xada4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0528: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E052C: BE882004
	s_cbranch_execnz 7332                                      // 0000000E0530: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaec4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0534: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0538: BE882005
	s_cbranch_execnz 7401                                      // 0000000E053C: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xafe4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0540: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0544: BE882006
	s_cbranch_execnz 7470                                      // 0000000E0548: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb104>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E054C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0550: BE882007
	s_cbranch_execnz 7539                                      // 0000000E0554: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb224>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0558: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E055C: BE882000
	s_cbranch_execnz 7608                                      // 0000000E0560: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb344>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0564: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E0568: BE882001
	s_cbranch_execnz 7677                                      // 0000000E056C: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb464>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0570: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E0574: BE882002
	s_cbranch_execnz 7746                                      // 0000000E0578: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb584>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E057C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0580: BE882003
	s_cbranch_execnz 7815                                      // 0000000E0584: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0588: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E058C: BE882004
	s_cbranch_execnz 7884                                      // 0000000E0590: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0594: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0598: BE882005
	s_cbranch_execnz 7953                                      // 0000000E059C: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E05A0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E05A4: BE882006
	s_cbranch_execnz 8022                                      // 0000000E05A8: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba04>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E05AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E05B0: BE882007
	s_cbranch_execnz 8091                                      // 0000000E05B4: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb24>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E05B8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E05BC: BE882000
	s_cbranch_execnz 8160                                      // 0000000E05C0: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc44>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E05C4: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000E05C8: BE802001
	s_cbranch_execnz 8229                                      // 0000000E05CC: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd64>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E05D0: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000E05D4: BE802002
	s_cbranch_execnz 8298                                      // 0000000E05D8: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe84>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E05DC: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000E05E0: BE802003
	s_cbranch_execnz 8367                                      // 0000000E05E4: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfa4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E05E8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000E05EC: BE802004
	s_cbranch_execnz 8436                                      // 0000000E05F0: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0c4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E05F4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000E05F8: BE802005
	s_cbranch_execnz 8505                                      // 0000000E05FC: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1e4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E0600: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000E0604: BE802006
	s_cbranch_execnz 8574                                      // 0000000E0608: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc304>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E060C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000E0610: BE802007
	s_cbranch_execnz 8643                                      // 0000000E0614: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc424>
	s_nop 0                                                    // 0000000E0618: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000E061C: BFB60003
	s_endpgm                                                   // 0000000E0620: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000E0624: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000E0630: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000E0634: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000E063C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000E0640: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0644: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000E0648: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000E0650: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000E065C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0660: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000E0664: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000E0668: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000E0670: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0678: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000E067C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000E0680: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000E0684: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0688: BF870095
	.long 0xd71c008e                                           // 0000000E068C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000E0690: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000E0694: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000E0698: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06A0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000E06A4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000E06AC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06B0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000E06B4: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000E06BC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06C0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000E06C4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000E06CC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000E06D0: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06D8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000E06DC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000E06E0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06E8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000E06EC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000E06F0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E06F8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000E06FC: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000E0704: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000E070C: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0718: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000E071C: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000E0724: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000E0730: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0738: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E073C: BE882000
	s_cbranch_execz 65104                                      // 0000000E0740: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000E0744: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000E0750: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000E0754: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000E075C: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000E0760: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0764: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000E0768: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000E0770: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000E077C: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0780: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000E0784: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000E0788: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000E0790: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0798: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000E079C: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000E07A0: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000E07A4: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E07A8: BF870095
	.long 0xd71c008d                                           // 0000000E07AC: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000E07B0: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000E07B4: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000E07B8: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E07C0: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000E07C4: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000E07CC: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E07D0: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000E07D4: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000E07DC: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E07E0: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000E07E4: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000E07EC: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000E07F0: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E07F8: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000E07FC: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000E0800: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0808: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000E080C: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000E0810: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0818: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000E081C: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000E0824: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000E082C: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0838: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000E083C: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000E0844: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000E0850: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0858: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E085C: BE882001
	s_cbranch_execz 65035                                      // 0000000E0860: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000E0864: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000E0870: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000E0874: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000E087C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0880: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0884: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000E0888: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000E0890: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000E089C: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E08A0: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000E08A4: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E08A8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000E08B0: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E08B8: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000E08BC: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000E08C0: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000E08C4: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E08C8: BF870095
	.long 0xd71c0080                                           // 0000000E08CC: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000E08D0: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000E08D4: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E08D8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E08E0: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000E08E4: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E08EC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E08F0: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000E08F4: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000E08FC: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0900: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000E0904: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000E090C: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000E0910: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0918: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000E091C: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000E0920: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0928: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000E092C: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000E0930: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0938: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000E093C: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000E0944: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000E094C: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0958: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000E095C: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000E0964: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000E0970: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0978: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E097C: BE882002
	s_cbranch_execz 64966                                      // 0000000E0980: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000E0984: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0990: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0998: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E099C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E09A0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E09A4: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000E09AC: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000E09B8: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E09BC: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000E09C0: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000E09C8: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000E09CC: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000E09D0: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000E09D4: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E09D8: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000E09E0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E09E4: BF870095
	.long 0xd71c0072                                           // 0000000E09E8: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000E09EC: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E09F0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E09F4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E09FC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000E0A00: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E0A0C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A10: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0A14: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000E0A1C: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A20: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000E0A24: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000E0A2C: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000E0A30: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A38: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000E0A3C: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000E0A40: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A48: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000E0A4C: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000E0A50: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A58: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000E0A5C: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E0A64: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000E0A6C: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0A78: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000E0A7C: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000E0A84: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E0A90: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0A98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E0A9C: BE882003
	s_cbranch_execz 64897                                      // 0000000E0AA0: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000E0AA4: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0AB0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0AB8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0ABC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0AC0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E0AC4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E0ACC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000E0AD8: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0ADC: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000E0AE0: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E0AE4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E0AEC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0AF4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E0AF8: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000E0AFC: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000E0B00: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B04: BF870095
	.long 0xd71c0072                                           // 0000000E0B08: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E0B0C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E0B10: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E0B14: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B1C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000E0B20: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E0B2C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B30: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0B34: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000E0B3C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B40: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000E0B44: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000E0B4C: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000E0B50: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B58: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000E0B5C: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000E0B60: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B68: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000E0B6C: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000E0B70: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B78: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000E0B7C: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E0B84: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000E0B8C: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B98: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000E0B9C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000E0BA4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E0BB0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0BB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E0BBC: BE882004
	s_cbranch_execz 64828                                      // 0000000E0BC0: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000E0BC4: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0BD0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0BD8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0BDC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0BE0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E0BE4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E0BEC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000E0BF8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0BFC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000E0C00: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E0C04: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E0C0C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0C14: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E0C18: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000E0C1C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000E0C20: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C24: BF870095
	.long 0xd71c0072                                           // 0000000E0C28: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E0C2C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E0C30: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E0C34: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C3C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000E0C40: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E0C4C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C50: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0C54: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000E0C5C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C60: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000E0C64: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000E0C6C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000E0C70: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C78: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000E0C7C: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000E0C80: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C88: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000E0C8C: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000E0C90: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0C98: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000E0C9C: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E0CA4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000E0CAC: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0CB8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000E0CBC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000E0CC4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E0CD0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0CD8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E0CDC: BE882005
	s_cbranch_execz 64759                                      // 0000000E0CE0: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000E0CE4: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0CF0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0CF8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0CFC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D00: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E0D04: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E0D0C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000E0D18: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0D1C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000E0D20: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E0D24: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E0D2C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0D34: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E0D38: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000E0D3C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000E0D40: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D44: BF870095
	.long 0xd71c0072                                           // 0000000E0D48: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E0D4C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E0D50: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E0D54: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D5C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000E0D60: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000E0D68: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D70: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0D74: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000E0D7C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D80: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000E0D84: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000E0D8C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000E0D90: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0D98: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000E0D9C: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000E0DA0: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0DA8: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000E0DAC: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000E0DB0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0DB8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000E0DBC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E0DC4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000E0DCC: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0DD8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000E0DDC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000E0DE4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E0DF0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0DF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E0DFC: BE882006
	s_cbranch_execz 64690                                      // 0000000E0E00: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000E0E04: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0E10: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0E18: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0E1C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0E20: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E0E24: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E0E2C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000E0E38: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0E3C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000E0E40: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E0E44: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E0E4C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0E54: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E0E58: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000E0E5C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000E0E60: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0E64: BF870095
	.long 0xd71c0072                                           // 0000000E0E68: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E0E6C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E0E70: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E0E74: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0E7C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000E0E80: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E0E8C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0E90: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0E94: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000E0E9C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0EA0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000E0EA4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000E0EAC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000E0EB0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0EB8: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000E0EBC: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000E0EC0: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0EC8: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000E0ECC: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000E0ED0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0ED8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000E0EDC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E0EE4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000E0EEC: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0EF8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000E0EFC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000E0F04: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E0F10: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E0F18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E0F1C: BE882007
	s_cbranch_execz 64621                                      // 0000000E0F20: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000E0F24: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000E0F30: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E0F38: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E0F3C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0F40: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E0F44: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E0F4C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000E0F58: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E0F5C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000E0F60: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E0F64: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E0F6C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0F74: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E0F78: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000E0F7C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000E0F80: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0F84: BF870095
	.long 0xd71c0072                                           // 0000000E0F88: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E0F8C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E0F90: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E0F94: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0F9C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000E0FA0: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E0FAC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0FB0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000E0FB4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000E0FBC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0FC0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000E0FC4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000E0FCC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000E0FD0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0FD8: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000E0FDC: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000E0FE0: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0FE8: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000E0FEC: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000E0FF0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0FF8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000E0FFC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000E1004: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000E100C: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1018: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000E101C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000E1024: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000E1030: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1038: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E103C: BE882000
	s_cbranch_execz 64552                                      // 0000000E1040: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000E1044: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000E1050: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000E1054: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000E105C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000E1060: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1064: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000E1068: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000E1070: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000E107C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E1080: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000E1084: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000E1088: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000E1090: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1098: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000E109C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000E10A0: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000E10A4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E10A8: BF870095
	.long 0xd71c0072                                           // 0000000E10AC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000E10B0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000E10B4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000E10B8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E10C0: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000E10C4: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000E10CC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E10D0: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000E10D4: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000E10DC: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E10E0: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000E10E4: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000E10EC: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000E10F0: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E10F8: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000E10FC: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000E1100: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1108: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000E110C: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000E1110: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1118: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000E111C: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000E1124: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000E112C: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1138: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000E113C: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000E1144: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000E1150: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1158: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E115C: BE882001
	s_cbranch_execz 64483                                      // 0000000E1160: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000E1164: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000E1170: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000E1174: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000E117C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E1180: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1184: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000E1188: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1190: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000E1198: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000E11A4: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E11A8: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000E11AC: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000E11B4: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E11B8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000E11BC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000E11C0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000E11C4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E11C8: BF870095
	.long 0xd71c0071                                           // 0000000E11CC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000E11D0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000E11D4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E11D8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E11E0: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000E11E4: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E11EC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E11F0: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000E11F4: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000E11FC: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1200: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000E1204: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000E120C: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000E1210: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1218: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000E121C: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000E1220: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1228: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000E122C: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000E1230: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1238: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000E123C: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000E1244: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000E124C: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1258: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000E125C: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000E1264: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000E1270: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1278: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E127C: BE882002
	s_cbranch_execz 64414                                      // 0000000E1280: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37fc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000E1284: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E1290: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E1298: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E129C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E12A0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E12A4: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000E12AC: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000E12B8: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E12BC: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000E12C0: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E12C4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000E12CC: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E12D4: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000E12D8: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000E12DC: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000E12E0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E12E4: BF870095
	.long 0xd71c006a                                           // 0000000E12E8: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000E12EC: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E12F0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E12F4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E12FC: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000E1300: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E130C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1310: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E1314: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000E131C: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1320: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000E1324: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000E132C: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000E1330: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1338: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000E133C: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000E1340: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1348: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000E134C: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000E1350: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1358: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000E135C: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E1364: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000E136C: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1378: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000E137C: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000E1384: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E1390: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1398: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E139C: BE882003
	s_cbranch_execz 64345                                      // 0000000E13A0: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3808>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000E13A4: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E13B0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E13B8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E13BC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E13C0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E13C4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E13CC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000E13D8: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E13DC: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000E13E0: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000E13EC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000E13F0: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E13F4: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E13FC: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000E1400: 7ED44B6A
	.long 0xd71c006a                                           // 0000000E1404: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E1408: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E140C: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E1410: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E1414: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000E141C: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1428: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E142C: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E1430: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E1438: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000E143C: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000E1440: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1448: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000E144C: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000E1450: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000E1458: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E145C: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000E1460: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000E1468: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E146C: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000E1470: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000E1478: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1480: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E1484: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000E148C: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000E1498: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E14A0: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000E14A4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E14B0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E14B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E14BC: BE882004
	s_cbranch_execz 64276                                      // 0000000E14C0: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000E14C4: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E14D0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E14D8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E14DC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E14E0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E14E4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E14EC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000E14F8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E14FC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000E1500: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1504: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000E150C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1514: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000E1518: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000E151C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000E1520: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1524: BF870095
	.long 0xd71c006a                                           // 0000000E1528: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E152C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E1530: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E1534: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E153C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000E1540: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E154C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1550: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E1554: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000E155C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1560: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000E1564: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000E156C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000E1570: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1578: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000E157C: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000E1580: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1588: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000E158C: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000E1590: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1598: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000E159C: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E15A4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000E15AC: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E15B8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000E15BC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000E15C4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E15D0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E15D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E15DC: BE882005
	s_cbranch_execz 64207                                      // 0000000E15E0: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000E15E4: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E15F0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E15F8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E15FC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1600: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E1604: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E160C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000E1618: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E161C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000E1620: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1624: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000E162C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1634: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000E1638: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000E163C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000E1640: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1644: BF870095
	.long 0xd71c006a                                           // 0000000E1648: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E164C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E1650: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E1654: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E165C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000E1660: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000E1668: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1670: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E1674: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000E167C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1680: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000E1684: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000E168C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000E1690: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1698: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000E169C: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000E16A0: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E16A8: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000E16AC: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000E16B0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E16B8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000E16BC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E16C4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000E16CC: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E16D8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000E16DC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000E16E4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E16F0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E16F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E16FC: BE882006
	s_cbranch_execz 64138                                      // 0000000E1700: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000E1704: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E1710: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E1718: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E171C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1720: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E1724: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E172C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000E1738: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E173C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000E1740: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1744: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000E174C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1754: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000E1758: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000E175C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000E1760: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1764: BF870095
	.long 0xd71c006a                                           // 0000000E1768: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E176C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E1770: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E1774: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E177C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000E1780: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E178C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1790: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E1794: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000E179C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E17A0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000E17A4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000E17AC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000E17B0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E17B8: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000E17BC: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000E17C0: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E17C8: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000E17CC: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000E17D0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E17D8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000E17DC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E17E4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000E17EC: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E17F8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000E17FC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000E1804: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E1810: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1818: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E181C: BE882007
	s_cbranch_execz 64069                                      // 0000000E1820: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000E1824: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000E1830: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E1838: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E183C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1840: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E1844: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E184C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000E1858: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E185C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000E1860: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1864: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000E186C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1874: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000E1878: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000E187C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000E1880: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1884: BF870095
	.long 0xd71c006a                                           // 0000000E1888: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E188C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E1890: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E1894: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E189C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000E18A0: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E18AC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E18B0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000E18B4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000E18BC: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E18C0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000E18C4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000E18CC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000E18D0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E18D8: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000E18DC: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000E18E0: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E18E8: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000E18EC: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000E18F0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E18F8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000E18FC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000E1904: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000E190C: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1918: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000E191C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000E1924: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000E1930: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1938: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E193C: BE882000
	s_cbranch_execz 64000                                      // 0000000E1940: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000E1944: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000E1950: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000E1954: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000E195C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000E1960: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1964: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000E1968: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000E1970: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000E197C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E1980: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000E1984: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000E1988: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000E1990: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1998: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000E199C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000E19A0: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000E19A4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E19A8: BF870095
	.long 0xd71c006a                                           // 0000000E19AC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000E19B0: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000E19B4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000E19B8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E19C0: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000E19C4: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000E19CC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E19D0: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000E19D4: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000E19DC: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E19E0: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000E19E4: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000E19EC: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000E19F0: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E19F8: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000E19FC: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000E1A00: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1A08: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000E1A0C: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000E1A10: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1A18: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000E1A1C: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000E1A24: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000E1A2C: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1A38: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000E1A3C: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000E1A44: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000E1A50: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1A58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E1A5C: BE882001
	s_cbranch_execz 63931                                      // 0000000E1A60: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000E1A64: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000E1A70: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000E1A74: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000E1A7C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E1A80: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1A84: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000E1A88: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E1A90: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000E1A98: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000E1AA4: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E1AA8: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000E1AAC: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000E1AB4: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1AB8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000E1ABC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000E1AC0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000E1AC4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1AC8: BF870095
	.long 0xd71c0069                                           // 0000000E1ACC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000E1AD0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000E1AD4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E1AD8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1AE0: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000E1AE4: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E1AEC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1AF0: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000E1AF4: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000E1AFC: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1B00: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000E1B04: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000E1B0C: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000E1B10: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1B18: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000E1B1C: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000E1B20: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1B28: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000E1B2C: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000E1B30: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1B38: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000E1B3C: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000E1B44: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000E1B4C: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1B58: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000E1B5C: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000E1B64: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000E1B70: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1B78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E1B7C: BE882002
	s_cbranch_execz 63862                                      // 0000000E1B80: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000E1B84: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E1B90: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E1B98: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E1B9C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1BA0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E1BA4: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000E1BAC: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000E1BB8: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E1BBC: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000E1BC0: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E1BC4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000E1BCC: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1BD4: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000E1BD8: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000E1BDC: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000E1BE0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1BE4: BF870095
	.long 0xd71c0062                                           // 0000000E1BE8: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000E1BEC: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E1BF0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E1BF4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1BFC: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000E1C00: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E1C0C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C10: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E1C14: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000E1C1C: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C20: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000E1C24: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000E1C2C: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000E1C30: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C38: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000E1C3C: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000E1C40: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C48: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000E1C4C: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000E1C50: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C58: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000E1C5C: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E1C64: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000E1C6C: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C78: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000E1C7C: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000E1C84: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E1C90: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1C98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E1C9C: BE882003
	s_cbranch_execz 63793                                      // 0000000E1CA0: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000E1CA4: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E1CB0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E1CB8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E1CBC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1CC0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E1CC4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E1CCC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000E1CD8: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1CDC: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000E1CE0: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000E1CEC: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000E1CF0: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E1CF4: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E1CFC: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000E1D00: 7EC44B62
	.long 0xd71c0062                                           // 0000000E1D04: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E1D08: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1D0C: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E1D10: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E1D14: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000E1D1C: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1D28: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E1D2C: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E1D30: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E1D38: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000E1D3C: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000E1D40: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1D48: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000E1D4C: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000E1D50: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000E1D58: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1D5C: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000E1D60: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000E1D68: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1D6C: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000E1D70: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000E1D78: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1D80: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E1D84: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000E1D8C: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000E1D98: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E1DA0: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000E1DA4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E1DB0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1DB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E1DBC: BE882004
	s_cbranch_execz 63724                                      // 0000000E1DC0: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000E1DC4: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E1DD0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E1DD8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E1DDC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1DE0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E1DE4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E1DEC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000E1DF8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E1DFC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000E1E00: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E1E04: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000E1E0C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1E14: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000E1E18: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000E1E1C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000E1E20: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E24: BF870095
	.long 0xd71c0062                                           // 0000000E1E28: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E1E2C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E1E30: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E1E34: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E3C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000E1E40: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E1E4C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E50: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E1E54: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000E1E5C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E60: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000E1E64: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000E1E6C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000E1E70: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E78: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000E1E7C: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000E1E80: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E88: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000E1E8C: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000E1E90: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1E98: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000E1E9C: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E1EA4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000E1EAC: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1EB8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000E1EBC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000E1EC4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E1ED0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1ED8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E1EDC: BE882005
	s_cbranch_execz 63655                                      // 0000000E1EE0: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000E1EE4: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E1EF0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E1EF8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E1EFC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F00: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E1F04: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E1F0C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000E1F18: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E1F1C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000E1F20: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E1F24: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000E1F2C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1F34: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000E1F38: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000E1F3C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000E1F40: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F44: BF870095
	.long 0xd71c0062                                           // 0000000E1F48: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E1F4C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E1F50: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E1F54: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F5C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000E1F60: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000E1F68: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F70: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E1F74: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000E1F7C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F80: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000E1F84: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000E1F8C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000E1F90: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1F98: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000E1F9C: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000E1FA0: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1FA8: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000E1FAC: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000E1FB0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1FB8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000E1FBC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E1FC4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000E1FCC: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1FD8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000E1FDC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000E1FE4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E1FF0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E1FF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E1FFC: BE882006
	s_cbranch_execz 63586                                      // 0000000E2000: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000E2004: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E2010: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E2018: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E201C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2020: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E2024: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E202C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000E2038: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E203C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000E2040: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E2044: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000E204C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2054: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000E2058: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000E205C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000E2060: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2064: BF870095
	.long 0xd71c0062                                           // 0000000E2068: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E206C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E2070: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E2074: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E207C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000E2080: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E208C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2090: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E2094: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000E209C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E20A0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000E20A4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000E20AC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000E20B0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E20B8: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000E20BC: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000E20C0: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E20C8: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000E20CC: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000E20D0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E20D8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000E20DC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E20E4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000E20EC: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E20F8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000E20FC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000E2104: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E2110: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2118: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E211C: BE882007
	s_cbranch_execz 63517                                      // 0000000E2120: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3898>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000E2124: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000E2130: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E2138: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E213C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2140: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E2144: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E214C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000E2158: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E215C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000E2160: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E2164: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000E216C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2174: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000E2178: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000E217C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000E2180: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2184: BF870095
	.long 0xd71c0062                                           // 0000000E2188: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E218C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E2190: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E2194: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E219C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000E21A0: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E21AC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E21B0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000E21B4: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000E21BC: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E21C0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000E21C4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000E21CC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000E21D0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E21D8: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000E21DC: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000E21E0: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E21E8: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000E21EC: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000E21F0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E21F8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000E21FC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000E2204: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000E220C: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2218: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000E221C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000E2224: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000E2230: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2238: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E223C: BE882000
	s_cbranch_execz 63448                                      // 0000000E2240: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000E2244: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000E2250: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000E2254: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000E225C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000E2260: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2264: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000E2268: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000E2270: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000E227C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E2280: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000E2284: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000E2288: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000E2290: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2298: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000E229C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000E22A0: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000E22A4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E22A8: BF870095
	.long 0xd71c0062                                           // 0000000E22AC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000E22B0: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000E22B4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000E22B8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E22C0: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000E22C4: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000E22CC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E22D0: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000E22D4: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000E22DC: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E22E0: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000E22E4: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000E22EC: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000E22F0: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E22F8: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000E22FC: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000E2300: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2308: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000E230C: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000E2310: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2318: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000E231C: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000E2324: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000E232C: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2338: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000E233C: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000E2344: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000E2350: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2358: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E235C: BE882001
	s_cbranch_execz 63379                                      // 0000000E2360: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000E2364: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000E2370: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000E2374: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000E237C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E2380: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2384: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000E2388: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2390: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000E2398: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000E23A4: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E23A8: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000E23AC: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000E23B4: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E23B8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000E23BC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000E23C0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000E23C4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E23C8: BF870095
	.long 0xd71c0061                                           // 0000000E23CC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000E23D0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000E23D4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E23D8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E23E0: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000E23E4: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E23EC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E23F0: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000E23F4: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000E23FC: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2400: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000E2404: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000E240C: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000E2410: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2418: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000E241C: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000E2420: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2428: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000E242C: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000E2430: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2438: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000E243C: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000E2444: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000E244C: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2458: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000E245C: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000E2464: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000E2470: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2478: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E247C: BE882002
	s_cbranch_execz 63310                                      // 0000000E2480: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38bc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000E2484: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E2490: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E2498: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E249C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E24A0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E24A4: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000E24AC: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000E24B8: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E24BC: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000E24C0: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E24C4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000E24CC: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E24D4: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000E24D8: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000E24DC: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000E24E0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E24E4: BF870095
	.long 0xd71c005a                                           // 0000000E24E8: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000E24EC: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E24F0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E24F4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E24FC: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000E2500: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E250C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2510: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2514: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000E251C: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2520: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000E2524: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000E252C: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000E2530: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2538: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000E253C: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000E2540: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2548: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000E254C: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000E2550: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2558: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000E255C: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E2564: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000E256C: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2578: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000E257C: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000E2584: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E2590: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2598: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E259C: BE882003
	s_cbranch_execz 63241                                      // 0000000E25A0: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000E25A4: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E25B0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E25B8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E25BC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E25C0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E25C4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E25CC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000E25D8: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E25DC: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000E25E0: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000E25EC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000E25F0: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E25F4: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E25FC: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000E2600: 7EB44B5A
	.long 0xd71c005a                                           // 0000000E2604: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E2608: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E260C: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2610: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2614: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000E261C: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2628: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E262C: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2630: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E2638: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000E263C: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000E2640: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E2648: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000E264C: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000E2650: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000E2658: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E265C: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000E2660: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000E2668: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E266C: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000E2670: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000E2678: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2680: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E2684: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000E268C: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000E2698: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E26A0: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000E26A4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E26B0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E26B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E26BC: BE882004
	s_cbranch_execz 63172                                      // 0000000E26C0: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000E26C4: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E26D0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E26D8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E26DC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E26E0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E26E4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E26EC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000E26F8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E26FC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000E2700: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2704: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000E270C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2714: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000E2718: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000E271C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000E2720: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2724: BF870095
	.long 0xd71c005a                                           // 0000000E2728: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E272C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2730: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2734: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E273C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000E2740: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E274C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2750: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2754: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000E275C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2760: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000E2764: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000E276C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000E2770: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2778: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000E277C: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000E2780: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2788: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000E278C: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000E2790: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2798: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000E279C: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E27A4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000E27AC: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E27B8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000E27BC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000E27C4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E27D0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E27D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E27DC: BE882005
	s_cbranch_execz 63103                                      // 0000000E27E0: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000E27E4: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E27F0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E27F8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E27FC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2800: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E2804: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E280C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000E2818: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E281C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000E2820: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2824: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000E282C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2834: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000E2838: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000E283C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000E2840: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2844: BF870095
	.long 0xd71c005a                                           // 0000000E2848: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E284C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2850: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2854: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E285C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000E2860: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000E2868: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2870: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2874: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000E287C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2880: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000E2884: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000E288C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000E2890: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2898: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000E289C: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000E28A0: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E28A8: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000E28AC: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000E28B0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E28B8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000E28BC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E28C4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000E28CC: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E28D8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000E28DC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000E28E4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E28F0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E28F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E28FC: BE882006
	s_cbranch_execz 63034                                      // 0000000E2900: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38ec>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000E2904: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E2910: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E2918: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E291C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2920: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E2924: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E292C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000E2938: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E293C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000E2940: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2944: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000E294C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2954: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000E2958: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000E295C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000E2960: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2964: BF870095
	.long 0xd71c005a                                           // 0000000E2968: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E296C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2970: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2974: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E297C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000E2980: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E298C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2990: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2994: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000E299C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E29A0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000E29A4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000E29AC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000E29B0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E29B8: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000E29BC: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000E29C0: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E29C8: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000E29CC: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000E29D0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E29D8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000E29DC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E29E4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000E29EC: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E29F8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000E29FC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000E2A04: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E2A10: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2A18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E2A1C: BE882007
	s_cbranch_execz 62965                                      // 0000000E2A20: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000E2A24: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000E2A30: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E2A38: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E2A3C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2A40: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E2A44: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E2A4C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000E2A58: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E2A5C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000E2A60: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2A64: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000E2A6C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2A74: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000E2A78: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000E2A7C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000E2A80: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2A84: BF870095
	.long 0xd71c005a                                           // 0000000E2A88: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E2A8C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2A90: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2A94: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2A9C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000E2AA0: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E2AAC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2AB0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000E2AB4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000E2ABC: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2AC0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000E2AC4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000E2ACC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000E2AD0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2AD8: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000E2ADC: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000E2AE0: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2AE8: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000E2AEC: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000E2AF0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2AF8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000E2AFC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000E2B04: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000E2B0C: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2B18: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000E2B1C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000E2B24: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000E2B30: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2B38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E2B3C: BE882000
	s_cbranch_execz 62896                                      // 0000000E2B40: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3904>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000E2B44: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000E2B50: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000E2B54: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000E2B5C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000E2B60: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2B64: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000E2B68: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000E2B70: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000E2B7C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E2B80: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000E2B84: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000E2B88: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000E2B90: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2B98: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000E2B9C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000E2BA0: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000E2BA4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2BA8: BF870095
	.long 0xd71c005a                                           // 0000000E2BAC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000E2BB0: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000E2BB4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000E2BB8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2BC0: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000E2BC4: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000E2BCC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2BD0: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000E2BD4: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000E2BDC: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2BE0: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000E2BE4: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000E2BEC: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000E2BF0: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2BF8: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000E2BFC: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000E2C00: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2C08: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000E2C0C: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000E2C10: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2C18: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000E2C1C: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000E2C24: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000E2C2C: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2C38: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000E2C3C: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000E2C44: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000E2C50: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2C58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E2C5C: BE882001
	s_cbranch_execz 62827                                      // 0000000E2C60: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000E2C64: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000E2C70: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000E2C74: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000E2C7C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E2C80: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2C84: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000E2C88: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E2C90: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000E2C98: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000E2CA4: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E2CA8: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000E2CAC: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000E2CB4: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2CB8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000E2CBC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000E2CC0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000E2CC4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2CC8: BF870095
	.long 0xd71c0059                                           // 0000000E2CCC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000E2CD0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000E2CD4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E2CD8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2CE0: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000E2CE4: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E2CEC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2CF0: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000E2CF4: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000E2CFC: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2D00: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000E2D04: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000E2D0C: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000E2D10: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2D18: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000E2D1C: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000E2D20: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2D28: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000E2D2C: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000E2D30: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2D38: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000E2D3C: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000E2D44: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000E2D4C: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2D58: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000E2D5C: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000E2D64: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000E2D70: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2D78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E2D7C: BE882002
	s_cbranch_execz 62758                                      // 0000000E2D80: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x391c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000E2D84: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E2D90: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E2D98: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E2D9C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2DA0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E2DA4: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000E2DAC: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000E2DB8: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E2DBC: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000E2DC0: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E2DC4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000E2DCC: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2DD4: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000E2DD8: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000E2DDC: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000E2DE0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2DE4: BF870095
	.long 0xd71c0052                                           // 0000000E2DE8: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000E2DEC: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E2DF0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E2DF4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2DFC: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000E2E00: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E2E0C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E10: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E2E14: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000E2E1C: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E20: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000E2E24: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000E2E2C: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000E2E30: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E38: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000E2E3C: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000E2E40: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E48: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000E2E4C: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000E2E50: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E58: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000E2E5C: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E2E64: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000E2E6C: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2E78: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000E2E7C: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000E2E84: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E2E90: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2E98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E2E9C: BE882003
	s_cbranch_execz 62689                                      // 0000000E2EA0: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3928>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000E2EA4: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E2EB0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E2EB8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E2EBC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2EC0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E2EC4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E2ECC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000E2ED8: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2EDC: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000E2EE0: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000E2EEC: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000E2EF0: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E2EF4: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E2EFC: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000E2F00: 7EA44B52
	.long 0xd71c0052                                           // 0000000E2F04: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E2F08: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2F0C: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E2F10: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E2F14: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000E2F1C: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2F28: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E2F2C: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E2F30: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E2F38: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000E2F3C: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000E2F40: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E2F48: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000E2F4C: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000E2F50: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000E2F58: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2F5C: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000E2F60: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000E2F68: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2F6C: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000E2F70: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000E2F78: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E2F80: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E2F84: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000E2F8C: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000E2F98: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E2FA0: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000E2FA4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E2FB0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E2FB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E2FBC: BE882004
	s_cbranch_execz 62620                                      // 0000000E2FC0: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3934>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000E2FC4: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E2FD0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E2FD8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E2FDC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E2FE0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E2FE4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E2FEC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000E2FF8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E2FFC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000E3000: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E3004: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000E300C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3014: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000E3018: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000E301C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000E3020: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3024: BF870095
	.long 0xd71c0052                                           // 0000000E3028: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E302C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E3030: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E3034: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E303C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000E3040: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E304C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3050: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E3054: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000E305C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3060: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000E3064: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000E306C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000E3070: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3078: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000E307C: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000E3080: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3088: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000E308C: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000E3090: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3098: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000E309C: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E30A4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000E30AC: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E30B8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000E30BC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000E30C4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E30D0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E30D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E30DC: BE882005
	s_cbranch_execz 62551                                      // 0000000E30E0: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3940>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000E30E4: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E30F0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E30F8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E30FC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3100: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E3104: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E310C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000E3118: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E311C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000E3120: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E3124: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000E312C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3134: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000E3138: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000E313C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000E3140: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3144: BF870095
	.long 0xd71c0052                                           // 0000000E3148: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E314C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E3150: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E3154: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E315C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000E3160: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000E3168: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3170: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E3174: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000E317C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3180: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000E3184: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000E318C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000E3190: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3198: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000E319C: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000E31A0: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E31A8: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000E31AC: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000E31B0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E31B8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000E31BC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E31C4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000E31CC: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E31D8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000E31DC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000E31E4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E31F0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E31F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E31FC: BE882006
	s_cbranch_execz 62482                                      // 0000000E3200: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x394c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000E3204: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E3210: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E3218: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E321C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3220: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E3224: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E322C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000E3238: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E323C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000E3240: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E3244: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000E324C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3254: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000E3258: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000E325C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000E3260: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3264: BF870095
	.long 0xd71c0052                                           // 0000000E3268: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E326C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E3270: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E3274: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E327C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000E3280: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E328C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3290: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E3294: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000E329C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E32A0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000E32A4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000E32AC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000E32B0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E32B8: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000E32BC: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000E32C0: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E32C8: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000E32CC: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000E32D0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E32D8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000E32DC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E32E4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000E32EC: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E32F8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000E32FC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000E3304: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E3310: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3318: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E331C: BE882007
	s_cbranch_execz 62413                                      // 0000000E3320: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3958>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000E3324: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000E3330: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E3338: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E333C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3340: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E3344: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E334C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000E3358: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E335C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000E3360: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E3364: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000E336C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3374: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000E3378: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000E337C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000E3380: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3384: BF870095
	.long 0xd71c0052                                           // 0000000E3388: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E338C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E3390: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E3394: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E339C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000E33A0: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E33AC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E33B0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000E33B4: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000E33BC: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E33C0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000E33C4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000E33CC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000E33D0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E33D8: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000E33DC: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000E33E0: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E33E8: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000E33EC: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000E33F0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E33F8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000E33FC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000E3404: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000E340C: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3418: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000E341C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000E3424: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000E3430: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3438: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E343C: BE882000
	s_cbranch_execz 62344                                      // 0000000E3440: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3964>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000E3444: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000E3450: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000E3454: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000E345C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000E3460: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3464: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000E3468: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000E3470: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000E347C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3480: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000E3484: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000E3488: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000E3490: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3498: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000E349C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000E34A0: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000E34A4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E34A8: BF870095
	.long 0xd71c0052                                           // 0000000E34AC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000E34B0: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000E34B4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000E34B8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E34C0: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000E34C4: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000E34CC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E34D0: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000E34D4: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000E34DC: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E34E0: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000E34E4: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000E34EC: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000E34F0: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E34F8: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000E34FC: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000E3500: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3508: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000E350C: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000E3510: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3518: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000E351C: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000E3524: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000E352C: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3538: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000E353C: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000E3544: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000E3550: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3558: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E355C: BE882001
	s_cbranch_execz 62275                                      // 0000000E3560: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3970>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000E3564: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000E3570: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000E3574: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000E357C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E3580: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3584: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000E3588: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3590: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000E3598: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000E35A4: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E35A8: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000E35AC: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000E35B4: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E35B8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000E35BC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000E35C0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000E35C4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E35C8: BF870095
	.long 0xd71c0051                                           // 0000000E35CC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000E35D0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000E35D4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E35D8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E35E0: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000E35E4: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E35EC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E35F0: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000E35F4: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000E35FC: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3600: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000E3604: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000E360C: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000E3610: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3618: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000E361C: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000E3620: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3628: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000E362C: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000E3630: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3638: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000E363C: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000E3644: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000E364C: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3658: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000E365C: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000E3664: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000E3670: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3678: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E367C: BE882002
	s_cbranch_execz 62206                                      // 0000000E3680: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x397c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000E3684: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E3690: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E3698: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E369C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E36A0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E36A4: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000E36AC: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000E36B8: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E36BC: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000E36C0: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E36C4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000E36CC: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E36D4: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000E36D8: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000E36DC: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000E36E0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E36E4: BF870095
	.long 0xd71c004a                                           // 0000000E36E8: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000E36EC: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E36F0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E36F4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E36FC: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000E3700: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E370C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3710: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3714: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000E371C: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3720: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000E3724: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000E372C: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000E3730: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3738: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000E373C: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000E3740: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3748: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000E374C: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000E3750: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3758: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000E375C: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E3764: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000E376C: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3778: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000E377C: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000E3784: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E3790: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3798: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E379C: BE882003
	s_cbranch_execz 62137                                      // 0000000E37A0: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3988>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000E37A4: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E37B0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E37B8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E37BC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E37C0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E37C4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E37CC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000E37D8: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E37DC: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000E37E0: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000E37EC: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000E37F0: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E37F4: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E37FC: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000E3800: 7E944B4A
	.long 0xd71c004a                                           // 0000000E3804: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E3808: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E380C: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3810: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3814: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000E381C: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3828: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E382C: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3830: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E3838: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000E383C: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000E3840: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E3848: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000E384C: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000E3850: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000E3858: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E385C: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000E3860: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000E3868: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E386C: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000E3870: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000E3878: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3880: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E3884: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000E388C: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000E3898: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E38A0: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000E38A4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E38B0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E38B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E38BC: BE882004
	s_cbranch_execz 62068                                      // 0000000E38C0: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3994>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000E38C4: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E38D0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E38D8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E38DC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E38E0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E38E4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E38EC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000E38F8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E38FC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000E3900: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3904: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000E390C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3914: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000E3918: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000E391C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000E3920: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3924: BF870095
	.long 0xd71c004a                                           // 0000000E3928: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E392C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3930: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3934: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E393C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000E3940: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E394C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3950: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3954: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000E395C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3960: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000E3964: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000E396C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000E3970: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3978: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000E397C: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000E3980: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3988: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000E398C: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000E3990: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3998: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000E399C: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E39A4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000E39AC: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E39B8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000E39BC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000E39C4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E39D0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E39D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E39DC: BE882005
	s_cbranch_execz 61999                                      // 0000000E39E0: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39a0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000E39E4: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E39F0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E39F8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E39FC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A00: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E3A04: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E3A0C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000E3A18: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3A1C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000E3A20: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3A24: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000E3A2C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3A34: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000E3A38: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000E3A3C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000E3A40: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A44: BF870095
	.long 0xd71c004a                                           // 0000000E3A48: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E3A4C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3A50: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3A54: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A5C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000E3A60: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000E3A68: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A70: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3A74: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000E3A7C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A80: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000E3A84: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000E3A8C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000E3A90: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3A98: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000E3A9C: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000E3AA0: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3AA8: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000E3AAC: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000E3AB0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3AB8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000E3ABC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E3AC4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000E3ACC: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3AD8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000E3ADC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000E3AE4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E3AF0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3AF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E3AFC: BE882006
	s_cbranch_execz 61930                                      // 0000000E3B00: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ac>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000E3B04: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E3B10: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E3B18: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E3B1C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3B20: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E3B24: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E3B2C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000E3B38: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3B3C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000E3B40: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3B44: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000E3B4C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3B54: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000E3B58: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000E3B5C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000E3B60: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3B64: BF870095
	.long 0xd71c004a                                           // 0000000E3B68: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E3B6C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3B70: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3B74: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3B7C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000E3B80: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E3B8C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3B90: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3B94: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000E3B9C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3BA0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000E3BA4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000E3BAC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000E3BB0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3BB8: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000E3BBC: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000E3BC0: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3BC8: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000E3BCC: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000E3BD0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3BD8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000E3BDC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E3BE4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000E3BEC: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3BF8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000E3BFC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000E3C04: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E3C10: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3C18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E3C1C: BE882007
	s_cbranch_execz 61861                                      // 0000000E3C20: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000E3C24: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000E3C30: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E3C38: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E3C3C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3C40: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E3C44: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E3C4C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000E3C58: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3C5C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000E3C60: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3C64: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000E3C6C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3C74: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000E3C78: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000E3C7C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000E3C80: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3C84: BF870095
	.long 0xd71c004a                                           // 0000000E3C88: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E3C8C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3C90: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3C94: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3C9C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000E3CA0: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E3CAC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3CB0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000E3CB4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000E3CBC: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3CC0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000E3CC4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000E3CCC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000E3CD0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3CD8: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000E3CDC: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000E3CE0: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3CE8: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000E3CEC: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000E3CF0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3CF8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000E3CFC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000E3D04: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000E3D0C: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3D18: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000E3D1C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000E3D24: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000E3D30: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3D38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E3D3C: BE882000
	s_cbranch_execz 61792                                      // 0000000E3D40: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000E3D44: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000E3D50: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000E3D54: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000E3D5C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000E3D60: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3D64: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000E3D68: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000E3D70: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000E3D7C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3D80: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000E3D84: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000E3D88: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000E3D90: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3D98: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000E3D9C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000E3DA0: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000E3DA4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3DA8: BF870095
	.long 0xd71c004a                                           // 0000000E3DAC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000E3DB0: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000E3DB4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000E3DB8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3DC0: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000E3DC4: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000E3DCC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3DD0: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000E3DD4: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000E3DDC: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3DE0: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000E3DE4: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000E3DEC: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000E3DF0: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3DF8: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000E3DFC: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000E3E00: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3E08: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000E3E0C: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000E3E10: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3E18: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000E3E1C: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000E3E24: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000E3E2C: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3E38: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000E3E3C: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000E3E44: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000E3E50: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3E58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E3E5C: BE882001
	s_cbranch_execz 61723                                      // 0000000E3E60: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39d0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000E3E64: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000E3E70: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000E3E74: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000E3E7C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E3E80: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3E84: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000E3E88: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E3E90: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000E3E98: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000E3EA4: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E3EA8: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000E3EAC: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000E3EB4: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3EB8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000E3EBC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000E3EC0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000E3EC4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3EC8: BF870095
	.long 0xd71c0049                                           // 0000000E3ECC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000E3ED0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000E3ED4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E3ED8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3EE0: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000E3EE4: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E3EEC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3EF0: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000E3EF4: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000E3EFC: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3F00: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000E3F04: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000E3F0C: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000E3F10: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3F18: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000E3F1C: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000E3F20: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3F28: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000E3F2C: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000E3F30: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3F38: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000E3F3C: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000E3F44: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000E3F4C: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3F58: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000E3F5C: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000E3F64: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000E3F70: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E3F78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E3F7C: BE882002
	s_cbranch_execz 61654                                      // 0000000E3F80: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39dc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000E3F84: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E3F90: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E3F98: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E3F9C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3FA0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E3FA4: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000E3FAC: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000E3FB8: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E3FBC: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000E3FC0: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E3FC4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000E3FCC: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E3FD4: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000E3FD8: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000E3FDC: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000E3FE0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3FE4: BF870095
	.long 0xd71c0042                                           // 0000000E3FE8: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000E3FEC: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E3FF0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E3FF4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E3FFC: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000E4000: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E400C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4010: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E4014: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000E401C: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4020: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000E4024: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000E402C: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000E4030: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4038: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000E403C: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000E4040: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4048: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000E404C: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000E4050: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4058: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000E405C: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E4064: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000E406C: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4078: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000E407C: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000E4084: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E4090: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4098: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E409C: BE882003
	s_cbranch_execz 61585                                      // 0000000E40A0: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39e8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000E40A4: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E40B0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E40B8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E40BC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E40C0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E40C4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E40CC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000E40D8: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E40DC: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000E40E0: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000E40EC: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000E40F0: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E40F4: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E40FC: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000E4100: 7E844B42
	.long 0xd71c0042                                           // 0000000E4104: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E4108: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E410C: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E4110: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E4114: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000E411C: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4128: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E412C: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E4130: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E4138: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000E413C: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000E4140: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E4148: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000E414C: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000E4150: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000E4158: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E415C: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000E4160: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000E4168: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E416C: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000E4170: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000E4178: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4180: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E4184: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000E418C: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000E4198: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E41A0: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000E41A4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E41B0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E41B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E41BC: BE882004
	s_cbranch_execz 61516                                      // 0000000E41C0: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39f4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000E41C4: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E41D0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E41D8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E41DC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E41E0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E41E4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E41EC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000E41F8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E41FC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000E4200: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E4204: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000E420C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4214: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000E4218: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000E421C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000E4220: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4224: BF870095
	.long 0xd71c0042                                           // 0000000E4228: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E422C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E4230: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E4234: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E423C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000E4240: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E424C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4250: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E4254: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000E425C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4260: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000E4264: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000E426C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000E4270: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4278: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000E427C: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000E4280: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4288: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000E428C: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000E4290: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4298: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000E429C: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E42A4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000E42AC: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E42B8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000E42BC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000E42C4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E42D0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E42D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E42DC: BE882005
	s_cbranch_execz 61447                                      // 0000000E42E0: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a00>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000E42E4: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E42F0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E42F8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E42FC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4300: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E4304: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E430C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000E4318: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E431C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000E4320: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E4324: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000E432C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4334: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000E4338: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000E433C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000E4340: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4344: BF870095
	.long 0xd71c0042                                           // 0000000E4348: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E434C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E4350: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E4354: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E435C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000E4360: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000E4368: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4370: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E4374: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000E437C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4380: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000E4384: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000E438C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000E4390: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4398: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000E439C: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000E43A0: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E43A8: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000E43AC: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000E43B0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E43B8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000E43BC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E43C4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000E43CC: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E43D8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000E43DC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000E43E4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E43F0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E43F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E43FC: BE882006
	s_cbranch_execz 61378                                      // 0000000E4400: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a0c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000E4404: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E4410: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E4418: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E441C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4420: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E4424: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E442C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000E4438: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E443C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000E4440: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E4444: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000E444C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4454: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000E4458: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000E445C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000E4460: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4464: BF870095
	.long 0xd71c0042                                           // 0000000E4468: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E446C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E4470: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E4474: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E447C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000E4480: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E448C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4490: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E4494: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000E449C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E44A0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000E44A4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000E44AC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000E44B0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E44B8: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000E44BC: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000E44C0: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E44C8: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000E44CC: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000E44D0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E44D8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000E44DC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E44E4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000E44EC: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E44F8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000E44FC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000E4504: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E4510: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4518: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E451C: BE882007
	s_cbranch_execz 61309                                      // 0000000E4520: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a18>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000E4524: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000E4530: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E4538: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E453C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4540: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E4544: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E454C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000E4558: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E455C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000E4560: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E4564: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000E456C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4574: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000E4578: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000E457C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000E4580: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4584: BF870095
	.long 0xd71c0042                                           // 0000000E4588: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E458C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E4590: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E4594: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E459C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000E45A0: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E45AC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E45B0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000E45B4: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000E45BC: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E45C0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000E45C4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000E45CC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000E45D0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E45D8: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000E45DC: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000E45E0: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E45E8: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000E45EC: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000E45F0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E45F8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000E45FC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000E4604: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000E460C: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4618: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000E461C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000E4624: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000E4630: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4638: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E463C: BE882000
	s_cbranch_execz 61240                                      // 0000000E4640: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a24>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000E4644: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000E4650: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000E4654: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000E465C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000E4660: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4664: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000E4668: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000E4670: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000E467C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4680: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000E4684: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000E4688: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000E4690: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4698: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000E469C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000E46A0: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000E46A4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E46A8: BF870095
	.long 0xd71c0042                                           // 0000000E46AC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000E46B0: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000E46B4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000E46B8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E46C0: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000E46C4: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000E46CC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E46D0: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000E46D4: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000E46DC: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E46E0: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000E46E4: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000E46EC: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000E46F0: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E46F8: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000E46FC: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000E4700: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4708: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000E470C: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000E4710: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4718: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000E471C: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000E4724: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000E472C: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4738: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000E473C: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000E4744: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000E4750: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4758: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E475C: BE882001
	s_cbranch_execz 61171                                      // 0000000E4760: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a30>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000E4764: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000E4770: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000E4774: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000E477C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4780: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4784: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000E4788: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4790: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000E4798: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000E47A4: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E47A8: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000E47AC: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000E47B4: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E47B8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000E47BC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000E47C0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000E47C4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E47C8: BF870095
	.long 0xd71c0041                                           // 0000000E47CC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000E47D0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000E47D4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E47D8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E47E0: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000E47E4: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E47EC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E47F0: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000E47F4: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000E47FC: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4800: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000E4804: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000E480C: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000E4810: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4818: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000E481C: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000E4820: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4828: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000E482C: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000E4830: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4838: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000E483C: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000E4844: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000E484C: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4858: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000E485C: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000E4864: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000E4870: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4878: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E487C: BE882002
	s_cbranch_execz 61102                                      // 0000000E4880: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a3c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000E4884: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E4890: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4898: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E489C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E48A0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E48A4: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000E48AC: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000E48B8: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E48BC: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000E48C0: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E48C4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000E48CC: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E48D4: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000E48D8: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000E48DC: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000E48E0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E48E4: BF870095
	.long 0xd71c003a                                           // 0000000E48E8: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000E48EC: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E48F0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E48F4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E48FC: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000E4900: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E490C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4910: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4914: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000E491C: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4920: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000E4924: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000E492C: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000E4930: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4938: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000E493C: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000E4940: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4948: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000E494C: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000E4950: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4958: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000E495C: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4964: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000E496C: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4978: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000E497C: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000E4984: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4990: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4998: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E499C: BE882003
	s_cbranch_execz 61033                                      // 0000000E49A0: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a48>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000E49A4: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E49B0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E49B8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E49BC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E49C0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E49C4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E49CC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000E49D8: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E49DC: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000E49E0: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000E49EC: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000E49F0: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E49F4: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E49FC: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000E4A00: 7E744B3A
	.long 0xd71c003a                                           // 0000000E4A04: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4A08: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4A0C: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4A10: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4A14: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000E4A1C: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4A28: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E4A2C: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4A30: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E4A38: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000E4A3C: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000E4A40: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E4A48: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000E4A4C: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000E4A50: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000E4A58: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4A5C: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000E4A60: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000E4A68: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4A6C: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000E4A70: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000E4A78: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4A80: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4A84: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000E4A8C: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000E4A98: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E4AA0: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000E4AA4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4AB0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4AB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E4ABC: BE882004
	s_cbranch_execz 60964                                      // 0000000E4AC0: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a54>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000E4AC4: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E4AD0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4AD8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4ADC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4AE0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E4AE4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E4AEC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000E4AF8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4AFC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000E4B00: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4B04: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000E4B0C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4B14: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000E4B18: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000E4B1C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000E4B20: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B24: BF870095
	.long 0xd71c003a                                           // 0000000E4B28: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4B2C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4B30: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4B34: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B3C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000E4B40: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E4B4C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B50: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4B54: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000E4B5C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B60: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000E4B64: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000E4B6C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000E4B70: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B78: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000E4B7C: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000E4B80: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B88: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000E4B8C: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000E4B90: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4B98: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000E4B9C: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4BA4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000E4BAC: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4BB8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000E4BBC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000E4BC4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4BD0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4BD8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E4BDC: BE882005
	s_cbranch_execz 60895                                      // 0000000E4BE0: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a60>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000E4BE4: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E4BF0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4BF8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4BFC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C00: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E4C04: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E4C0C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000E4C18: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4C1C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000E4C20: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4C24: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000E4C2C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4C34: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000E4C38: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000E4C3C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000E4C40: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C44: BF870095
	.long 0xd71c003a                                           // 0000000E4C48: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4C4C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4C50: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4C54: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C5C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000E4C60: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000E4C68: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C70: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4C74: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000E4C7C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C80: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000E4C84: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000E4C8C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000E4C90: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4C98: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000E4C9C: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000E4CA0: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4CA8: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000E4CAC: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000E4CB0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4CB8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000E4CBC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4CC4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000E4CCC: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4CD8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000E4CDC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000E4CE4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4CF0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4CF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E4CFC: BE882006
	s_cbranch_execz 60826                                      // 0000000E4D00: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a6c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000E4D04: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E4D10: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4D18: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4D1C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4D20: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E4D24: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E4D2C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000E4D38: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4D3C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000E4D40: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4D44: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000E4D4C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4D54: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000E4D58: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000E4D5C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000E4D60: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4D64: BF870095
	.long 0xd71c003a                                           // 0000000E4D68: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4D6C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4D70: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4D74: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4D7C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000E4D80: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E4D8C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4D90: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4D94: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000E4D9C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4DA0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000E4DA4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000E4DAC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000E4DB0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4DB8: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000E4DBC: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000E4DC0: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4DC8: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000E4DCC: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000E4DD0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4DD8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000E4DDC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4DE4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000E4DEC: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4DF8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000E4DFC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000E4E04: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4E10: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4E18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E4E1C: BE882007
	s_cbranch_execz 60757                                      // 0000000E4E20: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a78>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000E4E24: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000E4E30: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4E38: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4E3C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4E40: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E4E44: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E4E4C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000E4E58: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4E5C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000E4E60: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4E64: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000E4E6C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4E74: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000E4E78: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000E4E7C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000E4E80: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4E84: BF870095
	.long 0xd71c003a                                           // 0000000E4E88: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4E8C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4E90: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4E94: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4E9C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000E4EA0: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E4EAC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4EB0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000E4EB4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000E4EBC: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4EC0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000E4EC4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000E4ECC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000E4ED0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4ED8: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000E4EDC: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000E4EE0: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4EE8: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000E4EEC: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000E4EF0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4EF8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000E4EFC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000E4F04: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000E4F0C: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4F18: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000E4F1C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000E4F24: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000E4F30: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E4F38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E4F3C: BE882000
	s_cbranch_execz 60688                                      // 0000000E4F40: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a84>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000E4F44: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000E4F50: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000E4F54: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000E4F5C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000E4F60: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4F64: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000E4F68: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000E4F70: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000E4F7C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E4F80: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000E4F84: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000E4F88: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000E4F90: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E4F98: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000E4F9C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000E4FA0: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000E4FA4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4FA8: BF870095
	.long 0xd71c003a                                           // 0000000E4FAC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000E4FB0: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000E4FB4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000E4FB8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4FC0: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000E4FC4: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000E4FCC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4FD0: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000E4FD4: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000E4FDC: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4FE0: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000E4FE4: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000E4FEC: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000E4FF0: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E4FF8: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000E4FFC: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000E5000: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5008: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000E500C: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000E5010: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5018: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000E501C: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000E5024: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000E502C: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5038: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000E503C: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000E5044: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000E5050: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5058: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E505C: BE882001
	s_cbranch_execz 60619                                      // 0000000E5060: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a90>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000E5064: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000E5070: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000E5074: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000E507C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E5080: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5084: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000E5088: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5090: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000E5098: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000E50A4: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E50A8: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000E50AC: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000E50B4: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E50B8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000E50BC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000E50C0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000E50C4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E50C8: BF870095
	.long 0xd71c0039                                           // 0000000E50CC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000E50D0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000E50D4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E50D8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E50E0: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000E50E4: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E50EC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E50F0: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000E50F4: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000E50FC: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5100: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000E5104: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000E510C: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000E5110: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5118: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000E511C: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000E5120: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5128: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000E512C: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000E5130: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5138: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000E513C: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000E5144: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000E514C: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5158: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000E515C: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000E5164: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000E5170: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5178: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E517C: BE882002
	s_cbranch_execz 60550                                      // 0000000E5180: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a9c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000E5184: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E5190: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E5198: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E519C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E51A0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E51A4: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000E51AC: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000E51B8: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E51BC: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000E51C0: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E51C4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000E51CC: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E51D4: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000E51D8: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000E51DC: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000E51E0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E51E4: BF870095
	.long 0xd71c0032                                           // 0000000E51E8: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000E51EC: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E51F0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E51F4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E51FC: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000E5200: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E520C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5210: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E5214: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000E521C: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5220: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000E5224: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000E522C: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000E5230: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5238: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000E523C: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000E5240: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5248: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000E524C: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000E5250: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5258: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000E525C: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E5264: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000E526C: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5278: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000E527C: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000E5284: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E5290: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5298: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E529C: BE882003
	s_cbranch_execz 60481                                      // 0000000E52A0: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3aa8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000E52A4: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E52B0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E52B8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E52BC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E52C0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E52C4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E52CC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000E52D8: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E52DC: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000E52E0: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000E52EC: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000E52F0: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E52F4: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E52FC: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000E5300: 7E644B32
	.long 0xd71c0032                                           // 0000000E5304: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E5308: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E530C: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E5310: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E5314: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000E531C: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5328: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E532C: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E5330: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E5338: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000E533C: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000E5340: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E5348: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000E534C: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000E5350: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000E5358: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E535C: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000E5360: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000E5368: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E536C: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000E5370: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000E5378: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5380: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E5384: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000E538C: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000E5398: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E53A0: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000E53A4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E53B0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E53B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E53BC: BE882004
	s_cbranch_execz 60412                                      // 0000000E53C0: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ab4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000E53C4: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E53D0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E53D8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E53DC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E53E0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E53E4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E53EC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000E53F8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E53FC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000E5400: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5404: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000E540C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5414: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000E5418: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000E541C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000E5420: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5424: BF870095
	.long 0xd71c0032                                           // 0000000E5428: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E542C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E5430: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E5434: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E543C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000E5440: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E544C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5450: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E5454: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000E545C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5460: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000E5464: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000E546C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000E5470: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5478: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000E547C: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000E5480: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5488: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000E548C: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000E5490: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5498: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000E549C: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E54A4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000E54AC: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E54B8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000E54BC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000E54C4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E54D0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E54D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E54DC: BE882005
	s_cbranch_execz 60343                                      // 0000000E54E0: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ac0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000E54E4: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E54F0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E54F8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E54FC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5500: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E5504: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E550C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000E5518: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E551C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000E5520: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5524: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000E552C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5534: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000E5538: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000E553C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000E5540: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5544: BF870095
	.long 0xd71c0032                                           // 0000000E5548: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E554C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E5550: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E5554: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E555C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000E5560: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000E5568: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5570: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E5574: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000E557C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5580: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000E5584: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000E558C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000E5590: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5598: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000E559C: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000E55A0: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E55A8: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000E55AC: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000E55B0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E55B8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000E55BC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E55C4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000E55CC: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E55D8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000E55DC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000E55E4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E55F0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E55F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E55FC: BE882006
	s_cbranch_execz 60274                                      // 0000000E5600: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3acc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000E5604: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E5610: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E5618: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E561C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5620: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E5624: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E562C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000E5638: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E563C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000E5640: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5644: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000E564C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5654: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000E5658: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000E565C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000E5660: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5664: BF870095
	.long 0xd71c0032                                           // 0000000E5668: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E566C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E5670: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E5674: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E567C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000E5680: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E568C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5690: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E5694: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000E569C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E56A0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000E56A4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000E56AC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000E56B0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E56B8: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000E56BC: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000E56C0: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E56C8: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000E56CC: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000E56D0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E56D8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000E56DC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E56E4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000E56EC: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E56F8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000E56FC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000E5704: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E5710: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5718: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E571C: BE882007
	s_cbranch_execz 60205                                      // 0000000E5720: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ad8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000E5724: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000E5730: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E5738: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E573C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5740: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E5744: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E574C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000E5758: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E575C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000E5760: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5764: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000E576C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5774: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000E5778: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000E577C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000E5780: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5784: BF870095
	.long 0xd71c0032                                           // 0000000E5788: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E578C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E5790: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E5794: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E579C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000E57A0: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E57AC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E57B0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000E57B4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000E57BC: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E57C0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000E57C4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000E57CC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000E57D0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E57D8: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000E57DC: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000E57E0: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E57E8: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000E57EC: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000E57F0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E57F8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000E57FC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000E5804: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000E580C: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5818: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000E581C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000E5824: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000E5830: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5838: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E583C: BE882000
	s_cbranch_execz 60136                                      // 0000000E5840: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ae4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000E5844: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000E5850: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000E5854: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000E585C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000E5860: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5864: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000E5868: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000E5870: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000E587C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E5880: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000E5884: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000E5888: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000E5890: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5898: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000E589C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000E58A0: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000E58A4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E58A8: BF870095
	.long 0xd71c0032                                           // 0000000E58AC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000E58B0: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000E58B4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000E58B8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E58C0: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000E58C4: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000E58CC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E58D0: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000E58D4: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000E58DC: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E58E0: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000E58E4: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000E58EC: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000E58F0: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E58F8: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000E58FC: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000E5900: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5908: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000E590C: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000E5910: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5918: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000E591C: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000E5924: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000E592C: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5938: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000E593C: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000E5944: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000E5950: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5958: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E595C: BE882001
	s_cbranch_execz 60067                                      // 0000000E5960: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3af0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000E5964: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000E5970: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000E5974: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000E597C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5980: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5984: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000E5988: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5990: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000E5998: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000E59A4: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E59A8: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000E59AC: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000E59B4: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E59B8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000E59BC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000E59C0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000E59C4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E59C8: BF870095
	.long 0xd71c0031                                           // 0000000E59CC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000E59D0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000E59D4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E59D8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E59E0: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000E59E4: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E59EC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E59F0: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000E59F4: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000E59FC: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5A00: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000E5A04: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000E5A0C: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000E5A10: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5A18: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000E5A1C: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000E5A20: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5A28: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000E5A2C: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000E5A30: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5A38: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000E5A3C: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000E5A44: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000E5A4C: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5A58: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000E5A5C: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000E5A64: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000E5A70: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5A78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E5A7C: BE882002
	s_cbranch_execz 59998                                      // 0000000E5A80: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3afc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000E5A84: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E5A90: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E5A98: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5A9C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5AA0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E5AA4: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000E5AAC: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000E5AB8: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E5ABC: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000E5AC0: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5AC4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000E5ACC: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5AD4: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000E5AD8: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000E5ADC: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000E5AE0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5AE4: BF870095
	.long 0xd71c002a                                           // 0000000E5AE8: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000E5AEC: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E5AF0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E5AF4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5AFC: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000E5B00: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E5B0C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B10: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E5B14: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000E5B1C: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B20: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000E5B24: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000E5B2C: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000E5B30: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B38: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000E5B3C: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000E5B40: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B48: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000E5B4C: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000E5B50: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B58: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000E5B5C: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E5B64: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000E5B6C: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5B78: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000E5B7C: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000E5B84: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E5B90: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5B98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E5B9C: BE882003
	s_cbranch_execz 59929                                      // 0000000E5BA0: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b08>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000E5BA4: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E5BB0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E5BB8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5BBC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5BC0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E5BC4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E5BCC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000E5BD8: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5BDC: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000E5BE0: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000E5BEC: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000E5BF0: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5BF4: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E5BFC: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000E5C00: 7E544B2A
	.long 0xd71c002a                                           // 0000000E5C04: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E5C08: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5C0C: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E5C10: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E5C14: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000E5C1C: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5C28: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E5C2C: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E5C30: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E5C38: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000E5C3C: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000E5C40: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E5C48: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000E5C4C: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000E5C50: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000E5C58: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5C5C: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000E5C60: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000E5C68: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5C6C: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000E5C70: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000E5C78: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5C80: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E5C84: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000E5C8C: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000E5C98: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E5CA0: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000E5CA4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E5CB0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5CB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E5CBC: BE882004
	s_cbranch_execz 59860                                      // 0000000E5CC0: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b14>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000E5CC4: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E5CD0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E5CD8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5CDC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5CE0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E5CE4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E5CEC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000E5CF8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E5CFC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000E5D00: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5D04: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000E5D0C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5D14: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000E5D18: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000E5D1C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000E5D20: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D24: BF870095
	.long 0xd71c002a                                           // 0000000E5D28: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E5D2C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E5D30: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E5D34: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D3C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000E5D40: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E5D4C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D50: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E5D54: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000E5D5C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D60: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000E5D64: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000E5D6C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000E5D70: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D78: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000E5D7C: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000E5D80: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D88: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000E5D8C: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000E5D90: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5D98: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000E5D9C: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E5DA4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000E5DAC: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5DB8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000E5DBC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000E5DC4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E5DD0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5DD8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E5DDC: BE882005
	s_cbranch_execz 59791                                      // 0000000E5DE0: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b20>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000E5DE4: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E5DF0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E5DF8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5DFC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E00: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E5E04: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E5E0C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000E5E18: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E5E1C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000E5E20: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5E24: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000E5E2C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5E34: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000E5E38: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000E5E3C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000E5E40: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E44: BF870095
	.long 0xd71c002a                                           // 0000000E5E48: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E5E4C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E5E50: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E5E54: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E5C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000E5E60: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000E5E68: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E70: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E5E74: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000E5E7C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E80: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000E5E84: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000E5E8C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000E5E90: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5E98: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000E5E9C: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000E5EA0: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5EA8: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000E5EAC: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000E5EB0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5EB8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000E5EBC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E5EC4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000E5ECC: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5ED8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000E5EDC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000E5EE4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E5EF0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E5EF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E5EFC: BE882006
	s_cbranch_execz 59722                                      // 0000000E5F00: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b2c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000E5F04: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E5F10: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E5F18: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E5F1C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5F20: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E5F24: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E5F2C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000E5F38: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E5F3C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000E5F40: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E5F44: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000E5F4C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E5F54: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000E5F58: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000E5F5C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000E5F60: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5F64: BF870095
	.long 0xd71c002a                                           // 0000000E5F68: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E5F6C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E5F70: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E5F74: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5F7C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000E5F80: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E5F8C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5F90: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E5F94: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000E5F9C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5FA0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000E5FA4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000E5FAC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000E5FB0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5FB8: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000E5FBC: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000E5FC0: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5FC8: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000E5FCC: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000E5FD0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5FD8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000E5FDC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E5FE4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000E5FEC: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E5FF8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000E5FFC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000E6004: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E6010: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6018: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E601C: BE882007
	s_cbranch_execz 59653                                      // 0000000E6020: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b38>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000E6024: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000E6030: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E6038: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E603C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6040: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E6044: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E604C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000E6058: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E605C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000E6060: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E6064: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000E606C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6074: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000E6078: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000E607C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000E6080: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6084: BF870095
	.long 0xd71c002a                                           // 0000000E6088: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E608C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E6090: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E6094: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E609C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000E60A0: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E60AC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E60B0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000E60B4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000E60BC: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E60C0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000E60C4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000E60CC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000E60D0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E60D8: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000E60DC: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000E60E0: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E60E8: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000E60EC: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000E60F0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E60F8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000E60FC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000E6104: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000E610C: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6118: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000E611C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000E6124: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000E6130: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6138: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E613C: BE882000
	s_cbranch_execz 59584                                      // 0000000E6140: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b44>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000E6144: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000E6150: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000E6154: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000E615C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000E6160: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6164: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000E6168: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000E6170: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000E617C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E6180: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000E6184: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000E6188: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000E6190: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6198: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000E619C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000E61A0: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000E61A4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E61A8: BF870095
	.long 0xd71c002a                                           // 0000000E61AC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000E61B0: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000E61B4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000E61B8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E61C0: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000E61C4: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000E61CC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E61D0: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000E61D4: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000E61DC: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E61E0: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000E61E4: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000E61EC: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000E61F0: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E61F8: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000E61FC: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000E6200: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6208: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000E620C: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000E6210: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6218: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000E621C: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000E6224: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000E622C: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6238: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000E623C: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000E6244: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000E6250: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6258: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E625C: BE882001
	s_cbranch_execz 59515                                      // 0000000E6260: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b50>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000E6264: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000E6270: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000E6274: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000E627C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E6280: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6284: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000E6288: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6290: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000E6298: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000E62A4: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E62A8: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000E62AC: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000E62B4: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E62B8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000E62BC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000E62C0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000E62C4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E62C8: BF870095
	.long 0xd71c0029                                           // 0000000E62CC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000E62D0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000E62D4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E62D8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E62E0: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000E62E4: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E62EC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E62F0: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000E62F4: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000E62FC: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6300: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000E6304: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000E630C: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000E6310: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6318: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000E631C: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000E6320: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6328: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000E632C: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000E6330: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6338: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000E633C: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000E6344: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000E634C: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6358: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000E635C: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000E6364: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000E6370: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6378: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E637C: BE882002
	s_cbranch_execz 59446                                      // 0000000E6380: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b5c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000E6384: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E6390: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E6398: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E639C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E63A0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E63A4: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000E63AC: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000E63B8: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E63BC: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000E63C0: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E63C4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000E63CC: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E63D4: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000E63D8: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000E63DC: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000E63E0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E63E4: BF870095
	.long 0xd71c0022                                           // 0000000E63E8: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000E63EC: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E63F0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E63F4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E63FC: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000E6400: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E640C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6410: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E6414: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000E641C: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6420: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000E6424: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000E642C: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000E6430: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6438: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000E643C: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000E6440: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6448: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000E644C: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000E6450: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6458: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000E645C: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E6464: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000E646C: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6478: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000E647C: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000E6484: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E6490: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6498: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E649C: BE882003
	s_cbranch_execz 59377                                      // 0000000E64A0: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b68>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000E64A4: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E64B0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E64B8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E64BC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E64C0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E64C4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E64CC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000E64D8: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E64DC: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000E64E0: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000E64EC: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000E64F0: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E64F4: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E64FC: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000E6500: 7E444B22
	.long 0xd71c0022                                           // 0000000E6504: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E6508: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E650C: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6510: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6514: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000E651C: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6528: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E652C: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E6530: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E6538: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000E653C: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000E6540: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E6548: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000E654C: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000E6550: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000E6558: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E655C: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000E6560: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000E6568: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E656C: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000E6570: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000E6578: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6580: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E6584: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000E658C: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000E6598: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E65A0: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000E65A4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E65B0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E65B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E65BC: BE882004
	s_cbranch_execz 59308                                      // 0000000E65C0: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b74>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000E65C4: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E65D0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E65D8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E65DC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E65E0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E65E4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E65EC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000E65F8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E65FC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000E6600: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6604: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000E660C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6614: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000E6618: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000E661C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000E6620: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6624: BF870095
	.long 0xd71c0022                                           // 0000000E6628: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E662C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6630: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6634: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E663C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000E6640: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E664C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6650: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E6654: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000E665C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6660: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000E6664: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000E666C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000E6670: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6678: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000E667C: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000E6680: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6688: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000E668C: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000E6690: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6698: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000E669C: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E66A4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000E66AC: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E66B8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000E66BC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000E66C4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E66D0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E66D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E66DC: BE882005
	s_cbranch_execz 59239                                      // 0000000E66E0: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b80>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000E66E4: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E66F0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E66F8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E66FC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6700: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E6704: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E670C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000E6718: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E671C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000E6720: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6724: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000E672C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6734: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000E6738: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000E673C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000E6740: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6744: BF870095
	.long 0xd71c0022                                           // 0000000E6748: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E674C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6750: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6754: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E675C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000E6760: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000E6768: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6770: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E6774: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000E677C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6780: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000E6784: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000E678C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000E6790: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6798: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000E679C: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000E67A0: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E67A8: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000E67AC: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000E67B0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E67B8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000E67BC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E67C4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000E67CC: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E67D8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000E67DC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000E67E4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E67F0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E67F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E67FC: BE882006
	s_cbranch_execz 59170                                      // 0000000E6800: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b8c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000E6804: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E6810: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E6818: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E681C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6820: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E6824: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E682C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000E6838: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E683C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000E6840: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6844: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000E684C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6854: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000E6858: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000E685C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000E6860: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6864: BF870095
	.long 0xd71c0022                                           // 0000000E6868: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E686C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6870: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6874: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E687C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000E6880: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E688C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6890: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E6894: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000E689C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E68A0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000E68A4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000E68AC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000E68B0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E68B8: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000E68BC: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000E68C0: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E68C8: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000E68CC: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000E68D0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E68D8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000E68DC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E68E4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000E68EC: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E68F8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000E68FC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000E6904: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E6910: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6918: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E691C: BE882007
	s_cbranch_execz 59101                                      // 0000000E6920: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b98>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000E6924: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000E6930: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E6938: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E693C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6940: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E6944: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E694C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000E6958: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E695C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000E6960: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6964: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000E696C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6974: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000E6978: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000E697C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000E6980: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6984: BF870095
	.long 0xd71c0022                                           // 0000000E6988: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E698C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6990: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6994: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E699C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000E69A0: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E69AC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E69B0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000E69B4: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000E69BC: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E69C0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000E69C4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000E69CC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000E69D0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E69D8: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000E69DC: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000E69E0: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E69E8: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000E69EC: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000E69F0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E69F8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000E69FC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000E6A04: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000E6A0C: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6A18: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000E6A1C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000E6A24: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000E6A30: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6A38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E6A3C: BE882000
	s_cbranch_execz 59032                                      // 0000000E6A40: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ba4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000E6A44: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000E6A50: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000E6A54: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000E6A5C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000E6A60: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6A64: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000E6A68: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000E6A70: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000E6A7C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E6A80: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000E6A84: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000E6A88: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000E6A90: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6A98: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000E6A9C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000E6AA0: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000E6AA4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6AA8: BF870095
	.long 0xd71c0022                                           // 0000000E6AAC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000E6AB0: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000E6AB4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000E6AB8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6AC0: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000E6AC4: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000E6ACC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6AD0: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000E6AD4: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000E6ADC: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6AE0: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000E6AE4: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000E6AEC: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000E6AF0: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6AF8: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000E6AFC: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000E6B00: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6B08: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000E6B0C: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000E6B10: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6B18: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000E6B1C: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000E6B24: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000E6B2C: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6B38: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000E6B3C: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000E6B44: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000E6B50: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6B58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E6B5C: BE882001
	s_cbranch_execz 58963                                      // 0000000E6B60: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bb0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000E6B64: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000E6B70: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000E6B74: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000E6B7C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E6B80: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6B84: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000E6B88: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E6B90: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000E6B98: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000E6BA4: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E6BA8: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000E6BAC: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000E6BB4: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6BB8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000E6BBC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000E6BC0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000E6BC4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6BC8: BF870095
	.long 0xd71c0021                                           // 0000000E6BCC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000E6BD0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000E6BD4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E6BD8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6BE0: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000E6BE4: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E6BEC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6BF0: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000E6BF4: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000E6BFC: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6C00: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000E6C04: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000E6C0C: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000E6C10: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6C18: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000E6C1C: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000E6C20: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6C28: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000E6C2C: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000E6C30: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6C38: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000E6C3C: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000E6C44: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000E6C4C: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6C58: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000E6C5C: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000E6C64: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000E6C70: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6C78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E6C7C: BE882002
	s_cbranch_execz 58894                                      // 0000000E6C80: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bbc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000E6C84: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E6C90: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E6C98: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E6C9C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6CA0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E6CA4: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000E6CAC: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000E6CB8: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E6CBC: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000E6CC0: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E6CC4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000E6CCC: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6CD4: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000E6CD8: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000E6CDC: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000E6CE0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6CE4: BF870095
	.long 0xd71c001a                                           // 0000000E6CE8: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000E6CEC: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E6CF0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E6CF4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6CFC: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000E6D00: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E6D0C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D10: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E6D14: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000E6D1C: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D20: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000E6D24: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000E6D2C: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000E6D30: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D38: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000E6D3C: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000E6D40: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D48: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000E6D4C: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000E6D50: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D58: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000E6D5C: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E6D64: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000E6D6C: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6D78: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000E6D7C: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000E6D84: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E6D90: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6D98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E6D9C: BE882003
	s_cbranch_execz 58825                                      // 0000000E6DA0: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bc8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000E6DA4: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E6DB0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E6DB8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E6DBC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6DC0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E6DC4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E6DCC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000E6DD8: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6DDC: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000E6DE0: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000E6DEC: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000E6DF0: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E6DF4: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E6DFC: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000E6E00: 7E344B1A
	.long 0xd71c001a                                           // 0000000E6E04: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E6E08: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6E0C: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E6E10: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E6E14: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000E6E1C: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6E28: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E6E2C: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E6E30: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E6E38: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000E6E3C: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000E6E40: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E6E48: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000E6E4C: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000E6E50: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000E6E58: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6E5C: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000E6E60: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000E6E68: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6E6C: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000E6E70: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000E6E78: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6E80: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E6E84: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000E6E8C: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000E6E98: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E6EA0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000E6EA4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E6EB0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6EB8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E6EBC: BE882004
	s_cbranch_execz 58756                                      // 0000000E6EC0: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bd4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000E6EC4: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E6ED0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E6ED8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E6EDC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6EE0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E6EE4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E6EEC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000E6EF8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E6EFC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000E6F00: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E6F04: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000E6F0C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E6F14: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000E6F18: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000E6F1C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000E6F20: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F24: BF870095
	.long 0xd71c001a                                           // 0000000E6F28: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E6F2C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E6F30: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E6F34: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F3C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000E6F40: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E6F4C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F50: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E6F54: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000E6F5C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F60: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000E6F64: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000E6F6C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000E6F70: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F78: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000E6F7C: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000E6F80: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F88: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000E6F8C: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000E6F90: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6F98: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000E6F9C: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E6FA4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000E6FAC: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E6FB8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000E6FBC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000E6FC4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E6FD0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E6FD8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E6FDC: BE882005
	s_cbranch_execz 58687                                      // 0000000E6FE0: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3be0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000E6FE4: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E6FF0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E6FF8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E6FFC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7000: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E7004: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E700C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000E7018: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E701C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000E7020: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E7024: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000E702C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7034: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000E7038: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000E703C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000E7040: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7044: BF870095
	.long 0xd71c001a                                           // 0000000E7048: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E704C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E7050: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E7054: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E705C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000E7060: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000E7068: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7070: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E7074: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000E707C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7080: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000E7084: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000E708C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000E7090: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7098: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000E709C: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000E70A0: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E70A8: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000E70AC: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000E70B0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E70B8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000E70BC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E70C4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000E70CC: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E70D8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000E70DC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000E70E4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E70F0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E70F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E70FC: BE882006
	s_cbranch_execz 58618                                      // 0000000E7100: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bec>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000E7104: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E7110: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E7118: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E711C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7120: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E7124: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E712C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000E7138: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E713C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000E7140: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E7144: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000E714C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7154: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000E7158: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000E715C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000E7160: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7164: BF870095
	.long 0xd71c001a                                           // 0000000E7168: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E716C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E7170: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E7174: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E717C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000E7180: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E718C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7190: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E7194: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000E719C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E71A0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000E71A4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000E71AC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000E71B0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E71B8: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000E71BC: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000E71C0: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E71C8: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000E71CC: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000E71D0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E71D8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000E71DC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E71E4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000E71EC: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E71F8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000E71FC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000E7204: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E7210: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7218: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E721C: BE882007
	s_cbranch_execz 58549                                      // 0000000E7220: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bf8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000E7224: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000E7230: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E7238: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E723C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7240: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E7244: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E724C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000E7258: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E725C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000E7260: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E7264: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000E726C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7274: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000E7278: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000E727C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000E7280: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7284: BF870095
	.long 0xd71c001a                                           // 0000000E7288: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E728C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E7290: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E7294: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E729C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000E72A0: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E72AC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E72B0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000E72B4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000E72BC: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E72C0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000E72C4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000E72CC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000E72D0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E72D8: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000E72DC: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000E72E0: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E72E8: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000E72EC: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000E72F0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E72F8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000E72FC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000E7304: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000E730C: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7318: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000E731C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000E7324: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000E7330: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7338: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E733C: BE882000
	s_cbranch_execz 58480                                      // 0000000E7340: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c04>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000E7344: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000E7350: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000E7354: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000E735C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000E7360: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7364: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000E7368: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000E7370: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000E737C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E7380: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000E7384: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000E7388: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000E7390: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7398: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000E739C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000E73A0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000E73A4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E73A8: BF870095
	.long 0xd71c001a                                           // 0000000E73AC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000E73B0: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000E73B4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000E73B8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E73C0: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000E73C4: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000E73CC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E73D0: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000E73D4: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000E73DC: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E73E0: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000E73E4: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000E73EC: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000E73F0: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E73F8: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000E73FC: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000E7400: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7408: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000E740C: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000E7410: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7418: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000E741C: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000E7424: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000E742C: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7438: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000E743C: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000E7444: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000E7450: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7458: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E745C: BE882001
	s_cbranch_execz 58411                                      // 0000000E7460: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c10>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000E7464: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000E7470: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000E7474: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000E747C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E7480: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7484: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000E7488: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7490: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000E7498: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000E74A4: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E74A8: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000E74AC: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000E74B4: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E74B8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000E74BC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000E74C0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000E74C4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E74C8: BF870095
	.long 0xd71c0019                                           // 0000000E74CC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000E74D0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000E74D4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E74D8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E74E0: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000E74E4: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E74EC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E74F0: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000E74F4: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000E74FC: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7500: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000E7504: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000E750C: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000E7510: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7518: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000E751C: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000E7520: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7528: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000E752C: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000E7530: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7538: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000E753C: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000E7544: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000E754C: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7558: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000E755C: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000E7564: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000E7570: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7578: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E757C: BE882002
	s_cbranch_execz 58342                                      // 0000000E7580: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c1c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000E7584: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E7590: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E7598: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E759C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E75A0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E75A4: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000E75AC: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000E75B8: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E75BC: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000E75C0: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E75C4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000E75CC: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E75D4: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000E75D8: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000E75DC: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000E75E0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E75E4: BF870095
	.long 0xd71c0012                                           // 0000000E75E8: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000E75EC: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E75F0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E75F4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E75FC: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000E7600: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E760C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7610: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7614: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000E761C: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7620: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000E7624: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000E762C: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000E7630: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7638: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000E763C: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000E7640: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7648: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000E764C: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000E7650: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7658: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000E765C: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E7664: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000E766C: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7678: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000E767C: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000E7684: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E7690: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7698: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E769C: BE882003
	s_cbranch_execz 58273                                      // 0000000E76A0: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c28>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000E76A4: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E76B0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E76B8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E76BC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E76C0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E76C4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E76CC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000E76D8: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E76DC: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000E76E0: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000E76EC: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000E76F0: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E76F4: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E76FC: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000E7700: 7E244B12
	.long 0xd71c0012                                           // 0000000E7704: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E7708: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E770C: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7710: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7714: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000E771C: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7728: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E772C: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7730: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E7738: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000E773C: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000E7740: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E7748: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000E774C: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000E7750: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000E7758: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E775C: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000E7760: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000E7768: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E776C: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000E7770: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000E7778: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7780: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E7784: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000E778C: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000E7798: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E77A0: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000E77A4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E77B0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E77B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E77BC: BE882004
	s_cbranch_execz 58204                                      // 0000000E77C0: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c34>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000E77C4: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E77D0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E77D8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E77DC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E77E0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E77E4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E77EC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000E77F8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E77FC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000E7800: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7804: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000E780C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7814: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000E7818: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000E781C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000E7820: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7824: BF870095
	.long 0xd71c0012                                           // 0000000E7828: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E782C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7830: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7834: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E783C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000E7840: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E784C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7850: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7854: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000E785C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7860: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000E7864: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000E786C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000E7870: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7878: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000E787C: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000E7880: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7888: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000E788C: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000E7890: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7898: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000E789C: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E78A4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000E78AC: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E78B8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000E78BC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000E78C4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E78D0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E78D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E78DC: BE882005
	s_cbranch_execz 58135                                      // 0000000E78E0: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c40>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000E78E4: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E78F0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E78F8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E78FC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7900: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E7904: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E790C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000E7918: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E791C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000E7920: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7924: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000E792C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7934: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000E7938: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000E793C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000E7940: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7944: BF870095
	.long 0xd71c0012                                           // 0000000E7948: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E794C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7950: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7954: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E795C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000E7960: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000E7968: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7970: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7974: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000E797C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7980: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000E7984: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000E798C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000E7990: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7998: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000E799C: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000E79A0: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E79A8: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000E79AC: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000E79B0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E79B8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000E79BC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E79C4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000E79CC: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E79D8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000E79DC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000E79E4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E79F0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E79F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E79FC: BE882006
	s_cbranch_execz 58066                                      // 0000000E7A00: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c4c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000E7A04: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E7A10: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E7A18: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E7A1C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7A20: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E7A24: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E7A2C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000E7A38: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E7A3C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000E7A40: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7A44: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000E7A4C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7A54: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000E7A58: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000E7A5C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000E7A60: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7A64: BF870095
	.long 0xd71c0012                                           // 0000000E7A68: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E7A6C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7A70: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7A74: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7A7C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000E7A80: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E7A8C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7A90: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7A94: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000E7A9C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7AA0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000E7AA4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000E7AAC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000E7AB0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7AB8: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000E7ABC: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000E7AC0: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7AC8: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000E7ACC: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000E7AD0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7AD8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000E7ADC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E7AE4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000E7AEC: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7AF8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000E7AFC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000E7B04: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E7B10: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7B18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E7B1C: BE882007
	s_cbranch_execz 57997                                      // 0000000E7B20: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c58>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000E7B24: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000E7B30: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E7B38: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E7B3C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7B40: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E7B44: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E7B4C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000E7B58: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E7B5C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000E7B60: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7B64: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000E7B6C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7B74: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000E7B78: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000E7B7C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000E7B80: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7B84: BF870095
	.long 0xd71c0012                                           // 0000000E7B88: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E7B8C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7B90: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7B94: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7B9C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000E7BA0: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E7BAC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7BB0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000E7BB4: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000E7BBC: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7BC0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000E7BC4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000E7BCC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000E7BD0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7BD8: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000E7BDC: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000E7BE0: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7BE8: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000E7BEC: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000E7BF0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7BF8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000E7BFC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000E7C04: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000E7C0C: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7C18: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000E7C1C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000E7C24: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000E7C30: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7C38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E7C3C: BE882000
	s_cbranch_execz 57928                                      // 0000000E7C40: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c64>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000E7C44: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000E7C50: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000E7C54: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000E7C5C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000E7C60: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7C64: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000E7C68: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000E7C70: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000E7C7C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E7C80: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000E7C84: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000E7C88: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000E7C90: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7C98: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000E7C9C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000E7CA0: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000E7CA4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7CA8: BF870095
	.long 0xd71c0012                                           // 0000000E7CAC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000E7CB0: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000E7CB4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000E7CB8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7CC0: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000E7CC4: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000E7CCC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7CD0: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000E7CD4: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000E7CDC: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7CE0: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000E7CE4: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000E7CEC: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000E7CF0: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7CF8: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000E7CFC: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000E7D00: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7D08: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000E7D0C: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000E7D10: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7D18: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000E7D1C: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000E7D24: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000E7D2C: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7D38: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000E7D3C: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000E7D44: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000E7D50: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7D58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000E7D5C: BE882001
	s_cbranch_execz 57859                                      // 0000000E7D60: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c70>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000E7D64: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000E7D70: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000E7D74: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000E7D7C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E7D80: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7D84: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000E7D88: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E7D90: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000E7D98: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000E7DA4: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E7DA8: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000E7DAC: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000E7DB4: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7DB8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000E7DBC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000E7DC0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000E7DC4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7DC8: BF870095
	.long 0xd71c0011                                           // 0000000E7DCC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000E7DD0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000E7DD4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E7DD8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7DE0: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000E7DE4: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E7DEC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7DF0: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000E7DF4: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000E7DFC: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7E00: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000E7E04: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000E7E0C: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000E7E10: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7E18: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000E7E1C: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000E7E20: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7E28: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000E7E2C: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000E7E30: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7E38: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000E7E3C: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000E7E44: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000E7E4C: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7E58: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000E7E5C: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000E7E64: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000E7E70: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7E78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000E7E7C: BE882002
	s_cbranch_execz 57790                                      // 0000000E7E80: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c7c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000E7E84: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E7E90: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E7E98: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E7E9C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7EA0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E7EA4: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000E7EAC: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000E7EB8: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E7EBC: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000E7EC0: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E7EC4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000E7ECC: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E7ED4: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000E7ED8: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000E7EDC: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000E7EE0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7EE4: BF870095
	.long 0xd71c000a                                           // 0000000E7EE8: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000E7EEC: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E7EF0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E7EF4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7EFC: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000E7F00: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E7F0C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F10: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E7F14: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000E7F1C: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F20: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000E7F24: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000E7F2C: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000E7F30: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F38: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000E7F3C: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000E7F40: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F48: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000E7F4C: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000E7F50: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F58: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000E7F5C: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E7F64: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000E7F6C: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7F78: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000E7F7C: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000E7F84: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E7F90: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E7F98: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000E7F9C: BE882003
	s_cbranch_execz 57721                                      // 0000000E7FA0: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c88>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000E7FA4: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E7FB0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E7FB8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E7FBC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7FC0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E7FC4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E7FCC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000E7FD8: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E7FDC: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000E7FE0: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000E7FEC: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000E7FF0: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E7FF4: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E7FFC: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000E8000: 7E144B0A
	.long 0xd71c000a                                           // 0000000E8004: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E8008: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E800C: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E8010: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E8014: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000E801C: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8028: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E802C: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E8030: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000E8038: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000E803C: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000E8040: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E8048: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000E804C: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000E8050: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000E8058: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E805C: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000E8060: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000E8068: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E806C: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000E8070: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000E8078: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8080: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E8084: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000E808C: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000E8098: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E80A0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000E80A4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E80B0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E80B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000E80BC: BE882004
	s_cbranch_execz 57652                                      // 0000000E80C0: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c94>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000E80C4: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E80D0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E80D8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E80DC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E80E0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E80E4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E80EC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000E80F8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E80FC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000E8100: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E8104: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000E810C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8114: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000E8118: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000E811C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000E8120: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8124: BF870095
	.long 0xd71c000a                                           // 0000000E8128: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E812C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E8130: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E8134: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E813C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000E8140: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E814C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8150: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E8154: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000E815C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8160: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000E8164: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000E816C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000E8170: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8178: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000E817C: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000E8180: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8188: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000E818C: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000E8190: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8198: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000E819C: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E81A4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000E81AC: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E81B8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000E81BC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000E81C4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E81D0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E81D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000E81DC: BE882005
	s_cbranch_execz 57583                                      // 0000000E81E0: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ca0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000E81E4: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E81F0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E81F8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E81FC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8200: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E8204: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E820C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000E8218: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E821C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000E8220: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E8224: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000E822C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8234: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000E8238: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000E823C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000E8240: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8244: BF870095
	.long 0xd71c000a                                           // 0000000E8248: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E824C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E8250: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E8254: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E825C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000E8260: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000E8268: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8270: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E8274: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000E827C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8280: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000E8284: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000E828C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000E8290: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8298: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000E829C: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000E82A0: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E82A8: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000E82AC: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000E82B0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E82B8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000E82BC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E82C4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000E82CC: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E82D8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000E82DC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000E82E4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E82F0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E82F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000E82FC: BE882006
	s_cbranch_execz 57514                                      // 0000000E8300: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cac>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000E8304: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E8310: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E8318: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E831C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8320: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E8324: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E832C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000E8338: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E833C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000E8340: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E8344: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000E834C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8354: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000E8358: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000E835C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000E8360: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8364: BF870095
	.long 0xd71c000a                                           // 0000000E8368: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E836C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E8370: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E8374: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E837C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000E8380: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E838C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8390: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E8394: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000E839C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E83A0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000E83A4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000E83AC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000E83B0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E83B8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000E83BC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000E83C0: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E83C8: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000E83CC: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000E83D0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E83D8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000E83DC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E83E4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000E83EC: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E83F8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000E83FC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000E8404: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E8410: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E8418: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000E841C: BE882007
	s_cbranch_execz 57445                                      // 0000000E8420: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cb8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000E8424: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000E8430: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E8438: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E843C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8440: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E8444: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E844C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000E8458: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E845C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000E8460: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E8464: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000E846C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8474: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000E8478: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000E847C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000E8480: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8484: BF870095
	.long 0xd71c000a                                           // 0000000E8488: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E848C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E8490: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E8494: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E849C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000E84A0: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E84AC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E84B0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000E84B4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000E84BC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E84C0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000E84C4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000E84CC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000E84D0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E84D8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000E84DC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000E84E0: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E84E8: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000E84EC: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000E84F0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E84F8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000E84FC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000E8504: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000E850C: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8518: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000E851C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000E8524: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000E8530: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E8538: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000E853C: BE882000
	s_cbranch_execz 57376                                      // 0000000E8540: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cc4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000E8544: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000E8550: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000E8554: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000E855C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000E8560: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8564: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000E8568: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000E8570: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000E857C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E8580: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000E8584: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000E8588: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000E8590: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8598: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000E859C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000E85A0: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000E85A4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E85A8: BF870095
	.long 0xd71c000a                                           // 0000000E85AC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000E85B0: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000E85B4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000E85B8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E85C0: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000E85C4: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000E85CC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E85D0: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000E85D4: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000E85DC: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E85E0: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000E85E4: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000E85EC: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000E85F0: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E85F8: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000E85FC: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000E8600: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8608: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000E860C: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000E8610: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8618: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000E861C: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000E8624: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000E862C: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8638: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000E863C: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000E8644: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000E8650: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E8658: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000E865C: BE802001
	s_cbranch_execz 57307                                      // 0000000E8660: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cd0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000E8664: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E8670: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E8678: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E867C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8680: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E8684: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000E868C: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000E8698: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E869C: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000E86A0: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000E86A4: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E86AC: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E86B4: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000E86B8: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000E86BC: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000E86C0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E86C4: BF870095
	.long 0xd71c0001                                           // 0000000E86C8: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000E86CC: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E86D0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E86D4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E86DC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000E86E0: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E86EC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E86F0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E86F4: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000E86FC: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8700: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000E8704: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000E870C: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000E8710: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8718: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000E871C: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000E8720: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8728: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000E872C: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000E8730: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8738: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000E873C: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8744: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000E874C: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8758: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000E875C: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000E8764: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8770: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E8778: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000E877C: BE802002
	s_cbranch_execz 57238                                      // 0000000E8780: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cdc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000E8784: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E8790: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E8798: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E879C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E87A0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E87A4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E87AC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000E87B8: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E87BC: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000E87C0: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E87C4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E87CC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E87D4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E87D8: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000E87DC: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000E87E0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E87E4: BF870095
	.long 0xd71c0001                                           // 0000000E87E8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E87EC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E87F0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E87F4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E87FC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000E8800: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E880C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8810: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8814: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E881C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8820: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000E8824: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000E882C: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000E8830: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8838: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000E883C: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000E8840: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8848: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000E884C: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000E8850: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8858: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000E885C: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8864: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000E886C: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8878: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E887C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E8884: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8890: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E8898: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000E889C: BE802003
	s_cbranch_execz 57169                                      // 0000000E88A0: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ce8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000E88A4: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E88B0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E88B8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E88BC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E88C0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E88C4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E88CC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000E88D8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E88DC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000E88E0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E88E4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E88EC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E88F4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E88F8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000E88FC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000E8900: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8904: BF870095
	.long 0xd71c0001                                           // 0000000E8908: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E890C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E8910: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E8914: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E891C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000E8920: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E892C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8930: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8934: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E893C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8940: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000E8944: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000E894C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000E8950: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8958: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000E895C: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000E8960: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8968: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000E896C: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000E8970: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8978: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000E897C: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8984: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000E898C: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8998: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E899C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E89A4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E89B0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E89B8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000E89BC: BE802004
	s_cbranch_execz 57100                                      // 0000000E89C0: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cf4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000E89C4: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E89D0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E89D8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E89DC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E89E0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E89E4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E89EC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000E89F8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E89FC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000E8A00: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E8A04: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E8A0C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8A14: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E8A18: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000E8A1C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000E8A20: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A24: BF870095
	.long 0xd71c0001                                           // 0000000E8A28: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E8A2C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E8A30: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E8A34: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A3C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000E8A40: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000E8A48: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A50: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8A54: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E8A5C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A60: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000E8A64: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000E8A6C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000E8A70: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A78: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000E8A7C: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000E8A80: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A88: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000E8A8C: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000E8A90: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8A98: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000E8A9C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8AA4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000E8AAC: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8AB8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E8ABC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E8AC4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8AD0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E8AD8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000E8ADC: BE802005
	s_cbranch_execz 57031                                      // 0000000E8AE0: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d00>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000E8AE4: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E8AF0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E8AF8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E8AFC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B00: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E8B04: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E8B0C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000E8B18: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E8B1C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000E8B20: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E8B24: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E8B2C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8B34: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E8B38: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000E8B3C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000E8B40: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B44: BF870095
	.long 0xd71c0001                                           // 0000000E8B48: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E8B4C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E8B50: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E8B54: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B5C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000E8B60: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E8B6C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B70: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8B74: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E8B7C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B80: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000E8B84: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000E8B8C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000E8B90: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8B98: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000E8B9C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000E8BA0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8BA8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000E8BAC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000E8BB0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8BB8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000E8BBC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8BC4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000E8BCC: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8BD8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E8BDC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E8BE4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8BF0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E8BF8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000E8BFC: BE802006
	s_cbranch_execz 56962                                      // 0000000E8C00: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d0c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000E8C04: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E8C10: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E8C18: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E8C1C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8C20: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E8C24: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E8C2C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000E8C38: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E8C3C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000E8C40: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E8C44: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E8C4C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8C54: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E8C58: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000E8C5C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000E8C60: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8C64: BF870095
	.long 0xd71c0001                                           // 0000000E8C68: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E8C6C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E8C70: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E8C74: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8C7C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000E8C80: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E8C8C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8C90: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8C94: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E8C9C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8CA0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000E8CA4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000E8CAC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000E8CB0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8CB8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000E8CBC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000E8CC0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8CC8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000E8CCC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000E8CD0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8CD8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000E8CDC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8CE4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000E8CEC: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8CF8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E8CFC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E8D04: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8D10: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E8D18: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000E8D1C: BE802007
	s_cbranch_execz 56893                                      // 0000000E8D20: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d18>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000E8D24: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000E8D30: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000E8D38: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000E8D3C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8D40: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000E8D44: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000E8D4C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000E8D58: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000E8D5C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000E8D60: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000E8D64: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000E8D6C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E8D74: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000E8D78: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000E8D7C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000E8D80: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8D84: BF870095
	.long 0xd71c0001                                           // 0000000E8D88: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000E8D8C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000E8D90: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000E8D94: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8D9C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000E8DA0: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000E8DAC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8DB0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000E8DB4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000E8DBC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8DC0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000E8DC4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000E8DCC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000E8DD0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8DD8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000E8DDC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000E8DE0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8DE8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000E8DEC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000E8DF0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8DF8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000E8DFC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000E8E04: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000E8E0C: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8E18: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000E8E1C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000E8E24: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000E8E30: DC9601E0 007C0200
	s_nop 0                                                    // 0000000E8E38: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000E8E3C: BFB60003
	s_endpgm                                                   // 0000000E8E40: BFB00000
		...

