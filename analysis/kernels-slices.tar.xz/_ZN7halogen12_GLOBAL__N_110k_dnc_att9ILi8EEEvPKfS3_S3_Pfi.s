000000000021e600 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 00000021E600: BE8C0003
	s_clause 0x1                                               // 00000021E604: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000021E608: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 00000021E610: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 00000021E618: 360200FF 0000007F
	s_lshl_b32 s0, s2, 6                                       // 00000021E620: 84008602
	s_ashr_i32 s13, s12, 31                                    // 00000021E624: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021E628: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 00000021E62C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000021E634: 30060282
	s_waitcnt lgkmcnt(0)                                       // 00000021E638: BF89FC07
	.long 0xd7000103                                           // 00000021E63C: D7000103
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000021E640: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E644: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s1                    // 00000021E648: D5207C04 00050007
	s_mov_b32 s1, 0                                            // 00000021E650: BE810080
	s_mov_b32 s6, 0x43800000                                   // 00000021E654: BE8600FF 43800000
	s_set_inst_prefetch_distance 0x1                           // 00000021E65C: BF840001
	s_branch 22                                                // 00000021E660: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 00000021E664: BF800000
	s_nop 0                                                    // 00000021E668: BF800000
	s_nop 0                                                    // 00000021E66C: BF800000
	s_nop 0                                                    // 00000021E670: BF800000
	s_nop 0                                                    // 00000021E674: BF800000
	s_nop 0                                                    // 00000021E678: BF800000
	s_nop 0                                                    // 00000021E67C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000021E680: 8C7E077E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 00000021E684: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 00000021E68C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 00000021E698: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021E6A0: BF870003
	v_mov_b32_e32 v5, v8                                       // 00000021E6A4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 00000021E6A8: 8C01016A
	ds_store_b16 v6, v1                                        // 00000021E6AC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000021E6B4: 917E017E
	s_cbranch_execz 24                                         // 00000021E6B8: BFA50018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x11c>
	v_lshrrev_b32_e32 v6, 7, v5                                // 00000021E6BC: 320C0A87
	.long 0x7e023880                                           // 00000021E6C0: 7E023880
	s_mov_b32 s7, exec_lo                                      // 00000021E6C4: BE87007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E6C8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 00000021E6CC: 380E0C00
	.long 0xd4c4007e                                           // 00000021E6D0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 00000021E6D4: 02020E03
	s_cbranch_execz 65513                                      // 00000021E6D8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 00000021E6DC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E6E4: BF870091
	.long 0xd73c0007                                           // 00000021E6E8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 00000021E6EC: 02020E89
	.long 0xd7006a07                                           // 00000021E6F0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000021E6F4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E6F8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000021E6FC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 00000021E704: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 00000021E70C: BF8903F7
	v_fma_mixlo_f16 v1, v1, s6, 0                              // 00000021E710: CC210001 02000D01
	s_branch 65497                                             // 00000021E718: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000021E71C: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E720: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000021E724: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000021E728: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 00000021E72C: 7D9800C0
	s_cbranch_execz 17                                         // 00000021E730: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x178>
	v_or_b32_e32 v1, s0, v0                                    // 00000021E734: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 00000021E738: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E73C: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 00000021E740: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 00000021E74C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000021E750: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E754: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000021E758: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 00000021E760: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000021E768: 30040082
	s_waitcnt vmcnt(0)                                         // 00000021E76C: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 00000021E770: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E778: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000021E77C: BF89FC07
	s_barrier                                                  // 00000021E780: BFBD0000
	buffer_gl0_inv                                             // 00000021E784: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000021E78C: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 00000021E790: 7D9800FF 00000200
	s_cbranch_execz 1796                                       // 00000021E798: BFA50704 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1dac>
	v_and_b32_e32 v1, 15, v0                                   // 00000021E79C: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 00000021E7A0: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 00000021E7A8: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 00000021E7AC: 9682B002
	s_add_u32 s6, s1, s12                                      // 00000021E7B0: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 00000021E7B4: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 00000021E7BC: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 00000021E7C4: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 00000021E7CC: 82070D02
	v_lshrrev_b32_e32 v33, 5, v0                               // 00000021E7D0: 32420085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 00000021E7D4: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 00000021E7D8: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 00000021E7DC: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 00000021E7E4: D6560020 03FD051D 00004800
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v34, v2, v3      // 00000021E7F0: CA200080 01220702
	s_add_u32 s2, s10, s6                                      // 00000021E7F8: 8002060A
	s_addc_u32 s6, s11, s7                                     // 00000021E7FC: 8206070B
	s_mov_b32 s7, 0                                            // 00000021E800: BE870080
	s_mov_b32 s8, 0x43800000                                   // 00000021E804: BE8800FF 43800000
	s_branch 19                                                // 00000021E80C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x25c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E810: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021E814: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v33                            // 00000021E81C: 7C924287
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021E820: BF8700B2
	.long 0xd73c0003                                           // 00000021E824: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E828: 02020082
	v_add_nc_u32_e32 v0, 8, v33                                // 00000021E82C: 4A004288
	s_or_b32 s7, vcc_lo, s7                                    // 00000021E830: 8C07076A
	v_mov_b32_e32 v33, v0                                      // 00000021E834: 7E420300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E838: BF870093
	.long 0xd7000003                                           // 00000021E83C: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000021E840: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 00000021E844: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000021E84C: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000021E854: 917E077E
	s_cbranch_execz 1748                                       // 00000021E858: BFA506D4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1dac>
	v_lshrrev_b32_e32 v0, 2, v33                               // 00000021E85C: 32004282
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000021E860: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 00000021E868: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021E870: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 00000021E874: 7C923900
	.long 0xd44e0000                                           // 00000021E878: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000021E87C: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 00000021E880: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 00000021E888: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 00000021E890: 7E040280
	s_and_saveexec_b32 s9, s0                                  // 00000021E894: BE892000
	s_cbranch_execz 1301                                       // 00000021E898: BFA50515 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x16f0>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000021E89C: 4A083D00
	.long 0x7f143880                                           // 00000021E8A0: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000021E8A4: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 00000021E8A8: D6FF7C02 00316104
	.long 0xd4440000                                           // 00000021E8B0: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000021E8B4: 02020803
	.long 0x7e14398a                                           // 00000021E8B8: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E8BC: BF870093
	.long 0xd73c0002                                           // 00000021E8C0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000021E8C4: 02020489
	.long 0xd700011a                                           // 00000021E8C8: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000021E8CC: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E8D0: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 00000021E8D4: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 00000021E8DC: BE812000
	s_cbranch_execz 5                                          // 00000021E8E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x2f8>
	global_load_b32 v2, v[26:27], off                          // 00000021E8E4: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E8EC: BF8903F7
	v_fma_mixlo_f16 v10, v2, s8, 0                             // 00000021E8F0: CC21000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E8F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021E8FC: BE812000
	s_cbranch_execz 5                                          // 00000021E900: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x318>
	global_load_b32 v2, v[26:27], off offset:4                 // 00000021E904: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E90C: BF8903F7
	v_fma_mixhi_f16 v10, v2, s8, 0                             // 00000021E910: CC22000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E918: 8C7E017E
	.long 0x7f163880                                           // 00000021E91C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E920: BF870001
	.long 0x7e16398b                                           // 00000021E924: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021E928: BE812000
	s_cbranch_execz 5                                          // 00000021E92C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x344>
	global_load_b32 v2, v[26:27], off offset:8                 // 00000021E930: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E938: BF8903F7
	v_fma_mixlo_f16 v11, v2, s8, 0                             // 00000021E93C: CC21000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E944: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021E948: BE812000
	s_cbranch_execz 5                                          // 00000021E94C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x364>
	global_load_b32 v2, v[26:27], off offset:12                // 00000021E950: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E958: BF8903F7
	v_fma_mixhi_f16 v11, v2, s8, 0                             // 00000021E95C: CC22000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E964: 8C7E017E
	.long 0x7f183880                                           // 00000021E968: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E96C: BF870001
	.long 0x7e18398c                                           // 00000021E970: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021E974: BE812000
	s_cbranch_execz 5                                          // 00000021E978: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x390>
	global_load_b32 v2, v[26:27], off offset:16                // 00000021E97C: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E984: BF8903F7
	v_fma_mixlo_f16 v12, v2, s8, 0                             // 00000021E988: CC21000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E990: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021E994: BE812000
	s_cbranch_execz 5                                          // 00000021E998: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x3b0>
	global_load_b32 v2, v[26:27], off offset:20                // 00000021E99C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E9A4: BF8903F7
	v_fma_mixhi_f16 v12, v2, s8, 0                             // 00000021E9A8: CC22000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E9B0: 8C7E017E
	.long 0x7f1a3880                                           // 00000021E9B4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E9B8: BF870001
	.long 0x7e1a398d                                           // 00000021E9BC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021E9C0: BE812000
	s_cbranch_execz 5                                          // 00000021E9C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x3dc>
	global_load_b32 v2, v[26:27], off offset:24                // 00000021E9C8: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E9D0: BF8903F7
	v_fma_mixlo_f16 v13, v2, s8, 0                             // 00000021E9D4: CC21000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E9DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021E9E0: BE812000
	s_cbranch_execz 5                                          // 00000021E9E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x3fc>
	global_load_b32 v2, v[26:27], off offset:28                // 00000021E9E8: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021E9F0: BF8903F7
	v_fma_mixhi_f16 v13, v2, s8, 0                             // 00000021E9F4: CC22000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021E9FC: 8C7E017E
	.long 0x7f1c3880                                           // 00000021EA00: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EA04: BF870001
	.long 0x7e1c398e                                           // 00000021EA08: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021EA0C: BE812000
	s_cbranch_execz 5                                          // 00000021EA10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x428>
	global_load_b32 v2, v[26:27], off offset:32                // 00000021EA14: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EA1C: BF8903F7
	v_fma_mixlo_f16 v14, v2, s8, 0                             // 00000021EA20: CC21000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EA28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EA2C: BE812000
	s_cbranch_execz 5                                          // 00000021EA30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x448>
	global_load_b32 v2, v[26:27], off offset:36                // 00000021EA34: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EA3C: BF8903F7
	v_fma_mixhi_f16 v14, v2, s8, 0                             // 00000021EA40: CC22000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EA48: 8C7E017E
	.long 0x7f1e3880                                           // 00000021EA4C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EA50: BF870001
	.long 0x7e1e398f                                           // 00000021EA54: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021EA58: BE812000
	s_cbranch_execz 5                                          // 00000021EA5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x474>
	global_load_b32 v2, v[26:27], off offset:40                // 00000021EA60: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EA68: BF8903F7
	v_fma_mixlo_f16 v15, v2, s8, 0                             // 00000021EA6C: CC21000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EA74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EA78: BE812000
	s_cbranch_execz 5                                          // 00000021EA7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x494>
	global_load_b32 v2, v[26:27], off offset:44                // 00000021EA80: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EA88: BF8903F7
	v_fma_mixhi_f16 v15, v2, s8, 0                             // 00000021EA8C: CC22000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EA94: 8C7E017E
	.long 0x7f203880                                           // 00000021EA98: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EA9C: BF870001
	.long 0x7e203990                                           // 00000021EAA0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021EAA4: BE812000
	s_cbranch_execz 5                                          // 00000021EAA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x4c0>
	global_load_b32 v2, v[26:27], off offset:48                // 00000021EAAC: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EAB4: BF8903F7
	v_fma_mixlo_f16 v16, v2, s8, 0                             // 00000021EAB8: CC210010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EAC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EAC4: BE812000
	s_cbranch_execz 5                                          // 00000021EAC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:52                // 00000021EACC: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EAD4: BF8903F7
	v_fma_mixhi_f16 v16, v2, s8, 0                             // 00000021EAD8: CC220010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EAE0: 8C7E017E
	.long 0x7f223880                                           // 00000021EAE4: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EAE8: BF870001
	.long 0x7e223991                                           // 00000021EAEC: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021EAF0: BE812000
	s_cbranch_execz 5                                          // 00000021EAF4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x50c>
	global_load_b32 v2, v[26:27], off offset:56                // 00000021EAF8: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EB00: BF8903F7
	v_fma_mixlo_f16 v17, v2, s8, 0                             // 00000021EB04: CC210011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EB0C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EB10: BE812000
	s_cbranch_execz 5                                          // 00000021EB14: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x52c>
	global_load_b32 v2, v[26:27], off offset:60                // 00000021EB18: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021EB20: BF8903F7
	v_fma_mixhi_f16 v17, v2, s8, 0                             // 00000021EB24: CC220011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EB2C: 8C7E017E
	ds_load_b128 v[35:38], v34                                 // 00000021EB30: DBFC0000 23000022
	ds_load_b128 v[39:42], v34 offset:16                       // 00000021EB38: DBFC0010 27000022
	v_mov_b32_e32 v8, v1                                       // 00000021EB40: 7E100301
	v_mov_b32_e32 v2, v1                                       // 00000021EB44: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000021EB48: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000021EB4C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000021EB50: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000021EB54: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000021EB58: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000021EB5C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021EB60: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000021EB64: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000021EB68: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000021EB6C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000021EB70: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000021EB74: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000021EB78: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000021EB7C: 7E040301
	.long 0x7f243880                                           // 00000021EB80: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 00000021EB84: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021EB88: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021EB8C: CC404002 1C0A470A
	.long 0x7e243992                                           // 00000021EB94: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 00000021EB98: BE812000
	s_cbranch_execz 5                                          // 00000021EB9C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x5b4>
	global_load_b32 v10, v[26:27], off offset:64               // 00000021EBA0: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EBA8: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021EBAC: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EBB4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EBB8: BE812000
	s_cbranch_execz 5                                          // 00000021EBBC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x5d4>
	global_load_b32 v10, v[26:27], off offset:68               // 00000021EBC0: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EBC8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021EBCC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EBD4: 8C7E017E
	.long 0x7f263880                                           // 00000021EBD8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EBDC: BF870001
	.long 0x7e263993                                           // 00000021EBE0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021EBE4: BE812000
	s_cbranch_execz 5                                          // 00000021EBE8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x600>
	global_load_b32 v10, v[26:27], off offset:72               // 00000021EBEC: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EBF4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021EBF8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EC00: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EC04: BE812000
	s_cbranch_execz 5                                          // 00000021EC08: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x620>
	global_load_b32 v10, v[26:27], off offset:76               // 00000021EC0C: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EC14: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021EC18: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EC20: 8C7E017E
	.long 0x7f283880                                           // 00000021EC24: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EC28: BF870001
	.long 0x7e283994                                           // 00000021EC2C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021EC30: BE812000
	s_cbranch_execz 5                                          // 00000021EC34: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:80               // 00000021EC38: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EC40: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021EC44: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EC4C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EC50: BE812000
	s_cbranch_execz 5                                          // 00000021EC54: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x66c>
	global_load_b32 v10, v[26:27], off offset:84               // 00000021EC58: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EC60: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021EC64: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EC6C: 8C7E017E
	.long 0x7f2a3880                                           // 00000021EC70: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EC74: BF870001
	.long 0x7e2a3995                                           // 00000021EC78: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021EC7C: BE812000
	s_cbranch_execz 5                                          // 00000021EC80: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x698>
	global_load_b32 v10, v[26:27], off offset:88               // 00000021EC84: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EC8C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021EC90: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EC98: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EC9C: BE812000
	s_cbranch_execz 5                                          // 00000021ECA0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:92               // 00000021ECA4: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ECAC: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021ECB0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ECB8: 8C7E017E
	.long 0x7f2c3880                                           // 00000021ECBC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021ECC0: BF870001
	.long 0x7e2c3996                                           // 00000021ECC4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021ECC8: BE812000
	s_cbranch_execz 5                                          // 00000021ECCC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x6e4>
	global_load_b32 v10, v[26:27], off offset:96               // 00000021ECD0: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ECD8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021ECDC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ECE4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021ECE8: BE812000
	s_cbranch_execz 5                                          // 00000021ECEC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x704>
	global_load_b32 v10, v[26:27], off offset:100              // 00000021ECF0: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ECF8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021ECFC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ED04: 8C7E017E
	.long 0x7f2e3880                                           // 00000021ED08: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021ED0C: BF870001
	.long 0x7e2e3997                                           // 00000021ED10: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021ED14: BE812000
	s_cbranch_execz 5                                          // 00000021ED18: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x730>
	global_load_b32 v10, v[26:27], off offset:104              // 00000021ED1C: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ED24: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021ED28: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ED30: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021ED34: BE812000
	s_cbranch_execz 5                                          // 00000021ED38: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x750>
	global_load_b32 v10, v[26:27], off offset:108              // 00000021ED3C: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ED44: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021ED48: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ED50: 8C7E017E
	.long 0x7f303880                                           // 00000021ED54: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021ED58: BF870001
	.long 0x7e303998                                           // 00000021ED5C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021ED60: BE812000
	s_cbranch_execz 5                                          // 00000021ED64: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x77c>
	global_load_b32 v10, v[26:27], off offset:112              // 00000021ED68: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ED70: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021ED74: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ED7C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021ED80: BE812000
	s_cbranch_execz 5                                          // 00000021ED84: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x79c>
	global_load_b32 v10, v[26:27], off offset:116              // 00000021ED88: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021ED90: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021ED94: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021ED9C: 8C7E017E
	.long 0x7f323880                                           // 00000021EDA0: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EDA4: BF870001
	.long 0x7e323999                                           // 00000021EDA8: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021EDAC: BE812000
	s_cbranch_execz 5                                          // 00000021EDB0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x7c8>
	global_load_b32 v10, v[26:27], off offset:120              // 00000021EDB4: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EDBC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021EDC0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EDC8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EDCC: BE812000
	s_cbranch_execz 5                                          // 00000021EDD0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x7e8>
	global_load_b32 v10, v[26:27], off offset:124              // 00000021EDD4: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EDDC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021EDE0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EDE8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:32                       // 00000021EDEC: DBFC0020 23000022
	ds_load_b128 v[39:42], v34 offset:48                       // 00000021EDF4: DBFC0030 27000022
	.long 0x7f143880                                           // 00000021EDFC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EE00: BF870001
	.long 0x7e14398a                                           // 00000021EE04: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021EE08: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021EE0C: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021EE14: BE812000
	s_cbranch_execz 5                                          // 00000021EE18: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x830>
	global_load_b32 v11, v[26:27], off offset:128              // 00000021EE1C: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EE24: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021EE28: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EE30: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EE34: BE812000
	s_cbranch_execz 5                                          // 00000021EE38: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x850>
	global_load_b32 v11, v[26:27], off offset:132              // 00000021EE3C: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EE44: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021EE48: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EE50: 8C7E017E
	.long 0x7f163880                                           // 00000021EE54: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EE58: BF870001
	.long 0x7e16398b                                           // 00000021EE5C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021EE60: BE812000
	s_cbranch_execz 5                                          // 00000021EE64: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x87c>
	global_load_b32 v12, v[26:27], off offset:136              // 00000021EE68: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EE70: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021EE74: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EE7C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EE80: BE812000
	s_cbranch_execz 5                                          // 00000021EE84: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x89c>
	global_load_b32 v12, v[26:27], off offset:140              // 00000021EE88: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EE90: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021EE94: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EE9C: 8C7E017E
	.long 0x7f183880                                           // 00000021EEA0: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EEA4: BF870001
	.long 0x7e18398c                                           // 00000021EEA8: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021EEAC: BE812000
	s_cbranch_execz 5                                          // 00000021EEB0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x8c8>
	global_load_b32 v13, v[26:27], off offset:144              // 00000021EEB4: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EEBC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021EEC0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EEC8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EECC: BE812000
	s_cbranch_execz 5                                          // 00000021EED0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x8e8>
	global_load_b32 v13, v[26:27], off offset:148              // 00000021EED4: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EEDC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021EEE0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EEE8: 8C7E017E
	.long 0x7f1a3880                                           // 00000021EEEC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EEF0: BF870001
	.long 0x7e1a398d                                           // 00000021EEF4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021EEF8: BE812000
	s_cbranch_execz 5                                          // 00000021EEFC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x914>
	global_load_b32 v14, v[26:27], off offset:152              // 00000021EF00: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EF08: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021EF0C: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EF14: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EF18: BE812000
	s_cbranch_execz 5                                          // 00000021EF1C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x934>
	global_load_b32 v14, v[26:27], off offset:156              // 00000021EF20: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EF28: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021EF2C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EF34: 8C7E017E
	.long 0x7f1c3880                                           // 00000021EF38: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EF3C: BF870001
	.long 0x7e1c398e                                           // 00000021EF40: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021EF44: BE812000
	s_cbranch_execz 5                                          // 00000021EF48: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x960>
	global_load_b32 v15, v[26:27], off offset:160              // 00000021EF4C: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EF54: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021EF58: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EF60: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EF64: BE812000
	s_cbranch_execz 5                                          // 00000021EF68: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x980>
	global_load_b32 v15, v[26:27], off offset:164              // 00000021EF6C: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021EF74: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021EF78: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EF80: 8C7E017E
	.long 0x7f1e3880                                           // 00000021EF84: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EF88: BF870001
	.long 0x7e1e398f                                           // 00000021EF8C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021EF90: BE812000
	s_cbranch_execz 5                                          // 00000021EF94: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x9ac>
	global_load_b32 v16, v[26:27], off offset:168              // 00000021EF98: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021EFA0: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021EFA4: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EFAC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EFB0: BE812000
	s_cbranch_execz 5                                          // 00000021EFB4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x9cc>
	global_load_b32 v16, v[26:27], off offset:172              // 00000021EFB8: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021EFC0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021EFC4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EFCC: 8C7E017E
	.long 0x7f203880                                           // 00000021EFD0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021EFD4: BF870001
	.long 0x7e203990                                           // 00000021EFD8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021EFDC: BE812000
	s_cbranch_execz 5                                          // 00000021EFE0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v17, v[26:27], off offset:176              // 00000021EFE4: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021EFEC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021EFF0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021EFF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021EFFC: BE812000
	s_cbranch_execz 5                                          // 00000021F000: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xa18>
	global_load_b32 v17, v[26:27], off offset:180              // 00000021F004: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021F00C: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021F010: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F018: 8C7E017E
	.long 0x7f223880                                           // 00000021F01C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F020: BF870001
	.long 0x7e223991                                           // 00000021F024: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021F028: BE812000
	s_cbranch_execz 5                                          // 00000021F02C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xa44>
	global_load_b32 v18, v[26:27], off offset:184              // 00000021F030: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021F038: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021F03C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F044: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F048: BE812000
	s_cbranch_execz 5                                          // 00000021F04C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v18, v[26:27], off offset:188              // 00000021F050: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021F058: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021F05C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F064: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:64                       // 00000021F068: DBFC0040 23000022
	ds_load_b128 v[39:42], v34 offset:80                       // 00000021F070: DBFC0050 27000022
	.long 0x7f243880                                           // 00000021F078: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F07C: BF870001
	.long 0x7e243992                                           // 00000021F080: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021F084: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021F088: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021F090: BE812000
	s_cbranch_execz 5                                          // 00000021F094: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xaac>
	global_load_b32 v10, v[26:27], off offset:192              // 00000021F098: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F0A0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021F0A4: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F0AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F0B0: BE812000
	s_cbranch_execz 5                                          // 00000021F0B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xacc>
	global_load_b32 v10, v[26:27], off offset:196              // 00000021F0B8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F0C0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021F0C4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F0CC: 8C7E017E
	.long 0x7f263880                                           // 00000021F0D0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F0D4: BF870001
	.long 0x7e263993                                           // 00000021F0D8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021F0DC: BE812000
	s_cbranch_execz 5                                          // 00000021F0E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xaf8>
	global_load_b32 v10, v[26:27], off offset:200              // 00000021F0E4: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F0EC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021F0F0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F0F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F0FC: BE812000
	s_cbranch_execz 5                                          // 00000021F100: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xb18>
	global_load_b32 v10, v[26:27], off offset:204              // 00000021F104: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F10C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021F110: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F118: 8C7E017E
	.long 0x7f283880                                           // 00000021F11C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F120: BF870001
	.long 0x7e283994                                           // 00000021F124: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021F128: BE812000
	s_cbranch_execz 5                                          // 00000021F12C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xb44>
	global_load_b32 v10, v[26:27], off offset:208              // 00000021F130: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F138: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021F13C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F144: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F148: BE812000
	s_cbranch_execz 5                                          // 00000021F14C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xb64>
	global_load_b32 v10, v[26:27], off offset:212              // 00000021F150: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F158: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021F15C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F164: 8C7E017E
	.long 0x7f2a3880                                           // 00000021F168: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F16C: BF870001
	.long 0x7e2a3995                                           // 00000021F170: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021F174: BE812000
	s_cbranch_execz 5                                          // 00000021F178: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:216              // 00000021F17C: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F184: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021F188: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F190: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F194: BE812000
	s_cbranch_execz 5                                          // 00000021F198: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xbb0>
	global_load_b32 v10, v[26:27], off offset:220              // 00000021F19C: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F1A4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021F1A8: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F1B0: 8C7E017E
	.long 0x7f2c3880                                           // 00000021F1B4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F1B8: BF870001
	.long 0x7e2c3996                                           // 00000021F1BC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021F1C0: BE812000
	s_cbranch_execz 5                                          // 00000021F1C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xbdc>
	global_load_b32 v10, v[26:27], off offset:224              // 00000021F1C8: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F1D0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021F1D4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F1DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F1E0: BE812000
	s_cbranch_execz 5                                          // 00000021F1E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xbfc>
	global_load_b32 v10, v[26:27], off offset:228              // 00000021F1E8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F1F0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021F1F4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F1FC: 8C7E017E
	.long 0x7f2e3880                                           // 00000021F200: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F204: BF870001
	.long 0x7e2e3997                                           // 00000021F208: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021F20C: BE812000
	s_cbranch_execz 5                                          // 00000021F210: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xc28>
	global_load_b32 v10, v[26:27], off offset:232              // 00000021F214: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F21C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021F220: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F228: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F22C: BE812000
	s_cbranch_execz 5                                          // 00000021F230: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xc48>
	global_load_b32 v10, v[26:27], off offset:236              // 00000021F234: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F23C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021F240: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F248: 8C7E017E
	.long 0x7f303880                                           // 00000021F24C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F250: BF870001
	.long 0x7e303998                                           // 00000021F254: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021F258: BE812000
	s_cbranch_execz 5                                          // 00000021F25C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xc74>
	global_load_b32 v10, v[26:27], off offset:240              // 00000021F260: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F268: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021F26C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F274: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F278: BE812000
	s_cbranch_execz 5                                          // 00000021F27C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xc94>
	global_load_b32 v10, v[26:27], off offset:244              // 00000021F280: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F288: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021F28C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F294: 8C7E017E
	.long 0x7f323880                                           // 00000021F298: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F29C: BF870001
	.long 0x7e323999                                           // 00000021F2A0: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021F2A4: BE812000
	s_cbranch_execz 5                                          // 00000021F2A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xcc0>
	global_load_b32 v10, v[26:27], off offset:248              // 00000021F2AC: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F2B4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021F2B8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F2C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F2C4: BE812000
	s_cbranch_execz 5                                          // 00000021F2C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xce0>
	global_load_b32 v10, v[26:27], off offset:252              // 00000021F2CC: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F2D4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021F2D8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F2E0: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:96                       // 00000021F2E4: DBFC0060 23000022
	ds_load_b128 v[39:42], v34 offset:112                      // 00000021F2EC: DBFC0070 27000022
	.long 0x7f143880                                           // 00000021F2F4: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F2F8: BF870001
	.long 0x7e14398a                                           // 00000021F2FC: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021F300: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021F304: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021F30C: BE812000
	s_cbranch_execz 5                                          // 00000021F310: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v11, v[26:27], off offset:256              // 00000021F314: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F31C: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021F320: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F328: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F32C: BE812000
	s_cbranch_execz 5                                          // 00000021F330: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xd48>
	global_load_b32 v11, v[26:27], off offset:260              // 00000021F334: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F33C: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021F340: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F348: 8C7E017E
	.long 0x7f163880                                           // 00000021F34C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F350: BF870001
	.long 0x7e16398b                                           // 00000021F354: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021F358: BE812000
	s_cbranch_execz 5                                          // 00000021F35C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xd74>
	global_load_b32 v12, v[26:27], off offset:264              // 00000021F360: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F368: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021F36C: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F374: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F378: BE812000
	s_cbranch_execz 5                                          // 00000021F37C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xd94>
	global_load_b32 v12, v[26:27], off offset:268              // 00000021F380: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F388: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021F38C: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F394: 8C7E017E
	.long 0x7f183880                                           // 00000021F398: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F39C: BF870001
	.long 0x7e18398c                                           // 00000021F3A0: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021F3A4: BE812000
	s_cbranch_execz 5                                          // 00000021F3A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xdc0>
	global_load_b32 v13, v[26:27], off offset:272              // 00000021F3AC: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F3B4: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021F3B8: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F3C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F3C4: BE812000
	s_cbranch_execz 5                                          // 00000021F3C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xde0>
	global_load_b32 v13, v[26:27], off offset:276              // 00000021F3CC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F3D4: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021F3D8: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F3E0: 8C7E017E
	.long 0x7f1a3880                                           // 00000021F3E4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F3E8: BF870001
	.long 0x7e1a398d                                           // 00000021F3EC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021F3F0: BE812000
	s_cbranch_execz 5                                          // 00000021F3F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xe0c>
	global_load_b32 v14, v[26:27], off offset:280              // 00000021F3F8: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F400: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021F404: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F40C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F410: BE812000
	s_cbranch_execz 5                                          // 00000021F414: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xe2c>
	global_load_b32 v14, v[26:27], off offset:284              // 00000021F418: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F420: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021F424: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F42C: 8C7E017E
	.long 0x7f1c3880                                           // 00000021F430: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F434: BF870001
	.long 0x7e1c398e                                           // 00000021F438: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021F43C: BE812000
	s_cbranch_execz 5                                          // 00000021F440: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xe58>
	global_load_b32 v15, v[26:27], off offset:288              // 00000021F444: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F44C: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021F450: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F458: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F45C: BE812000
	s_cbranch_execz 5                                          // 00000021F460: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xe78>
	global_load_b32 v15, v[26:27], off offset:292              // 00000021F464: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F46C: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021F470: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F478: 8C7E017E
	.long 0x7f1e3880                                           // 00000021F47C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F480: BF870001
	.long 0x7e1e398f                                           // 00000021F484: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021F488: BE812000
	s_cbranch_execz 5                                          // 00000021F48C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xea4>
	global_load_b32 v16, v[26:27], off offset:296              // 00000021F490: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021F498: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021F49C: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F4A4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F4A8: BE812000
	s_cbranch_execz 5                                          // 00000021F4AC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xec4>
	global_load_b32 v16, v[26:27], off offset:300              // 00000021F4B0: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021F4B8: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021F4BC: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F4C4: 8C7E017E
	.long 0x7f203880                                           // 00000021F4C8: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F4CC: BF870001
	.long 0x7e203990                                           // 00000021F4D0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021F4D4: BE812000
	s_cbranch_execz 5                                          // 00000021F4D8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xef0>
	global_load_b32 v17, v[26:27], off offset:304              // 00000021F4DC: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021F4E4: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021F4E8: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F4F0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F4F4: BE812000
	s_cbranch_execz 5                                          // 00000021F4F8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xf10>
	global_load_b32 v17, v[26:27], off offset:308              // 00000021F4FC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021F504: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021F508: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F510: 8C7E017E
	.long 0x7f223880                                           // 00000021F514: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F518: BF870001
	.long 0x7e223991                                           // 00000021F51C: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021F520: BE812000
	s_cbranch_execz 5                                          // 00000021F524: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v18, v[26:27], off offset:312              // 00000021F528: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021F530: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021F534: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F53C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F540: BE812000
	s_cbranch_execz 5                                          // 00000021F544: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xf5c>
	global_load_b32 v18, v[26:27], off offset:316              // 00000021F548: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021F550: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021F554: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F55C: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:128                      // 00000021F560: DBFC0080 23000022
	ds_load_b128 v[39:42], v34 offset:144                      // 00000021F568: DBFC0090 27000022
	.long 0x7f243880                                           // 00000021F570: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F574: BF870001
	.long 0x7e243992                                           // 00000021F578: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021F57C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021F580: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021F588: BE812000
	s_cbranch_execz 5                                          // 00000021F58C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xfa4>
	global_load_b32 v10, v[26:27], off offset:320              // 00000021F590: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F598: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021F59C: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F5A4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F5A8: BE812000
	s_cbranch_execz 5                                          // 00000021F5AC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:324              // 00000021F5B0: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F5B8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021F5BC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F5C4: 8C7E017E
	.long 0x7f263880                                           // 00000021F5C8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F5CC: BF870001
	.long 0x7e263993                                           // 00000021F5D0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021F5D4: BE812000
	s_cbranch_execz 5                                          // 00000021F5D8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0xff0>
	global_load_b32 v10, v[26:27], off offset:328              // 00000021F5DC: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F5E4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021F5E8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F5F0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F5F4: BE812000
	s_cbranch_execz 5                                          // 00000021F5F8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1010>
	global_load_b32 v10, v[26:27], off offset:332              // 00000021F5FC: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F604: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021F608: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F610: 8C7E017E
	.long 0x7f283880                                           // 00000021F614: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F618: BF870001
	.long 0x7e283994                                           // 00000021F61C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021F620: BE812000
	s_cbranch_execz 5                                          // 00000021F624: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x103c>
	global_load_b32 v10, v[26:27], off offset:336              // 00000021F628: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F630: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021F634: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F63C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F640: BE812000
	s_cbranch_execz 5                                          // 00000021F644: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x105c>
	global_load_b32 v10, v[26:27], off offset:340              // 00000021F648: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F650: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021F654: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F65C: 8C7E017E
	.long 0x7f2a3880                                           // 00000021F660: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F664: BF870001
	.long 0x7e2a3995                                           // 00000021F668: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021F66C: BE812000
	s_cbranch_execz 5                                          // 00000021F670: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1088>
	global_load_b32 v10, v[26:27], off offset:344              // 00000021F674: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F67C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021F680: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F688: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F68C: BE812000
	s_cbranch_execz 5                                          // 00000021F690: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x10a8>
	global_load_b32 v10, v[26:27], off offset:348              // 00000021F694: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F69C: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021F6A0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F6A8: 8C7E017E
	.long 0x7f2c3880                                           // 00000021F6AC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F6B0: BF870001
	.long 0x7e2c3996                                           // 00000021F6B4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021F6B8: BE812000
	s_cbranch_execz 5                                          // 00000021F6BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v10, v[26:27], off offset:352              // 00000021F6C0: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F6C8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021F6CC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F6D4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F6D8: BE812000
	s_cbranch_execz 5                                          // 00000021F6DC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x10f4>
	global_load_b32 v10, v[26:27], off offset:356              // 00000021F6E0: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F6E8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021F6EC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F6F4: 8C7E017E
	.long 0x7f2e3880                                           // 00000021F6F8: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F6FC: BF870001
	.long 0x7e2e3997                                           // 00000021F700: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021F704: BE812000
	s_cbranch_execz 5                                          // 00000021F708: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1120>
	global_load_b32 v10, v[26:27], off offset:360              // 00000021F70C: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F714: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021F718: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F720: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F724: BE812000
	s_cbranch_execz 5                                          // 00000021F728: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1140>
	global_load_b32 v10, v[26:27], off offset:364              // 00000021F72C: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F734: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021F738: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F740: 8C7E017E
	.long 0x7f303880                                           // 00000021F744: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F748: BF870001
	.long 0x7e303998                                           // 00000021F74C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021F750: BE812000
	s_cbranch_execz 5                                          // 00000021F754: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x116c>
	global_load_b32 v10, v[26:27], off offset:368              // 00000021F758: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F760: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021F764: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F76C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F770: BE812000
	s_cbranch_execz 5                                          // 00000021F774: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x118c>
	global_load_b32 v10, v[26:27], off offset:372              // 00000021F778: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F780: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021F784: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F78C: 8C7E017E
	.long 0x7f323880                                           // 00000021F790: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F794: BF870001
	.long 0x7e323999                                           // 00000021F798: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021F79C: BE812000
	s_cbranch_execz 5                                          // 00000021F7A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x11b8>
	global_load_b32 v10, v[26:27], off offset:376              // 00000021F7A4: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F7AC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021F7B0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F7B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F7BC: BE812000
	s_cbranch_execz 5                                          // 00000021F7C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x11d8>
	global_load_b32 v10, v[26:27], off offset:380              // 00000021F7C4: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F7CC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021F7D0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F7D8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:160                      // 00000021F7DC: DBFC00A0 23000022
	ds_load_b128 v[39:42], v34 offset:176                      // 00000021F7E4: DBFC00B0 27000022
	.long 0x7f143880                                           // 00000021F7EC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F7F0: BF870001
	.long 0x7e14398a                                           // 00000021F7F4: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021F7F8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021F7FC: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021F804: BE812000
	s_cbranch_execz 5                                          // 00000021F808: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1220>
	global_load_b32 v11, v[26:27], off offset:384              // 00000021F80C: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F814: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021F818: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F820: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F824: BE812000
	s_cbranch_execz 5                                          // 00000021F828: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1240>
	global_load_b32 v11, v[26:27], off offset:388              // 00000021F82C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F834: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021F838: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F840: 8C7E017E
	.long 0x7f163880                                           // 00000021F844: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F848: BF870001
	.long 0x7e16398b                                           // 00000021F84C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021F850: BE812000
	s_cbranch_execz 5                                          // 00000021F854: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v12, v[26:27], off offset:392              // 00000021F858: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F860: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021F864: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F86C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F870: BE812000
	s_cbranch_execz 5                                          // 00000021F874: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x128c>
	global_load_b32 v12, v[26:27], off offset:396              // 00000021F878: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F880: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021F884: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F88C: 8C7E017E
	.long 0x7f183880                                           // 00000021F890: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F894: BF870001
	.long 0x7e18398c                                           // 00000021F898: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021F89C: BE812000
	s_cbranch_execz 5                                          // 00000021F8A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x12b8>
	global_load_b32 v13, v[26:27], off offset:400              // 00000021F8A4: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F8AC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021F8B0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F8B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F8BC: BE812000
	s_cbranch_execz 5                                          // 00000021F8C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x12d8>
	global_load_b32 v13, v[26:27], off offset:404              // 00000021F8C4: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F8CC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021F8D0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F8D8: 8C7E017E
	.long 0x7f1a3880                                           // 00000021F8DC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F8E0: BF870001
	.long 0x7e1a398d                                           // 00000021F8E4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021F8E8: BE812000
	s_cbranch_execz 5                                          // 00000021F8EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1304>
	global_load_b32 v14, v[26:27], off offset:408              // 00000021F8F0: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F8F8: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021F8FC: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F904: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F908: BE812000
	s_cbranch_execz 5                                          // 00000021F90C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1324>
	global_load_b32 v14, v[26:27], off offset:412              // 00000021F910: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F918: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021F91C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F924: 8C7E017E
	.long 0x7f1c3880                                           // 00000021F928: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F92C: BF870001
	.long 0x7e1c398e                                           // 00000021F930: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021F934: BE812000
	s_cbranch_execz 5                                          // 00000021F938: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1350>
	global_load_b32 v15, v[26:27], off offset:416              // 00000021F93C: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F944: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021F948: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F950: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F954: BE812000
	s_cbranch_execz 5                                          // 00000021F958: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v15, v[26:27], off offset:420              // 00000021F95C: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021F964: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021F968: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F970: 8C7E017E
	.long 0x7f1e3880                                           // 00000021F974: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F978: BF870001
	.long 0x7e1e398f                                           // 00000021F97C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021F980: BE812000
	s_cbranch_execz 5                                          // 00000021F984: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x139c>
	global_load_b32 v16, v[26:27], off offset:424              // 00000021F988: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021F990: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021F994: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F99C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F9A0: BE812000
	s_cbranch_execz 5                                          // 00000021F9A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x13bc>
	global_load_b32 v16, v[26:27], off offset:428              // 00000021F9A8: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021F9B0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021F9B4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F9BC: 8C7E017E
	.long 0x7f203880                                           // 00000021F9C0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021F9C4: BF870001
	.long 0x7e203990                                           // 00000021F9C8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021F9CC: BE812000
	s_cbranch_execz 5                                          // 00000021F9D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x13e8>
	global_load_b32 v17, v[26:27], off offset:432              // 00000021F9D4: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021F9DC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021F9E0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021F9E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021F9EC: BE812000
	s_cbranch_execz 5                                          // 00000021F9F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1408>
	global_load_b32 v17, v[26:27], off offset:436              // 00000021F9F4: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021F9FC: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021FA00: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FA08: 8C7E017E
	.long 0x7f223880                                           // 00000021FA0C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FA10: BF870001
	.long 0x7e223991                                           // 00000021FA14: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021FA18: BE812000
	s_cbranch_execz 5                                          // 00000021FA1C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1434>
	global_load_b32 v18, v[26:27], off offset:440              // 00000021FA20: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021FA28: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021FA2C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FA34: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FA38: BE812000
	s_cbranch_execz 5                                          // 00000021FA3C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1454>
	global_load_b32 v18, v[26:27], off offset:444              // 00000021FA40: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021FA48: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021FA4C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FA54: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:192                      // 00000021FA58: DBFC00C0 23000022
	ds_load_b128 v[39:42], v34 offset:208                      // 00000021FA60: DBFC00D0 27000022
	.long 0x7f243880                                           // 00000021FA68: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FA6C: BF870001
	.long 0x7e243992                                           // 00000021FA70: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021FA74: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021FA78: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021FA80: BE812000
	s_cbranch_execz 5                                          // 00000021FA84: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x149c>
	global_load_b32 v10, v[26:27], off offset:448              // 00000021FA88: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FA90: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021FA94: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FA9C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FAA0: BE812000
	s_cbranch_execz 5                                          // 00000021FAA4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x14bc>
	global_load_b32 v10, v[26:27], off offset:452              // 00000021FAA8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FAB0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021FAB4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FABC: 8C7E017E
	.long 0x7f263880                                           // 00000021FAC0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FAC4: BF870001
	.long 0x7e263993                                           // 00000021FAC8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021FACC: BE812000
	s_cbranch_execz 5                                          // 00000021FAD0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x14e8>
	global_load_b32 v10, v[26:27], off offset:456              // 00000021FAD4: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FADC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021FAE0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FAE8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FAEC: BE812000
	s_cbranch_execz 5                                          // 00000021FAF0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1508>
	global_load_b32 v10, v[26:27], off offset:460              // 00000021FAF4: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FAFC: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021FB00: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FB08: 8C7E017E
	.long 0x7f283880                                           // 00000021FB0C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FB10: BF870001
	.long 0x7e283994                                           // 00000021FB14: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021FB18: BE812000
	s_cbranch_execz 5                                          // 00000021FB1C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1534>
	global_load_b32 v10, v[26:27], off offset:464              // 00000021FB20: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FB28: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021FB2C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FB34: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FB38: BE812000
	s_cbranch_execz 5                                          // 00000021FB3C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1554>
	global_load_b32 v10, v[26:27], off offset:468              // 00000021FB40: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FB48: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021FB4C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FB54: 8C7E017E
	.long 0x7f2a3880                                           // 00000021FB58: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FB5C: BF870001
	.long 0x7e2a3995                                           // 00000021FB60: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021FB64: BE812000
	s_cbranch_execz 5                                          // 00000021FB68: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1580>
	global_load_b32 v10, v[26:27], off offset:472              // 00000021FB6C: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FB74: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021FB78: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FB80: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FB84: BE812000
	s_cbranch_execz 5                                          // 00000021FB88: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x15a0>
	global_load_b32 v10, v[26:27], off offset:476              // 00000021FB8C: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FB94: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021FB98: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FBA0: 8C7E017E
	.long 0x7f2c3880                                           // 00000021FBA4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FBA8: BF870001
	.long 0x7e2c3996                                           // 00000021FBAC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021FBB0: BE812000
	s_cbranch_execz 5                                          // 00000021FBB4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x15cc>
	global_load_b32 v10, v[26:27], off offset:480              // 00000021FBB8: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FBC0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021FBC4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FBCC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FBD0: BE812000
	s_cbranch_execz 5                                          // 00000021FBD4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x15ec>
	global_load_b32 v10, v[26:27], off offset:484              // 00000021FBD8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FBE0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021FBE4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FBEC: 8C7E017E
	.long 0x7f2e3880                                           // 00000021FBF0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FBF4: BF870001
	.long 0x7e2e3997                                           // 00000021FBF8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021FBFC: BE812000
	s_cbranch_execz 5                                          // 00000021FC00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1618>
	global_load_b32 v10, v[26:27], off offset:488              // 00000021FC04: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FC0C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021FC10: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FC18: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FC1C: BE812000
	s_cbranch_execz 5                                          // 00000021FC20: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1638>
	global_load_b32 v10, v[26:27], off offset:492              // 00000021FC24: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FC2C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021FC30: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FC38: 8C7E017E
	.long 0x7f303880                                           // 00000021FC3C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FC40: BF870001
	.long 0x7e303998                                           // 00000021FC44: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021FC48: BE812000
	s_cbranch_execz 5                                          // 00000021FC4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1664>
	global_load_b32 v10, v[26:27], off offset:496              // 00000021FC50: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FC58: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021FC5C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FC64: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FC68: BE812000
	s_cbranch_execz 5                                          // 00000021FC6C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1684>
	global_load_b32 v10, v[26:27], off offset:500              // 00000021FC70: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FC78: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021FC7C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FC84: 8C7E017E
	.long 0x7f323880                                           // 00000021FC88: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FC8C: BF870001
	.long 0x7e323999                                           // 00000021FC90: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021FC94: BE812000
	s_cbranch_execz 5                                          // 00000021FC98: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x16b0>
	global_load_b32 v10, v[26:27], off offset:504              // 00000021FC9C: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FCA4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021FCA8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FCB0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021FCB4: BE812000
	s_cbranch_execz 5                                          // 00000021FCB8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x16d0>
	global_load_b32 v10, v[26:27], off offset:508              // 00000021FCBC: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021FCC4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021FCC8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021FCD0: 8C7E017E
	ds_load_b128 v[10:13], v34 offset:224                      // 00000021FCD4: DBFC00E0 0A000022
	ds_load_b128 v[14:17], v34 offset:240                      // 00000021FCDC: DBFC00F0 0E000022
	s_waitcnt lgkmcnt(0)                                       // 00000021FCE4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 00000021FCE8: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s9                              // 00000021FCF0: 8C7E097E
	v_or_b32_e32 v11, v0, v31                                  // 00000021FCF4: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000021FCF8: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 00000021FD00: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000021FD04: BF8704B2
	.long 0xd44b0000                                           // 00000021FD08: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000021FD0C: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 00000021FD10: 30141682
	s_and_b32 s9, s1, s0                                       // 00000021FD14: 8B090001
	s_and_saveexec_b32 s0, s9                                  // 00000021FD18: BE802009
	s_cbranch_execz 36                                         // 00000021FD1C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x17b0>
	ds_load_b32 v0, v10 offset:18432                           // 00000021FD20: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 00000021FD28: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 00000021FD30: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 00000021FD34: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FD38: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000021FD3C: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 00000021FD44: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 00000021FD50: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021FD54: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 00000021FD58: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021FD5C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 00000021FD64: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FD6C: BF870121
	v_add_f32_e32 v13, v13, v14                                // 00000021FD70: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000021FD74: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 00000021FD78: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FD7C: BF870095
	.long 0xd71c000d                                           // 00000021FD80: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000021FD84: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000021FD88: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021FD8C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FD94: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 00000021FD98: 02001AFF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 00000021FDA0: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021FDA8: BF870001
	v_mul_f32_e32 v13, v2, v0                                  // 00000021FDAC: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021FDB0: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 00000021FDB4: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 00000021FDBC: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021FDC0: BF870112
	.long 0xd73c000e                                           // 00000021FDC4: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021FDC8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021FDCC: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021FDD0: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FDD4: BF870092
	.long 0xd700000e                                           // 00000021FDD8: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021FDDC: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021FDE0: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021FDE8: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021FDF0: BE802009
	s_cbranch_execz 35                                         // 00000021FDF4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1884>
	ds_load_b32 v0, v10 offset:18440                           // 00000021FDF8: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 00000021FE00: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021FE08: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021FE0C: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FE10: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021FE14: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021FE1C: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021FE24: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021FE30: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FE34: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021FE38: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021FE44: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021FE48: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021FE4C: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021FE50: 7E184B0C
	.long 0xd71c000c                                           // 00000021FE54: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021FE58: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FE5C: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021FE60: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021FE64: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021FE6C: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FE74: BF870091
	v_mul_f32_e32 v0, 0x37800000, v0                           // 00000021FE78: 100000FF 37800000
	v_mul_f32_e32 v12, v3, v0                                  // 00000021FE80: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021FE84: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021FE88: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 00000021FE90: 38061684
	v_mov_b32_e32 v2, 0                                        // 00000021FE94: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021FE98: BF870193
	.long 0xd73c000d                                           // 00000021FE9C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021FEA0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021FEA4: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021FEA8: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FEAC: BF870092
	.long 0xd700000f                                           // 00000021FEB0: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 00000021FEB4: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 00000021FEB8: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 00000021FEC0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 00000021FEC4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s9                                  // 00000021FECC: BE802009
	s_cbranch_execz 35                                         // 00000021FED0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1960>
	ds_load_b32 v0, v10 offset:18448                           // 00000021FED4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 00000021FEDC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021FEE4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021FEE8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FEEC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021FEF0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021FEF8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021FF00: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021FF0C: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FF10: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021FF14: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021FF20: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021FF24: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021FF28: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021FF2C: 7E184B0C
	.long 0xd71c000c                                           // 00000021FF30: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021FF34: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FF38: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021FF3C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021FF40: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021FF48: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FF50: BF870091
	v_mul_f32_e32 v0, 0x37800000, v0                           // 00000021FF54: 100000FF 37800000
	v_mul_f32_e32 v13, v4, v0                                  // 00000021FF5C: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021FF60: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021FF64: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 00000021FF6C: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021FF70: BF870112
	.long 0xd73c000e                                           // 00000021FF74: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021FF78: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021FF7C: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021FF80: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021FF84: BF870092
	.long 0xd700000e                                           // 00000021FF88: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021FF8C: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021FF90: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021FF98: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021FFA0: BE802009
	s_cbranch_execz 36                                         // 00000021FFA4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1a38>
	ds_load_b32 v0, v10 offset:18456                           // 00000021FFA8: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 00000021FFB0: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021FFB8: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021FFBC: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FFC0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021FFC4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021FFCC: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021FFD4: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021FFE0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021FFE4: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021FFE8: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021FFF0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021FFF4: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021FFF8: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 00000021FFFC: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 000000220000: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220004: BF870095
	.long 0xd71c0002                                           // 000000220008: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000022000C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000220010: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000220014: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022001C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000220020: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 000000220028: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000220030: BF870001
	v_mul_f32_e32 v2, v5, v0                                   // 000000220034: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000220038: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000022003C: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 000000220044: 38081688
	v_mov_b32_e32 v3, 0                                        // 000000220048: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000022004C: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000220050: BF870214
	.long 0xd73c000c                                           // 000000220054: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000220058: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000022005C: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000220060: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220064: BF870092
	.long 0xd700000c                                           // 000000220068: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000022006C: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000220070: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 000000220078: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s9                                  // 000000220080: BE802009
	s_cbranch_execz 36                                         // 000000220084: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1b18>
	ds_load_b32 v0, v10 offset:18464                           // 000000220088: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 000000220090: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000220098: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000022009C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002200A0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 0000002200A4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 0000002200AC: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 0000002200B4: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 0000002200C0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002200C4: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 0000002200C8: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 0000002200D0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002200D4: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 0000002200D8: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 0000002200DC: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 0000002200E0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002200E4: BF870095
	.long 0xd71c0002                                           // 0000002200E8: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000002200EC: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000002200F0: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 0000002200F4: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002200FC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000220100: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 000000220108: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000220110: BF870001
	v_mul_f32_e32 v5, v6, v0                                   // 000000220114: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 000000220118: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000022011C: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 000000220124: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000220128: BF870112
	.long 0xd73c000c                                           // 00000022012C: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000220130: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 000000220134: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 000000220138: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022013C: BF870092
	.long 0xd700000c                                           // 000000220140: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 000000220144: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000220148: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 000000220150: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s9                                  // 000000220158: BE802009
	s_cbranch_execz 36                                         // 00000022015C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1bf0>
	ds_load_b32 v0, v10 offset:18472                           // 000000220160: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 000000220168: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000220170: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000220174: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220178: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000022017C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 000000220184: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 000000220190: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000220194: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 000000220198: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000022019C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 0000002201A4: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002201AC: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 0000002201B0: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 0000002201B4: 7E081105
	v_exp_f32_e32 v3, v3                                       // 0000002201B8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002201BC: BF870095
	.long 0xd71c0003                                           // 0000002201C0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000002201C4: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000002201C8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 0000002201CC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002201D4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 0000002201D8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 0000002201E0: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002201E8: BF870001
	v_mul_f32_e32 v3, v7, v0                                   // 0000002201EC: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002201F0: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 0000002201F4: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 0000002201FC: 3808168C
	v_mov_b32_e32 v2, 0                                        // 000000220200: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000220204: BF870193
	.long 0xd73c0005                                           // 000000220208: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000022020C: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 000000220210: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000220214: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220218: BF870092
	.long 0xd700000c                                           // 00000022021C: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000220220: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 000000220224: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 00000022022C: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 000000220230: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s9                                  // 000000220238: BE802009
	s_cbranch_execz 36                                         // 00000022023C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x1cd0>
	ds_load_b32 v0, v10 offset:18480                           // 000000220240: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 000000220248: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000220250: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000220254: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220258: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000022025C: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 000000220264: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 000000220270: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000220274: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 000000220278: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000022027C: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000220284: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022028C: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 000000220290: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 000000220294: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 000000220298: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022029C: BF870095
	.long 0xd71c0003                                           // 0000002202A0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000002202A4: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000002202A8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 0000002202AC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002202B4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 0000002202B8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 0000002202C0: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002202C8: BF870001
	v_mul_f32_e32 v5, v8, v0                                   // 0000002202CC: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002202D0: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 0000002202D4: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 0000002202DC: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002202E0: BF870112
	.long 0xd73c0006                                           // 0000002202E4: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002202E8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 0000002202EC: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 0000002202F0: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002202F4: BF870092
	.long 0xd7000006                                           // 0000002202F8: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 0000002202FC: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 000000220300: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 000000220308: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 000000220310: BE802001
	s_cbranch_execz 63806                                      // 000000220314: BFA5F93E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x210>
	ds_load_b32 v0, v10 offset:18488                           // 000000220318: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 000000220320: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000220328: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000022032C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000220330: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000220334: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000022033C: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 000000220344: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 000000220350: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000220354: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000220358: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 000000220360: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000220364: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 000000220368: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 00000022036C: 7E081105
	v_exp_f32_e32 v2, v2                                       // 000000220370: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000220374: BF870095
	.long 0xd71c0002                                           // 000000220378: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000022037C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000220380: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000220384: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022038C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000220390: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x37800000, v0                           // 000000220398: 100000FF 37800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002203A0: BF870001
	v_mul_f32_e32 v2, v9, v0                                   // 0000002203A4: 10040109
	s_branch 63769                                             // 0000002203A8: BFA0F919 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi8EEEvPKfS3_S3_Pfi+0x210>
	s_endpgm                                                   // 0000002203AC: BFB00000
		...

