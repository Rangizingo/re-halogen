0000000000226300 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_load_b256 s[16:23], s[0:1], null                         // 000000226300: F40C0400 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000226308: CA240100 040000FF 0000007F
	s_mov_b32 s24, s3                                          // 000000226314: BE980003
	s_lshl_b32 s26, s2, 6                                      // 000000226318: 841A8602
	s_ashr_i32 s25, s24, 31                                    // 00000022631C: 86199F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226320: BF8700A1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000226324: 30020282
	s_waitcnt lgkmcnt(0)                                       // 000000226328: BF89FC07
	.long 0xd7000302                                           // 00000022632C: D7000302
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 000000226330: 02020212
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226334: BF870001
	v_add_co_ci_u32_e64 v3, null, s19, 0, s3                   // 000000226338: D5207C03 000D0013
	s_mov_b32 s3, 0                                            // 000000226340: BE830080
	s_nop 0                                                    // 000000226344: BF800000
	s_nop 0                                                    // 000000226348: BF800000
	s_nop 0                                                    // 00000022634C: BF800000
	s_nop 0                                                    // 000000226350: BF800000
	s_nop 0                                                    // 000000226354: BF800000
	s_nop 0                                                    // 000000226358: BF800000
	s_nop 0                                                    // 00000022635C: BF800000
	s_nop 0                                                    // 000000226360: BF800000
	s_nop 0                                                    // 000000226364: BF800000
	s_nop 0                                                    // 000000226368: BF800000
	s_nop 0                                                    // 00000022636C: BF800000
	s_nop 0                                                    // 000000226370: BF800000
	s_nop 0                                                    // 000000226374: BF800000
	s_nop 0                                                    // 000000226378: BF800000
	s_nop 0                                                    // 00000022637C: BF800000
	v_lshrrev_b32_e32 v7, 7, v4                                // 000000226380: 320E0887
	v_add_nc_u32_e32 v9, 0x100, v4                             // 000000226384: 4A1208FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022638C: BF870092
	v_or_b32_e32 v5, s26, v7                                   // 000000226390: 380A0E1A
	v_mad_i64_i32 v[5:6], null, v5, 48, s[24:25]               // 000000226394: D6FF7C05 00616105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022639C: BF870091
	.long 0xd73c0005                                           // 0000002263A0: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000002263A4: 02020A89
	.long 0xd7006a05                                           // 0000002263A8: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000002263AC: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002263B0: BF870001
	v_add_co_ci_u32_e64 v6, null, v3, v6, vcc_lo               // 0000002263B4: D5207C06 01AA0D03
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v4                        // 0000002263BC: 7C9208FF 00001EFF
	v_mov_b32_e32 v4, v9                                       // 0000002263C4: 7E080309
	global_load_b32 v8, v[5:6], off                            // 0000002263C8: DC520000 087C0005
	v_mad_u64_u32 v[5:6], null, 0x204, v7, v[1:2]              // 0000002263D0: D6FE7C05 04060EFF 00000204
	s_or_b32 s3, vcc_lo, s3                                    // 0000002263DC: 8C03036A
	s_waitcnt vmcnt(0)                                         // 0000002263E0: BF8903F7
	ds_store_b32 v5, v8                                        // 0000002263E4: D8340000 00000805
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000002263EC: 917E037E
	s_cbranch_execnz 65507                                     // 0000002263F0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002263F4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002263F8: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000002263FC: BE83007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000226400: 7D9800C0
	s_cbranch_execz 17                                         // 000000226404: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x14c>
	v_or_b32_e32 v1, s26, v0                                   // 000000226408: 3802001A
	s_lshl_b64 s[4:5], s[24:25], 2                             // 00000022640C: 84848218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226410: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[20:21]             // 000000226414: D6FF7C01 005202FF 000000C0
	.long 0xd7006a01                                           // 000000226420: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000226424: 02000901
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226428: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000022642C: D5207C02 01AA0405
	global_load_b32 v1, v[1:2], off                            // 000000226434: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000022643C: 30040082
	s_waitcnt vmcnt(0)                                         // 000000226440: BF8903F7
	ds_store_b32 v2, v1 offset:33024                           // 000000226444: D8348100 00000102
	s_or_b32 exec_lo, exec_lo, s3                              // 00000022644C: 8C7E037E
	s_mov_b64 s[18:19], 0                                      // 000000226450: BE920180
	s_cmp_eq_u64 s[22:23], 0                                   // 000000226454: BF108016
	s_mul_hi_i32 s3, s2, 48                                    // 000000226458: 9703B002
	s_mul_i32 s2, s2, 48                                       // 00000022645C: 9602B002
	s_mov_b64 s[20:21], 0                                      // 000000226460: BE940180
	s_waitcnt lgkmcnt(0)                                       // 000000226464: BF89FC07
	s_barrier                                                  // 000000226468: BFBD0000
	buffer_gl0_inv                                             // 00000022646C: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 000000226474: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x190>
	s_add_u32 s4, s2, s24                                      // 000000226478: 80041802
	s_addc_u32 s5, s3, s25                                     // 00000022647C: 82051903
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000226480: BF870499
	s_lshl_b64 s[4:5], s[4:5], 14                              // 000000226484: 84848E04
	s_add_u32 s20, s22, s4                                     // 000000226488: 80140416
	s_addc_u32 s21, s23, s5                                    // 00000022648C: 82150517
	s_load_b64 s[0:1], s[0:1], 0x28                            // 000000226490: F4040000 F8000028
	s_waitcnt lgkmcnt(0)                                       // 000000226498: BF89FC07
	s_cmp_eq_u64 s[0:1], 0                                     // 00000022649C: BF108000
	s_cbranch_scc1 6                                           // 0000002264A0: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1bc>
	s_add_u32 s2, s2, s24                                      // 0000002264A4: 80021802
	s_addc_u32 s3, s3, s25                                     // 0000002264A8: 82031903
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002264AC: BF870499
	s_lshl_b64 s[2:3], s[2:3], 13                              // 0000002264B0: 84828D02
	s_add_u32 s18, s0, s2                                      // 0000002264B4: 80120200
	s_addc_u32 s19, s1, s3                                     // 0000002264B8: 82130301
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v2, 63, v0          // 0000002264BC: CA240080 010200BF
	s_cmp_lg_u64 s[20:21], 0                                   // 0000002264C4: BF118014
	s_mov_b32 s29, 0                                           // 0000002264C8: BE9D0080
	s_cselect_b32 s27, -1, 0                                   // 0000002264CC: 981B80C1
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002264D0: BF870001
	v_mul_u32_u24_e32 v3, 0x204, v2                            // 0000002264D4: 160604FF 00000204
	v_lshl_or_b32 v4, v2, 2, 0x8100                            // 0000002264DC: D6560004 03FD0502 00008100
	s_cmp_lg_u64 s[18:19], 0                                   // 0000002264E8: BF118012
	s_mov_b32 s30, 0x41800000                                  // 0000002264EC: BE9E00FF 41800000
	s_cselect_b32 s28, -1, 0                                   // 0000002264F4: 981C80C1
	s_branch 9                                                 // 0000002264F8: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x220>
	v_add_nc_u32_e32 v5, 0x100, v0                             // 0000002264FC: 4A0A00FF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v0                         // 000000226504: 7C9200FF 00000EFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000022650C: BF8704A2
	v_mov_b32_e32 v0, v5                                       // 000000226510: 7E000305
	s_or_b32 s29, vcc_lo, s29                                  // 000000226514: 8C1D1D6A
	s_and_not1_b32 exec_lo, exec_lo, s29                       // 000000226518: 917E1D7E
	s_cbranch_execz 138                                        // 00000022651C: BFA5008A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x448>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000226520: BF870131
	v_lshrrev_b32_e32 v5, 6, v0                                // 000000226524: 320A0086
	v_mov_b32_e32 v6, 0                                        // 000000226528: 7E0C0280
	s_mov_b32 s31, exec_lo                                     // 00000022652C: BE9F007E
	.long 0xd4cb007e                                           // 000000226530: D4CB007E
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000226534: 02020B02
	s_cbranch_execz 104                                        // 000000226538: BFA50068 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x3dc>
	v_or_b32_e32 v6, s26, v5                                   // 00000022653C: 380C0A1A
	s_mov_b64 s[22:23], 0                                      // 000000226540: BE960180
	v_mov_b32_e32 v7, v3                                       // 000000226544: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2)                            // 000000226548: BF870002
	v_readfirstlane_b32 s0, v6                                 // 00000022654C: 7E000506
	v_mov_b32_e32 v6, 0                                        // 000000226550: 7E0C0280
	s_mul_i32 s1, s0, 48                                       // 000000226554: 9601B000
	s_mul_hi_i32 s2, s0, 48                                    // 000000226558: 9702B000
	s_add_u32 s0, s1, s24                                      // 00000022655C: 80001801
	s_addc_u32 s1, s2, s25                                     // 000000226560: 82011902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000226564: BF870499
	s_lshl_b64 s[0:1], s[0:1], 9                               // 000000226568: 84808900
	s_add_u32 s33, s16, s0                                     // 00000022656C: 80210010
	s_addc_u32 s34, s17, s1                                    // 000000226570: 82220111
	s_set_inst_prefetch_distance 0x1                           // 000000226574: BF840001
	s_nop 0                                                    // 000000226578: BF800000
	s_nop 0                                                    // 00000022657C: BF800000
	s_add_u32 s0, s33, s22                                     // 000000226580: 80001621
	s_addc_u32 s1, s34, s23                                    // 000000226584: 82011722
	ds_load_2addr_b32 v[8:9], v7 offset1:1                     // 000000226588: D8DC0100 08000007
	s_load_b512 s[0:15], s[0:1], null                          // 000000226590: F4100000 F8000000
	ds_load_2addr_b32 v[10:11], v7 offset0:2 offset1:3         // 000000226598: D8DC0302 0A000007
	ds_load_2addr_b32 v[12:13], v7 offset0:4 offset1:5         // 0000002265A0: D8DC0504 0C000007
	ds_load_2addr_b32 v[14:15], v7 offset0:6 offset1:7         // 0000002265A8: D8DC0706 0E000007
	s_add_u32 s22, s22, 64                                     // 0000002265B0: 8016C016
	s_addc_u32 s23, s23, 0                                     // 0000002265B4: 82178017
	s_cmpk_eq_i32 s22, 0x200                                   // 0000002265B8: B1960200
	s_waitcnt lgkmcnt(0)                                       // 0000002265BC: BF89FC07
	v_fmac_f32_e32 v6, s0, v8                                  // 0000002265C0: 560C1000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002265C4: BF8700B1
	v_fmac_f32_e32 v6, s1, v9                                  // 0000002265C8: 560C1201
	ds_load_2addr_b32 v[8:9], v7 offset0:8 offset1:9           // 0000002265CC: D8DC0908 08000007
	v_fmac_f32_e32 v6, s2, v10                                 // 0000002265D4: 560C1402
	v_fmac_f32_e32 v6, s3, v11                                 // 0000002265D8: 560C1603
	ds_load_2addr_b32 v[10:11], v7 offset0:10 offset1:11       // 0000002265DC: D8DC0B0A 0A000007
	v_fmac_f32_e32 v6, s4, v12                                 // 0000002265E4: 560C1804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002265E8: BF870091
	v_fmac_f32_e32 v6, s5, v13                                 // 0000002265EC: 560C1A05
	v_fmac_f32_e32 v6, s6, v14                                 // 0000002265F0: 560C1C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002265F4: BF8700D1
	v_fmac_f32_e32 v6, s7, v15                                 // 0000002265F8: 560C1E07
	ds_load_2addr_b32 v[12:13], v7 offset0:12 offset1:13       // 0000002265FC: D8DC0D0C 0C000007
	ds_load_2addr_b32 v[14:15], v7 offset0:14 offset1:15       // 000000226604: D8DC0F0E 0E000007
	s_waitcnt lgkmcnt(3)                                       // 00000022660C: BF89FC37
	v_dual_fmac_f32 v6, s8, v8 :: v_dual_add_nc_u32 v7, 64, v7 // 000000226610: C8201008 06060EC0
	v_fmac_f32_e32 v6, s9, v9                                  // 000000226618: 560C1209
	s_waitcnt lgkmcnt(2)                                       // 00000022661C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226620: BF870091
	v_fmac_f32_e32 v6, s10, v10                                // 000000226624: 560C140A
	v_fmac_f32_e32 v6, s11, v11                                // 000000226628: 560C160B
	s_waitcnt lgkmcnt(1)                                       // 00000022662C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226630: BF870091
	v_fmac_f32_e32 v6, s12, v12                                // 000000226634: 560C180C
	v_fmac_f32_e32 v6, s13, v13                                // 000000226638: 560C1A0D
	s_waitcnt lgkmcnt(0)                                       // 00000022663C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226640: BF870091
	v_fmac_f32_e32 v6, s14, v14                                // 000000226644: 560C1C0E
	v_fmac_f32_e32 v6, s15, v15                                // 000000226648: 560C1E0F
	s_cbranch_scc0 65484                                       // 00000022664C: BFA1FFCC <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x280>
	s_set_inst_prefetch_distance 0x2                           // 000000226650: BF840002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000226654: 300A0A82
	ds_load_b32 v5, v5 offset:33024                            // 000000226658: D8D88100 05000005
	ds_load_b32 v7, v4                                         // 000000226660: D8D80000 07000004
	s_waitcnt lgkmcnt(0)                                       // 000000226668: BF89FC07
	v_sub_f32_e32 v5, v5, v7                                   // 00000022666C: 080A0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000226670: BF870121
	v_mul_f32_e32 v7, 0x3fb8aa3b, v5                           // 000000226674: 100E0AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v5                   // 00000022667C: 7C360AFF C2CE8ED0
	v_fma_f32 v8, 0x3fb8aa3b, v5, -v7                          // 000000226684: D6130008 841E0AFF 3FB8AA3B
	v_rndne_f32_e32 v9, v7                                     // 000000226690: 7E124707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000226694: BF870112
	v_fmac_f32_e32 v8, 0x32a5705f, v5                          // 000000226698: 56100AFF 32A5705F
	v_sub_f32_e32 v7, v7, v9                                   // 0000002266A0: 080E1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002266A4: BF870121
	v_add_f32_e32 v7, v7, v8                                   // 0000002266A8: 060E1107
	v_cvt_i32_f32_e32 v8, v9                                   // 0000002266AC: 7E101109
	v_exp_f32_e32 v7, v7                                       // 0000002266B0: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002266B4: BF870095
	.long 0xd71c0007                                           // 0000002266B8: D71C0007
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 0000002266BC: 02021107
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000002266C0: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v5                   // 0000002266C4: 7C3C0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002266CC: BF870092
	v_cndmask_b32_e32 v5, 0x7f800000, v7, vcc_lo               // 0000002266D0: 020A0EFF 7F800000
	v_mul_f32_e32 v6, v6, v5                                   // 0000002266D8: 100C0B06
	s_or_b32 exec_lo, exec_lo, s31                             // 0000002266DC: 8C7E1F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002266E0: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 0000002266E4: 916A1B7E
	s_cbranch_vccnz 9                                          // 0000002266E8: BFA40009 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x410>
	.long 0xd73c0007                                           // 0000002266EC: D73C0007
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002266F0: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002266F4: BF870091
	.long 0xd7006a07                                           // 0000002266F8: D7006A07
	v_cndmask_b32_e32 v1, s20, v7, vcc_lo                      // 0000002266FC: 02020E14
	v_add_co_ci_u32_e64 v8, null, s21, v8, vcc_lo              // 000000226700: D5207C08 01AA1015
	global_store_b32 v[7:8], v6, off                           // 000000226708: DC6A0000 007C0607
	s_and_not1_b32 vcc_lo, exec_lo, s28                        // 000000226710: 916A1C7E
	s_cbranch_vccnz 65401                                      // 000000226714: BFA4FF79 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1fc>
	.long 0xd73c0007                                           // 000000226718: D73C0007
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000022671C: 02020081
	v_fma_mixlo_f16 v5, v6, s30, 0                             // 000000226720: CC210005 02003D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226728: BF870092
	.long 0xd7006a07                                           // 00000022672C: D7006A07
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000226730: 02020E12
	v_add_co_ci_u32_e64 v8, null, s19, v8, vcc_lo              // 000000226734: D5207C08 01AA1013
	global_store_b16 v[7:8], v5, off                           // 00000022673C: DC660000 007C0507
	s_branch 65389                                             // 000000226744: BFA0FF6D <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1fc>
	s_endpgm                                                   // 000000226748: BFB00000
		...

