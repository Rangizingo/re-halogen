0000000000177200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000177200: BF850001
	s_load_b512 s[12:27], s[0:1], 0x8                          // 000000177204: F4100300 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 00000017720C: F4080100 F8000048
	s_lshl_b32 s8, s3, 6                                       // 000000177214: 84088603
	s_ashr_i32 s3, s2, 31                                      // 000000177218: 86039F02
	s_ashr_i32 s9, s8, 31                                      // 00000017721C: 86099F08
	v_and_b32_e32 v88, 63, v0                                  // 000000177220: 36B000BF
	s_movk_i32 s11, 0x210                                      // 000000177224: B00B0210
	v_mov_b32_e32 v4, v0                                       // 000000177228: 7E080300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000017722C: BF8704D2
	v_lshlrev_b32_e32 v2, 2, v88                               // 000000177230: 3004B082
	v_mad_u32_u24 v1, v88, s11, 0x3200                         // 000000177234: D60B0001 03FC1758 00003200
	s_waitcnt lgkmcnt(0)                                       // 000000177240: BF89FC07
	s_load_b32 s10, s[26:27], null                             // 000000177244: F400028D F8000000
	s_lshl_b64 s[26:27], s[4:5], 2                             // 00000017724C: 849A8204
	s_add_u32 s4, s24, s26                                     // 000000177250: 80041A18
	s_addc_u32 s5, s25, s27                                    // 000000177254: 82051B19
	s_lshl_b64 s[28:29], s[2:3], 16                            // 000000177258: 849C9002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017725C: BF870009
	s_add_u32 s4, s4, s28                                      // 000000177260: 80041C04
	s_addc_u32 s5, s5, s29                                     // 000000177264: 82051D05
	s_waitcnt lgkmcnt(0)                                       // 000000177268: BF89FC07
	s_mul_i32 s33, s10, 0x9000000                              // 00000017726C: 9621FF0A 09000000
	s_mul_hi_i32 s34, s10, 0x9000000                           // 000000177274: 9722FF0A 09000000
	s_add_u32 s4, s4, s33                                      // 00000017727C: 80042104
	s_addc_u32 s5, s5, s34                                     // 000000177280: 82052205
	s_lshl_b64 s[30:31], s[8:9], 2                             // 000000177284: 849E8208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000177288: BF8700B9
	s_add_u32 s4, s4, s30                                      // 00000017728C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 000000177290: 82051F05
	.long 0xd7000402                                           // 000000177294: D7000402
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000177298: 02020404
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 00000017729C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 0000001772A4: BE840080
	s_nop 0                                                    // 0000001772A8: BF800000
	s_nop 0                                                    // 0000001772AC: BF800000
	s_nop 0                                                    // 0000001772B0: BF800000
	s_nop 0                                                    // 0000001772B4: BF800000
	s_nop 0                                                    // 0000001772B8: BF800000
	s_nop 0                                                    // 0000001772BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 0000001772C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001772C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000001772C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 0000001772CC: D6460007 04050507
	.long 0xd7006a05                                           // 0000001772D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000001772D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001772DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000001772E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001772E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 0000001772F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 0000001772F8: 4A0C08FF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000177300: 8C04046A
	v_mov_b32_e32 v4, v6                                       // 000000177304: 7E080306
	s_waitcnt vmcnt(0)                                         // 000000177308: BF8903F7
	ds_store_b32 v7, v5                                        // 00000017730C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000177314: 917E047E
	s_cbranch_execnz 65513                                     // 000000177318: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000017731C: 8C7E047E
	s_load_b32 s35, s[0:1], 0x58                               // 000000177320: F40008C0 F8000058
	v_or_b32_e32 v89, 0xffffff80, v0                           // 000000177328: 38B200FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 000000177330: 32020086
	s_mov_b32 s0, 0                                            // 000000177334: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000177338: BF89FC07
	s_barrier                                                  // 00000017733C: BFBD0000
	buffer_gl0_inv                                             // 000000177340: E0AC0000 00000000
	s_cmp_gt_i32 s35, 0                                        // 000000177348: BF028023
	s_cbranch_scc1 9                                           // 00000017734C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v82, 6, v0                               // 000000177350: 32A40086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 000000177354: 380400FF FFFFFF80
	v_mov_b32_e32 v83, 0                                       // 00000017735C: 7EA60280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000177360: BF870003
	v_mov_b32_e32 v3, v82                                      // 000000177364: 7E060352
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000177368: 916A007E
	s_cbranch_vccz 1                                           // 00000017736C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 6764                                              // 000000177370: BFA01A6C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6b24>
	s_add_i32 s0, s35, 63                                      // 000000177374: 8100BF23
	s_add_i32 s44, s2, 0xbd0                                   // 000000177378: 812CFF02 00000BD0
	s_lshr_b32 s45, s0, 6                                      // 000000177380: 852D8600
	s_add_i32 s46, s35, -1                                     // 000000177384: 812EC123
	s_add_u32 s4, s18, s30                                     // 000000177388: 80041E12
	s_addc_u32 s5, s19, s31                                    // 00000017738C: 82051F13
	s_mov_b32 s19, 0                                           // 000000177390: BE930080
	v_lshrrev_b32_e32 v90, 5, v0                               // 000000177394: 32B40085
	s_mov_b32 s36, s19                                         // 000000177398: BEA40013
	s_mov_b32 s37, s19                                         // 00000017739C: BEA50013
	s_mov_b32 s38, s19                                         // 0000001773A0: BEA60013
	s_mov_b32 s39, s19                                         // 0000001773A4: BEA70013
	s_mov_b32 s40, s19                                         // 0000001773A8: BEA80013
	s_mov_b32 s41, s19                                         // 0000001773AC: BEA90013
	s_mov_b32 s42, s19                                         // 0000001773B0: BEAA0013
	s_mov_b32 s43, s19                                         // 0000001773B4: BEAB0013
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000001773B8: 30040082
	v_mul_u32_u24_e32 v7, 0xa00, v90                           // 0000001773BC: 160EB4FF 00000A00
	v_dual_mov_b32 v10, s36 :: v_dual_mov_b32 v11, s37         // 0000001773C4: CA100024 0A0A0025
	v_and_b32_e32 v3, 15, v0                                   // 0000001773CC: 3606008F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001773D0: BF870004
	v_or_b32_e32 v91, 0xb600, v2                               // 0000001773D4: 38B604FF 0000B600
	v_dual_mov_b32 v13, s39 :: v_dual_add_nc_u32 v92, 0xb700, v2// 0000001773DC: CA200027 0D5C04FF 0000B700
	v_dual_mov_b32 v15, s41 :: v_dual_lshlrev_b32 v2, 8, v0    // 0000001773E8: CA220029 0F020088
	v_lshlrev_b32_e32 v4, 4, v90                               // 0000001773F0: 3008B484
	v_bfe_u32 v5, v0, 4, 1                                     // 0000001773F4: D6100005 02050900
	s_movk_i32 s0, 0x210                                       // 0000001773FC: B0000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000177400: BF870193
	v_dual_mov_b32 v17, s43 :: v_dual_and_b32 v2, 0xf00, v2    // 000000177404: CA24002B 110204FF 00000F00
	v_or_b32_e32 v93, v4, v3                                   // 000000177410: 38BA0704
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000177414: BF870223
	v_or_b32_e32 v95, v4, v5                                   // 000000177418: 38BE0B04
	v_lshl_or_b32 v105, v88, 2, 0xb600                         // 00000017741C: D6560069 03FD0558 0000B600
	v_lshl_or_b32 v4, v90, 12, v2                              // 000000177428: D6560004 0409195A
	v_mov_b32_e32 v2, 0                                        // 000000177430: 7E040280
	v_mad_u32_u24 v94, v3, s0, 0x3200                          // 000000177434: D60B005E 03FC0103 00003200
	s_lshl_b32 s0, s2, 7                                       // 000000177440: 84008702
	v_lshlrev_b32_e32 v6, 2, v3                                // 000000177444: 300C0682
	s_ashr_i32 s1, s0, 31                                      // 000000177448: 86019F00
	.long 0xd7000a60                                           // 00000017744C: D7000A60
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000177450: 02020816
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000177454: 84808100
	v_mad_u32_u24 v4, 0x2100, v90, v94                         // 000000177458: D60B0004 057AB4FF 00002100
	s_add_u32 s6, s6, s0                                       // 000000177464: 80060006
	s_addc_u32 s7, s7, s1                                      // 000000177468: 82070107
	s_lshl_b64 s[0:1], s[8:9], 1                               // 00000017746C: 84808108
	v_mul_u32_u24_e32 v98, 0xa0, v3                            // 000000177470: 16C406FF 000000A0
	s_add_u32 s6, s6, s0                                       // 000000177478: 80060006
	s_movk_i32 s0, 0x2800                                      // 00000017747C: B0002800
	s_addc_u32 s7, s7, s1                                      // 000000177480: 82070107
	v_mad_u32_u24 v99, 0xa0, v3, s0                            // 000000177484: D60B0063 000206FF 000000A0
	.long 0xd7000065                                           // 000000177490: D7000065
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 000000177494: 02020C04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000177498: BF870001
	v_add_co_ci_u32_e64 v102, null, s5, 0, s0                  // 00000017749C: D5207C66 00010005
	s_lshl_b64 s[0:1], s[2:3], 9                               // 0000001774A4: 84808902
	v_lshl_or_b32 v100, v5, 2, v4                              // 0000001774A8: D6560064 04110505
	v_lshlrev_b32_e32 v5, 1, v3                                // 0000001774B0: 300A0681
	v_mad_u64_u32 v[3:4], null, 0x6000, v88, s[0:1]            // 0000001774B4: D6FE7C03 0002B0FF 00006000
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 0000001774C0: 160C02FF 000000A0
	v_dual_mov_b32 v83, v2 :: v_dual_mov_b32 v82, v1           // 0000001774C8: CA100102 53520101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001774D0: BF870094
	.long 0xd7000054                                           // 0000001774D4: D7000054
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000001774D8: 02020A06
	v_add_co_ci_u32_e64 v85, null, s7, 0, s0                   // 0000001774DC: D5207C55 00010007
	v_lshl_or_b32 v3, v1, 2, v3                                // 0000001774E4: D6560003 040D0501
	v_add_co_ci_u32_e64 v97, null, s23, 0, s10                 // 0000001774EC: D5207C61 00290017
	v_lshl_add_u32 v103, v95, 1, v98                           // 0000001774F4: D6460067 0589035F
	v_lshl_or_b32 v104, v95, 2, 0xb700                         // 0000001774FC: D6560068 03FD055F 0000B700
	s_delay_alu instid0(VALU_DEP_4)                            // 000000177508: BF870004
	.long 0xd7000056                                           // 00000017750C: D7000056
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 000000177510: 0202060E
	v_lshl_add_u32 v106, v88, 1, v6                            // 000000177514: D646006A 04190358
	v_add_co_ci_u32_e64 v87, null, s15, v4, s0                 // 00000017751C: D5207C57 0002080F
	v_mov_b32_e32 v12, s38                                     // 000000177524: 7E180226
	v_mov_b32_e32 v14, s40                                     // 000000177528: 7E1C0228
	v_dual_mov_b32 v16, s42 :: v_dual_add_nc_u32 v107, v98, v7 // 00000017752C: CA20002A 106A0F62
	s_mov_b32 s22, 0x41800000                                  // 000000177534: BE9600FF 41800000
	s_mov_b32 s23, 0                                           // 00000017753C: BE970080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000177540: 7C9800C0
	s_branch 13                                                // 000000177544: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37c>
	.long 0xd7000056                                           // 000000177548: D7000056
	v_cndmask_b32_e32 v1, 0x180000, v86, vcc_lo                // 00000017754C: 0202ACFF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000177554: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v87, s0                  // 000000177558: D5207C57 0002AE80
	s_add_i32 s23, s23, 1                                      // 000000177560: 81178117
	s_waitcnt lgkmcnt(0)                                       // 000000177564: BF89FC07
	s_cmp_eq_u32 s23, s45                                      // 000000177568: BF062D17
	s_barrier                                                  // 00000017756C: BFBD0000
	buffer_gl0_inv                                             // 000000177570: E0AC0000 00000000
	s_cbranch_scc1 6632                                        // 000000177578: BFA219E8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6b1c>
	s_mul_i32 s0, s23, 0xc00                                   // 00000017757C: 9600FF17 00000C00
	s_lshl_b32 s47, s23, 6                                     // 000000177584: 842F8617
	s_add_i32 s0, s44, s0                                      // 000000177588: 8100002C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017758C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000177590: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000177594: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000177598: BF870009
	s_add_u32 s0, s16, s0                                      // 00000017759C: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001775A0: 82010111
	global_load_b32 v3, v2, s[0:1]                             // 0000001775A4: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 0000001775AC: BF8903F7
	v_readfirstlane_b32 s48, v3                                // 0000001775B0: 7E600503
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001775B4: BE81206A
	s_cbranch_execz 77                                         // 0000001775B8: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f0>
	v_or_b32_e32 v3, s47, v0                                   // 0000001775BC: 3806002F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001775C0: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 0000001775C4: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000001775CC: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001775D0: BF870091
	.long 0xd73c0003                                           // 0000001775D4: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000001775D8: 02020682
	.long 0xd7000003                                           // 0000001775DC: D7000003
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 0000001775E0: 02020610
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001775E4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s17, v4, s0                  // 0000001775E8: D5207C04 00020811
	global_load_b32 v3, v[3:4], off                            // 0000001775F0: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001775F8: BF8903F7
	v_sub_f32_e32 v4, s48, v3                                  // 0000001775FC: 08080630
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 000000177600: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000017760C: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 000000177610: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v18, v6                                    // 00000017761C: 7E244706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 000000177620: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 00000017762C: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000177630: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v18// 000000177634: C80A06FF 09062506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 000000177640: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000177644: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 000000177648: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 000000177650: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 000000177654: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 00000017765C: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 000000177664: 7E0E1108
	v_cvt_i32_f32_e32 v8, v18                                  // 000000177668: 7E101112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000017766C: BF870193
	v_exp_f32_e32 v6, v6                                       // 000000177670: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 000000177674: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000177678: BF870296
	.long 0xd71c0006                                           // 00000017767C: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000177680: 02021106
	.long 0xd71c0005                                           // 000000177684: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000177688: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017768C: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 000000177690: D5010005 00020A80
	.long 0xd41b0000                                           // 000000177698: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 00000017769C: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 0000001776A4: D5010006 00020C80
	.long 0xd41e0000                                           // 0000001776AC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 0000001776B0: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001776B8: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 0000001776BC: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 0000001776C8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000001776CC: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 0000001776D4: D5010003 00020CFF 7F800000
	ds_store_b32 v91, v4                                       // 0000001776E0: D8340000 0000045B
	ds_store_b32 v92, v3                                       // 0000001776E8: D8340000 0000035C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001776F0: 8C7E017E
	v_add_nc_u32_e32 v9, s47, v93                              // 0000001776F4: 4A12BA2F
	s_waitcnt lgkmcnt(0)                                       // 0000001776F8: BF89FC07
	s_barrier                                                  // 0000001776FC: BFBD0000
	buffer_gl0_inv                                             // 000000177700: E0AC0000 00000000
	v_min_i32_e32 v3, s46, v9                                  // 000000177708: 2206122E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017770C: BF870091
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 000000177710: D6FF7C03 00096103
	.long 0xd73c0007                                           // 000000177718: D73C0007
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000017771C: 02020689
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000177720: BF870091
	.long 0xd7000042                                           // 000000177724: D7000042
	v_cndmask_b32_e32 v1, s20, v7, vcc_lo                      // 000000177728: 02020E14
	v_add_co_ci_u32_e64 v67, null, s21, v8, s0                 // 00000017772C: D5207C43 00021015
	.long 0xd4430000                                           // 000000177734: D4430000
	v_cndmask_b32_e32 v1, s35, v9, vcc_lo                      // 000000177738: 02021223
	global_load_b128 v[3:6], v[66:67], off                     // 00000017773C: DC5E0000 037C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177744: BE812000
	s_cbranch_execnz 5292                                      // 000000177748: BFA614AC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57fc>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017774C: 8C7E017E
	global_load_b128 v[18:21], v[66:67], off offset:16         // 000000177750: DC5E0010 127C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177758: BE812000
	s_cbranch_execnz 5298                                      // 00000017775C: BFA614B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5828>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177760: 8C7E017E
	global_load_b128 v[22:25], v[66:67], off offset:32         // 000000177764: DC5E0020 167C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017776C: BE812000
	s_cbranch_execnz 5304                                      // 000000177770: BFA614B8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5854>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177774: 8C7E017E
	global_load_b128 v[26:29], v[66:67], off offset:48         // 000000177778: DC5E0030 1A7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177780: BE812000
	s_cbranch_execz 6                                          // 000000177784: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a0>
	s_waitcnt vmcnt(0)                                         // 000000177788: BF8903F7
	v_mov_b32_e32 v27, 0                                       // 00000017778C: 7E360280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000177790: BF870001
	v_mov_b32_e32 v26, v27                                     // 000000177794: 7E34031B
	v_mov_b32_e32 v28, v27                                     // 000000177798: 7E38031B
	v_mov_b32_e32 v29, v27                                     // 00000017779C: 7E3A031B
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001777A0: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:64         // 0000001777A4: DC5E0040 327C0042
	ds_load_b128 v[30:33], v94                                 // 0000001777AC: DBFC0000 1E00005E
	s_waitcnt vmcnt(4)                                         // 0000001777B4: BF8913F7
	v_fma_mixlo_f16 v54, v3, s22, 0                            // 0000001777B8: CC210036 02002D03
	v_fma_mixhi_f16 v54, v4, s22, 0                            // 0000001777C0: CC220036 02002D04
	v_fma_mixlo_f16 v55, v5, s22, 0                            // 0000001777C8: CC210037 02002D05
	v_fma_mixhi_f16 v55, v6, s22, 0                            // 0000001777D0: CC220037 02002D06
	ds_load_b128 v[3:6], v94 offset:16                         // 0000001777D8: DBFC0010 0300005E
	ds_load_b128 v[34:37], v94 offset:32                       // 0000001777E0: DBFC0020 2200005E
	ds_load_b128 v[38:41], v94 offset:48                       // 0000001777E8: DBFC0030 2600005E
	s_waitcnt vmcnt(1)                                         // 0000001777F0: BF8907F7
	v_fma_mixlo_f16 v60, v26, s22, 0                           // 0000001777F4: CC21003C 02002D1A
	v_fma_mixhi_f16 v60, v27, s22, 0                           // 0000001777FC: CC22003C 02002D1B
	v_fma_mixlo_f16 v61, v28, s22, 0                           // 000000177804: CC21003D 02002D1C
	v_fma_mixhi_f16 v61, v29, s22, 0                           // 00000017780C: CC22003D 02002D1D
	ds_load_b128 v[26:29], v94 offset:8448                     // 000000177814: DBFC2100 1A00005E
	v_fma_mixlo_f16 v56, v18, s22, 0                           // 00000017781C: CC210038 02002D12
	v_fma_mixhi_f16 v56, v19, s22, 0                           // 000000177824: CC220038 02002D13
	v_fma_mixlo_f16 v57, v20, s22, 0                           // 00000017782C: CC210039 02002D14
	v_fma_mixhi_f16 v57, v21, s22, 0                           // 000000177834: CC220039 02002D15
	v_fma_mixlo_f16 v58, v22, s22, 0                           // 00000017783C: CC21003A 02002D16
	v_fma_mixhi_f16 v58, v23, s22, 0                           // 000000177844: CC22003A 02002D17
	v_fma_mixlo_f16 v59, v24, s22, 0                           // 00000017784C: CC21003B 02002D18
	v_fma_mixhi_f16 v59, v25, s22, 0                           // 000000177854: CC22003B 02002D19
	s_waitcnt lgkmcnt(4)                                       // 00000017785C: BF89FC47
	v_fma_mixlo_f16 v18, v30, s22, 0                           // 000000177860: CC210012 02002D1E
	v_fma_mixhi_f16 v18, v31, s22, 0                           // 000000177868: CC220012 02002D1F
	v_fma_mixlo_f16 v19, v32, s22, 0                           // 000000177870: CC210013 02002D20
	v_fma_mixhi_f16 v19, v33, s22, 0                           // 000000177878: CC220013 02002D21
	s_waitcnt lgkmcnt(3)                                       // 000000177880: BF89FC37
	v_fma_mixlo_f16 v20, v3, s22, 0                            // 000000177884: CC210014 02002D03
	v_fma_mixhi_f16 v20, v4, s22, 0                            // 00000017788C: CC220014 02002D04
	v_fma_mixlo_f16 v21, v5, s22, 0                            // 000000177894: CC210015 02002D05
	v_fma_mixhi_f16 v21, v6, s22, 0                            // 00000017789C: CC220015 02002D06
	s_waitcnt lgkmcnt(2)                                       // 0000001778A4: BF89FC27
	v_fma_mixlo_f16 v22, v34, s22, 0                           // 0000001778A8: CC210016 02002D22
	v_fma_mixhi_f16 v22, v35, s22, 0                           // 0000001778B0: CC220016 02002D23
	v_fma_mixlo_f16 v23, v36, s22, 0                           // 0000001778B8: CC210017 02002D24
	v_fma_mixhi_f16 v23, v37, s22, 0                           // 0000001778C0: CC220017 02002D25
	s_waitcnt lgkmcnt(1)                                       // 0000001778C8: BF89FC17
	v_fma_mixlo_f16 v24, v38, s22, 0                           // 0000001778CC: CC210018 02002D26
	v_fma_mixhi_f16 v24, v39, s22, 0                           // 0000001778D4: CC220018 02002D27
	v_fma_mixlo_f16 v25, v40, s22, 0                           // 0000001778DC: CC210019 02002D28
	v_fma_mixhi_f16 v25, v41, s22, 0                           // 0000001778E4: CC220019 02002D29
	ds_load_b128 v[3:6], v94 offset:8464                       // 0000001778EC: DBFC2110 0300005E
	ds_load_b128 v[30:33], v94 offset:8480                     // 0000001778F4: DBFC2120 1E00005E
	ds_load_b128 v[34:37], v94 offset:8496                     // 0000001778FC: DBFC2130 2200005E
	ds_load_b128 v[38:41], v94 offset:16896                    // 000000177904: DBFC4200 2600005E
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[18:25], v[10:17]// 00000017790C: CC40402A 1C2A2536
	s_waitcnt lgkmcnt(4)                                       // 000000177914: BF89FC47
	v_fma_mixlo_f16 v18, v26, s22, 0                           // 000000177918: CC210012 02002D1A
	v_fma_mixhi_f16 v18, v27, s22, 0                           // 000000177920: CC220012 02002D1B
	v_fma_mixlo_f16 v19, v28, s22, 0                           // 000000177928: CC210013 02002D1C
	v_fma_mixhi_f16 v19, v29, s22, 0                           // 000000177930: CC220013 02002D1D
	ds_load_b128 v[26:29], v94 offset:16912                    // 000000177938: DBFC4210 1A00005E
	ds_load_b128 v[62:65], v94 offset:25360                    // 000000177940: DBFC6310 3E00005E
	s_waitcnt lgkmcnt(5)                                       // 000000177948: BF89FC57
	v_fma_mixlo_f16 v20, v3, s22, 0                            // 00000017794C: CC210014 02002D03
	v_fma_mixhi_f16 v20, v4, s22, 0                            // 000000177954: CC220014 02002D04
	v_fma_mixlo_f16 v21, v5, s22, 0                            // 00000017795C: CC210015 02002D05
	v_fma_mixhi_f16 v21, v6, s22, 0                            // 000000177964: CC220015 02002D06
	s_waitcnt lgkmcnt(4)                                       // 00000017796C: BF89FC47
	v_fma_mixlo_f16 v22, v30, s22, 0                           // 000000177970: CC210016 02002D1E
	ds_load_b128 v[3:6], v94 offset:16928                      // 000000177978: DBFC4220 0300005E
	v_fma_mixhi_f16 v22, v31, s22, 0                           // 000000177980: CC220016 02002D1F
	v_fma_mixlo_f16 v23, v32, s22, 0                           // 000000177988: CC210017 02002D20
	v_fma_mixhi_f16 v23, v33, s22, 0                           // 000000177990: CC220017 02002D21
	s_waitcnt lgkmcnt(4)                                       // 000000177998: BF89FC47
	v_fma_mixlo_f16 v24, v34, s22, 0                           // 00000017799C: CC210018 02002D22
	ds_load_b128 v[30:33], v94 offset:16944                    // 0000001779A4: DBFC4230 1E00005E
	v_fma_mixhi_f16 v24, v35, s22, 0                           // 0000001779AC: CC220018 02002D23
	v_fma_mixlo_f16 v25, v36, s22, 0                           // 0000001779B4: CC210019 02002D24
	v_fma_mixhi_f16 v25, v37, s22, 0                           // 0000001779BC: CC220019 02002D25
	ds_load_b128 v[34:37], v94 offset:25344                    // 0000001779C4: DBFC6300 2200005E
	s_waitcnt lgkmcnt(5)                                       // 0000001779CC: BF89FC57
	v_fma_mixlo_f16 v68, v38, s22, 0                           // 0000001779D0: CC210044 02002D26
	v_fma_mixhi_f16 v68, v39, s22, 0                           // 0000001779D8: CC220044 02002D27
	v_fma_mixlo_f16 v69, v40, s22, 0                           // 0000001779E0: CC210045 02002D28
	v_fma_mixhi_f16 v69, v41, s22, 0                           // 0000001779E8: CC220045 02002D29
	s_waitcnt lgkmcnt(4)                                       // 0000001779F0: BF89FC47
	v_fma_mixlo_f16 v70, v26, s22, 0                           // 0000001779F4: CC210046 02002D1A
	v_fma_mixhi_f16 v70, v27, s22, 0                           // 0000001779FC: CC220046 02002D1B
	ds_load_b128 v[38:41], v94 offset:25376                    // 000000177A04: DBFC6320 2600005E
	v_fma_mixlo_f16 v71, v28, s22, 0                           // 000000177A0C: CC210047 02002D1C
	v_fma_mixhi_f16 v71, v29, s22, 0                           // 000000177A14: CC220047 02002D1D
	ds_load_b128 v[26:29], v94 offset:25392                    // 000000177A1C: DBFC6330 1A00005E
	s_waitcnt lgkmcnt(4)                                       // 000000177A24: BF89FC47
	v_fma_mixlo_f16 v72, v3, s22, 0                            // 000000177A28: CC210048 02002D03
	v_fma_mixhi_f16 v72, v4, s22, 0                            // 000000177A30: CC220048 02002D04
	v_fma_mixlo_f16 v73, v5, s22, 0                            // 000000177A38: CC210049 02002D05
	v_fma_mixhi_f16 v73, v6, s22, 0                            // 000000177A40: CC220049 02002D06
	v_fma_mixlo_f16 v110, v62, s22, 0                          // 000000177A48: CC21006E 02002D3E
	s_waitcnt lgkmcnt(3)                                       // 000000177A50: BF89FC37
	v_fma_mixlo_f16 v74, v30, s22, 0                           // 000000177A54: CC21004A 02002D1E
	v_fma_mixhi_f16 v74, v31, s22, 0                           // 000000177A5C: CC22004A 02002D1F
	v_fma_mixlo_f16 v75, v32, s22, 0                           // 000000177A64: CC21004B 02002D20
	v_fma_mixhi_f16 v75, v33, s22, 0                           // 000000177A6C: CC22004B 02002D21
	s_waitcnt lgkmcnt(2)                                       // 000000177A74: BF89FC27
	v_fma_mixlo_f16 v108, v34, s22, 0                          // 000000177A78: CC21006C 02002D22
	v_fma_mixhi_f16 v108, v35, s22, 0                          // 000000177A80: CC22006C 02002D23
	v_fma_mixlo_f16 v109, v36, s22, 0                          // 000000177A88: CC21006D 02002D24
	v_fma_mixhi_f16 v109, v37, s22, 0                          // 000000177A90: CC22006D 02002D25
	v_fma_mixhi_f16 v110, v63, s22, 0                          // 000000177A98: CC22006E 02002D3F
	v_fma_mixlo_f16 v111, v64, s22, 0                          // 000000177AA0: CC21006F 02002D40
	v_fma_mixhi_f16 v111, v65, s22, 0                          // 000000177AA8: CC22006F 02002D41
	s_waitcnt lgkmcnt(1)                                       // 000000177AB0: BF89FC17
	v_fma_mixlo_f16 v112, v38, s22, 0                          // 000000177AB4: CC210070 02002D26
	v_fma_mixhi_f16 v112, v39, s22, 0                          // 000000177ABC: CC220070 02002D27
	v_fma_mixlo_f16 v113, v40, s22, 0                          // 000000177AC4: CC210071 02002D28
	v_fma_mixhi_f16 v113, v41, s22, 0                          // 000000177ACC: CC220071 02002D29
	s_waitcnt lgkmcnt(0)                                       // 000000177AD4: BF89FC07
	v_fma_mixlo_f16 v114, v26, s22, 0                          // 000000177AD8: CC210072 02002D1A
	v_fma_mixhi_f16 v114, v27, s22, 0                          // 000000177AE0: CC220072 02002D1B
	v_fma_mixlo_f16 v115, v28, s22, 0                          // 000000177AE8: CC210073 02002D1C
	v_fma_mixhi_f16 v115, v29, s22, 0                          // 000000177AF0: CC220073 02002D1D
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[18:25], v[10:17]// 000000177AF8: CC404022 1C2A2536
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[68:75], v[10:17]// 000000177B00: CC40401A 1C2A8936
	s_delay_alu instid0(VALU_DEP_3)                            // 000000177B08: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[108:115], v[10:17]// 000000177B0C: CC404012 1C2AD936
	s_and_saveexec_b32 s1, s0                                  // 000000177B14: BE812000
	s_cbranch_execnz 5082                                      // 000000177B18: BFA613DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5884>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177B1C: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:80         // 000000177B20: DC5E0050 367C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177B28: BE812000
	s_cbranch_execnz 5088                                      // 000000177B2C: BFA613E0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x58b0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177B30: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:96         // 000000177B34: DC5E0060 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177B3C: BE812000
	s_cbranch_execnz 5094                                      // 000000177B40: BFA613E6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x58dc>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177B44: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:112        // 000000177B48: DC5E0070 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177B50: BE812000
	s_cbranch_execz 6                                          // 000000177B54: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x970>
	s_waitcnt vmcnt(0)                                         // 000000177B58: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 000000177B5C: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000177B60: BF870001
	v_mov_b32_e32 v62, v63                                     // 000000177B64: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 000000177B68: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 000000177B6C: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177B70: 8C7E017E
	global_load_b128 v[3:6], v[66:67], off offset:128          // 000000177B74: DC5E0080 037C0042
	ds_load_b128 v[68:71], v94 offset:64                       // 000000177B7C: DBFC0040 4400005E
	ds_load_b128 v[72:75], v94 offset:80                       // 000000177B84: DBFC0050 4800005E
	ds_load_b128 v[76:79], v94 offset:96                       // 000000177B8C: DBFC0060 4C00005E
	ds_load_b128 v[108:111], v94 offset:112                    // 000000177B94: DBFC0070 6C00005E
	s_waitcnt vmcnt(4)                                         // 000000177B9C: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 000000177BA0: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 000000177BA8: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 000000177BB0: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 000000177BB8: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 000000177BC0: BF890FF7
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 000000177BC4: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 000000177BCC: CC210035 02002D38
	s_waitcnt vmcnt(2)                                         // 000000177BD4: BF890BF7
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000177BD8: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000177BE0: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 000000177BE8: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 000000177BEC: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 000000177BF4: CC220038 02002D3F
	ds_load_b128 v[112:115], v94 offset:8512                   // 000000177BFC: DBFC2140 7000005E
	ds_load_b128 v[116:119], v94 offset:8528                   // 000000177C04: DBFC2150 7400005E
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 000000177C0C: CC210034 02002D36
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 000000177C14: CC220035 02002D39
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000177C1C: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000177C24: CC220036 02002D3B
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 000000177C2C: CC210039 02002D40
	s_waitcnt lgkmcnt(4)                                       // 000000177C34: BF89FC47
	v_fma_mixlo_f16 v60, v72, s22, 0                           // 000000177C38: CC21003C 02002D48
	v_fma_mixhi_f16 v60, v73, s22, 0                           // 000000177C40: CC22003C 02002D49
	v_fma_mixlo_f16 v61, v74, s22, 0                           // 000000177C48: CC21003D 02002D4A
	v_fma_mixhi_f16 v61, v75, s22, 0                           // 000000177C50: CC22003D 02002D4B
	ds_load_b128 v[72:75], v94 offset:8544                     // 000000177C58: DBFC2160 4800005E
	s_waitcnt lgkmcnt(4)                                       // 000000177C60: BF89FC47
	v_fma_mixlo_f16 v62, v76, s22, 0                           // 000000177C64: CC21003E 02002D4C
	v_fma_mixhi_f16 v62, v77, s22, 0                           // 000000177C6C: CC22003E 02002D4D
	v_fma_mixlo_f16 v63, v78, s22, 0                           // 000000177C74: CC21003F 02002D4E
	v_fma_mixhi_f16 v63, v79, s22, 0                           // 000000177C7C: CC22003F 02002D4F
	ds_load_b128 v[76:79], v94 offset:8560                     // 000000177C84: DBFC2170 4C00005E
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 000000177C8C: CC220039 02002D41
	v_fma_mixlo_f16 v58, v68, s22, 0                           // 000000177C94: CC21003A 02002D44
	v_fma_mixhi_f16 v58, v69, s22, 0                           // 000000177C9C: CC22003A 02002D45
	v_fma_mixlo_f16 v59, v70, s22, 0                           // 000000177CA4: CC21003B 02002D46
	v_fma_mixhi_f16 v59, v71, s22, 0                           // 000000177CAC: CC22003B 02002D47
	s_waitcnt lgkmcnt(4)                                       // 000000177CB4: BF89FC47
	v_fma_mixlo_f16 v64, v108, s22, 0                          // 000000177CB8: CC210040 02002D6C
	v_fma_mixhi_f16 v64, v109, s22, 0                          // 000000177CC0: CC220040 02002D6D
	v_fma_mixlo_f16 v65, v110, s22, 0                          // 000000177CC8: CC210041 02002D6E
	v_fma_mixhi_f16 v65, v111, s22, 0                          // 000000177CD0: CC220041 02002D6F
	s_waitcnt lgkmcnt(3)                                       // 000000177CD8: BF89FC37
	v_fma_mixlo_f16 v68, v112, s22, 0                          // 000000177CDC: CC210044 02002D70
	ds_load_b128 v[108:111], v94 offset:16960                  // 000000177CE4: DBFC4240 6C00005E
	v_fma_mixhi_f16 v68, v113, s22, 0                          // 000000177CEC: CC220044 02002D71
	v_fma_mixlo_f16 v69, v114, s22, 0                          // 000000177CF4: CC210045 02002D72
	v_fma_mixhi_f16 v69, v115, s22, 0                          // 000000177CFC: CC220045 02002D73
	s_waitcnt lgkmcnt(3)                                       // 000000177D04: BF89FC37
	v_fma_mixlo_f16 v70, v116, s22, 0                          // 000000177D08: CC210046 02002D74
	ds_load_b128 v[112:115], v94 offset:16976                  // 000000177D10: DBFC4250 7000005E
	v_fma_mixhi_f16 v70, v117, s22, 0                          // 000000177D18: CC220046 02002D75
	v_fma_mixlo_f16 v71, v118, s22, 0                          // 000000177D20: CC210047 02002D76
	v_fma_mixhi_f16 v71, v119, s22, 0                          // 000000177D28: CC220047 02002D77
	s_waitcnt lgkmcnt(3)                                       // 000000177D30: BF89FC37
	v_fma_mixlo_f16 v72, v72, s22, 0                           // 000000177D34: CC210048 02002D48
	ds_load_b128 v[116:119], v94 offset:16992                  // 000000177D3C: DBFC4260 7400005E
	ds_load_b128 v[120:123], v94 offset:17008                  // 000000177D44: DBFC4270 7800005E
	v_fma_mixhi_f16 v72, v73, s22, 0                           // 000000177D4C: CC220048 02002D49
	v_fma_mixlo_f16 v73, v74, s22, 0                           // 000000177D54: CC210049 02002D4A
	v_fma_mixhi_f16 v73, v75, s22, 0                           // 000000177D5C: CC220049 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000177D64: BF89FC47
	v_fma_mixlo_f16 v74, v76, s22, 0                           // 000000177D68: CC21004A 02002D4C
	v_fma_mixhi_f16 v74, v77, s22, 0                           // 000000177D70: CC22004A 02002D4D
	v_fma_mixlo_f16 v75, v78, s22, 0                           // 000000177D78: CC21004B 02002D4E
	v_fma_mixhi_f16 v75, v79, s22, 0                           // 000000177D80: CC22004B 02002D4F
	ds_load_b128 v[76:79], v94 offset:25408                    // 000000177D88: DBFC6340 4C00005E
	ds_load_b128 v[124:127], v94 offset:25424                  // 000000177D90: DBFC6350 7C00005E
	ds_load_b128 v[128:131], v94 offset:25440                  // 000000177D98: DBFC6360 8000005E
	ds_load_b128 v[132:135], v94 offset:25456                  // 000000177DA0: DBFC6370 8400005E
	s_waitcnt lgkmcnt(7)                                       // 000000177DA8: BF89FC77
	v_fma_mixlo_f16 v108, v108, s22, 0                         // 000000177DAC: CC21006C 02002D6C
	v_fma_mixhi_f16 v108, v109, s22, 0                         // 000000177DB4: CC22006C 02002D6D
	v_fma_mixlo_f16 v109, v110, s22, 0                         // 000000177DBC: CC21006D 02002D6E
	v_fma_mixhi_f16 v109, v111, s22, 0                         // 000000177DC4: CC22006D 02002D6F
	s_waitcnt lgkmcnt(6)                                       // 000000177DCC: BF89FC67
	v_fma_mixlo_f16 v110, v112, s22, 0                         // 000000177DD0: CC21006E 02002D70
	v_fma_mixhi_f16 v110, v113, s22, 0                         // 000000177DD8: CC22006E 02002D71
	v_fma_mixlo_f16 v111, v114, s22, 0                         // 000000177DE0: CC21006F 02002D72
	v_fma_mixhi_f16 v111, v115, s22, 0                         // 000000177DE8: CC22006F 02002D73
	s_waitcnt lgkmcnt(5)                                       // 000000177DF0: BF89FC57
	v_fma_mixlo_f16 v112, v116, s22, 0                         // 000000177DF4: CC210070 02002D74
	v_fma_mixhi_f16 v112, v117, s22, 0                         // 000000177DFC: CC220070 02002D75
	v_fma_mixlo_f16 v113, v118, s22, 0                         // 000000177E04: CC210071 02002D76
	v_fma_mixhi_f16 v113, v119, s22, 0                         // 000000177E0C: CC220071 02002D77
	s_waitcnt lgkmcnt(4)                                       // 000000177E14: BF89FC47
	v_fma_mixlo_f16 v114, v120, s22, 0                         // 000000177E18: CC210072 02002D78
	v_fma_mixhi_f16 v114, v121, s22, 0                         // 000000177E20: CC220072 02002D79
	v_fma_mixlo_f16 v115, v122, s22, 0                         // 000000177E28: CC210073 02002D7A
	v_fma_mixhi_f16 v115, v123, s22, 0                         // 000000177E30: CC220073 02002D7B
	s_waitcnt lgkmcnt(3)                                       // 000000177E38: BF89FC37
	v_fma_mixlo_f16 v116, v76, s22, 0                          // 000000177E3C: CC210074 02002D4C
	v_fma_mixhi_f16 v116, v77, s22, 0                          // 000000177E44: CC220074 02002D4D
	v_fma_mixlo_f16 v117, v78, s22, 0                          // 000000177E4C: CC210075 02002D4E
	v_fma_mixhi_f16 v117, v79, s22, 0                          // 000000177E54: CC220075 02002D4F
	s_waitcnt lgkmcnt(2)                                       // 000000177E5C: BF89FC27
	v_fma_mixlo_f16 v118, v124, s22, 0                         // 000000177E60: CC210076 02002D7C
	v_fma_mixhi_f16 v118, v125, s22, 0                         // 000000177E68: CC220076 02002D7D
	v_fma_mixlo_f16 v119, v126, s22, 0                         // 000000177E70: CC210077 02002D7E
	v_fma_mixhi_f16 v119, v127, s22, 0                         // 000000177E78: CC220077 02002D7F
	s_waitcnt lgkmcnt(1)                                       // 000000177E80: BF89FC17
	v_fma_mixlo_f16 v120, v128, s22, 0                         // 000000177E84: CC210078 02002D80
	v_fma_mixhi_f16 v120, v129, s22, 0                         // 000000177E8C: CC220078 02002D81
	v_fma_mixlo_f16 v121, v130, s22, 0                         // 000000177E94: CC210079 02002D82
	v_fma_mixhi_f16 v121, v131, s22, 0                         // 000000177E9C: CC220079 02002D83
	s_waitcnt lgkmcnt(0)                                       // 000000177EA4: BF89FC07
	v_fma_mixlo_f16 v122, v132, s22, 0                         // 000000177EA8: CC21007A 02002D84
	v_fma_mixhi_f16 v122, v133, s22, 0                         // 000000177EB0: CC22007A 02002D85
	v_fma_mixlo_f16 v123, v134, s22, 0                         // 000000177EB8: CC21007B 02002D86
	v_fma_mixhi_f16 v123, v135, s22, 0                         // 000000177EC0: CC22007B 02002D87
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 000000177EC8: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[68:75], v[34:41]// 000000177ED0: CC404022 1C8A8932
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[108:115], v[26:33]// 000000177ED8: CC40401A 1C6AD932
	s_delay_alu instid0(VALU_DEP_4)                            // 000000177EE0: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[116:123], v[18:25]// 000000177EE4: CC404012 1C4AE932
	s_and_saveexec_b32 s1, s0                                  // 000000177EEC: BE812000
	s_cbranch_execnz 4870                                      // 000000177EF0: BFA61306 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x590c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177EF4: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:144        // 000000177EF8: DC5E0090 367C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177F00: BE812000
	s_cbranch_execnz 4876                                      // 000000177F04: BFA6130C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5938>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177F08: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:160        // 000000177F0C: DC5E00A0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177F14: BE812000
	s_cbranch_execnz 4882                                      // 000000177F18: BFA61312 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5964>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177F1C: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:176        // 000000177F20: DC5E00B0 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000177F28: BE812000
	s_cbranch_execz 6                                          // 000000177F2C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd48>
	s_waitcnt vmcnt(0)                                         // 000000177F30: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 000000177F34: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000177F38: BF870001
	v_mov_b32_e32 v62, v63                                     // 000000177F3C: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 000000177F40: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 000000177F44: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000177F48: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:192        // 000000177F4C: DC5E00C0 327C0042
	s_waitcnt vmcnt(4)                                         // 000000177F54: BF8913F7
	v_fma_mixlo_f16 v68, v3, s22, 0                            // 000000177F58: CC210044 02002D03
	ds_load_b128 v[76:79], v94 offset:128                      // 000000177F60: DBFC0080 4C00005E
	v_fma_mixhi_f16 v68, v4, s22, 0                            // 000000177F68: CC220044 02002D04
	v_fma_mixlo_f16 v69, v5, s22, 0                            // 000000177F70: CC210045 02002D05
	v_fma_mixhi_f16 v69, v6, s22, 0                            // 000000177F78: CC220045 02002D06
	ds_load_b128 v[3:6], v94 offset:144                        // 000000177F80: DBFC0090 0300005E
	ds_load_b128 v[108:111], v94 offset:160                    // 000000177F88: DBFC00A0 6C00005E
	ds_load_b128 v[112:115], v94 offset:176                    // 000000177F90: DBFC00B0 7000005E
	s_waitcnt vmcnt(1)                                         // 000000177F98: BF8907F7
	v_fma_mixlo_f16 v74, v62, s22, 0                           // 000000177F9C: CC21004A 02002D3E
	v_fma_mixhi_f16 v74, v63, s22, 0                           // 000000177FA4: CC22004A 02002D3F
	v_fma_mixlo_f16 v75, v64, s22, 0                           // 000000177FAC: CC21004B 02002D40
	v_fma_mixhi_f16 v75, v65, s22, 0                           // 000000177FB4: CC22004B 02002D41
	ds_load_b128 v[62:65], v94 offset:8576                     // 000000177FBC: DBFC2180 3E00005E
	v_fma_mixlo_f16 v70, v54, s22, 0                           // 000000177FC4: CC210046 02002D36
	v_fma_mixhi_f16 v70, v55, s22, 0                           // 000000177FCC: CC220046 02002D37
	v_fma_mixlo_f16 v71, v56, s22, 0                           // 000000177FD4: CC210047 02002D38
	v_fma_mixhi_f16 v71, v57, s22, 0                           // 000000177FDC: CC220047 02002D39
	v_fma_mixlo_f16 v72, v58, s22, 0                           // 000000177FE4: CC210048 02002D3A
	ds_load_b128 v[120:123], v94 offset:17024                  // 000000177FEC: DBFC4280 7800005E
	ds_load_b128 v[116:119], v94 offset:8624                   // 000000177FF4: DBFC21B0 7400005E
	v_fma_mixhi_f16 v72, v59, s22, 0                           // 000000177FFC: CC220048 02002D3B
	s_waitcnt lgkmcnt(6)                                       // 000000178004: BF89FC67
	v_fma_mixlo_f16 v54, v76, s22, 0                           // 000000178008: CC210036 02002D4C
	v_fma_mixhi_f16 v54, v77, s22, 0                           // 000000178010: CC220036 02002D4D
	v_fma_mixlo_f16 v55, v78, s22, 0                           // 000000178018: CC210037 02002D4E
	v_fma_mixhi_f16 v55, v79, s22, 0                           // 000000178020: CC220037 02002D4F
	ds_load_b128 v[76:79], v94 offset:8592                     // 000000178028: DBFC2190 4C00005E
	s_waitcnt lgkmcnt(6)                                       // 000000178030: BF89FC67
	v_fma_mixlo_f16 v56, v3, s22, 0                            // 000000178034: CC210038 02002D03
	v_fma_mixhi_f16 v56, v4, s22, 0                            // 00000017803C: CC220038 02002D04
	v_fma_mixlo_f16 v57, v5, s22, 0                            // 000000178044: CC210039 02002D05
	v_fma_mixhi_f16 v57, v6, s22, 0                            // 00000017804C: CC220039 02002D06
	ds_load_b128 v[3:6], v94 offset:8608                       // 000000178054: DBFC21A0 0300005E
	s_waitcnt lgkmcnt(6)                                       // 00000017805C: BF89FC67
	v_fma_mixlo_f16 v58, v108, s22, 0                          // 000000178060: CC21003A 02002D6C
	v_fma_mixhi_f16 v58, v109, s22, 0                          // 000000178068: CC22003A 02002D6D
	s_waitcnt lgkmcnt(4)                                       // 000000178070: BF89FC47
	v_fma_mixlo_f16 v108, v62, s22, 0                          // 000000178074: CC21006C 02002D3E
	v_fma_mixhi_f16 v108, v63, s22, 0                          // 00000017807C: CC22006C 02002D3F
	v_fma_mixlo_f16 v109, v64, s22, 0                          // 000000178084: CC21006D 02002D40
	v_fma_mixhi_f16 v109, v65, s22, 0                          // 00000017808C: CC22006D 02002D41
	ds_load_b128 v[62:65], v94 offset:17040                    // 000000178094: DBFC4290 3E00005E
	v_fma_mixlo_f16 v73, v60, s22, 0                           // 00000017809C: CC210049 02002D3C
	v_fma_mixhi_f16 v73, v61, s22, 0                           // 0000001780A4: CC220049 02002D3D
	v_fma_mixlo_f16 v59, v110, s22, 0                          // 0000001780AC: CC21003B 02002D6E
	v_fma_mixhi_f16 v59, v111, s22, 0                          // 0000001780B4: CC22003B 02002D6F
	v_fma_mixlo_f16 v60, v112, s22, 0                          // 0000001780BC: CC21003C 02002D70
	v_fma_mixhi_f16 v60, v113, s22, 0                          // 0000001780C4: CC22003C 02002D71
	v_fma_mixhi_f16 v61, v115, s22, 0                          // 0000001780CC: CC22003D 02002D73
	s_waitcnt lgkmcnt(2)                                       // 0000001780D4: BF89FC27
	v_fma_mixlo_f16 v110, v76, s22, 0                          // 0000001780D8: CC21006E 02002D4C
	v_fma_mixhi_f16 v110, v77, s22, 0                          // 0000001780E0: CC22006E 02002D4D
	v_fma_mixlo_f16 v111, v78, s22, 0                          // 0000001780E8: CC21006F 02002D4E
	v_fma_mixhi_f16 v111, v79, s22, 0                          // 0000001780F0: CC22006F 02002D4F
	ds_load_b128 v[76:79], v94 offset:17056                    // 0000001780F8: DBFC42A0 4C00005E
	s_waitcnt lgkmcnt(2)                                       // 000000178100: BF89FC27
	v_fma_mixlo_f16 v112, v3, s22, 0                           // 000000178104: CC210070 02002D03
	v_fma_mixhi_f16 v112, v4, s22, 0                           // 00000017810C: CC220070 02002D04
	v_fma_mixlo_f16 v113, v5, s22, 0                           // 000000178114: CC210071 02002D05
	v_fma_mixhi_f16 v113, v6, s22, 0                           // 00000017811C: CC220071 02002D06
	ds_load_b128 v[3:6], v94 offset:17072                      // 000000178124: DBFC42B0 0300005E
	v_fma_mixlo_f16 v115, v118, s22, 0                         // 00000017812C: CC210073 02002D76
	v_fma_mixhi_f16 v115, v119, s22, 0                         // 000000178134: CC220073 02002D77
	ds_load_b128 v[124:127], v94 offset:25472                  // 00000017813C: DBFC6380 7C00005E
	ds_load_b128 v[128:131], v94 offset:25488                  // 000000178144: DBFC6390 8000005E
	s_waitcnt lgkmcnt(4)                                       // 00000017814C: BF89FC47
	v_fma_mixlo_f16 v118, v62, s22, 0                          // 000000178150: CC210076 02002D3E
	v_fma_mixhi_f16 v118, v63, s22, 0                          // 000000178158: CC220076 02002D3F
	ds_load_b128 v[132:135], v94 offset:25504                  // 000000178160: DBFC63A0 8400005E
	v_fma_mixlo_f16 v119, v64, s22, 0                          // 000000178168: CC210077 02002D40
	v_fma_mixhi_f16 v119, v65, s22, 0                          // 000000178170: CC220077 02002D41
	ds_load_b128 v[62:65], v94 offset:25520                    // 000000178178: DBFC63B0 3E00005E
	v_fma_mixlo_f16 v61, v114, s22, 0                          // 000000178180: CC21003D 02002D72
	v_fma_mixlo_f16 v114, v116, s22, 0                         // 000000178188: CC210072 02002D74
	v_fma_mixhi_f16 v114, v117, s22, 0                         // 000000178190: CC220072 02002D75
	v_fma_mixlo_f16 v116, v120, s22, 0                         // 000000178198: CC210074 02002D78
	v_fma_mixhi_f16 v116, v121, s22, 0                         // 0000001781A0: CC220074 02002D79
	v_fma_mixlo_f16 v117, v122, s22, 0                         // 0000001781A8: CC210075 02002D7A
	v_fma_mixhi_f16 v117, v123, s22, 0                         // 0000001781B0: CC220075 02002D7B
	s_waitcnt lgkmcnt(5)                                       // 0000001781B8: BF89FC57
	v_fma_mixlo_f16 v120, v76, s22, 0                          // 0000001781BC: CC210078 02002D4C
	v_fma_mixhi_f16 v120, v77, s22, 0                          // 0000001781C4: CC220078 02002D4D
	v_fma_mixlo_f16 v121, v78, s22, 0                          // 0000001781CC: CC210079 02002D4E
	v_fma_mixhi_f16 v121, v79, s22, 0                          // 0000001781D4: CC220079 02002D4F
	s_waitcnt lgkmcnt(4)                                       // 0000001781DC: BF89FC47
	v_fma_mixlo_f16 v122, v3, s22, 0                           // 0000001781E0: CC21007A 02002D03
	v_fma_mixhi_f16 v122, v4, s22, 0                           // 0000001781E8: CC22007A 02002D04
	v_fma_mixlo_f16 v123, v5, s22, 0                           // 0000001781F0: CC21007B 02002D05
	v_fma_mixhi_f16 v123, v6, s22, 0                           // 0000001781F8: CC22007B 02002D06
	s_waitcnt lgkmcnt(3)                                       // 000000178200: BF89FC37
	v_fma_mixlo_f16 v124, v124, s22, 0                         // 000000178204: CC21007C 02002D7C
	v_fma_mixhi_f16 v124, v125, s22, 0                         // 00000017820C: CC22007C 02002D7D
	v_fma_mixlo_f16 v125, v126, s22, 0                         // 000000178214: CC21007D 02002D7E
	v_fma_mixhi_f16 v125, v127, s22, 0                         // 00000017821C: CC22007D 02002D7F
	s_waitcnt lgkmcnt(2)                                       // 000000178224: BF89FC27
	v_fma_mixlo_f16 v126, v128, s22, 0                         // 000000178228: CC21007E 02002D80
	v_fma_mixhi_f16 v126, v129, s22, 0                         // 000000178230: CC22007E 02002D81
	v_fma_mixlo_f16 v127, v130, s22, 0                         // 000000178238: CC21007F 02002D82
	v_fma_mixhi_f16 v127, v131, s22, 0                         // 000000178240: CC22007F 02002D83
	s_waitcnt lgkmcnt(1)                                       // 000000178248: BF89FC17
	v_fma_mixlo_f16 v128, v132, s22, 0                         // 00000017824C: CC210080 02002D84
	v_fma_mixhi_f16 v128, v133, s22, 0                         // 000000178254: CC220080 02002D85
	v_fma_mixlo_f16 v129, v134, s22, 0                         // 00000017825C: CC210081 02002D86
	v_fma_mixhi_f16 v129, v135, s22, 0                         // 000000178264: CC220081 02002D87
	s_waitcnt lgkmcnt(0)                                       // 00000017826C: BF89FC07
	v_fma_mixlo_f16 v130, v62, s22, 0                          // 000000178270: CC210082 02002D3E
	v_fma_mixhi_f16 v130, v63, s22, 0                          // 000000178278: CC220082 02002D3F
	v_fma_mixlo_f16 v131, v64, s22, 0                          // 000000178280: CC210083 02002D40
	v_fma_mixhi_f16 v131, v65, s22, 0                          // 000000178288: CC220083 02002D41
	v_wmma_f32_16x16x16_f16 v[42:49], v[68:75], v[54:61], v[42:49]// 000000178290: CC40402A 1CAA6D44
	v_wmma_f32_16x16x16_f16 v[34:41], v[68:75], v[108:115], v[34:41]// 000000178298: CC404022 1C8AD944
	v_wmma_f32_16x16x16_f16 v[26:33], v[68:75], v[116:123], v[26:33]// 0000001782A0: CC40401A 1C6AE944
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001782A8: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[68:75], v[124:131], v[18:25]// 0000001782AC: CC404012 1C4AF944
	s_and_saveexec_b32 s1, s0                                  // 0000001782B4: BE812000
	s_cbranch_execnz 4662                                      // 0000001782B8: BFA61236 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5994>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001782BC: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:208        // 0000001782C0: DC5E00D0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001782C8: BE812000
	s_cbranch_execnz 4668                                      // 0000001782CC: BFA6123C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x59c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001782D0: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:224        // 0000001782D4: DC5E00E0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001782DC: BE812000
	s_cbranch_execnz 4674                                      // 0000001782E0: BFA61242 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x59ec>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001782E4: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:240        // 0000001782E8: DC5E00F0 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001782F0: BE812000
	s_cbranch_execz 6                                          // 0000001782F4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1110>
	s_waitcnt vmcnt(0)                                         // 0000001782F8: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 0000001782FC: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000178300: BF870001
	v_mov_b32_e32 v62, v63                                     // 000000178304: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 000000178308: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017830C: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178310: 8C7E017E
	global_load_b128 v[3:6], v[66:67], off offset:256          // 000000178314: DC5E0100 037C0042
	ds_load_b128 v[68:71], v94 offset:192                      // 00000017831C: DBFC00C0 4400005E
	ds_load_b128 v[72:75], v94 offset:208                      // 000000178324: DBFC00D0 4800005E
	ds_load_b128 v[76:79], v94 offset:224                      // 00000017832C: DBFC00E0 4C00005E
	ds_load_b128 v[108:111], v94 offset:240                    // 000000178334: DBFC00F0 6C00005E
	s_waitcnt vmcnt(4)                                         // 00000017833C: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 000000178340: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 000000178348: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 000000178350: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 000000178358: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 000000178360: BF890FF7
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 000000178364: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 00000017836C: CC210035 02002D38
	s_waitcnt vmcnt(2)                                         // 000000178374: BF890BF7
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000178378: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000178380: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 000000178388: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 00000017838C: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 000000178394: CC220038 02002D3F
	ds_load_b128 v[112:115], v94 offset:8640                   // 00000017839C: DBFC21C0 7000005E
	ds_load_b128 v[116:119], v94 offset:8656                   // 0000001783A4: DBFC21D0 7400005E
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 0000001783AC: CC210034 02002D36
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 0000001783B4: CC220035 02002D39
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 0000001783BC: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 0000001783C4: CC220036 02002D3B
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 0000001783CC: CC210039 02002D40
	s_waitcnt lgkmcnt(4)                                       // 0000001783D4: BF89FC47
	v_fma_mixlo_f16 v60, v72, s22, 0                           // 0000001783D8: CC21003C 02002D48
	v_fma_mixhi_f16 v60, v73, s22, 0                           // 0000001783E0: CC22003C 02002D49
	v_fma_mixlo_f16 v61, v74, s22, 0                           // 0000001783E8: CC21003D 02002D4A
	v_fma_mixhi_f16 v61, v75, s22, 0                           // 0000001783F0: CC22003D 02002D4B
	ds_load_b128 v[72:75], v94 offset:8672                     // 0000001783F8: DBFC21E0 4800005E
	s_waitcnt lgkmcnt(4)                                       // 000000178400: BF89FC47
	v_fma_mixlo_f16 v62, v76, s22, 0                           // 000000178404: CC21003E 02002D4C
	v_fma_mixhi_f16 v62, v77, s22, 0                           // 00000017840C: CC22003E 02002D4D
	v_fma_mixlo_f16 v63, v78, s22, 0                           // 000000178414: CC21003F 02002D4E
	v_fma_mixhi_f16 v63, v79, s22, 0                           // 00000017841C: CC22003F 02002D4F
	ds_load_b128 v[76:79], v94 offset:8688                     // 000000178424: DBFC21F0 4C00005E
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 00000017842C: CC220039 02002D41
	v_fma_mixlo_f16 v58, v68, s22, 0                           // 000000178434: CC21003A 02002D44
	v_fma_mixhi_f16 v58, v69, s22, 0                           // 00000017843C: CC22003A 02002D45
	v_fma_mixlo_f16 v59, v70, s22, 0                           // 000000178444: CC21003B 02002D46
	v_fma_mixhi_f16 v59, v71, s22, 0                           // 00000017844C: CC22003B 02002D47
	s_waitcnt lgkmcnt(4)                                       // 000000178454: BF89FC47
	v_fma_mixlo_f16 v64, v108, s22, 0                          // 000000178458: CC210040 02002D6C
	v_fma_mixhi_f16 v64, v109, s22, 0                          // 000000178460: CC220040 02002D6D
	v_fma_mixlo_f16 v65, v110, s22, 0                          // 000000178468: CC210041 02002D6E
	v_fma_mixhi_f16 v65, v111, s22, 0                          // 000000178470: CC220041 02002D6F
	s_waitcnt lgkmcnt(3)                                       // 000000178478: BF89FC37
	v_fma_mixlo_f16 v68, v112, s22, 0                          // 00000017847C: CC210044 02002D70
	ds_load_b128 v[108:111], v94 offset:17088                  // 000000178484: DBFC42C0 6C00005E
	v_fma_mixhi_f16 v68, v113, s22, 0                          // 00000017848C: CC220044 02002D71
	v_fma_mixlo_f16 v69, v114, s22, 0                          // 000000178494: CC210045 02002D72
	v_fma_mixhi_f16 v69, v115, s22, 0                          // 00000017849C: CC220045 02002D73
	s_waitcnt lgkmcnt(3)                                       // 0000001784A4: BF89FC37
	v_fma_mixlo_f16 v70, v116, s22, 0                          // 0000001784A8: CC210046 02002D74
	ds_load_b128 v[112:115], v94 offset:17104                  // 0000001784B0: DBFC42D0 7000005E
	v_fma_mixhi_f16 v70, v117, s22, 0                          // 0000001784B8: CC220046 02002D75
	v_fma_mixlo_f16 v71, v118, s22, 0                          // 0000001784C0: CC210047 02002D76
	v_fma_mixhi_f16 v71, v119, s22, 0                          // 0000001784C8: CC220047 02002D77
	s_waitcnt lgkmcnt(3)                                       // 0000001784D0: BF89FC37
	v_fma_mixlo_f16 v72, v72, s22, 0                           // 0000001784D4: CC210048 02002D48
	ds_load_b128 v[116:119], v94 offset:17120                  // 0000001784DC: DBFC42E0 7400005E
	ds_load_b128 v[120:123], v94 offset:17136                  // 0000001784E4: DBFC42F0 7800005E
	v_fma_mixhi_f16 v72, v73, s22, 0                           // 0000001784EC: CC220048 02002D49
	v_fma_mixlo_f16 v73, v74, s22, 0                           // 0000001784F4: CC210049 02002D4A
	v_fma_mixhi_f16 v73, v75, s22, 0                           // 0000001784FC: CC220049 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000178504: BF89FC47
	v_fma_mixlo_f16 v74, v76, s22, 0                           // 000000178508: CC21004A 02002D4C
	v_fma_mixhi_f16 v74, v77, s22, 0                           // 000000178510: CC22004A 02002D4D
	v_fma_mixlo_f16 v75, v78, s22, 0                           // 000000178518: CC21004B 02002D4E
	v_fma_mixhi_f16 v75, v79, s22, 0                           // 000000178520: CC22004B 02002D4F
	ds_load_b128 v[76:79], v94 offset:25536                    // 000000178528: DBFC63C0 4C00005E
	ds_load_b128 v[124:127], v94 offset:25552                  // 000000178530: DBFC63D0 7C00005E
	ds_load_b128 v[128:131], v94 offset:25568                  // 000000178538: DBFC63E0 8000005E
	ds_load_b128 v[132:135], v94 offset:25584                  // 000000178540: DBFC63F0 8400005E
	s_waitcnt lgkmcnt(7)                                       // 000000178548: BF89FC77
	v_fma_mixlo_f16 v108, v108, s22, 0                         // 00000017854C: CC21006C 02002D6C
	v_fma_mixhi_f16 v108, v109, s22, 0                         // 000000178554: CC22006C 02002D6D
	v_fma_mixlo_f16 v109, v110, s22, 0                         // 00000017855C: CC21006D 02002D6E
	v_fma_mixhi_f16 v109, v111, s22, 0                         // 000000178564: CC22006D 02002D6F
	s_waitcnt lgkmcnt(6)                                       // 00000017856C: BF89FC67
	v_fma_mixlo_f16 v110, v112, s22, 0                         // 000000178570: CC21006E 02002D70
	v_fma_mixhi_f16 v110, v113, s22, 0                         // 000000178578: CC22006E 02002D71
	v_fma_mixlo_f16 v111, v114, s22, 0                         // 000000178580: CC21006F 02002D72
	v_fma_mixhi_f16 v111, v115, s22, 0                         // 000000178588: CC22006F 02002D73
	s_waitcnt lgkmcnt(5)                                       // 000000178590: BF89FC57
	v_fma_mixlo_f16 v112, v116, s22, 0                         // 000000178594: CC210070 02002D74
	v_fma_mixhi_f16 v112, v117, s22, 0                         // 00000017859C: CC220070 02002D75
	v_fma_mixlo_f16 v113, v118, s22, 0                         // 0000001785A4: CC210071 02002D76
	v_fma_mixhi_f16 v113, v119, s22, 0                         // 0000001785AC: CC220071 02002D77
	s_waitcnt lgkmcnt(4)                                       // 0000001785B4: BF89FC47
	v_fma_mixlo_f16 v114, v120, s22, 0                         // 0000001785B8: CC210072 02002D78
	v_fma_mixhi_f16 v114, v121, s22, 0                         // 0000001785C0: CC220072 02002D79
	v_fma_mixlo_f16 v115, v122, s22, 0                         // 0000001785C8: CC210073 02002D7A
	v_fma_mixhi_f16 v115, v123, s22, 0                         // 0000001785D0: CC220073 02002D7B
	s_waitcnt lgkmcnt(3)                                       // 0000001785D8: BF89FC37
	v_fma_mixlo_f16 v116, v76, s22, 0                          // 0000001785DC: CC210074 02002D4C
	v_fma_mixhi_f16 v116, v77, s22, 0                          // 0000001785E4: CC220074 02002D4D
	v_fma_mixlo_f16 v117, v78, s22, 0                          // 0000001785EC: CC210075 02002D4E
	v_fma_mixhi_f16 v117, v79, s22, 0                          // 0000001785F4: CC220075 02002D4F
	s_waitcnt lgkmcnt(2)                                       // 0000001785FC: BF89FC27
	v_fma_mixlo_f16 v118, v124, s22, 0                         // 000000178600: CC210076 02002D7C
	v_fma_mixhi_f16 v118, v125, s22, 0                         // 000000178608: CC220076 02002D7D
	v_fma_mixlo_f16 v119, v126, s22, 0                         // 000000178610: CC210077 02002D7E
	v_fma_mixhi_f16 v119, v127, s22, 0                         // 000000178618: CC220077 02002D7F
	s_waitcnt lgkmcnt(1)                                       // 000000178620: BF89FC17
	v_fma_mixlo_f16 v120, v128, s22, 0                         // 000000178624: CC210078 02002D80
	v_fma_mixhi_f16 v120, v129, s22, 0                         // 00000017862C: CC220078 02002D81
	v_fma_mixlo_f16 v121, v130, s22, 0                         // 000000178634: CC210079 02002D82
	v_fma_mixhi_f16 v121, v131, s22, 0                         // 00000017863C: CC220079 02002D83
	s_waitcnt lgkmcnt(0)                                       // 000000178644: BF89FC07
	v_fma_mixlo_f16 v122, v132, s22, 0                         // 000000178648: CC21007A 02002D84
	v_fma_mixhi_f16 v122, v133, s22, 0                         // 000000178650: CC22007A 02002D85
	v_fma_mixlo_f16 v123, v134, s22, 0                         // 000000178658: CC21007B 02002D86
	v_fma_mixhi_f16 v123, v135, s22, 0                         // 000000178660: CC22007B 02002D87
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 000000178668: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[68:75], v[34:41]// 000000178670: CC404022 1C8A8932
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[108:115], v[26:33]// 000000178678: CC40401A 1C6AD932
	s_delay_alu instid0(VALU_DEP_4)                            // 000000178680: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[116:123], v[18:25]// 000000178684: CC404012 1C4AE932
	s_and_saveexec_b32 s1, s0                                  // 00000017868C: BE812000
	s_cbranch_execnz 4450                                      // 000000178690: BFA61162 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a1c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178694: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:272        // 000000178698: DC5E0110 367C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001786A0: BE812000
	s_cbranch_execnz 4456                                      // 0000001786A4: BFA61168 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a48>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001786A8: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:288        // 0000001786AC: DC5E0120 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001786B4: BE812000
	s_cbranch_execnz 4462                                      // 0000001786B8: BFA6116E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a74>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001786BC: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:304        // 0000001786C0: DC5E0130 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 0000001786C8: BE812000
	s_cbranch_execz 6                                          // 0000001786CC: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14e8>
	s_waitcnt vmcnt(0)                                         // 0000001786D0: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 0000001786D4: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001786D8: BF870001
	v_mov_b32_e32 v62, v63                                     // 0000001786DC: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 0000001786E0: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 0000001786E4: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001786E8: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:320        // 0000001786EC: DC5E0140 327C0042
	s_waitcnt vmcnt(4)                                         // 0000001786F4: BF8913F7
	v_fma_mixlo_f16 v68, v3, s22, 0                            // 0000001786F8: CC210044 02002D03
	ds_load_b128 v[76:79], v94 offset:256                      // 000000178700: DBFC0100 4C00005E
	v_fma_mixhi_f16 v68, v4, s22, 0                            // 000000178708: CC220044 02002D04
	v_fma_mixlo_f16 v69, v5, s22, 0                            // 000000178710: CC210045 02002D05
	v_fma_mixhi_f16 v69, v6, s22, 0                            // 000000178718: CC220045 02002D06
	ds_load_b128 v[3:6], v94 offset:272                        // 000000178720: DBFC0110 0300005E
	ds_load_b128 v[108:111], v94 offset:288                    // 000000178728: DBFC0120 6C00005E
	ds_load_b128 v[112:115], v94 offset:304                    // 000000178730: DBFC0130 7000005E
	s_waitcnt vmcnt(1)                                         // 000000178738: BF8907F7
	v_fma_mixlo_f16 v74, v62, s22, 0                           // 00000017873C: CC21004A 02002D3E
	v_fma_mixhi_f16 v74, v63, s22, 0                           // 000000178744: CC22004A 02002D3F
	v_fma_mixlo_f16 v75, v64, s22, 0                           // 00000017874C: CC21004B 02002D40
	v_fma_mixhi_f16 v75, v65, s22, 0                           // 000000178754: CC22004B 02002D41
	ds_load_b128 v[62:65], v94 offset:8704                     // 00000017875C: DBFC2200 3E00005E
	v_fma_mixlo_f16 v70, v54, s22, 0                           // 000000178764: CC210046 02002D36
	v_fma_mixhi_f16 v70, v55, s22, 0                           // 00000017876C: CC220046 02002D37
	v_fma_mixlo_f16 v71, v56, s22, 0                           // 000000178774: CC210047 02002D38
	v_fma_mixhi_f16 v71, v57, s22, 0                           // 00000017877C: CC220047 02002D39
	v_fma_mixlo_f16 v72, v58, s22, 0                           // 000000178784: CC210048 02002D3A
	ds_load_b128 v[120:123], v94 offset:17152                  // 00000017878C: DBFC4300 7800005E
	ds_load_b128 v[116:119], v94 offset:8752                   // 000000178794: DBFC2230 7400005E
	v_fma_mixhi_f16 v72, v59, s22, 0                           // 00000017879C: CC220048 02002D3B
	s_waitcnt lgkmcnt(6)                                       // 0000001787A4: BF89FC67
	v_fma_mixlo_f16 v54, v76, s22, 0                           // 0000001787A8: CC210036 02002D4C
	v_fma_mixhi_f16 v54, v77, s22, 0                           // 0000001787B0: CC220036 02002D4D
	v_fma_mixlo_f16 v55, v78, s22, 0                           // 0000001787B8: CC210037 02002D4E
	v_fma_mixhi_f16 v55, v79, s22, 0                           // 0000001787C0: CC220037 02002D4F
	ds_load_b128 v[76:79], v94 offset:8720                     // 0000001787C8: DBFC2210 4C00005E
	s_waitcnt lgkmcnt(6)                                       // 0000001787D0: BF89FC67
	v_fma_mixlo_f16 v56, v3, s22, 0                            // 0000001787D4: CC210038 02002D03
	v_fma_mixhi_f16 v56, v4, s22, 0                            // 0000001787DC: CC220038 02002D04
	v_fma_mixlo_f16 v57, v5, s22, 0                            // 0000001787E4: CC210039 02002D05
	v_fma_mixhi_f16 v57, v6, s22, 0                            // 0000001787EC: CC220039 02002D06
	ds_load_b128 v[3:6], v94 offset:8736                       // 0000001787F4: DBFC2220 0300005E
	s_waitcnt lgkmcnt(6)                                       // 0000001787FC: BF89FC67
	v_fma_mixlo_f16 v58, v108, s22, 0                          // 000000178800: CC21003A 02002D6C
	v_fma_mixhi_f16 v58, v109, s22, 0                          // 000000178808: CC22003A 02002D6D
	s_waitcnt lgkmcnt(4)                                       // 000000178810: BF89FC47
	v_fma_mixlo_f16 v108, v62, s22, 0                          // 000000178814: CC21006C 02002D3E
	v_fma_mixhi_f16 v108, v63, s22, 0                          // 00000017881C: CC22006C 02002D3F
	v_fma_mixlo_f16 v109, v64, s22, 0                          // 000000178824: CC21006D 02002D40
	v_fma_mixhi_f16 v109, v65, s22, 0                          // 00000017882C: CC22006D 02002D41
	ds_load_b128 v[62:65], v94 offset:17168                    // 000000178834: DBFC4310 3E00005E
	v_fma_mixlo_f16 v73, v60, s22, 0                           // 00000017883C: CC210049 02002D3C
	v_fma_mixhi_f16 v73, v61, s22, 0                           // 000000178844: CC220049 02002D3D
	v_fma_mixlo_f16 v59, v110, s22, 0                          // 00000017884C: CC21003B 02002D6E
	v_fma_mixhi_f16 v59, v111, s22, 0                          // 000000178854: CC22003B 02002D6F
	v_fma_mixlo_f16 v60, v112, s22, 0                          // 00000017885C: CC21003C 02002D70
	v_fma_mixhi_f16 v60, v113, s22, 0                          // 000000178864: CC22003C 02002D71
	v_fma_mixhi_f16 v61, v115, s22, 0                          // 00000017886C: CC22003D 02002D73
	s_waitcnt lgkmcnt(2)                                       // 000000178874: BF89FC27
	v_fma_mixlo_f16 v110, v76, s22, 0                          // 000000178878: CC21006E 02002D4C
	v_fma_mixhi_f16 v110, v77, s22, 0                          // 000000178880: CC22006E 02002D4D
	v_fma_mixlo_f16 v111, v78, s22, 0                          // 000000178888: CC21006F 02002D4E
	v_fma_mixhi_f16 v111, v79, s22, 0                          // 000000178890: CC22006F 02002D4F
	ds_load_b128 v[76:79], v94 offset:17184                    // 000000178898: DBFC4320 4C00005E
	s_waitcnt lgkmcnt(2)                                       // 0000001788A0: BF89FC27
	v_fma_mixlo_f16 v112, v3, s22, 0                           // 0000001788A4: CC210070 02002D03
	v_fma_mixhi_f16 v112, v4, s22, 0                           // 0000001788AC: CC220070 02002D04
	v_fma_mixlo_f16 v113, v5, s22, 0                           // 0000001788B4: CC210071 02002D05
	v_fma_mixhi_f16 v113, v6, s22, 0                           // 0000001788BC: CC220071 02002D06
	ds_load_b128 v[3:6], v94 offset:17200                      // 0000001788C4: DBFC4330 0300005E
	v_fma_mixlo_f16 v115, v118, s22, 0                         // 0000001788CC: CC210073 02002D76
	v_fma_mixhi_f16 v115, v119, s22, 0                         // 0000001788D4: CC220073 02002D77
	ds_load_b128 v[124:127], v94 offset:25600                  // 0000001788DC: DBFC6400 7C00005E
	ds_load_b128 v[128:131], v94 offset:25616                  // 0000001788E4: DBFC6410 8000005E
	s_waitcnt lgkmcnt(4)                                       // 0000001788EC: BF89FC47
	v_fma_mixlo_f16 v118, v62, s22, 0                          // 0000001788F0: CC210076 02002D3E
	v_fma_mixhi_f16 v118, v63, s22, 0                          // 0000001788F8: CC220076 02002D3F
	ds_load_b128 v[132:135], v94 offset:25632                  // 000000178900: DBFC6420 8400005E
	v_fma_mixlo_f16 v119, v64, s22, 0                          // 000000178908: CC210077 02002D40
	v_fma_mixhi_f16 v119, v65, s22, 0                          // 000000178910: CC220077 02002D41
	ds_load_b128 v[62:65], v94 offset:25648                    // 000000178918: DBFC6430 3E00005E
	v_fma_mixlo_f16 v61, v114, s22, 0                          // 000000178920: CC21003D 02002D72
	v_fma_mixlo_f16 v114, v116, s22, 0                         // 000000178928: CC210072 02002D74
	v_fma_mixhi_f16 v114, v117, s22, 0                         // 000000178930: CC220072 02002D75
	v_fma_mixlo_f16 v116, v120, s22, 0                         // 000000178938: CC210074 02002D78
	v_fma_mixhi_f16 v116, v121, s22, 0                         // 000000178940: CC220074 02002D79
	v_fma_mixlo_f16 v117, v122, s22, 0                         // 000000178948: CC210075 02002D7A
	v_fma_mixhi_f16 v117, v123, s22, 0                         // 000000178950: CC220075 02002D7B
	s_waitcnt lgkmcnt(5)                                       // 000000178958: BF89FC57
	v_fma_mixlo_f16 v120, v76, s22, 0                          // 00000017895C: CC210078 02002D4C
	v_fma_mixhi_f16 v120, v77, s22, 0                          // 000000178964: CC220078 02002D4D
	v_fma_mixlo_f16 v121, v78, s22, 0                          // 00000017896C: CC210079 02002D4E
	v_fma_mixhi_f16 v121, v79, s22, 0                          // 000000178974: CC220079 02002D4F
	s_waitcnt lgkmcnt(4)                                       // 00000017897C: BF89FC47
	v_fma_mixlo_f16 v122, v3, s22, 0                           // 000000178980: CC21007A 02002D03
	v_fma_mixhi_f16 v122, v4, s22, 0                           // 000000178988: CC22007A 02002D04
	v_fma_mixlo_f16 v123, v5, s22, 0                           // 000000178990: CC21007B 02002D05
	v_fma_mixhi_f16 v123, v6, s22, 0                           // 000000178998: CC22007B 02002D06
	s_waitcnt lgkmcnt(3)                                       // 0000001789A0: BF89FC37
	v_fma_mixlo_f16 v124, v124, s22, 0                         // 0000001789A4: CC21007C 02002D7C
	v_fma_mixhi_f16 v124, v125, s22, 0                         // 0000001789AC: CC22007C 02002D7D
	v_fma_mixlo_f16 v125, v126, s22, 0                         // 0000001789B4: CC21007D 02002D7E
	v_fma_mixhi_f16 v125, v127, s22, 0                         // 0000001789BC: CC22007D 02002D7F
	s_waitcnt lgkmcnt(2)                                       // 0000001789C4: BF89FC27
	v_fma_mixlo_f16 v126, v128, s22, 0                         // 0000001789C8: CC21007E 02002D80
	v_fma_mixhi_f16 v126, v129, s22, 0                         // 0000001789D0: CC22007E 02002D81
	v_fma_mixlo_f16 v127, v130, s22, 0                         // 0000001789D8: CC21007F 02002D82
	v_fma_mixhi_f16 v127, v131, s22, 0                         // 0000001789E0: CC22007F 02002D83
	s_waitcnt lgkmcnt(1)                                       // 0000001789E8: BF89FC17
	v_fma_mixlo_f16 v128, v132, s22, 0                         // 0000001789EC: CC210080 02002D84
	v_fma_mixhi_f16 v128, v133, s22, 0                         // 0000001789F4: CC220080 02002D85
	v_fma_mixlo_f16 v129, v134, s22, 0                         // 0000001789FC: CC210081 02002D86
	v_fma_mixhi_f16 v129, v135, s22, 0                         // 000000178A04: CC220081 02002D87
	s_waitcnt lgkmcnt(0)                                       // 000000178A0C: BF89FC07
	v_fma_mixlo_f16 v130, v62, s22, 0                          // 000000178A10: CC210082 02002D3E
	v_fma_mixhi_f16 v130, v63, s22, 0                          // 000000178A18: CC220082 02002D3F
	v_fma_mixlo_f16 v131, v64, s22, 0                          // 000000178A20: CC210083 02002D40
	v_fma_mixhi_f16 v131, v65, s22, 0                          // 000000178A28: CC220083 02002D41
	v_wmma_f32_16x16x16_f16 v[42:49], v[68:75], v[54:61], v[42:49]// 000000178A30: CC40402A 1CAA6D44
	v_wmma_f32_16x16x16_f16 v[34:41], v[68:75], v[108:115], v[34:41]// 000000178A38: CC404022 1C8AD944
	v_wmma_f32_16x16x16_f16 v[26:33], v[68:75], v[116:123], v[26:33]// 000000178A40: CC40401A 1C6AE944
	s_delay_alu instid0(VALU_DEP_4)                            // 000000178A48: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[68:75], v[124:131], v[18:25]// 000000178A4C: CC404012 1C4AF944
	s_and_saveexec_b32 s1, s0                                  // 000000178A54: BE812000
	s_cbranch_execnz 4242                                      // 000000178A58: BFA61092 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5aa4>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178A5C: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:336        // 000000178A60: DC5E0150 367C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178A68: BE812000
	s_cbranch_execnz 4248                                      // 000000178A6C: BFA61098 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ad0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178A70: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:352        // 000000178A74: DC5E0160 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178A7C: BE812000
	s_cbranch_execnz 4254                                      // 000000178A80: BFA6109E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5afc>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178A84: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:368        // 000000178A88: DC5E0170 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178A90: BE812000
	s_cbranch_execz 6                                          // 000000178A94: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18b0>
	s_waitcnt vmcnt(0)                                         // 000000178A98: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 000000178A9C: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000178AA0: BF870001
	v_mov_b32_e32 v62, v63                                     // 000000178AA4: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 000000178AA8: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 000000178AAC: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178AB0: 8C7E017E
	global_load_b128 v[3:6], v[66:67], off offset:384          // 000000178AB4: DC5E0180 037C0042
	ds_load_b128 v[68:71], v94 offset:320                      // 000000178ABC: DBFC0140 4400005E
	ds_load_b128 v[72:75], v94 offset:336                      // 000000178AC4: DBFC0150 4800005E
	ds_load_b128 v[76:79], v94 offset:352                      // 000000178ACC: DBFC0160 4C00005E
	ds_load_b128 v[108:111], v94 offset:368                    // 000000178AD4: DBFC0170 6C00005E
	s_waitcnt vmcnt(4)                                         // 000000178ADC: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 000000178AE0: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 000000178AE8: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 000000178AF0: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 000000178AF8: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 000000178B00: BF890FF7
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 000000178B04: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 000000178B0C: CC210035 02002D38
	s_waitcnt vmcnt(2)                                         // 000000178B14: BF890BF7
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000178B18: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000178B20: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 000000178B28: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 000000178B2C: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 000000178B34: CC220038 02002D3F
	ds_load_b128 v[112:115], v94 offset:8768                   // 000000178B3C: DBFC2240 7000005E
	ds_load_b128 v[116:119], v94 offset:8784                   // 000000178B44: DBFC2250 7400005E
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 000000178B4C: CC210034 02002D36
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 000000178B54: CC220035 02002D39
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000178B5C: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000178B64: CC220036 02002D3B
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 000000178B6C: CC210039 02002D40
	s_waitcnt lgkmcnt(4)                                       // 000000178B74: BF89FC47
	v_fma_mixlo_f16 v60, v72, s22, 0                           // 000000178B78: CC21003C 02002D48
	v_fma_mixhi_f16 v60, v73, s22, 0                           // 000000178B80: CC22003C 02002D49
	v_fma_mixlo_f16 v61, v74, s22, 0                           // 000000178B88: CC21003D 02002D4A
	v_fma_mixhi_f16 v61, v75, s22, 0                           // 000000178B90: CC22003D 02002D4B
	ds_load_b128 v[72:75], v94 offset:8800                     // 000000178B98: DBFC2260 4800005E
	s_waitcnt lgkmcnt(4)                                       // 000000178BA0: BF89FC47
	v_fma_mixlo_f16 v62, v76, s22, 0                           // 000000178BA4: CC21003E 02002D4C
	v_fma_mixhi_f16 v62, v77, s22, 0                           // 000000178BAC: CC22003E 02002D4D
	v_fma_mixlo_f16 v63, v78, s22, 0                           // 000000178BB4: CC21003F 02002D4E
	v_fma_mixhi_f16 v63, v79, s22, 0                           // 000000178BBC: CC22003F 02002D4F
	ds_load_b128 v[76:79], v94 offset:8816                     // 000000178BC4: DBFC2270 4C00005E
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 000000178BCC: CC220039 02002D41
	v_fma_mixlo_f16 v58, v68, s22, 0                           // 000000178BD4: CC21003A 02002D44
	v_fma_mixhi_f16 v58, v69, s22, 0                           // 000000178BDC: CC22003A 02002D45
	v_fma_mixlo_f16 v59, v70, s22, 0                           // 000000178BE4: CC21003B 02002D46
	v_fma_mixhi_f16 v59, v71, s22, 0                           // 000000178BEC: CC22003B 02002D47
	s_waitcnt lgkmcnt(4)                                       // 000000178BF4: BF89FC47
	v_fma_mixlo_f16 v64, v108, s22, 0                          // 000000178BF8: CC210040 02002D6C
	v_fma_mixhi_f16 v64, v109, s22, 0                          // 000000178C00: CC220040 02002D6D
	v_fma_mixlo_f16 v65, v110, s22, 0                          // 000000178C08: CC210041 02002D6E
	v_fma_mixhi_f16 v65, v111, s22, 0                          // 000000178C10: CC220041 02002D6F
	s_waitcnt lgkmcnt(3)                                       // 000000178C18: BF89FC37
	v_fma_mixlo_f16 v68, v112, s22, 0                          // 000000178C1C: CC210044 02002D70
	ds_load_b128 v[108:111], v94 offset:17216                  // 000000178C24: DBFC4340 6C00005E
	v_fma_mixhi_f16 v68, v113, s22, 0                          // 000000178C2C: CC220044 02002D71
	v_fma_mixlo_f16 v69, v114, s22, 0                          // 000000178C34: CC210045 02002D72
	v_fma_mixhi_f16 v69, v115, s22, 0                          // 000000178C3C: CC220045 02002D73
	s_waitcnt lgkmcnt(3)                                       // 000000178C44: BF89FC37
	v_fma_mixlo_f16 v70, v116, s22, 0                          // 000000178C48: CC210046 02002D74
	ds_load_b128 v[112:115], v94 offset:17232                  // 000000178C50: DBFC4350 7000005E
	v_fma_mixhi_f16 v70, v117, s22, 0                          // 000000178C58: CC220046 02002D75
	v_fma_mixlo_f16 v71, v118, s22, 0                          // 000000178C60: CC210047 02002D76
	v_fma_mixhi_f16 v71, v119, s22, 0                          // 000000178C68: CC220047 02002D77
	s_waitcnt lgkmcnt(3)                                       // 000000178C70: BF89FC37
	v_fma_mixlo_f16 v72, v72, s22, 0                           // 000000178C74: CC210048 02002D48
	ds_load_b128 v[116:119], v94 offset:17248                  // 000000178C7C: DBFC4360 7400005E
	ds_load_b128 v[120:123], v94 offset:17264                  // 000000178C84: DBFC4370 7800005E
	v_fma_mixhi_f16 v72, v73, s22, 0                           // 000000178C8C: CC220048 02002D49
	v_fma_mixlo_f16 v73, v74, s22, 0                           // 000000178C94: CC210049 02002D4A
	v_fma_mixhi_f16 v73, v75, s22, 0                           // 000000178C9C: CC220049 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000178CA4: BF89FC47
	v_fma_mixlo_f16 v74, v76, s22, 0                           // 000000178CA8: CC21004A 02002D4C
	v_fma_mixhi_f16 v74, v77, s22, 0                           // 000000178CB0: CC22004A 02002D4D
	v_fma_mixlo_f16 v75, v78, s22, 0                           // 000000178CB8: CC21004B 02002D4E
	v_fma_mixhi_f16 v75, v79, s22, 0                           // 000000178CC0: CC22004B 02002D4F
	ds_load_b128 v[76:79], v94 offset:25664                    // 000000178CC8: DBFC6440 4C00005E
	ds_load_b128 v[124:127], v94 offset:25680                  // 000000178CD0: DBFC6450 7C00005E
	ds_load_b128 v[128:131], v94 offset:25696                  // 000000178CD8: DBFC6460 8000005E
	ds_load_b128 v[132:135], v94 offset:25712                  // 000000178CE0: DBFC6470 8400005E
	s_waitcnt lgkmcnt(7)                                       // 000000178CE8: BF89FC77
	v_fma_mixlo_f16 v108, v108, s22, 0                         // 000000178CEC: CC21006C 02002D6C
	v_fma_mixhi_f16 v108, v109, s22, 0                         // 000000178CF4: CC22006C 02002D6D
	v_fma_mixlo_f16 v109, v110, s22, 0                         // 000000178CFC: CC21006D 02002D6E
	v_fma_mixhi_f16 v109, v111, s22, 0                         // 000000178D04: CC22006D 02002D6F
	s_waitcnt lgkmcnt(6)                                       // 000000178D0C: BF89FC67
	v_fma_mixlo_f16 v110, v112, s22, 0                         // 000000178D10: CC21006E 02002D70
	v_fma_mixhi_f16 v110, v113, s22, 0                         // 000000178D18: CC22006E 02002D71
	v_fma_mixlo_f16 v111, v114, s22, 0                         // 000000178D20: CC21006F 02002D72
	v_fma_mixhi_f16 v111, v115, s22, 0                         // 000000178D28: CC22006F 02002D73
	s_waitcnt lgkmcnt(5)                                       // 000000178D30: BF89FC57
	v_fma_mixlo_f16 v112, v116, s22, 0                         // 000000178D34: CC210070 02002D74
	v_fma_mixhi_f16 v112, v117, s22, 0                         // 000000178D3C: CC220070 02002D75
	v_fma_mixlo_f16 v113, v118, s22, 0                         // 000000178D44: CC210071 02002D76
	v_fma_mixhi_f16 v113, v119, s22, 0                         // 000000178D4C: CC220071 02002D77
	s_waitcnt lgkmcnt(4)                                       // 000000178D54: BF89FC47
	v_fma_mixlo_f16 v114, v120, s22, 0                         // 000000178D58: CC210072 02002D78
	v_fma_mixhi_f16 v114, v121, s22, 0                         // 000000178D60: CC220072 02002D79
	v_fma_mixlo_f16 v115, v122, s22, 0                         // 000000178D68: CC210073 02002D7A
	v_fma_mixhi_f16 v115, v123, s22, 0                         // 000000178D70: CC220073 02002D7B
	s_waitcnt lgkmcnt(3)                                       // 000000178D78: BF89FC37
	v_fma_mixlo_f16 v116, v76, s22, 0                          // 000000178D7C: CC210074 02002D4C
	v_fma_mixhi_f16 v116, v77, s22, 0                          // 000000178D84: CC220074 02002D4D
	v_fma_mixlo_f16 v117, v78, s22, 0                          // 000000178D8C: CC210075 02002D4E
	v_fma_mixhi_f16 v117, v79, s22, 0                          // 000000178D94: CC220075 02002D4F
	s_waitcnt lgkmcnt(2)                                       // 000000178D9C: BF89FC27
	v_fma_mixlo_f16 v118, v124, s22, 0                         // 000000178DA0: CC210076 02002D7C
	v_fma_mixhi_f16 v118, v125, s22, 0                         // 000000178DA8: CC220076 02002D7D
	v_fma_mixlo_f16 v119, v126, s22, 0                         // 000000178DB0: CC210077 02002D7E
	v_fma_mixhi_f16 v119, v127, s22, 0                         // 000000178DB8: CC220077 02002D7F
	s_waitcnt lgkmcnt(1)                                       // 000000178DC0: BF89FC17
	v_fma_mixlo_f16 v120, v128, s22, 0                         // 000000178DC4: CC210078 02002D80
	v_fma_mixhi_f16 v120, v129, s22, 0                         // 000000178DCC: CC220078 02002D81
	v_fma_mixlo_f16 v121, v130, s22, 0                         // 000000178DD4: CC210079 02002D82
	v_fma_mixhi_f16 v121, v131, s22, 0                         // 000000178DDC: CC220079 02002D83
	s_waitcnt lgkmcnt(0)                                       // 000000178DE4: BF89FC07
	v_fma_mixlo_f16 v122, v132, s22, 0                         // 000000178DE8: CC21007A 02002D84
	v_fma_mixhi_f16 v122, v133, s22, 0                         // 000000178DF0: CC22007A 02002D85
	v_fma_mixlo_f16 v123, v134, s22, 0                         // 000000178DF8: CC21007B 02002D86
	v_fma_mixhi_f16 v123, v135, s22, 0                         // 000000178E00: CC22007B 02002D87
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 000000178E08: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[68:75], v[34:41]// 000000178E10: CC404022 1C8A8932
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[108:115], v[26:33]// 000000178E18: CC40401A 1C6AD932
	s_delay_alu instid0(VALU_DEP_4)                            // 000000178E20: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[116:123], v[18:25]// 000000178E24: CC404012 1C4AE932
	s_and_saveexec_b32 s1, s0                                  // 000000178E2C: BE812000
	s_cbranch_execnz 4030                                      // 000000178E30: BFA60FBE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b2c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178E34: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:400        // 000000178E38: DC5E0190 327C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178E40: BE812000
	s_cbranch_execnz 4036                                      // 000000178E44: BFA60FC4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b58>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178E48: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:416        // 000000178E4C: DC5E01A0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178E54: BE812000
	s_cbranch_execnz 4042                                      // 000000178E58: BFA60FCA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b84>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178E5C: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:432        // 000000178E60: DC5E01B0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 000000178E68: BE812000
	s_cbranch_execz 6                                          // 000000178E6C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c88>
	s_waitcnt vmcnt(0)                                         // 000000178E70: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 000000178E74: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000178E78: BF870001
	v_mov_b32_e32 v58, v59                                     // 000000178E7C: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 000000178E80: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 000000178E84: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000178E88: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:448        // 000000178E8C: DC5E01C0 3E7C0042
	s_waitcnt vmcnt(4)                                         // 000000178E94: BF8913F7
	v_fma_mixlo_f16 v68, v3, s22, 0                            // 000000178E98: CC210044 02002D03
	ds_load_b128 v[76:79], v94 offset:384                      // 000000178EA0: DBFC0180 4C00005E
	v_fma_mixhi_f16 v68, v4, s22, 0                            // 000000178EA8: CC220044 02002D04
	v_fma_mixlo_f16 v69, v5, s22, 0                            // 000000178EB0: CC210045 02002D05
	v_fma_mixhi_f16 v69, v6, s22, 0                            // 000000178EB8: CC220045 02002D06
	ds_load_b128 v[3:6], v94 offset:400                        // 000000178EC0: DBFC0190 0300005E
	ds_load_b128 v[108:111], v94 offset:416                    // 000000178EC8: DBFC01A0 6C00005E
	ds_load_b128 v[112:115], v94 offset:432                    // 000000178ED0: DBFC01B0 7000005E
	s_waitcnt vmcnt(1)                                         // 000000178ED8: BF8907F7
	v_fma_mixlo_f16 v74, v58, s22, 0                           // 000000178EDC: CC21004A 02002D3A
	v_fma_mixhi_f16 v74, v59, s22, 0                           // 000000178EE4: CC22004A 02002D3B
	v_fma_mixlo_f16 v75, v60, s22, 0                           // 000000178EEC: CC21004B 02002D3C
	v_fma_mixhi_f16 v75, v61, s22, 0                           // 000000178EF4: CC22004B 02002D3D
	ds_load_b128 v[58:61], v94 offset:8832                     // 000000178EFC: DBFC2280 3A00005E
	v_fma_mixlo_f16 v70, v50, s22, 0                           // 000000178F04: CC210046 02002D32
	v_fma_mixhi_f16 v70, v51, s22, 0                           // 000000178F0C: CC220046 02002D33
	v_fma_mixlo_f16 v71, v52, s22, 0                           // 000000178F14: CC210047 02002D34
	v_fma_mixhi_f16 v71, v53, s22, 0                           // 000000178F1C: CC220047 02002D35
	v_fma_mixlo_f16 v72, v54, s22, 0                           // 000000178F24: CC210048 02002D36
	ds_load_b128 v[120:123], v94 offset:17280                  // 000000178F2C: DBFC4380 7800005E
	ds_load_b128 v[116:119], v94 offset:8880                   // 000000178F34: DBFC22B0 7400005E
	v_fma_mixhi_f16 v72, v55, s22, 0                           // 000000178F3C: CC220048 02002D37
	s_waitcnt lgkmcnt(6)                                       // 000000178F44: BF89FC67
	v_fma_mixlo_f16 v50, v76, s22, 0                           // 000000178F48: CC210032 02002D4C
	v_fma_mixhi_f16 v50, v77, s22, 0                           // 000000178F50: CC220032 02002D4D
	v_fma_mixlo_f16 v51, v78, s22, 0                           // 000000178F58: CC210033 02002D4E
	v_fma_mixhi_f16 v51, v79, s22, 0                           // 000000178F60: CC220033 02002D4F
	ds_load_b128 v[76:79], v94 offset:8848                     // 000000178F68: DBFC2290 4C00005E
	s_waitcnt lgkmcnt(6)                                       // 000000178F70: BF89FC67
	v_fma_mixlo_f16 v52, v3, s22, 0                            // 000000178F74: CC210034 02002D03
	v_fma_mixhi_f16 v52, v4, s22, 0                            // 000000178F7C: CC220034 02002D04
	v_fma_mixlo_f16 v53, v5, s22, 0                            // 000000178F84: CC210035 02002D05
	v_fma_mixhi_f16 v53, v6, s22, 0                            // 000000178F8C: CC220035 02002D06
	ds_load_b128 v[3:6], v94 offset:8864                       // 000000178F94: DBFC22A0 0300005E
	s_waitcnt lgkmcnt(6)                                       // 000000178F9C: BF89FC67
	v_fma_mixlo_f16 v54, v108, s22, 0                          // 000000178FA0: CC210036 02002D6C
	v_fma_mixhi_f16 v54, v109, s22, 0                          // 000000178FA8: CC220036 02002D6D
	s_waitcnt lgkmcnt(4)                                       // 000000178FB0: BF89FC47
	v_fma_mixlo_f16 v108, v58, s22, 0                          // 000000178FB4: CC21006C 02002D3A
	v_fma_mixhi_f16 v108, v59, s22, 0                          // 000000178FBC: CC22006C 02002D3B
	v_fma_mixlo_f16 v109, v60, s22, 0                          // 000000178FC4: CC21006D 02002D3C
	v_fma_mixhi_f16 v109, v61, s22, 0                          // 000000178FCC: CC22006D 02002D3D
	ds_load_b128 v[58:61], v94 offset:17296                    // 000000178FD4: DBFC4390 3A00005E
	v_fma_mixlo_f16 v73, v56, s22, 0                           // 000000178FDC: CC210049 02002D38
	v_fma_mixhi_f16 v73, v57, s22, 0                           // 000000178FE4: CC220049 02002D39
	v_fma_mixlo_f16 v55, v110, s22, 0                          // 000000178FEC: CC210037 02002D6E
	v_fma_mixhi_f16 v55, v111, s22, 0                          // 000000178FF4: CC220037 02002D6F
	v_fma_mixlo_f16 v56, v112, s22, 0                          // 000000178FFC: CC210038 02002D70
	v_fma_mixhi_f16 v56, v113, s22, 0                          // 000000179004: CC220038 02002D71
	v_fma_mixhi_f16 v57, v115, s22, 0                          // 00000017900C: CC220039 02002D73
	s_waitcnt lgkmcnt(2)                                       // 000000179014: BF89FC27
	v_fma_mixlo_f16 v110, v76, s22, 0                          // 000000179018: CC21006E 02002D4C
	v_fma_mixhi_f16 v110, v77, s22, 0                          // 000000179020: CC22006E 02002D4D
	v_fma_mixlo_f16 v111, v78, s22, 0                          // 000000179028: CC21006F 02002D4E
	v_fma_mixhi_f16 v111, v79, s22, 0                          // 000000179030: CC22006F 02002D4F
	ds_load_b128 v[76:79], v94 offset:17312                    // 000000179038: DBFC43A0 4C00005E
	s_waitcnt lgkmcnt(2)                                       // 000000179040: BF89FC27
	v_fma_mixlo_f16 v112, v3, s22, 0                           // 000000179044: CC210070 02002D03
	v_fma_mixhi_f16 v112, v4, s22, 0                           // 00000017904C: CC220070 02002D04
	v_fma_mixlo_f16 v113, v5, s22, 0                           // 000000179054: CC210071 02002D05
	v_fma_mixhi_f16 v113, v6, s22, 0                           // 00000017905C: CC220071 02002D06
	ds_load_b128 v[3:6], v94 offset:17328                      // 000000179064: DBFC43B0 0300005E
	v_fma_mixlo_f16 v115, v118, s22, 0                         // 00000017906C: CC210073 02002D76
	v_fma_mixhi_f16 v115, v119, s22, 0                         // 000000179074: CC220073 02002D77
	ds_load_b128 v[124:127], v94 offset:25728                  // 00000017907C: DBFC6480 7C00005E
	ds_load_b128 v[128:131], v94 offset:25744                  // 000000179084: DBFC6490 8000005E
	s_waitcnt lgkmcnt(4)                                       // 00000017908C: BF89FC47
	v_fma_mixlo_f16 v118, v58, s22, 0                          // 000000179090: CC210076 02002D3A
	v_fma_mixhi_f16 v118, v59, s22, 0                          // 000000179098: CC220076 02002D3B
	ds_load_b128 v[132:135], v94 offset:25760                  // 0000001790A0: DBFC64A0 8400005E
	v_fma_mixlo_f16 v119, v60, s22, 0                          // 0000001790A8: CC210077 02002D3C
	v_fma_mixhi_f16 v119, v61, s22, 0                          // 0000001790B0: CC220077 02002D3D
	ds_load_b128 v[58:61], v94 offset:25776                    // 0000001790B8: DBFC64B0 3A00005E
	v_fma_mixlo_f16 v57, v114, s22, 0                          // 0000001790C0: CC210039 02002D72
	v_fma_mixlo_f16 v114, v116, s22, 0                         // 0000001790C8: CC210072 02002D74
	v_fma_mixhi_f16 v114, v117, s22, 0                         // 0000001790D0: CC220072 02002D75
	v_fma_mixlo_f16 v116, v120, s22, 0                         // 0000001790D8: CC210074 02002D78
	v_fma_mixhi_f16 v116, v121, s22, 0                         // 0000001790E0: CC220074 02002D79
	v_fma_mixlo_f16 v117, v122, s22, 0                         // 0000001790E8: CC210075 02002D7A
	v_fma_mixhi_f16 v117, v123, s22, 0                         // 0000001790F0: CC220075 02002D7B
	s_waitcnt lgkmcnt(5)                                       // 0000001790F8: BF89FC57
	v_fma_mixlo_f16 v120, v76, s22, 0                          // 0000001790FC: CC210078 02002D4C
	v_fma_mixhi_f16 v120, v77, s22, 0                          // 000000179104: CC220078 02002D4D
	v_fma_mixlo_f16 v121, v78, s22, 0                          // 00000017910C: CC210079 02002D4E
	v_fma_mixhi_f16 v121, v79, s22, 0                          // 000000179114: CC220079 02002D4F
	s_waitcnt lgkmcnt(4)                                       // 00000017911C: BF89FC47
	v_fma_mixlo_f16 v122, v3, s22, 0                           // 000000179120: CC21007A 02002D03
	v_fma_mixhi_f16 v122, v4, s22, 0                           // 000000179128: CC22007A 02002D04
	v_fma_mixlo_f16 v123, v5, s22, 0                           // 000000179130: CC21007B 02002D05
	v_fma_mixhi_f16 v123, v6, s22, 0                           // 000000179138: CC22007B 02002D06
	s_waitcnt lgkmcnt(3)                                       // 000000179140: BF89FC37
	v_fma_mixlo_f16 v124, v124, s22, 0                         // 000000179144: CC21007C 02002D7C
	v_fma_mixhi_f16 v124, v125, s22, 0                         // 00000017914C: CC22007C 02002D7D
	v_fma_mixlo_f16 v125, v126, s22, 0                         // 000000179154: CC21007D 02002D7E
	v_fma_mixhi_f16 v125, v127, s22, 0                         // 00000017915C: CC22007D 02002D7F
	s_waitcnt lgkmcnt(2)                                       // 000000179164: BF89FC27
	v_fma_mixlo_f16 v126, v128, s22, 0                         // 000000179168: CC21007E 02002D80
	v_fma_mixhi_f16 v126, v129, s22, 0                         // 000000179170: CC22007E 02002D81
	v_fma_mixlo_f16 v127, v130, s22, 0                         // 000000179178: CC21007F 02002D82
	v_fma_mixhi_f16 v127, v131, s22, 0                         // 000000179180: CC22007F 02002D83
	s_waitcnt lgkmcnt(1)                                       // 000000179188: BF89FC17
	v_fma_mixlo_f16 v128, v132, s22, 0                         // 00000017918C: CC210080 02002D84
	v_fma_mixhi_f16 v128, v133, s22, 0                         // 000000179194: CC220080 02002D85
	v_fma_mixlo_f16 v129, v134, s22, 0                         // 00000017919C: CC210081 02002D86
	v_fma_mixhi_f16 v129, v135, s22, 0                         // 0000001791A4: CC220081 02002D87
	s_waitcnt lgkmcnt(0)                                       // 0000001791AC: BF89FC07
	v_fma_mixlo_f16 v130, v58, s22, 0                          // 0000001791B0: CC210082 02002D3A
	v_fma_mixhi_f16 v130, v59, s22, 0                          // 0000001791B8: CC220082 02002D3B
	v_fma_mixlo_f16 v131, v60, s22, 0                          // 0000001791C0: CC210083 02002D3C
	v_fma_mixhi_f16 v131, v61, s22, 0                          // 0000001791C8: CC220083 02002D3D
	v_wmma_f32_16x16x16_f16 v[42:49], v[68:75], v[50:57], v[42:49]// 0000001791D0: CC40402A 1CAA6544
	v_wmma_f32_16x16x16_f16 v[34:41], v[68:75], v[108:115], v[34:41]// 0000001791D8: CC404022 1C8AD944
	v_wmma_f32_16x16x16_f16 v[26:33], v[68:75], v[116:123], v[26:33]// 0000001791E0: CC40401A 1C6AE944
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001791E8: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[68:75], v[124:131], v[18:25]// 0000001791EC: CC404012 1C4AF944
	s_and_saveexec_b32 s1, s0                                  // 0000001791F4: BE812000
	s_cbranch_execnz 3822                                      // 0000001791F8: BFA60EEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bb4>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001791FC: 8C7E017E
	global_load_b128 v[3:6], v[66:67], off offset:464          // 000000179200: DC5E01D0 037C0042
	s_and_saveexec_b32 s1, s0                                  // 000000179208: BE812000
	s_cbranch_execnz 3828                                      // 00000017920C: BFA60EF4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5be0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000179210: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:480        // 000000179214: DC5E01E0 327C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017921C: BE812000
	s_cbranch_execnz 3834                                      // 000000179220: BFA60EFA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000179224: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:496        // 000000179228: DC5E01F0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 000000179230: BE812000
	s_cbranch_execz 6                                          // 000000179234: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2050>
	s_waitcnt vmcnt(0)                                         // 000000179238: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017923C: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000179240: BF870001
	v_mov_b32_e32 v54, v55                                     // 000000179244: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 000000179248: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017924C: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 000000179250: 8C7E017E
	ds_load_b128 v[66:69], v94 offset:448                      // 000000179254: DBFC01C0 4200005E
	ds_load_b128 v[70:73], v94 offset:464                      // 00000017925C: DBFC01D0 4600005E
	s_waitcnt vmcnt(2)                                         // 000000179264: BF890BF7
	v_fma_mixlo_f16 v60, v3, s22, 0                            // 000000179268: CC21003C 02002D03
	v_fma_mixhi_f16 v60, v4, s22, 0                            // 000000179270: CC22003C 02002D04
	v_fma_mixlo_f16 v61, v5, s22, 0                            // 000000179278: CC21003D 02002D05
	v_fma_mixhi_f16 v61, v6, s22, 0                            // 000000179280: CC22003D 02002D06
	ds_load_b128 v[3:6], v94 offset:480                        // 000000179288: DBFC01E0 0300005E
	ds_load_b128 v[74:77], v94 offset:496                      // 000000179290: DBFC01F0 4A00005E
	v_fma_mixlo_f16 v58, v62, s22, 0                           // 000000179298: CC21003A 02002D3E
	v_fma_mixhi_f16 v58, v63, s22, 0                           // 0000001792A0: CC22003A 02002D3F
	v_fma_mixlo_f16 v59, v64, s22, 0                           // 0000001792A8: CC21003B 02002D40
	v_fma_mixhi_f16 v59, v65, s22, 0                           // 0000001792B0: CC22003B 02002D41
	s_waitcnt vmcnt(1)                                         // 0000001792B8: BF8907F7
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 0000001792BC: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 0000001792C4: CC22003E 02002D33
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 0000001792CC: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 0000001792D4: CC22003F 02002D35
	s_waitcnt vmcnt(0)                                         // 0000001792DC: BF8903F7
	v_fma_mixlo_f16 v64, v54, s22, 0                           // 0000001792E0: CC210040 02002D36
	v_fma_mixhi_f16 v64, v55, s22, 0                           // 0000001792E8: CC220040 02002D37
	v_fma_mixlo_f16 v65, v56, s22, 0                           // 0000001792F0: CC210041 02002D38
	v_fma_mixhi_f16 v65, v57, s22, 0                           // 0000001792F8: CC220041 02002D39
	s_waitcnt lgkmcnt(3)                                       // 000000179300: BF89FC37
	v_fma_mixlo_f16 v50, v66, s22, 0                           // 000000179304: CC210032 02002D42
	v_fma_mixhi_f16 v50, v67, s22, 0                           // 00000017930C: CC220032 02002D43
	v_fma_mixlo_f16 v51, v68, s22, 0                           // 000000179314: CC210033 02002D44
	v_fma_mixhi_f16 v51, v69, s22, 0                           // 00000017931C: CC220033 02002D45
	ds_load_b128 v[66:69], v94 offset:8896                     // 000000179324: DBFC22C0 4200005E
	s_waitcnt lgkmcnt(3)                                       // 00000017932C: BF89FC37
	v_fma_mixlo_f16 v52, v70, s22, 0                           // 000000179330: CC210034 02002D46
	v_fma_mixhi_f16 v52, v71, s22, 0                           // 000000179338: CC220034 02002D47
	v_fma_mixlo_f16 v53, v72, s22, 0                           // 000000179340: CC210035 02002D48
	v_fma_mixhi_f16 v53, v73, s22, 0                           // 000000179348: CC220035 02002D49
	ds_load_b128 v[70:73], v94 offset:8912                     // 000000179350: DBFC22D0 4600005E
	s_waitcnt lgkmcnt(3)                                       // 000000179358: BF89FC37
	v_fma_mixlo_f16 v54, v3, s22, 0                            // 00000017935C: CC210036 02002D03
	v_fma_mixhi_f16 v54, v4, s22, 0                            // 000000179364: CC220036 02002D04
	v_fma_mixlo_f16 v55, v5, s22, 0                            // 00000017936C: CC210037 02002D05
	v_fma_mixhi_f16 v55, v6, s22, 0                            // 000000179374: CC220037 02002D06
	ds_load_b128 v[3:6], v94 offset:8928                       // 00000017937C: DBFC22E0 0300005E
	s_waitcnt lgkmcnt(3)                                       // 000000179384: BF89FC37
	v_fma_mixlo_f16 v56, v74, s22, 0                           // 000000179388: CC210038 02002D4A
	v_fma_mixhi_f16 v56, v75, s22, 0                           // 000000179390: CC220038 02002D4B
	v_fma_mixlo_f16 v57, v76, s22, 0                           // 000000179398: CC210039 02002D4C
	v_fma_mixhi_f16 v57, v77, s22, 0                           // 0000001793A0: CC220039 02002D4D
	ds_load_b128 v[74:77], v94 offset:8944                     // 0000001793A8: DBFC22F0 4A00005E
	ds_load_b128 v[78:81], v94 offset:17344                    // 0000001793B0: DBFC43C0 4E00005E
	ds_load_b128 v[108:111], v94 offset:17360                  // 0000001793B8: DBFC43D0 6C00005E
	ds_load_b128 v[112:115], v94 offset:25808                  // 0000001793C0: DBFC64D0 7000005E
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[50:57], v[42:49]// 0000001793C8: CC40402A 1CAA653A
	s_waitcnt lgkmcnt(6)                                       // 0000001793D0: BF89FC67
	v_fma_mixlo_f16 v50, v66, s22, 0                           // 0000001793D4: CC210032 02002D42
	v_fma_mixhi_f16 v50, v67, s22, 0                           // 0000001793DC: CC220032 02002D43
	v_fma_mixlo_f16 v51, v68, s22, 0                           // 0000001793E4: CC210033 02002D44
	v_fma_mixhi_f16 v51, v69, s22, 0                           // 0000001793EC: CC220033 02002D45
	v_add_nc_u32_e32 v9, s47, v95                              // 0000001793F4: 4A12BE2F
	s_waitcnt lgkmcnt(5)                                       // 0000001793F8: BF89FC57
	v_fma_mixlo_f16 v52, v70, s22, 0                           // 0000001793FC: CC210034 02002D46
	v_fma_mixhi_f16 v52, v71, s22, 0                           // 000000179404: CC220034 02002D47
	v_fma_mixlo_f16 v53, v72, s22, 0                           // 00000017940C: CC210035 02002D48
	v_fma_mixhi_f16 v53, v73, s22, 0                           // 000000179414: CC220035 02002D49
	ds_load_b128 v[70:73], v94 offset:17376                    // 00000017941C: DBFC43E0 4600005E
	s_waitcnt lgkmcnt(5)                                       // 000000179424: BF89FC57
	v_fma_mixlo_f16 v54, v3, s22, 0                            // 000000179428: CC210036 02002D03
	v_fma_mixhi_f16 v54, v4, s22, 0                            // 000000179430: CC220036 02002D04
	v_fma_mixlo_f16 v55, v5, s22, 0                            // 000000179438: CC210037 02002D05
	v_fma_mixhi_f16 v55, v6, s22, 0                            // 000000179440: CC220037 02002D06
	ds_load_b128 v[3:6], v94 offset:17392                      // 000000179448: DBFC43F0 0300005E
	s_waitcnt lgkmcnt(5)                                       // 000000179450: BF89FC57
	v_fma_mixlo_f16 v56, v74, s22, 0                           // 000000179454: CC210038 02002D4A
	v_fma_mixhi_f16 v56, v75, s22, 0                           // 00000017945C: CC220038 02002D4B
	v_fma_mixlo_f16 v57, v76, s22, 0                           // 000000179464: CC210039 02002D4C
	v_fma_mixhi_f16 v57, v77, s22, 0                           // 00000017946C: CC220039 02002D4D
	ds_load_b128 v[74:77], v94 offset:25792                    // 000000179474: DBFC64C0 4A00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017947C: BF89FC57
	v_fma_mixlo_f16 v66, v78, s22, 0                           // 000000179480: CC210042 02002D4E
	v_fma_mixhi_f16 v66, v79, s22, 0                           // 000000179488: CC220042 02002D4F
	v_fma_mixlo_f16 v67, v80, s22, 0                           // 000000179490: CC210043 02002D50
	v_fma_mixhi_f16 v67, v81, s22, 0                           // 000000179498: CC220043 02002D51
	s_waitcnt lgkmcnt(4)                                       // 0000001794A0: BF89FC47
	v_fma_mixlo_f16 v68, v108, s22, 0                          // 0000001794A4: CC210044 02002D6C
	v_fma_mixhi_f16 v68, v109, s22, 0                          // 0000001794AC: CC220044 02002D6D
	ds_load_b128 v[78:81], v94 offset:25824                    // 0000001794B4: DBFC64E0 4E00005E
	v_fma_mixlo_f16 v69, v110, s22, 0                          // 0000001794BC: CC210045 02002D6E
	v_fma_mixhi_f16 v69, v111, s22, 0                          // 0000001794C4: CC220045 02002D6F
	ds_load_b128 v[108:111], v94 offset:25840                  // 0000001794CC: DBFC64F0 6C00005E
	s_waitcnt lgkmcnt(4)                                       // 0000001794D4: BF89FC47
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 0000001794D8: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 0000001794E0: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 0000001794E8: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 0000001794F0: CC220047 02002D49
	s_waitcnt lgkmcnt(3)                                       // 0000001794F8: BF89FC37
	v_fma_mixlo_f16 v72, v3, s22, 0                            // 0000001794FC: CC210048 02002D03
	v_fma_mixhi_f16 v72, v4, s22, 0                            // 000000179504: CC220048 02002D04
	v_fma_mixlo_f16 v73, v5, s22, 0                            // 00000017950C: CC210049 02002D05
	v_fma_mixhi_f16 v73, v6, s22, 0                            // 000000179514: CC220049 02002D06
	.long 0x7e063880                                           // 00000017951C: 7E063880
	s_waitcnt lgkmcnt(2)                                       // 000000179520: BF89FC27
	v_fma_mixlo_f16 v74, v74, s22, 0                           // 000000179524: CC21004A 02002D4A
	v_fma_mixhi_f16 v74, v75, s22, 0                           // 00000017952C: CC22004A 02002D4B
	v_fma_mixlo_f16 v75, v76, s22, 0                           // 000000179534: CC21004B 02002D4C
	v_fma_mixhi_f16 v75, v77, s22, 0                           // 00000017953C: CC22004B 02002D4D
	v_fma_mixlo_f16 v76, v112, s22, 0                          // 000000179544: CC21004C 02002D70
	v_fma_mixhi_f16 v76, v113, s22, 0                          // 00000017954C: CC22004C 02002D71
	v_fma_mixlo_f16 v77, v114, s22, 0                          // 000000179554: CC21004D 02002D72
	v_fma_mixhi_f16 v77, v115, s22, 0                          // 00000017955C: CC22004D 02002D73
	s_waitcnt lgkmcnt(1)                                       // 000000179564: BF89FC17
	v_fma_mixlo_f16 v78, v78, s22, 0                           // 000000179568: CC21004E 02002D4E
	v_fma_mixhi_f16 v78, v79, s22, 0                           // 000000179570: CC22004E 02002D4F
	v_fma_mixlo_f16 v79, v80, s22, 0                           // 000000179578: CC21004F 02002D50
	v_fma_mixhi_f16 v79, v81, s22, 0                           // 000000179580: CC22004F 02002D51
	s_waitcnt lgkmcnt(0)                                       // 000000179588: BF89FC07
	v_fma_mixlo_f16 v80, v108, s22, 0                          // 00000017958C: CC210050 02002D6C
	v_fma_mixhi_f16 v80, v109, s22, 0                          // 000000179594: CC220050 02002D6D
	v_fma_mixlo_f16 v81, v110, s22, 0                          // 00000017959C: CC210051 02002D6E
	v_fma_mixhi_f16 v81, v111, s22, 0                          // 0000001795A4: CC220051 02002D6F
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[50:57], v[34:41]// 0000001795AC: CC404022 1C8A653A
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[66:73], v[26:33]// 0000001795B4: CC40401A 1C6A853A
	.long 0xd4440001                                           // 0000001795BC: D4440001
	v_cndmask_b32_e32 v1, s35, v9, vcc_lo                      // 0000001795C0: 02021223
	.long 0x7f063903                                           // 0000001795C4: 7F063903
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[74:81], v[18:25]// 0000001795C8: CC404012 1C4A953A
	s_and_saveexec_b32 s5, s1                                  // 0000001795D0: BE852001
	s_cbranch_execz 17                                         // 0000001795D4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x241c>
	v_mad_u64_u32 v[4:5], null, v9, 48, s[2:3]                 // 0000001795D8: D6FE7C04 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001795E0: BF870091
	.long 0xd73c0004                                           // 0000001795E4: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001795E8: 02020889
	.long 0xd7000404                                           // 0000001795EC: D7000404
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 0000001795F0: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001795F4: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s4                 // 0000001795F8: D5207C05 00120B66
	global_load_b32 v4, v[4:5], off                            // 000000179600: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179608: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v42                         // 00000017960C: 560854FF BB800000
	v_fma_mixhi_f16 v3, v4, s22, 0                             // 000000179614: CC220003 02002D04
	s_or_b32 exec_lo, exec_lo, s5                              // 00000017961C: 8C7E057E
	v_add_nc_u32_e32 v108, 2, v9                               // 000000179620: 4AD81282
	ds_store_b16_d16_hi v103, v3                               // 000000179624: DA840000 00000367
	.long 0xd4440004                                           // 00000017962C: D4440004
	v_cndmask_b32_e32 v1, s35, v108, vcc_lo                    // 000000179630: 0202D823
	s_and_saveexec_b32 s6, s4                                  // 000000179634: BE862004
	s_cbranch_execz 17                                         // 000000179638: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 00000017963C: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179644: BF870091
	.long 0xd73c0003                                           // 000000179648: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000017964C: 02020689
	.long 0xd7000503                                           // 000000179650: D7000503
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179654: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179658: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s5                 // 00000017965C: D5207C04 00160966
	global_load_b32 v3, v[3:4], off                            // 000000179664: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017966C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v43                         // 000000179670: 560656FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000179678: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s6                              // 000000179680: 8C7E067E
	v_add_nc_u32_e32 v109, 4, v9                               // 000000179684: 4ADA1284
	.long 0x7f063880                                           // 000000179688: 7F063880
	ds_store_b16 v103, v3 offset:4                             // 00000017968C: D87C0004 00000367
	.long 0xd4440005                                           // 000000179694: D4440005
	v_cndmask_b32_e32 v1, s35, v109, vcc_lo                    // 000000179698: 0202DA23
	.long 0x7e083983                                           // 00000017969C: 7E083983
	s_and_saveexec_b32 s7, s5                                  // 0000001796A0: BE872005
	s_cbranch_execz 17                                         // 0000001796A4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24ec>
	v_mad_u64_u32 v[4:5], null, v109, 48, s[2:3]               // 0000001796A8: D6FE7C04 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001796B0: BF870091
	.long 0xd73c0004                                           // 0000001796B4: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001796B8: 02020889
	.long 0xd7000604                                           // 0000001796BC: D7000604
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 0000001796C0: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001796C4: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s6                 // 0000001796C8: D5207C05 001A0B66
	global_load_b32 v4, v[4:5], off                            // 0000001796D0: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001796D8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v44                         // 0000001796DC: 560858FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001796E4: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001796EC: 8C7E077E
	v_add_nc_u32_e32 v110, 6, v9                               // 0000001796F0: 4ADC1286
	ds_store_b16 v103, v4 offset:8                             // 0000001796F4: D87C0008 00000467
	.long 0xd4440006                                           // 0000001796FC: D4440006
	v_cndmask_b32_e32 v1, s35, v110, vcc_lo                    // 000000179700: 0202DC23
	s_and_saveexec_b32 s8, s6                                  // 000000179704: BE882006
	s_cbranch_execz 17                                         // 000000179708: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2550>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 00000017970C: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179714: BF870091
	.long 0xd73c0003                                           // 000000179718: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000017971C: 02020689
	.long 0xd7000703                                           // 000000179720: D7000703
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179724: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179728: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s7                 // 00000017972C: D5207C04 001E0966
	global_load_b32 v3, v[3:4], off                            // 000000179734: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017973C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v45                         // 000000179740: 56065AFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000179748: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s8                              // 000000179750: 8C7E087E
	v_add_nc_u32_e32 v111, 8, v9                               // 000000179754: 4ADE1288
	.long 0x7e083880                                           // 000000179758: 7E083880
	ds_store_b16_d16_hi v103, v3 offset:12                     // 00000017975C: DA84000C 00000367
	.long 0xd4440007                                           // 000000179764: D4440007
	v_cndmask_b32_e32 v1, s35, v111, vcc_lo                    // 000000179768: 0202DE23
	.long 0x7e063904                                           // 00000017976C: 7E063904
	s_and_saveexec_b32 s9, s7                                  // 000000179770: BE892007
	s_cbranch_execz 17                                         // 000000179774: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25bc>
	v_mad_u64_u32 v[5:6], null, v111, 48, s[2:3]               // 000000179778: D6FE7C05 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179780: BF870091
	.long 0xd73c0005                                           // 000000179784: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 000000179788: 02020A89
	.long 0xd7000805                                           // 00000017978C: D7000805
	v_cndmask_b32_e32 v1, v101, v5, vcc_lo                     // 000000179790: 02020B65
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179794: BF8700C1
	v_add_co_ci_u32_e64 v6, null, v102, v6, s8                 // 000000179798: D5207C06 00220D66
	global_load_b32 v3, v[5:6], off                            // 0000001797A0: DC520000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000001797A8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v46                         // 0000001797AC: 56065CFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001797B4: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001797BC: 8C7E097E
	v_add_nc_u32_e32 v112, 10, v9                              // 0000001797C0: 4AE0128A
	ds_store_b16 v103, v3 offset:16                            // 0000001797C4: D87C0010 00000367
	.long 0xd4440008                                           // 0000001797CC: D4440008
	v_cndmask_b32_e32 v1, s35, v112, vcc_lo                    // 0000001797D0: 0202E023
	s_and_saveexec_b32 s10, s8                                 // 0000001797D4: BE8A2008
	s_cbranch_execz 17                                         // 0000001797D8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2620>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 0000001797DC: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001797E4: BF870091
	.long 0xd73c0003                                           // 0000001797E8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001797EC: 02020689
	.long 0xd7000903                                           // 0000001797F0: D7000903
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001797F4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001797F8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s9                 // 0000001797FC: D5207C04 00260966
	global_load_b32 v3, v[3:4], off                            // 000000179804: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017980C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v47                         // 000000179810: 56065EFF BB800000
	v_fma_mixlo_f16 v4, v3, s22, 0                             // 000000179818: CC210004 02002D03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000179820: 8C7E0A7E
	v_add_nc_u32_e32 v113, 12, v9                              // 000000179824: 4AE2128C
	.long 0x7e063880                                           // 000000179828: 7E063880
	ds_store_b16 v103, v4 offset:20                            // 00000017982C: D87C0014 00000467
	.long 0xd4440009                                           // 000000179834: D4440009
	v_cndmask_b32_e32 v1, s35, v113, vcc_lo                    // 000000179838: 0202E223
	.long 0x7f063903                                           // 00000017983C: 7F063903
	s_and_saveexec_b32 s11, s9                                 // 000000179840: BE8B2009
	s_cbranch_execz 17                                         // 000000179844: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x268c>
	v_mad_u64_u32 v[4:5], null, v113, 48, s[2:3]               // 000000179848: D6FE7C04 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179850: BF870091
	.long 0xd73c0004                                           // 000000179854: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179858: 02020889
	.long 0xd7000a04                                           // 00000017985C: D7000A04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179860: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179864: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s10                // 000000179868: D5207C05 002A0B66
	global_load_b32 v4, v[4:5], off                            // 000000179870: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179878: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v48                         // 00000017987C: 560860FF BB800000
	v_fma_mixhi_f16 v3, v4, s22, 0                             // 000000179884: CC220003 02002D04
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017988C: 8C7E0B7E
	v_add_nc_u32_e32 v114, 14, v9                              // 000000179890: 4AE4128E
	ds_store_b16_d16_hi v103, v3 offset:24                     // 000000179894: DA840018 00000367
	.long 0xd444000a                                           // 00000017989C: D444000A
	v_cndmask_b32_e32 v1, s35, v114, vcc_lo                    // 0000001798A0: 0202E423
	s_and_saveexec_b32 s14, s10                                // 0000001798A4: BE8E200A
	s_cbranch_execz 17                                         // 0000001798A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26f0>
	v_mad_u64_u32 v[3:4], null, v114, 48, s[2:3]               // 0000001798AC: D6FE7C03 00096172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001798B4: BF870091
	.long 0xd73c0003                                           // 0000001798B8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001798BC: 02020689
	.long 0xd7000b03                                           // 0000001798C0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001798C4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001798C8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001798CC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off                            // 0000001798D4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001798DC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v49                         // 0000001798E0: 560662FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001798E8: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001798F0: 8C7E0E7E
	.long 0x7f063880                                           // 0000001798F4: 7F063880
	ds_store_b16 v103, v3 offset:28                            // 0000001798F8: D87C001C 00000367
	.long 0x7e083983                                           // 000000179900: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 000000179904: BE8E2001
	s_cbranch_execz 17                                         // 000000179908: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2750>
	v_mad_u64_u32 v[4:5], null, v9, 48, s[2:3]                 // 00000017990C: D6FE7C04 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179914: BF870091
	.long 0xd73c0004                                           // 000000179918: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000017991C: 02020889
	.long 0xd7000b04                                           // 000000179920: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179924: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179928: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 00000017992C: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:64                  // 000000179934: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 00000017993C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v34                         // 000000179940: 560844FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179948: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179950: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2560                          // 000000179954: D87C0A00 00000467
	s_and_saveexec_b32 s14, s4                                 // 00000017995C: BE8E2004
	s_cbranch_execz 17                                         // 000000179960: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27a8>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 000000179964: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017996C: BF870091
	.long 0xd73c0003                                           // 000000179970: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179974: 02020689
	.long 0xd7000b03                                           // 000000179978: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000017997C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179980: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179984: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 00000017998C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179994: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v35                         // 000000179998: 560646FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 0000001799A0: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001799A8: 8C7E0E7E
	.long 0x7e063880                                           // 0000001799AC: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:2564                   // 0000001799B0: DA840A04 00000367
	.long 0x7e083903                                           // 0000001799B8: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 0000001799BC: BE8E2005
	s_cbranch_execz 17                                         // 0000001799C0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2808>
	v_mad_u64_u32 v[4:5], null, v109, 48, s[2:3]               // 0000001799C4: D6FE7C04 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001799CC: BF870091
	.long 0xd73c0004                                           // 0000001799D0: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001799D4: 02020889
	.long 0xd7000b04                                           // 0000001799D8: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 0000001799DC: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001799E0: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 0000001799E4: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:64                  // 0000001799EC: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001799F4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v36                         // 0000001799F8: 560848FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179A00: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179A08: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2568                          // 000000179A0C: D87C0A08 00000467
	s_and_saveexec_b32 s14, s6                                 // 000000179A14: BE8E2006
	s_cbranch_execz 17                                         // 000000179A18: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2860>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000179A1C: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179A24: BF870091
	.long 0xd73c0003                                           // 000000179A28: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179A2C: 02020689
	.long 0xd7000b03                                           // 000000179A30: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179A34: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179A38: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179A3C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 000000179A44: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179A4C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v37                         // 000000179A50: 56064AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000179A58: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179A60: 8C7E0E7E
	.long 0x7f063880                                           // 000000179A64: 7F063880
	ds_store_b16 v103, v3 offset:2572                          // 000000179A68: D87C0A0C 00000367
	.long 0x7e083983                                           // 000000179A70: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 000000179A74: BE8E2007
	s_cbranch_execz 17                                         // 000000179A78: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	v_mad_u64_u32 v[4:5], null, v111, 48, s[2:3]               // 000000179A7C: D6FE7C04 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179A84: BF870091
	.long 0xd73c0004                                           // 000000179A88: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179A8C: 02020889
	.long 0xd7000b04                                           // 000000179A90: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179A94: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179A98: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179A9C: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:64                  // 000000179AA4: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179AAC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v38                         // 000000179AB0: 56084CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179AB8: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179AC0: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2576                          // 000000179AC4: D87C0A10 00000467
	s_and_saveexec_b32 s14, s8                                 // 000000179ACC: BE8E2008
	s_cbranch_execz 17                                         // 000000179AD0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2918>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 000000179AD4: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179ADC: BF870091
	.long 0xd73c0003                                           // 000000179AE0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179AE4: 02020689
	.long 0xd7000b03                                           // 000000179AE8: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179AEC: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179AF0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179AF4: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 000000179AFC: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179B04: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v39                         // 000000179B08: 56064EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000179B10: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179B18: 8C7E0E7E
	.long 0x7e063880                                           // 000000179B1C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:2580                   // 000000179B20: DA840A14 00000367
	.long 0x7e083903                                           // 000000179B28: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 000000179B2C: BE8E2009
	s_cbranch_execz 17                                         // 000000179B30: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2978>
	v_mad_u64_u32 v[4:5], null, v113, 48, s[2:3]               // 000000179B34: D6FE7C04 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179B3C: BF870091
	.long 0xd73c0004                                           // 000000179B40: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179B44: 02020889
	.long 0xd7000b04                                           // 000000179B48: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179B4C: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179B50: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179B54: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:64                  // 000000179B5C: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179B64: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v40                         // 000000179B68: 560850FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179B70: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179B78: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2584                          // 000000179B7C: D87C0A18 00000467
	s_and_saveexec_b32 s14, s10                                // 000000179B84: BE8E200A
	s_cbranch_execz 17                                         // 000000179B88: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29d0>
	v_mad_u64_u32 v[3:4], null, v114, 48, s[2:3]               // 000000179B8C: D6FE7C03 00096172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179B94: BF870091
	.long 0xd73c0003                                           // 000000179B98: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179B9C: 02020689
	.long 0xd7000b03                                           // 000000179BA0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179BA4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179BA8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179BAC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 000000179BB4: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179BBC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v41                         // 000000179BC0: 560652FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000179BC8: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179BD0: 8C7E0E7E
	.long 0x7f063880                                           // 000000179BD4: 7F063880
	ds_store_b16 v103, v3 offset:2588                          // 000000179BD8: D87C0A1C 00000367
	.long 0x7e083983                                           // 000000179BE0: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 000000179BE4: BE8E2001
	s_cbranch_execz 17                                         // 000000179BE8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a30>
	v_mad_u64_u32 v[4:5], null, v9, 48, s[2:3]                 // 000000179BEC: D6FE7C04 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179BF4: BF870091
	.long 0xd73c0004                                           // 000000179BF8: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179BFC: 02020889
	.long 0xd7000b04                                           // 000000179C00: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179C04: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179C08: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179C0C: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:128                 // 000000179C14: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179C1C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v26                         // 000000179C20: 560834FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179C28: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179C30: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5120                          // 000000179C34: D87C1400 00000467
	s_and_saveexec_b32 s14, s4                                 // 000000179C3C: BE8E2004
	s_cbranch_execz 17                                         // 000000179C40: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a88>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 000000179C44: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179C4C: BF870091
	.long 0xd73c0003                                           // 000000179C50: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179C54: 02020689
	.long 0xd7000b03                                           // 000000179C58: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179C5C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179C60: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179C64: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 000000179C6C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179C74: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v27                         // 000000179C78: 560636FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000179C80: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179C88: 8C7E0E7E
	.long 0x7e063880                                           // 000000179C8C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:5124                   // 000000179C90: DA841404 00000367
	.long 0x7e083903                                           // 000000179C98: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 000000179C9C: BE8E2005
	s_cbranch_execz 17                                         // 000000179CA0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ae8>
	v_mad_u64_u32 v[4:5], null, v109, 48, s[2:3]               // 000000179CA4: D6FE7C04 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179CAC: BF870091
	.long 0xd73c0004                                           // 000000179CB0: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179CB4: 02020889
	.long 0xd7000b04                                           // 000000179CB8: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179CBC: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179CC0: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179CC4: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:128                 // 000000179CCC: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179CD4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 000000179CD8: 560838FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179CE0: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179CE8: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5128                          // 000000179CEC: D87C1408 00000467
	s_and_saveexec_b32 s14, s6                                 // 000000179CF4: BE8E2006
	s_cbranch_execz 17                                         // 000000179CF8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b40>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000179CFC: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179D04: BF870091
	.long 0xd73c0003                                           // 000000179D08: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179D0C: 02020689
	.long 0xd7000b03                                           // 000000179D10: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179D14: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179D18: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179D1C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 000000179D24: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179D2C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v29                         // 000000179D30: 56063AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000179D38: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179D40: 8C7E0E7E
	.long 0x7f063880                                           // 000000179D44: 7F063880
	ds_store_b16 v103, v3 offset:5132                          // 000000179D48: D87C140C 00000367
	.long 0x7e083983                                           // 000000179D50: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 000000179D54: BE8E2007
	s_cbranch_execz 17                                         // 000000179D58: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ba0>
	v_mad_u64_u32 v[4:5], null, v111, 48, s[2:3]               // 000000179D5C: D6FE7C04 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179D64: BF870091
	.long 0xd73c0004                                           // 000000179D68: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179D6C: 02020889
	.long 0xd7000b04                                           // 000000179D70: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179D74: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179D78: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179D7C: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:128                 // 000000179D84: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179D8C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v30                         // 000000179D90: 56083CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179D98: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179DA0: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5136                          // 000000179DA4: D87C1410 00000467
	s_and_saveexec_b32 s14, s8                                 // 000000179DAC: BE8E2008
	s_cbranch_execz 17                                         // 000000179DB0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bf8>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 000000179DB4: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179DBC: BF870091
	.long 0xd73c0003                                           // 000000179DC0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179DC4: 02020689
	.long 0xd7000b03                                           // 000000179DC8: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179DCC: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179DD0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179DD4: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 000000179DDC: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179DE4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v31                         // 000000179DE8: 56063EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000179DF0: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179DF8: 8C7E0E7E
	.long 0x7e063880                                           // 000000179DFC: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:5140                   // 000000179E00: DA841414 00000367
	.long 0x7e083903                                           // 000000179E08: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 000000179E0C: BE8E2009
	s_cbranch_execz 17                                         // 000000179E10: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c58>
	v_mad_u64_u32 v[4:5], null, v113, 48, s[2:3]               // 000000179E14: D6FE7C04 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179E1C: BF870091
	.long 0xd73c0004                                           // 000000179E20: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179E24: 02020889
	.long 0xd7000b04                                           // 000000179E28: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179E2C: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179E30: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179E34: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:128                 // 000000179E3C: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179E44: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v32                         // 000000179E48: 560840FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179E50: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179E58: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5144                          // 000000179E5C: D87C1418 00000467
	s_and_saveexec_b32 s14, s10                                // 000000179E64: BE8E200A
	s_cbranch_execz 17                                         // 000000179E68: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cb0>
	v_mad_u64_u32 v[3:4], null, v114, 48, s[2:3]               // 000000179E6C: D6FE7C03 00096172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179E74: BF870091
	.long 0xd73c0003                                           // 000000179E78: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179E7C: 02020689
	.long 0xd7000b03                                           // 000000179E80: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179E84: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179E88: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179E8C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 000000179E94: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179E9C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v33                         // 000000179EA0: 560642FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000179EA8: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179EB0: 8C7E0E7E
	.long 0x7f063880                                           // 000000179EB4: 7F063880
	ds_store_b16 v103, v3 offset:5148                          // 000000179EB8: D87C141C 00000367
	.long 0x7e083983                                           // 000000179EC0: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 000000179EC4: BE8E2001
	s_cbranch_execz 17                                         // 000000179EC8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d10>
	v_mad_u64_u32 v[4:5], null, v9, 48, s[2:3]                 // 000000179ECC: D6FE7C04 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179ED4: BF870091
	.long 0xd73c0004                                           // 000000179ED8: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179EDC: 02020889
	.long 0xd7000b04                                           // 000000179EE0: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179EE4: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179EE8: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179EEC: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:192                 // 000000179EF4: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179EFC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v18                         // 000000179F00: 560824FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179F08: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179F10: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7680                          // 000000179F14: D87C1E00 00000467
	s_and_saveexec_b32 s14, s4                                 // 000000179F1C: BE8E2004
	s_cbranch_execz 17                                         // 000000179F20: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d68>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 000000179F24: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179F2C: BF870091
	.long 0xd73c0003                                           // 000000179F30: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179F34: 02020689
	.long 0xd7000b03                                           // 000000179F38: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179F3C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179F40: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179F44: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 000000179F4C: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000179F54: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v19                         // 000000179F58: 560626FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000179F60: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179F68: 8C7E0E7E
	.long 0x7e063880                                           // 000000179F6C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:7684                   // 000000179F70: DA841E04 00000367
	.long 0x7e083903                                           // 000000179F78: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 000000179F7C: BE8E2005
	s_cbranch_execz 17                                         // 000000179F80: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2dc8>
	v_mad_u64_u32 v[4:5], null, v109, 48, s[2:3]               // 000000179F84: D6FE7C04 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179F8C: BF870091
	.long 0xd73c0004                                           // 000000179F90: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000179F94: 02020889
	.long 0xd7000b04                                           // 000000179F98: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 000000179F9C: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179FA0: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 000000179FA4: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:192                 // 000000179FAC: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 000000179FB4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v20                         // 000000179FB8: 560828FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000179FC0: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000179FC8: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7688                          // 000000179FCC: D87C1E08 00000467
	s_and_saveexec_b32 s14, s6                                 // 000000179FD4: BE8E2006
	s_cbranch_execz 17                                         // 000000179FD8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e20>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000179FDC: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000179FE4: BF870091
	.long 0xd73c0003                                           // 000000179FE8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000179FEC: 02020689
	.long 0xd7000b03                                           // 000000179FF0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000179FF4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000179FF8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000179FFC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 00000017A004: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017A00C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v21                         // 00000017A010: 56062AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000017A018: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A020: 8C7E0E7E
	.long 0x7f063880                                           // 00000017A024: 7F063880
	ds_store_b16 v103, v3 offset:7692                          // 00000017A028: D87C1E0C 00000367
	.long 0x7e083983                                           // 00000017A030: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 00000017A034: BE8E2007
	s_cbranch_execz 17                                         // 00000017A038: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e80>
	v_mad_u64_u32 v[4:5], null, v111, 48, s[2:3]               // 00000017A03C: D6FE7C04 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A044: BF870091
	.long 0xd73c0004                                           // 00000017A048: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000017A04C: 02020889
	.long 0xd7000b04                                           // 00000017A050: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 00000017A054: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017A058: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 00000017A05C: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:192                 // 00000017A064: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 00000017A06C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v22                         // 00000017A070: 56082CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 00000017A078: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A080: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7696                          // 00000017A084: D87C1E10 00000467
	s_and_saveexec_b32 s14, s8                                 // 00000017A08C: BE8E2008
	s_cbranch_execz 17                                         // 00000017A090: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ed8>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 00000017A094: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A09C: BF870091
	.long 0xd73c0003                                           // 00000017A0A0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000017A0A4: 02020689
	.long 0xd7000b03                                           // 00000017A0A8: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000017A0AC: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017A0B0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 00000017A0B4: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 00000017A0BC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017A0C4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v23                         // 00000017A0C8: 56062EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 00000017A0D0: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A0D8: 8C7E0E7E
	.long 0x7e063880                                           // 00000017A0DC: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:7700                   // 00000017A0E0: DA841E14 00000367
	.long 0x7e083903                                           // 00000017A0E8: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 00000017A0EC: BE8E2009
	s_cbranch_execz 17                                         // 00000017A0F0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f38>
	v_mad_u64_u32 v[4:5], null, v113, 48, s[2:3]               // 00000017A0F4: D6FE7C04 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A0FC: BF870091
	.long 0xd73c0004                                           // 00000017A100: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000017A104: 02020889
	.long 0xd7000b04                                           // 00000017A108: D7000B04
	v_cndmask_b32_e32 v1, v101, v4, vcc_lo                     // 00000017A10C: 02020965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017A110: BF8700C1
	v_add_co_ci_u32_e64 v5, null, v102, v5, s11                // 00000017A114: D5207C05 002E0B66
	global_load_b32 v4, v[4:5], off offset:192                 // 00000017A11C: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 00000017A124: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v24                         // 00000017A128: 560830FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 00000017A130: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A138: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7704                          // 00000017A13C: D87C1E18 00000467
	s_and_saveexec_b32 s14, s10                                // 00000017A144: BE8E200A
	s_cbranch_execz 17                                         // 00000017A148: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f90>
	v_mad_u64_u32 v[3:4], null, v114, 48, s[2:3]               // 00000017A14C: D6FE7C03 00096172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A154: BF870091
	.long 0xd73c0003                                           // 00000017A158: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000017A15C: 02020689
	.long 0xd7000b03                                           // 00000017A160: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000017A164: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017A168: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 00000017A16C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 00000017A174: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000017A17C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v25                         // 00000017A180: 560632FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000017A188: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A190: 8C7E0E7E
	.long 0xd7000b07                                           // 00000017A194: D7000B07
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 00000017A198: 02020E0C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A19C: BF870001
	v_add_co_ci_u32_e64 v8, null, s13, v8, s11                 // 00000017A1A0: D5207C08 002E100D
	ds_store_b16 v103, v3 offset:7708                          // 00000017A1A8: D87C1E1C 00000367
	s_waitcnt lgkmcnt(0)                                       // 00000017A1B0: BF89FC07
	s_barrier                                                  // 00000017A1B4: BFBD0000
	buffer_gl0_inv                                             // 00000017A1B8: E0AC0000 00000000
	global_load_b128 v[3:6], v[7:8], off                       // 00000017A1C0: DC5E0000 037C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A1C8: BE8B2000
	s_cbranch_execnz 2843                                      // 00000017A1CC: BFA60B1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c3c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A1D0: 8C7E0B7E
	global_load_b128 v[18:21], v[7:8], off offset:16           // 00000017A1D4: DC5E0010 127C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A1DC: BE8B2000
	s_cbranch_execnz 2849                                      // 00000017A1E0: BFA60B21 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c68>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A1E4: 8C7E0B7E
	global_load_b128 v[22:25], v[7:8], off offset:32           // 00000017A1E8: DC5E0020 167C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A1F0: BE8B2000
	s_cbranch_execnz 2855                                      // 00000017A1F4: BFA60B27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c94>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A1F8: 8C7E0B7E
	global_load_b128 v[26:29], v[7:8], off offset:48           // 00000017A1FC: DC5E0030 1A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A204: BE8B2000
	s_cbranch_execz 6                                          // 00000017A208: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3024>
	s_waitcnt vmcnt(0)                                         // 00000017A20C: BF8903F7
	v_mov_b32_e32 v27, 0                                       // 00000017A210: 7E360280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A214: BF870001
	v_mov_b32_e32 v26, v27                                     // 00000017A218: 7E34031B
	v_mov_b32_e32 v28, v27                                     // 00000017A21C: 7E38031B
	v_mov_b32_e32 v29, v27                                     // 00000017A220: 7E3A031B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A224: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:64           // 00000017A228: DC5E0040 327C0007
	ds_load_b128 v[30:33], v94                                 // 00000017A230: DBFC0000 1E00005E
	ds_load_b128 v[34:37], v94 offset:16                       // 00000017A238: DBFC0010 2200005E
	s_waitcnt vmcnt(4)                                         // 00000017A240: BF8913F7
	v_fma_mixlo_f16 v54, v3, s22, 0                            // 00000017A244: CC210036 02002D03
	v_fma_mixhi_f16 v54, v4, s22, 0                            // 00000017A24C: CC220036 02002D04
	v_fma_mixlo_f16 v55, v5, s22, 0                            // 00000017A254: CC210037 02002D05
	v_fma_mixhi_f16 v55, v6, s22, 0                            // 00000017A25C: CC220037 02002D06
	ds_load_b128 v[3:6], v94 offset:32                         // 00000017A264: DBFC0020 0300005E
	ds_load_b128 v[38:41], v94 offset:48                       // 00000017A26C: DBFC0030 2600005E
	s_waitcnt vmcnt(1)                                         // 00000017A274: BF8907F7
	v_fma_mixlo_f16 v60, v26, s22, 0                           // 00000017A278: CC21003C 02002D1A
	v_fma_mixhi_f16 v60, v27, s22, 0                           // 00000017A280: CC22003C 02002D1B
	v_fma_mixlo_f16 v61, v28, s22, 0                           // 00000017A288: CC21003D 02002D1C
	v_fma_mixhi_f16 v61, v29, s22, 0                           // 00000017A290: CC22003D 02002D1D
	ds_load_b128 v[26:29], v94 offset:8448                     // 00000017A298: DBFC2100 1A00005E
	v_dual_mov_b32 v69, s43 :: v_dual_mov_b32 v68, s42         // 00000017A2A0: CA10002B 4544002A
	v_fma_mixlo_f16 v56, v18, s22, 0                           // 00000017A2A8: CC210038 02002D12
	v_fma_mixhi_f16 v56, v19, s22, 0                           // 00000017A2B0: CC220038 02002D13
	v_fma_mixlo_f16 v57, v20, s22, 0                           // 00000017A2B8: CC210039 02002D14
	v_fma_mixhi_f16 v57, v21, s22, 0                           // 00000017A2C0: CC220039 02002D15
	v_fma_mixlo_f16 v58, v22, s22, 0                           // 00000017A2C8: CC21003A 02002D16
	v_fma_mixhi_f16 v58, v23, s22, 0                           // 00000017A2D0: CC22003A 02002D17
	v_fma_mixlo_f16 v59, v24, s22, 0                           // 00000017A2D8: CC21003B 02002D18
	v_fma_mixhi_f16 v59, v25, s22, 0                           // 00000017A2E0: CC22003B 02002D19
	s_waitcnt lgkmcnt(4)                                       // 00000017A2E8: BF89FC47
	v_fma_mixlo_f16 v18, v30, s22, 0                           // 00000017A2EC: CC210012 02002D1E
	v_fma_mixhi_f16 v18, v31, s22, 0                           // 00000017A2F4: CC220012 02002D1F
	v_fma_mixlo_f16 v19, v32, s22, 0                           // 00000017A2FC: CC210013 02002D20
	v_fma_mixhi_f16 v19, v33, s22, 0                           // 00000017A304: CC220013 02002D21
	s_waitcnt lgkmcnt(3)                                       // 00000017A30C: BF89FC37
	v_fma_mixlo_f16 v20, v34, s22, 0                           // 00000017A310: CC210014 02002D22
	v_fma_mixhi_f16 v20, v35, s22, 0                           // 00000017A318: CC220014 02002D23
	v_fma_mixlo_f16 v21, v36, s22, 0                           // 00000017A320: CC210015 02002D24
	v_fma_mixhi_f16 v21, v37, s22, 0                           // 00000017A328: CC220015 02002D25
	s_waitcnt lgkmcnt(2)                                       // 00000017A330: BF89FC27
	v_fma_mixlo_f16 v22, v3, s22, 0                            // 00000017A334: CC210016 02002D03
	v_fma_mixhi_f16 v22, v4, s22, 0                            // 00000017A33C: CC220016 02002D04
	v_fma_mixlo_f16 v23, v5, s22, 0                            // 00000017A344: CC210017 02002D05
	v_fma_mixhi_f16 v23, v6, s22, 0                            // 00000017A34C: CC220017 02002D06
	s_waitcnt lgkmcnt(1)                                       // 00000017A354: BF89FC17
	v_fma_mixlo_f16 v24, v38, s22, 0                           // 00000017A358: CC210018 02002D26
	v_fma_mixhi_f16 v24, v39, s22, 0                           // 00000017A360: CC220018 02002D27
	v_fma_mixlo_f16 v25, v40, s22, 0                           // 00000017A368: CC210019 02002D28
	v_fma_mixhi_f16 v25, v41, s22, 0                           // 00000017A370: CC220019 02002D29
	v_dual_mov_b32 v67, s41 :: v_dual_mov_b32 v66, s40         // 00000017A378: CA100029 43420028
	v_dual_mov_b32 v65, s39 :: v_dual_mov_b32 v64, s38         // 00000017A380: CA100027 41400026
	v_dual_mov_b32 v63, s37 :: v_dual_mov_b32 v62, s36         // 00000017A388: CA100025 3F3E0024
	ds_load_b128 v[30:33], v94 offset:8464                     // 00000017A390: DBFC2110 1E00005E
	ds_load_b128 v[3:6], v94 offset:8480                       // 00000017A398: DBFC2120 0300005E
	ds_load_b128 v[34:37], v94 offset:8496                     // 00000017A3A0: DBFC2130 2200005E
	ds_load_b128 v[38:41], v94 offset:16896                    // 00000017A3A8: DBFC4200 2600005E
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[18:25], v[62:69]// 00000017A3B0: CC40402A 1CFA2536
	s_waitcnt lgkmcnt(4)                                       // 00000017A3B8: BF89FC47
	v_fma_mixlo_f16 v18, v26, s22, 0                           // 00000017A3BC: CC210012 02002D1A
	v_fma_mixhi_f16 v18, v27, s22, 0                           // 00000017A3C4: CC220012 02002D1B
	v_fma_mixlo_f16 v19, v28, s22, 0                           // 00000017A3CC: CC210013 02002D1C
	v_fma_mixhi_f16 v19, v29, s22, 0                           // 00000017A3D4: CC220013 02002D1D
	ds_load_b128 v[26:29], v94 offset:16912                    // 00000017A3DC: DBFC4210 1A00005E
	ds_load_b128 v[78:81], v94 offset:25360                    // 00000017A3E4: DBFC6310 4E00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017A3EC: BF89FC57
	v_fma_mixlo_f16 v20, v30, s22, 0                           // 00000017A3F0: CC210014 02002D1E
	v_fma_mixhi_f16 v20, v31, s22, 0                           // 00000017A3F8: CC220014 02002D1F
	v_fma_mixlo_f16 v21, v32, s22, 0                           // 00000017A400: CC210015 02002D20
	v_fma_mixhi_f16 v21, v33, s22, 0                           // 00000017A408: CC220015 02002D21
	s_waitcnt lgkmcnt(4)                                       // 00000017A410: BF89FC47
	v_fma_mixlo_f16 v22, v3, s22, 0                            // 00000017A414: CC210016 02002D03
	ds_load_b128 v[30:33], v94 offset:16928                    // 00000017A41C: DBFC4220 1E00005E
	v_fma_mixhi_f16 v22, v4, s22, 0                            // 00000017A424: CC220016 02002D04
	v_fma_mixlo_f16 v23, v5, s22, 0                            // 00000017A42C: CC210017 02002D05
	v_fma_mixhi_f16 v23, v6, s22, 0                            // 00000017A434: CC220017 02002D06
	s_waitcnt lgkmcnt(4)                                       // 00000017A43C: BF89FC47
	v_fma_mixlo_f16 v24, v34, s22, 0                           // 00000017A440: CC210018 02002D22
	ds_load_b128 v[3:6], v94 offset:16944                      // 00000017A448: DBFC4230 0300005E
	v_fma_mixhi_f16 v24, v35, s22, 0                           // 00000017A450: CC220018 02002D23
	v_fma_mixlo_f16 v25, v36, s22, 0                           // 00000017A458: CC210019 02002D24
	v_fma_mixhi_f16 v25, v37, s22, 0                           // 00000017A460: CC220019 02002D25
	ds_load_b128 v[34:37], v94 offset:25344                    // 00000017A468: DBFC6300 2200005E
	s_waitcnt lgkmcnt(5)                                       // 00000017A470: BF89FC57
	v_fma_mixlo_f16 v70, v38, s22, 0                           // 00000017A474: CC210046 02002D26
	v_fma_mixhi_f16 v70, v39, s22, 0                           // 00000017A47C: CC220046 02002D27
	v_fma_mixlo_f16 v71, v40, s22, 0                           // 00000017A484: CC210047 02002D28
	v_fma_mixhi_f16 v71, v41, s22, 0                           // 00000017A48C: CC220047 02002D29
	s_waitcnt lgkmcnt(4)                                       // 00000017A494: BF89FC47
	v_fma_mixlo_f16 v72, v26, s22, 0                           // 00000017A498: CC210048 02002D1A
	v_fma_mixhi_f16 v72, v27, s22, 0                           // 00000017A4A0: CC220048 02002D1B
	ds_load_b128 v[38:41], v94 offset:25376                    // 00000017A4A8: DBFC6320 2600005E
	v_fma_mixlo_f16 v73, v28, s22, 0                           // 00000017A4B0: CC210049 02002D1C
	v_fma_mixhi_f16 v73, v29, s22, 0                           // 00000017A4B8: CC220049 02002D1D
	ds_load_b128 v[26:29], v94 offset:25392                    // 00000017A4C0: DBFC6330 1A00005E
	s_waitcnt lgkmcnt(4)                                       // 00000017A4C8: BF89FC47
	v_fma_mixlo_f16 v74, v30, s22, 0                           // 00000017A4CC: CC21004A 02002D1E
	v_fma_mixhi_f16 v74, v31, s22, 0                           // 00000017A4D4: CC22004A 02002D1F
	v_fma_mixlo_f16 v75, v32, s22, 0                           // 00000017A4DC: CC21004B 02002D20
	v_fma_mixhi_f16 v75, v33, s22, 0                           // 00000017A4E4: CC22004B 02002D21
	v_fma_mixlo_f16 v117, v78, s22, 0                          // 00000017A4EC: CC210075 02002D4E
	s_waitcnt lgkmcnt(3)                                       // 00000017A4F4: BF89FC37
	v_fma_mixlo_f16 v76, v3, s22, 0                            // 00000017A4F8: CC21004C 02002D03
	v_fma_mixhi_f16 v76, v4, s22, 0                            // 00000017A500: CC22004C 02002D04
	v_fma_mixlo_f16 v77, v5, s22, 0                            // 00000017A508: CC21004D 02002D05
	v_fma_mixhi_f16 v77, v6, s22, 0                            // 00000017A510: CC22004D 02002D06
	s_waitcnt lgkmcnt(2)                                       // 00000017A518: BF89FC27
	v_fma_mixlo_f16 v115, v34, s22, 0                          // 00000017A51C: CC210073 02002D22
	v_fma_mixhi_f16 v115, v35, s22, 0                          // 00000017A524: CC220073 02002D23
	v_fma_mixlo_f16 v116, v36, s22, 0                          // 00000017A52C: CC210074 02002D24
	v_fma_mixhi_f16 v116, v37, s22, 0                          // 00000017A534: CC220074 02002D25
	v_fma_mixhi_f16 v117, v79, s22, 0                          // 00000017A53C: CC220075 02002D4F
	v_fma_mixlo_f16 v118, v80, s22, 0                          // 00000017A544: CC210076 02002D50
	v_fma_mixhi_f16 v118, v81, s22, 0                          // 00000017A54C: CC220076 02002D51
	s_waitcnt lgkmcnt(1)                                       // 00000017A554: BF89FC17
	v_fma_mixlo_f16 v119, v38, s22, 0                          // 00000017A558: CC210077 02002D26
	v_fma_mixhi_f16 v119, v39, s22, 0                          // 00000017A560: CC220077 02002D27
	v_fma_mixlo_f16 v120, v40, s22, 0                          // 00000017A568: CC210078 02002D28
	v_fma_mixhi_f16 v120, v41, s22, 0                          // 00000017A570: CC220078 02002D29
	s_waitcnt lgkmcnt(0)                                       // 00000017A578: BF89FC07
	v_fma_mixlo_f16 v121, v26, s22, 0                          // 00000017A57C: CC210079 02002D1A
	v_fma_mixhi_f16 v121, v27, s22, 0                          // 00000017A584: CC220079 02002D1B
	v_fma_mixlo_f16 v122, v28, s22, 0                          // 00000017A58C: CC21007A 02002D1C
	v_fma_mixhi_f16 v122, v29, s22, 0                          // 00000017A594: CC22007A 02002D1D
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[18:25], v[62:69]// 00000017A59C: CC404022 1CFA2536
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[70:77], v[62:69]// 00000017A5A4: CC40401A 1CFA8D36
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017A5AC: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[115:122], v[62:69]// 00000017A5B0: CC404012 1CFAE736
	s_and_saveexec_b32 s11, s0                                 // 00000017A5B8: BE8B2000
	s_cbranch_execnz 2625                                      // 00000017A5BC: BFA60A41 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5cc4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A5C0: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:80           // 00000017A5C4: DC5E0050 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A5CC: BE8B2000
	s_cbranch_execnz 2631                                      // 00000017A5D0: BFA60A47 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5cf0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A5D4: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:96           // 00000017A5D8: DC5E0060 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A5E0: BE8B2000
	s_cbranch_execnz 2637                                      // 00000017A5E4: BFA60A4D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d1c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A5E8: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:112          // 00000017A5EC: DC5E0070 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A5F4: BE8B2000
	s_cbranch_execz 6                                          // 00000017A5F8: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3414>
	s_waitcnt vmcnt(0)                                         // 00000017A5FC: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017A600: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A604: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017A608: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017A60C: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017A610: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A614: 8C7E0B7E
	global_load_b128 v[3:6], v[7:8], off offset:128            // 00000017A618: DC5E0080 037C0007
	ds_load_b128 v[66:69], v94 offset:64                       // 00000017A620: DBFC0040 4200005E
	ds_load_b128 v[70:73], v94 offset:80                       // 00000017A628: DBFC0050 4600005E
	ds_load_b128 v[74:77], v94 offset:96                       // 00000017A630: DBFC0060 4A00005E
	ds_load_b128 v[78:81], v94 offset:112                      // 00000017A638: DBFC0070 4E00005E
	ds_load_b128 v[115:118], v94 offset:8512                   // 00000017A640: DBFC2140 7300005E
	ds_load_b128 v[119:122], v94 offset:8528                   // 00000017A648: DBFC2150 7700005E
	s_waitcnt vmcnt(4)                                         // 00000017A650: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 00000017A654: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 00000017A65C: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 00000017A664: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 00000017A66C: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 00000017A674: BF890FF7
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 00000017A678: CC210034 02002D36
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 00000017A680: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 00000017A688: CC210035 02002D38
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 00000017A690: CC220035 02002D39
	s_waitcnt vmcnt(2)                                         // 00000017A698: BF890BF7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 00000017A69C: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 00000017A6A4: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 00000017A6AC: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 00000017A6B4: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 00000017A6BC: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 00000017A6C0: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 00000017A6C8: CC220038 02002D3F
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 00000017A6D0: CC210039 02002D40
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 00000017A6D8: CC220039 02002D41
	s_waitcnt lgkmcnt(5)                                       // 00000017A6E0: BF89FC57
	v_fma_mixlo_f16 v58, v66, s22, 0                           // 00000017A6E4: CC21003A 02002D42
	v_fma_mixhi_f16 v58, v67, s22, 0                           // 00000017A6EC: CC22003A 02002D43
	v_fma_mixlo_f16 v59, v68, s22, 0                           // 00000017A6F4: CC21003B 02002D44
	v_fma_mixhi_f16 v59, v69, s22, 0                           // 00000017A6FC: CC22003B 02002D45
	s_waitcnt lgkmcnt(4)                                       // 00000017A704: BF89FC47
	v_fma_mixlo_f16 v60, v70, s22, 0                           // 00000017A708: CC21003C 02002D46
	v_fma_mixhi_f16 v60, v71, s22, 0                           // 00000017A710: CC22003C 02002D47
	v_fma_mixlo_f16 v61, v72, s22, 0                           // 00000017A718: CC21003D 02002D48
	v_fma_mixhi_f16 v61, v73, s22, 0                           // 00000017A720: CC22003D 02002D49
	ds_load_b128 v[70:73], v94 offset:8544                     // 00000017A728: DBFC2160 4600005E
	s_waitcnt lgkmcnt(4)                                       // 00000017A730: BF89FC47
	v_fma_mixlo_f16 v62, v74, s22, 0                           // 00000017A734: CC21003E 02002D4A
	v_fma_mixhi_f16 v62, v75, s22, 0                           // 00000017A73C: CC22003E 02002D4B
	v_fma_mixlo_f16 v63, v76, s22, 0                           // 00000017A744: CC21003F 02002D4C
	v_fma_mixhi_f16 v63, v77, s22, 0                           // 00000017A74C: CC22003F 02002D4D
	ds_load_b128 v[74:77], v94 offset:8560                     // 00000017A754: DBFC2170 4A00005E
	s_waitcnt lgkmcnt(4)                                       // 00000017A75C: BF89FC47
	v_fma_mixlo_f16 v64, v78, s22, 0                           // 00000017A760: CC210040 02002D4E
	v_fma_mixhi_f16 v64, v79, s22, 0                           // 00000017A768: CC220040 02002D4F
	v_fma_mixlo_f16 v65, v80, s22, 0                           // 00000017A770: CC210041 02002D50
	v_fma_mixhi_f16 v65, v81, s22, 0                           // 00000017A778: CC220041 02002D51
	s_waitcnt lgkmcnt(3)                                       // 00000017A780: BF89FC37
	v_fma_mixlo_f16 v66, v115, s22, 0                          // 00000017A784: CC210042 02002D73
	ds_load_b128 v[78:81], v94 offset:16960                    // 00000017A78C: DBFC4240 4E00005E
	v_fma_mixhi_f16 v66, v116, s22, 0                          // 00000017A794: CC220042 02002D74
	v_fma_mixlo_f16 v67, v117, s22, 0                          // 00000017A79C: CC210043 02002D75
	v_fma_mixhi_f16 v67, v118, s22, 0                          // 00000017A7A4: CC220043 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017A7AC: BF89FC37
	v_fma_mixlo_f16 v68, v119, s22, 0                          // 00000017A7B0: CC210044 02002D77
	ds_load_b128 v[115:118], v94 offset:16976                  // 00000017A7B8: DBFC4250 7300005E
	v_fma_mixhi_f16 v68, v120, s22, 0                          // 00000017A7C0: CC220044 02002D78
	v_fma_mixlo_f16 v69, v121, s22, 0                          // 00000017A7C8: CC210045 02002D79
	v_fma_mixhi_f16 v69, v122, s22, 0                          // 00000017A7D0: CC220045 02002D7A
	ds_load_b128 v[119:122], v94 offset:16992                  // 00000017A7D8: DBFC4260 7700005E
	ds_load_b128 v[123:126], v94 offset:17008                  // 00000017A7E0: DBFC4270 7B00005E
	ds_load_b128 v[127:130], v94 offset:25408                  // 00000017A7E8: DBFC6340 7F00005E
	ds_load_b128 v[131:134], v94 offset:25424                  // 00000017A7F0: DBFC6350 8300005E
	ds_load_b128 v[135:138], v94 offset:25440                  // 00000017A7F8: DBFC6360 8700005E
	ds_load_b128 v[139:142], v94 offset:25456                  // 00000017A800: DBFC6370 8B00005E
	s_waitcnt lgkmcnt(9)                                       // 00000017A808: BF89FC97
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 00000017A80C: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 00000017A814: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 00000017A81C: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 00000017A824: CC220047 02002D49
	s_waitcnt lgkmcnt(8)                                       // 00000017A82C: BF89FC87
	v_fma_mixlo_f16 v72, v74, s22, 0                           // 00000017A830: CC210048 02002D4A
	v_fma_mixhi_f16 v72, v75, s22, 0                           // 00000017A838: CC220048 02002D4B
	v_fma_mixlo_f16 v73, v76, s22, 0                           // 00000017A840: CC210049 02002D4C
	v_fma_mixhi_f16 v73, v77, s22, 0                           // 00000017A848: CC220049 02002D4D
	s_waitcnt lgkmcnt(7)                                       // 00000017A850: BF89FC77
	v_fma_mixlo_f16 v74, v78, s22, 0                           // 00000017A854: CC21004A 02002D4E
	v_fma_mixhi_f16 v74, v79, s22, 0                           // 00000017A85C: CC22004A 02002D4F
	v_fma_mixlo_f16 v75, v80, s22, 0                           // 00000017A864: CC21004B 02002D50
	v_fma_mixhi_f16 v75, v81, s22, 0                           // 00000017A86C: CC22004B 02002D51
	s_waitcnt lgkmcnt(6)                                       // 00000017A874: BF89FC67
	v_fma_mixlo_f16 v76, v115, s22, 0                          // 00000017A878: CC21004C 02002D73
	v_fma_mixhi_f16 v76, v116, s22, 0                          // 00000017A880: CC22004C 02002D74
	v_fma_mixlo_f16 v77, v117, s22, 0                          // 00000017A888: CC21004D 02002D75
	v_fma_mixhi_f16 v77, v118, s22, 0                          // 00000017A890: CC22004D 02002D76
	s_waitcnt lgkmcnt(5)                                       // 00000017A898: BF89FC57
	v_fma_mixlo_f16 v78, v119, s22, 0                          // 00000017A89C: CC21004E 02002D77
	v_fma_mixhi_f16 v78, v120, s22, 0                          // 00000017A8A4: CC22004E 02002D78
	v_fma_mixlo_f16 v79, v121, s22, 0                          // 00000017A8AC: CC21004F 02002D79
	v_fma_mixhi_f16 v79, v122, s22, 0                          // 00000017A8B4: CC22004F 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017A8BC: BF89FC47
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017A8C0: CC210050 02002D7B
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017A8C8: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017A8D0: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017A8D8: CC220051 02002D7E
	s_waitcnt lgkmcnt(3)                                       // 00000017A8E0: BF89FC37
	v_fma_mixlo_f16 v115, v127, s22, 0                         // 00000017A8E4: CC210073 02002D7F
	v_fma_mixhi_f16 v115, v128, s22, 0                         // 00000017A8EC: CC220073 02002D80
	v_fma_mixlo_f16 v116, v129, s22, 0                         // 00000017A8F4: CC210074 02002D81
	v_fma_mixhi_f16 v116, v130, s22, 0                         // 00000017A8FC: CC220074 02002D82
	s_waitcnt lgkmcnt(2)                                       // 00000017A904: BF89FC27
	v_fma_mixlo_f16 v117, v131, s22, 0                         // 00000017A908: CC210075 02002D83
	v_fma_mixhi_f16 v117, v132, s22, 0                         // 00000017A910: CC220075 02002D84
	v_fma_mixlo_f16 v118, v133, s22, 0                         // 00000017A918: CC210076 02002D85
	v_fma_mixhi_f16 v118, v134, s22, 0                         // 00000017A920: CC220076 02002D86
	s_waitcnt lgkmcnt(1)                                       // 00000017A928: BF89FC17
	v_fma_mixlo_f16 v119, v135, s22, 0                         // 00000017A92C: CC210077 02002D87
	v_fma_mixhi_f16 v119, v136, s22, 0                         // 00000017A934: CC220077 02002D88
	v_fma_mixlo_f16 v120, v137, s22, 0                         // 00000017A93C: CC210078 02002D89
	v_fma_mixhi_f16 v120, v138, s22, 0                         // 00000017A944: CC220078 02002D8A
	s_waitcnt lgkmcnt(0)                                       // 00000017A94C: BF89FC07
	v_fma_mixlo_f16 v121, v139, s22, 0                         // 00000017A950: CC210079 02002D8B
	v_fma_mixhi_f16 v121, v140, s22, 0                         // 00000017A958: CC220079 02002D8C
	v_fma_mixlo_f16 v122, v141, s22, 0                         // 00000017A960: CC21007A 02002D8D
	v_fma_mixhi_f16 v122, v142, s22, 0                         // 00000017A968: CC22007A 02002D8E
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000017A970: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[66:73], v[34:41]// 00000017A978: CC404022 1C8A8532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[74:81], v[26:33]// 00000017A980: CC40401A 1C6A9532
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017A988: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[115:122], v[18:25]// 00000017A98C: CC404012 1C4AE732
	s_and_saveexec_b32 s11, s0                                 // 00000017A994: BE8B2000
	s_cbranch_execnz 2412                                      // 00000017A998: BFA6096C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d4c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A99C: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:144          // 00000017A9A0: DC5E0090 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A9A8: BE8B2000
	s_cbranch_execnz 2418                                      // 00000017A9AC: BFA60972 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d78>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A9B0: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:160          // 00000017A9B4: DC5E00A0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A9BC: BE8B2000
	s_cbranch_execnz 2424                                      // 00000017A9C0: BFA60978 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5da4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A9C4: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:176          // 00000017A9C8: DC5E00B0 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017A9D0: BE8B2000
	s_cbranch_execz 6                                          // 00000017A9D4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37f0>
	s_waitcnt vmcnt(0)                                         // 00000017A9D8: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017A9DC: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A9E0: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017A9E4: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017A9E8: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017A9EC: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017A9F0: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:192          // 00000017A9F4: DC5E00C0 327C0007
	s_waitcnt vmcnt(4)                                         // 00000017A9FC: BF8913F7
	v_fma_mixlo_f16 v66, v3, s22, 0                            // 00000017AA00: CC210042 02002D03
	ds_load_b128 v[74:77], v94 offset:128                      // 00000017AA08: DBFC0080 4A00005E
	v_fma_mixhi_f16 v66, v4, s22, 0                            // 00000017AA10: CC220042 02002D04
	v_fma_mixlo_f16 v67, v5, s22, 0                            // 00000017AA18: CC210043 02002D05
	v_fma_mixhi_f16 v67, v6, s22, 0                            // 00000017AA20: CC220043 02002D06
	ds_load_b128 v[3:6], v94 offset:144                        // 00000017AA28: DBFC0090 0300005E
	ds_load_b128 v[78:81], v94 offset:160                      // 00000017AA30: DBFC00A0 4E00005E
	ds_load_b128 v[115:118], v94 offset:176                    // 00000017AA38: DBFC00B0 7300005E
	s_waitcnt vmcnt(1)                                         // 00000017AA40: BF8907F7
	v_fma_mixlo_f16 v72, v62, s22, 0                           // 00000017AA44: CC210048 02002D3E
	v_fma_mixhi_f16 v72, v63, s22, 0                           // 00000017AA4C: CC220048 02002D3F
	v_fma_mixlo_f16 v73, v64, s22, 0                           // 00000017AA54: CC210049 02002D40
	v_fma_mixhi_f16 v73, v65, s22, 0                           // 00000017AA5C: CC220049 02002D41
	ds_load_b128 v[62:65], v94 offset:8576                     // 00000017AA64: DBFC2180 3E00005E
	ds_load_b128 v[119:122], v94 offset:8592                   // 00000017AA6C: DBFC2190 7700005E
	v_fma_mixlo_f16 v68, v54, s22, 0                           // 00000017AA74: CC210044 02002D36
	v_fma_mixlo_f16 v69, v56, s22, 0                           // 00000017AA7C: CC210045 02002D38
	v_fma_mixhi_f16 v69, v57, s22, 0                           // 00000017AA84: CC220045 02002D39
	v_fma_mixlo_f16 v71, v60, s22, 0                           // 00000017AA8C: CC210047 02002D3C
	v_fma_mixhi_f16 v71, v61, s22, 0                           // 00000017AA94: CC220047 02002D3D
	ds_load_b128 v[123:126], v94 offset:8624                   // 00000017AA9C: DBFC21B0 7B00005E
	v_fma_mixhi_f16 v68, v55, s22, 0                           // 00000017AAA4: CC220044 02002D37
	s_waitcnt lgkmcnt(6)                                       // 00000017AAAC: BF89FC67
	v_fma_mixlo_f16 v54, v74, s22, 0                           // 00000017AAB0: CC210036 02002D4A
	v_fma_mixhi_f16 v54, v75, s22, 0                           // 00000017AAB8: CC220036 02002D4B
	v_fma_mixlo_f16 v70, v58, s22, 0                           // 00000017AAC0: CC210046 02002D3A
	v_fma_mixhi_f16 v70, v59, s22, 0                           // 00000017AAC8: CC220046 02002D3B
	s_waitcnt lgkmcnt(5)                                       // 00000017AAD0: BF89FC57
	v_fma_mixlo_f16 v56, v3, s22, 0                            // 00000017AAD4: CC210038 02002D03
	v_fma_mixhi_f16 v56, v4, s22, 0                            // 00000017AADC: CC220038 02002D04
	v_fma_mixlo_f16 v57, v5, s22, 0                            // 00000017AAE4: CC210039 02002D05
	v_fma_mixhi_f16 v57, v6, s22, 0                            // 00000017AAEC: CC220039 02002D06
	ds_load_b128 v[3:6], v94 offset:8608                       // 00000017AAF4: DBFC21A0 0300005E
	s_waitcnt lgkmcnt(4)                                       // 00000017AAFC: BF89FC47
	v_fma_mixlo_f16 v60, v115, s22, 0                          // 00000017AB00: CC21003C 02002D73
	v_fma_mixhi_f16 v60, v116, s22, 0                          // 00000017AB08: CC22003C 02002D74
	v_fma_mixlo_f16 v61, v117, s22, 0                          // 00000017AB10: CC21003D 02002D75
	v_fma_mixhi_f16 v61, v118, s22, 0                          // 00000017AB18: CC22003D 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017AB20: BF89FC37
	v_fma_mixlo_f16 v74, v62, s22, 0                           // 00000017AB24: CC21004A 02002D3E
	ds_load_b128 v[115:118], v94 offset:17024                  // 00000017AB2C: DBFC4280 7300005E
	v_fma_mixhi_f16 v74, v63, s22, 0                           // 00000017AB34: CC22004A 02002D3F
	v_fma_mixlo_f16 v75, v64, s22, 0                           // 00000017AB3C: CC21004B 02002D40
	v_fma_mixhi_f16 v75, v65, s22, 0                           // 00000017AB44: CC22004B 02002D41
	ds_load_b128 v[62:65], v94 offset:17040                    // 00000017AB4C: DBFC4290 3E00005E
	v_fma_mixlo_f16 v55, v76, s22, 0                           // 00000017AB54: CC210037 02002D4C
	v_fma_mixhi_f16 v55, v77, s22, 0                           // 00000017AB5C: CC220037 02002D4D
	v_fma_mixlo_f16 v58, v78, s22, 0                           // 00000017AB64: CC21003A 02002D4E
	v_fma_mixhi_f16 v58, v79, s22, 0                           // 00000017AB6C: CC22003A 02002D4F
	v_fma_mixlo_f16 v59, v80, s22, 0                           // 00000017AB74: CC21003B 02002D50
	v_fma_mixhi_f16 v59, v81, s22, 0                           // 00000017AB7C: CC22003B 02002D51
	s_waitcnt lgkmcnt(4)                                       // 00000017AB84: BF89FC47
	v_fma_mixlo_f16 v76, v119, s22, 0                          // 00000017AB88: CC21004C 02002D77
	v_fma_mixhi_f16 v76, v120, s22, 0                          // 00000017AB90: CC22004C 02002D78
	v_fma_mixlo_f16 v77, v121, s22, 0                          // 00000017AB98: CC21004D 02002D79
	v_fma_mixhi_f16 v77, v122, s22, 0                          // 00000017ABA0: CC22004D 02002D7A
	s_waitcnt lgkmcnt(2)                                       // 00000017ABA8: BF89FC27
	v_fma_mixlo_f16 v78, v3, s22, 0                            // 00000017ABAC: CC21004E 02002D03
	ds_load_b128 v[119:122], v94 offset:17056                  // 00000017ABB4: DBFC42A0 7700005E
	v_fma_mixhi_f16 v78, v4, s22, 0                            // 00000017ABBC: CC22004E 02002D04
	v_fma_mixlo_f16 v79, v5, s22, 0                            // 00000017ABC4: CC21004F 02002D05
	v_fma_mixhi_f16 v79, v6, s22, 0                            // 00000017ABCC: CC22004F 02002D06
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017ABD4: CC210050 02002D7B
	ds_load_b128 v[3:6], v94 offset:17072                      // 00000017ABDC: DBFC42B0 0300005E
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017ABE4: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017ABEC: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017ABF4: CC220051 02002D7E
	ds_load_b128 v[123:126], v94 offset:25472                  // 00000017ABFC: DBFC6380 7B00005E
	ds_load_b128 v[127:130], v94 offset:25488                  // 00000017AC04: DBFC6390 7F00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017AC0C: BF89FC57
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 00000017AC10: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 00000017AC18: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 00000017AC20: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 00000017AC28: CC220074 02002D76
	s_waitcnt lgkmcnt(4)                                       // 00000017AC30: BF89FC47
	v_fma_mixlo_f16 v117, v62, s22, 0                          // 00000017AC34: CC210075 02002D3E
	v_fma_mixhi_f16 v117, v63, s22, 0                          // 00000017AC3C: CC220075 02002D3F
	ds_load_b128 v[131:134], v94 offset:25504                  // 00000017AC44: DBFC63A0 8300005E
	v_fma_mixlo_f16 v118, v64, s22, 0                          // 00000017AC4C: CC210076 02002D40
	v_fma_mixhi_f16 v118, v65, s22, 0                          // 00000017AC54: CC220076 02002D41
	ds_load_b128 v[62:65], v94 offset:25520                    // 00000017AC5C: DBFC63B0 3E00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017AC64: BF89FC57
	v_fma_mixlo_f16 v119, v119, s22, 0                         // 00000017AC68: CC210077 02002D77
	v_fma_mixhi_f16 v119, v120, s22, 0                         // 00000017AC70: CC220077 02002D78
	v_fma_mixlo_f16 v120, v121, s22, 0                         // 00000017AC78: CC210078 02002D79
	v_fma_mixhi_f16 v120, v122, s22, 0                         // 00000017AC80: CC220078 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017AC88: BF89FC47
	v_fma_mixlo_f16 v121, v3, s22, 0                           // 00000017AC8C: CC210079 02002D03
	v_fma_mixhi_f16 v121, v4, s22, 0                           // 00000017AC94: CC220079 02002D04
	v_fma_mixlo_f16 v122, v5, s22, 0                           // 00000017AC9C: CC21007A 02002D05
	v_fma_mixhi_f16 v122, v6, s22, 0                           // 00000017ACA4: CC22007A 02002D06
	s_waitcnt lgkmcnt(3)                                       // 00000017ACAC: BF89FC37
	v_fma_mixlo_f16 v123, v123, s22, 0                         // 00000017ACB0: CC21007B 02002D7B
	v_fma_mixhi_f16 v123, v124, s22, 0                         // 00000017ACB8: CC22007B 02002D7C
	v_fma_mixlo_f16 v124, v125, s22, 0                         // 00000017ACC0: CC21007C 02002D7D
	v_fma_mixhi_f16 v124, v126, s22, 0                         // 00000017ACC8: CC22007C 02002D7E
	s_waitcnt lgkmcnt(2)                                       // 00000017ACD0: BF89FC27
	v_fma_mixlo_f16 v125, v127, s22, 0                         // 00000017ACD4: CC21007D 02002D7F
	v_fma_mixhi_f16 v125, v128, s22, 0                         // 00000017ACDC: CC22007D 02002D80
	v_fma_mixlo_f16 v126, v129, s22, 0                         // 00000017ACE4: CC21007E 02002D81
	v_fma_mixhi_f16 v126, v130, s22, 0                         // 00000017ACEC: CC22007E 02002D82
	s_waitcnt lgkmcnt(1)                                       // 00000017ACF4: BF89FC17
	v_fma_mixlo_f16 v127, v131, s22, 0                         // 00000017ACF8: CC21007F 02002D83
	v_fma_mixhi_f16 v127, v132, s22, 0                         // 00000017AD00: CC22007F 02002D84
	v_fma_mixlo_f16 v128, v133, s22, 0                         // 00000017AD08: CC210080 02002D85
	v_fma_mixhi_f16 v128, v134, s22, 0                         // 00000017AD10: CC220080 02002D86
	s_waitcnt lgkmcnt(0)                                       // 00000017AD18: BF89FC07
	v_fma_mixlo_f16 v129, v62, s22, 0                          // 00000017AD1C: CC210081 02002D3E
	v_fma_mixhi_f16 v129, v63, s22, 0                          // 00000017AD24: CC220081 02002D3F
	v_fma_mixlo_f16 v130, v64, s22, 0                          // 00000017AD2C: CC210082 02002D40
	v_fma_mixhi_f16 v130, v65, s22, 0                          // 00000017AD34: CC220082 02002D41
	v_wmma_f32_16x16x16_f16 v[42:49], v[66:73], v[54:61], v[42:49]// 00000017AD3C: CC40402A 1CAA6D42
	v_wmma_f32_16x16x16_f16 v[34:41], v[66:73], v[74:81], v[34:41]// 00000017AD44: CC404022 1C8A9542
	v_wmma_f32_16x16x16_f16 v[26:33], v[66:73], v[115:122], v[26:33]// 00000017AD4C: CC40401A 1C6AE742
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017AD54: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[66:73], v[123:130], v[18:25]// 00000017AD58: CC404012 1C4AF742
	s_and_saveexec_b32 s11, s0                                 // 00000017AD60: BE8B2000
	s_cbranch_execnz 2203                                      // 00000017AD64: BFA6089B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5dd4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017AD68: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:208          // 00000017AD6C: DC5E00D0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017AD74: BE8B2000
	s_cbranch_execnz 2209                                      // 00000017AD78: BFA608A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e00>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017AD7C: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:224          // 00000017AD80: DC5E00E0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017AD88: BE8B2000
	s_cbranch_execnz 2215                                      // 00000017AD8C: BFA608A7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e2c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017AD90: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:240          // 00000017AD94: DC5E00F0 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017AD9C: BE8B2000
	s_cbranch_execz 6                                          // 00000017ADA0: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3bbc>
	s_waitcnt vmcnt(0)                                         // 00000017ADA4: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017ADA8: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017ADAC: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017ADB0: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017ADB4: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017ADB8: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017ADBC: 8C7E0B7E
	global_load_b128 v[3:6], v[7:8], off offset:256            // 00000017ADC0: DC5E0100 037C0007
	ds_load_b128 v[66:69], v94 offset:192                      // 00000017ADC8: DBFC00C0 4200005E
	ds_load_b128 v[70:73], v94 offset:208                      // 00000017ADD0: DBFC00D0 4600005E
	ds_load_b128 v[74:77], v94 offset:224                      // 00000017ADD8: DBFC00E0 4A00005E
	ds_load_b128 v[78:81], v94 offset:240                      // 00000017ADE0: DBFC00F0 4E00005E
	ds_load_b128 v[115:118], v94 offset:8640                   // 00000017ADE8: DBFC21C0 7300005E
	ds_load_b128 v[119:122], v94 offset:8656                   // 00000017ADF0: DBFC21D0 7700005E
	s_waitcnt vmcnt(4)                                         // 00000017ADF8: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 00000017ADFC: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 00000017AE04: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 00000017AE0C: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 00000017AE14: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 00000017AE1C: BF890FF7
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 00000017AE20: CC210034 02002D36
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 00000017AE28: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 00000017AE30: CC210035 02002D38
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 00000017AE38: CC220035 02002D39
	s_waitcnt vmcnt(2)                                         // 00000017AE40: BF890BF7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 00000017AE44: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 00000017AE4C: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 00000017AE54: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 00000017AE5C: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 00000017AE64: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 00000017AE68: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 00000017AE70: CC220038 02002D3F
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 00000017AE78: CC210039 02002D40
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 00000017AE80: CC220039 02002D41
	s_waitcnt lgkmcnt(5)                                       // 00000017AE88: BF89FC57
	v_fma_mixlo_f16 v58, v66, s22, 0                           // 00000017AE8C: CC21003A 02002D42
	v_fma_mixhi_f16 v58, v67, s22, 0                           // 00000017AE94: CC22003A 02002D43
	v_fma_mixlo_f16 v59, v68, s22, 0                           // 00000017AE9C: CC21003B 02002D44
	v_fma_mixhi_f16 v59, v69, s22, 0                           // 00000017AEA4: CC22003B 02002D45
	s_waitcnt lgkmcnt(4)                                       // 00000017AEAC: BF89FC47
	v_fma_mixlo_f16 v60, v70, s22, 0                           // 00000017AEB0: CC21003C 02002D46
	v_fma_mixhi_f16 v60, v71, s22, 0                           // 00000017AEB8: CC22003C 02002D47
	v_fma_mixlo_f16 v61, v72, s22, 0                           // 00000017AEC0: CC21003D 02002D48
	v_fma_mixhi_f16 v61, v73, s22, 0                           // 00000017AEC8: CC22003D 02002D49
	ds_load_b128 v[70:73], v94 offset:8672                     // 00000017AED0: DBFC21E0 4600005E
	s_waitcnt lgkmcnt(4)                                       // 00000017AED8: BF89FC47
	v_fma_mixlo_f16 v62, v74, s22, 0                           // 00000017AEDC: CC21003E 02002D4A
	v_fma_mixhi_f16 v62, v75, s22, 0                           // 00000017AEE4: CC22003E 02002D4B
	v_fma_mixlo_f16 v63, v76, s22, 0                           // 00000017AEEC: CC21003F 02002D4C
	v_fma_mixhi_f16 v63, v77, s22, 0                           // 00000017AEF4: CC22003F 02002D4D
	ds_load_b128 v[74:77], v94 offset:8688                     // 00000017AEFC: DBFC21F0 4A00005E
	s_waitcnt lgkmcnt(4)                                       // 00000017AF04: BF89FC47
	v_fma_mixlo_f16 v64, v78, s22, 0                           // 00000017AF08: CC210040 02002D4E
	v_fma_mixhi_f16 v64, v79, s22, 0                           // 00000017AF10: CC220040 02002D4F
	v_fma_mixlo_f16 v65, v80, s22, 0                           // 00000017AF18: CC210041 02002D50
	v_fma_mixhi_f16 v65, v81, s22, 0                           // 00000017AF20: CC220041 02002D51
	s_waitcnt lgkmcnt(3)                                       // 00000017AF28: BF89FC37
	v_fma_mixlo_f16 v66, v115, s22, 0                          // 00000017AF2C: CC210042 02002D73
	ds_load_b128 v[78:81], v94 offset:17088                    // 00000017AF34: DBFC42C0 4E00005E
	v_fma_mixhi_f16 v66, v116, s22, 0                          // 00000017AF3C: CC220042 02002D74
	v_fma_mixlo_f16 v67, v117, s22, 0                          // 00000017AF44: CC210043 02002D75
	v_fma_mixhi_f16 v67, v118, s22, 0                          // 00000017AF4C: CC220043 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017AF54: BF89FC37
	v_fma_mixlo_f16 v68, v119, s22, 0                          // 00000017AF58: CC210044 02002D77
	ds_load_b128 v[115:118], v94 offset:17104                  // 00000017AF60: DBFC42D0 7300005E
	v_fma_mixhi_f16 v68, v120, s22, 0                          // 00000017AF68: CC220044 02002D78
	v_fma_mixlo_f16 v69, v121, s22, 0                          // 00000017AF70: CC210045 02002D79
	v_fma_mixhi_f16 v69, v122, s22, 0                          // 00000017AF78: CC220045 02002D7A
	ds_load_b128 v[119:122], v94 offset:17120                  // 00000017AF80: DBFC42E0 7700005E
	ds_load_b128 v[123:126], v94 offset:17136                  // 00000017AF88: DBFC42F0 7B00005E
	ds_load_b128 v[127:130], v94 offset:25536                  // 00000017AF90: DBFC63C0 7F00005E
	ds_load_b128 v[131:134], v94 offset:25552                  // 00000017AF98: DBFC63D0 8300005E
	ds_load_b128 v[135:138], v94 offset:25568                  // 00000017AFA0: DBFC63E0 8700005E
	ds_load_b128 v[139:142], v94 offset:25584                  // 00000017AFA8: DBFC63F0 8B00005E
	s_waitcnt lgkmcnt(9)                                       // 00000017AFB0: BF89FC97
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 00000017AFB4: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 00000017AFBC: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 00000017AFC4: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 00000017AFCC: CC220047 02002D49
	s_waitcnt lgkmcnt(8)                                       // 00000017AFD4: BF89FC87
	v_fma_mixlo_f16 v72, v74, s22, 0                           // 00000017AFD8: CC210048 02002D4A
	v_fma_mixhi_f16 v72, v75, s22, 0                           // 00000017AFE0: CC220048 02002D4B
	v_fma_mixlo_f16 v73, v76, s22, 0                           // 00000017AFE8: CC210049 02002D4C
	v_fma_mixhi_f16 v73, v77, s22, 0                           // 00000017AFF0: CC220049 02002D4D
	s_waitcnt lgkmcnt(7)                                       // 00000017AFF8: BF89FC77
	v_fma_mixlo_f16 v74, v78, s22, 0                           // 00000017AFFC: CC21004A 02002D4E
	v_fma_mixhi_f16 v74, v79, s22, 0                           // 00000017B004: CC22004A 02002D4F
	v_fma_mixlo_f16 v75, v80, s22, 0                           // 00000017B00C: CC21004B 02002D50
	v_fma_mixhi_f16 v75, v81, s22, 0                           // 00000017B014: CC22004B 02002D51
	s_waitcnt lgkmcnt(6)                                       // 00000017B01C: BF89FC67
	v_fma_mixlo_f16 v76, v115, s22, 0                          // 00000017B020: CC21004C 02002D73
	v_fma_mixhi_f16 v76, v116, s22, 0                          // 00000017B028: CC22004C 02002D74
	v_fma_mixlo_f16 v77, v117, s22, 0                          // 00000017B030: CC21004D 02002D75
	v_fma_mixhi_f16 v77, v118, s22, 0                          // 00000017B038: CC22004D 02002D76
	s_waitcnt lgkmcnt(5)                                       // 00000017B040: BF89FC57
	v_fma_mixlo_f16 v78, v119, s22, 0                          // 00000017B044: CC21004E 02002D77
	v_fma_mixhi_f16 v78, v120, s22, 0                          // 00000017B04C: CC22004E 02002D78
	v_fma_mixlo_f16 v79, v121, s22, 0                          // 00000017B054: CC21004F 02002D79
	v_fma_mixhi_f16 v79, v122, s22, 0                          // 00000017B05C: CC22004F 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017B064: BF89FC47
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017B068: CC210050 02002D7B
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017B070: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017B078: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017B080: CC220051 02002D7E
	s_waitcnt lgkmcnt(3)                                       // 00000017B088: BF89FC37
	v_fma_mixlo_f16 v115, v127, s22, 0                         // 00000017B08C: CC210073 02002D7F
	v_fma_mixhi_f16 v115, v128, s22, 0                         // 00000017B094: CC220073 02002D80
	v_fma_mixlo_f16 v116, v129, s22, 0                         // 00000017B09C: CC210074 02002D81
	v_fma_mixhi_f16 v116, v130, s22, 0                         // 00000017B0A4: CC220074 02002D82
	s_waitcnt lgkmcnt(2)                                       // 00000017B0AC: BF89FC27
	v_fma_mixlo_f16 v117, v131, s22, 0                         // 00000017B0B0: CC210075 02002D83
	v_fma_mixhi_f16 v117, v132, s22, 0                         // 00000017B0B8: CC220075 02002D84
	v_fma_mixlo_f16 v118, v133, s22, 0                         // 00000017B0C0: CC210076 02002D85
	v_fma_mixhi_f16 v118, v134, s22, 0                         // 00000017B0C8: CC220076 02002D86
	s_waitcnt lgkmcnt(1)                                       // 00000017B0D0: BF89FC17
	v_fma_mixlo_f16 v119, v135, s22, 0                         // 00000017B0D4: CC210077 02002D87
	v_fma_mixhi_f16 v119, v136, s22, 0                         // 00000017B0DC: CC220077 02002D88
	v_fma_mixlo_f16 v120, v137, s22, 0                         // 00000017B0E4: CC210078 02002D89
	v_fma_mixhi_f16 v120, v138, s22, 0                         // 00000017B0EC: CC220078 02002D8A
	s_waitcnt lgkmcnt(0)                                       // 00000017B0F4: BF89FC07
	v_fma_mixlo_f16 v121, v139, s22, 0                         // 00000017B0F8: CC210079 02002D8B
	v_fma_mixhi_f16 v121, v140, s22, 0                         // 00000017B100: CC220079 02002D8C
	v_fma_mixlo_f16 v122, v141, s22, 0                         // 00000017B108: CC21007A 02002D8D
	v_fma_mixhi_f16 v122, v142, s22, 0                         // 00000017B110: CC22007A 02002D8E
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000017B118: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[66:73], v[34:41]// 00000017B120: CC404022 1C8A8532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[74:81], v[26:33]// 00000017B128: CC40401A 1C6A9532
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017B130: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[115:122], v[18:25]// 00000017B134: CC404012 1C4AE732
	s_and_saveexec_b32 s11, s0                                 // 00000017B13C: BE8B2000
	s_cbranch_execnz 1990                                      // 00000017B140: BFA607C6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e5c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B144: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:272          // 00000017B148: DC5E0110 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B150: BE8B2000
	s_cbranch_execnz 1996                                      // 00000017B154: BFA607CC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e88>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B158: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:288          // 00000017B15C: DC5E0120 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B164: BE8B2000
	s_cbranch_execnz 2002                                      // 00000017B168: BFA607D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5eb4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B16C: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:304          // 00000017B170: DC5E0130 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B178: BE8B2000
	s_cbranch_execz 6                                          // 00000017B17C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f98>
	s_waitcnt vmcnt(0)                                         // 00000017B180: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017B184: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B188: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017B18C: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017B190: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017B194: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B198: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:320          // 00000017B19C: DC5E0140 327C0007
	s_waitcnt vmcnt(4)                                         // 00000017B1A4: BF8913F7
	v_fma_mixlo_f16 v66, v3, s22, 0                            // 00000017B1A8: CC210042 02002D03
	ds_load_b128 v[74:77], v94 offset:256                      // 00000017B1B0: DBFC0100 4A00005E
	v_fma_mixhi_f16 v66, v4, s22, 0                            // 00000017B1B8: CC220042 02002D04
	v_fma_mixlo_f16 v67, v5, s22, 0                            // 00000017B1C0: CC210043 02002D05
	v_fma_mixhi_f16 v67, v6, s22, 0                            // 00000017B1C8: CC220043 02002D06
	ds_load_b128 v[3:6], v94 offset:272                        // 00000017B1D0: DBFC0110 0300005E
	ds_load_b128 v[78:81], v94 offset:288                      // 00000017B1D8: DBFC0120 4E00005E
	ds_load_b128 v[115:118], v94 offset:304                    // 00000017B1E0: DBFC0130 7300005E
	s_waitcnt vmcnt(1)                                         // 00000017B1E8: BF8907F7
	v_fma_mixlo_f16 v72, v62, s22, 0                           // 00000017B1EC: CC210048 02002D3E
	v_fma_mixhi_f16 v72, v63, s22, 0                           // 00000017B1F4: CC220048 02002D3F
	v_fma_mixlo_f16 v73, v64, s22, 0                           // 00000017B1FC: CC210049 02002D40
	v_fma_mixhi_f16 v73, v65, s22, 0                           // 00000017B204: CC220049 02002D41
	ds_load_b128 v[62:65], v94 offset:8704                     // 00000017B20C: DBFC2200 3E00005E
	ds_load_b128 v[119:122], v94 offset:8720                   // 00000017B214: DBFC2210 7700005E
	v_fma_mixlo_f16 v68, v54, s22, 0                           // 00000017B21C: CC210044 02002D36
	v_fma_mixlo_f16 v69, v56, s22, 0                           // 00000017B224: CC210045 02002D38
	v_fma_mixhi_f16 v69, v57, s22, 0                           // 00000017B22C: CC220045 02002D39
	v_fma_mixlo_f16 v71, v60, s22, 0                           // 00000017B234: CC210047 02002D3C
	v_fma_mixhi_f16 v71, v61, s22, 0                           // 00000017B23C: CC220047 02002D3D
	ds_load_b128 v[123:126], v94 offset:8752                   // 00000017B244: DBFC2230 7B00005E
	v_fma_mixhi_f16 v68, v55, s22, 0                           // 00000017B24C: CC220044 02002D37
	s_waitcnt lgkmcnt(6)                                       // 00000017B254: BF89FC67
	v_fma_mixlo_f16 v54, v74, s22, 0                           // 00000017B258: CC210036 02002D4A
	v_fma_mixhi_f16 v54, v75, s22, 0                           // 00000017B260: CC220036 02002D4B
	v_fma_mixlo_f16 v70, v58, s22, 0                           // 00000017B268: CC210046 02002D3A
	v_fma_mixhi_f16 v70, v59, s22, 0                           // 00000017B270: CC220046 02002D3B
	s_waitcnt lgkmcnt(5)                                       // 00000017B278: BF89FC57
	v_fma_mixlo_f16 v56, v3, s22, 0                            // 00000017B27C: CC210038 02002D03
	v_fma_mixhi_f16 v56, v4, s22, 0                            // 00000017B284: CC220038 02002D04
	v_fma_mixlo_f16 v57, v5, s22, 0                            // 00000017B28C: CC210039 02002D05
	v_fma_mixhi_f16 v57, v6, s22, 0                            // 00000017B294: CC220039 02002D06
	ds_load_b128 v[3:6], v94 offset:8736                       // 00000017B29C: DBFC2220 0300005E
	s_waitcnt lgkmcnt(4)                                       // 00000017B2A4: BF89FC47
	v_fma_mixlo_f16 v60, v115, s22, 0                          // 00000017B2A8: CC21003C 02002D73
	v_fma_mixhi_f16 v60, v116, s22, 0                          // 00000017B2B0: CC22003C 02002D74
	v_fma_mixlo_f16 v61, v117, s22, 0                          // 00000017B2B8: CC21003D 02002D75
	v_fma_mixhi_f16 v61, v118, s22, 0                          // 00000017B2C0: CC22003D 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017B2C8: BF89FC37
	v_fma_mixlo_f16 v74, v62, s22, 0                           // 00000017B2CC: CC21004A 02002D3E
	ds_load_b128 v[115:118], v94 offset:17152                  // 00000017B2D4: DBFC4300 7300005E
	v_fma_mixhi_f16 v74, v63, s22, 0                           // 00000017B2DC: CC22004A 02002D3F
	v_fma_mixlo_f16 v75, v64, s22, 0                           // 00000017B2E4: CC21004B 02002D40
	v_fma_mixhi_f16 v75, v65, s22, 0                           // 00000017B2EC: CC22004B 02002D41
	ds_load_b128 v[62:65], v94 offset:17168                    // 00000017B2F4: DBFC4310 3E00005E
	v_fma_mixlo_f16 v55, v76, s22, 0                           // 00000017B2FC: CC210037 02002D4C
	v_fma_mixhi_f16 v55, v77, s22, 0                           // 00000017B304: CC220037 02002D4D
	v_fma_mixlo_f16 v58, v78, s22, 0                           // 00000017B30C: CC21003A 02002D4E
	v_fma_mixhi_f16 v58, v79, s22, 0                           // 00000017B314: CC22003A 02002D4F
	v_fma_mixlo_f16 v59, v80, s22, 0                           // 00000017B31C: CC21003B 02002D50
	v_fma_mixhi_f16 v59, v81, s22, 0                           // 00000017B324: CC22003B 02002D51
	s_waitcnt lgkmcnt(4)                                       // 00000017B32C: BF89FC47
	v_fma_mixlo_f16 v76, v119, s22, 0                          // 00000017B330: CC21004C 02002D77
	v_fma_mixhi_f16 v76, v120, s22, 0                          // 00000017B338: CC22004C 02002D78
	v_fma_mixlo_f16 v77, v121, s22, 0                          // 00000017B340: CC21004D 02002D79
	v_fma_mixhi_f16 v77, v122, s22, 0                          // 00000017B348: CC22004D 02002D7A
	s_waitcnt lgkmcnt(2)                                       // 00000017B350: BF89FC27
	v_fma_mixlo_f16 v78, v3, s22, 0                            // 00000017B354: CC21004E 02002D03
	ds_load_b128 v[119:122], v94 offset:17184                  // 00000017B35C: DBFC4320 7700005E
	v_fma_mixhi_f16 v78, v4, s22, 0                            // 00000017B364: CC22004E 02002D04
	v_fma_mixlo_f16 v79, v5, s22, 0                            // 00000017B36C: CC21004F 02002D05
	v_fma_mixhi_f16 v79, v6, s22, 0                            // 00000017B374: CC22004F 02002D06
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017B37C: CC210050 02002D7B
	ds_load_b128 v[3:6], v94 offset:17200                      // 00000017B384: DBFC4330 0300005E
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017B38C: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017B394: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017B39C: CC220051 02002D7E
	ds_load_b128 v[123:126], v94 offset:25600                  // 00000017B3A4: DBFC6400 7B00005E
	ds_load_b128 v[127:130], v94 offset:25616                  // 00000017B3AC: DBFC6410 7F00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017B3B4: BF89FC57
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 00000017B3B8: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 00000017B3C0: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 00000017B3C8: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 00000017B3D0: CC220074 02002D76
	s_waitcnt lgkmcnt(4)                                       // 00000017B3D8: BF89FC47
	v_fma_mixlo_f16 v117, v62, s22, 0                          // 00000017B3DC: CC210075 02002D3E
	v_fma_mixhi_f16 v117, v63, s22, 0                          // 00000017B3E4: CC220075 02002D3F
	ds_load_b128 v[131:134], v94 offset:25632                  // 00000017B3EC: DBFC6420 8300005E
	v_fma_mixlo_f16 v118, v64, s22, 0                          // 00000017B3F4: CC210076 02002D40
	v_fma_mixhi_f16 v118, v65, s22, 0                          // 00000017B3FC: CC220076 02002D41
	ds_load_b128 v[62:65], v94 offset:25648                    // 00000017B404: DBFC6430 3E00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017B40C: BF89FC57
	v_fma_mixlo_f16 v119, v119, s22, 0                         // 00000017B410: CC210077 02002D77
	v_fma_mixhi_f16 v119, v120, s22, 0                         // 00000017B418: CC220077 02002D78
	v_fma_mixlo_f16 v120, v121, s22, 0                         // 00000017B420: CC210078 02002D79
	v_fma_mixhi_f16 v120, v122, s22, 0                         // 00000017B428: CC220078 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017B430: BF89FC47
	v_fma_mixlo_f16 v121, v3, s22, 0                           // 00000017B434: CC210079 02002D03
	v_fma_mixhi_f16 v121, v4, s22, 0                           // 00000017B43C: CC220079 02002D04
	v_fma_mixlo_f16 v122, v5, s22, 0                           // 00000017B444: CC21007A 02002D05
	v_fma_mixhi_f16 v122, v6, s22, 0                           // 00000017B44C: CC22007A 02002D06
	s_waitcnt lgkmcnt(3)                                       // 00000017B454: BF89FC37
	v_fma_mixlo_f16 v123, v123, s22, 0                         // 00000017B458: CC21007B 02002D7B
	v_fma_mixhi_f16 v123, v124, s22, 0                         // 00000017B460: CC22007B 02002D7C
	v_fma_mixlo_f16 v124, v125, s22, 0                         // 00000017B468: CC21007C 02002D7D
	v_fma_mixhi_f16 v124, v126, s22, 0                         // 00000017B470: CC22007C 02002D7E
	s_waitcnt lgkmcnt(2)                                       // 00000017B478: BF89FC27
	v_fma_mixlo_f16 v125, v127, s22, 0                         // 00000017B47C: CC21007D 02002D7F
	v_fma_mixhi_f16 v125, v128, s22, 0                         // 00000017B484: CC22007D 02002D80
	v_fma_mixlo_f16 v126, v129, s22, 0                         // 00000017B48C: CC21007E 02002D81
	v_fma_mixhi_f16 v126, v130, s22, 0                         // 00000017B494: CC22007E 02002D82
	s_waitcnt lgkmcnt(1)                                       // 00000017B49C: BF89FC17
	v_fma_mixlo_f16 v127, v131, s22, 0                         // 00000017B4A0: CC21007F 02002D83
	v_fma_mixhi_f16 v127, v132, s22, 0                         // 00000017B4A8: CC22007F 02002D84
	v_fma_mixlo_f16 v128, v133, s22, 0                         // 00000017B4B0: CC210080 02002D85
	v_fma_mixhi_f16 v128, v134, s22, 0                         // 00000017B4B8: CC220080 02002D86
	s_waitcnt lgkmcnt(0)                                       // 00000017B4C0: BF89FC07
	v_fma_mixlo_f16 v129, v62, s22, 0                          // 00000017B4C4: CC210081 02002D3E
	v_fma_mixhi_f16 v129, v63, s22, 0                          // 00000017B4CC: CC220081 02002D3F
	v_fma_mixlo_f16 v130, v64, s22, 0                          // 00000017B4D4: CC210082 02002D40
	v_fma_mixhi_f16 v130, v65, s22, 0                          // 00000017B4DC: CC220082 02002D41
	v_wmma_f32_16x16x16_f16 v[42:49], v[66:73], v[54:61], v[42:49]// 00000017B4E4: CC40402A 1CAA6D42
	v_wmma_f32_16x16x16_f16 v[34:41], v[66:73], v[74:81], v[34:41]// 00000017B4EC: CC404022 1C8A9542
	v_wmma_f32_16x16x16_f16 v[26:33], v[66:73], v[115:122], v[26:33]// 00000017B4F4: CC40401A 1C6AE742
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017B4FC: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[66:73], v[123:130], v[18:25]// 00000017B500: CC404012 1C4AF742
	s_and_saveexec_b32 s11, s0                                 // 00000017B508: BE8B2000
	s_cbranch_execnz 1781                                      // 00000017B50C: BFA606F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ee4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B510: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:336          // 00000017B514: DC5E0150 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B51C: BE8B2000
	s_cbranch_execnz 1787                                      // 00000017B520: BFA606FB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f10>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B524: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:352          // 00000017B528: DC5E0160 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B530: BE8B2000
	s_cbranch_execnz 1793                                      // 00000017B534: BFA60701 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f3c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B538: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:368          // 00000017B53C: DC5E0170 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B544: BE8B2000
	s_cbranch_execz 6                                          // 00000017B548: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4364>
	s_waitcnt vmcnt(0)                                         // 00000017B54C: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017B550: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B554: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017B558: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017B55C: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017B560: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B564: 8C7E0B7E
	global_load_b128 v[3:6], v[7:8], off offset:384            // 00000017B568: DC5E0180 037C0007
	ds_load_b128 v[66:69], v94 offset:320                      // 00000017B570: DBFC0140 4200005E
	ds_load_b128 v[70:73], v94 offset:336                      // 00000017B578: DBFC0150 4600005E
	ds_load_b128 v[74:77], v94 offset:352                      // 00000017B580: DBFC0160 4A00005E
	ds_load_b128 v[78:81], v94 offset:368                      // 00000017B588: DBFC0170 4E00005E
	ds_load_b128 v[115:118], v94 offset:8768                   // 00000017B590: DBFC2240 7300005E
	ds_load_b128 v[119:122], v94 offset:8784                   // 00000017B598: DBFC2250 7700005E
	s_waitcnt vmcnt(4)                                         // 00000017B5A0: BF8913F7
	v_fma_mixlo_f16 v50, v50, s22, 0                           // 00000017B5A4: CC210032 02002D32
	v_fma_mixhi_f16 v50, v51, s22, 0                           // 00000017B5AC: CC220032 02002D33
	v_fma_mixlo_f16 v51, v52, s22, 0                           // 00000017B5B4: CC210033 02002D34
	v_fma_mixhi_f16 v51, v53, s22, 0                           // 00000017B5BC: CC220033 02002D35
	s_waitcnt vmcnt(3)                                         // 00000017B5C4: BF890FF7
	v_fma_mixlo_f16 v52, v54, s22, 0                           // 00000017B5C8: CC210034 02002D36
	v_fma_mixhi_f16 v52, v55, s22, 0                           // 00000017B5D0: CC220034 02002D37
	v_fma_mixlo_f16 v53, v56, s22, 0                           // 00000017B5D8: CC210035 02002D38
	v_fma_mixhi_f16 v53, v57, s22, 0                           // 00000017B5E0: CC220035 02002D39
	s_waitcnt vmcnt(2)                                         // 00000017B5E8: BF890BF7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 00000017B5EC: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 00000017B5F4: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 00000017B5FC: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 00000017B604: CC220037 02002D3D
	s_waitcnt vmcnt(1)                                         // 00000017B60C: BF8907F7
	v_fma_mixlo_f16 v56, v62, s22, 0                           // 00000017B610: CC210038 02002D3E
	v_fma_mixhi_f16 v56, v63, s22, 0                           // 00000017B618: CC220038 02002D3F
	v_fma_mixlo_f16 v57, v64, s22, 0                           // 00000017B620: CC210039 02002D40
	v_fma_mixhi_f16 v57, v65, s22, 0                           // 00000017B628: CC220039 02002D41
	s_waitcnt lgkmcnt(5)                                       // 00000017B630: BF89FC57
	v_fma_mixlo_f16 v58, v66, s22, 0                           // 00000017B634: CC21003A 02002D42
	v_fma_mixhi_f16 v58, v67, s22, 0                           // 00000017B63C: CC22003A 02002D43
	v_fma_mixlo_f16 v59, v68, s22, 0                           // 00000017B644: CC21003B 02002D44
	v_fma_mixhi_f16 v59, v69, s22, 0                           // 00000017B64C: CC22003B 02002D45
	s_waitcnt lgkmcnt(4)                                       // 00000017B654: BF89FC47
	v_fma_mixlo_f16 v60, v70, s22, 0                           // 00000017B658: CC21003C 02002D46
	v_fma_mixhi_f16 v60, v71, s22, 0                           // 00000017B660: CC22003C 02002D47
	v_fma_mixlo_f16 v61, v72, s22, 0                           // 00000017B668: CC21003D 02002D48
	v_fma_mixhi_f16 v61, v73, s22, 0                           // 00000017B670: CC22003D 02002D49
	ds_load_b128 v[70:73], v94 offset:8800                     // 00000017B678: DBFC2260 4600005E
	s_waitcnt lgkmcnt(4)                                       // 00000017B680: BF89FC47
	v_fma_mixlo_f16 v62, v74, s22, 0                           // 00000017B684: CC21003E 02002D4A
	v_fma_mixhi_f16 v62, v75, s22, 0                           // 00000017B68C: CC22003E 02002D4B
	v_fma_mixlo_f16 v63, v76, s22, 0                           // 00000017B694: CC21003F 02002D4C
	v_fma_mixhi_f16 v63, v77, s22, 0                           // 00000017B69C: CC22003F 02002D4D
	ds_load_b128 v[74:77], v94 offset:8816                     // 00000017B6A4: DBFC2270 4A00005E
	s_waitcnt lgkmcnt(4)                                       // 00000017B6AC: BF89FC47
	v_fma_mixlo_f16 v64, v78, s22, 0                           // 00000017B6B0: CC210040 02002D4E
	v_fma_mixhi_f16 v64, v79, s22, 0                           // 00000017B6B8: CC220040 02002D4F
	v_fma_mixlo_f16 v65, v80, s22, 0                           // 00000017B6C0: CC210041 02002D50
	v_fma_mixhi_f16 v65, v81, s22, 0                           // 00000017B6C8: CC220041 02002D51
	s_waitcnt lgkmcnt(3)                                       // 00000017B6D0: BF89FC37
	v_fma_mixlo_f16 v66, v115, s22, 0                          // 00000017B6D4: CC210042 02002D73
	ds_load_b128 v[78:81], v94 offset:17216                    // 00000017B6DC: DBFC4340 4E00005E
	v_fma_mixhi_f16 v66, v116, s22, 0                          // 00000017B6E4: CC220042 02002D74
	v_fma_mixlo_f16 v67, v117, s22, 0                          // 00000017B6EC: CC210043 02002D75
	v_fma_mixhi_f16 v67, v118, s22, 0                          // 00000017B6F4: CC220043 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017B6FC: BF89FC37
	v_fma_mixlo_f16 v68, v119, s22, 0                          // 00000017B700: CC210044 02002D77
	ds_load_b128 v[115:118], v94 offset:17232                  // 00000017B708: DBFC4350 7300005E
	v_fma_mixhi_f16 v68, v120, s22, 0                          // 00000017B710: CC220044 02002D78
	v_fma_mixlo_f16 v69, v121, s22, 0                          // 00000017B718: CC210045 02002D79
	v_fma_mixhi_f16 v69, v122, s22, 0                          // 00000017B720: CC220045 02002D7A
	ds_load_b128 v[119:122], v94 offset:17248                  // 00000017B728: DBFC4360 7700005E
	ds_load_b128 v[123:126], v94 offset:17264                  // 00000017B730: DBFC4370 7B00005E
	ds_load_b128 v[127:130], v94 offset:25664                  // 00000017B738: DBFC6440 7F00005E
	ds_load_b128 v[131:134], v94 offset:25680                  // 00000017B740: DBFC6450 8300005E
	ds_load_b128 v[135:138], v94 offset:25696                  // 00000017B748: DBFC6460 8700005E
	ds_load_b128 v[139:142], v94 offset:25712                  // 00000017B750: DBFC6470 8B00005E
	s_waitcnt lgkmcnt(9)                                       // 00000017B758: BF89FC97
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 00000017B75C: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 00000017B764: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 00000017B76C: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 00000017B774: CC220047 02002D49
	s_waitcnt lgkmcnt(8)                                       // 00000017B77C: BF89FC87
	v_fma_mixlo_f16 v72, v74, s22, 0                           // 00000017B780: CC210048 02002D4A
	v_fma_mixhi_f16 v72, v75, s22, 0                           // 00000017B788: CC220048 02002D4B
	v_fma_mixlo_f16 v73, v76, s22, 0                           // 00000017B790: CC210049 02002D4C
	v_fma_mixhi_f16 v73, v77, s22, 0                           // 00000017B798: CC220049 02002D4D
	s_waitcnt lgkmcnt(7)                                       // 00000017B7A0: BF89FC77
	v_fma_mixlo_f16 v74, v78, s22, 0                           // 00000017B7A4: CC21004A 02002D4E
	v_fma_mixhi_f16 v74, v79, s22, 0                           // 00000017B7AC: CC22004A 02002D4F
	v_fma_mixlo_f16 v75, v80, s22, 0                           // 00000017B7B4: CC21004B 02002D50
	v_fma_mixhi_f16 v75, v81, s22, 0                           // 00000017B7BC: CC22004B 02002D51
	s_waitcnt lgkmcnt(6)                                       // 00000017B7C4: BF89FC67
	v_fma_mixlo_f16 v76, v115, s22, 0                          // 00000017B7C8: CC21004C 02002D73
	v_fma_mixhi_f16 v76, v116, s22, 0                          // 00000017B7D0: CC22004C 02002D74
	v_fma_mixlo_f16 v77, v117, s22, 0                          // 00000017B7D8: CC21004D 02002D75
	v_fma_mixhi_f16 v77, v118, s22, 0                          // 00000017B7E0: CC22004D 02002D76
	s_waitcnt lgkmcnt(5)                                       // 00000017B7E8: BF89FC57
	v_fma_mixlo_f16 v78, v119, s22, 0                          // 00000017B7EC: CC21004E 02002D77
	v_fma_mixhi_f16 v78, v120, s22, 0                          // 00000017B7F4: CC22004E 02002D78
	v_fma_mixlo_f16 v79, v121, s22, 0                          // 00000017B7FC: CC21004F 02002D79
	v_fma_mixhi_f16 v79, v122, s22, 0                          // 00000017B804: CC22004F 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017B80C: BF89FC47
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017B810: CC210050 02002D7B
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017B818: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017B820: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017B828: CC220051 02002D7E
	s_waitcnt lgkmcnt(3)                                       // 00000017B830: BF89FC37
	v_fma_mixlo_f16 v115, v127, s22, 0                         // 00000017B834: CC210073 02002D7F
	v_fma_mixhi_f16 v115, v128, s22, 0                         // 00000017B83C: CC220073 02002D80
	v_fma_mixlo_f16 v116, v129, s22, 0                         // 00000017B844: CC210074 02002D81
	v_fma_mixhi_f16 v116, v130, s22, 0                         // 00000017B84C: CC220074 02002D82
	s_waitcnt lgkmcnt(2)                                       // 00000017B854: BF89FC27
	v_fma_mixlo_f16 v117, v131, s22, 0                         // 00000017B858: CC210075 02002D83
	v_fma_mixhi_f16 v117, v132, s22, 0                         // 00000017B860: CC220075 02002D84
	v_fma_mixlo_f16 v118, v133, s22, 0                         // 00000017B868: CC210076 02002D85
	v_fma_mixhi_f16 v118, v134, s22, 0                         // 00000017B870: CC220076 02002D86
	s_waitcnt lgkmcnt(1)                                       // 00000017B878: BF89FC17
	v_fma_mixlo_f16 v119, v135, s22, 0                         // 00000017B87C: CC210077 02002D87
	v_fma_mixhi_f16 v119, v136, s22, 0                         // 00000017B884: CC220077 02002D88
	v_fma_mixlo_f16 v120, v137, s22, 0                         // 00000017B88C: CC210078 02002D89
	v_fma_mixhi_f16 v120, v138, s22, 0                         // 00000017B894: CC220078 02002D8A
	s_waitcnt lgkmcnt(0)                                       // 00000017B89C: BF89FC07
	v_fma_mixlo_f16 v121, v139, s22, 0                         // 00000017B8A0: CC210079 02002D8B
	v_fma_mixhi_f16 v121, v140, s22, 0                         // 00000017B8A8: CC220079 02002D8C
	v_fma_mixlo_f16 v122, v141, s22, 0                         // 00000017B8B0: CC21007A 02002D8D
	v_fma_mixhi_f16 v122, v142, s22, 0                         // 00000017B8B8: CC22007A 02002D8E
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000017B8C0: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[66:73], v[34:41]// 00000017B8C8: CC404022 1C8A8532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[74:81], v[26:33]// 00000017B8D0: CC40401A 1C6A9532
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017B8D8: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[115:122], v[18:25]// 00000017B8DC: CC404012 1C4AE732
	s_and_saveexec_b32 s11, s0                                 // 00000017B8E4: BE8B2000
	s_cbranch_execnz 1568                                      // 00000017B8E8: BFA60620 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f6c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B8EC: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:400          // 00000017B8F0: DC5E0190 327C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B8F8: BE8B2000
	s_cbranch_execnz 1574                                      // 00000017B8FC: BFA60626 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f98>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B900: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:416          // 00000017B904: DC5E01A0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B90C: BE8B2000
	s_cbranch_execnz 1580                                      // 00000017B910: BFA6062C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fc4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B914: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:432          // 00000017B918: DC5E01B0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017B920: BE8B2000
	s_cbranch_execz 6                                          // 00000017B924: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4740>
	s_waitcnt vmcnt(0)                                         // 00000017B928: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017B92C: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B930: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017B934: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017B938: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017B93C: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017B940: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:448          // 00000017B944: DC5E01C0 3E7C0007
	s_waitcnt vmcnt(4)                                         // 00000017B94C: BF8913F7
	v_fma_mixlo_f16 v66, v3, s22, 0                            // 00000017B950: CC210042 02002D03
	ds_load_b128 v[74:77], v94 offset:384                      // 00000017B958: DBFC0180 4A00005E
	v_fma_mixhi_f16 v66, v4, s22, 0                            // 00000017B960: CC220042 02002D04
	v_fma_mixlo_f16 v67, v5, s22, 0                            // 00000017B968: CC210043 02002D05
	v_fma_mixhi_f16 v67, v6, s22, 0                            // 00000017B970: CC220043 02002D06
	ds_load_b128 v[3:6], v94 offset:400                        // 00000017B978: DBFC0190 0300005E
	ds_load_b128 v[78:81], v94 offset:416                      // 00000017B980: DBFC01A0 4E00005E
	ds_load_b128 v[115:118], v94 offset:432                    // 00000017B988: DBFC01B0 7300005E
	s_waitcnt vmcnt(1)                                         // 00000017B990: BF8907F7
	v_fma_mixlo_f16 v72, v58, s22, 0                           // 00000017B994: CC210048 02002D3A
	v_fma_mixhi_f16 v72, v59, s22, 0                           // 00000017B99C: CC220048 02002D3B
	v_fma_mixlo_f16 v73, v60, s22, 0                           // 00000017B9A4: CC210049 02002D3C
	v_fma_mixhi_f16 v73, v61, s22, 0                           // 00000017B9AC: CC220049 02002D3D
	ds_load_b128 v[58:61], v94 offset:8832                     // 00000017B9B4: DBFC2280 3A00005E
	ds_load_b128 v[119:122], v94 offset:8848                   // 00000017B9BC: DBFC2290 7700005E
	v_fma_mixlo_f16 v68, v50, s22, 0                           // 00000017B9C4: CC210044 02002D32
	v_fma_mixlo_f16 v69, v52, s22, 0                           // 00000017B9CC: CC210045 02002D34
	v_fma_mixhi_f16 v69, v53, s22, 0                           // 00000017B9D4: CC220045 02002D35
	v_fma_mixlo_f16 v71, v56, s22, 0                           // 00000017B9DC: CC210047 02002D38
	v_fma_mixhi_f16 v71, v57, s22, 0                           // 00000017B9E4: CC220047 02002D39
	ds_load_b128 v[123:126], v94 offset:8880                   // 00000017B9EC: DBFC22B0 7B00005E
	v_fma_mixhi_f16 v68, v51, s22, 0                           // 00000017B9F4: CC220044 02002D33
	s_waitcnt lgkmcnt(6)                                       // 00000017B9FC: BF89FC67
	v_fma_mixlo_f16 v50, v74, s22, 0                           // 00000017BA00: CC210032 02002D4A
	v_fma_mixhi_f16 v50, v75, s22, 0                           // 00000017BA08: CC220032 02002D4B
	v_fma_mixlo_f16 v70, v54, s22, 0                           // 00000017BA10: CC210046 02002D36
	v_fma_mixhi_f16 v70, v55, s22, 0                           // 00000017BA18: CC220046 02002D37
	s_waitcnt lgkmcnt(5)                                       // 00000017BA20: BF89FC57
	v_fma_mixlo_f16 v52, v3, s22, 0                            // 00000017BA24: CC210034 02002D03
	v_fma_mixhi_f16 v52, v4, s22, 0                            // 00000017BA2C: CC220034 02002D04
	v_fma_mixlo_f16 v53, v5, s22, 0                            // 00000017BA34: CC210035 02002D05
	v_fma_mixhi_f16 v53, v6, s22, 0                            // 00000017BA3C: CC220035 02002D06
	ds_load_b128 v[3:6], v94 offset:8864                       // 00000017BA44: DBFC22A0 0300005E
	s_waitcnt lgkmcnt(4)                                       // 00000017BA4C: BF89FC47
	v_fma_mixlo_f16 v56, v115, s22, 0                          // 00000017BA50: CC210038 02002D73
	v_fma_mixhi_f16 v56, v116, s22, 0                          // 00000017BA58: CC220038 02002D74
	v_fma_mixlo_f16 v57, v117, s22, 0                          // 00000017BA60: CC210039 02002D75
	v_fma_mixhi_f16 v57, v118, s22, 0                          // 00000017BA68: CC220039 02002D76
	s_waitcnt lgkmcnt(3)                                       // 00000017BA70: BF89FC37
	v_fma_mixlo_f16 v74, v58, s22, 0                           // 00000017BA74: CC21004A 02002D3A
	ds_load_b128 v[115:118], v94 offset:17280                  // 00000017BA7C: DBFC4380 7300005E
	v_fma_mixhi_f16 v74, v59, s22, 0                           // 00000017BA84: CC22004A 02002D3B
	v_fma_mixlo_f16 v75, v60, s22, 0                           // 00000017BA8C: CC21004B 02002D3C
	v_fma_mixhi_f16 v75, v61, s22, 0                           // 00000017BA94: CC22004B 02002D3D
	ds_load_b128 v[58:61], v94 offset:17296                    // 00000017BA9C: DBFC4390 3A00005E
	v_fma_mixlo_f16 v51, v76, s22, 0                           // 00000017BAA4: CC210033 02002D4C
	v_fma_mixhi_f16 v51, v77, s22, 0                           // 00000017BAAC: CC220033 02002D4D
	v_fma_mixlo_f16 v54, v78, s22, 0                           // 00000017BAB4: CC210036 02002D4E
	v_fma_mixhi_f16 v54, v79, s22, 0                           // 00000017BABC: CC220036 02002D4F
	v_fma_mixlo_f16 v55, v80, s22, 0                           // 00000017BAC4: CC210037 02002D50
	v_fma_mixhi_f16 v55, v81, s22, 0                           // 00000017BACC: CC220037 02002D51
	s_waitcnt lgkmcnt(4)                                       // 00000017BAD4: BF89FC47
	v_fma_mixlo_f16 v76, v119, s22, 0                          // 00000017BAD8: CC21004C 02002D77
	v_fma_mixhi_f16 v76, v120, s22, 0                          // 00000017BAE0: CC22004C 02002D78
	v_fma_mixlo_f16 v77, v121, s22, 0                          // 00000017BAE8: CC21004D 02002D79
	v_fma_mixhi_f16 v77, v122, s22, 0                          // 00000017BAF0: CC22004D 02002D7A
	s_waitcnt lgkmcnt(2)                                       // 00000017BAF8: BF89FC27
	v_fma_mixlo_f16 v78, v3, s22, 0                            // 00000017BAFC: CC21004E 02002D03
	ds_load_b128 v[119:122], v94 offset:17312                  // 00000017BB04: DBFC43A0 7700005E
	v_fma_mixhi_f16 v78, v4, s22, 0                            // 00000017BB0C: CC22004E 02002D04
	v_fma_mixlo_f16 v79, v5, s22, 0                            // 00000017BB14: CC21004F 02002D05
	v_fma_mixhi_f16 v79, v6, s22, 0                            // 00000017BB1C: CC22004F 02002D06
	v_fma_mixlo_f16 v80, v123, s22, 0                          // 00000017BB24: CC210050 02002D7B
	ds_load_b128 v[3:6], v94 offset:17328                      // 00000017BB2C: DBFC43B0 0300005E
	v_fma_mixhi_f16 v80, v124, s22, 0                          // 00000017BB34: CC220050 02002D7C
	v_fma_mixlo_f16 v81, v125, s22, 0                          // 00000017BB3C: CC210051 02002D7D
	v_fma_mixhi_f16 v81, v126, s22, 0                          // 00000017BB44: CC220051 02002D7E
	ds_load_b128 v[123:126], v94 offset:25728                  // 00000017BB4C: DBFC6480 7B00005E
	ds_load_b128 v[127:130], v94 offset:25744                  // 00000017BB54: DBFC6490 7F00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017BB5C: BF89FC57
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 00000017BB60: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 00000017BB68: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 00000017BB70: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 00000017BB78: CC220074 02002D76
	s_waitcnt lgkmcnt(4)                                       // 00000017BB80: BF89FC47
	v_fma_mixlo_f16 v117, v58, s22, 0                          // 00000017BB84: CC210075 02002D3A
	v_fma_mixhi_f16 v117, v59, s22, 0                          // 00000017BB8C: CC220075 02002D3B
	ds_load_b128 v[131:134], v94 offset:25760                  // 00000017BB94: DBFC64A0 8300005E
	v_fma_mixlo_f16 v118, v60, s22, 0                          // 00000017BB9C: CC210076 02002D3C
	v_fma_mixhi_f16 v118, v61, s22, 0                          // 00000017BBA4: CC220076 02002D3D
	ds_load_b128 v[58:61], v94 offset:25776                    // 00000017BBAC: DBFC64B0 3A00005E
	s_waitcnt lgkmcnt(5)                                       // 00000017BBB4: BF89FC57
	v_fma_mixlo_f16 v119, v119, s22, 0                         // 00000017BBB8: CC210077 02002D77
	v_fma_mixhi_f16 v119, v120, s22, 0                         // 00000017BBC0: CC220077 02002D78
	v_fma_mixlo_f16 v120, v121, s22, 0                         // 00000017BBC8: CC210078 02002D79
	v_fma_mixhi_f16 v120, v122, s22, 0                         // 00000017BBD0: CC220078 02002D7A
	s_waitcnt lgkmcnt(4)                                       // 00000017BBD8: BF89FC47
	v_fma_mixlo_f16 v121, v3, s22, 0                           // 00000017BBDC: CC210079 02002D03
	v_fma_mixhi_f16 v121, v4, s22, 0                           // 00000017BBE4: CC220079 02002D04
	v_fma_mixlo_f16 v122, v5, s22, 0                           // 00000017BBEC: CC21007A 02002D05
	v_fma_mixhi_f16 v122, v6, s22, 0                           // 00000017BBF4: CC22007A 02002D06
	s_waitcnt lgkmcnt(3)                                       // 00000017BBFC: BF89FC37
	v_fma_mixlo_f16 v123, v123, s22, 0                         // 00000017BC00: CC21007B 02002D7B
	v_fma_mixhi_f16 v123, v124, s22, 0                         // 00000017BC08: CC22007B 02002D7C
	v_fma_mixlo_f16 v124, v125, s22, 0                         // 00000017BC10: CC21007C 02002D7D
	v_fma_mixhi_f16 v124, v126, s22, 0                         // 00000017BC18: CC22007C 02002D7E
	s_waitcnt lgkmcnt(2)                                       // 00000017BC20: BF89FC27
	v_fma_mixlo_f16 v125, v127, s22, 0                         // 00000017BC24: CC21007D 02002D7F
	v_fma_mixhi_f16 v125, v128, s22, 0                         // 00000017BC2C: CC22007D 02002D80
	v_fma_mixlo_f16 v126, v129, s22, 0                         // 00000017BC34: CC21007E 02002D81
	v_fma_mixhi_f16 v126, v130, s22, 0                         // 00000017BC3C: CC22007E 02002D82
	s_waitcnt lgkmcnt(1)                                       // 00000017BC44: BF89FC17
	v_fma_mixlo_f16 v127, v131, s22, 0                         // 00000017BC48: CC21007F 02002D83
	v_fma_mixhi_f16 v127, v132, s22, 0                         // 00000017BC50: CC22007F 02002D84
	v_fma_mixlo_f16 v128, v133, s22, 0                         // 00000017BC58: CC210080 02002D85
	v_fma_mixhi_f16 v128, v134, s22, 0                         // 00000017BC60: CC220080 02002D86
	s_waitcnt lgkmcnt(0)                                       // 00000017BC68: BF89FC07
	v_fma_mixlo_f16 v129, v58, s22, 0                          // 00000017BC6C: CC210081 02002D3A
	v_fma_mixhi_f16 v129, v59, s22, 0                          // 00000017BC74: CC220081 02002D3B
	v_fma_mixlo_f16 v130, v60, s22, 0                          // 00000017BC7C: CC210082 02002D3C
	v_fma_mixhi_f16 v130, v61, s22, 0                          // 00000017BC84: CC220082 02002D3D
	v_wmma_f32_16x16x16_f16 v[42:49], v[66:73], v[50:57], v[42:49]// 00000017BC8C: CC40402A 1CAA6542
	v_wmma_f32_16x16x16_f16 v[34:41], v[66:73], v[74:81], v[34:41]// 00000017BC94: CC404022 1C8A9542
	v_wmma_f32_16x16x16_f16 v[26:33], v[66:73], v[115:122], v[26:33]// 00000017BC9C: CC40401A 1C6AE742
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017BCA4: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[66:73], v[123:130], v[18:25]// 00000017BCA8: CC404012 1C4AF742
	s_and_saveexec_b32 s11, s0                                 // 00000017BCB0: BE8B2000
	s_cbranch_execnz 1359                                      // 00000017BCB4: BFA6054F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ff4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017BCB8: 8C7E0B7E
	global_load_b128 v[3:6], v[7:8], off offset:464            // 00000017BCBC: DC5E01D0 037C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017BCC4: BE8B2000
	s_cbranch_execnz 1365                                      // 00000017BCC8: BFA60555 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6020>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017BCCC: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:480          // 00000017BCD0: DC5E01E0 327C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017BCD8: BE8B2000
	s_cbranch_execnz 1371                                      // 00000017BCDC: BFA6055B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x604c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017BCE0: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:496          // 00000017BCE4: DC5E01F0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017BCEC: BE8B2000
	s_cbranch_execz 6                                          // 00000017BCF0: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b0c>
	s_waitcnt vmcnt(0)                                         // 00000017BCF4: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017BCF8: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017BCFC: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017BD00: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017BD04: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017BD08: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017BD0C: 8C7E0B7E
	ds_load_b128 v[66:69], v94 offset:448                      // 00000017BD10: DBFC01C0 4200005E
	ds_load_b128 v[70:73], v94 offset:464                      // 00000017BD18: DBFC01D0 4600005E
	s_waitcnt vmcnt(2)                                         // 00000017BD20: BF890BF7
	v_fma_mixlo_f16 v60, v3, s22, 0                            // 00000017BD24: CC21003C 02002D03
	v_fma_mixhi_f16 v60, v4, s22, 0                            // 00000017BD2C: CC22003C 02002D04
	v_fma_mixlo_f16 v61, v5, s22, 0                            // 00000017BD34: CC21003D 02002D05
	v_fma_mixhi_f16 v61, v6, s22, 0                            // 00000017BD3C: CC22003D 02002D06
	ds_load_b128 v[3:6], v94 offset:480                        // 00000017BD44: DBFC01E0 0300005E
	ds_load_b128 v[74:77], v94 offset:496                      // 00000017BD4C: DBFC01F0 4A00005E
	ds_load_b128 v[78:81], v94 offset:8896                     // 00000017BD54: DBFC22C0 4E00005E
	ds_load_b128 v[115:118], v94 offset:8912                   // 00000017BD5C: DBFC22D0 7300005E
	v_fma_mixhi_f16 v58, v63, s22, 0                           // 00000017BD64: CC22003A 02002D3F
	v_fma_mixlo_f16 v59, v64, s22, 0                           // 00000017BD6C: CC21003B 02002D40
	s_waitcnt vmcnt(1)                                         // 00000017BD74: BF8907F7
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 00000017BD78: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 00000017BD80: CC22003F 02002D35
	s_waitcnt vmcnt(0)                                         // 00000017BD88: BF8903F7
	v_fma_mixlo_f16 v64, v54, s22, 0                           // 00000017BD8C: CC210040 02002D36
	v_fma_mixhi_f16 v64, v55, s22, 0                           // 00000017BD94: CC220040 02002D37
	v_fma_mixlo_f16 v58, v62, s22, 0                           // 00000017BD9C: CC21003A 02002D3E
	v_fma_mixhi_f16 v59, v65, s22, 0                           // 00000017BDA4: CC22003B 02002D41
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 00000017BDAC: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 00000017BDB4: CC22003E 02002D33
	v_fma_mixlo_f16 v65, v56, s22, 0                           // 00000017BDBC: CC210041 02002D38
	s_waitcnt lgkmcnt(4)                                       // 00000017BDC4: BF89FC47
	v_fma_mixlo_f16 v52, v70, s22, 0                           // 00000017BDC8: CC210034 02002D46
	v_fma_mixhi_f16 v52, v71, s22, 0                           // 00000017BDD0: CC220034 02002D47
	v_fma_mixlo_f16 v53, v72, s22, 0                           // 00000017BDD8: CC210035 02002D48
	v_fma_mixhi_f16 v53, v73, s22, 0                           // 00000017BDE0: CC220035 02002D49
	ds_load_b128 v[70:73], v94 offset:8928                     // 00000017BDE8: DBFC22E0 4600005E
	s_waitcnt lgkmcnt(4)                                       // 00000017BDF0: BF89FC47
	v_fma_mixlo_f16 v54, v3, s22, 0                            // 00000017BDF4: CC210036 02002D03
	v_fma_mixhi_f16 v54, v4, s22, 0                            // 00000017BDFC: CC220036 02002D04
	v_fma_mixlo_f16 v55, v5, s22, 0                            // 00000017BE04: CC210037 02002D05
	v_fma_mixhi_f16 v55, v6, s22, 0                            // 00000017BE0C: CC220037 02002D06
	ds_load_b128 v[3:6], v94 offset:8944                       // 00000017BE14: DBFC22F0 0300005E
	v_fma_mixhi_f16 v65, v57, s22, 0                           // 00000017BE1C: CC220041 02002D39
	v_fma_mixlo_f16 v50, v66, s22, 0                           // 00000017BE24: CC210032 02002D42
	v_fma_mixhi_f16 v50, v67, s22, 0                           // 00000017BE2C: CC220032 02002D43
	v_fma_mixlo_f16 v51, v68, s22, 0                           // 00000017BE34: CC210033 02002D44
	v_fma_mixhi_f16 v51, v69, s22, 0                           // 00000017BE3C: CC220033 02002D45
	s_waitcnt lgkmcnt(4)                                       // 00000017BE44: BF89FC47
	v_fma_mixlo_f16 v56, v74, s22, 0                           // 00000017BE48: CC210038 02002D4A
	v_fma_mixhi_f16 v56, v75, s22, 0                           // 00000017BE50: CC220038 02002D4B
	v_fma_mixlo_f16 v57, v76, s22, 0                           // 00000017BE58: CC210039 02002D4C
	v_fma_mixhi_f16 v57, v77, s22, 0                           // 00000017BE60: CC220039 02002D4D
	s_waitcnt lgkmcnt(3)                                       // 00000017BE68: BF89FC37
	v_fma_mixlo_f16 v66, v78, s22, 0                           // 00000017BE6C: CC210042 02002D4E
	ds_load_b128 v[74:77], v94 offset:17344                    // 00000017BE74: DBFC43C0 4A00005E
	v_fma_mixhi_f16 v66, v79, s22, 0                           // 00000017BE7C: CC220042 02002D4F
	v_fma_mixlo_f16 v67, v80, s22, 0                           // 00000017BE84: CC210043 02002D50
	v_fma_mixhi_f16 v67, v81, s22, 0                           // 00000017BE8C: CC220043 02002D51
	s_waitcnt lgkmcnt(3)                                       // 00000017BE94: BF89FC37
	v_fma_mixlo_f16 v68, v115, s22, 0                          // 00000017BE98: CC210044 02002D73
	ds_load_b128 v[78:81], v94 offset:17360                    // 00000017BEA0: DBFC43D0 4E00005E
	v_fma_mixhi_f16 v68, v116, s22, 0                          // 00000017BEA8: CC220044 02002D74
	v_fma_mixlo_f16 v69, v117, s22, 0                          // 00000017BEB0: CC210045 02002D75
	v_fma_mixhi_f16 v69, v118, s22, 0                          // 00000017BEB8: CC220045 02002D76
	ds_load_b128 v[115:118], v94 offset:17376                  // 00000017BEC0: DBFC43E0 7300005E
	ds_load_b128 v[119:122], v94 offset:17392                  // 00000017BEC8: DBFC43F0 7700005E
	s_waitcnt lgkmcnt(5)                                       // 00000017BED0: BF89FC57
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 00000017BED4: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 00000017BEDC: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 00000017BEE4: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 00000017BEEC: CC220047 02002D49
	s_waitcnt lgkmcnt(4)                                       // 00000017BEF4: BF89FC47
	v_fma_mixlo_f16 v72, v3, s22, 0                            // 00000017BEF8: CC210048 02002D03
	v_fma_mixhi_f16 v72, v4, s22, 0                            // 00000017BF00: CC220048 02002D04
	v_fma_mixlo_f16 v73, v5, s22, 0                            // 00000017BF08: CC210049 02002D05
	v_fma_mixhi_f16 v73, v6, s22, 0                            // 00000017BF10: CC220049 02002D06
	ds_load_b128 v[3:6], v94 offset:25792                      // 00000017BF18: DBFC64C0 0300005E
	ds_load_b128 v[123:126], v94 offset:25808                  // 00000017BF20: DBFC64D0 7B00005E
	ds_load_b128 v[127:130], v94 offset:25824                  // 00000017BF28: DBFC64E0 7F00005E
	ds_load_b128 v[131:134], v94 offset:25840                  // 00000017BF30: DBFC64F0 8300005E
	s_waitcnt lgkmcnt(7)                                       // 00000017BF38: BF89FC77
	v_fma_mixlo_f16 v74, v74, s22, 0                           // 00000017BF3C: CC21004A 02002D4A
	v_fma_mixhi_f16 v74, v75, s22, 0                           // 00000017BF44: CC22004A 02002D4B
	v_fma_mixlo_f16 v75, v76, s22, 0                           // 00000017BF4C: CC21004B 02002D4C
	v_fma_mixhi_f16 v75, v77, s22, 0                           // 00000017BF54: CC22004B 02002D4D
	s_waitcnt lgkmcnt(6)                                       // 00000017BF5C: BF89FC67
	v_fma_mixlo_f16 v76, v78, s22, 0                           // 00000017BF60: CC21004C 02002D4E
	v_fma_mixhi_f16 v76, v79, s22, 0                           // 00000017BF68: CC22004C 02002D4F
	v_fma_mixlo_f16 v77, v80, s22, 0                           // 00000017BF70: CC21004D 02002D50
	v_fma_mixhi_f16 v77, v81, s22, 0                           // 00000017BF78: CC22004D 02002D51
	s_waitcnt lgkmcnt(5)                                       // 00000017BF80: BF89FC57
	v_fma_mixlo_f16 v78, v115, s22, 0                          // 00000017BF84: CC21004E 02002D73
	v_fma_mixhi_f16 v78, v116, s22, 0                          // 00000017BF8C: CC22004E 02002D74
	v_fma_mixlo_f16 v79, v117, s22, 0                          // 00000017BF94: CC21004F 02002D75
	v_fma_mixhi_f16 v79, v118, s22, 0                          // 00000017BF9C: CC22004F 02002D76
	s_waitcnt lgkmcnt(4)                                       // 00000017BFA4: BF89FC47
	v_fma_mixlo_f16 v80, v119, s22, 0                          // 00000017BFA8: CC210050 02002D77
	v_fma_mixhi_f16 v80, v120, s22, 0                          // 00000017BFB0: CC220050 02002D78
	v_fma_mixlo_f16 v81, v121, s22, 0                          // 00000017BFB8: CC210051 02002D79
	v_fma_mixhi_f16 v81, v122, s22, 0                          // 00000017BFC0: CC220051 02002D7A
	s_mul_i32 s11, s23, 48                                     // 00000017BFC8: 960BB017
	s_mul_hi_u32 s0, s23, 48                                   // 00000017BFCC: 9680B017
	s_add_u32 s14, s11, s2                                     // 00000017BFD0: 800E020B
	s_addc_u32 s15, s0, s3                                     // 00000017BFD4: 820F0300
	s_waitcnt lgkmcnt(3)                                       // 00000017BFD8: BF89FC37
	v_fma_mixlo_f16 v115, v3, s22, 0                           // 00000017BFDC: CC210073 02002D03
	v_fma_mixhi_f16 v115, v4, s22, 0                           // 00000017BFE4: CC220073 02002D04
	v_fma_mixlo_f16 v116, v5, s22, 0                           // 00000017BFEC: CC210074 02002D05
	v_fma_mixhi_f16 v116, v6, s22, 0                           // 00000017BFF4: CC220074 02002D06
	s_waitcnt lgkmcnt(2)                                       // 00000017BFFC: BF89FC27
	v_fma_mixlo_f16 v117, v123, s22, 0                         // 00000017C000: CC210075 02002D7B
	v_fma_mixhi_f16 v117, v124, s22, 0                         // 00000017C008: CC220075 02002D7C
	v_fma_mixlo_f16 v118, v125, s22, 0                         // 00000017C010: CC210076 02002D7D
	v_fma_mixhi_f16 v118, v126, s22, 0                         // 00000017C018: CC220076 02002D7E
	s_waitcnt lgkmcnt(1)                                       // 00000017C020: BF89FC17
	v_fma_mixlo_f16 v119, v127, s22, 0                         // 00000017C024: CC210077 02002D7F
	v_fma_mixhi_f16 v119, v128, s22, 0                         // 00000017C02C: CC220077 02002D80
	v_fma_mixlo_f16 v120, v129, s22, 0                         // 00000017C034: CC210078 02002D81
	v_fma_mixhi_f16 v120, v130, s22, 0                         // 00000017C03C: CC220078 02002D82
	s_waitcnt lgkmcnt(0)                                       // 00000017C044: BF89FC07
	v_fma_mixlo_f16 v121, v131, s22, 0                         // 00000017C048: CC210079 02002D83
	v_fma_mixhi_f16 v121, v132, s22, 0                         // 00000017C050: CC220079 02002D84
	v_fma_mixlo_f16 v122, v133, s22, 0                         // 00000017C058: CC21007A 02002D85
	v_fma_mixhi_f16 v122, v134, s22, 0                         // 00000017C060: CC22007A 02002D86
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[74:81], v[26:33]// 00000017C068: CC40401A 1C6A953A
	v_mov_b32_e32 v74, 0                                       // 00000017C070: 7E940280
	s_lshl_b64 s[14:15], s[14:15], 14                          // 00000017C074: 848E8E0E
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[50:57], v[42:49]// 00000017C078: CC40402A 1CAA653A
	.long 0xd7000003                                           // 00000017C080: D7000003
	v_cndmask_b32_e32 v0, v96, v14, vcc_lo                     // 00000017C084: 02001D60
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[66:73], v[34:41]// 00000017C088: CC404022 1C8A853A
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[115:122], v[18:25]// 00000017C090: CC404012 1C4AE73A
	v_add_co_ci_u32_e64 v4, null, s15, v97, s0                 // 00000017C098: D5207C04 0002C20F
	v_mov_b32_e32 v75, v74                                     // 00000017C0A0: 7E96034A
	v_mov_b32_e32 v76, v74                                     // 00000017C0A4: 7E98034A
	v_mov_b32_e32 v77, v74                                     // 00000017C0A8: 7E9A034A
	v_mov_b32_e32 v78, v74                                     // 00000017C0AC: 7E9C034A
	v_mov_b32_e32 v79, v74                                     // 00000017C0B0: 7E9E034A
	v_mov_b32_e32 v80, v74                                     // 00000017C0B4: 7EA0034A
	v_mov_b32_e32 v81, v74                                     // 00000017C0B8: 7EA2034A
	v_mov_b32_e32 v66, v74                                     // 00000017C0BC: 7E84034A
	v_mov_b32_e32 v67, v74                                     // 00000017C0C0: 7E86034A
	v_mov_b32_e32 v68, v74                                     // 00000017C0C4: 7E88034A
	v_mov_b32_e32 v69, v74                                     // 00000017C0C8: 7E8A034A
	v_mov_b32_e32 v70, v74                                     // 00000017C0CC: 7E8C034A
	v_mov_b32_e32 v71, v74                                     // 00000017C0D0: 7E8E034A
	v_mov_b32_e32 v72, v74                                     // 00000017C0D4: 7E90034A
	v_mov_b32_e32 v73, v74                                     // 00000017C0D8: 7E92034A
	v_mov_b32_e32 v58, v74                                     // 00000017C0DC: 7E74034A
	v_mov_b32_e32 v59, v74                                     // 00000017C0E0: 7E76034A
	v_mov_b32_e32 v60, v74                                     // 00000017C0E4: 7E78034A
	v_mov_b32_e32 v61, v74                                     // 00000017C0E8: 7E7A034A
	v_mov_b32_e32 v62, v74                                     // 00000017C0EC: 7E7C034A
	v_mov_b32_e32 v63, v74                                     // 00000017C0F0: 7E7E034A
	v_mov_b32_e32 v64, v74                                     // 00000017C0F4: 7E80034A
	v_mov_b32_e32 v65, v74                                     // 00000017C0F8: 7E82034A
	v_mov_b32_e32 v50, v74                                     // 00000017C0FC: 7E64034A
	v_mov_b32_e32 v51, v74                                     // 00000017C100: 7E66034A
	v_mov_b32_e32 v52, v74                                     // 00000017C104: 7E68034A
	v_mov_b32_e32 v53, v74                                     // 00000017C108: 7E6A034A
	v_mov_b32_e32 v54, v74                                     // 00000017C10C: 7E6C034A
	v_mov_b32_e32 v55, v74                                     // 00000017C110: 7E6E034A
	v_mov_b32_e32 v56, v74                                     // 00000017C114: 7E70034A
	v_mov_b32_e32 v57, v74                                     // 00000017C118: 7E72034A
	s_mov_b32 s14, 0                                           // 00000017C11C: BE8E0080
	s_mov_b32 s11, 0                                           // 00000017C120: BE8B0080
	s_lshl_b32 s18, s14, 4                                     // 00000017C124: 8412840E
	v_lshl_add_u32 v139, s14, 5, v98                           // 00000017C128: D646008B 05890A0E
	s_lshl_b64 s[50:51], s[18:19], 2                           // 00000017C130: 84B28212
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017C134: BF870099
	.long 0xd7000073                                           // 00000017C138: D7000073
	v_cndmask_b32_e32 v0, v3, v50, vcc_lo                      // 00000017C13C: 02006503
	v_add_co_ci_u32_e64 v116, null, s51, v4, s0                // 00000017C140: D5207C74 00020833
	.long 0xd44a0000                                           // 00000017C148: D44A0000
	v_cndmask_b32_e32 v1, s14, v90, vcc_lo                     // 00000017C14C: 0202B40E
	s_add_i32 s14, s14, 1                                      // 00000017C150: 810E810E
	s_clause 0x3                                               // 00000017C154: BF850003
	global_load_b128 v[5:8], v[115:116], off                   // 00000017C158: DC5E0000 057C0073
	global_load_b128 v[149:152], v[115:116], off offset:16     // 00000017C160: DC5E0010 957C0073
	global_load_b128 v[153:156], v[115:116], off offset:32     // 00000017C168: DC5E0020 997C0073
	global_load_b128 v[157:160], v[115:116], off offset:48     // 00000017C170: DC5E0030 9D7C0073
	ds_load_b128 v[115:118], v139                              // 00000017C178: DBFC0000 7300008B
	ds_load_b128 v[119:122], v139 offset:16                    // 00000017C180: DBFC0010 7700008B
	ds_load_b128 v[127:130], v139 offset:2576                  // 00000017C188: DBFC0A10 7F00008B
	ds_load_b128 v[123:126], v139 offset:2560                  // 00000017C190: DBFC0A00 7B00008B
	ds_load_b128 v[135:138], v139 offset:5136                  // 00000017C198: DBFC1410 8700008B
	ds_load_b128 v[131:134], v139 offset:5120                  // 00000017C1A0: DBFC1400 8300008B
	ds_load_b128 v[143:146], v139 offset:7696                  // 00000017C1A8: DBFC1E10 8F00008B
	ds_load_b128 v[139:142], v139 offset:7680                  // 00000017C1B0: DBFC1E00 8B00008B
	s_or_b32 s11, s0, s11                                      // 00000017C1B8: 8C0B0B00
	s_waitcnt vmcnt(3)                                         // 00000017C1BC: BF890FF7
	v_fma_mixlo_f16 v147, v5, s22, 0                           // 00000017C1C0: CC210093 02002D05
	v_fma_mixhi_f16 v147, v6, s22, 0                           // 00000017C1C8: CC220093 02002D06
	v_fma_mixlo_f16 v148, v7, s22, 0                           // 00000017C1D0: CC210094 02002D07
	v_fma_mixhi_f16 v148, v8, s22, 0                           // 00000017C1D8: CC220094 02002D08
	s_waitcnt vmcnt(2)                                         // 00000017C1E0: BF890BF7
	v_fma_mixlo_f16 v149, v149, s22, 0                         // 00000017C1E4: CC210095 02002D95
	v_fma_mixhi_f16 v149, v150, s22, 0                         // 00000017C1EC: CC220095 02002D96
	v_fma_mixlo_f16 v150, v151, s22, 0                         // 00000017C1F4: CC210096 02002D97
	v_fma_mixhi_f16 v150, v152, s22, 0                         // 00000017C1FC: CC220096 02002D98
	s_waitcnt vmcnt(1)                                         // 00000017C204: BF8907F7
	v_fma_mixlo_f16 v151, v153, s22, 0                         // 00000017C208: CC210097 02002D99
	v_fma_mixhi_f16 v151, v154, s22, 0                         // 00000017C210: CC220097 02002D9A
	v_fma_mixlo_f16 v152, v155, s22, 0                         // 00000017C218: CC210098 02002D9B
	v_fma_mixhi_f16 v152, v156, s22, 0                         // 00000017C220: CC220098 02002D9C
	s_waitcnt vmcnt(0)                                         // 00000017C228: BF8903F7
	v_fma_mixlo_f16 v153, v157, s22, 0                         // 00000017C22C: CC210099 02002D9D
	v_fma_mixhi_f16 v153, v158, s22, 0                         // 00000017C234: CC220099 02002D9E
	v_fma_mixlo_f16 v154, v159, s22, 0                         // 00000017C23C: CC21009A 02002D9F
	v_fma_mixhi_f16 v154, v160, s22, 0                         // 00000017C244: CC22009A 02002DA0
	s_waitcnt lgkmcnt(6)                                       // 00000017C24C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C250: BF870001
	v_wmma_f32_16x16x16_f16 v[74:81], v[147:154], v[115:122], v[74:81]// 00000017C254: CC40404A 1D2AE793
	s_waitcnt lgkmcnt(4)                                       // 00000017C25C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[66:73], v[147:154], v[123:130], v[66:73]// 00000017C260: CC404042 1D0AF793
	s_waitcnt lgkmcnt(2)                                       // 00000017C268: BF89FC27
	v_wmma_f32_16x16x16_f16 v[58:65], v[147:154], v[131:138], v[58:65]// 00000017C26C: CC40403A 1CEB0793
	s_waitcnt lgkmcnt(0)                                       // 00000017C274: BF89FC07
	v_wmma_f32_16x16x16_f16 v[50:57], v[147:154], v[139:146], v[50:57]// 00000017C278: CC404032 1CCB1793
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000017C280: 917E0B7E
	s_cbranch_execnz 65447                                     // 00000017C284: BFA6FFA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f24>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017C288: 8C7E0B7E
	s_and_saveexec_b32 s0, s1                                  // 00000017C28C: BE802001
	s_cbranch_execnz 1018                                      // 00000017C290: BFA603FA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x607c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C294: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017C298: BE802004
	s_cbranch_execnz 1037                                      // 00000017C29C: BFA6040D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2A0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017C2A4: BE802005
	s_cbranch_execnz 1056                                      // 00000017C2A8: BFA60420 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x612c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2AC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017C2B0: BE802006
	s_cbranch_execnz 1075                                      // 00000017C2B4: BFA60433 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6184>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2B8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017C2BC: BE802007
	s_cbranch_execnz 1094                                      // 00000017C2C0: BFA60446 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x61dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2C4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017C2C8: BE802008
	s_cbranch_execnz 1113                                      // 00000017C2CC: BFA60459 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6234>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2D0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017C2D4: BE802009
	s_cbranch_execnz 1132                                      // 00000017C2D8: BFA6046C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x628c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2DC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017C2E0: BE80200A
	s_cbranch_execnz 1151                                      // 00000017C2E4: BFA6047F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62e4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2E8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017C2EC: BE802001
	s_cbranch_execnz 1169                                      // 00000017C2F0: BFA60491 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6338>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C2F4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017C2F8: BE802004
	s_cbranch_execnz 1188                                      // 00000017C2FC: BFA604A4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6390>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C300: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017C304: BE802005
	s_cbranch_execnz 1207                                      // 00000017C308: BFA604B7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x63e8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C30C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017C310: BE802006
	s_cbranch_execnz 1226                                      // 00000017C314: BFA604CA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6440>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C318: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017C31C: BE802007
	s_cbranch_execnz 1245                                      // 00000017C320: BFA604DD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6498>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C324: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017C328: BE802008
	s_cbranch_execnz 1264                                      // 00000017C32C: BFA604F0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x64f0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C330: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017C334: BE802009
	s_cbranch_execnz 1283                                      // 00000017C338: BFA60503 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6548>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C33C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017C340: BE80200A
	s_cbranch_execnz 1302                                      // 00000017C344: BFA60516 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x65a0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C348: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017C34C: BE802001
	s_cbranch_execnz 1320                                      // 00000017C350: BFA60528 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x65f4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C354: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017C358: BE802004
	s_cbranch_execnz 1339                                      // 00000017C35C: BFA6053B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x664c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C360: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017C364: BE802005
	s_cbranch_execnz 1358                                      // 00000017C368: BFA6054E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66a4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C36C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017C370: BE802006
	s_cbranch_execnz 1377                                      // 00000017C374: BFA60561 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66fc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C378: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017C37C: BE802007
	s_cbranch_execnz 1396                                      // 00000017C380: BFA60574 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6754>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C384: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017C388: BE802008
	s_cbranch_execnz 1415                                      // 00000017C38C: BFA60587 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x67ac>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C390: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017C394: BE802009
	s_cbranch_execnz 1434                                      // 00000017C398: BFA6059A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6804>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C39C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017C3A0: BE80200A
	s_cbranch_execnz 1453                                      // 00000017C3A4: BFA605AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x685c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3A8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017C3AC: BE802001
	s_cbranch_execnz 1471                                      // 00000017C3B0: BFA605BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x68b0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3B4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017C3B8: BE802004
	s_cbranch_execnz 1490                                      // 00000017C3BC: BFA605D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6908>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3C0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017C3C4: BE802005
	s_cbranch_execnz 1509                                      // 00000017C3C8: BFA605E5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6960>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3CC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017C3D0: BE802006
	s_cbranch_execnz 1528                                      // 00000017C3D4: BFA605F8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x69b8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3D8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017C3DC: BE802007
	s_cbranch_execnz 1547                                      // 00000017C3E0: BFA6060B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a10>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3E4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017C3E8: BE802008
	s_cbranch_execnz 1566                                      // 00000017C3EC: BFA6061E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a68>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3F0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017C3F4: BE802009
	s_cbranch_execnz 1585                                      // 00000017C3F8: BFA60631 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6ac0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C3FC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017C400: BE80200A
	s_cbranch_execz 18                                         // 00000017C404: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5250>
	ds_load_b32 v3, v104 offset:56                             // 00000017C408: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017C410: BF89FC07
	v_fmac_f32_e32 v57, v25, v3                                // 00000017C414: 56720719
	v_mad_u64_u32 v[3:4], null, 0x3000, v114, v[84:85]         // 00000017C418: D6FE7C03 0552E4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017C424: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v57                          // 00000017C428: 100A72FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017C430: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C438: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017C43C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017C448: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017C450: 8C7E007E
	s_mul_f32 s0, s48, 0x3fb8aa3b                              // 00000017C454: A200FF30 3FB8AA3B
	v_or_b32_e32 v4, s47, v88                                  // 00000017C45C: 3808B02F
	v_dual_mov_b32 v18, v86 :: v_dual_mov_b32 v19, v87         // 00000017C460: CA100156 12120157
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017C468: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 00000017C46C: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 00000017C474: BE846300
	s_fmamk_f32 s1, s48, 0x3fb8aa3b, s1                        // 00000017C478: A3010130 3FB8AA3B
	s_cmp_nlt_f32 s48, 0xc2ce8ed0                              // 00000017C480: BF4EFF30 C2CE8ED0
	s_mov_b32 s5, 0                                            // 00000017C488: BE850080
	s_sub_f32 s0, s0, s4                                       // 00000017C48C: A0800400
	s_fmamk_f32 s1, s48, 0x32a5705f, s1                        // 00000017C490: A3010130 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000017C498: BF87059B
	s_add_f32 s0, s0, s1                                       // 00000017C49C: A0000100
	v_exp_f32_e32 v3, s0                                       // 00000017C4A0: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 00000017C4A4: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000017C4A8: BF870585
	.long 0xd71c0003                                           // 00000017C4AC: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000017C4B0: 02000103
	s_cselect_b32 s0, -1, 0                                    // 00000017C4B4: 980080C1
	s_cmp_ngt_f32 s48, 0x42b17218                              // 00000017C4B8: BF4BFF30 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017C4C0: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 00000017C4C4: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 00000017C4CC: 980180C1
	.long 0xd4440000                                           // 00000017C4D0: D4440000
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 00000017C4D4: 02020823
	v_cndmask_b32_e64 v20, 0x7f800000, v3, s1                  // 00000017C4D8: D5010014 000606FF 7F800000
	s_branch 120                                               // 00000017C4E4: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x54c8>
	s_set_inst_prefetch_distance 0x2                           // 00000017C4E8: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000017C4EC: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000017C4F0: BF89FC07
	s_barrier                                                  // 00000017C4F4: BFBD0000
	buffer_gl0_inv                                             // 00000017C4F8: E0AC0000 00000000
	ds_load_b128 v[22:25], v99                                 // 00000017C500: DBFC0000 16000063
	ds_load_b128 v[26:29], v99 offset:16                       // 00000017C508: DBFC0010 1A000063
	ds_load_b128 v[30:33], v107                                // 00000017C510: DBFC0000 1E00006B
	ds_load_b128 v[34:37], v107 offset:16                      // 00000017C518: DBFC0010 2200006B
	ds_load_b128 v[38:41], v99 offset:32                       // 00000017C520: DBFC0020 26000063
	ds_load_b128 v[42:45], v99 offset:48                       // 00000017C528: DBFC0030 2A000063
	ds_load_b128 v[46:49], v107 offset:32                      // 00000017C530: DBFC0020 2E00006B
	ds_load_b128 v[50:53], v107 offset:48                      // 00000017C538: DBFC0030 3200006B
	v_mov_b32_e32 v9, v2                                       // 00000017C540: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000017C544: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000017C548: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000017C54C: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000017C550: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000017C554: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000017C558: 7E100302
	v_mov_b32_e32 v61, v9                                      // 00000017C55C: 7E7A0309
	v_dual_mov_b32 v57, v5 :: v_dual_mov_b32 v56, v4           // 00000017C560: CA100105 39380104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000017C568: BF870214
	v_dual_mov_b32 v59, v7 :: v_dual_mov_b32 v58, v6           // 00000017C56C: CA100107 3B3A0106
	v_dual_mov_b32 v60, v8 :: v_dual_mov_b32 v55, v3           // 00000017C574: CA100108 3C360103
	v_mov_b32_e32 v54, v2                                      // 00000017C57C: 7E6C0302
	ds_load_b128 v[66:69], v99 offset:80                       // 00000017C580: DBFC0050 42000063
	ds_load_b128 v[62:65], v99 offset:64                       // 00000017C588: DBFC0040 3E000063
	ds_load_b128 v[74:77], v107 offset:80                      // 00000017C590: DBFC0050 4A00006B
	ds_load_b128 v[70:73], v107 offset:64                      // 00000017C598: DBFC0040 4600006B
	ds_load_b128 v[112:115], v99 offset:112                    // 00000017C5A0: DBFC0070 70000063
	ds_load_b128 v[108:111], v99 offset:96                     // 00000017C5A8: DBFC0060 6C000063
	ds_load_2addr_b32 v[3:4], v21 offset0:16 offset1:18        // 00000017C5B0: D8DC1210 03000015
	ds_load_b128 v[120:123], v107 offset:112                   // 00000017C5B8: DBFC0070 7800006B
	ds_load_b128 v[116:119], v107 offset:96                    // 00000017C5C0: DBFC0060 7400006B
	ds_load_2addr_b32 v[5:6], v21 offset0:20 offset1:22        // 00000017C5C8: D8DC1614 05000015
	ds_load_2addr_b32 v[7:8], v21 offset0:24 offset1:26        // 00000017C5D0: D8DC1A18 07000015
	.long 0xd7000112                                           // 00000017C5D8: D7000112
	v_cndmask_b32_e32 v1, 0x80, v18, vcc_lo                    // 00000017C5DC: 020224FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C5E4: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000017C5E8: D5207C13 00062680
	s_waitcnt lgkmcnt(15)                                      // 00000017C5F0: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[54:61], v[22:29], v[30:37], v[54:61]// 00000017C5F4: CC404036 1CDA3D16
	ds_load_2addr_b32 v[22:23], v21 offset0:28 offset1:30      // 00000017C5FC: D8DC1E1C 16000015
	s_add_i32 s1, s5, 32                                       // 00000017C604: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 00000017C608: B585005F
	s_mov_b32 s5, s1                                           // 00000017C60C: BE850001
	s_waitcnt lgkmcnt(12)                                      // 00000017C610: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[54:61], v[38:45], v[46:53], v[54:61]// 00000017C614: CC404036 1CDA5D26
	s_waitcnt lgkmcnt(8)                                       // 00000017C61C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C620: BF870001
	v_wmma_f32_16x16x16_f16 v[54:61], v[62:69], v[70:77], v[54:61]// 00000017C624: CC404036 1CDA8D3E
	s_waitcnt lgkmcnt(5)                                       // 00000017C62C: BF89FC57
	v_mul_f32_e32 v3, v20, v3                                  // 00000017C630: 10060714
	v_mul_f32_e32 v4, v20, v4                                  // 00000017C634: 10080914
	s_waitcnt lgkmcnt(2)                                       // 00000017C638: BF89FC27
	v_mul_f32_e32 v5, v20, v5                                  // 00000017C63C: 100A0B14
	v_wmma_f32_16x16x16_f16 v[54:61], v[108:115], v[116:123], v[54:61]// 00000017C640: CC404036 1CDAE96C
	s_waitcnt lgkmcnt(1)                                       // 00000017C648: BF89FC17
	v_mul_f32_e32 v7, v20, v7                                  // 00000017C64C: 100E0F14
	v_mul_f32_e32 v6, v20, v6                                  // 00000017C650: 100C0D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000017C654: BF870193
	v_dual_mul_f32 v8, v20, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v54// 00000017C658: C8C01114 08026CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v58                         // 00000017C664: 560E74FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000017C66C: BF89FC07
	v_mul_f32_e32 v9, v20, v22                                 // 00000017C670: 10122D14
	v_mul_f32_e32 v22, v20, v23                                // 00000017C674: 102C2F14
	v_dual_fmac_f32 v4, 0x3b800000, v55 :: v_dual_fmac_f32 v5, 0x3b800000, v56// 00000017C678: C8006EFF 040470FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v59                         // 00000017C684: 561076FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v57                         // 00000017C68C: 560C72FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000017C694: BF870004
	v_dual_fmac_f32 v22, 0x3b800000, v61 :: v_dual_fmac_f32 v9, 0x3b800000, v60// 00000017C698: C8007AFF 160878FF 3B800000
	ds_store_2addr_b32 v21, v3, v4 offset0:16 offset1:18       // 00000017C6A4: D8381210 00040315
	ds_store_2addr_b32 v21, v5, v6 offset0:20 offset1:22       // 00000017C6AC: D8381614 00060515
	ds_store_2addr_b32 v21, v7, v8 offset0:24 offset1:26       // 00000017C6B4: D8381A18 00080715
	ds_store_2addr_b32 v21, v9, v22 offset0:28 offset1:30      // 00000017C6BC: D8381E1C 00160915
	s_cbranch_scc1 60320                                       // 00000017C6C4: BFA2EBA0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x348>
	v_dual_mov_b32 v4, v18 :: v_dual_mov_b32 v5, v19           // 00000017C6C8: CA100112 04040113
	v_dual_mov_b32 v6, v106 :: v_dual_mov_b32 v7, v89          // 00000017C6D0: CA10016A 06060159
	s_mov_b32 s6, 0                                            // 00000017C6D8: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 00000017C6DC: BC7C0000
	s_barrier                                                  // 00000017C6E0: BFBD0000
	buffer_gl0_inv                                             // 00000017C6E4: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000017C6EC: BF840001
	s_branch 21                                                // 00000017C6F0: BFA00015 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5548>
	s_nop 0                                                    // 00000017C6F4: BF800000
	s_nop 0                                                    // 00000017C6F8: BF800000
	s_nop 0                                                    // 00000017C6FC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017C700: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000017C704: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000017C70C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000017C710: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000017C714: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000017C71C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000017C724: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000017C728: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000017C730: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000017C738: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017C73C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000017C740: 917E067E
	s_cbranch_execz 13                                         // 00000017C744: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x557c>
	.long 0x7e063880                                           // 00000017C748: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000017C74C: BE812000
	s_cbranch_execz 65515                                      // 00000017C750: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5500>
	global_load_b32 v3, v[4:5], off                            // 00000017C754: DC520000 037C0004
	ds_load_b32 v8, v105                                       // 00000017C75C: D8D80000 08000069
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000017C764: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000017C768: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C76C: BF870001
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000017C770: CC210003 02002D03
	s_branch 65505                                             // 00000017C778: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5500>
	s_set_inst_prefetch_distance 0x2                           // 00000017C77C: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000017C780: 8C7E067E
	v_lshl_add_u32 v21, s5, 2, v100                            // 00000017C784: D6460015 05910405
	s_waitcnt lgkmcnt(0)                                       // 00000017C78C: BF89FC07
	s_barrier                                                  // 00000017C790: BFBD0000
	buffer_gl0_inv                                             // 00000017C794: E0AC0000 00000000
	ds_load_b128 v[22:25], v99                                 // 00000017C79C: DBFC0000 16000063
	ds_load_b128 v[26:29], v99 offset:16                       // 00000017C7A4: DBFC0010 1A000063
	ds_load_b128 v[30:33], v99 offset:32                       // 00000017C7AC: DBFC0020 1E000063
	ds_load_b128 v[34:37], v99 offset:48                       // 00000017C7B4: DBFC0030 22000063
	ds_load_b128 v[38:41], v107                                // 00000017C7BC: DBFC0000 2600006B
	ds_load_b128 v[42:45], v107 offset:16                      // 00000017C7C4: DBFC0010 2A00006B
	ds_load_b128 v[46:49], v107 offset:32                      // 00000017C7CC: DBFC0020 2E00006B
	ds_load_b128 v[50:53], v107 offset:48                      // 00000017C7D4: DBFC0030 3200006B
	ds_load_b128 v[58:61], v99 offset:80                       // 00000017C7DC: DBFC0050 3A000063
	ds_load_b128 v[54:57], v99 offset:64                       // 00000017C7E4: DBFC0040 36000063
	ds_load_b128 v[66:69], v107 offset:80                      // 00000017C7EC: DBFC0050 4200006B
	ds_load_b128 v[62:65], v107 offset:64                      // 00000017C7F4: DBFC0040 3E00006B
	ds_load_b128 v[74:77], v99 offset:112                      // 00000017C7FC: DBFC0070 4A000063
	ds_load_b128 v[70:73], v99 offset:96                       // 00000017C804: DBFC0060 46000063
	ds_load_b128 v[112:115], v107 offset:112                   // 00000017C80C: DBFC0070 7000006B
	ds_load_b128 v[108:111], v107 offset:96                    // 00000017C814: DBFC0060 6C00006B
	ds_load_2addr_b32 v[78:79], v21 offset1:2                  // 00000017C81C: D8DC0200 4E000015
	ds_load_2addr_b32 v[80:81], v21 offset0:4 offset1:6        // 00000017C824: D8DC0604 50000015
	ds_load_2addr_b32 v[124:125], v21 offset0:8 offset1:10     // 00000017C82C: D8DC0A08 7C000015
	ds_load_2addr_b32 v[126:127], v21 offset0:12 offset1:14    // 00000017C834: D8DC0E0C 7E000015
	v_mov_b32_e32 v9, v2                                       // 00000017C83C: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000017C840: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000017C844: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000017C848: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000017C84C: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000017C850: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000017C854: 7E100302
	v_mov_b32_e32 v123, v9                                     // 00000017C858: 7EF60309
	v_dual_mov_b32 v119, v5 :: v_dual_mov_b32 v118, v4         // 00000017C85C: CA100105 77760104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000017C864: BF870214
	v_dual_mov_b32 v121, v7 :: v_dual_mov_b32 v120, v6         // 00000017C868: CA100107 79780106
	v_dual_mov_b32 v122, v8 :: v_dual_mov_b32 v117, v3         // 00000017C870: CA100108 7A740103
	v_mov_b32_e32 v116, v2                                     // 00000017C878: 7EE80302
	s_waitcnt lgkmcnt(3)                                       // 00000017C87C: BF89FC37
	v_dual_mov_b32 v4, v18 :: v_dual_mul_f32 v3, v20, v78      // 00000017C880: CA060112 04029D14
	v_mul_f32_e32 v8, v20, v79                                 // 00000017C888: 10109F14
	s_waitcnt lgkmcnt(2)                                       // 00000017C88C: BF89FC27
	v_mul_f32_e32 v9, v20, v80                                 // 00000017C890: 1012A114
	v_wmma_f32_16x16x16_f16 v[116:123], v[22:29], v[38:45], v[116:123]// 00000017C894: CC404074 1DD24D16
	v_mul_f32_e32 v22, v20, v81                                // 00000017C89C: 102CA314
	s_waitcnt lgkmcnt(1)                                       // 00000017C8A0: BF89FC17
	v_mul_f32_e32 v23, v20, v124                               // 00000017C8A4: 102EF914
	v_mul_f32_e32 v24, v20, v125                               // 00000017C8A8: 1030FB14
	s_waitcnt lgkmcnt(0)                                       // 00000017C8AC: BF89FC07
	v_dual_mov_b32 v6, v106 :: v_dual_mul_f32 v25, v20, v126   // 00000017C8B0: CA06016A 0618FD14
	v_wmma_f32_16x16x16_f16 v[116:123], v[30:37], v[46:53], v[116:123]// 00000017C8B8: CC404074 1DD25D1E
	v_dual_mul_f32 v26, v20, v127 :: v_dual_mov_b32 v5, v19    // 00000017C8C0: C8D0FF14 1A040113
	v_mov_b32_e32 v7, v89                                      // 00000017C8C8: 7E0E0359
	s_mov_b32 s6, 0                                            // 00000017C8CC: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017C8D0: BF870093
	v_wmma_f32_16x16x16_f16 v[116:123], v[54:61], v[62:69], v[116:123]// 00000017C8D4: CC404074 1DD27D36
	v_wmma_f32_16x16x16_f16 v[116:123], v[70:77], v[108:115], v[116:123]// 00000017C8DC: CC404074 1DD2D946
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017C8E4: BF870111
	v_dual_fmac_f32 v3, 0x3b800000, v116 :: v_dual_fmac_f32 v8, 0x3b800000, v117// 00000017C8E8: C800E8FF 0308EAFF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v118 :: v_dual_fmac_f32 v22, 0x3b800000, v119// 00000017C8F4: C800ECFF 0916EEFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000017C900: BF870213
	v_dual_fmac_f32 v23, 0x3b800000, v120 :: v_dual_fmac_f32 v24, 0x3b800000, v121// 00000017C904: C800F0FF 1718F2FF 3B800000
	v_dual_fmac_f32 v25, 0x3b800000, v122 :: v_dual_fmac_f32 v26, 0x3b800000, v123// 00000017C910: C800F4FF 191AF6FF 3B800000
	ds_store_2addr_b32 v21, v3, v8 offset1:2                   // 00000017C91C: D8380200 00080315
	ds_store_2addr_b32 v21, v9, v22 offset0:4 offset1:6        // 00000017C924: D8380604 00160915
	ds_store_2addr_b32 v21, v23, v24 offset0:8 offset1:10      // 00000017C92C: D8380A08 00181715
	ds_store_2addr_b32 v21, v25, v26 offset0:12 offset1:14     // 00000017C934: D8380E0C 001A1915
	s_waitcnt lgkmcnt(0)                                       // 00000017C93C: BF89FC07
	s_barrier                                                  // 00000017C940: BFBD0000
	buffer_gl0_inv                                             // 00000017C944: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000017C94C: BF840001
	s_branch 29                                                // 00000017C950: BFA0001D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57c8>
	s_nop 0                                                    // 00000017C954: BF800000
	s_nop 0                                                    // 00000017C958: BF800000
	s_nop 0                                                    // 00000017C95C: BF800000
	s_nop 0                                                    // 00000017C960: BF800000
	s_nop 0                                                    // 00000017C964: BF800000
	s_nop 0                                                    // 00000017C968: BF800000
	s_nop 0                                                    // 00000017C96C: BF800000
	s_nop 0                                                    // 00000017C970: BF800000
	s_nop 0                                                    // 00000017C974: BF800000
	s_nop 0                                                    // 00000017C978: BF800000
	s_nop 0                                                    // 00000017C97C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017C980: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000017C984: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000017C98C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000017C990: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000017C994: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000017C99C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000017C9A4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000017C9A8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000017C9B0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000017C9B8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017C9BC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000017C9C0: 917E067E
	s_cbranch_execz 65224                                      // 00000017C9C4: BFA5FEC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52e8>
	.long 0x7e063880                                           // 00000017C9C8: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000017C9CC: BE812000
	s_cbranch_execz 65515                                      // 00000017C9D0: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5780>
	global_load_b32 v3, v[4:5], off offset:64                  // 00000017C9D4: DC520040 037C0004
	ds_load_b32 v8, v105                                       // 00000017C9DC: D8D80000 08000069
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000017C9E4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000017C9E8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017C9EC: BF870001
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000017C9F0: CC210003 02002D03
	s_branch 65505                                             // 00000017C9F8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5780>
	s_waitcnt vmcnt(0)                                         // 00000017C9FC: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CA00: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CA04: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CA08: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CA0C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CA10: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CA14: 8C7E017E
	global_load_b128 v[18:21], v[66:67], off offset:16         // 00000017CA18: DC5E0010 127C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CA20: BE812000
	s_cbranch_execz 60238                                      // 00000017CA24: BFA5EB4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x560>
	s_waitcnt vmcnt(0)                                         // 00000017CA28: BF8903F7
	v_mov_b32_e32 v19, 0                                       // 00000017CA2C: 7E260280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CA30: BF870001
	v_mov_b32_e32 v18, v19                                     // 00000017CA34: 7E240313
	v_mov_b32_e32 v20, v19                                     // 00000017CA38: 7E280313
	v_mov_b32_e32 v21, v19                                     // 00000017CA3C: 7E2A0313
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CA40: 8C7E017E
	global_load_b128 v[22:25], v[66:67], off offset:32         // 00000017CA44: DC5E0020 167C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CA4C: BE812000
	s_cbranch_execz 60232                                      // 00000017CA50: BFA5EB48 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x574>
	s_waitcnt vmcnt(0)                                         // 00000017CA54: BF8903F7
	v_mov_b32_e32 v23, 0                                       // 00000017CA58: 7E2E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CA5C: BF870001
	v_mov_b32_e32 v22, v23                                     // 00000017CA60: 7E2C0317
	v_mov_b32_e32 v24, v23                                     // 00000017CA64: 7E300317
	v_mov_b32_e32 v25, v23                                     // 00000017CA68: 7E320317
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CA6C: 8C7E017E
	global_load_b128 v[26:29], v[66:67], off offset:48         // 00000017CA70: DC5E0030 1A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CA78: BE812000
	s_cbranch_execnz 60226                                     // 00000017CA7C: BFA6EB42 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x588>
	s_branch 60231                                             // 00000017CA80: BFA0EB47 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a0>
	s_waitcnt vmcnt(0)                                         // 00000017CA84: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CA88: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CA8C: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CA90: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CA94: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CA98: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CA9C: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:80         // 00000017CAA0: DC5E0050 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CAA8: BE812000
	s_cbranch_execz 60448                                      // 00000017CAAC: BFA5EC20 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x930>
	s_waitcnt vmcnt(0)                                         // 00000017CAB0: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CAB4: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CAB8: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CABC: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CAC0: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CAC4: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CAC8: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:96         // 00000017CACC: DC5E0060 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CAD4: BE812000
	s_cbranch_execz 60442                                      // 00000017CAD8: BFA5EC1A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x944>
	s_waitcnt vmcnt(0)                                         // 00000017CADC: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CAE0: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CAE4: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CAE8: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CAEC: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CAF0: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CAF4: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:112        // 00000017CAF8: DC5E0070 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CB00: BE812000
	s_cbranch_execnz 60436                                     // 00000017CB04: BFA6EC14 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x958>
	s_branch 60441                                             // 00000017CB08: BFA0EC19 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x970>
	s_waitcnt vmcnt(0)                                         // 00000017CB0C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CB10: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CB14: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CB18: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CB1C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CB20: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CB24: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:144        // 00000017CB28: DC5E0090 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CB30: BE812000
	s_cbranch_execz 60660                                      // 00000017CB34: BFA5ECF4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd08>
	s_waitcnt vmcnt(0)                                         // 00000017CB38: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CB3C: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CB40: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CB44: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CB48: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CB4C: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CB50: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:160        // 00000017CB54: DC5E00A0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CB5C: BE812000
	s_cbranch_execz 60654                                      // 00000017CB60: BFA5ECEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd1c>
	s_waitcnt vmcnt(0)                                         // 00000017CB64: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CB68: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CB6C: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CB70: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CB74: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CB78: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CB7C: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:176        // 00000017CB80: DC5E00B0 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CB88: BE812000
	s_cbranch_execnz 60648                                     // 00000017CB8C: BFA6ECE8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd30>
	s_branch 60653                                             // 00000017CB90: BFA0ECED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd48>
	s_waitcnt vmcnt(0)                                         // 00000017CB94: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CB98: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CB9C: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CBA0: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CBA4: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CBA8: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CBAC: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:208        // 00000017CBB0: DC5E00D0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CBB8: BE812000
	s_cbranch_execz 60868                                      // 00000017CBBC: BFA5EDC4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10d0>
	s_waitcnt vmcnt(0)                                         // 00000017CBC0: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CBC4: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CBC8: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CBCC: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CBD0: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CBD4: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CBD8: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:224        // 00000017CBDC: DC5E00E0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CBE4: BE812000
	s_cbranch_execz 60862                                      // 00000017CBE8: BFA5EDBE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e4>
	s_waitcnt vmcnt(0)                                         // 00000017CBEC: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CBF0: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CBF4: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CBF8: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CBFC: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CC00: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CC04: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:240        // 00000017CC08: DC5E00F0 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CC10: BE812000
	s_cbranch_execnz 60856                                     // 00000017CC14: BFA6EDB8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f8>
	s_branch 60861                                             // 00000017CC18: BFA0EDBD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1110>
	s_waitcnt vmcnt(0)                                         // 00000017CC1C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CC20: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CC24: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CC28: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CC2C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CC30: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CC34: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:272        // 00000017CC38: DC5E0110 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CC40: BE812000
	s_cbranch_execz 61080                                      // 00000017CC44: BFA5EE98 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14a8>
	s_waitcnt vmcnt(0)                                         // 00000017CC48: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CC4C: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CC50: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CC54: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CC58: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CC5C: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CC60: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:288        // 00000017CC64: DC5E0120 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CC6C: BE812000
	s_cbranch_execz 61074                                      // 00000017CC70: BFA5EE92 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14bc>
	s_waitcnt vmcnt(0)                                         // 00000017CC74: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CC78: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CC7C: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CC80: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CC84: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CC88: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CC8C: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:304        // 00000017CC90: DC5E0130 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CC98: BE812000
	s_cbranch_execnz 61068                                     // 00000017CC9C: BFA6EE8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14d0>
	s_branch 61073                                             // 00000017CCA0: BFA0EE91 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14e8>
	s_waitcnt vmcnt(0)                                         // 00000017CCA4: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CCA8: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CCAC: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CCB0: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CCB4: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CCB8: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CCBC: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:336        // 00000017CCC0: DC5E0150 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CCC8: BE812000
	s_cbranch_execz 61288                                      // 00000017CCCC: BFA5EF68 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1870>
	s_waitcnt vmcnt(0)                                         // 00000017CCD0: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CCD4: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CCD8: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CCDC: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CCE0: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CCE4: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CCE8: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:352        // 00000017CCEC: DC5E0160 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CCF4: BE812000
	s_cbranch_execz 61282                                      // 00000017CCF8: BFA5EF62 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1884>
	s_waitcnt vmcnt(0)                                         // 00000017CCFC: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CD00: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CD04: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CD08: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CD0C: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CD10: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CD14: 8C7E017E
	global_load_b128 v[62:65], v[66:67], off offset:368        // 00000017CD18: DC5E0170 3E7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CD20: BE812000
	s_cbranch_execnz 61276                                     // 00000017CD24: BFA6EF5C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1898>
	s_branch 61281                                             // 00000017CD28: BFA0EF61 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18b0>
	s_waitcnt vmcnt(0)                                         // 00000017CD2C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CD30: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CD34: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CD38: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CD3C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CD40: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CD44: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:400        // 00000017CD48: DC5E0190 327C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CD50: BE812000
	s_cbranch_execz 61500                                      // 00000017CD54: BFA5F03C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c48>
	s_waitcnt vmcnt(0)                                         // 00000017CD58: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CD5C: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CD60: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CD64: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CD68: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CD6C: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CD70: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:416        // 00000017CD74: DC5E01A0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CD7C: BE812000
	s_cbranch_execz 61494                                      // 00000017CD80: BFA5F036 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c5c>
	s_waitcnt vmcnt(0)                                         // 00000017CD84: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CD88: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CD8C: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CD90: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CD94: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CD98: 7E720337
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CD9C: 8C7E017E
	global_load_b128 v[58:61], v[66:67], off offset:432        // 00000017CDA0: DC5E01B0 3A7C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CDA8: BE812000
	s_cbranch_execnz 61488                                     // 00000017CDAC: BFA6F030 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c70>
	s_branch 61493                                             // 00000017CDB0: BFA0F035 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c88>
	s_waitcnt vmcnt(0)                                         // 00000017CDB4: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017CDB8: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CDBC: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017CDC0: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017CDC4: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017CDC8: 7E82033F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CDCC: 8C7E017E
	global_load_b128 v[3:6], v[66:67], off offset:464          // 00000017CDD0: DC5E01D0 037C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CDD8: BE812000
	s_cbranch_execz 61708                                      // 00000017CDDC: BFA5F10C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2010>
	s_waitcnt vmcnt(0)                                         // 00000017CDE0: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CDE4: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CDE8: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CDEC: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CDF0: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CDF4: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CDF8: 8C7E017E
	global_load_b128 v[50:53], v[66:67], off offset:480        // 00000017CDFC: DC5E01E0 327C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CE04: BE812000
	s_cbranch_execz 61702                                      // 00000017CE08: BFA5F106 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2024>
	s_waitcnt vmcnt(0)                                         // 00000017CE0C: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CE10: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CE14: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CE18: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CE1C: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CE20: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017CE24: 8C7E017E
	global_load_b128 v[54:57], v[66:67], off offset:496        // 00000017CE28: DC5E01F0 367C0042
	s_and_saveexec_b32 s1, s0                                  // 00000017CE30: BE812000
	s_cbranch_execnz 61696                                     // 00000017CE34: BFA6F100 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2038>
	s_branch 61701                                             // 00000017CE38: BFA0F105 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2050>
	s_waitcnt vmcnt(0)                                         // 00000017CE3C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CE40: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CE44: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CE48: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CE4C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CE50: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CE54: 8C7E0B7E
	global_load_b128 v[18:21], v[7:8], off offset:16           // 00000017CE58: DC5E0010 127C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CE60: BE8B2000
	s_cbranch_execz 62687                                      // 00000017CE64: BFA5F4DF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fe4>
	s_waitcnt vmcnt(0)                                         // 00000017CE68: BF8903F7
	v_mov_b32_e32 v19, 0                                       // 00000017CE6C: 7E260280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CE70: BF870001
	v_mov_b32_e32 v18, v19                                     // 00000017CE74: 7E240313
	v_mov_b32_e32 v20, v19                                     // 00000017CE78: 7E280313
	v_mov_b32_e32 v21, v19                                     // 00000017CE7C: 7E2A0313
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CE80: 8C7E0B7E
	global_load_b128 v[22:25], v[7:8], off offset:32           // 00000017CE84: DC5E0020 167C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CE8C: BE8B2000
	s_cbranch_execz 62681                                      // 00000017CE90: BFA5F4D9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ff8>
	s_waitcnt vmcnt(0)                                         // 00000017CE94: BF8903F7
	v_mov_b32_e32 v23, 0                                       // 00000017CE98: 7E2E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CE9C: BF870001
	v_mov_b32_e32 v22, v23                                     // 00000017CEA0: 7E2C0317
	v_mov_b32_e32 v24, v23                                     // 00000017CEA4: 7E300317
	v_mov_b32_e32 v25, v23                                     // 00000017CEA8: 7E320317
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CEAC: 8C7E0B7E
	global_load_b128 v[26:29], v[7:8], off offset:48           // 00000017CEB0: DC5E0030 1A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CEB8: BE8B2000
	s_cbranch_execnz 62675                                     // 00000017CEBC: BFA6F4D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x300c>
	s_branch 62680                                             // 00000017CEC0: BFA0F4D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3024>
	s_waitcnt vmcnt(0)                                         // 00000017CEC4: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CEC8: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CECC: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CED0: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CED4: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CED8: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CEDC: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:80           // 00000017CEE0: DC5E0050 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CEE8: BE8B2000
	s_cbranch_execz 62905                                      // 00000017CEEC: BFA5F5B9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33d4>
	s_waitcnt vmcnt(0)                                         // 00000017CEF0: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CEF4: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CEF8: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CEFC: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CF00: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CF04: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CF08: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:96           // 00000017CF0C: DC5E0060 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CF14: BE8B2000
	s_cbranch_execz 62899                                      // 00000017CF18: BFA5F5B3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33e8>
	s_waitcnt vmcnt(0)                                         // 00000017CF1C: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CF20: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CF24: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CF28: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CF2C: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CF30: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CF34: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:112          // 00000017CF38: DC5E0070 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CF40: BE8B2000
	s_cbranch_execnz 62893                                     // 00000017CF44: BFA6F5AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33fc>
	s_branch 62898                                             // 00000017CF48: BFA0F5B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3414>
	s_waitcnt vmcnt(0)                                         // 00000017CF4C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017CF50: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CF54: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017CF58: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017CF5C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017CF60: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CF64: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:144          // 00000017CF68: DC5E0090 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CF70: BE8B2000
	s_cbranch_execz 63118                                      // 00000017CF74: BFA5F68E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37b0>
	s_waitcnt vmcnt(0)                                         // 00000017CF78: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017CF7C: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CF80: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017CF84: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017CF88: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017CF8C: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CF90: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:160          // 00000017CF94: DC5E00A0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CF9C: BE8B2000
	s_cbranch_execz 63112                                      // 00000017CFA0: BFA5F688 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37c4>
	s_waitcnt vmcnt(0)                                         // 00000017CFA4: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017CFA8: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CFAC: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017CFB0: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017CFB4: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017CFB8: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CFBC: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:176          // 00000017CFC0: DC5E00B0 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CFC8: BE8B2000
	s_cbranch_execnz 63106                                     // 00000017CFCC: BFA6F682 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37d8>
	s_branch 63111                                             // 00000017CFD0: BFA0F687 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37f0>
	s_waitcnt vmcnt(0)                                         // 00000017CFD4: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017CFD8: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017CFDC: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017CFE0: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017CFE4: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017CFE8: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017CFEC: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:208          // 00000017CFF0: DC5E00D0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017CFF8: BE8B2000
	s_cbranch_execz 63327                                      // 00000017CFFC: BFA5F75F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b7c>
	s_waitcnt vmcnt(0)                                         // 00000017D000: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017D004: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D008: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017D00C: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017D010: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017D014: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D018: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:224          // 00000017D01C: DC5E00E0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D024: BE8B2000
	s_cbranch_execz 63321                                      // 00000017D028: BFA5F759 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b90>
	s_waitcnt vmcnt(0)                                         // 00000017D02C: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017D030: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D034: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017D038: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017D03C: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017D040: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D044: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:240          // 00000017D048: DC5E00F0 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D050: BE8B2000
	s_cbranch_execnz 63315                                     // 00000017D054: BFA6F753 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ba4>
	s_branch 63320                                             // 00000017D058: BFA0F758 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3bbc>
	s_waitcnt vmcnt(0)                                         // 00000017D05C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017D060: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D064: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017D068: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017D06C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017D070: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D074: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:272          // 00000017D078: DC5E0110 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D080: BE8B2000
	s_cbranch_execz 63540                                      // 00000017D084: BFA5F834 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f58>
	s_waitcnt vmcnt(0)                                         // 00000017D088: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017D08C: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D090: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017D094: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017D098: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017D09C: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D0A0: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:288          // 00000017D0A4: DC5E0120 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D0AC: BE8B2000
	s_cbranch_execz 63534                                      // 00000017D0B0: BFA5F82E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f6c>
	s_waitcnt vmcnt(0)                                         // 00000017D0B4: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017D0B8: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D0BC: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017D0C0: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017D0C4: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017D0C8: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D0CC: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:304          // 00000017D0D0: DC5E0130 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D0D8: BE8B2000
	s_cbranch_execnz 63528                                     // 00000017D0DC: BFA6F828 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f80>
	s_branch 63533                                             // 00000017D0E0: BFA0F82D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f98>
	s_waitcnt vmcnt(0)                                         // 00000017D0E4: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017D0E8: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D0EC: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017D0F0: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017D0F4: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017D0F8: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D0FC: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:336          // 00000017D100: DC5E0150 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D108: BE8B2000
	s_cbranch_execz 63749                                      // 00000017D10C: BFA5F905 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4324>
	s_waitcnt vmcnt(0)                                         // 00000017D110: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017D114: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D118: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017D11C: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017D120: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017D124: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D128: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:352          // 00000017D12C: DC5E0160 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D134: BE8B2000
	s_cbranch_execz 63743                                      // 00000017D138: BFA5F8FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4338>
	s_waitcnt vmcnt(0)                                         // 00000017D13C: BF8903F7
	v_mov_b32_e32 v59, 0                                       // 00000017D140: 7E760280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D144: BF870001
	v_mov_b32_e32 v58, v59                                     // 00000017D148: 7E74033B
	v_mov_b32_e32 v60, v59                                     // 00000017D14C: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 00000017D150: 7E7A033B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D154: 8C7E0B7E
	global_load_b128 v[62:65], v[7:8], off offset:368          // 00000017D158: DC5E0170 3E7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D160: BE8B2000
	s_cbranch_execnz 63737                                     // 00000017D164: BFA6F8F9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x434c>
	s_branch 63742                                             // 00000017D168: BFA0F8FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4364>
	s_waitcnt vmcnt(0)                                         // 00000017D16C: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017D170: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D174: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017D178: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017D17C: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017D180: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D184: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:400          // 00000017D188: DC5E0190 327C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D190: BE8B2000
	s_cbranch_execz 63962                                      // 00000017D194: BFA5F9DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4700>
	s_waitcnt vmcnt(0)                                         // 00000017D198: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017D19C: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D1A0: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017D1A4: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017D1A8: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017D1AC: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D1B0: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:416          // 00000017D1B4: DC5E01A0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D1BC: BE8B2000
	s_cbranch_execz 63956                                      // 00000017D1C0: BFA5F9D4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4714>
	s_waitcnt vmcnt(0)                                         // 00000017D1C4: BF8903F7
	v_mov_b32_e32 v55, 0                                       // 00000017D1C8: 7E6E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D1CC: BF870001
	v_mov_b32_e32 v54, v55                                     // 00000017D1D0: 7E6C0337
	v_mov_b32_e32 v56, v55                                     // 00000017D1D4: 7E700337
	v_mov_b32_e32 v57, v55                                     // 00000017D1D8: 7E720337
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D1DC: 8C7E0B7E
	global_load_b128 v[58:61], v[7:8], off offset:432          // 00000017D1E0: DC5E01B0 3A7C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D1E8: BE8B2000
	s_cbranch_execnz 63950                                     // 00000017D1EC: BFA6F9CE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4728>
	s_branch 63955                                             // 00000017D1F0: BFA0F9D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4740>
	s_waitcnt vmcnt(0)                                         // 00000017D1F4: BF8903F7
	v_mov_b32_e32 v63, 0                                       // 00000017D1F8: 7E7E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D1FC: BF870001
	v_mov_b32_e32 v62, v63                                     // 00000017D200: 7E7C033F
	v_mov_b32_e32 v64, v63                                     // 00000017D204: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 00000017D208: 7E82033F
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D20C: 8C7E0B7E
	global_load_b128 v[3:6], v[7:8], off offset:464            // 00000017D210: DC5E01D0 037C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D218: BE8B2000
	s_cbranch_execz 64171                                      // 00000017D21C: BFA5FAAB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4acc>
	s_waitcnt vmcnt(0)                                         // 00000017D220: BF8903F7
	v_mov_b32_e32 v4, 0                                        // 00000017D224: 7E080280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D228: BF870001
	v_mov_b32_e32 v3, v4                                       // 00000017D22C: 7E060304
	v_mov_b32_e32 v5, v4                                       // 00000017D230: 7E0A0304
	v_mov_b32_e32 v6, v4                                       // 00000017D234: 7E0C0304
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D238: 8C7E0B7E
	global_load_b128 v[50:53], v[7:8], off offset:480          // 00000017D23C: DC5E01E0 327C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D244: BE8B2000
	s_cbranch_execz 64165                                      // 00000017D248: BFA5FAA5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ae0>
	s_waitcnt vmcnt(0)                                         // 00000017D24C: BF8903F7
	v_mov_b32_e32 v51, 0                                       // 00000017D250: 7E660280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D254: BF870001
	v_mov_b32_e32 v50, v51                                     // 00000017D258: 7E640333
	v_mov_b32_e32 v52, v51                                     // 00000017D25C: 7E680333
	v_mov_b32_e32 v53, v51                                     // 00000017D260: 7E6A0333
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017D264: 8C7E0B7E
	global_load_b128 v[54:57], v[7:8], off offset:496          // 00000017D268: DC5E01F0 367C0007
	s_and_saveexec_b32 s11, s0                                 // 00000017D270: BE8B2000
	s_cbranch_execnz 64159                                     // 00000017D274: BFA6FA9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4af4>
	s_branch 64164                                             // 00000017D278: BFA0FAA4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b0c>
	ds_load_b32 v3, v104                                       // 00000017D27C: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D284: BF89FC07
	v_fma_f32 v3, v42, v3, v74                                 // 00000017D288: D6130003 052A072A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D290: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D294: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000017D29C: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D2A8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D2B0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D2B4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D2C0: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D2C8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017D2CC: BE802004
	s_cbranch_execz 64499                                      // 00000017D2D0: BFA5FBF3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50a0>
	ds_load_b32 v3, v104 offset:8                              // 00000017D2D4: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D2DC: BF89FC07
	v_fma_f32 v3, v43, v3, v75                                 // 00000017D2E0: D6130003 052E072B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D2E8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D2EC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000017D2F4: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D300: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D308: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D30C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D318: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D320: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017D324: BE802005
	s_cbranch_execz 64480                                      // 00000017D328: BFA5FBE0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50ac>
	ds_load_b32 v3, v104 offset:16                             // 00000017D32C: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D334: BF89FC07
	v_fma_f32 v3, v44, v3, v76                                 // 00000017D338: D6130003 0532072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D340: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D344: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000017D34C: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D358: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D360: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D364: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D370: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D378: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017D37C: BE802006
	s_cbranch_execz 64461                                      // 00000017D380: BFA5FBCD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50b8>
	ds_load_b32 v3, v104 offset:24                             // 00000017D384: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D38C: BF89FC07
	v_fma_f32 v3, v45, v3, v77                                 // 00000017D390: D6130003 0536072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D398: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D39C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000017D3A4: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D3B0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D3B8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D3BC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D3C8: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D3D0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017D3D4: BE802007
	s_cbranch_execz 64442                                      // 00000017D3D8: BFA5FBBA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50c4>
	ds_load_b32 v3, v104 offset:32                             // 00000017D3DC: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D3E4: BF89FC07
	v_fma_f32 v3, v46, v3, v78                                 // 00000017D3E8: D6130003 053A072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D3F0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D3F4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000017D3FC: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D408: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D410: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D414: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D420: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D428: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017D42C: BE802008
	s_cbranch_execz 64423                                      // 00000017D430: BFA5FBA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50d0>
	ds_load_b32 v3, v104 offset:40                             // 00000017D434: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D43C: BF89FC07
	v_fma_f32 v3, v47, v3, v79                                 // 00000017D440: D6130003 053E072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D448: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D44C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000017D454: D6FE7C03 0552E0FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D460: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D468: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D46C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D478: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D480: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017D484: BE802009
	s_cbranch_execz 64404                                      // 00000017D488: BFA5FB94 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50dc>
	ds_load_b32 v3, v104 offset:48                             // 00000017D48C: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D494: BF89FC07
	v_fma_f32 v3, v48, v3, v80                                 // 00000017D498: D6130003 05420730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D4A0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D4A4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v113, v[84:85]         // 00000017D4AC: D6FE7C03 0552E2FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D4B8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D4C0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D4C4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D4D0: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D4D8: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017D4DC: BE80200A
	s_cbranch_execz 64385                                      // 00000017D4E0: BFA5FB81 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50e8>
	ds_load_b32 v3, v104 offset:56                             // 00000017D4E4: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D4EC: BF89FC07
	v_fmac_f32_e32 v81, v49, v3                                // 00000017D4F0: 56A20731
	v_mad_u64_u32 v[3:4], null, 0x3000, v114, v[84:85]         // 00000017D4F4: D6FE7C03 0552E4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017D500: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v81                          // 00000017D504: 100AA2FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D50C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D514: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D518: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000017D524: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D52C: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017D530: BE802001
	s_cbranch_execz 64367                                      // 00000017D534: BFA5FB6F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50f4>
	ds_load_b32 v3, v104                                       // 00000017D538: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D540: BF89FC07
	v_fma_f32 v3, v34, v3, v66                                 // 00000017D544: D6130003 050A0722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D54C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D550: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000017D558: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D564: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D56C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D570: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D57C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D584: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017D588: BE802004
	s_cbranch_execz 64348                                      // 00000017D58C: BFA5FB5C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5100>
	ds_load_b32 v3, v104 offset:8                              // 00000017D590: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D598: BF89FC07
	v_fma_f32 v3, v35, v3, v67                                 // 00000017D59C: D6130003 050E0723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D5A4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D5A8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000017D5B0: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D5BC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D5C4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D5C8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D5D4: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D5DC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017D5E0: BE802005
	s_cbranch_execz 64329                                      // 00000017D5E4: BFA5FB49 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510c>
	ds_load_b32 v3, v104 offset:16                             // 00000017D5E8: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D5F0: BF89FC07
	v_fma_f32 v3, v36, v3, v68                                 // 00000017D5F4: D6130003 05120724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D5FC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D600: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000017D608: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D614: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D61C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D620: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D62C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D634: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017D638: BE802006
	s_cbranch_execz 64310                                      // 00000017D63C: BFA5FB36 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5118>
	ds_load_b32 v3, v104 offset:24                             // 00000017D640: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D648: BF89FC07
	v_fma_f32 v3, v37, v3, v69                                 // 00000017D64C: D6130003 05160725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D654: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D658: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000017D660: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D66C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D674: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D678: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D684: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D68C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017D690: BE802007
	s_cbranch_execz 64291                                      // 00000017D694: BFA5FB23 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5124>
	ds_load_b32 v3, v104 offset:32                             // 00000017D698: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D6A0: BF89FC07
	v_fma_f32 v3, v38, v3, v70                                 // 00000017D6A4: D6130003 051A0726
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D6AC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D6B0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000017D6B8: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D6C4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D6CC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D6D0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D6DC: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D6E4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017D6E8: BE802008
	s_cbranch_execz 64272                                      // 00000017D6EC: BFA5FB10 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5130>
	ds_load_b32 v3, v104 offset:40                             // 00000017D6F0: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D6F8: BF89FC07
	v_fma_f32 v3, v39, v3, v71                                 // 00000017D6FC: D6130003 051E0727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D704: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D708: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000017D710: D6FE7C03 0552E0FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D71C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D724: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D728: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D734: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D73C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017D740: BE802009
	s_cbranch_execz 64253                                      // 00000017D744: BFA5FAFD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x513c>
	ds_load_b32 v3, v104 offset:48                             // 00000017D748: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D750: BF89FC07
	v_fma_f32 v3, v40, v3, v72                                 // 00000017D754: D6130003 05220728
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D75C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D760: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v113, v[84:85]         // 00000017D768: D6FE7C03 0552E2FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D774: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D77C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D780: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D78C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D794: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017D798: BE80200A
	s_cbranch_execz 64234                                      // 00000017D79C: BFA5FAEA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5148>
	ds_load_b32 v3, v104 offset:56                             // 00000017D7A0: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D7A8: BF89FC07
	v_fmac_f32_e32 v73, v41, v3                                // 00000017D7AC: 56920729
	v_mad_u64_u32 v[3:4], null, 0x3000, v114, v[84:85]         // 00000017D7B0: D6FE7C03 0552E4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017D7BC: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v73                          // 00000017D7C0: 100A92FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D7C8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D7D0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D7D4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000017D7E0: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D7E8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017D7EC: BE802001
	s_cbranch_execz 64216                                      // 00000017D7F0: BFA5FAD8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5154>
	ds_load_b32 v3, v104                                       // 00000017D7F4: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D7FC: BF89FC07
	v_fma_f32 v3, v26, v3, v58                                 // 00000017D800: D6130003 04EA071A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D808: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D80C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000017D814: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D820: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D828: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D82C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D838: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D840: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017D844: BE802004
	s_cbranch_execz 64197                                      // 00000017D848: BFA5FAC5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5160>
	ds_load_b32 v3, v104 offset:8                              // 00000017D84C: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D854: BF89FC07
	v_fma_f32 v3, v27, v3, v59                                 // 00000017D858: D6130003 04EE071B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D860: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D864: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000017D86C: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D878: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D880: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D884: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D890: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D898: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017D89C: BE802005
	s_cbranch_execz 64178                                      // 00000017D8A0: BFA5FAB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x516c>
	ds_load_b32 v3, v104 offset:16                             // 00000017D8A4: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D8AC: BF89FC07
	v_fma_f32 v3, v28, v3, v60                                 // 00000017D8B0: D6130003 04F2071C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D8B8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D8BC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000017D8C4: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D8D0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D8D8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D8DC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D8E8: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D8F0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017D8F4: BE802006
	s_cbranch_execz 64159                                      // 00000017D8F8: BFA5FA9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5178>
	ds_load_b32 v3, v104 offset:24                             // 00000017D8FC: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D904: BF89FC07
	v_fma_f32 v3, v29, v3, v61                                 // 00000017D908: D6130003 04F6071D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D910: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D914: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000017D91C: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D928: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D930: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D934: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D940: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D948: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017D94C: BE802007
	s_cbranch_execz 64140                                      // 00000017D950: BFA5FA8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5184>
	ds_load_b32 v3, v104 offset:32                             // 00000017D954: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D95C: BF89FC07
	v_fma_f32 v3, v30, v3, v62                                 // 00000017D960: D6130003 04FA071E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D968: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D96C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000017D974: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D980: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D988: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D98C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D998: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D9A0: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017D9A4: BE802008
	s_cbranch_execz 64121                                      // 00000017D9A8: BFA5FA79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5190>
	ds_load_b32 v3, v104 offset:40                             // 00000017D9AC: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017D9B4: BF89FC07
	v_fma_f32 v3, v31, v3, v63                                 // 00000017D9B8: D6130003 04FE071F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017D9C0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017D9C4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000017D9CC: D6FE7C03 0552E0FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017D9D8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017D9E0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017D9E4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017D9F0: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017D9F8: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017D9FC: BE802009
	s_cbranch_execz 64102                                      // 00000017DA00: BFA5FA66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x519c>
	ds_load_b32 v3, v104 offset:48                             // 00000017DA04: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DA0C: BF89FC07
	v_fma_f32 v3, v32, v3, v64                                 // 00000017DA10: D6130003 05020720
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DA18: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DA1C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v113, v[84:85]         // 00000017DA24: D6FE7C03 0552E2FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DA30: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DA38: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DA3C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017DA48: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DA50: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017DA54: BE80200A
	s_cbranch_execz 64083                                      // 00000017DA58: BFA5FA53 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51a8>
	ds_load_b32 v3, v104 offset:56                             // 00000017DA5C: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DA64: BF89FC07
	v_fmac_f32_e32 v65, v33, v3                                // 00000017DA68: 56820721
	v_mad_u64_u32 v[3:4], null, 0x3000, v114, v[84:85]         // 00000017DA6C: D6FE7C03 0552E4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017DA78: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v65                          // 00000017DA7C: 100A82FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DA84: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DA8C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DA90: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000017DA9C: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DAA4: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000017DAA8: BE802001
	s_cbranch_execz 64065                                      // 00000017DAAC: BFA5FA41 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51b4>
	ds_load_b32 v3, v104                                       // 00000017DAB0: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DAB8: BF89FC07
	v_fma_f32 v3, v18, v3, v50                                 // 00000017DABC: D6130003 04CA0712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DAC4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DAC8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000017DAD0: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DADC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DAE4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DAE8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DAF4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DAFC: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000017DB00: BE802004
	s_cbranch_execz 64046                                      // 00000017DB04: BFA5FA2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c0>
	ds_load_b32 v3, v104 offset:8                              // 00000017DB08: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DB10: BF89FC07
	v_fma_f32 v3, v19, v3, v51                                 // 00000017DB14: D6130003 04CE0713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DB1C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DB20: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000017DB28: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DB34: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DB3C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DB40: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DB4C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DB54: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000017DB58: BE802005
	s_cbranch_execz 64027                                      // 00000017DB5C: BFA5FA1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51cc>
	ds_load_b32 v3, v104 offset:16                             // 00000017DB60: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DB68: BF89FC07
	v_fma_f32 v3, v20, v3, v52                                 // 00000017DB6C: D6130003 04D20714
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DB74: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DB78: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000017DB80: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DB8C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DB94: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DB98: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DBA4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DBAC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000017DBB0: BE802006
	s_cbranch_execz 64008                                      // 00000017DBB4: BFA5FA08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51d8>
	ds_load_b32 v3, v104 offset:24                             // 00000017DBB8: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DBC0: BF89FC07
	v_fma_f32 v3, v21, v3, v53                                 // 00000017DBC4: D6130003 04D60715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DBCC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DBD0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000017DBD8: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DBE4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DBEC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DBF0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DBFC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DC04: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000017DC08: BE802007
	s_cbranch_execz 63989                                      // 00000017DC0C: BFA5F9F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51e4>
	ds_load_b32 v3, v104 offset:32                             // 00000017DC10: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DC18: BF89FC07
	v_fma_f32 v3, v22, v3, v54                                 // 00000017DC1C: D6130003 04DA0716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DC24: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DC28: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000017DC30: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DC3C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DC44: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DC48: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DC54: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DC5C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000017DC60: BE802008
	s_cbranch_execz 63970                                      // 00000017DC64: BFA5F9E2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51f0>
	ds_load_b32 v3, v104 offset:40                             // 00000017DC68: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DC70: BF89FC07
	v_fma_f32 v3, v23, v3, v55                                 // 00000017DC74: D6130003 04DE0717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DC7C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DC80: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000017DC88: D6FE7C03 0552E0FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DC94: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DC9C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DCA0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DCAC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DCB4: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000017DCB8: BE802009
	s_cbranch_execz 63951                                      // 00000017DCBC: BFA5F9CF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51fc>
	ds_load_b32 v3, v104 offset:48                             // 00000017DCC0: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000017DCC8: BF89FC07
	v_fma_f32 v3, v24, v3, v56                                 // 00000017DCCC: D6130003 04E20718
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017DCD4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000017DCD8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v113, v[84:85]         // 00000017DCE0: D6FE7C03 0552E2FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017DCEC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017DCF4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000017DCF8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017DD04: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017DD0C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000017DD10: BE80200A
	s_cbranch_execnz 63932                                     // 00000017DD14: BFA6F9BC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5208>
	s_branch 63949                                             // 00000017DD18: BFA0F9CD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5250>
	v_mov_b32_e32 v2, v89                                      // 00000017DD1C: 7E040359
	v_mov_b32_e32 v3, v1                                       // 00000017DD20: 7E060301
	s_add_u32 s0, s33, s28                                     // 00000017DD24: 80001C21
	.long 0xd73c0000                                           // 00000017DD28: D73C0000
	v_cndmask_b32_e32 v1, 9, v82, vcc_lo                       // 00000017DD2C: 0202A489
	s_addc_u32 s1, s34, s29                                    // 00000017DD30: 82011D22
	s_add_u32 s2, s30, s26                                     // 00000017DD34: 80021A1E
	s_addc_u32 s3, s31, s27                                    // 00000017DD38: 82031B1F
	s_add_u32 s0, s2, s0                                       // 00000017DD3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000017DD40: 82010103
	v_lshlrev_b32_e32 v4, 2, v88                               // 00000017DD44: 3008B082
	.long 0xd7006a00                                           // 00000017DD48: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000017DD4C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000017DD50: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000017DD54: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000017DD5C: BE810080
	.long 0xd7006a00                                           // 00000017DD60: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 00000017DD64: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000017DD68: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v88                           // 00000017DD70: 1608B0FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017DD78: BF870093
	.long 0xd7006a00                                           // 00000017DD7C: D7006A00
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000017DD80: 02020018
	v_add_co_ci_u32_e64 v1, null, s25, v1, vcc_lo              // 00000017DD84: D5207C01 01AA0219
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017DD8C: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 00000017DD90: D6460003 04110503
	s_nop 0                                                    // 00000017DD98: BF800000
	s_nop 0                                                    // 00000017DD9C: BF800000
	s_nop 0                                                    // 00000017DDA0: BF800000
	s_nop 0                                                    // 00000017DDA4: BF800000
	s_nop 0                                                    // 00000017DDA8: BF800000
	s_nop 0                                                    // 00000017DDAC: BF800000
	s_nop 0                                                    // 00000017DDB0: BF800000
	s_nop 0                                                    // 00000017DDB4: BF800000
	s_nop 0                                                    // 00000017DDB8: BF800000
	s_nop 0                                                    // 00000017DDBC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 00000017DDC0: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 00000017DDC8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000017DDD0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000017DDD4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 00000017DDD8: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000017DDE0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000017DDE4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 00000017DDE8: DC6A0000 007C0400
	.long 0xd7000000                                           // 00000017DDF0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 00000017DDF4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000017DDFC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000017DE04: 917E017E
	s_cbranch_execnz 65517                                     // 00000017DE08: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6bc0>
	s_nop 0                                                    // 00000017DE0C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000017DE10: BFB60003
	s_endpgm                                                   // 00000017DE14: BFB00000
		...

