0000000000084500 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000084500: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000084504: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000008450C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000084514: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000084518: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000008451C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000084520: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000084528: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000008452C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000084530: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000084534: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000008453C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000084540: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000084544: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000084548: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008454C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000084550: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000084554: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000084558: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000008455C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000084564: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000008456C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000084570: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000084574: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000084578: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000008457C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000084580: 821E191E
	.long 0xd7001f02                                           // 000000084584: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000084588: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000008458C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000084594: BE9E0080
	s_nop 0                                                    // 000000084598: BF800000
	s_nop 0                                                    // 00000008459C: BF800000
	s_nop 0                                                    // 0000000845A0: BF800000
	s_nop 0                                                    // 0000000845A4: BF800000
	s_nop 0                                                    // 0000000845A8: BF800000
	s_nop 0                                                    // 0000000845AC: BF800000
	s_nop 0                                                    // 0000000845B0: BF800000
	s_nop 0                                                    // 0000000845B4: BF800000
	s_nop 0                                                    // 0000000845B8: BF800000
	s_nop 0                                                    // 0000000845BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000845C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000845C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000845CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000845D0: 300C1089
	.long 0xd7006a06                                           // 0000000845D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000845D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000845DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000845E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000845E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000845F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000845F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000845FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000084608: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000008460C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000084610: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000084618: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000008461C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000084620: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000084624: F4000780 F8000058
	v_or_b32_e32 v23, 0xffffff80, v0                           // 00000008462C: 382E00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000084634: 32040084
	s_mov_b32 s0, 0                                            // 000000084638: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000008463C: BF89FC07
	s_barrier                                                  // 000000084640: BFBD0000
	buffer_gl0_inv                                             // 000000084644: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000008464C: BF02801E
	s_cbranch_scc1 12                                          // 000000084650: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000084654: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000008465C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000084664: BF870002
	v_lshl_add_u32 v22, v5, 2, v3                              // 000000084668: D6460016 040D0505
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v24, 2, v5      // 000000084670: CA220080 03180A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000084678: 916A007E
	s_cbranch_vccz 2                                           // 00000008467C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 1055                                              // 000000084680: BFA0041F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1200>
	v_lshlrev_b32_e32 v24, 2, v5                               // 000000084684: 30300A82
	s_add_i32 s0, s30, 63                                      // 000000084688: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000008468C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000084694: 85218600
	s_add_u32 s34, s10, s24                                    // 000000084698: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000008469C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000846A0: 84008702
	v_lshlrev_b32_e32 v25, 2, v0                               // 0000000846A4: 30320082
	s_ashr_i32 s1, s0, 31                                      // 0000000846A8: 86019F00
	v_lshlrev_b32_e32 v6, 1, v5                                // 0000000846AC: 300C0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000846B0: 84808100
	v_lshlrev_b32_e32 v12, 8, v2                               // 0000000846B4: 30180488
	s_add_u32 s22, s22, s0                                     // 0000000846B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000846BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000846C0: 848A811A
	v_mad_u32_u24 v22, 0x44, v2, v24                           // 0000000846C4: D60B0016 046204FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000846D0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000846D4: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000846D8: B00A0204
	.long 0xd7000b1d                                           // 0000000846DC: D7000B1D
	v_cndmask_b32_e32 v1, s34, v24, vcc_lo                     // 0000000846E0: 02023022
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000846E4: BF8704B1
	v_add_co_ci_u32_e64 v30, null, s35, 0, s11                 // 0000000846E8: D5207C1E 002D0023
	v_mad_u32_u24 v31, v2, s10, 0x3300                         // 0000000846F0: D60B001F 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000846FC: 848A8902
	v_dual_mov_b32 v15, s11 :: v_dual_add_nc_u32 v28, 1, v2    // 000000084700: CA20000B 0F1C0481
	v_or_b32_e32 v14, s10, v25                                 // 000000084708: 381C320A
	.long 0xd7000a06                                           // 00000008470C: D7000A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000084710: 02020C16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000084714: BF870191
	v_add_co_ci_u32_e64 v7, null, s1, 0, s10                   // 000000084718: D5207C07 00290001
	.long 0xd7000108                                           // 000000084720: D7000108
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 000000084724: 02021C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000084728: BF8700B1
	v_add_co_ci_u32_e64 v9, null, s13, v15, s1                 // 00000008472C: D5207C09 00061E0D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000084734: 848A8E02
	.long 0xd700010a                                           // 000000084738: D700010A
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 00000008473C: 02021C04
	v_add_co_ci_u32_e64 v11, null, s5, v15, s1                 // 000000084740: D5207C0B 00061E05
	s_add_u32 s1, s14, s10                                     // 000000084748: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 00000008474C: 82040B0F
	.long 0xd700010c                                           // 000000084750: D700010C
	v_cndmask_b32_e32 v1, s1, v12, vcc_lo                      // 000000084754: 02021801
	s_delay_alu instid0(VALU_DEP_1)                            // 000000084758: BF870001
	v_add_co_ci_u32_e64 v13, null, s4, 0, s1                   // 00000008475C: D5207C0D 00050004
	.long 0xd700010e                                           // 000000084764: D700010E
	v_cndmask_b32_e32 v1, s6, v14, vcc_lo                      // 000000084768: 02021C06
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v26, 0x4320, v25 // 00000008476C: CA200080 031A32FF 00004320
	v_add_nc_u32_e32 v27, 0x4420, v25                          // 000000084778: 4A3632FF 00004420
	.long 0xd44c0000                                           // 000000084780: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000084784: 020200FF 00000080
	v_add_nc_u32_e32 v4, 0x2200, v22                           // 00000008478C: 4A082CFF 00002200
	v_or_b32_e32 v5, 0x2200, v1                                // 000000084794: 380A02FF 00002200
	v_add_co_ci_u32_e64 v15, null, s7, v15, s1                 // 00000008479C: D5207C0F 00061E07
	s_mov_b32 s5, 0                                            // 0000000847A4: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000847A8: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000847AC: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000847B4: BF870499
	s_add_i32 s6, s31, s1                                      // 0000000847B8: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000000847BC: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000847C0: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000000847C4: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000000847C8: 84078605
	s_add_u32 s10, s8, s10                                     // 0000000847CC: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000000847D0: 820B0B09
	global_load_b32 v16, v3, s[10:11]                          // 0000000847D4: DC520000 100A0003
	s_waitcnt vmcnt(0)                                         // 0000000847DC: BF8903F7
	v_readfirstlane_b32 s6, v16                                // 0000000847E0: 7E0C0510
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000847E4: BE84206A
	s_cbranch_execz 77                                         // 0000000847E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x420>
	v_or_b32_e32 v16, s7, v0                                   // 0000000847EC: 38200007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000847F0: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[2:3]              // 0000000847F4: D6FE7C10 00096110
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000000847FC: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084800: BF870091
	.long 0xd73c0010                                           // 000000084804: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000084808: 02022082
	.long 0xd7000110                                           // 00000008480C: D7000110
	v_cndmask_b32_e32 v1, s8, v16, vcc_lo                      // 000000084810: 02022008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000084814: BF8700C1
	v_add_co_ci_u32_e64 v17, null, s9, v17, s1                 // 000000084818: D5207C11 00062209
	global_load_b32 v16, v[16:17], off                         // 000000084820: DC520000 107C0010
	s_waitcnt vmcnt(0)                                         // 000000084828: BF8903F7
	v_sub_f32_e32 v17, s6, v16                                 // 00000008482C: 08222006
	v_dual_mul_f32 v19, 0x3fb8aa3b, v16 :: v_dual_mul_f32 v18, 0x3fb8aa3b, v17// 000000084830: C8C620FF 131222FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000008483C: BF8701A1
	v_fma_f32 v32, 0x3fb8aa3b, v16, -v19                       // 000000084840: D6130020 844E20FF 3FB8AA3B
	v_rndne_f32_e32 v33, v19                                   // 00000008484C: 7E424713
	v_fma_f32 v20, 0x3fb8aa3b, v17, -v18                       // 000000084850: D6130014 844A22FF 3FB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 00000008485C: 7E2A4712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000084860: BF870113
	v_dual_fmac_f32 v32, 0x32a5705f, v16 :: v_dual_sub_f32 v19, v19, v33// 000000084864: C80A20FF 20124313 32A5705F
	v_sub_f32_e32 v18, v18, v21                                // 000000084870: 08242B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084874: BF870122
	v_dual_fmac_f32 v20, 0x32a5705f, v17 :: v_dual_add_f32 v19, v19, v32// 000000084878: C80822FF 14124113 32A5705F
	.long 0xd41b0001                                           // 000000084884: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v17, vcc_lo              // 000000084888: 020222FF C2CE8ED0
	v_add_f32_e32 v18, v18, v20                                // 000000084890: 06242912
	v_cvt_i32_f32_e32 v20, v21                                 // 000000084894: 7E281115
	v_cvt_i32_f32_e32 v21, v33                                 // 000000084898: 7E2A1121
	v_exp_f32_e32 v19, v19                                     // 00000008489C: 7E264B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000848A0: BF870313
	v_exp_f32_e32 v18, v18                                     // 0000000848A4: 7E244B12
	.long 0xd71c0013                                           // 0000000848A8: D71C0013
	v_cndmask_b32_e32 v1, v19, v21, vcc_lo                     // 0000000848AC: 02022B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000848B0: BF870095
	.long 0xd71c0012                                           // 0000000848B4: D71C0012
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000000848B8: 02022912
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000000848BC: D5010012 00062480
	.long 0xd41b0001                                           // 0000000848C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v16, vcc_lo              // 0000000848C8: 020220FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000848D0: BF8700A1
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000000848D4: D5010013 00062680
	.long 0xd41e0001                                           // 0000000848DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v17, vcc_lo              // 0000000848E0: 020222FF 42B17218
	v_cndmask_b32_e64 v17, 0x7f800000, v18, s1                 // 0000000848E8: D5010011 000624FF 7F800000
	.long 0xd41e0001                                           // 0000000848F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v16, vcc_lo              // 0000000848F8: 020220FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000084900: BF870001
	v_cndmask_b32_e64 v16, 0x7f800000, v19, s1                 // 000000084904: D5010010 000626FF 7F800000
	ds_store_b32 v26, v17                                      // 000000084910: D8340000 0000111A
	ds_store_b32 v27, v16                                      // 000000084918: D8340000 0000101B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000084920: 8C7E047E
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v16, v8           // 000000084924: CA100109 11100108
	s_mov_b32 s10, 0                                           // 00000008492C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000084930: BF89FC07
	s_barrier                                                  // 000000084934: BFBD0000
	buffer_gl0_inv                                             // 000000084938: E0AC0000 00000000
	s_branch 15                                                // 000000084940: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x480>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000084944: 8C7E047E
	.long 0xd7000110                                           // 000000084948: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 00000008494C: 020220FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000084954: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000084958: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 000000084960: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000084964: BF08B70A
	s_mov_b32 s10, s1                                          // 000000084968: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000008496C: BF89FC07
	s_barrier                                                  // 000000084970: BFBD0000
	buffer_gl0_inv                                             // 000000084974: E0AC0000 00000000
	s_cbranch_scc1 227                                         // 00000008497C: BFA200E3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x80c>
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 000000084980: CA100111 13120110
	v_dual_mov_b32 v20, v25 :: v_dual_mov_b32 v21, v23         // 000000084988: CA100119 14140117
	s_mov_b32 s11, 0                                           // 000000084990: BE8B0080
	s_nop 0                                                    // 000000084994: BF800000
	s_nop 0                                                    // 000000084998: BF800000
	s_nop 0                                                    // 00000008499C: BF800000
	s_nop 0                                                    // 0000000849A0: BF800000
	s_nop 0                                                    // 0000000849A4: BF800000
	s_nop 0                                                    // 0000000849A8: BF800000
	s_nop 0                                                    // 0000000849AC: BF800000
	s_nop 0                                                    // 0000000849B0: BF800000
	s_nop 0                                                    // 0000000849B4: BF800000
	s_nop 0                                                    // 0000000849B8: BF800000
	s_nop 0                                                    // 0000000849BC: BF800000
	global_load_b32 v32, v[18:19], off                         // 0000000849C0: DC520000 207C0012
	v_add_nc_u32_e32 v21, 0x80, v21                            // 0000000849C8: 4A2A2AFF 00000080
	.long 0xd7000112                                           // 0000000849D0: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 0000000849D4: 020224FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000849DC: BF870191
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 0000000849E0: D5207C13 00062680
	.long 0xd4490004                                           // 0000000849E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v21, vcc_lo                   // 0000000849EC: 02022AFF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000000849F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000000849F8: BF8903F7
	ds_store_b32 v20, v32 offset:13056                         // 0000000849FC: D8343300 00002014
	v_add_nc_u32_e32 v20, 0x204, v20                           // 000000084A04: 4A2828FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000084A0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000084A10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000084A14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000084A18: BF89FC07
	s_barrier                                                  // 000000084A1C: BFBD0000
	buffer_gl0_inv                                             // 000000084A20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000084A28: BE842000
	s_cbranch_execz 65477                                      // 000000084A2C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x444>
	v_or3_b32 v18, s10, s7, v2                                 // 000000084A30: D6580012 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A38: BF870091
	v_mad_u64_u32 v[18:19], null, v18, 48, s[2:3]              // 000000084A3C: D6FE7C12 00096112
	.long 0xd73c0012                                           // 000000084A44: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000084A48: 02022489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A4C: BF870091
	.long 0xd7000112                                           // 000000084A50: D7000112
	v_cndmask_b32_e32 v1, v29, v18, vcc_lo                     // 000000084A54: 0202251D
	v_add_co_ci_u32_e64 v19, null, v30, v19, s1                // 000000084A58: D5207C13 0006271E
	s_mov_b32 s1, 0                                            // 000000084A60: BE810080
	global_load_b32 v18, v[18:19], off                         // 000000084A64: DC520000 127C0012
	v_mad_u64_u32 v[19:20], null, 0x44, s1, v[1:2]             // 000000084A6C: D6FE7C13 040402FF 00000044
	s_add_i32 s11, s1, 8                                       // 000000084A78: 810B8801
	s_cmpk_lt_u32 s1, 0x78                                     // 000000084A7C: B6810078
	ds_load_2addr_b32 v[20:21], v19 offset1:17                 // 000000084A80: D8DC1100 14000013
	ds_load_2addr_b32 v[32:33], v19 offset0:34 offset1:51      // 000000084A88: D8DC3322 20000013
	ds_load_2addr_b32 v[34:35], v19 offset0:68 offset1:85      // 000000084A90: D8DC5544 22000013
	ds_load_2addr_b32 v[36:37], v19 offset0:102 offset1:119    // 000000084A98: D8DC7766 24000013
	v_lshl_add_u32 v19, s1, 2, v31                             // 000000084AA0: D6460013 047D0401
	s_mov_b32 s1, s11                                          // 000000084AA8: BE81000B
	ds_load_2addr_b32 v[38:39], v19 offset1:1                  // 000000084AAC: D8DC0100 26000013
	ds_load_2addr_b32 v[40:41], v19 offset0:2 offset1:3        // 000000084AB4: D8DC0302 28000013
	ds_load_2addr_b32 v[42:43], v19 offset0:4 offset1:5        // 000000084ABC: D8DC0504 2A000013
	ds_load_2addr_b32 v[44:45], v19 offset0:6 offset1:7        // 000000084AC4: D8DC0706 2C000013
	s_waitcnt lgkmcnt(7)                                       // 000000084ACC: BF89FC77
	v_bfe_u32 v19, v20, 16, 1                                  // 000000084AD0: D6100013 02052114
	v_bfe_u32 v46, v21, 16, 1                                  // 000000084AD8: D610002E 02052115
	s_waitcnt lgkmcnt(6)                                       // 000000084AE0: BF89FC67
	v_bfe_u32 v47, v32, 16, 1                                  // 000000084AE4: D610002F 02052120
	v_bfe_u32 v48, v33, 16, 1                                  // 000000084AEC: D6100030 02052121
	s_waitcnt lgkmcnt(5)                                       // 000000084AF4: BF89FC57
	v_bfe_u32 v49, v34, 16, 1                                  // 000000084AF8: D6100031 02052122
	v_add3_u32 v19, v20, v19, 0x7fff                           // 000000084B00: D6550013 03FE2714 00007FFF
	v_add3_u32 v21, v21, v46, 0x7fff                           // 000000084B0C: D6550015 03FE5D15 00007FFF
	v_add3_u32 v32, v32, v47, 0x7fff                           // 000000084B18: D6550020 03FE5F20 00007FFF
	v_bfe_u32 v50, v35, 16, 1                                  // 000000084B24: D6100032 02052123
	s_waitcnt lgkmcnt(3)                                       // 000000084B2C: BF89FC37
	v_bfe_u32 v53, v38, 16, 1                                  // 000000084B30: D6100035 02052126
	v_bfe_u32 v54, v39, 16, 1                                  // 000000084B38: D6100036 02052127
	s_waitcnt lgkmcnt(2)                                       // 000000084B40: BF89FC27
	v_bfe_u32 v55, v40, 16, 1                                  // 000000084B44: D6100037 02052128
	v_and_b32_e32 v19, 0xffff0000, v19                         // 000000084B4C: 362626FF FFFF0000
	v_bfe_u32 v56, v41, 16, 1                                  // 000000084B54: D6100038 02052129
	v_add3_u32 v20, v38, v53, 0x7fff                           // 000000084B5C: D6550014 03FE6B26 00007FFF
	v_add3_u32 v39, v39, v54, 0x7fff                           // 000000084B68: D6550027 03FE6D27 00007FFF
	v_add3_u32 v40, v40, v55, 0x7fff                           // 000000084B74: D6550028 03FE6F28 00007FFF
	v_and_b32_e32 v21, 0xffff0000, v21                         // 000000084B80: 362A2AFF FFFF0000
	s_waitcnt lgkmcnt(1)                                       // 000000084B88: BF89FC17
	v_bfe_u32 v57, v42, 16, 1                                  // 000000084B8C: D6100039 0205212A
	v_and_b32_e32 v20, 0xffff0000, v20                         // 000000084B94: 362828FF FFFF0000
	v_and_b32_e32 v39, 0xffff0000, v39                         // 000000084B9C: 364E4EFF FFFF0000
	v_and_b32_e32 v32, 0xffff0000, v32                         // 000000084BA4: 364040FF FFFF0000
	v_bfe_u32 v58, v43, 16, 1                                  // 000000084BAC: D610003A 0205212B
	v_bfe_u32 v51, v36, 16, 1                                  // 000000084BB4: D6100033 02052124
	s_waitcnt vmcnt(0)                                         // 000000084BBC: BF8903F7
	v_fma_f32 v18, -v20, v19, v18                              // 000000084BC0: D6130012 244A2714
	v_add3_u32 v19, v33, v48, 0x7fff                           // 000000084BC8: D6550013 03FE6121 00007FFF
	v_add3_u32 v20, v41, v56, 0x7fff                           // 000000084BD4: D6550014 03FE7129 00007FFF
	v_and_b32_e32 v33, 0xffff0000, v40                         // 000000084BE0: 364250FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 000000084BE8: BF89FC07
	v_bfe_u32 v59, v44, 16, 1                                  // 000000084BEC: D610003B 0205212C
	v_fma_f32 v18, -v39, v21, v18                              // 000000084BF4: D6130012 244A2B27
	v_add3_u32 v21, v34, v49, 0x7fff                           // 000000084BFC: D6550015 03FE6322 00007FFF
	v_add3_u32 v34, v42, v57, 0x7fff                           // 000000084C08: D6550022 03FE732A 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v19                         // 000000084C14: 362626FF FFFF0000
	v_and_b32_e32 v20, 0xffff0000, v20                         // 000000084C1C: 362828FF FFFF0000
	v_fma_f32 v18, -v33, v32, v18                              // 000000084C24: D6130012 244A4121
	v_add3_u32 v32, v35, v50, 0x7fff                           // 000000084C2C: D6550020 03FE6523 00007FFF
	v_add3_u32 v33, v43, v58, 0x7fff                           // 000000084C38: D6550021 03FE752B 00007FFF
	v_and_b32_e32 v21, 0xffff0000, v21                         // 000000084C44: 362A2AFF FFFF0000
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000084C4C: 364444FF FFFF0000
	v_fma_f32 v18, -v20, v19, v18                              // 000000084C54: D6130012 244A2714
	v_bfe_u32 v52, v37, 16, 1                                  // 000000084C5C: D6100034 02052125
	v_bfe_u32 v38, v45, 16, 1                                  // 000000084C64: D6100026 0205212D
	v_add3_u32 v19, v36, v51, 0x7fff                           // 000000084C6C: D6550013 03FE6724 00007FFF
	v_add3_u32 v20, v44, v59, 0x7fff                           // 000000084C78: D6550014 03FE772C 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 000000084C84: 364040FF FFFF0000
	v_and_b32_e32 v33, 0xffff0000, v33                         // 000000084C8C: 364242FF FFFF0000
	v_fma_f32 v18, -v34, v21, v18                              // 000000084C94: D6130012 244A2B22
	v_add3_u32 v21, v37, v52, 0x7fff                           // 000000084C9C: D6550015 03FE6925 00007FFF
	v_add3_u32 v34, v45, v38, 0x7fff                           // 000000084CA8: D6550022 03FE4D2D 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v19                         // 000000084CB4: 362626FF FFFF0000
	v_and_b32_e32 v20, 0xffff0000, v20                         // 000000084CBC: 362828FF FFFF0000
	v_fma_f32 v18, -v33, v32, v18                              // 000000084CC4: D6130012 244A4121
	v_and_b32_e32 v21, 0xffff0000, v21                         // 000000084CCC: 362A2AFF FFFF0000
	v_and_b32_e32 v32, 0xffff0000, v34                         // 000000084CD4: 364044FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084CDC: BF870093
	v_fma_f32 v18, -v20, v19, v18                              // 000000084CE0: D6130012 244A2714
	v_fma_f32 v18, -v32, v21, v18                              // 000000084CE8: D6130012 244A2B20
	s_cbranch_scc1 65374                                       // 000000084CF0: BFA2FF5E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x56c>
	v_mad_u64_u32 v[19:20], null, 0x44, s10, v[4:5]            // 000000084CF4: D6FE7C13 041014FF 00000044
	ds_store_b32 v19, v18                                      // 000000084D00: D8340000 00001213
	s_branch 65294                                             // 000000084D08: BFA0FF0E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x444>
	v_mov_b32_e32 v17, v13                                     // 000000084D0C: 7E22030D
	v_dual_mov_b32 v19, v11 :: v_dual_mov_b32 v16, v12         // 000000084D10: CA10010B 1310010C
	v_mov_b32_e32 v18, v10                                     // 000000084D18: 7E24030A
	v_mov_b32_e32 v32, v28                                     // 000000084D1C: 7E40031C
	s_mov_b32 s10, 0                                           // 000000084D20: BE8A0080
	s_branch 21                                                // 000000084D24: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x87c>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000084D28: 8C7E0B7E
	.long 0xd7000112                                           // 000000084D2C: D7000112
	v_cndmask_b32_e32 v1, 0x30000, v18, vcc_lo                 // 000000084D30: 020224FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000084D38: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000084D3C: D5207C13 00062680
	.long 0xd7000110                                           // 000000084D44: D7000110
	v_cndmask_b32_e32 v1, 0x800, v16, vcc_lo                   // 000000084D48: 020220FF 00000800
	v_add_nc_u32_e32 v32, 8, v32                               // 000000084D50: 4A404088
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000084D54: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 000000084D5C: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000084D60: BF08B70A
	s_mov_b32 s10, s1                                          // 000000084D64: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 000000084D68: BC7C0000
	s_barrier                                                  // 000000084D6C: BFBD0000
	buffer_gl0_inv                                             // 000000084D70: E0AC0000 00000000
	s_cbranch_scc1 275                                         // 000000084D78: BFA20113 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcc8>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000084D7C: BF870002
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v20, v18         // 000000084D80: CA100113 15140112
	v_dual_mov_b32 v33, v25 :: v_dual_mov_b32 v34, v23         // 000000084D88: CA100119 21220117
	s_mov_b32 s11, 0                                           // 000000084D90: BE8B0080
	s_nop 0                                                    // 000000084D94: BF800000
	s_nop 0                                                    // 000000084D98: BF800000
	s_nop 0                                                    // 000000084D9C: BF800000
	s_nop 0                                                    // 000000084DA0: BF800000
	s_nop 0                                                    // 000000084DA4: BF800000
	s_nop 0                                                    // 000000084DA8: BF800000
	s_nop 0                                                    // 000000084DAC: BF800000
	s_nop 0                                                    // 000000084DB0: BF800000
	s_nop 0                                                    // 000000084DB4: BF800000
	s_nop 0                                                    // 000000084DB8: BF800000
	s_nop 0                                                    // 000000084DBC: BF800000
	global_load_b32 v35, v[20:21], off                         // 000000084DC0: DC520000 237C0014
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000084DC8: 4A4444FF 00000080
	.long 0xd7000114                                           // 000000084DD0: D7000114
	v_cndmask_b32_e32 v1, 0x6000, v20, vcc_lo                  // 000000084DD4: 020228FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000084DDC: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 000000084DE0: D5207C15 00062A80
	.long 0xd4490004                                           // 000000084DE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000084DEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000084DF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000084DF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 000000084DFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000084E04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000084E0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000084E10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000084E14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000084E18: BF89FC07
	s_barrier                                                  // 000000084E1C: BFBD0000
	buffer_gl0_inv                                             // 000000084E20: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000084E28: BE8B2000
	s_cbranch_execz 65470                                      // 000000084E2C: BFA5FFBE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x828>
	v_or_b32_e32 v20, s10, v2                                  // 000000084E30: 3828040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084E34: BF870091
	v_or_b32_e32 v33, s7, v20                                  // 000000084E38: 38422807
	.long 0xd4440001                                           // 000000084E3C: D4440001
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 000000084E40: 0202421E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000084E44: 8B7E017E
	s_cbranch_execz 65463                                      // 000000084E48: BFA5FFB7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x828>
	v_mov_b32_e32 v34, 0                                       // 000000084E4C: 7E440280
	s_mov_b32 s1, 0                                            // 000000084E50: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000084E54: BF870009
	v_lshl_add_u32 v21, s1, 2, v31                             // 000000084E58: D6460015 047D0401
	s_add_i32 s4, s1, 8                                        // 000000084E60: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 000000084E64: B6810078
	ds_load_2addr_b32 v[44:45], v21 offset0:6 offset1:7        // 000000084E68: D8DC0706 2C000015
	ds_load_2addr_b32 v[46:47], v21 offset1:1                  // 000000084E70: D8DC0100 2E000015
	ds_load_2addr_b32 v[48:49], v21 offset0:4 offset1:5        // 000000084E78: D8DC0504 30000015
	ds_load_2addr_b32 v[50:51], v21 offset0:2 offset1:3        // 000000084E80: D8DC0302 32000015
	v_mad_u64_u32 v[35:36], null, 0x44, s1, v[1:2]             // 000000084E88: D6FE7C23 040402FF 00000044
	s_mov_b32 s1, s4                                           // 000000084E94: BE810004
	ds_load_2addr_b32 v[36:37], v35 offset1:17                 // 000000084E98: D8DC1100 24000023
	ds_load_2addr_b32 v[40:41], v35 offset0:34 offset1:51      // 000000084EA0: D8DC3322 28000023
	ds_load_2addr_b32 v[42:43], v35 offset0:68 offset1:85      // 000000084EA8: D8DC5544 2A000023
	ds_load_2addr_b32 v[38:39], v35 offset0:102 offset1:119    // 000000084EB0: D8DC7766 26000023
	s_waitcnt lgkmcnt(7)                                       // 000000084EB8: BF89FC77
	v_bfe_u32 v59, v44, 16, 1                                  // 000000084EBC: D610003B 0205212C
	s_waitcnt lgkmcnt(6)                                       // 000000084EC4: BF89FC67
	v_bfe_u32 v61, v46, 16, 1                                  // 000000084EC8: D610003D 0205212E
	v_bfe_u32 v64, v47, 16, 1                                  // 000000084ED0: D6100040 0205212F
	s_waitcnt lgkmcnt(4)                                       // 000000084ED8: BF89FC47
	v_bfe_u32 v63, v51, 16, 1                                  // 000000084EDC: D610003F 02052133
	v_bfe_u32 v62, v48, 16, 1                                  // 000000084EE4: D610003E 02052130
	v_bfe_u32 v60, v49, 16, 1                                  // 000000084EEC: D610003C 02052131
	v_add3_u32 v46, v46, v61, 0x7fff                           // 000000084EF4: D655002E 03FE7B2E 00007FFF
	v_add3_u32 v47, v47, v64, 0x7fff                           // 000000084F00: D655002F 03FE812F 00007FFF
	v_bfe_u32 v58, v45, 16, 1                                  // 000000084F0C: D610003A 0205212D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000084F14: BF870003
	v_and_b32_e32 v46, 0xffff0000, v46                         // 000000084F18: 365C5CFF FFFF0000
	s_waitcnt lgkmcnt(3)                                       // 000000084F20: BF89FC37
	v_bfe_u32 v57, v36, 16, 1                                  // 000000084F24: D6100039 02052124
	v_bfe_u32 v56, v37, 16, 1                                  // 000000084F2C: D6100038 02052125
	s_waitcnt lgkmcnt(2)                                       // 000000084F34: BF89FC27
	v_bfe_u32 v55, v40, 16, 1                                  // 000000084F38: D6100037 02052128
	v_bfe_u32 v54, v41, 16, 1                                  // 000000084F40: D6100036 02052129
	v_and_b32_e32 v47, 0xffff0000, v47                         // 000000084F48: 365E5EFF FFFF0000
	v_add3_u32 v36, v36, v57, 0x7fff                           // 000000084F50: D6550024 03FE7324 00007FFF
	v_bfe_u32 v57, v50, 16, 1                                  // 000000084F5C: D6100039 02052132
	v_add3_u32 v37, v37, v56, 0x7fff                           // 000000084F64: D6550025 03FE7125 00007FFF
	v_add3_u32 v40, v40, v55, 0x7fff                           // 000000084F70: D6550028 03FE6F28 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 000000084F7C: BF89FC17
	v_bfe_u32 v53, v42, 16, 1                                  // 000000084F80: D6100035 0205212A
	v_and_b32_e32 v36, 0xffff0000, v36                         // 000000084F88: 364848FF FFFF0000
	v_add3_u32 v50, v50, v57, 0x7fff                           // 000000084F90: D6550032 03FE7332 00007FFF
	v_and_b32_e32 v37, 0xffff0000, v37                         // 000000084F9C: 364A4AFF FFFF0000
	v_and_b32_e32 v40, 0xffff0000, v40                         // 000000084FA4: 365050FF FFFF0000
	v_bfe_u32 v52, v43, 16, 1                                  // 000000084FAC: D6100034 0205212B
	v_fmac_f32_e32 v34, v46, v36                               // 000000084FB4: 5644492E
	v_add3_u32 v36, v41, v54, 0x7fff                           // 000000084FB8: D6550024 03FE6D29 00007FFF
	v_add3_u32 v41, v51, v63, 0x7fff                           // 000000084FC4: D6550029 03FE7F33 00007FFF
	v_and_b32_e32 v46, 0xffff0000, v50                         // 000000084FD0: 365C64FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 000000084FD8: BF89FC07
	v_bfe_u32 v35, v38, 16, 1                                  // 000000084FDC: D6100023 02052126
	v_fmac_f32_e32 v34, v47, v37                               // 000000084FE4: 56444B2F
	v_add3_u32 v37, v42, v53, 0x7fff                           // 000000084FE8: D6550025 03FE6B2A 00007FFF
	v_add3_u32 v42, v48, v62, 0x7fff                           // 000000084FF4: D655002A 03FE7D30 00007FFF
	v_and_b32_e32 v36, 0xffff0000, v36                         // 000000085000: 364848FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000085008: BF870004
	v_dual_fmac_f32 v34, v46, v40 :: v_dual_and_b32 v41, 0xffff0000, v41// 00000008500C: C824512E 222852FF FFFF0000
	v_add3_u32 v40, v43, v52, 0x7fff                           // 000000085018: D6550028 03FE692B 00007FFF
	v_add3_u32 v43, v49, v60, 0x7fff                           // 000000085024: D655002B 03FE7931 00007FFF
	v_and_b32_e32 v37, 0xffff0000, v37                         // 000000085030: 364A4AFF FFFF0000
	v_and_b32_e32 v42, 0xffff0000, v42                         // 000000085038: 365454FF FFFF0000
	v_fmac_f32_e32 v34, v41, v36                               // 000000085040: 56444929
	v_bfe_u32 v21, v39, 16, 1                                  // 000000085044: D6100015 02052127
	v_add3_u32 v35, v38, v35, 0x7fff                           // 00000008504C: D6550023 03FE4726 00007FFF
	v_add3_u32 v36, v44, v59, 0x7fff                           // 000000085058: D6550024 03FE772C 00007FFF
	v_and_b32_e32 v38, 0xffff0000, v40                         // 000000085064: 364C50FF FFFF0000
	v_and_b32_e32 v40, 0xffff0000, v43                         // 00000008506C: 365056FF FFFF0000
	v_fmac_f32_e32 v34, v42, v37                               // 000000085074: 56444B2A
	v_add3_u32 v21, v39, v21, 0x7fff                           // 000000085078: D6550015 03FE2B27 00007FFF
	v_add3_u32 v37, v45, v58, 0x7fff                           // 000000085084: D6550025 03FE752D 00007FFF
	v_and_b32_e32 v35, 0xffff0000, v35                         // 000000085090: 364646FF FFFF0000
	v_and_b32_e32 v36, 0xffff0000, v36                         // 000000085098: 364848FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000850A0: BF870214
	v_dual_fmac_f32 v34, v40, v38 :: v_dual_and_b32 v21, 0xffff0000, v21// 0000000850A4: C8244D28 22142AFF FFFF0000
	v_and_b32_e32 v37, 0xffff0000, v37                         // 0000000850B0: 364A4AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000850B8: BF870092
	v_fmac_f32_e32 v34, v36, v35                               // 0000000850BC: 56444724
	v_fmac_f32_e32 v34, v37, v21                               // 0000000850C0: 56442B25
	s_cbranch_scc1 65379                                       // 0000000850C4: BFA2FF63 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v35, v1 :: v_dual_lshlrev_b32 v20, 2, v20   // 0000000850C8: CA220101 23142882
	s_mov_b32 s12, 0                                           // 0000000850D0: BE8C0080
	ds_load_b32 v36, v20 offset:17440                          // 0000000850D4: D8D84420 24000014
	v_dual_mov_b32 v21, v17 :: v_dual_mov_b32 v20, v16         // 0000000850DC: CA100111 15140110
	s_waitcnt lgkmcnt(0)                                       // 0000000850E4: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000850E8: 10444922
	v_mov_b32_e32 v36, v32                                     // 0000000850EC: 7E480320
	s_nop 0                                                    // 0000000850F0: BF800000
	s_nop 0                                                    // 0000000850F4: BF800000
	s_nop 0                                                    // 0000000850F8: BF800000
	s_nop 0                                                    // 0000000850FC: BF800000
	global_load_b32 v37, v[20:21], off                         // 000000085100: DC520000 257C0014
	ds_load_b32 v38, v35 offset:8704                           // 000000085108: D8D82200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 000000085110: 4A4848C1
	.long 0xd7000114                                           // 000000085114: D7000114
	v_cndmask_b32_e32 v0, v20, v132, vcc_lo                    // 000000085118: 02010914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008511C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 000000085120: D5207C15 00062A80
	.long 0xd44a0004                                           // 000000085128: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 00000008512C: 02024880
	v_add_nc_u32_e32 v35, 0x44, v35                            // 000000085130: 4A4646FF 00000044
	s_or_b32 s12, s4, s12                                      // 000000085138: 8C0C0C04
	s_waitcnt lgkmcnt(0)                                       // 00000008513C: BF89FC07
	v_bfe_u32 v39, v38, 16, 1                                  // 000000085140: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085148: BF870091
	v_add3_u32 v38, v38, v39, 0x7fff                           // 00000008514C: D6550026 03FE4F26 00007FFF
	v_and_b32_e32 v38, 0xffff0000, v38                         // 000000085158: 364C4CFF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000085160: BF8903F7
	v_bfe_u32 v40, v37, 16, 1                                  // 000000085164: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008516C: BF870091
	v_add3_u32 v37, v37, v40, 0x7fff                           // 000000085170: D6550025 03FE5125 00007FFF
	v_and_b32_e32 v37, 0xffff0000, v37                         // 00000008517C: 364A4AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085184: BF870001
	v_fmac_f32_e32 v34, v37, v38                               // 000000085188: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000008518C: 917E0C7E
	s_cbranch_execnz 65499                                     // 000000085190: BFA6FFDB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc00>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000085194: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085198: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 00000008519C: D6100023 02052122
	v_mad_u64_u32 v[20:21], null, 0x3000, v33, v[6:7]          // 0000000851A4: D6FE7C14 041A42FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000851B0: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[20:21], v33, off                 // 0000000851BC: DC960000 007C2114
	s_branch 65240                                             // 0000000851C4: BFA0FED8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x828>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 0000000851C8: A201FF06 3FB8AA3B
	v_mov_b32_e32 v18, v23                                     // 0000000851D0: 7E240317
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000851D4: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000851D8: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 0000000851E0: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 0000000851E4: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 0000000851EC: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 0000000851F4: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000851F8: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 0000000851FC: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000085204: A0010401
	s_mov_b32 s4, 0                                            // 000000085208: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000008520C: BF87000A
	v_exp_f32_e32 v16, s1                                      // 000000085210: 7E204A01
	s_cvt_i32_f32 s1, s7                                       // 000000085214: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000085218: BF870585
	.long 0xd71c0010                                           // 00000008521C: D71C0010
	v_cndmask_b32_e32 v0, v16, v1, vcc_lo                      // 000000085220: 02000310
	s_cselect_b32 s1, -1, 0                                    // 000000085224: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000085228: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000085230: BF870131
	v_cndmask_b32_e64 v17, 0, v16, s1                          // 000000085234: D5010011 00062080
	s_cselect_b32 s1, -1, 0                                    // 00000008523C: 980180C1
	v_mov_b32_e32 v16, v22                                     // 000000085240: 7E200316
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 000000085244: D5010011 000622FF 7F800000
	ds_load_b32 v19, v16                                       // 000000085250: D8D80000 13000010
	v_add_nc_u32_e32 v18, 0x80, v18                            // 000000085258: 4A2424FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085260: BF870001
	.long 0xd4490001                                           // 000000085264: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v18, vcc_lo                   // 000000085268: 020224FF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000085270: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000085274: BF89FC07
	v_mul_f32_e32 v19, v17, v19                                // 000000085278: 10262711
	ds_store_b32 v16, v19                                      // 00000008527C: D8340000 00001310
	v_add_nc_u32_e32 v16, 0x220, v16                           // 000000085284: 4A2020FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008528C: 917E047E
	s_cbranch_execnz 65519                                     // 000000085290: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd50>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000085294: 8C7E047E
	v_dual_mov_b32 v17, v15 :: v_dual_mov_b32 v16, v14         // 000000085298: CA10010F 1110010E
	v_mov_b32_e32 v20, 0                                       // 0000000852A0: 7E280280
	s_mov_b32 s6, 0                                            // 0000000852A4: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000852A8: BF870112
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 0000000852AC: CA100111 13120110
	v_dual_mov_b32 v21, v20 :: v_dual_mov_b32 v32, v25         // 0000000852B4: CA100114 15200119
	v_mov_b32_e32 v33, v23                                     // 0000000852BC: 7E420317
	s_mov_b32 s7, 0                                            // 0000000852C0: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000852C4: BF89FC07
	s_barrier                                                  // 0000000852C8: BFBD0000
	buffer_gl0_inv                                             // 0000000852CC: E0AC0000 00000000
	s_nop 0                                                    // 0000000852D4: BF800000
	s_nop 0                                                    // 0000000852D8: BF800000
	s_nop 0                                                    // 0000000852DC: BF800000
	s_nop 0                                                    // 0000000852E0: BF800000
	s_nop 0                                                    // 0000000852E4: BF800000
	s_nop 0                                                    // 0000000852E8: BF800000
	s_nop 0                                                    // 0000000852EC: BF800000
	s_nop 0                                                    // 0000000852F0: BF800000
	s_nop 0                                                    // 0000000852F4: BF800000
	s_nop 0                                                    // 0000000852F8: BF800000
	s_nop 0                                                    // 0000000852FC: BF800000
	global_load_b32 v34, v[18:19], off                         // 000000085300: DC520000 227C0012
	ds_load_b32 v35, v21 offset:17184                          // 000000085308: D8D84320 23000015
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000085310: 4A4242FF 00000080
	.long 0xd7000112                                           // 000000085318: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 00000008531C: 020224FF 00006000
	v_add_nc_u32_e32 v21, 4, v21                               // 000000085324: 4A2A2A84
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000085328: D5207C13 00062680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000085330: BF870004
	.long 0xd4490004                                           // 000000085334: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000085338: 020242FF 0000037F
	s_or_b32 s7, s4, s7                                        // 000000085340: 8C070704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000085344: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000085348: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000008534C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000085354: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000008535C: 917E077E
	s_cbranch_execnz 65511                                     // 000000085360: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe00>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000085364: 8C7E077E
	v_mad_u64_u32 v[18:19], null, 0x44, s6, v[5:6]             // 000000085368: D6FE7C12 04140CFF 00000044
	s_waitcnt lgkmcnt(0)                                       // 000000085374: BF89FC07
	s_barrier                                                  // 000000085378: BFBD0000
	buffer_gl0_inv                                             // 00000008537C: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 000000085384: BE840080
	ds_load_2addr_b32 v[32:33], v18 offset0:102 offset1:119    // 000000085388: D8DC7766 20000012
	ds_load_2addr_b32 v[34:35], v18 offset0:68 offset1:85      // 000000085390: D8DC5544 22000012
	ds_load_2addr_b32 v[36:37], v18 offset1:17                 // 000000085398: D8DC1100 24000012
	ds_load_2addr_b32 v[18:19], v18 offset0:34 offset1:51      // 0000000853A0: D8DC3322 12000012
	s_waitcnt lgkmcnt(3)                                       // 0000000853A8: BF89FC37
	v_bfe_u32 v21, v33, 16, 1                                  // 0000000853AC: D6100015 02052121
	v_bfe_u32 v38, v32, 16, 1                                  // 0000000853B4: D6100026 02052120
	s_waitcnt lgkmcnt(2)                                       // 0000000853BC: BF89FC27
	v_bfe_u32 v39, v35, 16, 1                                  // 0000000853C0: D6100027 02052123
	s_waitcnt lgkmcnt(1)                                       // 0000000853C8: BF89FC17
	v_bfe_u32 v40, v36, 16, 1                                  // 0000000853CC: D6100028 02052124
	v_bfe_u32 v41, v37, 16, 1                                  // 0000000853D4: D6100029 02052125
	s_waitcnt lgkmcnt(0)                                       // 0000000853DC: BF89FC07
	v_bfe_u32 v42, v18, 16, 1                                  // 0000000853E0: D610002A 02052112
	v_bfe_u32 v43, v34, 16, 1                                  // 0000000853E8: D610002B 02052122
	v_bfe_u32 v44, v19, 16, 1                                  // 0000000853F0: D610002C 02052113
	v_add3_u32 v36, v36, v40, 0x7fff                           // 0000000853F8: D6550024 03FE5124 00007FFF
	v_add3_u32 v37, v37, v41, 0x7fff                           // 000000085404: D6550025 03FE5325 00007FFF
	v_add3_u32 v40, v18, v42, 0x7fff                           // 000000085410: D6550028 03FE5512 00007FFF
	v_add3_u32 v18, v33, v21, 0x7fff                           // 00000008541C: D6550012 03FE2B21 00007FFF
	v_add3_u32 v21, v32, v38, 0x7fff                           // 000000085428: D6550015 03FE4D20 00007FFF
	v_add3_u32 v32, v35, v39, 0x7fff                           // 000000085434: D6550020 03FE4F23 00007FFF
	v_add3_u32 v33, v34, v43, 0x7fff                           // 000000085440: D6550021 03FE5722 00007FFF
	v_add3_u32 v34, v19, v44, 0x7fff                           // 00000008544C: D6550022 03FE5913 00007FFF
	v_and_b32_e32 v18, 0xffff0000, v18                         // 000000085458: 362424FF FFFF0000
	v_and_b32_e32 v19, 0xffff0000, v21                         // 000000085460: 36262AFF FFFF0000
	v_and_b32_e32 v21, 0xffff0000, v32                         // 000000085468: 362A40FF FFFF0000
	v_and_b32_e32 v32, 0xffff0000, v33                         // 000000085470: 364042FF FFFF0000
	v_and_b32_e32 v33, 0xffff0000, v34                         // 000000085478: 364244FF FFFF0000
	v_and_b32_e32 v34, 0xffff0000, v40                         // 000000085480: 364450FF FFFF0000
	v_and_b32_e32 v35, 0xffff0000, v37                         // 000000085488: 36464AFF FFFF0000
	v_dual_mov_b32 v37, v0 :: v_dual_and_b32 v36, 0xffff0000, v36// 000000085490: CA240100 252448FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008549C: BF870121
	v_lshrrev_b32_e32 v40, 4, v37                              // 0000000854A0: 32504A84
	.long 0xd4490001                                           // 0000000854A4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v37, vcc_lo                   // 0000000854A8: 02024AFF 0000077F
	v_lshlrev_b32_e32 v45, 2, v40                              // 0000000854B0: 305A5082
	v_mad_u64_u32 v[40:41], null, 0x44, v40, v[1:2]            // 0000000854B4: D6FE7C28 040650FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000854C0: 8C040401
	v_add_nc_u32_e32 v38, 0x3200, v45                          // 0000000854C4: 4A4C5AFF 00003200
	v_add_nc_u32_e32 v42, 0x3600, v45                          // 0000000854CC: 4A545AFF 00003600
	v_add_nc_u32_e32 v43, 0x3a00, v45                          // 0000000854D4: 4A565AFF 00003A00
	v_add_nc_u32_e32 v45, 0x3e00, v45                          // 0000000854DC: 4A5A5AFF 00003E00
	ds_load_b32 v47, v40                                       // 0000000854E4: D8D80000 2F000028
	ds_load_2addr_b32 v[43:44], v43 offset0:68 offset1:197     // 0000000854EC: D8DCC544 2B00002B
	ds_load_2addr_b32 v[38:39], v38 offset0:64 offset1:193     // 0000000854F4: D8DCC140 26000026
	ds_load_2addr_b32 v[41:42], v42 offset0:66 offset1:195     // 0000000854FC: D8DCC342 2900002A
	s_waitcnt lgkmcnt(1)                                       // 000000085504: BF89FC17
	v_bfe_u32 v46, v38, 16, 1                                  // 000000085508: D610002E 02052126
	v_bfe_u32 v48, v39, 16, 1                                  // 000000085510: D6100030 02052127
	s_waitcnt lgkmcnt(0)                                       // 000000085518: BF89FC07
	v_bfe_u32 v49, v41, 16, 1                                  // 00000008551C: D6100031 02052129
	s_delay_alu instid0(VALU_DEP_3)                            // 000000085524: BF870003
	v_add3_u32 v38, v38, v46, 0x7fff                           // 000000085528: D6550026 03FE5D26 00007FFF
	ds_load_2addr_b32 v[45:46], v45 offset0:70 offset1:199     // 000000085534: D8DCC746 2D00002D
	v_add3_u32 v39, v39, v48, 0x7fff                           // 00000008553C: D6550027 03FE6127 00007FFF
	v_bfe_u32 v48, v42, 16, 1                                  // 000000085548: D6100030 0205212A
	v_add3_u32 v41, v41, v49, 0x7fff                           // 000000085550: D6550029 03FE6329 00007FFF
	v_and_b32_e32 v38, 0xffff0000, v38                         // 00000008555C: 364C4CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000085564: BF870214
	v_and_b32_e32 v39, 0xffff0000, v39                         // 000000085568: 364E4EFF FFFF0000
	v_add3_u32 v42, v42, v48, 0x7fff                           // 000000085570: D655002A 03FE612A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000008557C: BF870214
	v_and_b32_e32 v41, 0xffff0000, v41                         // 000000085580: 365252FF FFFF0000
	v_fmac_f32_e32 v47, v38, v36                               // 000000085588: 565E4926
	v_bfe_u32 v38, v43, 16, 1                                  // 00000008558C: D6100026 0205212B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000085594: BF8701A2
	v_dual_fmac_f32 v47, v39, v35 :: v_dual_and_b32 v42, 0xffff0000, v42// 000000085598: C8244727 2F2A54FF FFFF0000
	v_bfe_u32 v39, v44, 16, 1                                  // 0000000855A4: D6100027 0205212C
	v_add3_u32 v38, v43, v38, 0x7fff                           // 0000000855AC: D6550026 03FE4D2B 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000855B8: BF8701C3
	v_fmac_f32_e32 v47, v41, v34                               // 0000000855BC: 565E4529
	s_waitcnt lgkmcnt(0)                                       // 0000000855C0: BF89FC07
	v_bfe_u32 v41, v45, 16, 1                                  // 0000000855C4: D6100029 0205212D
	v_add3_u32 v39, v44, v39, 0x7fff                           // 0000000855CC: D6550027 03FE4F2C 00007FFF
	v_dual_fmac_f32 v47, v42, v33 :: v_dual_and_b32 v38, 0xffff0000, v38// 0000000855D8: C824432A 2F264CFF FFFF0000
	v_bfe_u32 v42, v46, 16, 1                                  // 0000000855E4: D610002A 0205212E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000855EC: BF870214
	v_add3_u32 v41, v45, v41, 0x7fff                           // 0000000855F0: D6550029 03FE532D 00007FFF
	v_and_b32_e32 v39, 0xffff0000, v39                         // 0000000855FC: 364E4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000085604: BF870214
	v_fmac_f32_e32 v47, v38, v32                               // 000000085608: 565E4126
	v_add3_u32 v38, v46, v42, 0x7fff                           // 00000008560C: D6550026 03FE552E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000085618: BF870114
	v_and_b32_e32 v41, 0xffff0000, v41                         // 00000008561C: 365252FF FFFF0000
	v_dual_fmac_f32 v47, v39, v21 :: v_dual_and_b32 v38, 0xffff0000, v38// 000000085624: C8242B27 2F264CFF FFFF0000
	v_add_nc_u32_e32 v39, 0x80, v37                            // 000000085630: 4A4E4AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000085638: BF870112
	v_fmac_f32_e32 v47, v41, v19                               // 00000008563C: 565E2729
	v_mov_b32_e32 v37, v39                                     // 000000085640: 7E4A0327
	s_delay_alu instid0(VALU_DEP_2)                            // 000000085644: BF870002
	v_fmac_f32_e32 v47, v38, v18                               // 000000085648: 565E2526
	ds_store_b32 v40, v47                                      // 00000008564C: D8340000 00002F28
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000085654: 917E047E
	s_cbranch_execnz 65424                                     // 000000085658: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf9c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008565C: 8C7E047E
	.long 0xd7000110                                           // 000000085660: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 000000085664: 020220FF 00030000
	v_add_nc_u32_e32 v20, 32, v20                              // 00000008566C: 4A2828A0
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000085670: D5207C11 00062280
	s_add_i32 s1, s6, 8                                        // 000000085678: 81018806
	s_cmp_gt_u32 s6, 55                                        // 00000008567C: BF08B706
	s_mov_b32 s6, s1                                           // 000000085680: BE860001
	s_cbranch_scc0 65288                                       // 000000085684: BFA1FF08 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xda8>
	.long 0xd7000108                                           // 000000085688: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000008568C: 020210FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085694: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 000000085698: D5207C09 00061280
	.long 0xd700010a                                           // 0000000856A0: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 0000000856A4: 020214FF 00180000
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 0000000856AC: D5207C0B 00061680
	.long 0xd700010c                                           // 0000000856B4: D700010C
	v_cndmask_b32_e32 v1, 0xc0000, v12, vcc_lo                 // 0000000856B8: 020218FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000856C0: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 0000000856C4: D5207C0D 00061A80
	.long 0xd700010e                                           // 0000000856CC: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 0000000856D0: 02021CFF 00180000
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 0000000856D8: D5207C0F 00061E80
	s_add_i32 s5, s5, 1                                        // 0000000856E0: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000856E4: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000856E8: BF062105
	s_barrier                                                  // 0000000856EC: BFBD0000
	buffer_gl0_inv                                             // 0000000856F0: E0AC0000 00000000
	s_cbranch_scc0 64556                                       // 0000000856F8: BFA1FC2C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac>
	v_mov_b32_e32 v4, v23                                      // 0000000856FC: 7E080317
	s_add_u32 s0, s28, s20                                     // 000000085700: 8000141C
	.long 0xd73c0000                                           // 000000085704: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000085708: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000008570C: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000085710: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000085714: 82031319
	s_add_u32 s0, s2, s0                                       // 000000085718: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000008571C: 82010103
	.long 0xd7006a00                                           // 000000085720: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000085724: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000085728: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000008572C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000085734: BE810080
	.long 0xd7006a00                                           // 000000085738: D7006A00
	v_cndmask_b32_e32 v1, v0, v24, vcc_lo                      // 00000008573C: 02023100
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000085740: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085748: BF870092
	.long 0xd7006a00                                           // 00000008574C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000085750: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000085754: D5207C01 01AA0211
	s_nop 0                                                    // 00000008575C: BF800000
	s_nop 0                                                    // 000000085760: BF800000
	s_nop 0                                                    // 000000085764: BF800000
	s_nop 0                                                    // 000000085768: BF800000
	s_nop 0                                                    // 00000008576C: BF800000
	s_nop 0                                                    // 000000085770: BF800000
	s_nop 0                                                    // 000000085774: BF800000
	s_nop 0                                                    // 000000085778: BF800000
	s_nop 0                                                    // 00000008577C: BF800000
	ds_load_b32 v2, v22                                        // 000000085780: D8D80000 02000016
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000085788: 4A0808FF 00000080
	v_add_nc_u32_e32 v22, 0x220, v22                           // 000000085790: 4A2C2CFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000085798: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008579C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000857A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000857A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000857AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000857B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000857B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000857C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000857C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000857CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_endpgm                                                   // 0000000857D0: BFB00000
		...

