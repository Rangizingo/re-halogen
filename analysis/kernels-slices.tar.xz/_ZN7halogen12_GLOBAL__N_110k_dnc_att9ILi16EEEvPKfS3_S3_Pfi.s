0000000000222200 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 000000222200: BE8C0003
	s_clause 0x1                                               // 000000222204: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000222208: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 000000222210: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 000000222218: 360200FF 0000007F
	s_lshl_b32 s0, s2, 6                                       // 000000222220: 84008602
	s_ashr_i32 s13, s12, 31                                    // 000000222224: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000222228: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 00000022222C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000222234: 30060282
	s_waitcnt lgkmcnt(0)                                       // 000000222238: BF89FC07
	.long 0xd7000103                                           // 00000022223C: D7000103
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000222240: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222244: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s1                    // 000000222248: D5207C04 00050007
	s_mov_b32 s1, 0                                            // 000000222250: BE810080
	s_mov_b32 s6, 0x47800000                                   // 000000222254: BE8600FF 47800000
	s_set_inst_prefetch_distance 0x1                           // 00000022225C: BF840001
	s_branch 22                                                // 000000222260: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 000000222264: BF800000
	s_nop 0                                                    // 000000222268: BF800000
	s_nop 0                                                    // 00000022226C: BF800000
	s_nop 0                                                    // 000000222270: BF800000
	s_nop 0                                                    // 000000222274: BF800000
	s_nop 0                                                    // 000000222278: BF800000
	s_nop 0                                                    // 00000022227C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000222280: 8C7E077E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 000000222284: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 00000022228C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 000000222298: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002222A0: BF870003
	v_mov_b32_e32 v5, v8                                       // 0000002222A4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 0000002222A8: 8C01016A
	ds_store_b16 v6, v1                                        // 0000002222AC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000002222B4: 917E017E
	s_cbranch_execz 24                                         // 0000002222B8: BFA50018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x11c>
	v_lshrrev_b32_e32 v6, 7, v5                                // 0000002222BC: 320C0A87
	.long 0x7e023880                                           // 0000002222C0: 7E023880
	s_mov_b32 s7, exec_lo                                      // 0000002222C4: BE87007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002222C8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 0000002222CC: 380E0C00
	.long 0xd4c4007e                                           // 0000002222D0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 0000002222D4: 02020E03
	s_cbranch_execz 65513                                      // 0000002222D8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 0000002222DC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002222E4: BF870091
	.long 0xd73c0007                                           // 0000002222E8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000002222EC: 02020E89
	.long 0xd7006a07                                           // 0000002222F0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002222F4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002222F8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000002222FC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 000000222304: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 00000022230C: BF8903F7
	v_fma_mixlo_f16 v1, v1, s6, 0                              // 000000222310: CC210001 02000D01
	s_branch 65497                                             // 000000222318: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000022231C: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222320: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000222324: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000222328: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 00000022232C: 7D9800C0
	s_cbranch_execz 17                                         // 000000222330: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x178>
	v_or_b32_e32 v1, s0, v0                                    // 000000222334: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 000000222338: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022233C: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000222340: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 00000022234C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000222350: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222354: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000222358: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 000000222360: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000222368: 30040082
	s_waitcnt vmcnt(0)                                         // 00000022236C: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 000000222370: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222378: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000022237C: BF89FC07
	s_barrier                                                  // 000000222380: BFBD0000
	buffer_gl0_inv                                             // 000000222384: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000022238C: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 000000222390: 7D9800FF 00000200
	s_cbranch_execz 1796                                       // 000000222398: BFA50704 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1dac>
	v_and_b32_e32 v1, 15, v0                                   // 00000022239C: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 0000002223A0: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 0000002223A8: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 0000002223AC: 9682B002
	s_add_u32 s6, s1, s12                                      // 0000002223B0: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 0000002223B4: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 0000002223BC: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 0000002223C4: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 0000002223CC: 82070D02
	v_lshrrev_b32_e32 v33, 5, v0                               // 0000002223D0: 32420085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 0000002223D4: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 0000002223D8: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 0000002223DC: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 0000002223E4: D6560020 03FD051D 00004800
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v34, v2, v3      // 0000002223F0: CA200080 01220702
	s_add_u32 s2, s10, s6                                      // 0000002223F8: 8002060A
	s_addc_u32 s6, s11, s7                                     // 0000002223FC: 8206070B
	s_mov_b32 s7, 0                                            // 000000222400: BE870080
	s_mov_b32 s8, 0x47800000                                   // 000000222404: BE8800FF 47800000
	s_branch 19                                                // 00000022240C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x25c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000222410: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000222414: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v33                            // 00000022241C: 7C924287
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000222420: BF8700B2
	.long 0xd73c0003                                           // 000000222424: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000222428: 02020082
	v_add_nc_u32_e32 v0, 8, v33                                // 00000022242C: 4A004288
	s_or_b32 s7, vcc_lo, s7                                    // 000000222430: 8C07076A
	v_mov_b32_e32 v33, v0                                      // 000000222434: 7E420300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000222438: BF870093
	.long 0xd7000003                                           // 00000022243C: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000222440: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 000000222444: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000022244C: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000222454: 917E077E
	s_cbranch_execz 1748                                       // 000000222458: BFA506D4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1dac>
	v_lshrrev_b32_e32 v0, 2, v33                               // 00000022245C: 32004282
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000222460: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 000000222468: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000222470: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 000000222474: 7C923900
	.long 0xd44e0000                                           // 000000222478: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000022247C: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 000000222480: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000222488: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 000000222490: 7E040280
	s_and_saveexec_b32 s9, s0                                  // 000000222494: BE892000
	s_cbranch_execz 1301                                       // 000000222498: BFA50515 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x16f0>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000022249C: 4A083D00
	.long 0x7f143880                                           // 0000002224A0: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002224A4: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 0000002224A8: D6FF7C02 00316104
	.long 0xd4440000                                           // 0000002224B0: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000002224B4: 02020803
	.long 0x7e14398a                                           // 0000002224B8: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002224BC: BF870093
	.long 0xd73c0002                                           // 0000002224C0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002224C4: 02020489
	.long 0xd700011a                                           // 0000002224C8: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002224CC: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002224D0: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 0000002224D4: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 0000002224DC: BE812000
	s_cbranch_execz 5                                          // 0000002224E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x2f8>
	global_load_b32 v2, v[26:27], off                          // 0000002224E4: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002224EC: BF8903F7
	v_fma_mixlo_f16 v10, v2, s8, 0                             // 0000002224F0: CC21000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002224F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002224FC: BE812000
	s_cbranch_execz 5                                          // 000000222500: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x318>
	global_load_b32 v2, v[26:27], off offset:4                 // 000000222504: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022250C: BF8903F7
	v_fma_mixhi_f16 v10, v2, s8, 0                             // 000000222510: CC22000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222518: 8C7E017E
	.long 0x7f163880                                           // 00000022251C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222520: BF870001
	.long 0x7e16398b                                           // 000000222524: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000222528: BE812000
	s_cbranch_execz 5                                          // 00000022252C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x344>
	global_load_b32 v2, v[26:27], off offset:8                 // 000000222530: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222538: BF8903F7
	v_fma_mixlo_f16 v11, v2, s8, 0                             // 00000022253C: CC21000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222544: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222548: BE812000
	s_cbranch_execz 5                                          // 00000022254C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x364>
	global_load_b32 v2, v[26:27], off offset:12                // 000000222550: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222558: BF8903F7
	v_fma_mixhi_f16 v11, v2, s8, 0                             // 00000022255C: CC22000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222564: 8C7E017E
	.long 0x7f183880                                           // 000000222568: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022256C: BF870001
	.long 0x7e18398c                                           // 000000222570: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000222574: BE812000
	s_cbranch_execz 5                                          // 000000222578: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x390>
	global_load_b32 v2, v[26:27], off offset:16                // 00000022257C: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222584: BF8903F7
	v_fma_mixlo_f16 v12, v2, s8, 0                             // 000000222588: CC21000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222590: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222594: BE812000
	s_cbranch_execz 5                                          // 000000222598: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x3b0>
	global_load_b32 v2, v[26:27], off offset:20                // 00000022259C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002225A4: BF8903F7
	v_fma_mixhi_f16 v12, v2, s8, 0                             // 0000002225A8: CC22000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002225B0: 8C7E017E
	.long 0x7f1a3880                                           // 0000002225B4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002225B8: BF870001
	.long 0x7e1a398d                                           // 0000002225BC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002225C0: BE812000
	s_cbranch_execz 5                                          // 0000002225C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x3dc>
	global_load_b32 v2, v[26:27], off offset:24                // 0000002225C8: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002225D0: BF8903F7
	v_fma_mixlo_f16 v13, v2, s8, 0                             // 0000002225D4: CC21000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002225DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002225E0: BE812000
	s_cbranch_execz 5                                          // 0000002225E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x3fc>
	global_load_b32 v2, v[26:27], off offset:28                // 0000002225E8: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002225F0: BF8903F7
	v_fma_mixhi_f16 v13, v2, s8, 0                             // 0000002225F4: CC22000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002225FC: 8C7E017E
	.long 0x7f1c3880                                           // 000000222600: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222604: BF870001
	.long 0x7e1c398e                                           // 000000222608: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000022260C: BE812000
	s_cbranch_execz 5                                          // 000000222610: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x428>
	global_load_b32 v2, v[26:27], off offset:32                // 000000222614: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022261C: BF8903F7
	v_fma_mixlo_f16 v14, v2, s8, 0                             // 000000222620: CC21000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222628: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022262C: BE812000
	s_cbranch_execz 5                                          // 000000222630: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x448>
	global_load_b32 v2, v[26:27], off offset:36                // 000000222634: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022263C: BF8903F7
	v_fma_mixhi_f16 v14, v2, s8, 0                             // 000000222640: CC22000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222648: 8C7E017E
	.long 0x7f1e3880                                           // 00000022264C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222650: BF870001
	.long 0x7e1e398f                                           // 000000222654: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000222658: BE812000
	s_cbranch_execz 5                                          // 00000022265C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x474>
	global_load_b32 v2, v[26:27], off offset:40                // 000000222660: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222668: BF8903F7
	v_fma_mixlo_f16 v15, v2, s8, 0                             // 00000022266C: CC21000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222674: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222678: BE812000
	s_cbranch_execz 5                                          // 00000022267C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x494>
	global_load_b32 v2, v[26:27], off offset:44                // 000000222680: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222688: BF8903F7
	v_fma_mixhi_f16 v15, v2, s8, 0                             // 00000022268C: CC22000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222694: 8C7E017E
	.long 0x7f203880                                           // 000000222698: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022269C: BF870001
	.long 0x7e203990                                           // 0000002226A0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002226A4: BE812000
	s_cbranch_execz 5                                          // 0000002226A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x4c0>
	global_load_b32 v2, v[26:27], off offset:48                // 0000002226AC: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002226B4: BF8903F7
	v_fma_mixlo_f16 v16, v2, s8, 0                             // 0000002226B8: CC210010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002226C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002226C4: BE812000
	s_cbranch_execz 5                                          // 0000002226C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:52                // 0000002226CC: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002226D4: BF8903F7
	v_fma_mixhi_f16 v16, v2, s8, 0                             // 0000002226D8: CC220010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002226E0: 8C7E017E
	.long 0x7f223880                                           // 0000002226E4: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002226E8: BF870001
	.long 0x7e223991                                           // 0000002226EC: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 0000002226F0: BE812000
	s_cbranch_execz 5                                          // 0000002226F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x50c>
	global_load_b32 v2, v[26:27], off offset:56                // 0000002226F8: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222700: BF8903F7
	v_fma_mixlo_f16 v17, v2, s8, 0                             // 000000222704: CC210011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022270C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222710: BE812000
	s_cbranch_execz 5                                          // 000000222714: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x52c>
	global_load_b32 v2, v[26:27], off offset:60                // 000000222718: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000222720: BF8903F7
	v_fma_mixhi_f16 v17, v2, s8, 0                             // 000000222724: CC220011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022272C: 8C7E017E
	ds_load_b128 v[35:38], v34                                 // 000000222730: DBFC0000 23000022
	ds_load_b128 v[39:42], v34 offset:16                       // 000000222738: DBFC0010 27000022
	v_mov_b32_e32 v8, v1                                       // 000000222740: 7E100301
	v_mov_b32_e32 v2, v1                                       // 000000222744: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000222748: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000022274C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000222750: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000222754: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000222758: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000022275C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000222760: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000222764: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000222768: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000022276C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000222770: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000222774: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000222778: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000022277C: 7E040301
	.long 0x7f243880                                           // 000000222780: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 000000222784: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000222788: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000022278C: CC404002 1C0A470A
	.long 0x7e243992                                           // 000000222794: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 000000222798: BE812000
	s_cbranch_execz 5                                          // 00000022279C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x5b4>
	global_load_b32 v10, v[26:27], off offset:64               // 0000002227A0: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002227A8: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 0000002227AC: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002227B4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002227B8: BE812000
	s_cbranch_execz 5                                          // 0000002227BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x5d4>
	global_load_b32 v10, v[26:27], off offset:68               // 0000002227C0: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002227C8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002227CC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002227D4: 8C7E017E
	.long 0x7f263880                                           // 0000002227D8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002227DC: BF870001
	.long 0x7e263993                                           // 0000002227E0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002227E4: BE812000
	s_cbranch_execz 5                                          // 0000002227E8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x600>
	global_load_b32 v10, v[26:27], off offset:72               // 0000002227EC: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002227F4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002227F8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222800: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222804: BE812000
	s_cbranch_execz 5                                          // 000000222808: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x620>
	global_load_b32 v10, v[26:27], off offset:76               // 00000022280C: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222814: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000222818: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222820: 8C7E017E
	.long 0x7f283880                                           // 000000222824: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222828: BF870001
	.long 0x7e283994                                           // 00000022282C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000222830: BE812000
	s_cbranch_execz 5                                          // 000000222834: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:80               // 000000222838: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222840: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000222844: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022284C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222850: BE812000
	s_cbranch_execz 5                                          // 000000222854: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x66c>
	global_load_b32 v10, v[26:27], off offset:84               // 000000222858: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222860: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000222864: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022286C: 8C7E017E
	.long 0x7f2a3880                                           // 000000222870: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222874: BF870001
	.long 0x7e2a3995                                           // 000000222878: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000022287C: BE812000
	s_cbranch_execz 5                                          // 000000222880: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x698>
	global_load_b32 v10, v[26:27], off offset:88               // 000000222884: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022288C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000222890: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222898: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022289C: BE812000
	s_cbranch_execz 5                                          // 0000002228A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:92               // 0000002228A4: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002228AC: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002228B0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002228B8: 8C7E017E
	.long 0x7f2c3880                                           // 0000002228BC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002228C0: BF870001
	.long 0x7e2c3996                                           // 0000002228C4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002228C8: BE812000
	s_cbranch_execz 5                                          // 0000002228CC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x6e4>
	global_load_b32 v10, v[26:27], off offset:96               // 0000002228D0: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002228D8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002228DC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002228E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002228E8: BE812000
	s_cbranch_execz 5                                          // 0000002228EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x704>
	global_load_b32 v10, v[26:27], off offset:100              // 0000002228F0: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002228F8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002228FC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222904: 8C7E017E
	.long 0x7f2e3880                                           // 000000222908: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022290C: BF870001
	.long 0x7e2e3997                                           // 000000222910: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000222914: BE812000
	s_cbranch_execz 5                                          // 000000222918: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x730>
	global_load_b32 v10, v[26:27], off offset:104              // 00000022291C: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222924: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000222928: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222930: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222934: BE812000
	s_cbranch_execz 5                                          // 000000222938: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x750>
	global_load_b32 v10, v[26:27], off offset:108              // 00000022293C: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222944: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000222948: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222950: 8C7E017E
	.long 0x7f303880                                           // 000000222954: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222958: BF870001
	.long 0x7e303998                                           // 00000022295C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000222960: BE812000
	s_cbranch_execz 5                                          // 000000222964: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x77c>
	global_load_b32 v10, v[26:27], off offset:112              // 000000222968: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222970: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000222974: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022297C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222980: BE812000
	s_cbranch_execz 5                                          // 000000222984: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x79c>
	global_load_b32 v10, v[26:27], off offset:116              // 000000222988: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222990: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000222994: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022299C: 8C7E017E
	.long 0x7f323880                                           // 0000002229A0: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002229A4: BF870001
	.long 0x7e323999                                           // 0000002229A8: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 0000002229AC: BE812000
	s_cbranch_execz 5                                          // 0000002229B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x7c8>
	global_load_b32 v10, v[26:27], off offset:120              // 0000002229B4: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002229BC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002229C0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002229C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002229CC: BE812000
	s_cbranch_execz 5                                          // 0000002229D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x7e8>
	global_load_b32 v10, v[26:27], off offset:124              // 0000002229D4: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002229DC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002229E0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002229E8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:32                       // 0000002229EC: DBFC0020 23000022
	ds_load_b128 v[39:42], v34 offset:48                       // 0000002229F4: DBFC0030 27000022
	.long 0x7f143880                                           // 0000002229FC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222A00: BF870001
	.long 0x7e14398a                                           // 000000222A04: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000222A08: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 000000222A0C: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000222A14: BE812000
	s_cbranch_execz 5                                          // 000000222A18: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x830>
	global_load_b32 v11, v[26:27], off offset:128              // 000000222A1C: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000222A24: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000222A28: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222A30: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222A34: BE812000
	s_cbranch_execz 5                                          // 000000222A38: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x850>
	global_load_b32 v11, v[26:27], off offset:132              // 000000222A3C: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000222A44: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000222A48: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222A50: 8C7E017E
	.long 0x7f163880                                           // 000000222A54: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222A58: BF870001
	.long 0x7e16398b                                           // 000000222A5C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000222A60: BE812000
	s_cbranch_execz 5                                          // 000000222A64: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x87c>
	global_load_b32 v12, v[26:27], off offset:136              // 000000222A68: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000222A70: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000222A74: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222A7C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222A80: BE812000
	s_cbranch_execz 5                                          // 000000222A84: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x89c>
	global_load_b32 v12, v[26:27], off offset:140              // 000000222A88: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000222A90: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000222A94: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222A9C: 8C7E017E
	.long 0x7f183880                                           // 000000222AA0: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222AA4: BF870001
	.long 0x7e18398c                                           // 000000222AA8: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000222AAC: BE812000
	s_cbranch_execz 5                                          // 000000222AB0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x8c8>
	global_load_b32 v13, v[26:27], off offset:144              // 000000222AB4: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000222ABC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 000000222AC0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222AC8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222ACC: BE812000
	s_cbranch_execz 5                                          // 000000222AD0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x8e8>
	global_load_b32 v13, v[26:27], off offset:148              // 000000222AD4: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000222ADC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 000000222AE0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222AE8: 8C7E017E
	.long 0x7f1a3880                                           // 000000222AEC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222AF0: BF870001
	.long 0x7e1a398d                                           // 000000222AF4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 000000222AF8: BE812000
	s_cbranch_execz 5                                          // 000000222AFC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x914>
	global_load_b32 v14, v[26:27], off offset:152              // 000000222B00: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000222B08: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 000000222B0C: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222B14: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222B18: BE812000
	s_cbranch_execz 5                                          // 000000222B1C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x934>
	global_load_b32 v14, v[26:27], off offset:156              // 000000222B20: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000222B28: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 000000222B2C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222B34: 8C7E017E
	.long 0x7f1c3880                                           // 000000222B38: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222B3C: BF870001
	.long 0x7e1c398e                                           // 000000222B40: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000222B44: BE812000
	s_cbranch_execz 5                                          // 000000222B48: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x960>
	global_load_b32 v15, v[26:27], off offset:160              // 000000222B4C: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000222B54: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000222B58: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222B60: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222B64: BE812000
	s_cbranch_execz 5                                          // 000000222B68: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x980>
	global_load_b32 v15, v[26:27], off offset:164              // 000000222B6C: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000222B74: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000222B78: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222B80: 8C7E017E
	.long 0x7f1e3880                                           // 000000222B84: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222B88: BF870001
	.long 0x7e1e398f                                           // 000000222B8C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000222B90: BE812000
	s_cbranch_execz 5                                          // 000000222B94: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x9ac>
	global_load_b32 v16, v[26:27], off offset:168              // 000000222B98: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 000000222BA0: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 000000222BA4: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222BAC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222BB0: BE812000
	s_cbranch_execz 5                                          // 000000222BB4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x9cc>
	global_load_b32 v16, v[26:27], off offset:172              // 000000222BB8: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 000000222BC0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 000000222BC4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222BCC: 8C7E017E
	.long 0x7f203880                                           // 000000222BD0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222BD4: BF870001
	.long 0x7e203990                                           // 000000222BD8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 000000222BDC: BE812000
	s_cbranch_execz 5                                          // 000000222BE0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v17, v[26:27], off offset:176              // 000000222BE4: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 000000222BEC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 000000222BF0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222BF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222BFC: BE812000
	s_cbranch_execz 5                                          // 000000222C00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xa18>
	global_load_b32 v17, v[26:27], off offset:180              // 000000222C04: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 000000222C0C: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000222C10: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222C18: 8C7E017E
	.long 0x7f223880                                           // 000000222C1C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222C20: BF870001
	.long 0x7e223991                                           // 000000222C24: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000222C28: BE812000
	s_cbranch_execz 5                                          // 000000222C2C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xa44>
	global_load_b32 v18, v[26:27], off offset:184              // 000000222C30: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 000000222C38: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 000000222C3C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222C44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222C48: BE812000
	s_cbranch_execz 5                                          // 000000222C4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v18, v[26:27], off offset:188              // 000000222C50: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 000000222C58: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 000000222C5C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222C64: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:64                       // 000000222C68: DBFC0040 23000022
	ds_load_b128 v[39:42], v34 offset:80                       // 000000222C70: DBFC0050 27000022
	.long 0x7f243880                                           // 000000222C78: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222C7C: BF870001
	.long 0x7e243992                                           // 000000222C80: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000222C84: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000222C88: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000222C90: BE812000
	s_cbranch_execz 5                                          // 000000222C94: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xaac>
	global_load_b32 v10, v[26:27], off offset:192              // 000000222C98: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222CA0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000222CA4: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222CAC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222CB0: BE812000
	s_cbranch_execz 5                                          // 000000222CB4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xacc>
	global_load_b32 v10, v[26:27], off offset:196              // 000000222CB8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222CC0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 000000222CC4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222CCC: 8C7E017E
	.long 0x7f263880                                           // 000000222CD0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222CD4: BF870001
	.long 0x7e263993                                           // 000000222CD8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 000000222CDC: BE812000
	s_cbranch_execz 5                                          // 000000222CE0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xaf8>
	global_load_b32 v10, v[26:27], off offset:200              // 000000222CE4: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222CEC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 000000222CF0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222CF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222CFC: BE812000
	s_cbranch_execz 5                                          // 000000222D00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xb18>
	global_load_b32 v10, v[26:27], off offset:204              // 000000222D04: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222D0C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000222D10: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222D18: 8C7E017E
	.long 0x7f283880                                           // 000000222D1C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222D20: BF870001
	.long 0x7e283994                                           // 000000222D24: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000222D28: BE812000
	s_cbranch_execz 5                                          // 000000222D2C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xb44>
	global_load_b32 v10, v[26:27], off offset:208              // 000000222D30: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222D38: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000222D3C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222D44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222D48: BE812000
	s_cbranch_execz 5                                          // 000000222D4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xb64>
	global_load_b32 v10, v[26:27], off offset:212              // 000000222D50: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222D58: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000222D5C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222D64: 8C7E017E
	.long 0x7f2a3880                                           // 000000222D68: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222D6C: BF870001
	.long 0x7e2a3995                                           // 000000222D70: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000222D74: BE812000
	s_cbranch_execz 5                                          // 000000222D78: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:216              // 000000222D7C: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222D84: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000222D88: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222D90: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222D94: BE812000
	s_cbranch_execz 5                                          // 000000222D98: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xbb0>
	global_load_b32 v10, v[26:27], off offset:220              // 000000222D9C: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222DA4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 000000222DA8: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222DB0: 8C7E017E
	.long 0x7f2c3880                                           // 000000222DB4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222DB8: BF870001
	.long 0x7e2c3996                                           // 000000222DBC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 000000222DC0: BE812000
	s_cbranch_execz 5                                          // 000000222DC4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xbdc>
	global_load_b32 v10, v[26:27], off offset:224              // 000000222DC8: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222DD0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 000000222DD4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222DDC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222DE0: BE812000
	s_cbranch_execz 5                                          // 000000222DE4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xbfc>
	global_load_b32 v10, v[26:27], off offset:228              // 000000222DE8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222DF0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 000000222DF4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222DFC: 8C7E017E
	.long 0x7f2e3880                                           // 000000222E00: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222E04: BF870001
	.long 0x7e2e3997                                           // 000000222E08: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000222E0C: BE812000
	s_cbranch_execz 5                                          // 000000222E10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xc28>
	global_load_b32 v10, v[26:27], off offset:232              // 000000222E14: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222E1C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000222E20: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222E28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222E2C: BE812000
	s_cbranch_execz 5                                          // 000000222E30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xc48>
	global_load_b32 v10, v[26:27], off offset:236              // 000000222E34: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222E3C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000222E40: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222E48: 8C7E017E
	.long 0x7f303880                                           // 000000222E4C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222E50: BF870001
	.long 0x7e303998                                           // 000000222E54: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000222E58: BE812000
	s_cbranch_execz 5                                          // 000000222E5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xc74>
	global_load_b32 v10, v[26:27], off offset:240              // 000000222E60: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222E68: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000222E6C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222E74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222E78: BE812000
	s_cbranch_execz 5                                          // 000000222E7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xc94>
	global_load_b32 v10, v[26:27], off offset:244              // 000000222E80: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222E88: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000222E8C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222E94: 8C7E017E
	.long 0x7f323880                                           // 000000222E98: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222E9C: BF870001
	.long 0x7e323999                                           // 000000222EA0: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000222EA4: BE812000
	s_cbranch_execz 5                                          // 000000222EA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xcc0>
	global_load_b32 v10, v[26:27], off offset:248              // 000000222EAC: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222EB4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 000000222EB8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222EC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222EC4: BE812000
	s_cbranch_execz 5                                          // 000000222EC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xce0>
	global_load_b32 v10, v[26:27], off offset:252              // 000000222ECC: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000222ED4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 000000222ED8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222EE0: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:96                       // 000000222EE4: DBFC0060 23000022
	ds_load_b128 v[39:42], v34 offset:112                      // 000000222EEC: DBFC0070 27000022
	.long 0x7f143880                                           // 000000222EF4: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222EF8: BF870001
	.long 0x7e14398a                                           // 000000222EFC: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000222F00: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 000000222F04: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000222F0C: BE812000
	s_cbranch_execz 5                                          // 000000222F10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v11, v[26:27], off offset:256              // 000000222F14: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000222F1C: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000222F20: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222F28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222F2C: BE812000
	s_cbranch_execz 5                                          // 000000222F30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xd48>
	global_load_b32 v11, v[26:27], off offset:260              // 000000222F34: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000222F3C: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000222F40: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222F48: 8C7E017E
	.long 0x7f163880                                           // 000000222F4C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222F50: BF870001
	.long 0x7e16398b                                           // 000000222F54: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000222F58: BE812000
	s_cbranch_execz 5                                          // 000000222F5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xd74>
	global_load_b32 v12, v[26:27], off offset:264              // 000000222F60: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000222F68: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000222F6C: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222F74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222F78: BE812000
	s_cbranch_execz 5                                          // 000000222F7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xd94>
	global_load_b32 v12, v[26:27], off offset:268              // 000000222F80: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000222F88: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000222F8C: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222F94: 8C7E017E
	.long 0x7f183880                                           // 000000222F98: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222F9C: BF870001
	.long 0x7e18398c                                           // 000000222FA0: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000222FA4: BE812000
	s_cbranch_execz 5                                          // 000000222FA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xdc0>
	global_load_b32 v13, v[26:27], off offset:272              // 000000222FAC: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000222FB4: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 000000222FB8: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222FC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000222FC4: BE812000
	s_cbranch_execz 5                                          // 000000222FC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xde0>
	global_load_b32 v13, v[26:27], off offset:276              // 000000222FCC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000222FD4: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 000000222FD8: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000222FE0: 8C7E017E
	.long 0x7f1a3880                                           // 000000222FE4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000222FE8: BF870001
	.long 0x7e1a398d                                           // 000000222FEC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 000000222FF0: BE812000
	s_cbranch_execz 5                                          // 000000222FF4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xe0c>
	global_load_b32 v14, v[26:27], off offset:280              // 000000222FF8: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000223000: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 000000223004: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022300C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223010: BE812000
	s_cbranch_execz 5                                          // 000000223014: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xe2c>
	global_load_b32 v14, v[26:27], off offset:284              // 000000223018: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000223020: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 000000223024: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022302C: 8C7E017E
	.long 0x7f1c3880                                           // 000000223030: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223034: BF870001
	.long 0x7e1c398e                                           // 000000223038: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000022303C: BE812000
	s_cbranch_execz 5                                          // 000000223040: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xe58>
	global_load_b32 v15, v[26:27], off offset:288              // 000000223044: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000022304C: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000223050: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223058: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022305C: BE812000
	s_cbranch_execz 5                                          // 000000223060: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xe78>
	global_load_b32 v15, v[26:27], off offset:292              // 000000223064: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000022306C: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000223070: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223078: 8C7E017E
	.long 0x7f1e3880                                           // 00000022307C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223080: BF870001
	.long 0x7e1e398f                                           // 000000223084: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000223088: BE812000
	s_cbranch_execz 5                                          // 00000022308C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xea4>
	global_load_b32 v16, v[26:27], off offset:296              // 000000223090: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 000000223098: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000022309C: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002230A4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002230A8: BE812000
	s_cbranch_execz 5                                          // 0000002230AC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xec4>
	global_load_b32 v16, v[26:27], off offset:300              // 0000002230B0: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002230B8: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 0000002230BC: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002230C4: 8C7E017E
	.long 0x7f203880                                           // 0000002230C8: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002230CC: BF870001
	.long 0x7e203990                                           // 0000002230D0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002230D4: BE812000
	s_cbranch_execz 5                                          // 0000002230D8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xef0>
	global_load_b32 v17, v[26:27], off offset:304              // 0000002230DC: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002230E4: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 0000002230E8: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002230F0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002230F4: BE812000
	s_cbranch_execz 5                                          // 0000002230F8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xf10>
	global_load_b32 v17, v[26:27], off offset:308              // 0000002230FC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 000000223104: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000223108: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223110: 8C7E017E
	.long 0x7f223880                                           // 000000223114: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223118: BF870001
	.long 0x7e223991                                           // 00000022311C: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000223120: BE812000
	s_cbranch_execz 5                                          // 000000223124: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v18, v[26:27], off offset:312              // 000000223128: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 000000223130: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 000000223134: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022313C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223140: BE812000
	s_cbranch_execz 5                                          // 000000223144: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xf5c>
	global_load_b32 v18, v[26:27], off offset:316              // 000000223148: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 000000223150: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 000000223154: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022315C: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:128                      // 000000223160: DBFC0080 23000022
	ds_load_b128 v[39:42], v34 offset:144                      // 000000223168: DBFC0090 27000022
	.long 0x7f243880                                           // 000000223170: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223174: BF870001
	.long 0x7e243992                                           // 000000223178: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000022317C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000223180: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000223188: BE812000
	s_cbranch_execz 5                                          // 00000022318C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xfa4>
	global_load_b32 v10, v[26:27], off offset:320              // 000000223190: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223198: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000022319C: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002231A4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002231A8: BE812000
	s_cbranch_execz 5                                          // 0000002231AC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:324              // 0000002231B0: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002231B8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002231BC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002231C4: 8C7E017E
	.long 0x7f263880                                           // 0000002231C8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002231CC: BF870001
	.long 0x7e263993                                           // 0000002231D0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002231D4: BE812000
	s_cbranch_execz 5                                          // 0000002231D8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0xff0>
	global_load_b32 v10, v[26:27], off offset:328              // 0000002231DC: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002231E4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002231E8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002231F0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002231F4: BE812000
	s_cbranch_execz 5                                          // 0000002231F8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1010>
	global_load_b32 v10, v[26:27], off offset:332              // 0000002231FC: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223204: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000223208: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223210: 8C7E017E
	.long 0x7f283880                                           // 000000223214: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223218: BF870001
	.long 0x7e283994                                           // 00000022321C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000223220: BE812000
	s_cbranch_execz 5                                          // 000000223224: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x103c>
	global_load_b32 v10, v[26:27], off offset:336              // 000000223228: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223230: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000223234: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022323C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223240: BE812000
	s_cbranch_execz 5                                          // 000000223244: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x105c>
	global_load_b32 v10, v[26:27], off offset:340              // 000000223248: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223250: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000223254: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022325C: 8C7E017E
	.long 0x7f2a3880                                           // 000000223260: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223264: BF870001
	.long 0x7e2a3995                                           // 000000223268: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000022326C: BE812000
	s_cbranch_execz 5                                          // 000000223270: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1088>
	global_load_b32 v10, v[26:27], off offset:344              // 000000223274: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022327C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000223280: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223288: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022328C: BE812000
	s_cbranch_execz 5                                          // 000000223290: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x10a8>
	global_load_b32 v10, v[26:27], off offset:348              // 000000223294: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022329C: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002232A0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002232A8: 8C7E017E
	.long 0x7f2c3880                                           // 0000002232AC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002232B0: BF870001
	.long 0x7e2c3996                                           // 0000002232B4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002232B8: BE812000
	s_cbranch_execz 5                                          // 0000002232BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v10, v[26:27], off offset:352              // 0000002232C0: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002232C8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002232CC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002232D4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002232D8: BE812000
	s_cbranch_execz 5                                          // 0000002232DC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x10f4>
	global_load_b32 v10, v[26:27], off offset:356              // 0000002232E0: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002232E8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002232EC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002232F4: 8C7E017E
	.long 0x7f2e3880                                           // 0000002232F8: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002232FC: BF870001
	.long 0x7e2e3997                                           // 000000223300: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000223304: BE812000
	s_cbranch_execz 5                                          // 000000223308: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1120>
	global_load_b32 v10, v[26:27], off offset:360              // 00000022330C: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223314: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000223318: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223320: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223324: BE812000
	s_cbranch_execz 5                                          // 000000223328: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1140>
	global_load_b32 v10, v[26:27], off offset:364              // 00000022332C: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223334: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000223338: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223340: 8C7E017E
	.long 0x7f303880                                           // 000000223344: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223348: BF870001
	.long 0x7e303998                                           // 00000022334C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000223350: BE812000
	s_cbranch_execz 5                                          // 000000223354: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x116c>
	global_load_b32 v10, v[26:27], off offset:368              // 000000223358: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223360: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000223364: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022336C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223370: BE812000
	s_cbranch_execz 5                                          // 000000223374: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x118c>
	global_load_b32 v10, v[26:27], off offset:372              // 000000223378: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223380: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000223384: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022338C: 8C7E017E
	.long 0x7f323880                                           // 000000223390: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223394: BF870001
	.long 0x7e323999                                           // 000000223398: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000022339C: BE812000
	s_cbranch_execz 5                                          // 0000002233A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x11b8>
	global_load_b32 v10, v[26:27], off offset:376              // 0000002233A4: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002233AC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002233B0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002233B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002233BC: BE812000
	s_cbranch_execz 5                                          // 0000002233C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x11d8>
	global_load_b32 v10, v[26:27], off offset:380              // 0000002233C4: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002233CC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002233D0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002233D8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:160                      // 0000002233DC: DBFC00A0 23000022
	ds_load_b128 v[39:42], v34 offset:176                      // 0000002233E4: DBFC00B0 27000022
	.long 0x7f143880                                           // 0000002233EC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002233F0: BF870001
	.long 0x7e14398a                                           // 0000002233F4: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 0000002233F8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 0000002233FC: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000223404: BE812000
	s_cbranch_execz 5                                          // 000000223408: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1220>
	global_load_b32 v11, v[26:27], off offset:384              // 00000022340C: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000223414: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000223418: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223420: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223424: BE812000
	s_cbranch_execz 5                                          // 000000223428: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1240>
	global_load_b32 v11, v[26:27], off offset:388              // 00000022342C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000223434: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000223438: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223440: 8C7E017E
	.long 0x7f163880                                           // 000000223444: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223448: BF870001
	.long 0x7e16398b                                           // 00000022344C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000223450: BE812000
	s_cbranch_execz 5                                          // 000000223454: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v12, v[26:27], off offset:392              // 000000223458: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000223460: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000223464: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022346C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223470: BE812000
	s_cbranch_execz 5                                          // 000000223474: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x128c>
	global_load_b32 v12, v[26:27], off offset:396              // 000000223478: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000223480: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000223484: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022348C: 8C7E017E
	.long 0x7f183880                                           // 000000223490: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223494: BF870001
	.long 0x7e18398c                                           // 000000223498: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000022349C: BE812000
	s_cbranch_execz 5                                          // 0000002234A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x12b8>
	global_load_b32 v13, v[26:27], off offset:400              // 0000002234A4: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002234AC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 0000002234B0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002234B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002234BC: BE812000
	s_cbranch_execz 5                                          // 0000002234C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x12d8>
	global_load_b32 v13, v[26:27], off offset:404              // 0000002234C4: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002234CC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 0000002234D0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002234D8: 8C7E017E
	.long 0x7f1a3880                                           // 0000002234DC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002234E0: BF870001
	.long 0x7e1a398d                                           // 0000002234E4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002234E8: BE812000
	s_cbranch_execz 5                                          // 0000002234EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1304>
	global_load_b32 v14, v[26:27], off offset:408              // 0000002234F0: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 0000002234F8: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 0000002234FC: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223504: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223508: BE812000
	s_cbranch_execz 5                                          // 00000022350C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1324>
	global_load_b32 v14, v[26:27], off offset:412              // 000000223510: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000223518: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000022351C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223524: 8C7E017E
	.long 0x7f1c3880                                           // 000000223528: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022352C: BF870001
	.long 0x7e1c398e                                           // 000000223530: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000223534: BE812000
	s_cbranch_execz 5                                          // 000000223538: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1350>
	global_load_b32 v15, v[26:27], off offset:416              // 00000022353C: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000223544: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000223548: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223550: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223554: BE812000
	s_cbranch_execz 5                                          // 000000223558: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v15, v[26:27], off offset:420              // 00000022355C: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000223564: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000223568: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223570: 8C7E017E
	.long 0x7f1e3880                                           // 000000223574: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223578: BF870001
	.long 0x7e1e398f                                           // 00000022357C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000223580: BE812000
	s_cbranch_execz 5                                          // 000000223584: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x139c>
	global_load_b32 v16, v[26:27], off offset:424              // 000000223588: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 000000223590: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 000000223594: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022359C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002235A0: BE812000
	s_cbranch_execz 5                                          // 0000002235A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x13bc>
	global_load_b32 v16, v[26:27], off offset:428              // 0000002235A8: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002235B0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 0000002235B4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002235BC: 8C7E017E
	.long 0x7f203880                                           // 0000002235C0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002235C4: BF870001
	.long 0x7e203990                                           // 0000002235C8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002235CC: BE812000
	s_cbranch_execz 5                                          // 0000002235D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x13e8>
	global_load_b32 v17, v[26:27], off offset:432              // 0000002235D4: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002235DC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 0000002235E0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002235E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002235EC: BE812000
	s_cbranch_execz 5                                          // 0000002235F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1408>
	global_load_b32 v17, v[26:27], off offset:436              // 0000002235F4: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002235FC: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000223600: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223608: 8C7E017E
	.long 0x7f223880                                           // 00000022360C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223610: BF870001
	.long 0x7e223991                                           // 000000223614: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000223618: BE812000
	s_cbranch_execz 5                                          // 00000022361C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1434>
	global_load_b32 v18, v[26:27], off offset:440              // 000000223620: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 000000223628: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000022362C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223634: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223638: BE812000
	s_cbranch_execz 5                                          // 00000022363C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1454>
	global_load_b32 v18, v[26:27], off offset:444              // 000000223640: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 000000223648: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000022364C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223654: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:192                      // 000000223658: DBFC00C0 23000022
	ds_load_b128 v[39:42], v34 offset:208                      // 000000223660: DBFC00D0 27000022
	.long 0x7f243880                                           // 000000223668: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022366C: BF870001
	.long 0x7e243992                                           // 000000223670: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000223674: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000223678: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000223680: BE812000
	s_cbranch_execz 5                                          // 000000223684: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x149c>
	global_load_b32 v10, v[26:27], off offset:448              // 000000223688: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223690: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000223694: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022369C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002236A0: BE812000
	s_cbranch_execz 5                                          // 0000002236A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x14bc>
	global_load_b32 v10, v[26:27], off offset:452              // 0000002236A8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002236B0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002236B4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002236BC: 8C7E017E
	.long 0x7f263880                                           // 0000002236C0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002236C4: BF870001
	.long 0x7e263993                                           // 0000002236C8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002236CC: BE812000
	s_cbranch_execz 5                                          // 0000002236D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x14e8>
	global_load_b32 v10, v[26:27], off offset:456              // 0000002236D4: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002236DC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002236E0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002236E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002236EC: BE812000
	s_cbranch_execz 5                                          // 0000002236F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1508>
	global_load_b32 v10, v[26:27], off offset:460              // 0000002236F4: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002236FC: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000223700: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223708: 8C7E017E
	.long 0x7f283880                                           // 00000022370C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223710: BF870001
	.long 0x7e283994                                           // 000000223714: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000223718: BE812000
	s_cbranch_execz 5                                          // 00000022371C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1534>
	global_load_b32 v10, v[26:27], off offset:464              // 000000223720: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223728: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000022372C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223734: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223738: BE812000
	s_cbranch_execz 5                                          // 00000022373C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1554>
	global_load_b32 v10, v[26:27], off offset:468              // 000000223740: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223748: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000022374C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223754: 8C7E017E
	.long 0x7f2a3880                                           // 000000223758: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022375C: BF870001
	.long 0x7e2a3995                                           // 000000223760: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000223764: BE812000
	s_cbranch_execz 5                                          // 000000223768: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1580>
	global_load_b32 v10, v[26:27], off offset:472              // 00000022376C: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223774: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000223778: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223780: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223784: BE812000
	s_cbranch_execz 5                                          // 000000223788: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x15a0>
	global_load_b32 v10, v[26:27], off offset:476              // 00000022378C: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223794: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 000000223798: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002237A0: 8C7E017E
	.long 0x7f2c3880                                           // 0000002237A4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002237A8: BF870001
	.long 0x7e2c3996                                           // 0000002237AC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002237B0: BE812000
	s_cbranch_execz 5                                          // 0000002237B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x15cc>
	global_load_b32 v10, v[26:27], off offset:480              // 0000002237B8: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002237C0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002237C4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002237CC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002237D0: BE812000
	s_cbranch_execz 5                                          // 0000002237D4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x15ec>
	global_load_b32 v10, v[26:27], off offset:484              // 0000002237D8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002237E0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002237E4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002237EC: 8C7E017E
	.long 0x7f2e3880                                           // 0000002237F0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002237F4: BF870001
	.long 0x7e2e3997                                           // 0000002237F8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 0000002237FC: BE812000
	s_cbranch_execz 5                                          // 000000223800: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1618>
	global_load_b32 v10, v[26:27], off offset:488              // 000000223804: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022380C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000223810: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223818: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022381C: BE812000
	s_cbranch_execz 5                                          // 000000223820: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1638>
	global_load_b32 v10, v[26:27], off offset:492              // 000000223824: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022382C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000223830: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223838: 8C7E017E
	.long 0x7f303880                                           // 00000022383C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223840: BF870001
	.long 0x7e303998                                           // 000000223844: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000223848: BE812000
	s_cbranch_execz 5                                          // 00000022384C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1664>
	global_load_b32 v10, v[26:27], off offset:496              // 000000223850: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223858: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000022385C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223864: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000223868: BE812000
	s_cbranch_execz 5                                          // 00000022386C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1684>
	global_load_b32 v10, v[26:27], off offset:500              // 000000223870: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000223878: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000022387C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000223884: 8C7E017E
	.long 0x7f323880                                           // 000000223888: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022388C: BF870001
	.long 0x7e323999                                           // 000000223890: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000223894: BE812000
	s_cbranch_execz 5                                          // 000000223898: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x16b0>
	global_load_b32 v10, v[26:27], off offset:504              // 00000022389C: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002238A4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002238A8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002238B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002238B4: BE812000
	s_cbranch_execz 5                                          // 0000002238B8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x16d0>
	global_load_b32 v10, v[26:27], off offset:508              // 0000002238BC: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002238C4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002238C8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002238D0: 8C7E017E
	ds_load_b128 v[10:13], v34 offset:224                      // 0000002238D4: DBFC00E0 0A000022
	ds_load_b128 v[14:17], v34 offset:240                      // 0000002238DC: DBFC00F0 0E000022
	s_waitcnt lgkmcnt(0)                                       // 0000002238E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 0000002238E8: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s9                              // 0000002238F0: 8C7E097E
	v_or_b32_e32 v11, v0, v31                                  // 0000002238F4: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000002238F8: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 000000223900: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000223904: BF8704B2
	.long 0xd44b0000                                           // 000000223908: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000022390C: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 000000223910: 30141682
	s_and_b32 s9, s1, s0                                       // 000000223914: 8B090001
	s_and_saveexec_b32 s0, s9                                  // 000000223918: BE802009
	s_cbranch_execz 36                                         // 00000022391C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x17b0>
	ds_load_b32 v0, v10 offset:18432                           // 000000223920: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 000000223928: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 000000223930: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 000000223934: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223938: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000022393C: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 000000223944: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 000000223950: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000223954: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 000000223958: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000022395C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 000000223964: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022396C: BF870121
	v_add_f32_e32 v13, v13, v14                                // 000000223970: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 000000223974: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 000000223978: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022397C: BF870095
	.long 0xd71c000d                                           // 000000223980: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 000000223984: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 000000223988: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000022398C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223994: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 000000223998: 02001AFF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 0000002239A0: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002239A8: BF870001
	v_mul_f32_e32 v13, v2, v0                                  // 0000002239AC: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002239B0: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 0000002239B4: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 0000002239BC: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002239C0: BF870112
	.long 0xd73c000e                                           // 0000002239C4: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002239C8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 0000002239CC: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 0000002239D0: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002239D4: BF870092
	.long 0xd700000e                                           // 0000002239D8: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002239DC: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 0000002239E0: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 0000002239E8: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 0000002239F0: BE802009
	s_cbranch_execz 35                                         // 0000002239F4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1884>
	ds_load_b32 v0, v10 offset:18440                           // 0000002239F8: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 000000223A00: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 000000223A08: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 000000223A0C: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223A10: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 000000223A14: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223A1C: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 000000223A24: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 000000223A30: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223A34: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 000000223A38: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 000000223A44: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 000000223A48: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000223A4C: BF870292
	v_exp_f32_e32 v12, v12                                     // 000000223A50: 7E184B0C
	.long 0xd71c000c                                           // 000000223A54: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 000000223A58: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223A5C: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000223A60: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223A64: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 000000223A6C: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223A74: BF870091
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223A78: 100000FF 2F800000
	v_mul_f32_e32 v12, v3, v0                                  // 000000223A80: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223A84: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 000000223A88: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 000000223A90: 38061684
	v_mov_b32_e32 v2, 0                                        // 000000223A94: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000223A98: BF870193
	.long 0xd73c000d                                           // 000000223A9C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223AA0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 000000223AA4: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 000000223AA8: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223AAC: BF870092
	.long 0xd700000f                                           // 000000223AB0: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 000000223AB4: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 000000223AB8: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 000000223AC0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 000000223AC4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s9                                  // 000000223ACC: BE802009
	s_cbranch_execz 35                                         // 000000223AD0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1960>
	ds_load_b32 v0, v10 offset:18448                           // 000000223AD4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 000000223ADC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 000000223AE4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 000000223AE8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223AEC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 000000223AF0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223AF8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 000000223B00: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 000000223B0C: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223B10: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 000000223B14: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 000000223B20: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 000000223B24: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000223B28: BF870292
	v_exp_f32_e32 v12, v12                                     // 000000223B2C: 7E184B0C
	.long 0xd71c000c                                           // 000000223B30: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 000000223B34: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223B38: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000223B3C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223B40: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 000000223B48: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223B50: BF870091
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223B54: 100000FF 2F800000
	v_mul_f32_e32 v13, v4, v0                                  // 000000223B5C: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223B60: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000223B64: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 000000223B6C: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223B70: BF870112
	.long 0xd73c000e                                           // 000000223B74: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223B78: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 000000223B7C: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 000000223B80: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223B84: BF870092
	.long 0xd700000e                                           // 000000223B88: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 000000223B8C: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 000000223B90: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 000000223B98: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 000000223BA0: BE802009
	s_cbranch_execz 36                                         // 000000223BA4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1a38>
	ds_load_b32 v0, v10 offset:18456                           // 000000223BA8: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 000000223BB0: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000223BB8: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 000000223BBC: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223BC0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000223BC4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223BCC: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 000000223BD4: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 000000223BE0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223BE4: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000223BE8: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 000000223BF0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223BF4: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 000000223BF8: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 000000223BFC: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 000000223C00: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223C04: BF870095
	.long 0xd71c0002                                           // 000000223C08: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000223C0C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000223C10: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223C14: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223C1C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000223C20: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223C28: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223C30: BF870001
	v_mul_f32_e32 v2, v5, v0                                   // 000000223C34: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223C38: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000223C3C: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 000000223C44: 38081688
	v_mov_b32_e32 v3, 0                                        // 000000223C48: 7E060280
	v_mov_b32_e32 v5, 0                                        // 000000223C4C: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000223C50: BF870214
	.long 0xd73c000c                                           // 000000223C54: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223C58: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 000000223C5C: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000223C60: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223C64: BF870092
	.long 0xd700000c                                           // 000000223C68: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 000000223C6C: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000223C70: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 000000223C78: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s9                                  // 000000223C80: BE802009
	s_cbranch_execz 36                                         // 000000223C84: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1b18>
	ds_load_b32 v0, v10 offset:18464                           // 000000223C88: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 000000223C90: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000223C98: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 000000223C9C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223CA0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000223CA4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223CAC: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 000000223CB4: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 000000223CC0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223CC4: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 000000223CC8: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 000000223CD0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223CD4: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 000000223CD8: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 000000223CDC: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 000000223CE0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223CE4: BF870095
	.long 0xd71c0002                                           // 000000223CE8: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000223CEC: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000223CF0: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223CF4: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223CFC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000223D00: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223D08: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223D10: BF870001
	v_mul_f32_e32 v5, v6, v0                                   // 000000223D14: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223D18: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 000000223D1C: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 000000223D24: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223D28: BF870112
	.long 0xd73c000c                                           // 000000223D2C: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223D30: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 000000223D34: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 000000223D38: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223D3C: BF870092
	.long 0xd700000c                                           // 000000223D40: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 000000223D44: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000223D48: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 000000223D50: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s9                                  // 000000223D58: BE802009
	s_cbranch_execz 36                                         // 000000223D5C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1bf0>
	ds_load_b32 v0, v10 offset:18472                           // 000000223D60: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 000000223D68: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000223D70: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000223D74: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223D78: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 000000223D7C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 000000223D84: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 000000223D90: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000223D94: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 000000223D98: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223D9C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000223DA4: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223DAC: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 000000223DB0: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 000000223DB4: 7E081105
	v_exp_f32_e32 v3, v3                                       // 000000223DB8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223DBC: BF870095
	.long 0xd71c0003                                           // 000000223DC0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000223DC4: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000223DC8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223DCC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223DD4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 000000223DD8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223DE0: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223DE8: BF870001
	v_mul_f32_e32 v3, v7, v0                                   // 000000223DEC: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223DF0: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 000000223DF4: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 000000223DFC: 3808168C
	v_mov_b32_e32 v2, 0                                        // 000000223E00: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000223E04: BF870193
	.long 0xd73c0005                                           // 000000223E08: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223E0C: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 000000223E10: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000223E14: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223E18: BF870092
	.long 0xd700000c                                           // 000000223E1C: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000223E20: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 000000223E24: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 000000223E2C: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 000000223E30: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s9                                  // 000000223E38: BE802009
	s_cbranch_execz 36                                         // 000000223E3C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x1cd0>
	ds_load_b32 v0, v10 offset:18480                           // 000000223E40: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 000000223E48: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000223E50: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000223E54: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223E58: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 000000223E5C: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 000000223E64: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 000000223E70: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000223E74: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 000000223E78: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 000000223E7C: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223E84: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223E8C: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 000000223E90: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 000000223E94: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 000000223E98: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223E9C: BF870095
	.long 0xd71c0003                                           // 000000223EA0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000223EA4: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000223EA8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223EAC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223EB4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 000000223EB8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223EC0: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223EC8: BF870001
	v_mul_f32_e32 v5, v8, v0                                   // 000000223ECC: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 000000223ED0: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 000000223ED4: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 000000223EDC: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223EE0: BF870112
	.long 0xd73c0006                                           // 000000223EE4: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000223EE8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 000000223EEC: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 000000223EF0: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223EF4: BF870092
	.long 0xd7000006                                           // 000000223EF8: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 000000223EFC: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 000000223F00: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 000000223F08: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 000000223F10: BE802001
	s_cbranch_execz 63806                                      // 000000223F14: BFA5F93E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x210>
	ds_load_b32 v0, v10 offset:18488                           // 000000223F18: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 000000223F20: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000223F28: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 000000223F2C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223F30: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000223F34: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000223F3C: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 000000223F44: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 000000223F50: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000223F54: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000223F58: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 000000223F60: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000223F64: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 000000223F68: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 000000223F6C: 7E081105
	v_exp_f32_e32 v2, v2                                       // 000000223F70: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223F74: BF870095
	.long 0xd71c0002                                           // 000000223F78: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000223F7C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000223F80: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000223F84: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000223F8C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000223F90: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x2f800000, v0                           // 000000223F98: 100000FF 2F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000223FA0: BF870001
	v_mul_f32_e32 v2, v9, v0                                   // 000000223FA4: 10040109
	s_branch 63769                                             // 000000223FA8: BFA0F919 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi16EEEvPKfS3_S3_Pfi+0x210>
	s_endpgm                                                   // 000000223FAC: BFB00000
		...

