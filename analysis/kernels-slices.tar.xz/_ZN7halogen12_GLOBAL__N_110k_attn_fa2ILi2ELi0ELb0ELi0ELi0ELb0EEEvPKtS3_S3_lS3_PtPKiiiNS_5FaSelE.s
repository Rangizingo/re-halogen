0000000000164700 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000164700: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000164704: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000016470C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 000000164714: 3706009F
	v_lshrrev_b32_e32 v148, 5, v0                              // 000000164718: 33280085
	s_mov_b32 s24, s3                                          // 00000016471C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000164720: BF870112
	.long 0xd44c0003                                           // 000000164724: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 000000164728: 02030690
	v_lshlrev_b32_e32 v132, 6, v148                            // 00000016472C: 31092886
	s_waitcnt lgkmcnt(0)                                       // 000000164730: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000164734: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000016473C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000164740: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 000000164744: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000016474C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 000000164758: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000164760: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 000000164764: 160200FF 000002AB
	s_lshl_b32 s25, s2, 5                                      // 00000016476C: 84198502
	v_dual_mov_b32 v142, 0 :: v_dual_and_b32 v147, 15, v0      // 000000164770: CA240080 8E92008F
	s_cmp_eq_u64 s[14:15], 0                                   // 000000164778: BF10800E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000016477C: BF8704C2
	.long 0xd7381001                                           // 000000164780: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000164784: 02020282
	.long 0x7f023880                                           // 000000164788: 7F023880
	v_mov_b32_e32 v141, 0                                      // 00000016478C: 7F1A0280
	s_cselect_b32 s27, -1, 0                                   // 000000164790: 981B80C1
	s_and_b32 vcc_lo, exec_lo, s27                             // 000000164794: 8B6A1B7E
	.long 0xd7620001                                           // 000000164798: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 00000016479C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001647A0: BF870091
	v_add_nc_u32_e32 v149, s25, v1                             // 0000001647A4: 4B2A0219
	v_or_b32_e32 v129, v149, v147                              // 0000001647A8: 39032795
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001647AC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000001647B0: 3505029F
	s_cbranch_vccnz 10                                         // 0000001647B4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000001647B8: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001647C0: BF870091
	.long 0xd73c0001                                           // 0000001647C4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001647C8: 02020282
	.long 0xd7006a8d                                           // 0000001647CC: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000001647D0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001647D4: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000001647D8: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000001647E0: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000001647E4: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000001647EC: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000001647F4: F40C0100 F8000000
	v_mov_b32_e32 v151, 0                                      // 0000001647FC: 7F2E0280
	s_xor_b32 s0, s27, -1                                      // 000000164800: 8D00C11B
	s_waitcnt lgkmcnt(0)                                       // 000000164804: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 000000164808: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000016480C: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000164810: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000164814: BE802017
	s_cbranch_execz 9                                          // 000000164818: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 00000016481C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000164820: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164824: BF870091
	.long 0xd7006a01                                           // 000000164828: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000016482C: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 000000164830: D5207C02 01AA0415
	global_load_b32 v151, v[1:2], off                          // 000000164838: DC520000 977C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000164840: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000164844: BF10800C
	s_mov_b64 s[20:21], 0                                      // 000000164848: BE940180
	s_cbranch_scc1 10                                          // 00000016484C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s22, 31                                     // 000000164850: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000164854: 96810216
	s_mul_i32 s0, s0, s2                                       // 000000164858: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000016485C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 000000164860: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000164864: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000164868: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016486C: BF870009
	s_add_u32 s20, s12, s0                                     // 000000164870: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000164874: 8215010D
	.long 0xd7050001                                           // 000000164878: D7050001
	v_cndmask_b32_e32 v0, v148, v150, vcc_lo                   // 00000016487C: 02012D94
	s_or_b32 s25, s25, 31                                      // 000000164880: 8C199F19
	s_add_i32 s0, s14, -1                                      // 000000164884: 8100C10E
	v_lshrrev_b32_e32 v150, 4, v131                            // 000000164888: 332D0684
	s_min_i32 s0, s25, s0                                      // 00000016488C: 89000019
	.long 0xd7390001                                           // 000000164890: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000164894: 02020288
	s_add_i32 s0, s26, s0                                      // 000000164898: 8100001A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016489C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 0000001648A0: BF04CF00
	.long 0xd7050001                                           // 0000001648A4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000001648A8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001648AC: BF870091
	.long 0xd7040001                                           // 0000001648B0: D7040001
	v_cndmask_b32_e32 v1, v148, v1, vcc_lo                     // 0000001648B4: 02020394
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000001648B8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001648C4: BF870001
	v_mov_b32_e32 v71, v72                                     // 0000001648C8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000001648CC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000001648D0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000001648D4: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000001648D8: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000001648E0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000001648E4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000001648E8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000001648EC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000001648F0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000001648F4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000001648F8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000001648FC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 000000164904: 7E960348
	v_mov_b32_e32 v74, v72                                     // 000000164908: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000016490C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 000000164910: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000164914: 3404029F
	v_mov_b32_e32 v88, v72                                     // 000000164918: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000016491C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 000000164920: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 000000164924: 7EAA0348
	.long 0xd73c008b                                           // 000000164928: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000016492C: 02020281
	v_mov_b32_e32 v84, v72                                     // 000000164930: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 000000164934: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 000000164938: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000016493C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 000000164940: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 000000164944: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 000000164948: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000016494C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 000000164950: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 000000164954: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 000000164958: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000016495C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 000000164960: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 000000164964: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 000000164968: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000016496C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 000000164970: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 000000164974: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 000000164978: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000016497C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 000000164980: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 000000164984: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 000000164988: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000016498C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 000000164990: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 000000164994: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 000000164998: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000016499C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000001649A0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000001649A4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000001649A8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000001649AC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000001649B0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000001649B4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000001649B8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000001649BC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000001649C0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000001649C4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000001649C8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000001649CC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000001649D0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000001649D4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000001649D8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000001649DC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000001649E0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000001649E4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000001649E8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000001649EC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000001649F0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000001649F4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000001649F8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000001649FC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 000000164A00: 7E700348
	v_mov_b32_e32 v55, v72                                     // 000000164A04: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 000000164A08: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 000000164A0C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 000000164A10: 7E680348
	v_mov_b32_e32 v51, v72                                     // 000000164A14: 7E660348
	v_mov_b32_e32 v50, v72                                     // 000000164A18: 7E640348
	v_mov_b32_e32 v49, v72                                     // 000000164A1C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 000000164A20: 7E600348
	v_mov_b32_e32 v47, v72                                     // 000000164A24: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 000000164A28: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 000000164A2C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 000000164A30: 7E580348
	v_mov_b32_e32 v43, v72                                     // 000000164A34: 7E560348
	v_mov_b32_e32 v42, v72                                     // 000000164A38: 7E540348
	v_mov_b32_e32 v41, v72                                     // 000000164A3C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 000000164A40: 7E500348
	v_mov_b32_e32 v39, v72                                     // 000000164A44: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 000000164A48: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 000000164A4C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 000000164A50: 7E480348
	v_mov_b32_e32 v35, v72                                     // 000000164A54: 7E460348
	v_mov_b32_e32 v34, v72                                     // 000000164A58: 7E440348
	v_mov_b32_e32 v33, v72                                     // 000000164A5C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 000000164A60: 7E400348
	v_mov_b32_e32 v31, v72                                     // 000000164A64: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 000000164A68: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 000000164A6C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 000000164A70: 7E380348
	v_mov_b32_e32 v27, v72                                     // 000000164A74: 7E360348
	v_mov_b32_e32 v26, v72                                     // 000000164A78: 7E340348
	v_mov_b32_e32 v25, v72                                     // 000000164A7C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 000000164A80: 7E300348
	v_mov_b32_e32 v23, v72                                     // 000000164A84: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 000000164A88: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 000000164A8C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 000000164A90: 7E280348
	v_mov_b32_e32 v19, v72                                     // 000000164A94: 7E260348
	v_mov_b32_e32 v18, v72                                     // 000000164A98: 7E240348
	v_mov_b32_e32 v17, v72                                     // 000000164A9C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 000000164AA0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 000000164AA4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 000000164AA8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 000000164AAC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 000000164AB0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 000000164AB4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 000000164AB8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 000000164ABC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 000000164AC0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 000000164AC4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 000000164AC8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 000000164ACC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 000000164AD0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 000000164AD4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 000000164AD8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 000000164ADC: 7E020348
	s_cbranch_scc1 2211                                        // 000000164AE0: BFA208A3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2670>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 000000164AE4: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 000000164AF0: 86019F00
	v_add3_u32 v153, v149, v131, s26                           // 000000164AF4: D6550099 006B0795
	s_lshr_b32 s1, s1, 28                                      // 000000164AFC: 85019C01
	v_mad_u32_u24 v164, v147, 48, 0x9600                       // 000000164B00: D60B00A4 03FD6193 00009600
	s_add_i32 s0, s0, s1                                       // 000000164B0C: 81000100
	s_movk_i32 s1, 0x440                                       // 000000164B10: B0010440
	s_ashr_i32 s2, s0, 4                                       // 000000164B14: 86028400
	.long 0xd7006a8f                                           // 000000164B18: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 000000164B1C: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 000000164B20: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 000000164B28: D5207C90 01AB1902
	v_mad_u32_u24 v3, v148, s1, 0x3000                         // 000000164B30: D60B0003 03FC0394 00003000
	s_cmp_eq_u64 s[20:21], 0                                   // 000000164B3C: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 000000164B40: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000164B44: 3404029F
	s_cselect_b32 s4, -1, 0                                    // 000000164B48: 980480C1
	s_cmp_lg_u64 s[20:21], 0                                   // 000000164B4C: BF118014
	v_mad_u32_u24 v4, 0x44, v150, v3                           // 000000164B50: D60B0004 040F2CFF 00000044
	v_mad_u32_u24 v155, 0x44, v131, v3                         // 000000164B5C: D60B009B 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 000000164B68: 3204049E
	s_cselect_b32 s5, -1, 0                                    // 000000164B6C: 980580C1
	s_ashr_i32 s25, s24, 31                                    // 000000164B70: 86199F18
	v_mov_b32_e32 v129, 0                                      // 000000164B74: 7F020280
	v_lshlrev_b32_e32 v5, 2, v131                              // 000000164B78: 300B0682
	v_add_nc_u32_e32 v1, v1, v2                                // 000000164B7C: 4A020501
	v_lshlrev_b32_e32 v2, 3, v0                                // 000000164B80: 30040083
	s_lshl_b64 s[24:25], s[24:25], 9                           // 000000164B84: 84988918
	s_add_i32 s12, s15, -1                                     // 000000164B88: 810CC10F
	s_add_u32 s1, s6, s24                                      // 000000164B8C: 80011806
	.long 0xd44c0000                                           // 000000164B90: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000164B94: 020200FF 00000200
	v_and_b32_e32 v2, 0xf8, v2                                 // 000000164B9C: 360404FF 000000F8
	s_addc_u32 s6, s7, s25                                     // 000000164BA4: 82061907
	v_lshl_add_u32 v152, v147, 2, v4                           // 000000164BA8: D6460098 04110593
	v_ashrrev_i32_e32 v0, 2, v1                                // 000000164BB0: 34000282
	v_lshlrev_b32_e32 v1, 9, v148                              // 000000164BB4: 30032889
	v_mul_u32_u24_e32 v3, 48, v2                               // 000000164BB8: 160604B0
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v6, 0xed00, v132// 000000164BBC: CA200181 070708FF 0000ED00
	s_add_u32 s7, s8, s24                                      // 000000164BC8: 80071808
	s_addc_u32 s8, s9, s25                                     // 000000164BCC: 82081909
	s_delay_alu instid0(VALU_DEP_2)                            // 000000164BD0: BF870002
	v_lshl_or_b32 v3, v148, 1, v3                              // 000000164BD4: D6560003 040D0394
	s_movk_i32 s9, 0x210                                       // 000000164BDC: B0090210
	v_mov_b32_e32 v11, v129                                    // 000000164BE0: 7E160381
	v_lshl_add_u32 v156, v131, 5, v1                           // 000000164BE4: D646009C 04050B83
	v_lshl_or_b32 v159, v150, 2, v6                            // 000000164BEC: D656009F 04190596
	v_dual_mov_b32 v13, v129 :: v_dual_add_nc_u32 v162, 0x9600, v3// 000000164BF4: CA200181 0DA206FF 00009600
	v_dual_mov_b32 v3, v129 :: v_dual_lshlrev_b32 v130, 1, v2  // 000000164C00: CA220181 03820481
	v_mul_u32_u24_e32 v2, 0x210, v148                          // 000000164C08: 160528FF 00000210
	v_lshl_or_b32 v160, v147, 5, v1                            // 000000164C10: D65600A0 04050B93
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v8, v129            // 000000164C18: CA100080 01080181
	v_mov_b32_e32 v17, 0                                       // 000000164C20: 7E220280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000164C24: BF8700C4
	v_add3_u32 v161, v2, v130, 0xc600                          // 000000164C28: D65500A1 03FF0502 0000C600
	v_mov_b32_e32 v2, v129                                     // 000000164C34: 7E040381
	v_add_nc_u32_e32 v4, v132, v5                              // 000000164C38: 4A080B84
	.long 0xd70001a5                                           // 000000164C3C: D70001A5
	v_cndmask_b32_e32 v1, s1, v130, vcc_lo                     // 000000164C40: 02030401
	v_add_co_ci_u32_e64 v166, null, s6, 0, s1                  // 000000164C44: D5207CA6 00050006
	.long 0xd70001a7                                           // 000000164C4C: D70001A7
	v_cndmask_b32_e32 v1, s7, v130, vcc_lo                     // 000000164C50: 02030407
	s_delay_alu instid0(VALU_DEP_4)                            // 000000164C54: BF870004
	v_add_nc_u32_e32 v154, 0xe700, v4                          // 000000164C58: 4B3408FF 0000E700
	v_add_nc_u32_e32 v157, 0xf300, v4                          // 000000164C60: 4B3A08FF 0000F300
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v158, v6, v5     // 000000164C68: CA200080 099E0B06
	v_mov_b32_e32 v4, v129                                     // 000000164C70: 7E080381
	v_mov_b32_e32 v5, v129                                     // 000000164C74: 7E0A0381
	v_mov_b32_e32 v6, v129                                     // 000000164C78: 7E0C0381
	v_dual_mov_b32 v10, v129 :: v_dual_mov_b32 v25, 0          // 000000164C7C: CA100181 0A180080
	v_dual_mov_b32 v12, v129 :: v_dual_mov_b32 v33, 0          // 000000164C84: CA100181 0C200080
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v41, 0          // 000000164C8C: CA100181 0E280080
	v_mov_b32_e32 v15, v129                                    // 000000164C94: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v49, 0          // 000000164C98: CA100181 10300080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v57, 0          // 000000164CA0: CA100181 12380080
	v_mov_b32_e32 v19, v129                                    // 000000164CA8: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v121, 0         // 000000164CAC: CA100181 14780080
	v_mov_b32_e32 v21, v129                                    // 000000164CB4: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v113, 0         // 000000164CB8: CA100181 16700080
	v_mov_b32_e32 v23, v129                                    // 000000164CC0: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v105, 0         // 000000164CC4: CA100181 18680080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v97, 0          // 000000164CCC: CA100181 1A600080
	v_mov_b32_e32 v27, v129                                    // 000000164CD4: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v89, 0          // 000000164CD8: CA100181 1C580080
	v_mov_b32_e32 v29, v129                                    // 000000164CE0: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v81, 0          // 000000164CE4: CA100181 1E500080
	v_mov_b32_e32 v31, v129                                    // 000000164CEC: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v73, 0          // 000000164CF0: CA100181 20480080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v65, 0          // 000000164CF8: CA100181 22400080
	v_mov_b32_e32 v35, v129                                    // 000000164D00: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v145, 0         // 000000164D04: CA100181 24900080
	v_mov_b32_e32 v37, v129                                    // 000000164D0C: 7E4A0381
	v_mov_b32_e32 v38, v129                                    // 000000164D10: 7E4C0381
	v_mov_b32_e32 v39, v129                                    // 000000164D14: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 000000164D18: 7E500381
	v_mov_b32_e32 v42, v129                                    // 000000164D1C: 7E540381
	v_mov_b32_e32 v43, v129                                    // 000000164D20: 7E560381
	v_mov_b32_e32 v44, v129                                    // 000000164D24: 7E580381
	v_mov_b32_e32 v45, v129                                    // 000000164D28: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 000000164D2C: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 000000164D30: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000164D34: 7E600381
	v_mov_b32_e32 v50, v129                                    // 000000164D38: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000164D3C: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000164D40: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000164D44: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 000000164D48: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000164D4C: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000164D50: 7E700381
	v_mov_b32_e32 v58, v129                                    // 000000164D54: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000164D58: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000164D5C: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000164D60: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 000000164D64: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000164D68: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000164D6C: 7E800381
	v_mov_b32_e32 v122, v129                                   // 000000164D70: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 000000164D74: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 000000164D78: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 000000164D7C: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 000000164D80: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 000000164D84: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 000000164D88: 7F000381
	v_mov_b32_e32 v114, v129                                   // 000000164D8C: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 000000164D90: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 000000164D94: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 000000164D98: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 000000164D9C: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 000000164DA0: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 000000164DA4: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 000000164DA8: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 000000164DAC: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 000000164DB0: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 000000164DB4: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 000000164DB8: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 000000164DBC: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 000000164DC0: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 000000164DC4: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 000000164DC8: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 000000164DCC: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 000000164DD0: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 000000164DD4: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 000000164DD8: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 000000164DDC: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 000000164DE0: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 000000164DE4: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 000000164DE8: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 000000164DEC: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 000000164DF0: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 000000164DF4: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 000000164DF8: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 000000164DFC: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 000000164E00: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 000000164E04: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 000000164E08: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 000000164E0C: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 000000164E10: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 000000164E14: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 000000164E18: 7E940381
	v_mov_b32_e32 v75, v129                                    // 000000164E1C: 7E960381
	v_mov_b32_e32 v76, v129                                    // 000000164E20: 7E980381
	v_mov_b32_e32 v77, v129                                    // 000000164E24: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 000000164E28: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 000000164E2C: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000164E30: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 000000164E34: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000164E38: 7E860381
	v_mov_b32_e32 v68, v129                                    // 000000164E3C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000164E40: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 000000164E44: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000164E48: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 000000164E4C: 7E900381
	v_mad_u32_u24 v163, v147, s9, 0xc600                       // 000000164E50: D60B00A3 03FC1393 0000C600
	v_add_co_ci_u32_e64 v168, null, s8, 0, s1                  // 000000164E5C: D5207CA8 00050008
	s_mov_b32 s6, 0                                            // 000000164E64: BE860080
	s_branch 298                                               // 000000164E68: BFA0012A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc14>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000164E6C: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 000000164E70: 07070985
	ds_load_b32 v132, v157                                     // 000000164E74: D8D80000 8400009D
	v_add_f32_e32 v131, v131, v135                             // 000000164E7C: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164E80: BF870091
	v_add_f32_e32 v131, v131, v134                             // 000000164E84: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 000000164E88: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164E8C: BF870091
	v_add_f32_e32 v131, v131, v136                             // 000000164E90: 07071183
	v_add_f32_e32 v131, v131, v169                             // 000000164E94: 07075383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164E98: BF870091
	v_add_f32_e32 v131, v131, v146                             // 000000164E9C: 07072583
	v_add_f32_e32 v131, v131, v171                             // 000000164EA0: 07075783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164EA4: BF870091
	v_add_f32_e32 v131, v131, v170                             // 000000164EA8: 07075583
	v_add_f32_e32 v131, v131, v173                             // 000000164EAC: 07075B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164EB0: BF870091
	v_add_f32_e32 v131, v131, v172                             // 000000164EB4: 07075983
	v_add_f32_e32 v131, v131, v175                             // 000000164EB8: 07075F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000164EBC: BF870091
	v_add_f32_e32 v131, v131, v174                             // 000000164EC0: 07075D83
	v_add_f32_e32 v131, v131, v177                             // 000000164EC4: 07076383
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000164EC8: BF8700A1
	v_add_f32_e32 v131, v131, v176                             // 000000164ECC: 07076183
	s_waitcnt lgkmcnt(0)                                       // 000000164ED0: BF89FC07
	v_fmac_f32_e32 v131, v178, v132                            // 000000164ED4: 570709B2
	ds_store_b32 v154, v130                                    // 000000164ED8: D8340000 0000829A
	ds_store_b32 v157, v131                                    // 000000164EE0: D8340000 0000839D
	ds_store_b32 v158, v178                                    // 000000164EE8: D8340000 0000B29E
	s_or_b32 exec_lo, exec_lo, s8                              // 000000164EF0: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000164EF4: BF89FC07
	s_barrier                                                  // 000000164EF8: BFBD0000
	buffer_gl0_inv                                             // 000000164EFC: E0AC0000 00000000
	ds_load_2addr_b32 v[169:170], v159 offset1:2               // 000000164F04: D8DC0200 A900009F
	ds_load_2addr_b32 v[171:172], v159 offset0:4 offset1:6     // 000000164F0C: D8DC0604 AB00009F
	ds_load_2addr_b32 v[173:174], v159 offset0:8 offset1:10    // 000000164F14: D8DC0A08 AD00009F
	ds_load_2addr_b32 v[175:176], v159 offset0:12 offset1:14   // 000000164F1C: D8DC0E0C AF00009F
	ds_load_b128 v[130:133], v160                              // 000000164F24: DBFC0000 820000A0
	ds_load_b128 v[134:137], v160 offset:16                    // 000000164F2C: DBFC0010 860000A0
	s_waitcnt lgkmcnt(5)                                       // 000000164F34: BF89FC57
	v_dual_mul_f32 v121, v169, v121 :: v_dual_mul_f32 v122, v170, v122// 000000164F38: C8C6F3A9 797AF5AA
	s_waitcnt lgkmcnt(4)                                       // 000000164F40: BF89FC47
	v_dual_mul_f32 v123, v171, v123 :: v_dual_mul_f32 v124, v172, v124// 000000164F44: C8C6F7AB 7B7CF9AC
	s_waitcnt lgkmcnt(3)                                       // 000000164F4C: BF89FC37
	v_dual_mul_f32 v125, v173, v125 :: v_dual_mul_f32 v126, v174, v126// 000000164F50: C8C6FBAD 7D7EFDAE
	s_waitcnt lgkmcnt(2)                                       // 000000164F58: BF89FC27
	v_dual_mul_f32 v127, v175, v127 :: v_dual_mul_f32 v128, v176, v128// 000000164F5C: C8C6FFAF 7F8101B0
	v_dual_mul_f32 v113, v169, v113 :: v_dual_mul_f32 v114, v170, v114// 000000164F64: C8C6E3A9 7172E5AA
	v_dual_mul_f32 v115, v171, v115 :: v_dual_mul_f32 v116, v172, v116// 000000164F6C: C8C6E7AB 7374E9AC
	v_dual_mul_f32 v117, v173, v117 :: v_dual_mul_f32 v118, v174, v118// 000000164F74: C8C6EBAD 7576EDAE
	v_dual_mul_f32 v119, v175, v119 :: v_dual_mul_f32 v120, v176, v120// 000000164F7C: C8C6EFAF 7778F1B0
	v_dual_mul_f32 v105, v169, v105 :: v_dual_mul_f32 v106, v170, v106// 000000164F84: C8C6D3A9 696AD5AA
	v_dual_mul_f32 v107, v171, v107 :: v_dual_mul_f32 v108, v172, v108// 000000164F8C: C8C6D7AB 6B6CD9AC
	v_dual_mul_f32 v109, v173, v109 :: v_dual_mul_f32 v110, v174, v110// 000000164F94: C8C6DBAD 6D6EDDAE
	v_dual_mul_f32 v111, v175, v111 :: v_dual_mul_f32 v112, v176, v112// 000000164F9C: C8C6DFAF 6F70E1B0
	v_dual_mul_f32 v97, v169, v97 :: v_dual_mul_f32 v98, v170, v98// 000000164FA4: C8C6C3A9 6162C5AA
	v_dual_mul_f32 v99, v171, v99 :: v_dual_mul_f32 v100, v172, v100// 000000164FAC: C8C6C7AB 6364C9AC
	v_dual_mul_f32 v101, v173, v101 :: v_dual_mul_f32 v102, v174, v102// 000000164FB4: C8C6CBAD 6566CDAE
	v_dual_mul_f32 v103, v175, v103 :: v_dual_mul_f32 v104, v176, v104// 000000164FBC: C8C6CFAF 6768D1B0
	v_dual_mul_f32 v89, v169, v89 :: v_dual_mul_f32 v90, v170, v90// 000000164FC4: C8C6B3A9 595AB5AA
	v_dual_mul_f32 v91, v171, v91 :: v_dual_mul_f32 v92, v172, v92// 000000164FCC: C8C6B7AB 5B5CB9AC
	v_dual_mul_f32 v93, v173, v93 :: v_dual_mul_f32 v94, v174, v94// 000000164FD4: C8C6BBAD 5D5EBDAE
	v_dual_mul_f32 v95, v175, v95 :: v_dual_mul_f32 v96, v176, v96// 000000164FDC: C8C6BFAF 5F60C1B0
	v_dual_mul_f32 v81, v169, v81 :: v_dual_mul_f32 v82, v170, v82// 000000164FE4: C8C6A3A9 5152A5AA
	v_dual_mul_f32 v83, v171, v83 :: v_dual_mul_f32 v84, v172, v84// 000000164FEC: C8C6A7AB 5354A9AC
	v_dual_mul_f32 v85, v173, v85 :: v_dual_mul_f32 v86, v174, v86// 000000164FF4: C8C6ABAD 5556ADAE
	v_dual_mul_f32 v87, v175, v87 :: v_dual_mul_f32 v88, v176, v88// 000000164FFC: C8C6AFAF 5758B1B0
	v_dual_mul_f32 v73, v169, v73 :: v_dual_mul_f32 v74, v170, v74// 000000165004: C8C693A9 494A95AA
	v_dual_mul_f32 v75, v171, v75 :: v_dual_mul_f32 v76, v172, v76// 00000016500C: C8C697AB 4B4C99AC
	v_dual_mul_f32 v77, v173, v77 :: v_dual_mul_f32 v78, v174, v78// 000000165014: C8C69BAD 4D4E9DAE
	v_dual_mul_f32 v79, v175, v79 :: v_dual_mul_f32 v80, v176, v80// 00000016501C: C8C69FAF 4F50A1B0
	v_dual_mul_f32 v65, v169, v65 :: v_dual_mul_f32 v66, v170, v66// 000000165024: C8C683A9 414285AA
	v_dual_mul_f32 v67, v171, v67 :: v_dual_mul_f32 v68, v172, v68// 00000016502C: C8C687AB 434489AC
	v_dual_mul_f32 v69, v173, v69 :: v_dual_mul_f32 v70, v174, v70// 000000165034: C8C68BAD 45468DAE
	v_dual_mul_f32 v71, v175, v71 :: v_dual_mul_f32 v72, v176, v72// 00000016503C: C8C68FAF 474891B0
	v_dual_mul_f32 v57, v169, v57 :: v_dual_mul_f32 v58, v170, v58// 000000165044: C8C673A9 393A75AA
	v_dual_mul_f32 v59, v171, v59 :: v_dual_mul_f32 v60, v172, v60// 00000016504C: C8C677AB 3B3C79AC
	v_dual_mul_f32 v61, v173, v61 :: v_dual_mul_f32 v62, v174, v62// 000000165054: C8C67BAD 3D3E7DAE
	v_dual_mul_f32 v63, v175, v63 :: v_dual_mul_f32 v64, v176, v64// 00000016505C: C8C67FAF 3F4081B0
	v_dual_mul_f32 v49, v169, v49 :: v_dual_mul_f32 v50, v170, v50// 000000165064: C8C663A9 313265AA
	v_dual_mul_f32 v51, v171, v51 :: v_dual_mul_f32 v52, v172, v52// 00000016506C: C8C667AB 333469AC
	v_dual_mul_f32 v53, v173, v53 :: v_dual_mul_f32 v54, v174, v54// 000000165074: C8C66BAD 35366DAE
	v_dual_mul_f32 v55, v175, v55 :: v_dual_mul_f32 v56, v176, v56// 00000016507C: C8C66FAF 373871B0
	v_dual_mul_f32 v41, v169, v41 :: v_dual_mul_f32 v42, v170, v42// 000000165084: C8C653A9 292A55AA
	v_dual_mul_f32 v43, v171, v43 :: v_dual_mul_f32 v44, v172, v44// 00000016508C: C8C657AB 2B2C59AC
	v_dual_mul_f32 v45, v173, v45 :: v_dual_mul_f32 v46, v174, v46// 000000165094: C8C65BAD 2D2E5DAE
	v_dual_mul_f32 v47, v175, v47 :: v_dual_mul_f32 v48, v176, v48// 00000016509C: C8C65FAF 2F3061B0
	v_dual_mul_f32 v33, v169, v33 :: v_dual_mul_f32 v34, v170, v34// 0000001650A4: C8C643A9 212245AA
	v_dual_mul_f32 v35, v171, v35 :: v_dual_mul_f32 v36, v172, v36// 0000001650AC: C8C647AB 232449AC
	v_dual_mul_f32 v37, v173, v37 :: v_dual_mul_f32 v38, v174, v38// 0000001650B4: C8C64BAD 25264DAE
	v_dual_mul_f32 v39, v175, v39 :: v_dual_mul_f32 v40, v176, v40// 0000001650BC: C8C64FAF 272851B0
	v_dual_mul_f32 v25, v169, v25 :: v_dual_mul_f32 v26, v170, v26// 0000001650C4: C8C633A9 191A35AA
	v_dual_mul_f32 v27, v171, v27 :: v_dual_mul_f32 v28, v172, v28// 0000001650CC: C8C637AB 1B1C39AC
	v_dual_mul_f32 v29, v173, v29 :: v_dual_mul_f32 v30, v174, v30// 0000001650D4: C8C63BAD 1D1E3DAE
	v_dual_mul_f32 v31, v175, v31 :: v_dual_mul_f32 v32, v176, v32// 0000001650DC: C8C63FAF 1F2041B0
	v_dual_mul_f32 v17, v169, v17 :: v_dual_mul_f32 v18, v170, v18// 0000001650E4: C8C623A9 111225AA
	v_dual_mul_f32 v19, v171, v19 :: v_dual_mul_f32 v20, v172, v20// 0000001650EC: C8C627AB 131429AC
	v_dual_mul_f32 v21, v173, v21 :: v_dual_mul_f32 v22, v174, v22// 0000001650F4: C8C62BAD 15162DAE
	v_dual_mul_f32 v23, v175, v23 :: v_dual_mul_f32 v24, v176, v24// 0000001650FC: C8C62FAF 171831B0
	v_dual_mul_f32 v9, v169, v9 :: v_dual_mul_f32 v10, v170, v10// 000000165104: C8C613A9 090A15AA
	v_dual_mul_f32 v11, v171, v11 :: v_dual_mul_f32 v12, v172, v12// 00000016510C: C8C617AB 0B0C19AC
	v_dual_mul_f32 v13, v173, v13 :: v_dual_mul_f32 v14, v174, v14// 000000165114: C8C61BAD 0D0E1DAE
	v_dual_mul_f32 v15, v175, v15 :: v_dual_mul_f32 v16, v176, v16// 00000016511C: C8C61FAF 0F1021B0
	v_dual_mul_f32 v1, v169, v1 :: v_dual_mul_f32 v2, v170, v2 // 000000165124: C8C603A9 010205AA
	v_dual_mul_f32 v3, v171, v3 :: v_dual_mul_f32 v4, v172, v4 // 00000016512C: C8C607AB 030409AC
	v_dual_mul_f32 v5, v173, v5 :: v_dual_mul_f32 v6, v174, v6 // 000000165134: C8C60BAD 05060DAE
	v_dual_mul_f32 v7, v175, v7 :: v_dual_mul_f32 v8, v176, v8 // 00000016513C: C8C60FAF 070811B0
	ds_load_b128 v[169:172], v164                              // 000000165144: DBFC0000 A90000A4
	ds_load_b128 v[173:176], v164 offset:16                    // 00000016514C: DBFC0010 AD0000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165154: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[169:176], v[121:128]// 000000165158: CC414079 1DE75382
	ds_load_b128 v[173:176], v164 offset:784                   // 000000165160: DBFC0310 AD0000A4
	ds_load_b128 v[169:172], v164 offset:768                   // 000000165168: DBFC0300 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165170: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[169:176], v[113:120]// 000000165174: CC414071 1DC75382
	ds_load_b128 v[173:176], v164 offset:1552                  // 00000016517C: DBFC0610 AD0000A4
	ds_load_b128 v[169:172], v164 offset:1536                  // 000000165184: DBFC0600 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000016518C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[169:176], v[105:112]// 000000165190: CC414069 1DA75382
	ds_load_b128 v[173:176], v164 offset:2320                  // 000000165198: DBFC0910 AD0000A4
	ds_load_b128 v[169:172], v164 offset:2304                  // 0000001651A0: DBFC0900 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001651A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[169:176], v[97:104]// 0000001651AC: CC414061 1D875382
	ds_load_b128 v[173:176], v164 offset:3088                  // 0000001651B4: DBFC0C10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:3072                  // 0000001651BC: DBFC0C00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001651C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[169:176], v[89:96]// 0000001651C8: CC414059 1D675382
	ds_load_b128 v[173:176], v164 offset:3856                  // 0000001651D0: DBFC0F10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:3840                  // 0000001651D8: DBFC0F00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001651E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[169:176], v[81:88]// 0000001651E4: CC414051 1D475382
	ds_load_b128 v[173:176], v164 offset:4624                  // 0000001651EC: DBFC1210 AD0000A4
	ds_load_b128 v[169:172], v164 offset:4608                  // 0000001651F4: DBFC1200 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001651FC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[169:176], v[73:80]// 000000165200: CC414049 1D275382
	ds_load_b128 v[173:176], v164 offset:5392                  // 000000165208: DBFC1510 AD0000A4
	ds_load_b128 v[169:172], v164 offset:5376                  // 000000165210: DBFC1500 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165218: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[169:176], v[65:72]// 00000016521C: CC414041 1D075382
	ds_load_b128 v[173:176], v164 offset:6160                  // 000000165224: DBFC1810 AD0000A4
	ds_load_b128 v[169:172], v164 offset:6144                  // 00000016522C: DBFC1800 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165234: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[169:176], v[57:64]// 000000165238: CC414039 1CE75382
	ds_load_b128 v[173:176], v164 offset:6928                  // 000000165240: DBFC1B10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:6912                  // 000000165248: DBFC1B00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165250: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[169:176], v[49:56]// 000000165254: CC414031 1CC75382
	ds_load_b128 v[173:176], v164 offset:7696                  // 00000016525C: DBFC1E10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:7680                  // 000000165264: DBFC1E00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000016526C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[169:176], v[41:48]// 000000165270: CC414029 1CA75382
	ds_load_b128 v[173:176], v164 offset:8464                  // 000000165278: DBFC2110 AD0000A4
	ds_load_b128 v[169:172], v164 offset:8448                  // 000000165280: DBFC2100 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 000000165288: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[169:176], v[33:40]// 00000016528C: CC414021 1C875382
	ds_load_b128 v[173:176], v164 offset:9232                  // 000000165294: DBFC2410 AD0000A4
	ds_load_b128 v[169:172], v164 offset:9216                  // 00000016529C: DBFC2400 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001652A4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[169:176], v[25:32]// 0000001652A8: CC414019 1C675382
	ds_load_b128 v[173:176], v164 offset:10000                 // 0000001652B0: DBFC2710 AD0000A4
	ds_load_b128 v[169:172], v164 offset:9984                  // 0000001652B8: DBFC2700 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001652C0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[169:176], v[17:24]// 0000001652C4: CC414011 1C475382
	ds_load_b128 v[173:176], v164 offset:10768                 // 0000001652CC: DBFC2A10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:10752                 // 0000001652D4: DBFC2A00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001652DC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[169:176], v[9:16]// 0000001652E0: CC414009 1C275382
	ds_load_b128 v[173:176], v164 offset:11536                 // 0000001652E8: DBFC2D10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:11520                 // 0000001652F0: DBFC2D00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 0000001652F8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[169:176], v[1:8]// 0000001652FC: CC414001 1C075382
	s_add_i32 s1, s6, 1                                        // 000000165304: 81018106
	s_cmp_eq_u32 s6, s2                                        // 000000165308: BF060206
	s_mov_b32 s6, s1                                           // 00000016530C: BE860001
	s_cbranch_scc1 1687                                        // 000000165310: BFA20697 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2670>
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 000000165314: 916A057E
	s_mov_b32 s1, s4                                           // 000000165318: BE810004
	s_cbranch_vccz 3                                           // 00000016531C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc2c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000165320: 916A017E
	s_cbranch_vccnz 65527                                      // 000000165324: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc04>
	s_branch 15                                                // 000000165328: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc68>
	s_lshr_b32 s1, s6, 3                                       // 00000016532C: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165330: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000165334: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000016533C: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 000000165340: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 000000165348: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 00000016534C: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165350: BF870091
	v_and_b32_e32 v130, 1, v130                                // 000000165354: 37050481
	.long 0xd44a0001                                           // 000000165358: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000016535C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000165360: 916A017E
	s_cbranch_vccnz 65511                                      // 000000165364: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc04>
	s_lshl_b32 s7, s6, 4                                       // 000000165368: 84078406
	s_waitcnt vmcnt(0)                                         // 00000016536C: BF8903F7
	s_barrier                                                  // 000000165370: BFBD0000
	buffer_gl0_inv                                             // 000000165374: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000016537C: BE812000
	s_cbranch_execz 49                                         // 000000165380: BFA50031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd48>
	v_or_b32_e32 v130, s7, v148                                // 000000165384: 39052807
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165388: BF870091
	v_min_i32_e32 v130, s12, v130                              // 00000016538C: 2305040C
	v_ashrrev_i32_e32 v132, 31, v130                           // 000000165390: 3509049F
	.long 0xd72c0085                                           // 000000165394: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 000000165398: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000016539C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001653A4: BF870093
	.long 0xd72c0084                                           // 0000001653A8: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 0000001653AC: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 0000001653B0: D6550083 06170983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001653B8: BF870091
	.long 0xd73c0082                                           // 0000001653BC: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000001653C0: 02030481
	.long 0xd7006a84                                           // 0000001653C4: D7006A84
	v_cndmask_b32_e32 v1, v165, v130, vcc_lo                   // 0000001653C8: 020305A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001653CC: BF8700A1
	v_add_co_ci_u32_e64 v133, null, v166, v131, vcc_lo         // 0000001653D0: D5207C85 01AB07A6
	.long 0xd7006a86                                           // 0000001653D8: D7006A86
	v_cndmask_b32_e32 v1, v167, v130, vcc_lo                   // 0000001653DC: 020305A7
	v_add_co_ci_u32_e64 v135, null, v168, v131, vcc_lo         // 0000001653E0: D5207C87 01AB07A8
	global_load_b128 v[130:133], v[132:133], off               // 0000001653E8: DC5E0000 827C0084
	global_load_b128 v[134:137], v[134:135], off               // 0000001653F0: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 0000001653F8: BF8907F7
	ds_store_b128 v161, v[130:133]                             // 0000001653FC: DB7C0000 000082A1
	s_waitcnt vmcnt(0)                                         // 000000165404: BF8903F7
	ds_store_b16 v162, v134                                    // 000000165408: D87C0000 000086A2
	ds_store_b16_d16_hi v162, v134 offset:48                   // 000000165410: DA840030 000086A2
	ds_store_b16 v162, v135 offset:96                          // 000000165418: D87C0060 000087A2
	ds_store_b16_d16_hi v162, v135 offset:144                  // 000000165420: DA840090 000087A2
	ds_store_b16 v162, v136 offset:192                         // 000000165428: D87C00C0 000088A2
	ds_store_b16_d16_hi v162, v136 offset:240                  // 000000165430: DA8400F0 000088A2
	ds_store_b16 v162, v137 offset:288                         // 000000165438: D87C0120 000089A2
	ds_store_b16_d16_hi v162, v137 offset:336                  // 000000165440: DA840150 000089A2
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165448: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000016544C: BF89FC07
	s_barrier                                                  // 000000165450: BFBD0000
	buffer_gl0_inv                                             // 000000165454: E0AC0000 00000000
	s_clause 0x1                                               // 00000016545C: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:16     // 000000165460: DC5E0010 AD7C008F
	global_load_b128 v[169:172], v[143:144], off               // 000000165468: DC5E0000 A97C008F
	ds_load_b128 v[177:180], v163                              // 000000165470: DBFC0000 B10000A3
	ds_load_b128 v[181:184], v163 offset:16                    // 000000165478: DBFC0010 B50000A3
	v_mov_b32_e32 v136, v129                                   // 000000165480: 7F100381
	v_mov_b32_e32 v130, v129                                   // 000000165484: 7F040381
	v_mov_b32_e32 v131, v129                                   // 000000165488: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000016548C: 7F080381
	v_mov_b32_e32 v133, v129                                   // 000000165490: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 000000165494: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 000000165498: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000016549C: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001654A0: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000001654A4: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000001654A8: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000001654AC: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000001654B0: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000001654B4: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000001654B8: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000001654BC: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001654C0: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001654C4: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001654C8: CC414082 1E0B63A9
	s_clause 0x1                                               // 0000001654D0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:48     // 0000001654D4: DC5E0030 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:32     // 0000001654DC: DC5E0020 A97C008F
	ds_load_b128 v[177:180], v163 offset:32                    // 0000001654E4: DBFC0020 B10000A3
	ds_load_b128 v[181:184], v163 offset:48                    // 0000001654EC: DBFC0030 B50000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001654F4: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001654F8: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165500: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:80     // 000000165504: DC5E0050 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:64     // 00000016550C: DC5E0040 A97C008F
	ds_load_b128 v[181:184], v163 offset:80                    // 000000165514: DBFC0050 B50000A3
	ds_load_b128 v[177:180], v163 offset:64                    // 00000016551C: DBFC0040 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165524: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165528: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165530: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:112    // 000000165534: DC5E0070 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:96     // 00000016553C: DC5E0060 A97C008F
	ds_load_b128 v[181:184], v163 offset:112                   // 000000165544: DBFC0070 B50000A3
	ds_load_b128 v[177:180], v163 offset:96                    // 00000016554C: DBFC0060 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165554: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165558: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165560: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:144    // 000000165564: DC5E0090 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:128    // 00000016556C: DC5E0080 A97C008F
	ds_load_b128 v[181:184], v163 offset:144                   // 000000165574: DBFC0090 B50000A3
	ds_load_b128 v[177:180], v163 offset:128                   // 00000016557C: DBFC0080 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165584: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165588: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165590: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:176    // 000000165594: DC5E00B0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:160    // 00000016559C: DC5E00A0 A97C008F
	ds_load_b128 v[181:184], v163 offset:176                   // 0000001655A4: DBFC00B0 B50000A3
	ds_load_b128 v[177:180], v163 offset:160                   // 0000001655AC: DBFC00A0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001655B4: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001655B8: CC414082 1E0B63A9
	s_clause 0x1                                               // 0000001655C0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:208    // 0000001655C4: DC5E00D0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:192    // 0000001655CC: DC5E00C0 A97C008F
	ds_load_b128 v[181:184], v163 offset:208                   // 0000001655D4: DBFC00D0 B50000A3
	ds_load_b128 v[177:180], v163 offset:192                   // 0000001655DC: DBFC00C0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001655E4: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001655E8: CC414082 1E0B63A9
	s_clause 0x1                                               // 0000001655F0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:240    // 0000001655F4: DC5E00F0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:224    // 0000001655FC: DC5E00E0 A97C008F
	ds_load_b128 v[181:184], v163 offset:240                   // 000000165604: DBFC00F0 B50000A3
	ds_load_b128 v[177:180], v163 offset:224                   // 00000016560C: DBFC00E0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165614: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165618: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165620: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:272    // 000000165624: DC5E0110 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:256    // 00000016562C: DC5E0100 A97C008F
	ds_load_b128 v[181:184], v163 offset:272                   // 000000165634: DBFC0110 B50000A3
	ds_load_b128 v[177:180], v163 offset:256                   // 00000016563C: DBFC0100 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165644: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165648: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165650: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:304    // 000000165654: DC5E0130 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:288    // 00000016565C: DC5E0120 A97C008F
	ds_load_b128 v[181:184], v163 offset:304                   // 000000165664: DBFC0130 B50000A3
	ds_load_b128 v[177:180], v163 offset:288                   // 00000016566C: DBFC0120 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165674: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165678: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165680: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:336    // 000000165684: DC5E0150 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:320    // 00000016568C: DC5E0140 A97C008F
	ds_load_b128 v[181:184], v163 offset:336                   // 000000165694: DBFC0150 B50000A3
	ds_load_b128 v[177:180], v163 offset:320                   // 00000016569C: DBFC0140 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001656A4: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001656A8: CC414082 1E0B63A9
	s_clause 0x1                                               // 0000001656B0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:368    // 0000001656B4: DC5E0170 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:352    // 0000001656BC: DC5E0160 A97C008F
	ds_load_b128 v[181:184], v163 offset:368                   // 0000001656C4: DBFC0170 B50000A3
	ds_load_b128 v[177:180], v163 offset:352                   // 0000001656CC: DBFC0160 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001656D4: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 0000001656D8: CC414082 1E0B63A9
	s_clause 0x1                                               // 0000001656E0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:400    // 0000001656E4: DC5E0190 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:384    // 0000001656EC: DC5E0180 A97C008F
	ds_load_b128 v[181:184], v163 offset:400                   // 0000001656F4: DBFC0190 B50000A3
	ds_load_b128 v[177:180], v163 offset:384                   // 0000001656FC: DBFC0180 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165704: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165708: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165710: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:432    // 000000165714: DC5E01B0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:416    // 00000016571C: DC5E01A0 A97C008F
	ds_load_b128 v[181:184], v163 offset:432                   // 000000165724: DBFC01B0 B50000A3
	ds_load_b128 v[177:180], v163 offset:416                   // 00000016572C: DBFC01A0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165734: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165738: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165740: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:464    // 000000165744: DC5E01D0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:448    // 00000016574C: DC5E01C0 A97C008F
	ds_load_b128 v[181:184], v163 offset:464                   // 000000165754: DBFC01D0 B50000A3
	ds_load_b128 v[177:180], v163 offset:448                   // 00000016575C: DBFC01C0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165764: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165768: CC414082 1E0B63A9
	s_clause 0x1                                               // 000000165770: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:496    // 000000165774: DC5E01F0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:480    // 00000016577C: DC5E01E0 A97C008F
	ds_load_b128 v[181:184], v163 offset:496                   // 000000165784: DBFC01F0 B50000A3
	ds_load_b128 v[177:180], v163 offset:480                   // 00000016578C: DBFC01E0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000165794: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 000000165798: CC414082 1E0B63A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001657A0: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000001657A4: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000001657B0: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000001657B8: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001657C0: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000001657C4: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000001657CC: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000001657D8: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v152, v130, v131 offset1:34             // 0000001657E4: D8382200 00838298
	ds_store_2addr_b32 v152, v132, v146 offset0:68 offset1:102 // 0000001657EC: D8386644 00928498
	ds_store_2addr_b32 v152, v134, v135 offset0:136 offset1:170// 0000001657F4: D838AA88 00878698
	ds_store_2addr_b32 v152, v136, v137 offset0:204 offset1:238// 0000001657FC: D838EECC 00898898
	s_waitcnt lgkmcnt(0)                                       // 000000165804: BF89FC07
	s_barrier                                                  // 000000165808: BFBD0000
	buffer_gl0_inv                                             // 00000016580C: E0AC0000 00000000
	s_and_saveexec_b32 s8, s23                                 // 000000165814: BE882017
	s_cbranch_execz 365                                        // 000000165818: BFA5016D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d0>
	s_lshl_b32 s9, s6, 2                                       // 00000016581C: 84098206
	s_mov_b32 s13, exec_lo                                     // 000000165820: BE8D007E
	.long 0xd4c1007e                                           // 000000165824: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 000000165828: 02032F91
	s_cbranch_execz 50                                         // 00000016582C: BFA50032 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11f8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 000000165830: 3525229F
	s_mov_b32 s15, 0                                           // 000000165834: BE8F0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165838: BF870091
	.long 0xd73c0082                                           // 00000016583C: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 000000165840: 02032282
	.long 0xd7006a82                                           // 000000165844: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 000000165848: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016584C: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 000000165850: D5207C83 01AB078E
	s_branch 17                                                // 000000165858: BFA00011 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a0>
	s_nop 0                                                    // 00000016585C: BF800000
	s_nop 0                                                    // 000000165860: BF800000
	s_nop 0                                                    // 000000165864: BF800000
	s_nop 0                                                    // 000000165868: BF800000
	s_nop 0                                                    // 00000016586C: BF800000
	s_nop 0                                                    // 000000165870: BF800000
	s_nop 0                                                    // 000000165874: BF800000
	s_nop 0                                                    // 000000165878: BF800000
	s_nop 0                                                    // 00000016587C: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 000000165880: 8C7E187E
	v_mov_b32_e32 v133, v145                                   // 000000165884: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 000000165888: 7F220384
	s_and_b32 s1, exec_lo, s22                                 // 00000016588C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165890: BF870499
	s_or_b32 s15, s1, s15                                      // 000000165894: 8C0F0F01
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000165898: 917E0F7E
	s_cbranch_execz 20                                         // 00000016589C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11f0>
	global_load_b32 v132, v[130:131], off                      // 0000001658A0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 0000001658A8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 0000001658AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s9, v132                          // 0000001658B0: 7C890809
	s_and_saveexec_b32 s24, vcc_lo                             // 0000001658B4: BE98206A
	s_cbranch_execz 65521                                      // 0000001658B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_dual_mov_b32 v145, v151 :: v_dual_add_nc_u32 v132, 1, v145// 0000001658BC: CA200197 91852281
	.long 0xd7000182                                           // 0000001658C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000001658C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001658CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000001658D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v151, v132                        // 0000001658D8: 7C950997
	s_and_not1_b32 s1, s22, exec_lo                            // 0000001658DC: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000001658E0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001658E4: BF870009
	s_or_b32 s22, s1, s22                                      // 0000001658E8: 8C161601
	s_branch 65508                                             // 0000001658EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001658F0: 8C7E0F7E
	v_mov_b32_e32 v145, v133                                   // 0000001658F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001658F8: 8C7E0D7E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001658FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 000000165900: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 000000165908: BE81007E
	.long 0xd4c1007e                                           // 00000016590C: D4C1007E
	v_cndmask_b32_e32 v1, s9, v0, vcc_lo                       // 000000165910: 02020009
	s_cbranch_execz 62                                         // 000000165914: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1310>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 000000165918: CA100080 85820191
	s_mov_b32 s13, exec_lo                                     // 000000165920: BE8D007E
	.long 0xd4c1007e                                           // 000000165924: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 000000165928: 02032F91
	s_cbranch_execz 54                                         // 00000016592C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1308>
	v_mov_b32_e32 v130, v145                                   // 000000165930: 7F040391
	s_mov_b32 s22, 0                                           // 000000165934: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000165938: BF840001
	s_branch 10                                                // 00000016593C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000165940: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165944: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000165948: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000016594C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 000000165950: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 000000165954: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165958: BF870009
	s_or_b32 s15, s15, s26                                     // 00000016595C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000165960: 917E167E
	s_cbranch_execz 28                                         // 000000165964: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000165968: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000016596C: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 000000165970: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000165974: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000165978: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000016597C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165980: BF870091
	.long 0xd73c0084                                           // 000000165984: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000165988: 02030682
	.long 0xd7006a84                                           // 00000016598C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 000000165990: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165994: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 000000165998: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000001659A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000001659A8: BF8903F7
	.long 0xd4c4007e                                           // 0000001659AC: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000001659B0: 02030809
	s_cbranch_execz 65506                                      // 0000001659B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000001659B8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 0000001659BC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000001659C0: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000001659C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 0000001659C8: 7C950597
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000001659CC: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000001659D0: 8C191B19
	s_branch 65498                                             // 0000001659D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 0000001659D8: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000001659DC: 8C7E167E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v151        // 0000001659E0: CA100080 85820197
	s_and_saveexec_b32 s22, s15                                // 0000001659E8: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001659EC: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 0000001659F0: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 0000001659F4: 7C950809
	v_mov_b32_e32 v130, v131                                   // 0000001659F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000001659FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s15                             // 000000165A04: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165A08: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 000000165A0C: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165A10: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165A14: 8C7E017E
	s_or_b32 s13, s9, 1                                        // 000000165A18: 8C0D8109
	s_mov_b32 s1, exec_lo                                      // 000000165A1C: BE81007E
	.long 0xd4c6007e                                           // 000000165A20: D4C6007E
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 000000165A24: 0202000D
	s_xor_b32 s1, exec_lo, s1                                  // 000000165A28: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 000000165A2C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000165A34: BE813001
	s_cbranch_execz 70                                         // 000000165A38: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s15, exec_lo                                     // 000000165A3C: BE8F007E
	.long 0xd4c1007e                                           // 000000165A40: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 000000165A44: 02032F82
	s_cbranch_execz 64                                         // 000000165A48: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 000000165A4C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000165A50: BF840001
	s_branch 20                                                // 000000165A54: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 000000165A58: BF800000
	s_nop 0                                                    // 000000165A5C: BF800000
	s_nop 0                                                    // 000000165A60: BF800000
	s_nop 0                                                    // 000000165A64: BF800000
	s_nop 0                                                    // 000000165A68: BF800000
	s_nop 0                                                    // 000000165A6C: BF800000
	s_nop 0                                                    // 000000165A70: BF800000
	s_nop 0                                                    // 000000165A74: BF800000
	s_nop 0                                                    // 000000165A78: BF800000
	s_nop 0                                                    // 000000165A7C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000165A80: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165A84: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000165A88: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 000000165A8C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000165A90: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000165A94: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165A98: BF870009
	s_or_b32 s22, s22, s27                                     // 000000165A9C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000165AA0: 917E187E
	s_cbranch_execz 27                                         // 000000165AA4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v131, v130                                   // 000000165AA8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 000000165AAC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000165AB0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000165AB4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165AB8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000165ABC: 3509069F
	.long 0xd73c0086                                           // 000000165AC0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000165AC4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165AC8: BF870091
	.long 0xd7006a86                                           // 000000165ACC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000165AD0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000165AD4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 000000165ADC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000165AE4: BF8903F7
	.long 0xd4c6007e                                           // 000000165AE8: D4C6007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 000000165AEC: 02030809
	s_cbranch_execz 65507                                      // 000000165AF0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000165AF4: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 000000165AF8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 000000165AFC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000165B00: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 000000165B04: 7C950597
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000165B08: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 000000165B0C: 8C1A1C1A
	s_branch 65499                                             // 000000165B10: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 000000165B14: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000165B18: 8C7E187E
	v_mov_b32_e32 v130, v151                                   // 000000165B1C: 7F040397
	s_and_saveexec_b32 s24, s22                                // 000000165B20: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165B24: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000165B28: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 000000165B2C: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 000000165B30: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165B3C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000165B40: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000165B44: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 000000165B48: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165B4C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 000000165B50: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165B54: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165B58: 8C7E017E
	s_or_b32 s13, s9, 2                                        // 000000165B5C: 8C0D8209
	s_mov_b32 s1, exec_lo                                      // 000000165B60: BE81007E
	.long 0xd4c6007e                                           // 000000165B64: D4C6007E
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 000000165B68: 0202000D
	s_xor_b32 s1, exec_lo, s1                                  // 000000165B6C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000165B70: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000165B78: BE813001
	s_cbranch_execz 69                                         // 000000165B7C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1594>
	s_mov_b32 s15, exec_lo                                     // 000000165B80: BE8F007E
	.long 0xd4c1007e                                           // 000000165B84: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 000000165B88: 02032F82
	s_cbranch_execz 63                                         // 000000165B8C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	s_mov_b32 s24, 0                                           // 000000165B90: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000165B94: BF840001
	s_branch 19                                                // 000000165B98: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 000000165B9C: BF800000
	s_nop 0                                                    // 000000165BA0: BF800000
	s_nop 0                                                    // 000000165BA4: BF800000
	s_nop 0                                                    // 000000165BA8: BF800000
	s_nop 0                                                    // 000000165BAC: BF800000
	s_nop 0                                                    // 000000165BB0: BF800000
	s_nop 0                                                    // 000000165BB4: BF800000
	s_nop 0                                                    // 000000165BB8: BF800000
	s_nop 0                                                    // 000000165BBC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000165BC0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165BC4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000165BC8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 000000165BCC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000165BD0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000165BD4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165BD8: BF870009
	s_or_b32 s22, s22, s27                                     // 000000165BDC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000165BE0: 917E187E
	s_cbranch_execz 27                                         // 000000165BE4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1554>
	v_mov_b32_e32 v131, v130                                   // 000000165BE8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 000000165BEC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000165BF0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000165BF4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165BF8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000165BFC: 3509069F
	.long 0xd73c0086                                           // 000000165C00: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000165C04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165C08: BF870091
	.long 0xd7006a86                                           // 000000165C0C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000165C10: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000165C14: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 000000165C1C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000165C24: BF8903F7
	.long 0xd4c4007e                                           // 000000165C28: D4C4007E
	v_cndmask_b32_e32 v1, s13, v132, vcc_lo                    // 000000165C2C: 0203080D
	s_cbranch_execz 65507                                      // 000000165C30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000165C34: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 000000165C38: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 000000165C3C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000165C40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 000000165C44: 7C950597
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000165C48: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 000000165C4C: 8C1A1C1A
	s_branch 65499                                             // 000000165C50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 000000165C54: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000165C58: 8C7E187E
	v_mov_b32_e32 v130, v151                                   // 000000165C5C: 7F040397
	s_and_saveexec_b32 s24, s22                                // 000000165C60: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165C64: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000165C68: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 000000165C6C: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 000000165C70: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165C7C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000165C80: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000165C84: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 000000165C88: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165C8C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 000000165C90: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165C94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165C98: 8C7E017E
	s_or_b32 s9, s9, 3                                         // 000000165C9C: 8C098309
	s_mov_b32 s1, exec_lo                                      // 000000165CA0: BE81007E
	.long 0xd4c6007e                                           // 000000165CA4: D4C6007E
	v_cndmask_b32_e32 v1, s9, v0, vcc_lo                       // 000000165CA8: 02020009
	s_xor_b32 s1, exec_lo, s1                                  // 000000165CAC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 000000165CB0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000165CB8: BE813001
	s_cbranch_execz 66                                         // 000000165CBC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c8>
	s_mov_b32 s13, exec_lo                                     // 000000165CC0: BE8D007E
	.long 0xd4c1007e                                           // 000000165CC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 000000165CC8: 02032F82
	s_cbranch_execz 60                                         // 000000165CCC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	s_mov_b32 s22, 0                                           // 000000165CD0: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000165CD4: BF840001
	s_branch 19                                                // 000000165CD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1628>
	s_nop 0                                                    // 000000165CDC: BF800000
	s_nop 0                                                    // 000000165CE0: BF800000
	s_nop 0                                                    // 000000165CE4: BF800000
	s_nop 0                                                    // 000000165CE8: BF800000
	s_nop 0                                                    // 000000165CEC: BF800000
	s_nop 0                                                    // 000000165CF0: BF800000
	s_nop 0                                                    // 000000165CF4: BF800000
	s_nop 0                                                    // 000000165CF8: BF800000
	s_nop 0                                                    // 000000165CFC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 000000165D00: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000165D04: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000165D08: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 000000165D0C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 000000165D10: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 000000165D14: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165D18: BF870009
	s_or_b32 s15, s15, s26                                     // 000000165D1C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000165D20: 917E167E
	s_cbranch_execz 26                                         // 000000165D24: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1690>
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000165D28: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 000000165D2C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000165D30: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000165D34: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165D38: BF870091
	.long 0xd73c0083                                           // 000000165D3C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000165D40: 02030482
	.long 0xd7006a83                                           // 000000165D44: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 000000165D48: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165D4C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 000000165D50: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 000000165D58: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000165D60: BF8903F7
	.long 0xd4c4007e                                           // 000000165D64: D4C4007E
	v_cndmask_b32_e32 v1, s9, v131, vcc_lo                     // 000000165D68: 02030609
	s_cbranch_execz 65508                                      // 000000165D6C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1600>
	v_add_nc_u32_e32 v130, 1, v130                             // 000000165D70: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 000000165D74: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000165D78: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000165D7C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 000000165D80: 7C950597
	s_and_b32 s27, vcc_lo, exec_lo                             // 000000165D84: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000165D88: 8C191B19
	s_branch 65500                                             // 000000165D8C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1600>
	s_set_inst_prefetch_distance 0x2                           // 000000165D90: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 000000165D94: 8C7E167E
	s_and_saveexec_b32 s22, s15                                // 000000165D98: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165D9C: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 000000165DA0: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v131                          // 000000165DA4: 7C950609
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 000000165DA8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165DB4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000165DB8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s15                             // 000000165DBC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165DC0: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 000000165DC4: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165DC8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165DCC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165DD0: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 000000165DD4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000165DD8: BE882003
	s_cbranch_execz 64580                                      // 000000165DDC: BFA5FC44 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f0>
	ds_load_b32 v131, v154                                     // 000000165DE0: D8D80000 8300009A
	v_and_b32_e32 v130, 1, v133                                // 000000165DE8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s7, v153                          // 000000165DEC: 7C873207
	s_delay_alu instid0(VALU_DEP_2)                            // 000000165DF0: BF870002
	.long 0xd44a0001                                           // 000000165DF4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000165DF8: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 000000165DFC: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 000000165E00: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 000000165E04: 7F040383
	s_and_saveexec_b32 s1, s35                                 // 000000165E08: BE812023
	s_cbranch_execz 7                                          // 000000165E0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x172c>
	ds_load_b32 v130, v155                                     // 000000165E10: D8D80000 8200009B
	v_max_f32_e32 v132, v131, v131                             // 000000165E18: 21090783
	s_waitcnt lgkmcnt(0)                                       // 000000165E1C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 000000165E20: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165E24: BF870001
	v_max_f32_e32 v130, v132, v130                             // 000000165E28: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165E2C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 000000165E30: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s7, v153                          // 000000165E34: 7C833207
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000165E38: BF8704A2
	.long 0xd44d0001                                           // 000000165E3C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165E40: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 000000165E44: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 000000165E48: BE812022
	s_cbranch_execz 7                                          // 000000165E4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v132, v155 offset:4                            // 000000165E50: D8D80004 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165E58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165E5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165E60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165E64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165E68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165E6C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 000000165E70: 37090A84
	s_or_b32 s1, s7, 2                                         // 000000165E74: 8C018207
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165E78: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165E7C: 7C873201
	.long 0xd44d0001                                           // 000000165E80: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165E84: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 000000165E88: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165E8C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000165E90: BE812021
	s_cbranch_execz 7                                          // 000000165E94: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17b4>
	ds_load_b32 v132, v155 offset:8                            // 000000165E98: D8D80008 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165EA0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165EA4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165EA8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165EAC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165EB0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165EB4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 000000165EB8: 37090A88
	s_or_b32 s1, s7, 3                                         // 000000165EBC: 8C018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165EC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165EC4: 7C873201
	.long 0xd44d0001                                           // 000000165EC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165ECC: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 000000165ED0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165ED4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000165ED8: BE81201F
	s_cbranch_execz 7                                          // 000000165EDC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17fc>
	ds_load_b32 v132, v155 offset:12                           // 000000165EE0: D8D8000C 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165EE8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165EEC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165EF0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165EF4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165EF8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165EFC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 000000165F00: 37090A90
	s_or_b32 s1, s7, 4                                         // 000000165F04: 8C018407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165F08: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165F0C: 7C873201
	.long 0xd44d0001                                           // 000000165F10: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165F14: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 000000165F18: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165F1C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000165F20: BE81201E
	s_cbranch_execz 7                                          // 000000165F24: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1844>
	ds_load_b32 v132, v155 offset:16                           // 000000165F28: D8D80010 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165F30: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165F34: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165F38: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165F3C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165F40: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165F44: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 000000165F48: 37090AA0
	s_or_b32 s1, s7, 5                                         // 000000165F4C: 8C018507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165F50: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165F54: 7C873201
	.long 0xd44d0001                                           // 000000165F58: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165F5C: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 000000165F60: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165F64: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000165F68: BE81201D
	s_cbranch_execz 7                                          // 000000165F6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x188c>
	ds_load_b32 v132, v155 offset:20                           // 000000165F70: D8D80014 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165F78: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165F7C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165F80: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165F84: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165F88: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165F8C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 000000165F90: 37090AC0
	s_or_b32 s1, s7, 6                                         // 000000165F94: 8C018607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165F98: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165F9C: 7C873201
	.long 0xd44d0001                                           // 000000165FA0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165FA4: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 000000165FA8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165FAC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 000000165FB0: BE81201C
	s_cbranch_execz 7                                          // 000000165FB4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d4>
	ds_load_b32 v132, v155 offset:24                           // 000000165FB8: D8D80018 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000165FC0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000165FC4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000165FC8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165FCC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000165FD0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165FD4: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 000000165FD8: 37090AFF 00000080
	s_or_b32 s1, s7, 7                                         // 000000165FE0: 8C018707
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000165FE4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000165FE8: 7C873201
	.long 0xd44d0001                                           // 000000165FEC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000165FF0: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 000000165FF4: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000165FF8: BF870009
	s_and_saveexec_b32 s1, s27                                 // 000000165FFC: BE81201B
	s_cbranch_execz 7                                          // 000000166000: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1920>
	ds_load_b32 v132, v155 offset:28                           // 000000166004: D8D8001C 8400009B
	v_max_f32_e32 v130, v130, v130                             // 00000016600C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000166010: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166014: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166018: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000016601C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166020: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 000000166024: 37090AFF 00000100
	s_or_b32 s1, s7, 8                                         // 00000016602C: 8C018807
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166030: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000166034: 7C873201
	.long 0xd44d0001                                           // 000000166038: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000016603C: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 000000166040: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166044: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000166048: BE81201A
	s_cbranch_execz 7                                          // 00000016604C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x196c>
	ds_load_b32 v132, v155 offset:32                           // 000000166050: D8D80020 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000166058: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000016605C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166060: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166064: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000166068: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016606C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 000000166070: 37090AFF 00000200
	s_or_b32 s1, s7, 9                                         // 000000166078: 8C018907
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016607C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000166080: 7C873201
	.long 0xd44d0001                                           // 000000166084: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000166088: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000016608C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166090: BF870009
	s_and_saveexec_b32 s1, s25                                 // 000000166094: BE812019
	s_cbranch_execz 7                                          // 000000166098: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19b8>
	ds_load_b32 v132, v155 offset:36                           // 00000016609C: D8D80024 8400009B
	v_max_f32_e32 v130, v130, v130                             // 0000001660A4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000001660A8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000001660AC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001660B0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000001660B4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001660B8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000001660BC: 37090AFF 00000400
	s_or_b32 s1, s7, 10                                        // 0000001660C4: 8C018A07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001660C8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 0000001660CC: 7C873201
	.long 0xd44d0001                                           // 0000001660D0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000001660D4: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 0000001660D8: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001660DC: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000001660E0: BE812018
	s_cbranch_execz 7                                          // 0000001660E4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a04>
	ds_load_b32 v132, v155 offset:40                           // 0000001660E8: D8D80028 8400009B
	v_max_f32_e32 v130, v130, v130                             // 0000001660F0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000001660F4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000001660F8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001660FC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000166100: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166104: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 000000166108: 37090AFF 00000800
	s_or_b32 s1, s7, 11                                        // 000000166110: 8C018B07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166114: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000166118: 7C873201
	.long 0xd44d0001                                           // 00000016611C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000166120: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 000000166124: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166128: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000016612C: BE812016
	s_cbranch_execz 7                                          // 000000166130: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a50>
	ds_load_b32 v132, v155 offset:44                           // 000000166134: D8D8002C 8400009B
	v_max_f32_e32 v130, v130, v130                             // 00000016613C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000166140: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166144: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166148: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000016614C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166150: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 000000166154: 37090AFF 00001000
	s_or_b32 s1, s7, 12                                        // 00000016615C: 8C018C07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166160: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 000000166164: 7C873201
	.long 0xd44d0001                                           // 000000166168: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000016616C: 02030880
	s_and_b32 s15, vcc_lo, s1                                  // 000000166170: 8B0F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166174: BF870009
	s_and_saveexec_b32 s1, s15                                 // 000000166178: BE81200F
	s_cbranch_execz 7                                          // 00000016617C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a9c>
	ds_load_b32 v132, v155 offset:48                           // 000000166180: D8D80030 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000166188: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000016618C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166190: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166194: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000166198: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016619C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000001661A0: 37090AFF 00002000
	s_or_b32 s1, s7, 13                                        // 0000001661A8: 8C018D07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001661AC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 0000001661B0: 7C873201
	.long 0xd44d0001                                           // 0000001661B4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000001661B8: 02030880
	s_and_b32 s13, vcc_lo, s1                                  // 0000001661BC: 8B0D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001661C0: BF870009
	s_and_saveexec_b32 s1, s13                                 // 0000001661C4: BE81200D
	s_cbranch_execz 7                                          // 0000001661C8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ae8>
	ds_load_b32 v132, v155 offset:52                           // 0000001661CC: D8D80034 8400009B
	v_max_f32_e32 v130, v130, v130                             // 0000001661D4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000001661D8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000001661DC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001661E0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000001661E4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001661E8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000001661EC: 37090AFF 00004000
	s_or_b32 s1, s7, 14                                        // 0000001661F4: 8C018E07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001661F8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v153                          // 0000001661FC: 7C873201
	.long 0xd44d0001                                           // 000000166200: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000166204: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 000000166208: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016620C: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000166210: BE812009
	s_cbranch_execz 7                                          // 000000166214: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b34>
	ds_load_b32 v132, v155 offset:56                           // 000000166218: D8D80038 8400009B
	v_max_f32_e32 v130, v130, v130                             // 000000166220: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000166224: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166228: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016622C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000166230: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166234: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 000000166238: 37090AFF 00008000
	s_or_b32 s7, s7, 15                                        // 000000166240: 8C078F07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166244: BF870119
	v_cmp_le_i32_e32 vcc_lo, s7, v153                          // 000000166248: 7C873207
	.long 0xd44d0001                                           // 00000016624C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000166250: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 000000166254: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166258: BF870009
	s_and_saveexec_b32 s7, s1                                  // 00000016625C: BE872001
	s_cbranch_execz 7                                          // 000000166260: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b80>
	ds_load_b32 v132, v155 offset:60                           // 000000166264: D8D8003C 8400009B
	v_max_f32_e32 v130, v130, v130                             // 00000016626C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000166270: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000166274: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166278: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000016627C: 21050982
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166280: 8C7E077E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 000000166284: CA100080 84840080
	s_and_saveexec_b32 s7, s35                                 // 00000016628C: BE872023
	s_cbranch_execz 30                                         // 000000166290: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c0c>
	ds_load_b32 v133, v155                                     // 000000166294: D8D80000 8500009B
	s_waitcnt lgkmcnt(0)                                       // 00000016629C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000001662A0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001662A4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000001662A8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000001662B0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000001662BC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001662C0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000001662C4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000001662C8: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 0000001662D0: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001662D8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000001662DC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000001662E0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000001662E4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001662E8: BF870095
	.long 0xd71c0086                                           // 0000001662EC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000001662F0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000001662F4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000001662F8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166300: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 000000166304: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000016630C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166310: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 000000166314: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000016631C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v156, v134                             // 000000166328: DA840000 0000869C
	s_and_saveexec_b32 s7, s34                                 // 000000166330: BE872022
	s_cbranch_execz 30                                         // 000000166334: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cb0>
	ds_load_b32 v132, v155 offset:4                            // 000000166338: D8D80004 8400009B
	s_waitcnt lgkmcnt(0)                                       // 000000166340: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 000000166344: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166348: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000016634C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 000000166354: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000016635C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 000000166368: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016636C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 000000166370: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 000000166378: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016637C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 000000166380: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 000000166384: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 000000166388: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016638C: BF870095
	.long 0xd71c0086                                           // 000000166390: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 000000166394: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 000000166398: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 00000016639C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001663A4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000001663A8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001663B0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001663B4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000001663B8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000001663C0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000001663C4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000001663D0: 7F0C0280
	ds_store_b16_d16_hi v156, v136 offset:2                    // 0000001663D4: DA840002 0000889C
	s_and_saveexec_b32 s7, s33                                 // 0000001663DC: BE872021
	s_cbranch_execz 29                                         // 0000001663E0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d58>
	ds_load_b32 v135, v155 offset:8                            // 0000001663E4: D8D80008 8700009B
	s_waitcnt lgkmcnt(0)                                       // 0000001663EC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 0000001663F0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001663F4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000001663F8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 000000166400: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000016640C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166410: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 000000166414: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 000000166420: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000166424: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000166428: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166430: BF870293
	v_exp_f32_e32 v136, v136                                   // 000000166434: 7F104B88
	.long 0xd71c0088                                           // 000000166438: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000016643C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166440: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 000000166444: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000166448: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 000000166450: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166458: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016645C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 000000166460: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 000000166468: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v156, v136 offset:4                    // 000000166474: DA840004 0000889C
	s_and_saveexec_b32 s7, s31                                 // 00000016647C: BE87201F
	s_cbranch_execz 30                                         // 000000166480: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dfc>
	ds_load_b32 v134, v155 offset:12                           // 000000166484: D8D8000C 8600009B
	s_waitcnt lgkmcnt(0)                                       // 00000016648C: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 000000166490: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166494: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 000000166498: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000001664A0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000001664A8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000001664B4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001664B8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000001664BC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 0000001664C4: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001664C8: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000001664CC: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000001664D0: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000001664D4: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001664D8: BF870095
	.long 0xd71c0088                                           // 0000001664DC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000001664E0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000001664E4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000001664E8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001664F0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000001664F4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001664FC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166500: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 000000166504: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000016650C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 000000166510: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000016651C: 7F100280
	ds_store_b16_d16_hi v156, v146 offset:6                    // 000000166520: DA840006 0000929C
	s_and_saveexec_b32 s7, s30                                 // 000000166528: BE87201E
	s_cbranch_execz 29                                         // 00000016652C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ea4>
	ds_load_b32 v137, v155 offset:16                           // 000000166530: D8D80010 8900009B
	s_waitcnt lgkmcnt(0)                                       // 000000166538: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 00000016653C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166540: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 000000166544: 112512FF 3FB8AA3B
	v_fma_f32 v169, 0x3fb8aa3b, v137, -v146                    // 00000016654C: D61300A9 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v170, v146                                 // 000000166558: 7F544792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016655C: BF870091
	v_dual_fmac_f32 v169, 0x32a5705f, v137 :: v_dual_sub_f32 v146, v146, v170// 000000166560: C80B12FF A9935592 32A5705F
	v_add_f32_e32 v146, v146, v169                             // 00000016656C: 07255392
	v_cvt_i32_f32_e32 v169, v170                               // 000000166570: 7F5211AA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 000000166574: 7C3712FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016657C: BF870293
	v_exp_f32_e32 v146, v146                                   // 000000166580: 7F244B92
	.long 0xd71c0092                                           // 000000166584: D71C0092
	v_cndmask_b32_e32 v1, v146, v169, vcc_lo                   // 000000166588: 02035392
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016658C: BF870121
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000166590: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 000000166594: 7C3D12FF 42B17218
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000016659C: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001665A4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001665A8: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000001665AC: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000001665B4: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v156, v146 offset:8                    // 0000001665C0: DA840008 0000929C
	s_and_saveexec_b32 s7, s29                                 // 0000001665C8: BE87201D
	s_cbranch_execz 29                                         // 0000001665CC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f44>
	ds_load_b32 v136, v155 offset:20                           // 0000001665D0: D8D80014 8800009B
	s_waitcnt lgkmcnt(0)                                       // 0000001665D8: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000001665DC: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001665E0: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 0000001665E4: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000001665EC: 7C3710FF C2CE8ED0
	v_fma_f32 v169, 0x3fb8aa3b, v136, -v146                    // 0000001665F4: D61300A9 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v170, v146                                 // 000000166600: 7F544792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166604: BF870091
	v_dual_fmac_f32 v169, 0x32a5705f, v136 :: v_dual_sub_f32 v146, v146, v170// 000000166608: C80B10FF A9935592 32A5705F
	v_add_f32_e32 v146, v146, v169                             // 000000166614: 07255392
	v_cvt_i32_f32_e32 v169, v170                               // 000000166618: 7F5211AA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016661C: BF870292
	v_exp_f32_e32 v146, v146                                   // 000000166620: 7F244B92
	.long 0xd71c0092                                           // 000000166624: D71C0092
	v_cndmask_b32_e32 v1, v146, v169, vcc_lo                   // 000000166628: 02035392
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016662C: BF870121
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000166630: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000166634: 7C3D10FF 42B17218
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 00000016663C: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166644: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166648: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000016664C: D6100092 02052188
	v_mov_b32_e32 v169, 0                                      // 000000166654: 7F520280
	v_add3_u32 v170, v136, v146, 0x7fff                        // 000000166658: D65500AA 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 000000166664: 7F240280
	ds_store_b16_d16_hi v156, v170 offset:10                   // 000000166668: DA84000A 0000AA9C
	s_and_saveexec_b32 s7, s28                                 // 000000166670: BE87201C
	s_cbranch_execz 30                                         // 000000166674: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ff0>
	ds_load_b32 v169, v155 offset:24                           // 000000166678: D8D80018 A900009B
	s_waitcnt lgkmcnt(0)                                       // 000000166680: BF89FC07
	v_sub_f32_e32 v169, v169, v130                             // 000000166684: 095305A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166688: BF870091
	v_mul_f32_e32 v170, 0x3fb8aa3b, v169                       // 00000016668C: 115552FF 3FB8AA3B
	v_fma_f32 v171, 0x3fb8aa3b, v169, -v170                    // 000000166694: D61300AB 86AB52FF 3FB8AA3B
	v_rndne_f32_e32 v172, v170                                 // 0000001666A0: 7F5847AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001666A4: BF870221
	v_sub_f32_e32 v170, v170, v172                             // 0000001666A8: 095559AA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v169                 // 0000001666AC: 7C3752FF C2CE8ED0
	v_fmac_f32_e32 v171, 0x32a5705f, v169                      // 0000001666B4: 575752FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001666BC: BF870121
	v_add_f32_e32 v170, v170, v171                             // 0000001666C0: 075557AA
	v_cvt_i32_f32_e32 v171, v172                               // 0000001666C4: 7F5611AC
	v_exp_f32_e32 v170, v170                                   // 0000001666C8: 7F544BAA
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001666CC: BF870095
	.long 0xd71c00aa                                           // 0000001666D0: D71C00AA
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                   // 0000001666D4: 020357AA
	v_cndmask_b32_e32 v170, 0, v170, vcc_lo                    // 0000001666D8: 03555480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v169                 // 0000001666DC: 7C3D52FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001666E4: BF870002
	v_cndmask_b32_e32 v169, 0x7f800000, v170, vcc_lo           // 0000001666E8: 035354FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001666F0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001666F4: BF870091
	v_bfe_u32 v170, v169, 16, 1                                // 0000001666F8: D61000AA 020521A9
	v_add3_u32 v170, v169, v170, 0x7fff                        // 000000166700: D65500AA 03FF55A9 00007FFF
	ds_store_b16_d16_hi v156, v170 offset:12                   // 00000016670C: DA84000C 0000AA9C
	s_and_saveexec_b32 s7, s27                                 // 000000166714: BE87201B
	s_cbranch_execz 29                                         // 000000166718: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2090>
	ds_load_b32 v146, v155 offset:28                           // 00000016671C: D8D8001C 9200009B
	s_waitcnt lgkmcnt(0)                                       // 000000166724: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 000000166728: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016672C: BF870121
	v_mul_f32_e32 v170, 0x3fb8aa3b, v146                       // 000000166730: 115524FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 000000166738: 7C3724FF C2CE8ED0
	v_fma_f32 v171, 0x3fb8aa3b, v146, -v170                    // 000000166740: D61300AB 86AB24FF 3FB8AA3B
	v_rndne_f32_e32 v172, v170                                 // 00000016674C: 7F5847AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166750: BF870091
	v_dual_fmac_f32 v171, 0x32a5705f, v146 :: v_dual_sub_f32 v170, v170, v172// 000000166754: C80B24FF ABAB59AA 32A5705F
	v_add_f32_e32 v170, v170, v171                             // 000000166760: 075557AA
	v_cvt_i32_f32_e32 v171, v172                               // 000000166764: 7F5611AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166768: BF870292
	v_exp_f32_e32 v170, v170                                   // 00000016676C: 7F544BAA
	.long 0xd71c00aa                                           // 000000166770: D71C00AA
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                   // 000000166774: 020357AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166778: BF870121
	v_cndmask_b32_e32 v170, 0, v170, vcc_lo                    // 00000016677C: 03555480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 000000166780: 7C3D24FF 42B17218
	v_cndmask_b32_e32 v146, 0x7f800000, v170, vcc_lo           // 000000166788: 032554FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166790: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166794: BF870121
	v_bfe_u32 v170, v146, 16, 1                                // 000000166798: D61000AA 02052192
	v_mov_b32_e32 v171, 0                                      // 0000001667A0: 7F560280
	v_add3_u32 v172, v146, v170, 0x7fff                        // 0000001667A4: D65500AC 03FF5592 00007FFF
	v_mov_b32_e32 v170, 0                                      // 0000001667B0: 7F540280
	ds_store_b16_d16_hi v156, v172 offset:14                   // 0000001667B4: DA84000E 0000AC9C
	s_and_saveexec_b32 s7, s26                                 // 0000001667BC: BE87201A
	s_cbranch_execz 29                                         // 0000001667C0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2138>
	ds_load_b32 v171, v155 offset:32                           // 0000001667C4: D8D80020 AB00009B
	s_waitcnt lgkmcnt(0)                                       // 0000001667CC: BF89FC07
	v_sub_f32_e32 v171, v171, v130                             // 0000001667D0: 095705AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001667D4: BF870091
	v_mul_f32_e32 v172, 0x3fb8aa3b, v171                       // 0000001667D8: 115956FF 3FB8AA3B
	v_fma_f32 v173, 0x3fb8aa3b, v171, -v172                    // 0000001667E0: D61300AD 86B356FF 3FB8AA3B
	v_rndne_f32_e32 v174, v172                                 // 0000001667EC: 7F5C47AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001667F0: BF870091
	v_dual_fmac_f32 v173, 0x32a5705f, v171 :: v_dual_sub_f32 v172, v172, v174// 0000001667F4: C80B56FF ADAD5DAC 32A5705F
	v_add_f32_e32 v172, v172, v173                             // 000000166800: 07595BAC
	v_cvt_i32_f32_e32 v173, v174                               // 000000166804: 7F5A11AE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v171                 // 000000166808: 7C3756FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166810: BF870293
	v_exp_f32_e32 v172, v172                                   // 000000166814: 7F584BAC
	.long 0xd71c00ac                                           // 000000166818: D71C00AC
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                   // 00000016681C: 02035BAC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166820: BF870121
	v_cndmask_b32_e32 v172, 0, v172, vcc_lo                    // 000000166824: 03595880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v171                 // 000000166828: 7C3D56FF 42B17218
	v_cndmask_b32_e32 v171, 0x7f800000, v172, vcc_lo           // 000000166830: 035758FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166838: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016683C: BF870091
	v_bfe_u32 v172, v171, 16, 1                                // 000000166840: D61000AC 020521AB
	v_add3_u32 v172, v171, v172, 0x7fff                        // 000000166848: D65500AC 03FF59AB 00007FFF
	ds_store_b16_d16_hi v156, v172 offset:16                   // 000000166854: DA840010 0000AC9C
	s_and_saveexec_b32 s7, s25                                 // 00000016685C: BE872019
	s_cbranch_execz 30                                         // 000000166860: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21dc>
	ds_load_b32 v170, v155 offset:36                           // 000000166864: D8D80024 AA00009B
	s_waitcnt lgkmcnt(0)                                       // 00000016686C: BF89FC07
	v_sub_f32_e32 v170, v170, v130                             // 000000166870: 095505AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166874: BF870121
	v_mul_f32_e32 v172, 0x3fb8aa3b, v170                       // 000000166878: 115954FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v170                 // 000000166880: 7C3754FF C2CE8ED0
	v_fma_f32 v173, 0x3fb8aa3b, v170, -v172                    // 000000166888: D61300AD 86B354FF 3FB8AA3B
	v_rndne_f32_e32 v174, v172                                 // 000000166894: 7F5C47AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166898: BF870112
	v_fmac_f32_e32 v173, 0x32a5705f, v170                      // 00000016689C: 575B54FF 32A5705F
	v_sub_f32_e32 v172, v172, v174                             // 0000001668A4: 09595DAC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001668A8: BF870121
	v_add_f32_e32 v172, v172, v173                             // 0000001668AC: 07595BAC
	v_cvt_i32_f32_e32 v173, v174                               // 0000001668B0: 7F5A11AE
	v_exp_f32_e32 v172, v172                                   // 0000001668B4: 7F584BAC
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001668B8: BF870095
	.long 0xd71c00ac                                           // 0000001668BC: D71C00AC
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                   // 0000001668C0: 02035BAC
	v_cndmask_b32_e32 v172, 0, v172, vcc_lo                    // 0000001668C4: 03595880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v170                 // 0000001668C8: 7C3D54FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001668D0: BF870002
	v_cndmask_b32_e32 v170, 0x7f800000, v172, vcc_lo           // 0000001668D4: 035558FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001668DC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001668E0: BF870121
	v_bfe_u32 v172, v170, 16, 1                                // 0000001668E4: D61000AC 020521AA
	v_mov_b32_e32 v173, 0                                      // 0000001668EC: 7F5A0280
	v_add3_u32 v174, v170, v172, 0x7fff                        // 0000001668F0: D65500AE 03FF59AA 00007FFF
	v_mov_b32_e32 v172, 0                                      // 0000001668FC: 7F580280
	ds_store_b16_d16_hi v156, v174 offset:18                   // 000000166900: DA840012 0000AE9C
	s_and_saveexec_b32 s7, s24                                 // 000000166908: BE872018
	s_cbranch_execz 30                                         // 00000016690C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2288>
	ds_load_b32 v173, v155 offset:40                           // 000000166910: D8D80028 AD00009B
	s_waitcnt lgkmcnt(0)                                       // 000000166918: BF89FC07
	v_sub_f32_e32 v173, v173, v130                             // 00000016691C: 095B05AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166920: BF870091
	v_mul_f32_e32 v174, 0x3fb8aa3b, v173                       // 000000166924: 115D5AFF 3FB8AA3B
	v_fma_f32 v175, 0x3fb8aa3b, v173, -v174                    // 00000016692C: D61300AF 86BB5AFF 3FB8AA3B
	v_rndne_f32_e32 v176, v174                                 // 000000166938: 7F6047AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016693C: BF870221
	v_sub_f32_e32 v174, v174, v176                             // 000000166940: 095D61AE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v173                 // 000000166944: 7C375AFF C2CE8ED0
	v_fmac_f32_e32 v175, 0x32a5705f, v173                      // 00000016694C: 575F5AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166954: BF870121
	v_add_f32_e32 v174, v174, v175                             // 000000166958: 075D5FAE
	v_cvt_i32_f32_e32 v175, v176                               // 00000016695C: 7F5E11B0
	v_exp_f32_e32 v174, v174                                   // 000000166960: 7F5C4BAE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166964: BF870095
	.long 0xd71c00ae                                           // 000000166968: D71C00AE
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                   // 00000016696C: 02035FAE
	v_cndmask_b32_e32 v174, 0, v174, vcc_lo                    // 000000166970: 035D5C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v173                 // 000000166974: 7C3D5AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000016697C: BF870002
	v_cndmask_b32_e32 v173, 0x7f800000, v174, vcc_lo           // 000000166980: 035B5CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166988: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016698C: BF870091
	v_bfe_u32 v174, v173, 16, 1                                // 000000166990: D61000AE 020521AD
	v_add3_u32 v174, v173, v174, 0x7fff                        // 000000166998: D65500AE 03FF5DAD 00007FFF
	ds_store_b16_d16_hi v156, v174 offset:20                   // 0000001669A4: DA840014 0000AE9C
	s_and_saveexec_b32 s7, s22                                 // 0000001669AC: BE872016
	s_cbranch_execz 30                                         // 0000001669B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x232c>
	ds_load_b32 v172, v155 offset:44                           // 0000001669B4: D8D8002C AC00009B
	s_waitcnt lgkmcnt(0)                                       // 0000001669BC: BF89FC07
	v_sub_f32_e32 v172, v172, v130                             // 0000001669C0: 095905AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001669C4: BF870121
	v_mul_f32_e32 v174, 0x3fb8aa3b, v172                       // 0000001669C8: 115D58FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v172                 // 0000001669D0: 7C3758FF C2CE8ED0
	v_fma_f32 v175, 0x3fb8aa3b, v172, -v174                    // 0000001669D8: D61300AF 86BB58FF 3FB8AA3B
	v_rndne_f32_e32 v176, v174                                 // 0000001669E4: 7F6047AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001669E8: BF870112
	v_fmac_f32_e32 v175, 0x32a5705f, v172                      // 0000001669EC: 575F58FF 32A5705F
	v_sub_f32_e32 v174, v174, v176                             // 0000001669F4: 095D61AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001669F8: BF870121
	v_add_f32_e32 v174, v174, v175                             // 0000001669FC: 075D5FAE
	v_cvt_i32_f32_e32 v175, v176                               // 000000166A00: 7F5E11B0
	v_exp_f32_e32 v174, v174                                   // 000000166A04: 7F5C4BAE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166A08: BF870095
	.long 0xd71c00ae                                           // 000000166A0C: D71C00AE
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                   // 000000166A10: 02035FAE
	v_cndmask_b32_e32 v174, 0, v174, vcc_lo                    // 000000166A14: 035D5C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v172                 // 000000166A18: 7C3D58FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166A20: BF870002
	v_cndmask_b32_e32 v172, 0x7f800000, v174, vcc_lo           // 000000166A24: 03595CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166A2C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166A30: BF870121
	v_bfe_u32 v174, v172, 16, 1                                // 000000166A34: D61000AE 020521AC
	v_mov_b32_e32 v175, 0                                      // 000000166A3C: 7F5E0280
	v_add3_u32 v176, v172, v174, 0x7fff                        // 000000166A40: D65500B0 03FF5DAC 00007FFF
	v_mov_b32_e32 v174, 0                                      // 000000166A4C: 7F5C0280
	ds_store_b16_d16_hi v156, v176 offset:22                   // 000000166A50: DA840016 0000B09C
	s_and_saveexec_b32 s7, s15                                 // 000000166A58: BE87200F
	s_cbranch_execz 29                                         // 000000166A5C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23d4>
	ds_load_b32 v175, v155 offset:48                           // 000000166A60: D8D80030 AF00009B
	s_waitcnt lgkmcnt(0)                                       // 000000166A68: BF89FC07
	v_sub_f32_e32 v175, v175, v130                             // 000000166A6C: 095F05AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166A70: BF870091
	v_mul_f32_e32 v176, 0x3fb8aa3b, v175                       // 000000166A74: 11615EFF 3FB8AA3B
	v_fma_f32 v177, 0x3fb8aa3b, v175, -v176                    // 000000166A7C: D61300B1 86C35EFF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 000000166A88: 7F6447B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166A8C: BF870091
	v_dual_fmac_f32 v177, 0x32a5705f, v175 :: v_dual_sub_f32 v176, v176, v178// 000000166A90: C80B5EFF B1B165B0 32A5705F
	v_add_f32_e32 v176, v176, v177                             // 000000166A9C: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 000000166AA0: 7F6211B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v175                 // 000000166AA4: 7C375EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166AAC: BF870293
	v_exp_f32_e32 v176, v176                                   // 000000166AB0: 7F604BB0
	.long 0xd71c00b0                                           // 000000166AB4: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 000000166AB8: 020363B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166ABC: BF870121
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 000000166AC0: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v175                 // 000000166AC4: 7C3D5EFF 42B17218
	v_cndmask_b32_e32 v175, 0x7f800000, v176, vcc_lo           // 000000166ACC: 035F60FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166AD4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166AD8: BF870091
	v_bfe_u32 v176, v175, 16, 1                                // 000000166ADC: D61000B0 020521AF
	v_add3_u32 v176, v175, v176, 0x7fff                        // 000000166AE4: D65500B0 03FF61AF 00007FFF
	ds_store_b16_d16_hi v156, v176 offset:24                   // 000000166AF0: DA840018 0000B09C
	s_and_saveexec_b32 s7, s13                                 // 000000166AF8: BE87200D
	s_cbranch_execz 30                                         // 000000166AFC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2478>
	ds_load_b32 v174, v155 offset:52                           // 000000166B00: D8D80034 AE00009B
	s_waitcnt lgkmcnt(0)                                       // 000000166B08: BF89FC07
	v_sub_f32_e32 v174, v174, v130                             // 000000166B0C: 095D05AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166B10: BF870121
	v_mul_f32_e32 v176, 0x3fb8aa3b, v174                       // 000000166B14: 11615CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v174                 // 000000166B1C: 7C375CFF C2CE8ED0
	v_fma_f32 v177, 0x3fb8aa3b, v174, -v176                    // 000000166B24: D61300B1 86C35CFF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 000000166B30: 7F6447B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166B34: BF870112
	v_fmac_f32_e32 v177, 0x32a5705f, v174                      // 000000166B38: 57635CFF 32A5705F
	v_sub_f32_e32 v176, v176, v178                             // 000000166B40: 096165B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166B44: BF870121
	v_add_f32_e32 v176, v176, v177                             // 000000166B48: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 000000166B4C: 7F6211B2
	v_exp_f32_e32 v176, v176                                   // 000000166B50: 7F604BB0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166B54: BF870095
	.long 0xd71c00b0                                           // 000000166B58: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 000000166B5C: 020363B0
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 000000166B60: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v174                 // 000000166B64: 7C3D5CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166B6C: BF870002
	v_cndmask_b32_e32 v174, 0x7f800000, v176, vcc_lo           // 000000166B70: 035D60FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166B78: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166B7C: BF870121
	v_bfe_u32 v176, v174, 16, 1                                // 000000166B80: D61000B0 020521AE
	v_mov_b32_e32 v177, 0                                      // 000000166B88: 7F620280
	v_add3_u32 v178, v174, v176, 0x7fff                        // 000000166B8C: D65500B2 03FF61AE 00007FFF
	v_mov_b32_e32 v176, 0                                      // 000000166B98: 7F600280
	ds_store_b16_d16_hi v156, v178 offset:26                   // 000000166B9C: DA84001A 0000B29C
	s_and_saveexec_b32 s7, s9                                  // 000000166BA4: BE872009
	s_cbranch_execz 30                                         // 000000166BA8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2524>
	ds_load_b32 v177, v155 offset:56                           // 000000166BAC: D8D80038 B100009B
	s_waitcnt lgkmcnt(0)                                       // 000000166BB4: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 000000166BB8: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166BBC: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v177                       // 000000166BC0: 116562FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v177, -v178                    // 000000166BC8: D61300B3 86CB62FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000166BD4: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000166BD8: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 000000166BDC: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 000000166BE0: 7C3762FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v177                      // 000000166BE8: 576762FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166BF0: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000166BF4: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000166BF8: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000166BFC: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166C00: BF870095
	.long 0xd71c00b2                                           // 000000166C04: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000166C08: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000166C0C: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 000000166C10: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166C18: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v178, vcc_lo           // 000000166C1C: 036364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166C24: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166C28: BF870091
	v_bfe_u32 v178, v177, 16, 1                                // 000000166C2C: D61000B2 020521B1
	v_add3_u32 v178, v177, v178, 0x7fff                        // 000000166C34: D65500B2 03FF65B1 00007FFF
	ds_store_b16_d16_hi v156, v178 offset:28                   // 000000166C40: DA84001C 0000B29C
	s_and_saveexec_b32 s7, s1                                  // 000000166C48: BE872001
	s_cbranch_execz 30                                         // 000000166C4C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x25c8>
	ds_load_b32 v176, v155 offset:60                           // 000000166C50: D8D8003C B000009B
	s_waitcnt lgkmcnt(0)                                       // 000000166C58: BF89FC07
	v_sub_f32_e32 v176, v176, v130                             // 000000166C5C: 096105B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166C60: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v176                       // 000000166C64: 116560FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v176                 // 000000166C6C: 7C3760FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v176, -v178                    // 000000166C74: D61300B3 86CB60FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000166C80: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166C84: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v176                      // 000000166C88: 576760FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 000000166C90: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166C94: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000166C98: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000166C9C: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000166CA0: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166CA4: BF870095
	.long 0xd71c00b2                                           // 000000166CA8: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000166CAC: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000166CB0: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v176                 // 000000166CB4: 7C3D60FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166CBC: BF870002
	v_cndmask_b32_e32 v176, 0x7f800000, v178, vcc_lo           // 000000166CC0: 036164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000166CC8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000166CCC: BF8700A1
	v_bfe_u32 v178, v176, 16, 1                                // 000000166CD0: D61000B2 020521B0
	s_mov_b32 s1, exec_lo                                      // 000000166CD8: BE81007E
	v_add3_u32 v179, v176, v178, 0x7fff                        // 000000166CDC: D65500B3 03FF65B0 00007FFF
	v_mov_b32_e32 v178, 0                                      // 000000166CE8: 7F640280
	ds_store_b16_d16_hi v156, v179 offset:30                   // 000000166CEC: DA84001E 0000B39C
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 000000166CF4: 7D2306FF EFA18F08
	s_cbranch_execz 63579                                      // 000000166CFC: BFA5F85B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76c>
	v_sub_f32_e32 v131, v131, v130                             // 000000166D00: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166D04: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v131                       // 000000166D08: 116506FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v131, -v178                    // 000000166D10: D61300B3 86CB06FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000166D1C: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000166D20: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 000000166D24: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 000000166D28: 7C3706FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v131                      // 000000166D30: 576706FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166D38: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000166D3C: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000166D40: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000166D44: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166D48: BF870095
	.long 0xd71c00b2                                           // 000000166D4C: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000166D50: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000166D54: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 000000166D58: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000166D60: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v178, vcc_lo           // 000000166D64: 036564FF 7F800000
	s_branch 63551                                             // 000000166D6C: BFA0F83F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76c>
	v_lshlrev_b32_e32 v0, 2, v150                              // 000000166D70: 30012C82
	.long 0xd700008b                                           // 000000166D74: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 000000166D78: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000166D7C: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 000000166D80: D5207C8C 00031813
	v_lshl_or_b32 v0, v148, 6, v0                              // 000000166D88: D6560000 04010D94
	v_lshlrev_b32_e32 v147, 1, v147                            // 000000166D90: 31272681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000166D94: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 000000166D98: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 000000166DA0: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 000000166DA8: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 000000166DAC: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 000000166DB4: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 000000166DBC: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000166DC0: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 000000166DC4: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 000000166DCC: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 000000166DD0: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 000000166DD8: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 000000166DE0: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 000000166DE8: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 000000166DEC: 3505029F
	v_or_b32_e32 v0, v149, v150                                // 000000166DF0: 38012D95
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000166DF4: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 000000166DF8: 11252191
	.long 0xd73c0083                                           // 000000166DFC: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000166E00: 02030281
	.long 0xd7000081                                           // 000000166E04: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 000000166E08: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000166E0C: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 000000166E10: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 000000166E18: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166E20: BF870094
	.long 0xd7000083                                           // 000000166E24: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 000000166E28: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 000000166E2C: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000166E34: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 000000166E38: 57252194
	.long 0xd4440000                                           // 000000166E3C: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000166E40: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 000000166E44: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000166E4C: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 000000166E50: D637008B 064B218B
	.long 0xd7006a83                                           // 000000166E58: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 000000166E5C: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 000000166E60: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000166E68: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 000000166E6C: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 000000166E74: BE812000
	s_cbranch_execz 70                                         // 000000166E78: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2894>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166E7C: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 000000166E80: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000166E8C: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 000000166E90: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 000000166E98: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 000000166E9C: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166EA0: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 000000166EA4: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 000000166EAC: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 000000166EB8: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166EBC: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 000000166EC0: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 000000166EC8: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000166ECC: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 000000166ED0: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 000000166ED4: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 000000166ED8: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 000000166EE0: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166EE4: BF870095
	.long 0xd71c008d                                           // 000000166EE8: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 000000166EEC: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000166EF0: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 000000166EF4: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166EFC: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 000000166F00: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 000000166F08: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F0C: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 000000166F10: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 000000166F18: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F1C: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 000000166F20: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 000000166F28: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 000000166F2C: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F34: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000166F38: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 000000166F3C: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F44: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000166F48: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 000000166F4C: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F54: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 000000166F58: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 000000166F60: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 000000166F68: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166F74: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000166F78: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000166F80: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 000000166F8C: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166F94: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 000000166F98: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 000000166FA0: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166FA8: BF870292
	v_rcp_f32_e32 v140, v121                                   // 000000166FAC: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 000000166FB0: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166FB8: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 000000166FBC: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 000000166FC0: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166FC4: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 000000166FC8: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 000000166FD0: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166FD4: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 000000166FD8: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 000000166FE0: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 000000166FE8: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166FEC: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 000000166FF0: D627008C 03CB1D8C
	.long 0xd4440001                                           // 000000166FF8: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000166FFC: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 000000167000: BE822001
	s_cbranch_execz 69                                         // 000000167004: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2a1c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000167008: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 000000167014: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 000000167018: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000167020: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000167024: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167028: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000016702C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000167034: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000167040: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000167044: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000167048: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000016704C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000167054: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016705C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167060: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000167064: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000167068: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016706C: BF870095
	.long 0xd71c008e                                           // 000000167070: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167074: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000167078: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000016707C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167084: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000167088: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000167090: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167094: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000167098: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001670A0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001670A4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001670A8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001670B0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000001670B4: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001670BC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001670C0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001670C4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001670CC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001670D0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001670D4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001670DC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001670E0: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000001670E8: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000001670F0: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001670FC: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 000000167100: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000167108: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000167114: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000016711C: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 000000167120: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000167124: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000016712C: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000167134: BF870292
	v_rcp_f32_e32 v141, v122                                   // 000000167138: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000016713C: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167144: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000167148: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000016714C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167150: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 000000167154: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000016715C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167160: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000167164: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000016716C: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 000000167174: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000167178: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000016717C: D6270089 03CB138D
	.long 0xd4440002                                           // 000000167184: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 000000167188: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 00000016718C: BE832002
	s_cbranch_execz 69                                         // 000000167190: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ba8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000167194: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000001671A0: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000001671A4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001671AC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001671B0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001671B4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001671B8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001671C0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001671CC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001671D0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001671D4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001671D8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001671E0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001671E8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001671EC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001671F0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001671F4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001671F8: BF870095
	.long 0xd71c008e                                           // 0000001671FC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167200: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000167204: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000167208: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167210: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000167214: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000016721C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167220: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 000000167224: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000016722C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167230: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000167234: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000016723C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 000000167240: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167248: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000016724C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000167250: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167258: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000016725C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000167260: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167268: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000016726C: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 000000167274: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000016727C: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167288: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000016728C: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000167294: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000001672A0: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000001672A8: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000001672AC: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000001672B4: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001672BC: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000001672C0: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000001672C4: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001672CC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001672D0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001672D4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001672D8: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000001672DC: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000001672E4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001672E8: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000001672EC: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000001672F4: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000001672FC: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000167300: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000167304: D627008A 03CB158D
	.long 0xd4440003                                           // 00000016730C: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 000000167310: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 000000167314: BE842003
	s_cbranch_execz 69                                         // 000000167318: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d30>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000016731C: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 000000167328: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000016732C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000167334: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000167338: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016733C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000167340: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000167348: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000167354: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000167358: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000016735C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000167360: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000167368: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000167370: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167374: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000167378: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000016737C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167380: BF870095
	.long 0xd71c008e                                           // 000000167384: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167388: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000016738C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000167390: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167398: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000016739C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001673A4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001673A8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000001673AC: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001673B4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001673B8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001673BC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001673C4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000001673C8: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001673D0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001673D4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001673D8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001673E0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001673E4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001673E8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001673F0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001673F4: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000001673FC: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 000000167404: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167410: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000167414: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000016741C: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000167428: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000167430: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 000000167434: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 000000167438: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 000000167440: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000167448: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000016744C: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 000000167450: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167458: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000016745C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000167460: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167464: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 000000167468: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 000000167470: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167474: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 000000167478: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 000000167480: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 000000167488: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016748C: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 000000167490: D6270087 03CB0F8D
	.long 0xd4440004                                           // 000000167498: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000016749C: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000001674A0: BE852004
	s_cbranch_execz 69                                         // 0000001674A4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ebc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000001674A8: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000001674B4: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000001674B8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001674C0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001674C4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001674C8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001674CC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001674D4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001674E0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001674E4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001674E8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001674EC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001674F4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001674FC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167500: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000167504: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000167508: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016750C: BF870095
	.long 0xd71c008e                                           // 000000167510: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167514: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000167518: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000016751C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167524: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000167528: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000167530: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167534: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 000000167538: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000167540: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167544: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000167548: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000167550: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 000000167554: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016755C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000167560: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000167564: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016756C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000167570: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000167574: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016757C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000167580: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 000000167588: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 000000167590: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016759C: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000001675A0: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000001675A8: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000001675B4: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001675BC: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000001675C0: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000001675C8: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001675D0: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000001675D4: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000001675D8: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001675E0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001675E4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001675E8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001675EC: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000001675F0: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000001675F8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001675FC: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 000000167600: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000167608: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 000000167610: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000167614: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 000000167618: D6270088 03CB118D
	.long 0xd4440005                                           // 000000167620: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000167624: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 000000167628: BE862005
	s_cbranch_execz 69                                         // 00000016762C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3044>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 000000167630: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000016763C: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 000000167640: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000167648: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000016764C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167650: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000167654: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000016765C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000167668: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016766C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000167670: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000167674: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000016767C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000167684: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167688: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000016768C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000167690: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167694: BF870095
	.long 0xd71c008e                                           // 000000167698: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000016769C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001676A0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001676A4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001676AC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001676B0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001676B8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001676BC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000001676C0: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001676C8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001676CC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001676D0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001676D8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000001676DC: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001676E4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001676E8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001676EC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001676F4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001676F8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001676FC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167704: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000167708: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 000000167710: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 000000167718: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167724: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000167728: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 000000167730: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000016773C: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000167744: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000167748: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000016774C: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 000000167754: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016775C: BF870292
	v_rcp_f32_e32 v141, v126                                   // 000000167760: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 000000167764: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016776C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000167770: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000167774: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167778: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000016777C: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 000000167784: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167788: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000016778C: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 000000167794: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000016779C: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001677A0: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000001677A4: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000001677AC: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000001677B0: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000001677B4: BE872006
	s_cbranch_execz 69                                         // 0000001677B8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x31d0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000001677BC: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000001677C8: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000001677CC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001677D4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001677D8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001677DC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001677E0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001677E8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001677F4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001677F8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001677FC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000167800: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000167808: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000167810: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167814: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000167818: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000016781C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167820: BF870095
	.long 0xd71c008e                                           // 000000167824: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167828: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000016782C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000167830: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167838: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000016783C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000167844: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167848: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000016784C: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000167854: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167858: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000016785C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000167864: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 000000167868: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167870: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000167874: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000167878: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167880: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000167884: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000167888: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167890: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000167894: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000016789C: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000001678A4: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001678B0: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000001678B4: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000001678BC: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000001678C8: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001678D0: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000001678D4: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000001678DC: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001678E4: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000001678E8: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000001678EC: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001678F4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001678F8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001678FC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167900: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 000000167904: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000016790C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167910: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 000000167914: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000016791C: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 000000167924: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000167928: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000016792C: D6270086 03CB0D8D
	.long 0xd4440007                                           // 000000167934: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 000000167938: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 00000016793C: BE882007
	s_cbranch_execnz 363                                       // 000000167940: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167944: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167948: BE882000
	s_cbranch_execnz 432                                       // 00000016794C: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167950: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167954: BE882001
	s_cbranch_execnz 501                                       // 000000167958: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016795C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167960: BE882002
	s_cbranch_execnz 570                                       // 000000167964: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167968: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016796C: BE882003
	s_cbranch_execnz 639                                       // 000000167970: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c70>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167974: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167978: BE882004
	s_cbranch_execnz 708                                       // 00000016797C: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d90>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167980: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167984: BE882005
	s_cbranch_execnz 777                                       // 000000167988: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016798C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167990: BE882006
	s_cbranch_execnz 846                                       // 000000167994: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167998: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016799C: BE882007
	s_cbranch_execnz 915                                       // 0000001679A0: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679A4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001679A8: BE882000
	s_cbranch_execnz 984                                       // 0000001679AC: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4210>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679B0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001679B4: BE882001
	s_cbranch_execnz 1053                                      // 0000001679B8: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4330>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679BC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001679C0: BE882002
	s_cbranch_execnz 1122                                      // 0000001679C4: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4450>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679C8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001679CC: BE882003
	s_cbranch_execnz 1191                                      // 0000001679D0: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4570>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679D4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001679D8: BE882004
	s_cbranch_execnz 1260                                      // 0000001679DC: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4690>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679E0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001679E4: BE882005
	s_cbranch_execnz 1329                                      // 0000001679E8: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679EC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001679F0: BE882006
	s_cbranch_execnz 1398                                      // 0000001679F4: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001679F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001679FC: BE882007
	s_cbranch_execnz 1467                                      // 000000167A00: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167A08: BE882000
	s_cbranch_execnz 1536                                      // 000000167A0C: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A10: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167A14: BE882001
	s_cbranch_execnz 1605                                      // 000000167A18: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c30>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167A20: BE882002
	s_cbranch_execnz 1674                                      // 000000167A24: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167A2C: BE882003
	s_cbranch_execnz 1743                                      // 000000167A30: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e70>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167A38: BE882004
	s_cbranch_execnz 1812                                      // 000000167A3C: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f90>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167A44: BE882005
	s_cbranch_execnz 1881                                      // 000000167A48: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167A50: BE882006
	s_cbranch_execnz 1950                                      // 000000167A54: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167A5C: BE882007
	s_cbranch_execnz 2019                                      // 000000167A60: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A64: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167A68: BE882000
	s_cbranch_execnz 2088                                      // 000000167A6C: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5410>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A70: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167A74: BE882001
	s_cbranch_execnz 2157                                      // 000000167A78: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5530>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167A80: BE882002
	s_cbranch_execnz 2226                                      // 000000167A84: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5650>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167A8C: BE882003
	s_cbranch_execnz 2295                                      // 000000167A90: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5770>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167A94: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167A98: BE882004
	s_cbranch_execnz 2364                                      // 000000167A9C: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5890>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167AA4: BE882005
	s_cbranch_execnz 2433                                      // 000000167AA8: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AAC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167AB0: BE882006
	s_cbranch_execnz 2502                                      // 000000167AB4: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ad0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AB8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167ABC: BE882007
	s_cbranch_execnz 2571                                      // 000000167AC0: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bf0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AC4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167AC8: BE882000
	s_cbranch_execnz 2640                                      // 000000167ACC: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AD0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167AD4: BE882001
	s_cbranch_execnz 2709                                      // 000000167AD8: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e30>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167ADC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167AE0: BE882002
	s_cbranch_execnz 2778                                      // 000000167AE4: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AE8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167AEC: BE882003
	s_cbranch_execnz 2847                                      // 000000167AF0: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6070>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167AF4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167AF8: BE882004
	s_cbranch_execnz 2916                                      // 000000167AFC: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6190>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167B04: BE882005
	s_cbranch_execnz 2985                                      // 000000167B08: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B0C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167B10: BE882006
	s_cbranch_execnz 3054                                      // 000000167B14: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167B1C: BE882007
	s_cbranch_execnz 3123                                      // 000000167B20: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B24: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167B28: BE882000
	s_cbranch_execnz 3192                                      // 000000167B2C: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6610>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167B34: BE882001
	s_cbranch_execnz 3261                                      // 000000167B38: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6730>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B3C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167B40: BE882002
	s_cbranch_execnz 3330                                      // 000000167B44: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6850>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B48: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167B4C: BE882003
	s_cbranch_execnz 3399                                      // 000000167B50: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6970>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B54: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167B58: BE882004
	s_cbranch_execnz 3468                                      // 000000167B5C: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a90>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B60: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167B64: BE882005
	s_cbranch_execnz 3537                                      // 000000167B68: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B6C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167B70: BE882006
	s_cbranch_execnz 3606                                      // 000000167B74: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6cd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B78: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167B7C: BE882007
	s_cbranch_execnz 3675                                      // 000000167B80: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6df0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B84: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167B88: BE882000
	s_cbranch_execnz 3744                                      // 000000167B8C: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167B94: BE882001
	s_cbranch_execnz 3813                                      // 000000167B98: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7030>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167B9C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167BA0: BE882002
	s_cbranch_execnz 3882                                      // 000000167BA4: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7150>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BA8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167BAC: BE882003
	s_cbranch_execnz 3951                                      // 000000167BB0: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7270>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BB4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167BB8: BE882004
	s_cbranch_execnz 4020                                      // 000000167BBC: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7390>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BC0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167BC4: BE882005
	s_cbranch_execnz 4089                                      // 000000167BC8: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167BD0: BE882006
	s_cbranch_execnz 4158                                      // 000000167BD4: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BD8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167BDC: BE882007
	s_cbranch_execnz 4227                                      // 000000167BE0: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BE4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167BE8: BE882000
	s_cbranch_execnz 4296                                      // 000000167BEC: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7810>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167BF4: BE882001
	s_cbranch_execnz 4365                                      // 000000167BF8: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7930>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167BFC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167C00: BE882002
	s_cbranch_execnz 4434                                      // 000000167C04: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C08: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167C0C: BE882003
	s_cbranch_execnz 4503                                      // 000000167C10: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b70>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C14: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167C18: BE882004
	s_cbranch_execnz 4572                                      // 000000167C1C: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c90>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C20: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167C24: BE882005
	s_cbranch_execnz 4641                                      // 000000167C28: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7db0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C2C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167C30: BE882006
	s_cbranch_execnz 4710                                      // 000000167C34: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ed0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C38: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167C3C: BE882007
	s_cbranch_execnz 4779                                      // 000000167C40: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ff0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167C48: BE882000
	s_cbranch_execnz 4848                                      // 000000167C4C: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8110>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C50: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167C54: BE882001
	s_cbranch_execnz 4917                                      // 000000167C58: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8230>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C5C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167C60: BE882002
	s_cbranch_execnz 4986                                      // 000000167C64: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8350>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167C6C: BE882003
	s_cbranch_execnz 5055                                      // 000000167C70: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8470>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C74: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167C78: BE882004
	s_cbranch_execnz 5124                                      // 000000167C7C: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8590>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C80: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167C84: BE882005
	s_cbranch_execnz 5193                                      // 000000167C88: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167C90: BE882006
	s_cbranch_execnz 5262                                      // 000000167C94: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167C98: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167C9C: BE882007
	s_cbranch_execnz 5331                                      // 000000167CA0: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CA4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167CA8: BE882000
	s_cbranch_execnz 5400                                      // 000000167CAC: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CB0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167CB4: BE882001
	s_cbranch_execnz 5469                                      // 000000167CB8: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b30>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CBC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167CC0: BE882002
	s_cbranch_execnz 5538                                      // 000000167CC4: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CC8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167CCC: BE882003
	s_cbranch_execnz 5607                                      // 000000167CD0: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d70>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CD4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167CD8: BE882004
	s_cbranch_execnz 5676                                      // 000000167CDC: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e90>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CE0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167CE4: BE882005
	s_cbranch_execnz 5745                                      // 000000167CE8: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8fb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CEC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167CF0: BE882006
	s_cbranch_execnz 5814                                      // 000000167CF4: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167CF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167CFC: BE882007
	s_cbranch_execnz 5883                                      // 000000167D00: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167D08: BE882000
	s_cbranch_execnz 5952                                      // 000000167D0C: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9310>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D10: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167D14: BE882001
	s_cbranch_execnz 6021                                      // 000000167D18: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9430>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167D20: BE882002
	s_cbranch_execnz 6090                                      // 000000167D24: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9550>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167D2C: BE882003
	s_cbranch_execnz 6159                                      // 000000167D30: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9670>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167D38: BE882004
	s_cbranch_execnz 6228                                      // 000000167D3C: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9790>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167D44: BE882005
	s_cbranch_execnz 6297                                      // 000000167D48: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167D50: BE882006
	s_cbranch_execnz 6366                                      // 000000167D54: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167D5C: BE882007
	s_cbranch_execnz 6435                                      // 000000167D60: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9af0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D64: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167D68: BE882000
	s_cbranch_execnz 6504                                      // 000000167D6C: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D70: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167D74: BE882001
	s_cbranch_execnz 6573                                      // 000000167D78: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d30>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167D80: BE882002
	s_cbranch_execnz 6642                                      // 000000167D84: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e50>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167D8C: BE882003
	s_cbranch_execnz 6711                                      // 000000167D90: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f70>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167D94: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167D98: BE882004
	s_cbranch_execnz 6780                                      // 000000167D9C: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa090>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167DA4: BE882005
	s_cbranch_execnz 6849                                      // 000000167DA8: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DAC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167DB0: BE882006
	s_cbranch_execnz 6918                                      // 000000167DB4: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DB8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167DBC: BE882007
	s_cbranch_execnz 6987                                      // 000000167DC0: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DC4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167DC8: BE882000
	s_cbranch_execnz 7056                                      // 000000167DCC: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa510>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DD0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167DD4: BE882001
	s_cbranch_execnz 7125                                      // 000000167DD8: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa630>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DDC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167DE0: BE882002
	s_cbranch_execnz 7194                                      // 000000167DE4: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa750>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DE8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167DEC: BE882003
	s_cbranch_execnz 7263                                      // 000000167DF0: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa870>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167DF4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167DF8: BE882004
	s_cbranch_execnz 7332                                      // 000000167DFC: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa990>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167E04: BE882005
	s_cbranch_execnz 7401                                      // 000000167E08: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaab0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E0C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167E10: BE882006
	s_cbranch_execnz 7470                                      // 000000167E14: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xabd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167E1C: BE882007
	s_cbranch_execnz 7539                                      // 000000167E20: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacf0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E24: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167E28: BE882000
	s_cbranch_execnz 7608                                      // 000000167E2C: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000167E34: BE882001
	s_cbranch_execnz 7677                                      // 000000167E38: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf30>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E3C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000167E40: BE882002
	s_cbranch_execnz 7746                                      // 000000167E44: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb050>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E48: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000167E4C: BE882003
	s_cbranch_execnz 7815                                      // 000000167E50: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb170>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E54: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000167E58: BE882004
	s_cbranch_execnz 7884                                      // 000000167E5C: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb290>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E60: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000167E64: BE882005
	s_cbranch_execnz 7953                                      // 000000167E68: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E6C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000167E70: BE882006
	s_cbranch_execnz 8022                                      // 000000167E74: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E78: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000167E7C: BE882007
	s_cbranch_execnz 8091                                      // 000000167E80: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E84: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000167E88: BE882000
	s_cbranch_execnz 8160                                      // 000000167E8C: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb710>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000167E90: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000167E94: BE802001
	s_cbranch_execnz 8229                                      // 000000167E98: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb830>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167E9C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000167EA0: BE802002
	s_cbranch_execnz 8298                                      // 000000167EA4: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb950>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167EA8: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000167EAC: BE802003
	s_cbranch_execnz 8367                                      // 000000167EB0: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba70>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167EB4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000167EB8: BE802004
	s_cbranch_execnz 8436                                      // 000000167EBC: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb90>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167EC0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000167EC4: BE802005
	s_cbranch_execnz 8505                                      // 000000167EC8: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcb0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167ECC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000167ED0: BE802006
	s_cbranch_execnz 8574                                      // 000000167ED4: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbdd0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000167ED8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000167EDC: BE802007
	s_cbranch_execnz 8643                                      // 000000167EE0: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbef0>
	s_nop 0                                                    // 000000167EE4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000167EE8: BFB60003
	s_endpgm                                                   // 000000167EEC: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 000000167EF0: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000167EFC: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000167F00: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000167F08: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000167F0C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F10: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000167F14: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000167F1C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000167F28: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000167F2C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000167F30: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000167F34: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000167F3C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000167F44: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000167F48: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000167F4C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000167F50: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F54: BF870095
	.long 0xd71c008e                                           // 000000167F58: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000167F5C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000167F60: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000167F64: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F6C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000167F70: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000167F78: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F7C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 000000167F80: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000167F88: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F8C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000167F90: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000167F98: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000167F9C: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167FA4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000167FA8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000167FAC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167FB4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000167FB8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000167FBC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167FC4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000167FC8: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000167FD0: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000167FD8: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167FE4: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000167FE8: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000167FF0: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000167FFC: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168004: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000168008: BE882000
	s_cbranch_execz 65104                                      // 00000016800C: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3250>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000168010: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000016801C: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000168020: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 000000168028: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000016802C: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168030: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 000000168034: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000016803C: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000168048: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016804C: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 000000168050: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 000000168054: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000016805C: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168064: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000168068: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000016806C: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 000000168070: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168074: BF870095
	.long 0xd71c008d                                           // 000000168078: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000016807C: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000168080: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000168084: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016808C: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000168090: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000168098: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016809C: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000001680A0: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000001680A8: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001680AC: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000001680B0: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000001680B8: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000001680BC: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001680C4: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000001680C8: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000001680CC: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001680D4: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000001680D8: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000001680DC: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001680E4: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000001680E8: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000001680F0: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000001680F8: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168104: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 000000168108: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 000000168110: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000016811C: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168124: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000168128: BE882001
	s_cbranch_execz 65035                                      // 00000016812C: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x325c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000168130: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000016813C: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 000000168140: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 000000168148: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000016814C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168150: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 000000168154: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000016815C: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 000000168168: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016816C: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 000000168170: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000168174: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000016817C: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168184: BF870121
	v_add_f32_e32 v128, v128, v141                             // 000000168188: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000016818C: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 000000168190: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168194: BF870095
	.long 0xd71c0080                                           // 000000168198: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000016819C: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000001681A0: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001681A4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681AC: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000001681B0: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001681B8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681BC: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000001681C0: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000001681C8: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681CC: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000001681D0: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000001681D8: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000001681DC: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681E4: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000001681E8: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000001681EC: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681F4: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000001681F8: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000001681FC: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168204: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000168208: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000168210: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000168218: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168224: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000168228: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 000000168230: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000016823C: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168244: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000168248: BE882002
	s_cbranch_execz 64966                                      // 00000016824C: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3268>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 000000168250: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000016825C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000168264: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000168268: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016826C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000168270: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 000000168278: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 000000168284: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000168288: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 00000016828C: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000168294: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000168298: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 00000016829C: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000001682A0: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001682A4: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000001682AC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001682B0: BF870095
	.long 0xd71c0072                                           // 0000001682B4: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000001682B8: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001682BC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001682C0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001682C8: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000001682CC: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001682D8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001682DC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001682E0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000001682E8: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001682EC: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000001682F0: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000001682F8: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000001682FC: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168304: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000168308: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000016830C: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168314: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000168318: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000016831C: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168324: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000168328: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000168330: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 000000168338: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168344: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 000000168348: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 000000168350: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000016835C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168364: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000168368: BE882003
	s_cbranch_execz 64897                                      // 00000016836C: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3274>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 000000168370: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000016837C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000168384: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000168388: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016838C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000168390: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000168398: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000001683A4: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001683A8: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000001683AC: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001683B0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000001683B8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001683C0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001683C4: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000001683C8: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000001683CC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001683D0: BF870095
	.long 0xd71c0072                                           // 0000001683D4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001683D8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001683DC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001683E0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001683E8: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000001683EC: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001683F8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001683FC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000168400: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000168408: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016840C: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 000000168410: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000168418: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000016841C: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168424: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000168428: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000016842C: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168434: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 000000168438: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000016843C: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168444: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 000000168448: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000168450: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 000000168458: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168464: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000168468: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000168470: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000016847C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168484: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000168488: BE882004
	s_cbranch_execz 64828                                      // 00000016848C: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3280>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 000000168490: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000016849C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001684A4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001684A8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001684AC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001684B0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000001684B8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000001684C4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001684C8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000001684CC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001684D0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000001684D8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001684E0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001684E4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000001684E8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000001684EC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001684F0: BF870095
	.long 0xd71c0072                                           // 0000001684F4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001684F8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001684FC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000168500: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168508: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000016850C: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000168518: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016851C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000168520: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000168528: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016852C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000168530: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000168538: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000016853C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168544: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 000000168548: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000016854C: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168554: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 000000168558: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000016855C: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168564: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 000000168568: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000168570: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 000000168578: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168584: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000168588: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000168590: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000016859C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001685A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001685A8: BE882005
	s_cbranch_execz 64759                                      // 0000001685AC: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x328c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000001685B0: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001685BC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001685C4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001685C8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001685CC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001685D0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000001685D8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000001685E4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001685E8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000001685EC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001685F0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000001685F8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168600: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000168604: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000168608: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000016860C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168610: BF870095
	.long 0xd71c0072                                           // 000000168614: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000168618: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000016861C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000168620: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168628: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000016862C: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 000000168634: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016863C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000168640: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000168648: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016864C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000168650: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000168658: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000016865C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168664: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000168668: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 00000016866C: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168674: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 000000168678: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 00000016867C: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168684: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000168688: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000168690: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 000000168698: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001686A4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001686A8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001686B0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001686BC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001686C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001686C8: BE882006
	s_cbranch_execz 64690                                      // 0000001686CC: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3298>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000001686D0: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001686DC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001686E4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001686E8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001686EC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001686F0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000001686F8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000168704: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000168708: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000016870C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000168710: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000168718: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168720: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000168724: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000168728: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000016872C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168730: BF870095
	.long 0xd71c0072                                           // 000000168734: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000168738: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000016873C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000168740: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168748: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000016874C: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000168758: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016875C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000168760: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000168768: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016876C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000168770: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000168778: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000016877C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168784: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000168788: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000016878C: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168794: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000168798: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000016879C: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001687A4: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000001687A8: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001687B0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000001687B8: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001687C4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001687C8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001687D0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001687DC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001687E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001687E8: BE882007
	s_cbranch_execz 64621                                      // 0000001687EC: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32a4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000001687F0: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001687FC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000168804: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000168808: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016880C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000168810: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000168818: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000168824: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000168828: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000016882C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000168830: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000168838: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168840: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000168844: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000168848: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000016884C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168850: BF870095
	.long 0xd71c0072                                           // 000000168854: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000168858: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000016885C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000168860: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168868: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 00000016886C: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000168878: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016887C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000168880: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000168888: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016888C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000168890: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000168898: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000016889C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001688A4: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000001688A8: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000001688AC: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001688B4: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000001688B8: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000001688BC: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001688C4: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000001688C8: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001688D0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000001688D8: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001688E4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001688E8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001688F0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001688FC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168904: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000168908: BE882000
	s_cbranch_execz 64552                                      // 00000016890C: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32b0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 000000168910: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000016891C: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 000000168920: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000168928: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000016892C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168930: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000168934: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000016893C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000168948: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016894C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000168950: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000168954: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000016895C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168964: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000168968: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000016896C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000168970: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168974: BF870095
	.long 0xd71c0072                                           // 000000168978: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000016897C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000168980: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000168984: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016898C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000168990: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000168998: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016899C: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000001689A0: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000001689A8: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001689AC: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000001689B0: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000001689B8: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000001689BC: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001689C4: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000001689C8: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000001689CC: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001689D4: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000001689D8: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000001689DC: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001689E4: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000001689E8: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000001689F0: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000001689F8: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168A04: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000168A08: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 000000168A10: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000168A1C: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168A24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000168A28: BE882001
	s_cbranch_execz 64483                                      // 000000168A2C: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32bc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 000000168A30: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000168A3C: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 000000168A40: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 000000168A48: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168A4C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168A50: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000168A54: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000168A5C: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 000000168A64: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000168A70: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000168A74: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 000000168A78: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 000000168A80: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168A84: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000168A88: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000168A8C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000168A90: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168A94: BF870095
	.long 0xd71c0071                                           // 000000168A98: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000168A9C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000168AA0: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000168AA4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168AAC: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 000000168AB0: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000168AB8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168ABC: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000168AC0: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000168AC8: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168ACC: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000168AD0: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000168AD8: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 000000168ADC: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168AE4: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000168AE8: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000168AEC: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168AF4: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000168AF8: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000168AFC: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168B04: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000168B08: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 000000168B10: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000168B18: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168B24: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000168B28: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 000000168B30: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000168B3C: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168B44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000168B48: BE882002
	s_cbranch_execz 64414                                      // 000000168B4C: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32c8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000168B50: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000168B5C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000168B64: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168B68: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168B6C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000168B70: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 000000168B78: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000168B84: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000168B88: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000168B8C: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000168B90: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 000000168B98: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168BA0: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000168BA4: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 000000168BA8: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000168BAC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168BB0: BF870095
	.long 0xd71c006a                                           // 000000168BB4: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 000000168BB8: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000168BBC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000168BC0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168BC8: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000168BCC: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000168BD8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168BDC: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000168BE0: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000168BE8: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168BEC: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 000000168BF0: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000168BF8: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000168BFC: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168C04: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000168C08: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000168C0C: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168C14: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000168C18: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000168C1C: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168C24: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000168C28: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000168C30: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000168C38: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168C44: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000168C48: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000168C50: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000168C5C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168C64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000168C68: BE882003
	s_cbranch_execz 64345                                      // 000000168C6C: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32d4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000168C70: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000168C7C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000168C84: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168C88: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168C8C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000168C90: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000168C98: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000168CA4: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168CA8: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000168CAC: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000168CB8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000168CBC: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000168CC0: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000168CC8: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000168CCC: 7ED44B6A
	.long 0xd71c006a                                           // 000000168CD0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000168CD4: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168CD8: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000168CDC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000168CE0: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000168CE8: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168CF4: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000168CF8: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000168CFC: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000168D04: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000168D08: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000168D0C: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000168D14: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000168D18: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000168D1C: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000168D24: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168D28: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000168D2C: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000168D34: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168D38: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000168D3C: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000168D44: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168D4C: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000168D50: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000168D58: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000168D64: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000168D6C: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000168D70: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000168D7C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168D84: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000168D88: BE882004
	s_cbranch_execz 64276                                      // 000000168D8C: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32e0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000168D90: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000168D9C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000168DA4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168DA8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168DAC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000168DB0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000168DB8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000168DC4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000168DC8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000168DCC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000168DD0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000168DD8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168DE0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000168DE4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000168DE8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000168DEC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168DF0: BF870095
	.long 0xd71c006a                                           // 000000168DF4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000168DF8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000168DFC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000168E00: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E08: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000168E0C: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000168E18: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E1C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000168E20: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000168E28: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E2C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000168E30: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000168E38: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000168E3C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E44: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000168E48: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000168E4C: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E54: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000168E58: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000168E5C: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E64: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000168E68: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000168E70: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000168E78: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168E84: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000168E88: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000168E90: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000168E9C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168EA4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000168EA8: BE882005
	s_cbranch_execz 64207                                      // 000000168EAC: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32ec>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000168EB0: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000168EBC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000168EC4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168EC8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168ECC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000168ED0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000168ED8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000168EE4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000168EE8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000168EEC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000168EF0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000168EF8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000168F00: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000168F04: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000168F08: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000168F0C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F10: BF870095
	.long 0xd71c006a                                           // 000000168F14: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000168F18: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000168F1C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000168F20: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F28: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000168F2C: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000168F34: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F3C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000168F40: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000168F48: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F4C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000168F50: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000168F58: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000168F5C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F64: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000168F68: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000168F6C: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F74: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000168F78: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000168F7C: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168F84: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000168F88: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000168F90: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000168F98: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168FA4: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000168FA8: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000168FB0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000168FBC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168FC4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000168FC8: BE882006
	s_cbranch_execz 64138                                      // 000000168FCC: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32f8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000168FD0: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000168FDC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000168FE4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000168FE8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168FEC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000168FF0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000168FF8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000169004: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169008: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000016900C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000169010: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000169018: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169020: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000169024: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000169028: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000016902C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169030: BF870095
	.long 0xd71c006a                                           // 000000169034: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000169038: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000016903C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000169040: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169048: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 00000016904C: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000169058: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016905C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000169060: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000169068: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016906C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000169070: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000169078: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000016907C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169084: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000169088: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000016908C: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169094: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000169098: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000016909C: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001690A4: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000001690A8: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000001690B0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000001690B8: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001690C4: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000001690C8: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000001690D0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000001690DC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001690E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001690E8: BE882007
	s_cbranch_execz 64069                                      // 0000001690EC: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3304>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000001690F0: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000001690FC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000169104: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000169108: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016910C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000169110: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000169118: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000169124: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169128: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000016912C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000169130: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000169138: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169140: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000169144: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000169148: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000016914C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169150: BF870095
	.long 0xd71c006a                                           // 000000169154: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000169158: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000016915C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000169160: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169168: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000016916C: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000169178: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016917C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000169180: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000169188: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016918C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000169190: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000169198: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000016919C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001691A4: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000001691A8: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000001691AC: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001691B4: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000001691B8: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000001691BC: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001691C4: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000001691C8: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000001691D0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000001691D8: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001691E4: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000001691E8: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000001691F0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000001691FC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169204: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000169208: BE882000
	s_cbranch_execz 64000                                      // 00000016920C: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3310>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000169210: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000016921C: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000169220: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 000000169228: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000016922C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169230: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000169234: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000016923C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000169248: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016924C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000169250: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000169254: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000016925C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169264: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000169268: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000016926C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000169270: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169274: BF870095
	.long 0xd71c006a                                           // 000000169278: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000016927C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000169280: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000169284: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016928C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000169290: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000169298: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016929C: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000001692A0: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000001692A8: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001692AC: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000001692B0: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000001692B8: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000001692BC: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001692C4: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000001692C8: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000001692CC: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001692D4: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000001692D8: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000001692DC: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001692E4: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000001692E8: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000001692F0: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000001692F8: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169304: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000169308: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000169310: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000016931C: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169324: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000169328: BE882001
	s_cbranch_execz 63931                                      // 00000016932C: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x331c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 000000169330: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000016933C: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 000000169340: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 000000169348: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000016934C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169350: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 000000169354: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000016935C: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 000000169364: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000169370: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000169374: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 000000169378: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 000000169380: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169384: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000169388: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000016938C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000169390: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169394: BF870095
	.long 0xd71c0069                                           // 000000169398: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000016939C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001693A0: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001693A4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001693AC: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000001693B0: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001693B8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001693BC: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000001693C0: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000001693C8: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001693CC: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000001693D0: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000001693D8: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000001693DC: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001693E4: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000001693E8: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000001693EC: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001693F4: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000001693F8: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000001693FC: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169404: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000169408: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000169410: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000169418: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169424: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000169428: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 000000169430: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000016943C: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169444: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000169448: BE882002
	s_cbranch_execz 63862                                      // 00000016944C: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3328>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 000000169450: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000016945C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000169464: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000169468: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016946C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000169470: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 000000169478: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 000000169484: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169488: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 00000016948C: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000169490: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 000000169498: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001694A0: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000001694A4: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000001694A8: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000001694AC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001694B0: BF870095
	.long 0xd71c0062                                           // 0000001694B4: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000001694B8: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001694BC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001694C0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001694C8: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000001694CC: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001694D8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001694DC: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001694E0: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000001694E8: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001694EC: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000001694F0: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000001694F8: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000001694FC: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169504: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 000000169508: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000016950C: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169514: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 000000169518: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000016951C: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169524: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 000000169528: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000169530: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 000000169538: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169544: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 000000169548: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 000000169550: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000016955C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169564: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000169568: BE882003
	s_cbranch_execz 63793                                      // 00000016956C: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3334>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 000000169570: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000016957C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000169584: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000169588: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016958C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000169590: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000169598: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000001695A4: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001695A8: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000001695AC: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000001695B8: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000001695BC: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001695C0: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001695C8: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000001695CC: 7EC44B62
	.long 0xd71c0062                                           // 0000001695D0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000001695D4: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001695D8: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001695DC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001695E0: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000001695E8: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001695F4: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000001695F8: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001695FC: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000169604: BF870291
	v_rcp_f32_e32 v100, v99                                    // 000000169608: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000016960C: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000169614: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 000000169618: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000016961C: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 000000169624: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169628: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000016962C: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 000000169634: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169638: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000016963C: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 000000169644: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016964C: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000169650: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 000000169658: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 000000169664: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016966C: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000169670: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000016967C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169684: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000169688: BE882004
	s_cbranch_execz 63724                                      // 00000016968C: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3340>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 000000169690: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000016969C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001696A4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001696A8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001696AC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001696B0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001696B8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000001696C4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001696C8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000001696CC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001696D0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000001696D8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001696E0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000001696E4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000001696E8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000001696EC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001696F0: BF870095
	.long 0xd71c0062                                           // 0000001696F4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000001696F8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001696FC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000169700: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169708: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 00000016970C: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000169718: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016971C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000169720: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000169728: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016972C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000169730: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000169738: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000016973C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169744: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 000000169748: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 00000016974C: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169754: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 000000169758: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 00000016975C: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169764: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 000000169768: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000169770: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 000000169778: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169784: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000169788: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000169790: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000016979C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001697A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001697A8: BE882005
	s_cbranch_execz 63655                                      // 0000001697AC: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x334c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000001697B0: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001697BC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001697C4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001697C8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001697CC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001697D0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001697D8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000001697E4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001697E8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000001697EC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001697F0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000001697F8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169800: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000169804: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000169808: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000016980C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169810: BF870095
	.long 0xd71c0062                                           // 000000169814: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000169818: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000016981C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000169820: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169828: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000016982C: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000169834: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016983C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000169840: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000169848: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016984C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000169850: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000169858: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000016985C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169864: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000169868: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 00000016986C: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169874: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 000000169878: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 00000016987C: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169884: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000169888: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000169890: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 000000169898: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001698A4: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001698A8: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001698B0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001698BC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001698C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001698C8: BE882006
	s_cbranch_execz 63586                                      // 0000001698CC: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3358>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000001698D0: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001698DC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001698E4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001698E8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001698EC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001698F0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001698F8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000169904: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169908: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000016990C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000169910: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000169918: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169920: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000169924: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000169928: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000016992C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169930: BF870095
	.long 0xd71c0062                                           // 000000169934: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000169938: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000016993C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000169940: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169948: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 00000016994C: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000169958: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016995C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000169960: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000169968: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016996C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000169970: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000169978: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000016997C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169984: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000169988: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000016998C: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169994: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000169998: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000016999C: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001699A4: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000001699A8: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001699B0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000001699B8: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001699C4: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001699C8: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001699D0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001699DC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001699E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001699E8: BE882007
	s_cbranch_execz 63517                                      // 0000001699EC: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3364>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000001699F0: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001699FC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000169A04: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000169A08: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169A0C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000169A10: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000169A18: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000169A24: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169A28: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000169A2C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000169A30: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000169A38: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169A40: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000169A44: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000169A48: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000169A4C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169A50: BF870095
	.long 0xd71c0062                                           // 000000169A54: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000169A58: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000169A5C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000169A60: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169A68: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000169A6C: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000169A78: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169A7C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000169A80: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000169A88: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169A8C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000169A90: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000169A98: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000169A9C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169AA4: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000169AA8: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000169AAC: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169AB4: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000169AB8: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000169ABC: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169AC4: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000169AC8: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000169AD0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000169AD8: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169AE4: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000169AE8: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000169AF0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000169AFC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169B04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000169B08: BE882000
	s_cbranch_execz 63448                                      // 000000169B0C: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3370>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 000000169B10: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000169B1C: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 000000169B20: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000169B28: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000169B2C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169B30: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000169B34: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000169B3C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000169B48: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169B4C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000169B50: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000169B54: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000169B5C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169B64: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000169B68: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000169B6C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000169B70: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169B74: BF870095
	.long 0xd71c0062                                           // 000000169B78: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000169B7C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000169B80: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000169B84: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169B8C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000169B90: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000169B98: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169B9C: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 000000169BA0: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 000000169BA8: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169BAC: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000169BB0: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000169BB8: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 000000169BBC: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169BC4: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000169BC8: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000169BCC: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169BD4: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000169BD8: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000169BDC: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169BE4: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000169BE8: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 000000169BF0: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000169BF8: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169C04: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000169C08: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 000000169C10: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000169C1C: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169C24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000169C28: BE882001
	s_cbranch_execz 63379                                      // 000000169C2C: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x337c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 000000169C30: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000169C3C: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000169C40: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000169C48: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000169C4C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169C50: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000169C54: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000169C5C: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000169C64: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000169C70: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000169C74: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000169C78: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 000000169C80: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169C84: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000169C88: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000169C8C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000169C90: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169C94: BF870095
	.long 0xd71c0061                                           // 000000169C98: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000169C9C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000169CA0: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000169CA4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169CAC: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000169CB0: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000169CB8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169CBC: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000169CC0: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000169CC8: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169CCC: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000169CD0: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000169CD8: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000169CDC: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169CE4: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000169CE8: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000169CEC: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169CF4: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000169CF8: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000169CFC: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169D04: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000169D08: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000169D10: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000169D18: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169D24: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000169D28: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000169D30: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000169D3C: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169D44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000169D48: BE882002
	s_cbranch_execz 63310                                      // 000000169D4C: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3388>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000169D50: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000169D5C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000169D64: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000169D68: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169D6C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000169D70: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000169D78: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000169D84: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169D88: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000169D8C: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000169D90: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000169D98: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169DA0: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000169DA4: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000169DA8: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000169DAC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169DB0: BF870095
	.long 0xd71c005a                                           // 000000169DB4: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000169DB8: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000169DBC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000169DC0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169DC8: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000169DCC: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000169DD8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169DDC: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000169DE0: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000169DE8: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169DEC: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 000000169DF0: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000169DF8: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000169DFC: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169E04: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000169E08: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000169E0C: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169E14: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000169E18: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000169E1C: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169E24: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000169E28: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000169E30: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000169E38: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169E44: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000169E48: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000169E50: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000169E5C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169E64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000169E68: BE882003
	s_cbranch_execz 63241                                      // 000000169E6C: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3394>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000169E70: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000169E7C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000169E84: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000169E88: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169E8C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000169E90: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000169E98: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000169EA4: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169EA8: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000169EAC: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000169EB8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000169EBC: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000169EC0: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000169EC8: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000169ECC: 7EB44B5A
	.long 0xd71c005a                                           // 000000169ED0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000169ED4: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169ED8: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000169EDC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000169EE0: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000169EE8: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169EF4: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000169EF8: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000169EFC: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000169F04: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000169F08: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000169F0C: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000169F14: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000169F18: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000169F1C: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000169F24: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169F28: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000169F2C: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000169F34: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169F38: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000169F3C: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000169F44: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169F4C: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000169F50: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000169F58: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000169F64: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000169F6C: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000169F70: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000169F7C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000169F84: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000169F88: BE882004
	s_cbranch_execz 63172                                      // 000000169F8C: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000169F90: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000169F9C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000169FA4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000169FA8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169FAC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000169FB0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000169FB8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000169FC4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000169FC8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000169FCC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000169FD0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000169FD8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000169FE0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000169FE4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000169FE8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000169FEC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000169FF0: BF870095
	.long 0xd71c005a                                           // 000000169FF4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000169FF8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000169FFC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000016A000: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A008: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 00000016A00C: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000016A018: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A01C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000016A020: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000016A028: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A02C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000016A030: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000016A038: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000016A03C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A044: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 00000016A048: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 00000016A04C: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A054: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 00000016A058: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 00000016A05C: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A064: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 00000016A068: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000016A070: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 00000016A078: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A084: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000016A088: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000016A090: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000016A09C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A0A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016A0A8: BE882005
	s_cbranch_execz 63103                                      // 00000016A0AC: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ac>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 00000016A0B0: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000016A0BC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000016A0C4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000016A0C8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A0CC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000016A0D0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000016A0D8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000016A0E4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A0E8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000016A0EC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000016A0F0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000016A0F8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A100: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000016A104: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000016A108: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000016A10C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A110: BF870095
	.long 0xd71c005a                                           // 00000016A114: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000016A118: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000016A11C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000016A120: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A128: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000016A12C: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 00000016A134: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A13C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000016A140: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000016A148: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A14C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000016A150: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000016A158: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000016A15C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A164: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000016A168: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 00000016A16C: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A174: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 00000016A178: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 00000016A17C: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A184: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000016A188: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000016A190: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 00000016A198: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A1A4: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000016A1A8: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000016A1B0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000016A1BC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A1C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016A1C8: BE882006
	s_cbranch_execz 63034                                      // 00000016A1CC: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 00000016A1D0: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000016A1DC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000016A1E4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000016A1E8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A1EC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000016A1F0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000016A1F8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000016A204: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A208: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000016A20C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000016A210: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000016A218: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A220: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000016A224: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000016A228: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000016A22C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A230: BF870095
	.long 0xd71c005a                                           // 00000016A234: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000016A238: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000016A23C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000016A240: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A248: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 00000016A24C: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000016A258: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A25C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000016A260: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000016A268: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A26C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000016A270: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000016A278: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000016A27C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A284: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000016A288: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000016A28C: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A294: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000016A298: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000016A29C: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A2A4: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000016A2A8: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000016A2B0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 00000016A2B8: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A2C4: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000016A2C8: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000016A2D0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000016A2DC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A2E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016A2E8: BE882007
	s_cbranch_execz 62965                                      // 00000016A2EC: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000016A2F0: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000016A2FC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000016A304: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000016A308: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A30C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000016A310: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000016A318: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000016A324: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A328: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000016A32C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000016A330: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000016A338: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A340: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000016A344: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000016A348: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000016A34C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A350: BF870095
	.long 0xd71c005a                                           // 00000016A354: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000016A358: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000016A35C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000016A360: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A368: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 00000016A36C: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000016A378: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A37C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000016A380: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000016A388: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A38C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000016A390: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000016A398: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000016A39C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A3A4: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000016A3A8: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000016A3AC: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A3B4: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000016A3B8: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000016A3BC: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A3C4: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000016A3C8: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000016A3D0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 00000016A3D8: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A3E4: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000016A3E8: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000016A3F0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000016A3FC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A404: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016A408: BE882000
	s_cbranch_execz 62896                                      // 00000016A40C: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 00000016A410: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000016A41C: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 00000016A420: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 00000016A428: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000016A42C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A430: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000016A434: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000016A43C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000016A448: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A44C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000016A450: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000016A454: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000016A45C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A464: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000016A468: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000016A46C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000016A470: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A474: BF870095
	.long 0xd71c005a                                           // 00000016A478: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000016A47C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000016A480: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000016A484: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A48C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000016A490: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000016A498: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A49C: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 00000016A4A0: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000016A4A8: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A4AC: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000016A4B0: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000016A4B8: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 00000016A4BC: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A4C4: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000016A4C8: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000016A4CC: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A4D4: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000016A4D8: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000016A4DC: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A4E4: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000016A4E8: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000016A4F0: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 00000016A4F8: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A504: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 00000016A508: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000016A510: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 00000016A51C: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A524: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016A528: BE882001
	s_cbranch_execz 62827                                      // 00000016A52C: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33dc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000016A530: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 00000016A53C: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000016A540: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 00000016A548: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016A54C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A550: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 00000016A554: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016A55C: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 00000016A564: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000016A570: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016A574: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 00000016A578: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000016A580: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A584: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000016A588: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000016A58C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000016A590: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A594: BF870095
	.long 0xd71c0059                                           // 00000016A598: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000016A59C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000016A5A0: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016A5A4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A5AC: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000016A5B0: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016A5B8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A5BC: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000016A5C0: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000016A5C8: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A5CC: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000016A5D0: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000016A5D8: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 00000016A5DC: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A5E4: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000016A5E8: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000016A5EC: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A5F4: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000016A5F8: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000016A5FC: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A604: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000016A608: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000016A610: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 00000016A618: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A624: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 00000016A628: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000016A630: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 00000016A63C: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A644: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016A648: BE882002
	s_cbranch_execz 62758                                      // 00000016A64C: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 00000016A650: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016A65C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016A664: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016A668: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A66C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016A670: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 00000016A678: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 00000016A684: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A688: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 00000016A68C: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016A690: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000016A698: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A6A0: BF870121
	v_add_f32_e32 v82, v82, v89                                // 00000016A6A4: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000016A6A8: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 00000016A6AC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A6B0: BF870095
	.long 0xd71c0052                                           // 00000016A6B4: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000016A6B8: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016A6BC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016A6C0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A6C8: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 00000016A6CC: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016A6D8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A6DC: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016A6E0: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 00000016A6E8: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A6EC: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000016A6F0: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 00000016A6F8: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 00000016A6FC: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A704: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000016A708: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 00000016A70C: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A714: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000016A718: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 00000016A71C: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A724: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 00000016A728: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016A730: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 00000016A738: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A744: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 00000016A748: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000016A750: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016A75C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A764: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016A768: BE882003
	s_cbranch_execz 62689                                      // 00000016A76C: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000016A770: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016A77C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016A784: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016A788: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A78C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016A790: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016A798: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 00000016A7A4: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A7A8: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 00000016A7AC: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000016A7B8: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 00000016A7BC: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016A7C0: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016A7C8: BF870293
	v_exp_f32_e32 v82, v82                                     // 00000016A7CC: 7EA44B52
	.long 0xd71c0052                                           // 00000016A7D0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016A7D4: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A7D8: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016A7DC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016A7E0: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 00000016A7E8: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A7F4: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 00000016A7F8: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016A7FC: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016A804: BF870291
	v_rcp_f32_e32 v84, v83                                     // 00000016A808: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 00000016A80C: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016A814: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 00000016A818: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 00000016A81C: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 00000016A824: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A828: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 00000016A82C: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 00000016A834: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A838: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 00000016A83C: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 00000016A844: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A84C: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016A850: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 00000016A858: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 00000016A864: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A86C: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000016A870: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016A87C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A884: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016A888: BE882004
	s_cbranch_execz 62620                                      // 00000016A88C: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3400>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000016A890: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016A89C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016A8A4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016A8A8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A8AC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016A8B0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016A8B8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000016A8C4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A8C8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000016A8CC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016A8D0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000016A8D8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016A8E0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000016A8E4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000016A8E8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000016A8EC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A8F0: BF870095
	.long 0xd71c0052                                           // 00000016A8F4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016A8F8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016A8FC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016A900: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A908: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 00000016A90C: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016A918: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A91C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016A920: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000016A928: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A92C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000016A930: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000016A938: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000016A93C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A944: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 00000016A948: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 00000016A94C: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A954: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 00000016A958: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 00000016A95C: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A964: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 00000016A968: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016A970: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 00000016A978: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A984: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000016A988: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000016A990: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016A99C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016A9A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016A9A8: BE882005
	s_cbranch_execz 62551                                      // 00000016A9AC: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x340c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 00000016A9B0: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016A9BC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016A9C4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016A9C8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A9CC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016A9D0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016A9D8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000016A9E4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016A9E8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000016A9EC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016A9F0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000016A9F8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AA00: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000016AA04: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000016AA08: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000016AA0C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA10: BF870095
	.long 0xd71c0052                                           // 00000016AA14: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016AA18: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016AA1C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016AA20: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA28: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000016AA2C: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 00000016AA34: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA3C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016AA40: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000016AA48: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA4C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000016AA50: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000016AA58: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000016AA5C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA64: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000016AA68: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 00000016AA6C: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA74: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 00000016AA78: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 00000016AA7C: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA84: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000016AA88: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016AA90: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 00000016AA98: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AAA4: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000016AAA8: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000016AAB0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016AABC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016AAC4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016AAC8: BE882006
	s_cbranch_execz 62482                                      // 00000016AACC: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3418>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 00000016AAD0: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016AADC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016AAE4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016AAE8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AAEC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016AAF0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016AAF8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000016AB04: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016AB08: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000016AB0C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016AB10: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000016AB18: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AB20: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000016AB24: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000016AB28: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000016AB2C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB30: BF870095
	.long 0xd71c0052                                           // 00000016AB34: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016AB38: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016AB3C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016AB40: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB48: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 00000016AB4C: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016AB58: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB5C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016AB60: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000016AB68: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB6C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000016AB70: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000016AB78: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000016AB7C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB84: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000016AB88: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000016AB8C: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AB94: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000016AB98: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000016AB9C: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ABA4: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000016ABA8: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016ABB0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 00000016ABB8: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ABC4: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000016ABC8: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000016ABD0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016ABDC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016ABE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016ABE8: BE882007
	s_cbranch_execz 62413                                      // 00000016ABEC: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3424>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 00000016ABF0: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000016ABFC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016AC04: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016AC08: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AC0C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016AC10: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016AC18: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000016AC24: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016AC28: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000016AC2C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016AC30: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000016AC38: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AC40: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000016AC44: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000016AC48: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000016AC4C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AC50: BF870095
	.long 0xd71c0052                                           // 00000016AC54: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016AC58: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016AC5C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016AC60: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AC68: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 00000016AC6C: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016AC78: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AC7C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000016AC80: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000016AC88: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AC8C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000016AC90: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000016AC98: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000016AC9C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ACA4: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000016ACA8: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000016ACAC: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ACB4: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000016ACB8: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000016ACBC: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ACC4: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000016ACC8: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000016ACD0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 00000016ACD8: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ACE4: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000016ACE8: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000016ACF0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000016ACFC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016AD04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016AD08: BE882000
	s_cbranch_execz 62344                                      // 00000016AD0C: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3430>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000016AD10: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000016AD1C: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000016AD20: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000016AD28: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000016AD2C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AD30: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000016AD34: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000016AD3C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000016AD48: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016AD4C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000016AD50: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000016AD54: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000016AD5C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AD64: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000016AD68: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000016AD6C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000016AD70: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AD74: BF870095
	.long 0xd71c0052                                           // 00000016AD78: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000016AD7C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000016AD80: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000016AD84: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AD8C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000016AD90: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000016AD98: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AD9C: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000016ADA0: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 00000016ADA8: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ADAC: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000016ADB0: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000016ADB8: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 00000016ADBC: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ADC4: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000016ADC8: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000016ADCC: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ADD4: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000016ADD8: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000016ADDC: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ADE4: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000016ADE8: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 00000016ADF0: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 00000016ADF8: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AE04: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 00000016AE08: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 00000016AE10: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 00000016AE1C: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016AE24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016AE28: BE882001
	s_cbranch_execz 62275                                      // 00000016AE2C: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x343c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 00000016AE30: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 00000016AE3C: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 00000016AE40: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 00000016AE48: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016AE4C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AE50: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 00000016AE54: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016AE5C: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 00000016AE64: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000016AE70: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016AE74: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 00000016AE78: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000016AE80: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AE84: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000016AE88: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000016AE8C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000016AE90: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AE94: BF870095
	.long 0xd71c0051                                           // 00000016AE98: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000016AE9C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000016AEA0: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016AEA4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AEAC: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 00000016AEB0: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016AEB8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AEBC: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 00000016AEC0: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 00000016AEC8: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AECC: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000016AED0: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000016AED8: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 00000016AEDC: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AEE4: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000016AEE8: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 00000016AEEC: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AEF4: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000016AEF8: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 00000016AEFC: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AF04: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000016AF08: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 00000016AF10: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 00000016AF18: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AF24: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 00000016AF28: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 00000016AF30: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 00000016AF3C: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016AF44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016AF48: BE882002
	s_cbranch_execz 62206                                      // 00000016AF4C: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3448>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 00000016AF50: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016AF5C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016AF64: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016AF68: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AF6C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016AF70: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 00000016AF78: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 00000016AF84: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016AF88: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 00000016AF8C: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016AF90: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 00000016AF98: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AFA0: BF870121
	v_add_f32_e32 v74, v74, v81                                // 00000016AFA4: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 00000016AFA8: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 00000016AFAC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AFB0: BF870095
	.long 0xd71c004a                                           // 00000016AFB4: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 00000016AFB8: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016AFBC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016AFC0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AFC8: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 00000016AFCC: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016AFD8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AFDC: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016AFE0: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 00000016AFE8: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AFEC: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 00000016AFF0: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 00000016AFF8: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 00000016AFFC: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B004: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000016B008: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 00000016B00C: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B014: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000016B018: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 00000016B01C: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B024: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 00000016B028: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B030: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 00000016B038: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B044: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 00000016B048: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 00000016B050: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B05C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B064: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016B068: BE882003
	s_cbranch_execz 62137                                      // 00000016B06C: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3454>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 00000016B070: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016B07C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B084: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B088: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B08C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B090: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B098: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 00000016B0A4: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B0A8: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 00000016B0AC: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 00000016B0B8: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 00000016B0BC: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B0C0: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016B0C8: BF870293
	v_exp_f32_e32 v74, v74                                     // 00000016B0CC: 7E944B4A
	.long 0xd71c004a                                           // 00000016B0D0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B0D4: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B0D8: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B0DC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B0E0: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 00000016B0E8: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B0F4: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 00000016B0F8: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016B0FC: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016B104: BF870291
	v_rcp_f32_e32 v76, v75                                     // 00000016B108: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 00000016B10C: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016B114: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 00000016B118: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 00000016B11C: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 00000016B124: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B128: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 00000016B12C: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 00000016B134: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B138: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 00000016B13C: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 00000016B144: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B14C: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B150: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 00000016B158: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 00000016B164: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B16C: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000016B170: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B17C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B184: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016B188: BE882004
	s_cbranch_execz 62068                                      // 00000016B18C: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3460>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 00000016B190: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016B19C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B1A4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B1A8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B1AC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B1B0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B1B8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000016B1C4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B1C8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000016B1CC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B1D0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000016B1D8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B1E0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000016B1E4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000016B1E8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000016B1EC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B1F0: BF870095
	.long 0xd71c004a                                           // 00000016B1F4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B1F8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B1FC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B200: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B208: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 00000016B20C: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016B218: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B21C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016B220: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000016B228: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B22C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000016B230: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000016B238: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000016B23C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B244: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 00000016B248: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 00000016B24C: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B254: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 00000016B258: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 00000016B25C: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B264: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 00000016B268: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B270: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 00000016B278: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B284: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000016B288: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000016B290: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B29C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B2A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016B2A8: BE882005
	s_cbranch_execz 61999                                      // 00000016B2AC: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x346c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 00000016B2B0: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016B2BC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B2C4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B2C8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B2CC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B2D0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B2D8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000016B2E4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B2E8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000016B2EC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B2F0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000016B2F8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B300: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000016B304: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000016B308: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000016B30C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B310: BF870095
	.long 0xd71c004a                                           // 00000016B314: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B318: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B31C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B320: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B328: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000016B32C: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 00000016B334: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B33C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016B340: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000016B348: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B34C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000016B350: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000016B358: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000016B35C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B364: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000016B368: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 00000016B36C: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B374: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 00000016B378: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 00000016B37C: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B384: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000016B388: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B390: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 00000016B398: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B3A4: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000016B3A8: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000016B3B0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B3BC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B3C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016B3C8: BE882006
	s_cbranch_execz 61930                                      // 00000016B3CC: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3478>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 00000016B3D0: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016B3DC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B3E4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B3E8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B3EC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B3F0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B3F8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000016B404: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B408: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000016B40C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B410: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000016B418: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B420: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000016B424: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000016B428: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000016B42C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B430: BF870095
	.long 0xd71c004a                                           // 00000016B434: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B438: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B43C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B440: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B448: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 00000016B44C: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016B458: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B45C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016B460: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000016B468: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B46C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000016B470: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000016B478: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000016B47C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B484: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000016B488: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 00000016B48C: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B494: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000016B498: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 00000016B49C: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B4A4: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000016B4A8: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B4B0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 00000016B4B8: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B4C4: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000016B4C8: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000016B4D0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B4DC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B4E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016B4E8: BE882007
	s_cbranch_execz 61861                                      // 00000016B4EC: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 00000016B4F0: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000016B4FC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B504: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B508: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B50C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B510: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B518: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000016B524: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B528: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000016B52C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B530: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000016B538: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B540: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000016B544: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000016B548: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000016B54C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B550: BF870095
	.long 0xd71c004a                                           // 00000016B554: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B558: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B55C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B560: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B568: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 00000016B56C: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016B578: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B57C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000016B580: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000016B588: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B58C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000016B590: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000016B598: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000016B59C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B5A4: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000016B5A8: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 00000016B5AC: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B5B4: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000016B5B8: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 00000016B5BC: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B5C4: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000016B5C8: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000016B5D0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 00000016B5D8: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B5E4: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000016B5E8: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000016B5F0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000016B5FC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B604: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016B608: BE882000
	s_cbranch_execz 61792                                      // 00000016B60C: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3490>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 00000016B610: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 00000016B61C: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 00000016B620: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000016B628: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000016B62C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B630: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000016B634: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000016B63C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000016B648: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B64C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000016B650: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000016B654: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000016B65C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B664: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000016B668: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000016B66C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000016B670: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B674: BF870095
	.long 0xd71c004a                                           // 00000016B678: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000016B67C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000016B680: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000016B684: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B68C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000016B690: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000016B698: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B69C: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 00000016B6A0: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 00000016B6A8: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B6AC: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000016B6B0: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000016B6B8: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 00000016B6BC: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B6C4: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000016B6C8: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000016B6CC: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B6D4: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000016B6D8: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000016B6DC: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B6E4: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000016B6E8: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 00000016B6F0: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 00000016B6F8: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B704: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 00000016B708: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000016B710: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 00000016B71C: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B724: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016B728: BE882001
	s_cbranch_execz 61723                                      // 00000016B72C: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x349c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000016B730: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 00000016B73C: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000016B740: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 00000016B748: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016B74C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B750: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 00000016B754: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016B75C: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 00000016B764: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000016B770: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016B774: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 00000016B778: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 00000016B780: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B784: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000016B788: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000016B78C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000016B790: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B794: BF870095
	.long 0xd71c0049                                           // 00000016B798: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000016B79C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000016B7A0: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016B7A4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B7AC: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 00000016B7B0: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016B7B8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B7BC: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 00000016B7C0: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 00000016B7C8: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B7CC: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 00000016B7D0: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000016B7D8: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 00000016B7DC: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B7E4: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 00000016B7E8: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 00000016B7EC: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B7F4: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 00000016B7F8: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 00000016B7FC: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B804: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 00000016B808: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000016B810: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 00000016B818: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B824: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 00000016B828: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000016B830: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 00000016B83C: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B844: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016B848: BE882002
	s_cbranch_execz 61654                                      // 00000016B84C: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 00000016B850: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016B85C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016B864: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016B868: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B86C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016B870: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 00000016B878: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 00000016B884: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B888: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 00000016B88C: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016B890: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 00000016B898: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B8A0: BF870121
	v_add_f32_e32 v66, v66, v73                                // 00000016B8A4: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 00000016B8A8: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 00000016B8AC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B8B0: BF870095
	.long 0xd71c0042                                           // 00000016B8B4: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 00000016B8B8: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016B8BC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016B8C0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B8C8: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 00000016B8CC: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016B8D8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B8DC: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016B8E0: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 00000016B8E8: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B8EC: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 00000016B8F0: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 00000016B8F8: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 00000016B8FC: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B904: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 00000016B908: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 00000016B90C: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B914: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 00000016B918: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 00000016B91C: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B924: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 00000016B928: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016B930: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 00000016B938: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B944: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 00000016B948: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 00000016B950: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016B95C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B964: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016B968: BE882003
	s_cbranch_execz 61585                                      // 00000016B96C: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 00000016B970: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016B97C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016B984: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016B988: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B98C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016B990: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016B998: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 00000016B9A4: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B9A8: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 00000016B9AC: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 00000016B9B8: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 00000016B9BC: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016B9C0: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016B9C8: BF870293
	v_exp_f32_e32 v66, v66                                     // 00000016B9CC: 7E844B42
	.long 0xd71c0042                                           // 00000016B9D0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016B9D4: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B9D8: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016B9DC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016B9E0: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 00000016B9E8: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B9F4: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 00000016B9F8: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016B9FC: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016BA04: BF870291
	v_rcp_f32_e32 v68, v67                                     // 00000016BA08: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 00000016BA0C: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016BA14: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 00000016BA18: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 00000016BA1C: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 00000016BA24: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BA28: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 00000016BA2C: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 00000016BA34: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BA38: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 00000016BA3C: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 00000016BA44: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BA4C: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016BA50: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 00000016BA58: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 00000016BA64: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016BA6C: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000016BA70: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016BA7C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016BA84: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016BA88: BE882004
	s_cbranch_execz 61516                                      // 00000016BA8C: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 00000016BA90: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016BA9C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016BAA4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016BAA8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BAAC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016BAB0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016BAB8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000016BAC4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016BAC8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000016BACC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016BAD0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000016BAD8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BAE0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000016BAE4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000016BAE8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000016BAEC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BAF0: BF870095
	.long 0xd71c0042                                           // 00000016BAF4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016BAF8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016BAFC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016BB00: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB08: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 00000016BB0C: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016BB18: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB1C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016BB20: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000016BB28: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB2C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000016BB30: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000016BB38: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000016BB3C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB44: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 00000016BB48: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 00000016BB4C: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB54: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 00000016BB58: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 00000016BB5C: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB64: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 00000016BB68: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016BB70: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 00000016BB78: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB84: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000016BB88: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000016BB90: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016BB9C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016BBA4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016BBA8: BE882005
	s_cbranch_execz 61447                                      // 00000016BBAC: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34cc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 00000016BBB0: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016BBBC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016BBC4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016BBC8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BBCC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016BBD0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016BBD8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000016BBE4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016BBE8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000016BBEC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016BBF0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000016BBF8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BC00: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000016BC04: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000016BC08: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000016BC0C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC10: BF870095
	.long 0xd71c0042                                           // 00000016BC14: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016BC18: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016BC1C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016BC20: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC28: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000016BC2C: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 00000016BC34: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC3C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016BC40: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000016BC48: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC4C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000016BC50: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000016BC58: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000016BC5C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC64: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000016BC68: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 00000016BC6C: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC74: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 00000016BC78: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 00000016BC7C: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BC84: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000016BC88: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016BC90: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 00000016BC98: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BCA4: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000016BCA8: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000016BCB0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016BCBC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016BCC4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016BCC8: BE882006
	s_cbranch_execz 61378                                      // 00000016BCCC: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 00000016BCD0: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016BCDC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016BCE4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016BCE8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BCEC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016BCF0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016BCF8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000016BD04: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016BD08: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000016BD0C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016BD10: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000016BD18: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BD20: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000016BD24: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000016BD28: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000016BD2C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD30: BF870095
	.long 0xd71c0042                                           // 00000016BD34: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016BD38: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016BD3C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016BD40: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD48: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 00000016BD4C: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016BD58: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD5C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016BD60: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000016BD68: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD6C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000016BD70: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000016BD78: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000016BD7C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD84: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000016BD88: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 00000016BD8C: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BD94: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000016BD98: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 00000016BD9C: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BDA4: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000016BDA8: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016BDB0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 00000016BDB8: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BDC4: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000016BDC8: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000016BDD0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016BDDC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016BDE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016BDE8: BE882007
	s_cbranch_execz 61309                                      // 00000016BDEC: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 00000016BDF0: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000016BDFC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016BE04: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016BE08: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BE0C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016BE10: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016BE18: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000016BE24: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016BE28: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000016BE2C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016BE30: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000016BE38: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BE40: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000016BE44: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000016BE48: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000016BE4C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BE50: BF870095
	.long 0xd71c0042                                           // 00000016BE54: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016BE58: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016BE5C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016BE60: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BE68: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 00000016BE6C: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016BE78: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BE7C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000016BE80: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000016BE88: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BE8C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000016BE90: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000016BE98: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000016BE9C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BEA4: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000016BEA8: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 00000016BEAC: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BEB4: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000016BEB8: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 00000016BEBC: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BEC4: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000016BEC8: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000016BED0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 00000016BED8: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BEE4: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000016BEE8: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000016BEF0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000016BEFC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016BF04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016BF08: BE882000
	s_cbranch_execz 61240                                      // 00000016BF0C: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 00000016BF10: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 00000016BF1C: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 00000016BF20: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 00000016BF28: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000016BF2C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BF30: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000016BF34: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000016BF3C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000016BF48: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016BF4C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000016BF50: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000016BF54: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000016BF5C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BF64: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000016BF68: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000016BF6C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000016BF70: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BF74: BF870095
	.long 0xd71c0042                                           // 00000016BF78: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000016BF7C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000016BF80: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000016BF84: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BF8C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000016BF90: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000016BF98: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BF9C: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 00000016BFA0: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 00000016BFA8: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BFAC: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000016BFB0: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000016BFB8: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 00000016BFBC: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BFC4: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000016BFC8: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000016BFCC: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BFD4: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000016BFD8: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000016BFDC: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BFE4: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000016BFE8: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 00000016BFF0: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 00000016BFF8: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C004: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 00000016C008: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 00000016C010: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 00000016C01C: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C024: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016C028: BE882001
	s_cbranch_execz 61171                                      // 00000016C02C: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34fc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 00000016C030: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 00000016C03C: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 00000016C040: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 00000016C048: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C04C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C050: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 00000016C054: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C05C: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 00000016C064: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000016C070: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016C074: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 00000016C078: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 00000016C080: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C084: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000016C088: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000016C08C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000016C090: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C094: BF870095
	.long 0xd71c0041                                           // 00000016C098: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000016C09C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000016C0A0: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C0A4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C0AC: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 00000016C0B0: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C0B8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C0BC: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 00000016C0C0: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 00000016C0C8: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C0CC: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000016C0D0: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000016C0D8: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 00000016C0DC: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C0E4: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000016C0E8: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 00000016C0EC: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C0F4: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000016C0F8: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 00000016C0FC: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C104: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000016C108: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 00000016C110: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 00000016C118: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C124: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 00000016C128: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 00000016C130: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 00000016C13C: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C144: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016C148: BE882002
	s_cbranch_execz 61102                                      // 00000016C14C: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3508>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 00000016C150: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C15C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C164: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C168: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C16C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C170: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 00000016C178: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 00000016C184: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C188: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 00000016C18C: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C190: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 00000016C198: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C1A0: BF870121
	v_add_f32_e32 v58, v58, v65                                // 00000016C1A4: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 00000016C1A8: 7E821142
	v_exp_f32_e32 v58, v58                                     // 00000016C1AC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C1B0: BF870095
	.long 0xd71c003a                                           // 00000016C1B4: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 00000016C1B8: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C1BC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C1C0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C1C8: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 00000016C1CC: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C1D8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C1DC: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C1E0: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 00000016C1E8: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C1EC: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 00000016C1F0: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 00000016C1F8: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 00000016C1FC: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C204: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000016C208: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 00000016C20C: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C214: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000016C218: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 00000016C21C: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C224: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 00000016C228: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C230: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 00000016C238: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C244: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 00000016C248: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 00000016C250: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C25C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C264: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016C268: BE882003
	s_cbranch_execz 61033                                      // 00000016C26C: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3514>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 00000016C270: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C27C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C284: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C288: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C28C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C290: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C298: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 00000016C2A4: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C2A8: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 00000016C2AC: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 00000016C2B8: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 00000016C2BC: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C2C0: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016C2C8: BF870293
	v_exp_f32_e32 v58, v58                                     // 00000016C2CC: 7E744B3A
	.long 0xd71c003a                                           // 00000016C2D0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C2D4: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C2D8: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C2DC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C2E0: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 00000016C2E8: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C2F4: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C2F8: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C2FC: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016C304: BF870291
	v_rcp_f32_e32 v60, v59                                     // 00000016C308: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 00000016C30C: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016C314: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 00000016C318: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 00000016C31C: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 00000016C324: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C328: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 00000016C32C: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 00000016C334: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C338: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 00000016C33C: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 00000016C344: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C34C: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C350: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 00000016C358: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 00000016C364: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016C36C: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000016C370: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C37C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C384: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016C388: BE882004
	s_cbranch_execz 60964                                      // 00000016C38C: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3520>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 00000016C390: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C39C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C3A4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C3A8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C3AC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C3B0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C3B8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000016C3C4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C3C8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000016C3CC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C3D0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000016C3D8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C3E0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000016C3E4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000016C3E8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000016C3EC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C3F0: BF870095
	.long 0xd71c003a                                           // 00000016C3F4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C3F8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C3FC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C400: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C408: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 00000016C40C: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C418: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C41C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C420: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000016C428: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C42C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000016C430: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000016C438: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000016C43C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C444: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 00000016C448: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 00000016C44C: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C454: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 00000016C458: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 00000016C45C: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C464: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 00000016C468: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C470: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 00000016C478: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C484: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000016C488: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000016C490: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C49C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C4A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016C4A8: BE882005
	s_cbranch_execz 60895                                      // 00000016C4AC: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x352c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 00000016C4B0: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C4BC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C4C4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C4C8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C4CC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C4D0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C4D8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000016C4E4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C4E8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000016C4EC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C4F0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000016C4F8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C500: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000016C504: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000016C508: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000016C50C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C510: BF870095
	.long 0xd71c003a                                           // 00000016C514: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C518: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C51C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C520: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C528: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000016C52C: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 00000016C534: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C53C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C540: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000016C548: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C54C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000016C550: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000016C558: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000016C55C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C564: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000016C568: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 00000016C56C: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C574: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 00000016C578: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 00000016C57C: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C584: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000016C588: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C590: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000016C598: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C5A4: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000016C5A8: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000016C5B0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C5BC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C5C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016C5C8: BE882006
	s_cbranch_execz 60826                                      // 00000016C5CC: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3538>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 00000016C5D0: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C5DC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C5E4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C5E8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C5EC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C5F0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C5F8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000016C604: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C608: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000016C60C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C610: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000016C618: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C620: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000016C624: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000016C628: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000016C62C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C630: BF870095
	.long 0xd71c003a                                           // 00000016C634: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C638: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C63C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C640: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C648: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 00000016C64C: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C658: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C65C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C660: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000016C668: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C66C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000016C670: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000016C678: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000016C67C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C684: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000016C688: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000016C68C: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C694: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000016C698: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000016C69C: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C6A4: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000016C6A8: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C6B0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 00000016C6B8: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C6C4: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000016C6C8: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000016C6D0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C6DC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C6E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016C6E8: BE882007
	s_cbranch_execz 60757                                      // 00000016C6EC: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3544>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 00000016C6F0: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000016C6FC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C704: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C708: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C70C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C710: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C718: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000016C724: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C728: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000016C72C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C730: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000016C738: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C740: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000016C744: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000016C748: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000016C74C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C750: BF870095
	.long 0xd71c003a                                           // 00000016C754: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C758: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C75C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C760: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C768: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 00000016C76C: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C778: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C77C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000016C780: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000016C788: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C78C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000016C790: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000016C798: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000016C79C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C7A4: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000016C7A8: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000016C7AC: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C7B4: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000016C7B8: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000016C7BC: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C7C4: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000016C7C8: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000016C7D0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 00000016C7D8: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C7E4: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000016C7E8: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000016C7F0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000016C7FC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C804: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016C808: BE882000
	s_cbranch_execz 60688                                      // 00000016C80C: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3550>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000016C810: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000016C81C: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000016C820: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 00000016C828: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000016C82C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C830: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000016C834: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000016C83C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000016C848: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016C84C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000016C850: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000016C854: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000016C85C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C864: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000016C868: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000016C86C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000016C870: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C874: BF870095
	.long 0xd71c003a                                           // 00000016C878: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000016C87C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000016C880: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000016C884: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C88C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000016C890: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000016C898: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C89C: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 00000016C8A0: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 00000016C8A8: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C8AC: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000016C8B0: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000016C8B8: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 00000016C8BC: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C8C4: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000016C8C8: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000016C8CC: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C8D4: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000016C8D8: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000016C8DC: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C8E4: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000016C8E8: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 00000016C8F0: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 00000016C8F8: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C904: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 00000016C908: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000016C910: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 00000016C91C: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016C924: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016C928: BE882001
	s_cbranch_execz 60619                                      // 00000016C92C: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x355c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000016C930: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 00000016C93C: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000016C940: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 00000016C948: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016C94C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C950: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 00000016C954: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016C95C: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 00000016C964: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000016C970: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016C974: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 00000016C978: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 00000016C980: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016C984: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000016C988: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000016C98C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000016C990: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C994: BF870095
	.long 0xd71c0039                                           // 00000016C998: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000016C99C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000016C9A0: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016C9A4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C9AC: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 00000016C9B0: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016C9B8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C9BC: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 00000016C9C0: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 00000016C9C8: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C9CC: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000016C9D0: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000016C9D8: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 00000016C9DC: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C9E4: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000016C9E8: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000016C9EC: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016C9F4: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000016C9F8: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000016C9FC: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CA04: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000016CA08: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000016CA10: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 00000016CA18: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CA24: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 00000016CA28: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000016CA30: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 00000016CA3C: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CA44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016CA48: BE882002
	s_cbranch_execz 60550                                      // 00000016CA4C: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3568>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 00000016CA50: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CA5C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016CA64: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016CA68: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CA6C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016CA70: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 00000016CA78: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 00000016CA84: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016CA88: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 00000016CA8C: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016CA90: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 00000016CA98: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CAA0: BF870121
	v_add_f32_e32 v50, v50, v57                                // 00000016CAA4: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 00000016CAA8: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 00000016CAAC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CAB0: BF870095
	.long 0xd71c0032                                           // 00000016CAB4: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 00000016CAB8: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016CABC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016CAC0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CAC8: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 00000016CACC: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016CAD8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CADC: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016CAE0: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 00000016CAE8: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CAEC: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 00000016CAF0: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 00000016CAF8: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 00000016CAFC: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CB04: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000016CB08: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 00000016CB0C: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CB14: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000016CB18: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 00000016CB1C: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CB24: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 00000016CB28: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016CB30: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 00000016CB38: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CB44: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 00000016CB48: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 00000016CB50: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016CB5C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CB64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016CB68: BE882003
	s_cbranch_execz 60481                                      // 00000016CB6C: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3574>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 00000016CB70: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CB7C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016CB84: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016CB88: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CB8C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016CB90: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016CB98: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 00000016CBA4: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CBA8: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 00000016CBAC: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 00000016CBB8: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 00000016CBBC: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016CBC0: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016CBC8: BF870293
	v_exp_f32_e32 v50, v50                                     // 00000016CBCC: 7E644B32
	.long 0xd71c0032                                           // 00000016CBD0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016CBD4: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CBD8: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016CBDC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016CBE0: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 00000016CBE8: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CBF4: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 00000016CBF8: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016CBFC: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016CC04: BF870291
	v_rcp_f32_e32 v52, v51                                     // 00000016CC08: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 00000016CC0C: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016CC14: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 00000016CC18: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 00000016CC1C: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 00000016CC24: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CC28: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 00000016CC2C: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 00000016CC34: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CC38: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 00000016CC3C: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 00000016CC44: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CC4C: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016CC50: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 00000016CC58: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 00000016CC64: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016CC6C: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000016CC70: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016CC7C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CC84: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016CC88: BE882004
	s_cbranch_execz 60412                                      // 00000016CC8C: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3580>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 00000016CC90: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CC9C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016CCA4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016CCA8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CCAC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016CCB0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016CCB8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000016CCC4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016CCC8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000016CCCC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016CCD0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000016CCD8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CCE0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000016CCE4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000016CCE8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000016CCEC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CCF0: BF870095
	.long 0xd71c0032                                           // 00000016CCF4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016CCF8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016CCFC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016CD00: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD08: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 00000016CD0C: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016CD18: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD1C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016CD20: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000016CD28: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD2C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000016CD30: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000016CD38: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000016CD3C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD44: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 00000016CD48: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 00000016CD4C: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD54: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 00000016CD58: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 00000016CD5C: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD64: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 00000016CD68: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016CD70: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 00000016CD78: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CD84: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000016CD88: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000016CD90: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016CD9C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CDA4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016CDA8: BE882005
	s_cbranch_execz 60343                                      // 00000016CDAC: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x358c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 00000016CDB0: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CDBC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016CDC4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016CDC8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CDCC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016CDD0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016CDD8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000016CDE4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016CDE8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000016CDEC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016CDF0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000016CDF8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CE00: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000016CE04: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000016CE08: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000016CE0C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE10: BF870095
	.long 0xd71c0032                                           // 00000016CE14: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016CE18: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016CE1C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016CE20: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE28: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000016CE2C: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 00000016CE34: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE3C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016CE40: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000016CE48: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE4C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000016CE50: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000016CE58: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000016CE5C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE64: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000016CE68: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 00000016CE6C: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE74: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 00000016CE78: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 00000016CE7C: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CE84: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000016CE88: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016CE90: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 00000016CE98: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CEA4: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000016CEA8: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000016CEB0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016CEBC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CEC4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016CEC8: BE882006
	s_cbranch_execz 60274                                      // 00000016CECC: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3598>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 00000016CED0: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CEDC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016CEE4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016CEE8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CEEC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016CEF0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016CEF8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000016CF04: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016CF08: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000016CF0C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016CF10: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000016CF18: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016CF20: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000016CF24: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000016CF28: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000016CF2C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF30: BF870095
	.long 0xd71c0032                                           // 00000016CF34: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016CF38: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016CF3C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016CF40: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF48: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 00000016CF4C: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016CF58: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF5C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016CF60: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000016CF68: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF6C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000016CF70: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000016CF78: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000016CF7C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF84: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000016CF88: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000016CF8C: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CF94: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000016CF98: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000016CF9C: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CFA4: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000016CFA8: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016CFB0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 00000016CFB8: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016CFC4: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000016CFC8: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000016CFD0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016CFDC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016CFE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016CFE8: BE882007
	s_cbranch_execz 60205                                      // 00000016CFEC: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 00000016CFF0: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000016CFFC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016D004: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016D008: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D00C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016D010: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016D018: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000016D024: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D028: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000016D02C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016D030: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000016D038: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D040: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000016D044: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000016D048: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000016D04C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D050: BF870095
	.long 0xd71c0032                                           // 00000016D054: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016D058: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016D05C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016D060: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D068: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 00000016D06C: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016D078: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D07C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000016D080: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000016D088: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D08C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000016D090: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000016D098: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000016D09C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D0A4: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000016D0A8: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000016D0AC: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D0B4: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000016D0B8: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000016D0BC: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D0C4: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000016D0C8: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000016D0D0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 00000016D0D8: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D0E4: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000016D0E8: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000016D0F0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000016D0FC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D104: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016D108: BE882000
	s_cbranch_execz 60136                                      // 00000016D10C: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 00000016D110: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 00000016D11C: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 00000016D120: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 00000016D128: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000016D12C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D130: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000016D134: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000016D13C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000016D148: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D14C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000016D150: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000016D154: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000016D15C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D164: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000016D168: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000016D16C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000016D170: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D174: BF870095
	.long 0xd71c0032                                           // 00000016D178: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000016D17C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000016D180: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000016D184: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D18C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000016D190: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000016D198: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D19C: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 00000016D1A0: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 00000016D1A8: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D1AC: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000016D1B0: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000016D1B8: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 00000016D1BC: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D1C4: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000016D1C8: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000016D1CC: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D1D4: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000016D1D8: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000016D1DC: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D1E4: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000016D1E8: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 00000016D1F0: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 00000016D1F8: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D204: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 00000016D208: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 00000016D210: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 00000016D21C: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D224: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016D228: BE882001
	s_cbranch_execz 60067                                      // 00000016D22C: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35bc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 00000016D230: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 00000016D23C: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 00000016D240: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 00000016D248: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D24C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D250: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 00000016D254: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D25C: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 00000016D264: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000016D270: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016D274: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 00000016D278: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 00000016D280: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D284: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000016D288: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000016D28C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000016D290: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D294: BF870095
	.long 0xd71c0031                                           // 00000016D298: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000016D29C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000016D2A0: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D2A4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D2AC: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 00000016D2B0: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D2B8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D2BC: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 00000016D2C0: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 00000016D2C8: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D2CC: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000016D2D0: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000016D2D8: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 00000016D2DC: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D2E4: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000016D2E8: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000016D2EC: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D2F4: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000016D2F8: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000016D2FC: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D304: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000016D308: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 00000016D310: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 00000016D318: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D324: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 00000016D328: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 00000016D330: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 00000016D33C: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D344: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016D348: BE882002
	s_cbranch_execz 59998                                      // 00000016D34C: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 00000016D350: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D35C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D364: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D368: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D36C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D370: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 00000016D378: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 00000016D384: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D388: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 00000016D38C: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D390: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 00000016D398: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D3A0: BF870121
	v_add_f32_e32 v42, v42, v49                                // 00000016D3A4: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 00000016D3A8: 7E621132
	v_exp_f32_e32 v42, v42                                     // 00000016D3AC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D3B0: BF870095
	.long 0xd71c002a                                           // 00000016D3B4: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 00000016D3B8: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D3BC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D3C0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D3C8: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 00000016D3CC: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D3D8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D3DC: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D3E0: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 00000016D3E8: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D3EC: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 00000016D3F0: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 00000016D3F8: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 00000016D3FC: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D404: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000016D408: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 00000016D40C: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D414: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000016D418: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 00000016D41C: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D424: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 00000016D428: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D430: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 00000016D438: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D444: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 00000016D448: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 00000016D450: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D45C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D464: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016D468: BE882003
	s_cbranch_execz 59929                                      // 00000016D46C: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 00000016D470: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D47C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D484: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D488: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D48C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D490: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016D498: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 00000016D4A4: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D4A8: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 00000016D4AC: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 00000016D4B8: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 00000016D4BC: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D4C0: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016D4C8: BF870293
	v_exp_f32_e32 v42, v42                                     // 00000016D4CC: 7E544B2A
	.long 0xd71c002a                                           // 00000016D4D0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016D4D4: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D4D8: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D4DC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D4E0: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 00000016D4E8: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D4F4: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D4F8: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D4FC: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016D504: BF870291
	v_rcp_f32_e32 v44, v43                                     // 00000016D508: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 00000016D50C: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016D514: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 00000016D518: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 00000016D51C: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 00000016D524: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D528: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 00000016D52C: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 00000016D534: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D538: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 00000016D53C: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 00000016D544: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D54C: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D550: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 00000016D558: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 00000016D564: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016D56C: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000016D570: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D57C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D584: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016D588: BE882004
	s_cbranch_execz 59860                                      // 00000016D58C: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 00000016D590: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D59C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D5A4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D5A8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D5AC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D5B0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016D5B8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000016D5C4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D5C8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000016D5CC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D5D0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000016D5D8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D5E0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000016D5E4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000016D5E8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000016D5EC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D5F0: BF870095
	.long 0xd71c002a                                           // 00000016D5F4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016D5F8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D5FC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D600: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D608: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 00000016D60C: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D618: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D61C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D620: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000016D628: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D62C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000016D630: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000016D638: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000016D63C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D644: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 00000016D648: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 00000016D64C: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D654: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 00000016D658: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 00000016D65C: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D664: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 00000016D668: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D670: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 00000016D678: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D684: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000016D688: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000016D690: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D69C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D6A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016D6A8: BE882005
	s_cbranch_execz 59791                                      // 00000016D6AC: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 00000016D6B0: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D6BC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D6C4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D6C8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D6CC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D6D0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016D6D8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000016D6E4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D6E8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000016D6EC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D6F0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000016D6F8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D700: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000016D704: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000016D708: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000016D70C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D710: BF870095
	.long 0xd71c002a                                           // 00000016D714: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016D718: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D71C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D720: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D728: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000016D72C: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 00000016D734: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D73C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D740: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000016D748: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D74C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000016D750: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000016D758: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000016D75C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D764: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000016D768: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 00000016D76C: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D774: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 00000016D778: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 00000016D77C: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D784: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000016D788: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D790: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000016D798: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D7A4: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000016D7A8: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000016D7B0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D7BC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D7C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016D7C8: BE882006
	s_cbranch_execz 59722                                      // 00000016D7CC: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 00000016D7D0: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D7DC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D7E4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D7E8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D7EC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D7F0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016D7F8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000016D804: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D808: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000016D80C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D810: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000016D818: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D820: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000016D824: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000016D828: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000016D82C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D830: BF870095
	.long 0xd71c002a                                           // 00000016D834: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016D838: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D83C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D840: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D848: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 00000016D84C: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D858: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D85C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D860: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000016D868: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D86C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000016D870: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000016D878: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000016D87C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D884: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000016D888: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000016D88C: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D894: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000016D898: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000016D89C: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D8A4: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000016D8A8: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D8B0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 00000016D8B8: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D8C4: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000016D8C8: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000016D8D0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D8DC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D8E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016D8E8: BE882007
	s_cbranch_execz 59653                                      // 00000016D8EC: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3604>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 00000016D8F0: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000016D8FC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016D904: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016D908: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D90C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016D910: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016D918: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000016D924: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016D928: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000016D92C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016D930: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000016D938: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016D940: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000016D944: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000016D948: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000016D94C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D950: BF870095
	.long 0xd71c002a                                           // 00000016D954: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016D958: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016D95C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016D960: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D968: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 00000016D96C: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016D978: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D97C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000016D980: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000016D988: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D98C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000016D990: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000016D998: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000016D99C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D9A4: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000016D9A8: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000016D9AC: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D9B4: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000016D9B8: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000016D9BC: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D9C4: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000016D9C8: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000016D9D0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 00000016D9D8: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D9E4: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000016D9E8: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000016D9F0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000016D9FC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DA04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016DA08: BE882000
	s_cbranch_execz 59584                                      // 00000016DA0C: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3610>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000016DA10: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000016DA1C: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000016DA20: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 00000016DA28: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000016DA2C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DA30: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000016DA34: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000016DA3C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000016DA48: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016DA4C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000016DA50: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000016DA54: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000016DA5C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DA64: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000016DA68: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000016DA6C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000016DA70: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DA74: BF870095
	.long 0xd71c002a                                           // 00000016DA78: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000016DA7C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000016DA80: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000016DA84: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DA8C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000016DA90: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000016DA98: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DA9C: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 00000016DAA0: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 00000016DAA8: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DAAC: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000016DAB0: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000016DAB8: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 00000016DABC: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DAC4: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000016DAC8: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000016DACC: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DAD4: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000016DAD8: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000016DADC: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DAE4: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000016DAE8: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 00000016DAF0: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 00000016DAF8: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DB04: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 00000016DB08: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000016DB10: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 00000016DB1C: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DB24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016DB28: BE882001
	s_cbranch_execz 59515                                      // 00000016DB2C: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x361c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000016DB30: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 00000016DB3C: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000016DB40: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 00000016DB48: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016DB4C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DB50: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 00000016DB54: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016DB5C: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 00000016DB64: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000016DB70: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016DB74: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 00000016DB78: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 00000016DB80: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DB84: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000016DB88: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000016DB8C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000016DB90: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DB94: BF870095
	.long 0xd71c0029                                           // 00000016DB98: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000016DB9C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000016DBA0: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016DBA4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBAC: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 00000016DBB0: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016DBB8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBBC: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 00000016DBC0: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 00000016DBC8: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBCC: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000016DBD0: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000016DBD8: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 00000016DBDC: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBE4: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 00000016DBE8: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 00000016DBEC: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBF4: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 00000016DBF8: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 00000016DBFC: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DC04: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 00000016DC08: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000016DC10: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 00000016DC18: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DC24: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 00000016DC28: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000016DC30: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 00000016DC3C: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DC44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016DC48: BE882002
	s_cbranch_execz 59446                                      // 00000016DC4C: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3628>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 00000016DC50: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016DC5C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016DC64: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016DC68: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DC6C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016DC70: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 00000016DC78: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 00000016DC84: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016DC88: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 00000016DC8C: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016DC90: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 00000016DC98: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DCA0: BF870121
	v_add_f32_e32 v34, v34, v41                                // 00000016DCA4: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 00000016DCA8: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 00000016DCAC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DCB0: BF870095
	.long 0xd71c0022                                           // 00000016DCB4: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 00000016DCB8: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016DCBC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016DCC0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DCC8: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 00000016DCCC: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016DCD8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DCDC: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016DCE0: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 00000016DCE8: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DCEC: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 00000016DCF0: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 00000016DCF8: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 00000016DCFC: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD04: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 00000016DD08: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 00000016DD0C: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD14: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 00000016DD18: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 00000016DD1C: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD24: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 00000016DD28: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016DD30: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 00000016DD38: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD44: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 00000016DD48: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 00000016DD50: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016DD5C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DD64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016DD68: BE882003
	s_cbranch_execz 59377                                      // 00000016DD6C: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3634>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 00000016DD70: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016DD7C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016DD84: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016DD88: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD8C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016DD90: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016DD98: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 00000016DDA4: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DDA8: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 00000016DDAC: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 00000016DDB8: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 00000016DDBC: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016DDC0: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016DDC8: BF870293
	v_exp_f32_e32 v34, v34                                     // 00000016DDCC: 7E444B22
	.long 0xd71c0022                                           // 00000016DDD0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016DDD4: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DDD8: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016DDDC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016DDE0: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 00000016DDE8: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DDF4: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 00000016DDF8: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016DDFC: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016DE04: BF870291
	v_rcp_f32_e32 v36, v35                                     // 00000016DE08: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 00000016DE0C: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016DE14: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 00000016DE18: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 00000016DE1C: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 00000016DE24: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DE28: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 00000016DE2C: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 00000016DE34: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DE38: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 00000016DE3C: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 00000016DE44: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DE4C: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016DE50: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 00000016DE58: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000016DE64: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016DE6C: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016DE70: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016DE7C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DE84: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016DE88: BE882004
	s_cbranch_execz 59308                                      // 00000016DE8C: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3640>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 00000016DE90: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016DE9C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016DEA4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016DEA8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DEAC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016DEB0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016DEB8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000016DEC4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016DEC8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000016DECC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016DED0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000016DED8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016DEE0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000016DEE4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000016DEE8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000016DEEC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DEF0: BF870095
	.long 0xd71c0022                                           // 00000016DEF4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016DEF8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016DEFC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016DF00: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF08: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 00000016DF0C: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016DF18: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF1C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016DF20: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000016DF28: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF2C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000016DF30: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000016DF38: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000016DF3C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF44: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 00000016DF48: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 00000016DF4C: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF54: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 00000016DF58: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 00000016DF5C: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF64: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 00000016DF68: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016DF70: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 00000016DF78: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DF84: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000016DF88: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016DF90: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016DF9C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016DFA4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016DFA8: BE882005
	s_cbranch_execz 59239                                      // 00000016DFAC: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x364c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 00000016DFB0: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016DFBC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016DFC4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016DFC8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DFCC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016DFD0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016DFD8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000016DFE4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016DFE8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000016DFEC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016DFF0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000016DFF8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E000: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000016E004: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000016E008: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000016E00C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E010: BF870095
	.long 0xd71c0022                                           // 00000016E014: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016E018: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016E01C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016E020: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E028: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000016E02C: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 00000016E034: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E03C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016E040: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000016E048: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E04C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000016E050: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000016E058: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000016E05C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E064: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000016E068: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 00000016E06C: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E074: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 00000016E078: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 00000016E07C: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E084: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000016E088: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016E090: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 00000016E098: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E0A4: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000016E0A8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016E0B0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016E0BC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E0C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016E0C8: BE882006
	s_cbranch_execz 59170                                      // 00000016E0CC: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3658>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 00000016E0D0: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016E0DC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016E0E4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016E0E8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E0EC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016E0F0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016E0F8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000016E104: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E108: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000016E10C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016E110: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000016E118: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E120: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000016E124: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000016E128: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000016E12C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E130: BF870095
	.long 0xd71c0022                                           // 00000016E134: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016E138: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016E13C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016E140: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E148: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 00000016E14C: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016E158: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E15C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016E160: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000016E168: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E16C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000016E170: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000016E178: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000016E17C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E184: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000016E188: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000016E18C: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E194: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000016E198: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000016E19C: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E1A4: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000016E1A8: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016E1B0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 00000016E1B8: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E1C4: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000016E1C8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016E1D0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016E1DC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E1E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016E1E8: BE882007
	s_cbranch_execz 59101                                      // 00000016E1EC: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3664>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 00000016E1F0: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000016E1FC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016E204: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016E208: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E20C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016E210: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016E218: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000016E224: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E228: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000016E22C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016E230: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000016E238: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E240: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000016E244: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000016E248: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000016E24C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E250: BF870095
	.long 0xd71c0022                                           // 00000016E254: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016E258: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016E25C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016E260: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E268: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 00000016E26C: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016E278: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E27C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000016E280: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000016E288: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E28C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000016E290: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000016E298: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000016E29C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E2A4: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000016E2A8: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000016E2AC: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E2B4: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000016E2B8: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000016E2BC: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E2C4: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000016E2C8: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000016E2D0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 00000016E2D8: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E2E4: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000016E2E8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016E2F0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000016E2FC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E304: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016E308: BE882000
	s_cbranch_execz 59032                                      // 00000016E30C: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3670>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 00000016E310: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000016E31C: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 00000016E320: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 00000016E328: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000016E32C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E330: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000016E334: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000016E33C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000016E348: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E34C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000016E350: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000016E354: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000016E35C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E364: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000016E368: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000016E36C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000016E370: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E374: BF870095
	.long 0xd71c0022                                           // 00000016E378: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000016E37C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000016E380: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000016E384: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E38C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000016E390: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000016E398: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E39C: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 00000016E3A0: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 00000016E3A8: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E3AC: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000016E3B0: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000016E3B8: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 00000016E3BC: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E3C4: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000016E3C8: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000016E3CC: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E3D4: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000016E3D8: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000016E3DC: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E3E4: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000016E3E8: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 00000016E3F0: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 00000016E3F8: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E404: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 00000016E408: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000016E410: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 00000016E41C: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E424: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016E428: BE882001
	s_cbranch_execz 58963                                      // 00000016E42C: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x367c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 00000016E430: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 00000016E43C: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000016E440: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 00000016E448: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E44C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E450: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 00000016E454: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016E45C: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 00000016E464: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000016E470: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016E474: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 00000016E478: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000016E480: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E484: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000016E488: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000016E48C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000016E490: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E494: BF870095
	.long 0xd71c0021                                           // 00000016E498: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000016E49C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000016E4A0: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016E4A4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E4AC: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000016E4B0: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016E4B8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E4BC: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000016E4C0: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 00000016E4C8: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E4CC: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000016E4D0: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000016E4D8: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 00000016E4DC: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E4E4: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000016E4E8: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000016E4EC: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E4F4: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000016E4F8: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000016E4FC: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E504: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000016E508: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000016E510: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000016E518: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E524: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000016E528: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000016E530: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 00000016E53C: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E544: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016E548: BE882002
	s_cbranch_execz 58894                                      // 00000016E54C: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3688>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 00000016E550: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016E55C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016E564: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E568: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E56C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016E570: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 00000016E578: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 00000016E584: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E588: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 00000016E58C: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016E590: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000016E598: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E5A0: BF870121
	v_add_f32_e32 v26, v26, v33                                // 00000016E5A4: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 00000016E5A8: 7E421122
	v_exp_f32_e32 v26, v26                                     // 00000016E5AC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E5B0: BF870095
	.long 0xd71c001a                                           // 00000016E5B4: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 00000016E5B8: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016E5BC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016E5C0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E5C8: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 00000016E5CC: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016E5D8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E5DC: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016E5E0: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 00000016E5E8: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E5EC: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000016E5F0: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 00000016E5F8: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 00000016E5FC: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E604: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000016E608: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 00000016E60C: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E614: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000016E618: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 00000016E61C: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E624: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000016E628: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016E630: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 00000016E638: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E644: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 00000016E648: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000016E650: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016E65C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E664: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016E668: BE882003
	s_cbranch_execz 58825                                      // 00000016E66C: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3694>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000016E670: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016E67C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016E684: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E688: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E68C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016E690: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016E698: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 00000016E6A4: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E6A8: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 00000016E6AC: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 00000016E6B8: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 00000016E6BC: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016E6C0: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016E6C8: BF870293
	v_exp_f32_e32 v26, v26                                     // 00000016E6CC: 7E344B1A
	.long 0xd71c001a                                           // 00000016E6D0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016E6D4: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E6D8: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016E6DC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016E6E0: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 00000016E6E8: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E6F4: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 00000016E6F8: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016E6FC: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016E704: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000016E708: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 00000016E70C: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016E714: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000016E718: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 00000016E71C: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 00000016E724: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E728: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 00000016E72C: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 00000016E734: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E738: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 00000016E73C: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 00000016E744: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E74C: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016E750: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 00000016E758: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000016E764: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016E76C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000016E770: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016E77C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E784: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016E788: BE882004
	s_cbranch_execz 58756                                      // 00000016E78C: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000016E790: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016E79C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016E7A4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E7A8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E7AC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016E7B0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016E7B8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000016E7C4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E7C8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000016E7CC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016E7D0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000016E7D8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E7E0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000016E7E4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000016E7E8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000016E7EC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E7F0: BF870095
	.long 0xd71c001a                                           // 00000016E7F4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016E7F8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016E7FC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016E800: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E808: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 00000016E80C: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016E818: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E81C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016E820: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000016E828: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E82C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000016E830: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000016E838: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000016E83C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E844: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 00000016E848: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 00000016E84C: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E854: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 00000016E858: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 00000016E85C: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E864: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 00000016E868: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016E870: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 00000016E878: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E884: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000016E888: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000016E890: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016E89C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E8A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016E8A8: BE882005
	s_cbranch_execz 58687                                      // 00000016E8AC: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ac>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 00000016E8B0: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016E8BC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016E8C4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E8C8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E8CC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016E8D0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016E8D8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000016E8E4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016E8E8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000016E8EC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016E8F0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000016E8F8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016E900: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000016E904: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000016E908: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000016E90C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E910: BF870095
	.long 0xd71c001a                                           // 00000016E914: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016E918: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016E91C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016E920: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E928: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000016E92C: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 00000016E934: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E93C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016E940: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000016E948: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E94C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000016E950: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000016E958: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000016E95C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E964: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000016E968: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 00000016E96C: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E974: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 00000016E978: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 00000016E97C: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E984: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000016E988: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016E990: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 00000016E998: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E9A4: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000016E9A8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000016E9B0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016E9BC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016E9C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016E9C8: BE882006
	s_cbranch_execz 58618                                      // 00000016E9CC: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 00000016E9D0: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016E9DC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016E9E4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016E9E8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016E9EC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016E9F0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016E9F8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000016EA04: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016EA08: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000016EA0C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016EA10: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000016EA18: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016EA20: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000016EA24: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000016EA28: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000016EA2C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA30: BF870095
	.long 0xd71c001a                                           // 00000016EA34: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016EA38: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016EA3C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016EA40: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA48: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 00000016EA4C: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016EA58: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA5C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016EA60: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000016EA68: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA6C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000016EA70: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000016EA78: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000016EA7C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA84: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000016EA88: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000016EA8C: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EA94: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000016EA98: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000016EA9C: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EAA4: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000016EAA8: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016EAB0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 00000016EAB8: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EAC4: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000016EAC8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000016EAD0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016EADC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016EAE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016EAE8: BE882007
	s_cbranch_execz 58549                                      // 00000016EAEC: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 00000016EAF0: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000016EAFC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016EB04: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016EB08: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EB0C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016EB10: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016EB18: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000016EB24: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016EB28: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000016EB2C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016EB30: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000016EB38: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016EB40: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000016EB44: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000016EB48: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000016EB4C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EB50: BF870095
	.long 0xd71c001a                                           // 00000016EB54: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016EB58: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016EB5C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016EB60: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EB68: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 00000016EB6C: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016EB78: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EB7C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000016EB80: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000016EB88: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EB8C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000016EB90: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000016EB98: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000016EB9C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EBA4: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000016EBA8: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000016EBAC: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EBB4: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000016EBB8: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000016EBBC: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EBC4: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000016EBC8: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000016EBD0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 00000016EBD8: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EBE4: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000016EBE8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000016EBF0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000016EBFC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016EC04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016EC08: BE882000
	s_cbranch_execz 58480                                      // 00000016EC0C: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000016EC10: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000016EC1C: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000016EC20: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 00000016EC28: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000016EC2C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EC30: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000016EC34: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000016EC3C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000016EC48: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016EC4C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000016EC50: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000016EC54: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000016EC5C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016EC64: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000016EC68: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000016EC6C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000016EC70: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EC74: BF870095
	.long 0xd71c001a                                           // 00000016EC78: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000016EC7C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000016EC80: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000016EC84: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EC8C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000016EC90: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000016EC98: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EC9C: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 00000016ECA0: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 00000016ECA8: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ECAC: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000016ECB0: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000016ECB8: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 00000016ECBC: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ECC4: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000016ECC8: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000016ECCC: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ECD4: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000016ECD8: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000016ECDC: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ECE4: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000016ECE8: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 00000016ECF0: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 00000016ECF8: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ED04: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 00000016ED08: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000016ED10: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 00000016ED1C: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016ED24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016ED28: BE882001
	s_cbranch_execz 58411                                      // 00000016ED2C: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36dc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 00000016ED30: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 00000016ED3C: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 00000016ED40: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 00000016ED48: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016ED4C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016ED50: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 00000016ED54: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016ED5C: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 00000016ED64: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000016ED70: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016ED74: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 00000016ED78: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000016ED80: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016ED84: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000016ED88: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000016ED8C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000016ED90: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ED94: BF870095
	.long 0xd71c0019                                           // 00000016ED98: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000016ED9C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000016EDA0: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016EDA4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EDAC: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 00000016EDB0: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016EDB8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EDBC: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 00000016EDC0: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 00000016EDC8: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EDCC: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000016EDD0: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000016EDD8: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 00000016EDDC: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EDE4: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000016EDE8: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000016EDEC: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EDF4: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000016EDF8: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000016EDFC: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EE04: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000016EE08: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 00000016EE10: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 00000016EE18: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EE24: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 00000016EE28: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000016EE30: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 00000016EE3C: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016EE44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016EE48: BE882002
	s_cbranch_execz 58342                                      // 00000016EE4C: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 00000016EE50: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016EE5C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016EE64: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016EE68: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EE6C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016EE70: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 00000016EE78: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 00000016EE84: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016EE88: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 00000016EE8C: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016EE90: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000016EE98: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016EEA0: BF870121
	v_add_f32_e32 v18, v18, v25                                // 00000016EEA4: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 00000016EEA8: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 00000016EEAC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EEB0: BF870095
	.long 0xd71c0012                                           // 00000016EEB4: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 00000016EEB8: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016EEBC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016EEC0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EEC8: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 00000016EECC: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016EED8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EEDC: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016EEE0: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 00000016EEE8: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EEEC: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 00000016EEF0: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 00000016EEF8: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 00000016EEFC: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EF04: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000016EF08: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 00000016EF0C: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EF14: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000016EF18: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 00000016EF1C: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EF24: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000016EF28: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016EF30: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 00000016EF38: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EF44: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 00000016EF48: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000016EF50: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016EF5C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016EF64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016EF68: BE882003
	s_cbranch_execz 58273                                      // 00000016EF6C: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000016EF70: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016EF7C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016EF84: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016EF88: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EF8C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016EF90: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016EF98: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 00000016EFA4: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EFA8: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 00000016EFAC: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 00000016EFB8: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 00000016EFBC: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016EFC0: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016EFC8: BF870293
	v_exp_f32_e32 v18, v18                                     // 00000016EFCC: 7E244B12
	.long 0xd71c0012                                           // 00000016EFD0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016EFD4: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016EFD8: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016EFDC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016EFE0: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 00000016EFE8: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016EFF4: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 00000016EFF8: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016EFFC: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016F004: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000016F008: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000016F00C: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016F014: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000016F018: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 00000016F01C: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 00000016F024: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F028: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 00000016F02C: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 00000016F034: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F038: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 00000016F03C: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 00000016F044: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F04C: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016F050: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 00000016F058: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000016F064: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016F06C: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000016F070: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016F07C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F084: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016F088: BE882004
	s_cbranch_execz 58204                                      // 00000016F08C: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3700>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000016F090: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016F09C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016F0A4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016F0A8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F0AC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016F0B0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016F0B8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000016F0C4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F0C8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000016F0CC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016F0D0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000016F0D8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F0E0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000016F0E4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000016F0E8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000016F0EC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F0F0: BF870095
	.long 0xd71c0012                                           // 00000016F0F4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016F0F8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016F0FC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016F100: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F108: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 00000016F10C: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016F118: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F11C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016F120: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000016F128: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F12C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000016F130: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000016F138: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000016F13C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F144: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 00000016F148: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 00000016F14C: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F154: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 00000016F158: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 00000016F15C: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F164: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 00000016F168: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016F170: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 00000016F178: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F184: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000016F188: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000016F190: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016F19C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F1A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016F1A8: BE882005
	s_cbranch_execz 58135                                      // 00000016F1AC: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x370c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 00000016F1B0: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016F1BC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016F1C4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016F1C8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F1CC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016F1D0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016F1D8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000016F1E4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F1E8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000016F1EC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016F1F0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000016F1F8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F200: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000016F204: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000016F208: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000016F20C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F210: BF870095
	.long 0xd71c0012                                           // 00000016F214: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016F218: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016F21C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016F220: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F228: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000016F22C: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 00000016F234: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F23C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016F240: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000016F248: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F24C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000016F250: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000016F258: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000016F25C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F264: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000016F268: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 00000016F26C: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F274: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 00000016F278: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 00000016F27C: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F284: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000016F288: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016F290: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 00000016F298: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F2A4: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000016F2A8: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000016F2B0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016F2BC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F2C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016F2C8: BE882006
	s_cbranch_execz 58066                                      // 00000016F2CC: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3718>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000016F2D0: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016F2DC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016F2E4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016F2E8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F2EC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016F2F0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016F2F8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000016F304: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F308: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000016F30C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016F310: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000016F318: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F320: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000016F324: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000016F328: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000016F32C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F330: BF870095
	.long 0xd71c0012                                           // 00000016F334: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016F338: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016F33C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016F340: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F348: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 00000016F34C: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016F358: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F35C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016F360: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000016F368: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F36C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000016F370: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000016F378: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000016F37C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F384: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000016F388: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000016F38C: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F394: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000016F398: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000016F39C: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F3A4: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000016F3A8: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016F3B0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 00000016F3B8: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F3C4: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000016F3C8: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000016F3D0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016F3DC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F3E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016F3E8: BE882007
	s_cbranch_execz 57997                                      // 00000016F3EC: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3724>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000016F3F0: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000016F3FC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016F404: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016F408: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F40C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016F410: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016F418: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000016F424: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F428: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000016F42C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016F430: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000016F438: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F440: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000016F444: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000016F448: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000016F44C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F450: BF870095
	.long 0xd71c0012                                           // 00000016F454: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016F458: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016F45C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016F460: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F468: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 00000016F46C: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016F478: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F47C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000016F480: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000016F488: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F48C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000016F490: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000016F498: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000016F49C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F4A4: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000016F4A8: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000016F4AC: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F4B4: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000016F4B8: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000016F4BC: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F4C4: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000016F4C8: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000016F4D0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 00000016F4D8: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F4E4: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000016F4E8: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000016F4F0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000016F4FC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F504: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016F508: BE882000
	s_cbranch_execz 57928                                      // 00000016F50C: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3730>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000016F510: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000016F51C: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000016F520: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000016F528: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000016F52C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F530: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000016F534: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000016F53C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000016F548: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F54C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000016F550: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000016F554: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000016F55C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F564: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000016F568: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000016F56C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000016F570: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F574: BF870095
	.long 0xd71c0012                                           // 00000016F578: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000016F57C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000016F580: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000016F584: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F58C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000016F590: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000016F598: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F59C: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 00000016F5A0: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 00000016F5A8: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F5AC: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000016F5B0: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000016F5B8: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 00000016F5BC: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F5C4: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000016F5C8: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000016F5CC: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F5D4: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000016F5D8: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000016F5DC: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F5E4: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000016F5E8: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000016F5F0: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 00000016F5F8: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F604: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 00000016F608: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000016F610: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 00000016F61C: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F624: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000016F628: BE882001
	s_cbranch_execz 57859                                      // 00000016F62C: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x373c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000016F630: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 00000016F63C: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 00000016F640: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 00000016F648: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016F64C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F650: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 00000016F654: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016F65C: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 00000016F664: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000016F670: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016F674: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 00000016F678: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 00000016F680: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F684: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000016F688: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000016F68C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000016F690: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F694: BF870095
	.long 0xd71c0011                                           // 00000016F698: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000016F69C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000016F6A0: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016F6A4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F6AC: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000016F6B0: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016F6B8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F6BC: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000016F6C0: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 00000016F6C8: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F6CC: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000016F6D0: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000016F6D8: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 00000016F6DC: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F6E4: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000016F6E8: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000016F6EC: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F6F4: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000016F6F8: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000016F6FC: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F704: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000016F708: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000016F710: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 00000016F718: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F724: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 00000016F728: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000016F730: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 00000016F73C: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F744: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000016F748: BE882002
	s_cbranch_execz 57790                                      // 00000016F74C: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3748>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 00000016F750: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016F75C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016F764: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016F768: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F76C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016F770: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 00000016F778: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 00000016F784: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F788: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 00000016F78C: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016F790: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 00000016F798: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F7A0: BF870121
	v_add_f32_e32 v10, v10, v17                                // 00000016F7A4: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 00000016F7A8: 7E221112
	v_exp_f32_e32 v10, v10                                     // 00000016F7AC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F7B0: BF870095
	.long 0xd71c000a                                           // 00000016F7B4: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 00000016F7B8: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016F7BC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016F7C0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F7C8: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 00000016F7CC: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016F7D8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F7DC: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016F7E0: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 00000016F7E8: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F7EC: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 00000016F7F0: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 00000016F7F8: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 00000016F7FC: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F804: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000016F808: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 00000016F80C: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F814: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000016F818: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 00000016F81C: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F824: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 00000016F828: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016F830: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 00000016F838: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F844: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 00000016F848: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000016F850: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016F85C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F864: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000016F868: BE882003
	s_cbranch_execz 57721                                      // 00000016F86C: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3754>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 00000016F870: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016F87C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016F884: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016F888: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F88C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016F890: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016F898: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 00000016F8A4: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F8A8: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 00000016F8AC: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 00000016F8B8: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 00000016F8BC: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016F8C0: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016F8C8: BF870293
	v_exp_f32_e32 v10, v10                                     // 00000016F8CC: 7E144B0A
	.long 0xd71c000a                                           // 00000016F8D0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016F8D4: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F8D8: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016F8DC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016F8E0: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 00000016F8E8: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F8F4: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016F8F8: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016F8FC: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016F904: BF870291
	v_rcp_f32_e32 v12, v11                                     // 00000016F908: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 00000016F90C: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016F914: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 00000016F918: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 00000016F91C: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 00000016F924: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F928: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 00000016F92C: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 00000016F934: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F938: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 00000016F93C: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 00000016F944: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F94C: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016F950: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 00000016F958: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000016F964: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016F96C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000016F970: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016F97C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016F984: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000016F988: BE882004
	s_cbranch_execz 57652                                      // 00000016F98C: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3760>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 00000016F990: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016F99C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016F9A4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016F9A8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F9AC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016F9B0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016F9B8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000016F9C4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016F9C8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000016F9CC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016F9D0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000016F9D8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016F9E0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000016F9E4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000016F9E8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000016F9EC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F9F0: BF870095
	.long 0xd71c000a                                           // 00000016F9F4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016F9F8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016F9FC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016FA00: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA08: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 00000016FA0C: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016FA18: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA1C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016FA20: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000016FA28: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA2C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000016FA30: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000016FA38: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000016FA3C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA44: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 00000016FA48: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 00000016FA4C: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA54: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 00000016FA58: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 00000016FA5C: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA64: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 00000016FA68: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016FA70: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 00000016FA78: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FA84: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000016FA88: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000016FA90: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016FA9C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016FAA4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000016FAA8: BE882005
	s_cbranch_execz 57583                                      // 00000016FAAC: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x376c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 00000016FAB0: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016FABC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016FAC4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016FAC8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FACC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016FAD0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016FAD8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000016FAE4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016FAE8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000016FAEC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016FAF0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000016FAF8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FB00: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000016FB04: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000016FB08: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000016FB0C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB10: BF870095
	.long 0xd71c000a                                           // 00000016FB14: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016FB18: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016FB1C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016FB20: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB28: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000016FB2C: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 00000016FB34: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB3C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016FB40: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000016FB48: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB4C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000016FB50: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000016FB58: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000016FB5C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB64: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000016FB68: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 00000016FB6C: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB74: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 00000016FB78: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 00000016FB7C: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FB84: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000016FB88: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016FB90: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 00000016FB98: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FBA4: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000016FBA8: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000016FBB0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016FBBC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016FBC4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000016FBC8: BE882006
	s_cbranch_execz 57514                                      // 00000016FBCC: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 00000016FBD0: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016FBDC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016FBE4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016FBE8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FBEC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016FBF0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016FBF8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000016FC04: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016FC08: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000016FC0C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016FC10: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000016FC18: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FC20: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000016FC24: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000016FC28: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000016FC2C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC30: BF870095
	.long 0xd71c000a                                           // 00000016FC34: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016FC38: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016FC3C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016FC40: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC48: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 00000016FC4C: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016FC58: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC5C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016FC60: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000016FC68: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC6C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000016FC70: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000016FC78: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000016FC7C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC84: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000016FC88: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000016FC8C: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FC94: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000016FC98: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000016FC9C: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FCA4: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000016FCA8: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016FCB0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 00000016FCB8: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FCC4: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000016FCC8: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000016FCD0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016FCDC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016FCE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000016FCE8: BE882007
	s_cbranch_execz 57445                                      // 00000016FCEC: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 00000016FCF0: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000016FCFC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016FD04: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016FD08: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FD0C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016FD10: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016FD18: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000016FD24: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016FD28: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000016FD2C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016FD30: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000016FD38: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FD40: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000016FD44: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000016FD48: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000016FD4C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FD50: BF870095
	.long 0xd71c000a                                           // 00000016FD54: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016FD58: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016FD5C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016FD60: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FD68: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 00000016FD6C: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016FD78: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FD7C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000016FD80: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000016FD88: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FD8C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000016FD90: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000016FD98: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000016FD9C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FDA4: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000016FDA8: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000016FDAC: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FDB4: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000016FDB8: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000016FDBC: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FDC4: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000016FDC8: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000016FDD0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 00000016FDD8: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FDE4: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000016FDE8: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000016FDF0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000016FDFC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016FE04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000016FE08: BE882000
	s_cbranch_execz 57376                                      // 00000016FE0C: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 00000016FE10: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000016FE1C: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 00000016FE20: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000016FE28: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000016FE2C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FE30: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000016FE34: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000016FE3C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000016FE48: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016FE4C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000016FE50: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000016FE54: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000016FE5C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FE64: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000016FE68: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000016FE6C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000016FE70: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FE74: BF870095
	.long 0xd71c000a                                           // 00000016FE78: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000016FE7C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000016FE80: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000016FE84: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FE8C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000016FE90: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000016FE98: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FE9C: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000016FEA0: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 00000016FEA8: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FEAC: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000016FEB0: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000016FEB8: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 00000016FEBC: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FEC4: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000016FEC8: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000016FECC: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FED4: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000016FED8: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000016FEDC: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FEE4: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000016FEE8: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 00000016FEF0: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 00000016FEF8: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FF04: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000016FF08: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000016FF10: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 00000016FF1C: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016FF24: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000016FF28: BE802001
	s_cbranch_execz 57307                                      // 00000016FF2C: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 00000016FF30: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000016FF3C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000016FF44: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000016FF48: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FF4C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000016FF50: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 00000016FF58: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 00000016FF64: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016FF68: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 00000016FF6C: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000016FF70: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000016FF78: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FF80: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 00000016FF84: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 00000016FF88: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 00000016FF8C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FF90: BF870095
	.long 0xd71c0001                                           // 00000016FF94: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000016FF98: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000016FF9C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000016FFA0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FFA8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 00000016FFAC: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000016FFB8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FFBC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000016FFC0: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 00000016FFC8: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FFCC: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 00000016FFD0: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 00000016FFD8: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000016FFDC: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FFE4: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000016FFE8: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 00000016FFEC: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FFF4: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000016FFF8: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 00000016FFFC: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170004: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000170008: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000170010: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000170018: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170024: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000170028: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000170030: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000017003C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170044: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000170048: BE802002
	s_cbranch_execz 57238                                      // 00000017004C: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000170050: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000017005C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000170064: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000170068: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017006C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000170070: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000170078: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000170084: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000170088: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000017008C: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000170090: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000170098: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001700A0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001700A4: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000001700A8: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000001700AC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001700B0: BF870095
	.long 0xd71c0001                                           // 0000001700B4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001700B8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001700BC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001700C0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001700C8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000001700CC: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001700D8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001700DC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000001700E0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000001700E8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001700EC: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000001700F0: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000001700F8: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000001700FC: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170104: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000170108: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 00000017010C: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170114: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000170118: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000017011C: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170124: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000170128: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000170130: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000170138: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170144: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000170148: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000170150: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000017015C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170164: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000170168: BE802003
	s_cbranch_execz 57169                                      // 00000017016C: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000170170: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000017017C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000170184: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000170188: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017018C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000170190: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000170198: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001701A4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001701A8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001701AC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001701B0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001701B8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001701C0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001701C4: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000001701C8: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000001701CC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001701D0: BF870095
	.long 0xd71c0001                                           // 0000001701D4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001701D8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001701DC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001701E0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001701E8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000001701EC: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001701F8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001701FC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000170200: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000170208: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017020C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000170210: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000170218: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000017021C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170224: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000170228: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 00000017022C: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170234: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000170238: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 00000017023C: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170244: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000170248: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000170250: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000170258: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170264: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000170268: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000170270: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000017027C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170284: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000170288: BE802004
	s_cbranch_execz 57100                                      // 00000017028C: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000170290: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000017029C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001702A4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001702A8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001702AC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001702B0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001702B8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001702C4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001702C8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001702CC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001702D0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001702D8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001702E0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001702E4: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000001702E8: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000001702EC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001702F0: BF870095
	.long 0xd71c0001                                           // 0000001702F4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001702F8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001702FC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000170300: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170308: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000017030C: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000170314: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017031C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000170320: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000170328: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017032C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000170330: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000170338: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000017033C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170344: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000170348: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000017034C: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170354: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000170358: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000017035C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170364: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000170368: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000170370: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 000000170378: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170384: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000170388: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000170390: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000017039C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001703A4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001703A8: BE802005
	s_cbranch_execz 57031                                      // 0000001703AC: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000001703B0: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001703BC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001703C4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001703C8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001703CC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001703D0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001703D8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001703E4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001703E8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001703EC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001703F0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001703F8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170400: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000170404: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000170408: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000017040C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170410: BF870095
	.long 0xd71c0001                                           // 000000170414: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000170418: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000017041C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000170420: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170428: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000017042C: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000170438: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017043C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000170440: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000170448: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017044C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000170450: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000170458: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000017045C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170464: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000170468: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000017046C: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170474: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000170478: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000017047C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170484: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000170488: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000170490: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 000000170498: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001704A4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001704A8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001704B0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001704BC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001704C4: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001704C8: BE802006
	s_cbranch_execz 56962                                      // 0000001704CC: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000001704D0: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001704DC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001704E4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001704E8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001704EC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001704F0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001704F8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000170504: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000170508: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000017050C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000170510: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000170518: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170520: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000170524: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000170528: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000017052C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170530: BF870095
	.long 0xd71c0001                                           // 000000170534: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000170538: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000017053C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000170540: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170548: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000017054C: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000170558: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017055C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000170560: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000170568: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017056C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000170570: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000170578: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000017057C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170584: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000170588: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000017058C: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170594: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000170598: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000017059C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001705A4: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001705A8: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001705B0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000001705B8: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001705C4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001705C8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001705D0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001705DC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001705E4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001705E8: BE802007
	s_cbranch_execz 56893                                      // 0000001705EC: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000001705F0: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001705FC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000170604: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000170608: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017060C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000170610: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000170618: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000170624: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000170628: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000017062C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000170630: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000170638: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170640: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000170644: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000170648: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000017064C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170650: BF870095
	.long 0xd71c0001                                           // 000000170654: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000170658: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000017065C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000170660: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170668: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 00000017066C: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000170678: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017067C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000170680: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000170688: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017068C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000170690: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000170698: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000017069C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001706A4: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001706A8: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001706AC: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001706B4: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001706B8: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001706BC: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001706C4: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001706C8: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001706D0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000001706D8: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001706E4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001706E8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001706F0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001706FC: DC9601E0 007C0200
	s_nop 0                                                    // 000000170704: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000170708: BFB60003
	s_endpgm                                                   // 00000017070C: BFB00000
		...

