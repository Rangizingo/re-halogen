0000000000061700 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000061700: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000061704: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000006170C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 000000061714: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 000000061718: 33380085
	s_mov_b32 s24, s3                                          // 00000006171C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000061720: BF870112
	.long 0xd44c0003                                           // 000000061724: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 000000061728: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000006172C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 000000061730: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000061734: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000006173C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000061740: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 000000061744: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000006174C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 000000061758: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000061760: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 000000061764: 160200FF 000000AB
	.long 0x7f043880                                           // 00000006176C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 000000061770: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 000000061778: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000006177C: BF8704B3
	.long 0x7e043981                                           // 000000061780: 7E043981
	v_mov_b32_e32 v142, 0                                      // 000000061784: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 000000061788: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000006178C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061790: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 000000061794: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000006179C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000617A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000617A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000617A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000617AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000617B4: BF870091
	.long 0xd73c0001                                           // 0000000617B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000617BC: 02020282
	.long 0xd7006a8d                                           // 0000000617C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000617C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000617C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000617CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000617D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000617D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000617E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000617E8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 0000000617F0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 0000000617F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000617F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000617FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 000000061800: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000061804: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000061808: BE802017
	s_cbranch_execz 9                                          // 00000006180C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 000000061810: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000061814: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061818: BF870091
	.long 0xd7006a01                                           // 00000006181C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000061820: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 000000061824: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000006182C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000061834: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000061838: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000006183C: BE940180
	s_cbranch_scc1 10                                          // 000000061840: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 000000061844: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000061848: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000006184C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000061850: BF8704A9
	s_add_i32 s1, s1, s0                                       // 000000061854: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000061858: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000006185C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000061860: BF870009
	s_add_u32 s20, s12, s0                                     // 000000061864: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000061868: 8215010D
	.long 0xd7050001                                           // 00000006186C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 000000061870: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 000000061874: 84008402
	s_add_i32 s1, s14, -1                                      // 000000061878: 8101C10E
	s_or_b32 s0, s0, 15                                        // 00000006187C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 000000061880: 333B0684
	.long 0xd7390001                                           // 000000061884: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000061888: 02020288
	s_min_i32 s0, s0, s1                                       // 00000006188C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000061890: BF870499
	s_add_i32 s0, s26, s0                                      // 000000061894: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 000000061898: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006189C: BF870091
	.long 0xd7050001                                           // 0000000618A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000618A4: 02011901
	.long 0xd7040001                                           // 0000000618A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 0000000618AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000618B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000618B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000618C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000618C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000618C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000618CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000618D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000618D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000618DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000618E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000618E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000618E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000618EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000618F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000618F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000618FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 000000061900: 7E940348
	v_mov_b32_e32 v73, v72                                     // 000000061904: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 000000061908: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000006190C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 000000061910: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 000000061914: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 000000061918: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000006191C: 7EAA0348
	.long 0xd73c008b                                           // 000000061920: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000061924: 02020281
	v_mov_b32_e32 v84, v72                                     // 000000061928: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000006192C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 000000061930: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 000000061934: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 000000061938: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000006193C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 000000061940: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 000000061944: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 000000061948: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000006194C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 000000061950: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 000000061954: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 000000061958: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000006195C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 000000061960: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 000000061964: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 000000061968: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000006196C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 000000061970: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 000000061974: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 000000061978: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000006197C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 000000061980: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 000000061984: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 000000061988: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000006198C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 000000061990: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 000000061994: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 000000061998: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000006199C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000619A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000619A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000619A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000619AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000619B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000619B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000619B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000619BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000619C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000619C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000619C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000619CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000619D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000619D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000619D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000619DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000619E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000619E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000619E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000619EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000619F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000619F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000619F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000619FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 000000061A00: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 000000061A04: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 000000061A08: 7E680348
	v_mov_b32_e32 v51, v72                                     // 000000061A0C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 000000061A10: 7E640348
	v_mov_b32_e32 v49, v72                                     // 000000061A14: 7E620348
	v_mov_b32_e32 v48, v72                                     // 000000061A18: 7E600348
	v_mov_b32_e32 v47, v72                                     // 000000061A1C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 000000061A20: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 000000061A24: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 000000061A28: 7E580348
	v_mov_b32_e32 v43, v72                                     // 000000061A2C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 000000061A30: 7E540348
	v_mov_b32_e32 v41, v72                                     // 000000061A34: 7E520348
	v_mov_b32_e32 v40, v72                                     // 000000061A38: 7E500348
	v_mov_b32_e32 v39, v72                                     // 000000061A3C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 000000061A40: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 000000061A44: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 000000061A48: 7E480348
	v_mov_b32_e32 v35, v72                                     // 000000061A4C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 000000061A50: 7E440348
	v_mov_b32_e32 v33, v72                                     // 000000061A54: 7E420348
	v_mov_b32_e32 v32, v72                                     // 000000061A58: 7E400348
	v_mov_b32_e32 v31, v72                                     // 000000061A5C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 000000061A60: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 000000061A64: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 000000061A68: 7E380348
	v_mov_b32_e32 v27, v72                                     // 000000061A6C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 000000061A70: 7E340348
	v_mov_b32_e32 v25, v72                                     // 000000061A74: 7E320348
	v_mov_b32_e32 v24, v72                                     // 000000061A78: 7E300348
	v_mov_b32_e32 v23, v72                                     // 000000061A7C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 000000061A80: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 000000061A84: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 000000061A88: 7E280348
	v_mov_b32_e32 v19, v72                                     // 000000061A8C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 000000061A90: 7E240348
	v_mov_b32_e32 v17, v72                                     // 000000061A94: 7E220348
	v_mov_b32_e32 v16, v72                                     // 000000061A98: 7E200348
	v_mov_b32_e32 v15, v72                                     // 000000061A9C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 000000061AA0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 000000061AA4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 000000061AA8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 000000061AAC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 000000061AB0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 000000061AB4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 000000061AB8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 000000061ABC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 000000061AC0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 000000061AC4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 000000061AC8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 000000061ACC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 000000061AD0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 000000061AD4: 7E020348
	s_cbranch_scc1 2920                                        // 000000061AD8: BFA20B68 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x317c>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 000000061ADC: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 000000061AE8: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 000000061AEC: 30090682
	s_lshr_b32 s1, s1, 28                                      // 000000061AF0: 85019C01
	v_add_nc_u32_e32 v160, s26, v155                           // 000000061AF4: 4B41361A
	s_add_i32 s0, s0, s1                                       // 000000061AF8: 81000100
	s_movk_i32 s1, 0x440                                       // 000000061AFC: B0010440
	s_ashr_i32 s12, s0, 4                                      // 000000061B00: 860C8400
	.long 0xd7006a8f                                           // 000000061B04: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 000000061B08: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 000000061B0C: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 000000061B14: D5207C90 01AB1902
	v_mad_u32_u24 v3, v156, s1, 0x1800                         // 000000061B1C: D60B0003 03FC039C 00001800
	s_cmp_eq_u64 s[20:21], 0                                   // 000000061B28: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 000000061B2C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000061B30: 3404029F
	v_mov_b32_e32 v129, 0                                      // 000000061B34: 7F020280
	s_cselect_b32 s13, -1, 0                                   // 000000061B38: 980D80C1
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 000000061B3C: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v165, 0x44, v131, v3                         // 000000061B48: D60B00A5 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 000000061B54: 3204049E
	v_dual_mov_b32 v8, v129 :: v_dual_lshlrev_b32 v3, 4, v0    // 000000061B58: CA220181 08020084
	s_cmp_lg_u64 s[20:21], 0                                   // 000000061B60: BF118014
	v_lshl_add_u32 v161, v154, 2, v5                           // 000000061B64: D64600A1 0415059A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000061B6C: BF870003
	v_add_nc_u32_e32 v1, v1, v2                                // 000000061B70: 4A020501
	v_add_nc_u32_e32 v2, v4, v132                              // 000000061B74: 4A050904
	s_cselect_b32 s22, -1, 0                                   // 000000061B78: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 000000061B7C: 86199F18
	s_add_i32 s15, s15, -1                                     // 000000061B80: 810FC10F
	v_ashrrev_i32_e32 v162, 2, v1                              // 000000061B84: 35440282
	v_lshlrev_b32_e32 v1, 9, v156                              // 000000061B88: 30033889
	s_lshl_b64 s[4:5], s[24:25], 9                             // 000000061B8C: 84848918
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 000000061B90: CA200181 060508FF 00009F00
	s_add_u32 s2, s6, s4                                       // 000000061B9C: 80020406
	s_delay_alu instid0(VALU_DEP_2)                            // 000000061BA0: BF870002
	v_lshl_add_u32 v166, v131, 5, v1                           // 000000061BA4: D64600A6 04050B83
	v_lshl_or_b32 v170, v154, 5, v1                            // 000000061BAC: D65600AA 04050B9A
	v_dual_mov_b32 v12, v129 :: v_dual_and_b32 v1, 0x1f0, v3   // 000000061BB4: CA240181 0C0006FF 000001F0
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v164, 0x9c00, v2// 000000061BC0: CA200181 03A404FF 00009C00
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v167, 0xa200, v2// 000000061BCC: CA200181 0AA604FF 0000A200
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 000000061BD8: 160538FF 00000210
	s_addc_u32 s1, s7, s5                                      // 000000061BE0: 82010507
	s_movk_i32 s6, 0x210                                       // 000000061BE4: B0060210
	.long 0xd70002ac                                           // 000000061BE8: D70002AC
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000061BEC: 02020202
	.long 0xd44c0000                                           // 000000061BF0: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000061BF4: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s6, 0x7b00                       // 000000061BFC: D60B009F 03FC0D9A 00007B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v168, v5, v4     // 000000061C08: CA200080 09A80905
	v_lshl_or_b32 v169, v157, 2, v5                            // 000000061C10: D65600A9 0415059D
	v_mad_u32_u24 v171, v154, 48, 0x4b00                       // 000000061C18: D60B00AB 03FD619A 00004B00
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 000000061C24: D5207CAD 00090001
	v_lshl_or_b32 v174, v154, 1, 0x4b00                        // 000000061C2C: D65600AE 03FD039A 00004B00
	v_dual_mov_b32 v14, v129 :: v_dual_add_nc_u32 v175, 0xfffffe80, v0// 000000061C38: CA200181 0EAE00FF FFFFFE80
	v_lshl_add_u32 v176, v131, 4, v2                           // 000000061C44: D64600B0 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 000000061C4C: 32000081
	v_mov_b32_e32 v1, 0                                        // 000000061C50: 7E020280
	v_dual_mov_b32 v4, v129 :: v_dual_add_nc_u32 v163, v160, v131// 000000061C54: CA200181 04A307A0
	v_mov_b32_e32 v2, v129                                     // 000000061C5C: 7E040381
	v_mov_b32_e32 v5, v129                                     // 000000061C60: 7E0A0381
	v_mov_b32_e32 v7, v129                                     // 000000061C64: 7E0E0381
	v_mov_b32_e32 v11, v129                                    // 000000061C68: 7E160381
	v_mov_b32_e32 v13, v129                                    // 000000061C6C: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 000000061C70: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 000000061C74: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 000000061C7C: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 000000061C84: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 000000061C88: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 000000061C90: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 000000061C94: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 000000061C9C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 000000061CA0: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 000000061CA8: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 000000061CB0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 000000061CB4: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 000000061CBC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 000000061CC0: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 000000061CC8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 000000061CCC: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 000000061CD4: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 000000061CDC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 000000061CE0: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 000000061CE8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 000000061CEC: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 000000061CF4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 000000061CF8: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 000000061D00: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 000000061D08: 7E560381
	v_dual_mov_b32 v44, v129 :: v_dual_mov_b32 v177, v156      // 000000061D0C: CA100181 2CB0019C
	v_mov_b32_e32 v45, v129                                    // 000000061D14: 7E5A0381
	v_dual_mov_b32 v46, v129 :: v_dual_mov_b32 v145, 0         // 000000061D18: CA100181 2E900080
	v_mov_b32_e32 v47, v129                                    // 000000061D20: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000061D24: 7E600381
	v_mov_b32_e32 v50, v129                                    // 000000061D28: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000061D2C: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000061D30: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000061D34: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 000000061D38: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000061D3C: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000061D40: 7E700381
	v_mov_b32_e32 v58, v129                                    // 000000061D44: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000061D48: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000061D4C: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000061D50: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 000000061D54: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000061D58: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000061D5C: 7E800381
	v_mov_b32_e32 v122, v129                                   // 000000061D60: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 000000061D64: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 000000061D68: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 000000061D6C: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 000000061D70: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 000000061D74: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 000000061D78: 7F000381
	v_mov_b32_e32 v114, v129                                   // 000000061D7C: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 000000061D80: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 000000061D84: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 000000061D88: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 000000061D8C: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 000000061D90: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 000000061D94: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 000000061D98: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 000000061D9C: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 000000061DA0: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 000000061DA4: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 000000061DA8: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 000000061DAC: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 000000061DB0: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 000000061DB4: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 000000061DB8: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 000000061DBC: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 000000061DC0: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 000000061DC4: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 000000061DC8: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 000000061DCC: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 000000061DD0: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 000000061DD4: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 000000061DD8: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 000000061DDC: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 000000061DE0: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 000000061DE4: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 000000061DE8: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 000000061DEC: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 000000061DF0: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 000000061DF4: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 000000061DF8: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 000000061DFC: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 000000061E00: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 000000061E04: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 000000061E08: 7E940381
	v_mov_b32_e32 v75, v129                                    // 000000061E0C: 7E960381
	v_mov_b32_e32 v76, v129                                    // 000000061E10: 7E980381
	v_mov_b32_e32 v77, v129                                    // 000000061E14: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 000000061E18: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 000000061E1C: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000061E20: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 000000061E24: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000061E28: 7E860381
	v_mov_b32_e32 v68, v129                                    // 000000061E2C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000061E30: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 000000061E34: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000061E38: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 000000061E3C: 7E900381
	s_add_u32 s6, s8, s4                                       // 000000061E40: 80060408
	s_addc_u32 s5, s9, s5                                      // 000000061E44: 82050509
	s_mov_b32 s7, 0                                            // 000000061E48: BE870080
	s_branch 117                                               // 000000061E4C: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x924>
	ds_load_b128 v[146:149], v171                              // 000000061E50: DBFC0000 920000AB
	ds_load_b128 v[150:153], v171 offset:16                    // 000000061E58: DBFC0010 960000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061E60: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 000000061E64: CC414079 1DE72582
	ds_load_b128 v[150:153], v171 offset:784                   // 000000061E6C: DBFC0310 960000AB
	ds_load_b128 v[146:149], v171 offset:768                   // 000000061E74: DBFC0300 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061E7C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 000000061E80: CC414071 1DC72582
	ds_load_b128 v[150:153], v171 offset:1552                  // 000000061E88: DBFC0610 960000AB
	ds_load_b128 v[146:149], v171 offset:1536                  // 000000061E90: DBFC0600 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061E98: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 000000061E9C: CC414069 1DA72582
	ds_load_b128 v[150:153], v171 offset:2320                  // 000000061EA4: DBFC0910 960000AB
	ds_load_b128 v[146:149], v171 offset:2304                  // 000000061EAC: DBFC0900 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061EB4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 000000061EB8: CC414061 1D872582
	ds_load_b128 v[150:153], v171 offset:3088                  // 000000061EC0: DBFC0C10 960000AB
	ds_load_b128 v[146:149], v171 offset:3072                  // 000000061EC8: DBFC0C00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061ED0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 000000061ED4: CC414059 1D672582
	ds_load_b128 v[150:153], v171 offset:3856                  // 000000061EDC: DBFC0F10 960000AB
	ds_load_b128 v[146:149], v171 offset:3840                  // 000000061EE4: DBFC0F00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061EEC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 000000061EF0: CC414051 1D472582
	ds_load_b128 v[150:153], v171 offset:4624                  // 000000061EF8: DBFC1210 960000AB
	ds_load_b128 v[146:149], v171 offset:4608                  // 000000061F00: DBFC1200 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F08: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 000000061F0C: CC414049 1D272582
	ds_load_b128 v[150:153], v171 offset:5392                  // 000000061F14: DBFC1510 960000AB
	ds_load_b128 v[146:149], v171 offset:5376                  // 000000061F1C: DBFC1500 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F24: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 000000061F28: CC414041 1D072582
	ds_load_b128 v[150:153], v171 offset:6160                  // 000000061F30: DBFC1810 960000AB
	ds_load_b128 v[146:149], v171 offset:6144                  // 000000061F38: DBFC1800 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F40: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 000000061F44: CC414039 1CE72582
	ds_load_b128 v[150:153], v171 offset:6928                  // 000000061F4C: DBFC1B10 960000AB
	ds_load_b128 v[146:149], v171 offset:6912                  // 000000061F54: DBFC1B00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F5C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 000000061F60: CC414031 1CC72582
	ds_load_b128 v[150:153], v171 offset:7696                  // 000000061F68: DBFC1E10 960000AB
	ds_load_b128 v[146:149], v171 offset:7680                  // 000000061F70: DBFC1E00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F78: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 000000061F7C: CC414029 1CA72582
	ds_load_b128 v[150:153], v171 offset:8464                  // 000000061F84: DBFC2110 960000AB
	ds_load_b128 v[146:149], v171 offset:8448                  // 000000061F8C: DBFC2100 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061F94: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 000000061F98: CC414021 1C872582
	ds_load_b128 v[150:153], v171 offset:9232                  // 000000061FA0: DBFC2410 960000AB
	ds_load_b128 v[146:149], v171 offset:9216                  // 000000061FA8: DBFC2400 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061FB0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 000000061FB4: CC414019 1C672582
	ds_load_b128 v[150:153], v171 offset:10000                 // 000000061FBC: DBFC2710 960000AB
	ds_load_b128 v[146:149], v171 offset:9984                  // 000000061FC4: DBFC2700 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061FCC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 000000061FD0: CC414011 1C472582
	ds_load_b128 v[150:153], v171 offset:10768                 // 000000061FD8: DBFC2A10 960000AB
	ds_load_b128 v[146:149], v171 offset:10752                 // 000000061FE0: DBFC2A00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000061FE8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 000000061FEC: CC414009 1C272582
	ds_load_b128 v[150:153], v171 offset:11536                 // 000000061FF4: DBFC2D10 960000AB
	ds_load_b128 v[146:149], v171 offset:11520                 // 000000061FFC: DBFC2D00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000062004: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 000000062008: CC414001 1C072582
	v_add_nc_u32_e32 v177, 16, v177                            // 000000062010: 4B636290
	s_add_i32 s1, s7, 1                                        // 000000062014: 81018107
	s_cmp_eq_u32 s7, s12                                       // 000000062018: BF060C07
	s_mov_b32 s7, s1                                           // 00000006201C: BE870001
	s_cbranch_scc1 2582                                        // 000000062020: BFA20A16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x317c>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 000000062024: 916A167E
	s_mov_b32 s1, s13                                          // 000000062028: BE81000D
	s_cbranch_vccnz 13                                         // 00000006202C: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x964>
	s_lshr_b32 s1, s7, 3                                       // 000000062030: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000062034: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000062038: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 000000062040: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 000000062044: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000006204C: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 000000062050: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062054: BF870091
	v_and_b32_e32 v130, 1, v130                                // 000000062058: 37050481
	.long 0xd44a0001                                           // 00000006205C: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000062060: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062064: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000062068: 916A017E
	s_cbranch_vccnz 65512                                      // 00000006206C: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x910>
	s_lshl_b32 s2, s7, 4                                       // 000000062070: 84028407
	s_waitcnt vmcnt(0)                                         // 000000062074: BF8903F7
	s_barrier                                                  // 000000062078: BFBD0000
	buffer_gl0_inv                                             // 00000006207C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000062084: BE812000
	s_cbranch_execz 117                                        // 000000062088: BFA50075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v177 :: v_dual_mov_b32 v131, v176     // 00000006208C: CA1001B1 828201B0
	v_mov_b32_e32 v132, v175                                   // 000000062094: 7F0803AF
	s_mov_b32 s4, 0                                            // 000000062098: BE840080
	s_nop 0                                                    // 00000006209C: BF800000
	s_nop 0                                                    // 0000000620A0: BF800000
	s_nop 0                                                    // 0000000620A4: BF800000
	s_nop 0                                                    // 0000000620A8: BF800000
	s_nop 0                                                    // 0000000620AC: BF800000
	s_nop 0                                                    // 0000000620B0: BF800000
	s_nop 0                                                    // 0000000620B4: BF800000
	s_nop 0                                                    // 0000000620B8: BF800000
	s_nop 0                                                    // 0000000620BC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000620C0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 0000000620C4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 0000000620C8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 0000000620D0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000620D4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 0000000620D8: 350F0A9F
	.long 0xd72c0088                                           // 0000000620DC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 0000000620E0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 0000000620E4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 0000000620EC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 0000000620F0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000620F4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 0000000620F8: D6550086 06230F86
	.long 0xd73c0085                                           // 000000062100: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 000000062104: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062108: BF870091
	.long 0xd7006a85                                           // 00000006210C: D7006A85
	v_cndmask_b32_e32 v1, v172, v133, vcc_lo                   // 000000062110: 02030BAC
	v_add_co_ci_u32_e64 v134, null, v173, v134, vcc_lo         // 000000062114: D5207C86 01AB0DAD
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000006211C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 000000062124: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000006212C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000062130: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 000000062134: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000006213C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000062144: 917E047E
	s_cbranch_execnz 65501                                     // 000000062148: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006214C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 000000062150: 39053402
	s_mov_b32 s4, 0                                            // 000000062154: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062158: BF870091
	v_min_i32_e32 v130, s15, v130                              // 00000006215C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 000000062160: 3509049F
	.long 0xd72c0085                                           // 000000062164: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 000000062168: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000006216C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062174: BF870093
	.long 0xd72c0084                                           // 000000062178: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 00000006217C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 000000062180: D6550083 06170983
	v_mov_b32_e32 v133, v175                                   // 000000062188: 7F0A03AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006218C: BF870122
	.long 0xd73c0083                                           // 000000062190: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000062194: 02030481
	v_mov_b32_e32 v130, v0                                     // 000000062198: 7F040300
	.long 0xd7006a83                                           // 00000006219C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 0000000621A0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000621A4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 0000000621A8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 0000000621B0: BF840001
	s_nop 0                                                    // 0000000621B4: BF800000
	s_nop 0                                                    // 0000000621B8: BF800000
	s_nop 0                                                    // 0000000621BC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000621C0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 0000000621C4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 0000000621CC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 0000000621D4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 0000000621DC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v174                         // 0000000621E0: D60B0092 06B96192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000621E8: BF870092
	.long 0xd7006a86                                           // 0000000621EC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 0000000621F0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 0000000621F4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 0000000621FC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 000000062204: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000006220C: BF8903F7
	ds_store_b16 v146, v134                                    // 000000062210: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 000000062218: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 000000062220: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 000000062228: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 000000062230: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 000000062238: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 000000062240: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 000000062248: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 000000062250: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062254: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000062258: 917E047E
	s_cbranch_execnz 65496                                     // 00000006225C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 000000062260: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062264: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000062268: BF89FC07
	s_barrier                                                  // 00000006226C: BFBD0000
	buffer_gl0_inv                                             // 000000062270: E0AC0000 00000000
	s_clause 0x3                                               // 000000062278: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000006227C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 000000062284: DC5E0000 927C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 00000006228C: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 000000062294: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v159                              // 00000006229C: DBFC0000 BA00009F
	ds_load_b128 v[190:193], v159 offset:16                    // 0000000622A4: DBFC0010 BE00009F
	v_mov_b32_e32 v136, v129                                   // 0000000622AC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000622B0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000622B4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000622B8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000622BC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000622C0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000622C4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000622C8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000622CC: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000622D0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000622D4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000622D8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000622DC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000622E0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000622E4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000622E8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000622EC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000622F0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000622F4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000622FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 000000062300: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 000000062308: DC5E0040 927C008F
	ds_load_b128 v[186:189], v159 offset:32                    // 000000062310: DBFC0020 BA00009F
	ds_load_b128 v[190:193], v159 offset:48                    // 000000062318: DBFC0030 BE00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062320: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000062324: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000006232C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 000000062330: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 000000062338: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v159 offset:80                    // 000000062340: DBFC0050 BE00009F
	ds_load_b128 v[186:189], v159 offset:64                    // 000000062348: DBFC0040 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062350: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000062354: CC414082 1E0B7592
	s_clause 0x1                                               // 00000006235C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 000000062360: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 000000062368: DC5E0080 927C008F
	ds_load_b128 v[190:193], v159 offset:112                   // 000000062370: DBFC0070 BE00009F
	ds_load_b128 v[186:189], v159 offset:96                    // 000000062378: DBFC0060 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062380: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000062384: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000006238C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 000000062390: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 000000062398: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:144                   // 0000000623A0: DBFC0090 BE00009F
	ds_load_b128 v[186:189], v159 offset:128                   // 0000000623A8: DBFC0080 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000623B0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000623B4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000623BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000623C0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000623C8: DC5E00C0 927C008F
	ds_load_b128 v[190:193], v159 offset:176                   // 0000000623D0: DBFC00B0 BE00009F
	ds_load_b128 v[186:189], v159 offset:160                   // 0000000623D8: DBFC00A0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000623E0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000623E4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000623EC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 0000000623F0: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 0000000623F8: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v159 offset:208                   // 000000062400: DBFC00D0 BE00009F
	ds_load_b128 v[186:189], v159 offset:192                   // 000000062408: DBFC00C0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062410: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000062414: CC414082 1E0B7592
	s_clause 0x1                                               // 00000006241C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 000000062420: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 000000062428: DC5E0100 927C008F
	ds_load_b128 v[190:193], v159 offset:240                   // 000000062430: DBFC00F0 BE00009F
	ds_load_b128 v[186:189], v159 offset:224                   // 000000062438: DBFC00E0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062440: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000062444: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000006244C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 000000062450: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 000000062458: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v159 offset:272                   // 000000062460: DBFC0110 BE00009F
	ds_load_b128 v[186:189], v159 offset:256                   // 000000062468: DBFC0100 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062470: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000062474: CC414082 1E0B7592
	s_clause 0x1                                               // 00000006247C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 000000062480: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 000000062488: DC5E0140 927C008F
	ds_load_b128 v[190:193], v159 offset:304                   // 000000062490: DBFC0130 BE00009F
	ds_load_b128 v[186:189], v159 offset:288                   // 000000062498: DBFC0120 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000624A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000624A4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000624AC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 0000000624B0: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 0000000624B8: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v159 offset:336                   // 0000000624C0: DBFC0150 BE00009F
	ds_load_b128 v[186:189], v159 offset:320                   // 0000000624C8: DBFC0140 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000624D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000624D4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000624DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000624E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000624E8: DC5E0180 927C008F
	ds_load_b128 v[190:193], v159 offset:368                   // 0000000624F0: DBFC0170 BE00009F
	ds_load_b128 v[186:189], v159 offset:352                   // 0000000624F8: DBFC0160 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062500: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000062504: CC414082 1E0B75B2
	ds_load_b128 v[182:185], v159 offset:400                   // 00000006250C: DBFC0190 B600009F
	ds_load_b128 v[178:181], v159 offset:384                   // 000000062514: DBFC0180 B200009F
	s_clause 0x1                                               // 00000006251C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:432    // 000000062520: DC5E01B0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:416    // 000000062528: DC5E01A0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062530: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 000000062534: CC414082 1E0B6592
	s_clause 0x1                                               // 00000006253C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 000000062540: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 000000062548: DC5E01C0 927C008F
	ds_load_b128 v[182:185], v159 offset:432                   // 000000062550: DBFC01B0 B600009F
	ds_load_b128 v[178:181], v159 offset:416                   // 000000062558: DBFC01A0 B200009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062560: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 000000062564: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v159 offset:464                   // 00000006256C: DBFC01D0 B600009F
	ds_load_b128 v[178:181], v159 offset:448                   // 000000062574: DBFC01C0 B200009F
	s_clause 0x1                                               // 00000006257C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:496    // 000000062580: DC5E01F0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:480    // 000000062588: DC5E01E0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000062590: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 000000062594: CC414082 1E0B6592
	ds_load_b128 v[150:153], v159 offset:496                   // 00000006259C: DBFC01F0 9600009F
	ds_load_b128 v[146:149], v159 offset:480                   // 0000000625A4: DBFC01E0 9200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000625AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[146:153], v[130:137]// 0000000625B0: CC414082 1E0B25BA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000625B8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000625BC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000000625C8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000625D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000625D8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000625DC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000625E4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000625F0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v161, v130, v131 offset1:34             // 0000000625FC: D8382200 008382A1
	ds_store_2addr_b32 v161, v132, v146 offset0:68 offset1:102 // 000000062604: D8386644 009284A1
	ds_store_2addr_b32 v161, v134, v135 offset0:136 offset1:170// 00000006260C: D838AA88 008786A1
	ds_store_2addr_b32 v161, v136, v137 offset0:204 offset1:238// 000000062614: D838EECC 008988A1
	s_waitcnt lgkmcnt(0)                                       // 00000006261C: BF89FC07
	s_barrier                                                  // 000000062620: BFBD0000
	buffer_gl0_inv                                             // 000000062624: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 00000006262C: BE842017
	s_cbranch_execz 359                                        // 000000062630: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 000000062634: 84088207
	s_mov_b32 s9, exec_lo                                      // 000000062638: BE89007E
	.long 0xd4c1007e                                           // 00000006263C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000062640: 02033D91
	s_cbranch_execz 44                                         // 000000062644: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 000000062648: 3525229F
	s_mov_b32 s24, 0                                           // 00000006264C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062650: BF870091
	.long 0xd73c0082                                           // 000000062654: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 000000062658: 02032282
	.long 0xd7006a82                                           // 00000006265C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 000000062660: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062664: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 000000062668: D5207C83 01AB078E
	s_branch 11                                                // 000000062670: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 000000062674: BF800000
	s_nop 0                                                    // 000000062678: BF800000
	s_nop 0                                                    // 00000006267C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 000000062680: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 000000062684: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 000000062688: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 00000006268C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000062690: BF870499
	s_or_b32 s24, s1, s24                                      // 000000062694: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000062698: 917E187E
	s_cbranch_execz 20                                         // 00000006269C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 0000000626A0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 0000000626A8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 0000000626AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 0000000626B0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 0000000626B4: BE9A206A
	s_cbranch_execz 65521                                      // 0000000626B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000626BC: CA20019E 91852281
	.long 0xd7000182                                           // 0000000626C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000626C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000626CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000626D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000626D8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 0000000626DC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 0000000626E0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000626E4: BF870009
	s_or_b32 s25, s1, s25                                      // 0000000626E8: 8C191901
	s_branch 65508                                             // 0000000626EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000626F0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 0000000626F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000626F8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000626FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 000000062700: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 000000062708: BE81007E
	.long 0xd4c1007e                                           // 00000006270C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 000000062710: 02034408
	s_cbranch_execz 62                                         // 000000062714: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 000000062718: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 000000062720: BE89007E
	.long 0xd4c1007e                                           // 000000062724: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000062728: 02033D91
	s_cbranch_execz 54                                         // 00000006272C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 000000062730: 7F040391
	s_mov_b32 s25, 0                                           // 000000062734: BE990080
	s_set_inst_prefetch_distance 0x1                           // 000000062738: BF840001
	s_branch 10                                                // 00000006273C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 000000062740: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000062744: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000062748: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000006274C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000062750: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000062754: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062758: BF870009
	s_or_b32 s24, s24, s28                                     // 00000006275C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000062760: 917E197E
	s_cbranch_execz 28                                         // 000000062764: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000062768: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000006276C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 000000062770: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000062774: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000062778: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000006277C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062780: BF870091
	.long 0xd73c0084                                           // 000000062784: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000062788: 02030682
	.long 0xd7006a84                                           // 00000006278C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 000000062790: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062794: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 000000062798: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000627A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000627A8: BF8903F7
	.long 0xd4c4007e                                           // 0000000627AC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000627B0: 02030808
	s_cbranch_execz 65506                                      // 0000000627B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000627B8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000627BC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000627C0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000627C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000627C8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000627CC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000627D0: 8C1B1D1B
	s_branch 65498                                             // 0000000627D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 0000000627D8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000627DC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 0000000627E0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 0000000627E8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000627EC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000627F0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000627F4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 0000000627F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000627FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 000000062804: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062808: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000006280C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062810: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062814: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 000000062818: 8C098108
	s_mov_b32 s1, exec_lo                                      // 00000006281C: BE81007E
	.long 0xd4c6007e                                           // 000000062820: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 000000062824: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 000000062828: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000006282C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000062834: BE813001
	s_cbranch_execz 70                                         // 000000062838: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 00000006283C: BE98007E
	.long 0xd4c1007e                                           // 000000062840: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000062844: 02033D82
	s_cbranch_execz 64                                         // 000000062848: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 00000006284C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000062850: BF840001
	s_branch 20                                                // 000000062854: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 000000062858: BF800000
	s_nop 0                                                    // 00000006285C: BF800000
	s_nop 0                                                    // 000000062860: BF800000
	s_nop 0                                                    // 000000062864: BF800000
	s_nop 0                                                    // 000000062868: BF800000
	s_nop 0                                                    // 00000006286C: BF800000
	s_nop 0                                                    // 000000062870: BF800000
	s_nop 0                                                    // 000000062874: BF800000
	s_nop 0                                                    // 000000062878: BF800000
	s_nop 0                                                    // 00000006287C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000062880: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000062884: BF870499
	s_and_b32 s29, exec_lo, s28                                // 000000062888: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000006288C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 000000062890: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 000000062894: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062898: BF870009
	s_or_b32 s25, s25, s29                                     // 00000006289C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000628A0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000628A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 0000000628A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000628AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000628B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000628B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000628B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000628BC: 3509069F
	.long 0xd73c0086                                           // 0000000628C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000628C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000628C8: BF870091
	.long 0xd7006a86                                           // 0000000628CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000628D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000628D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000628DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000628E4: BF8903F7
	.long 0xd4c6007e                                           // 0000000628E8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000628EC: 02030808
	s_cbranch_execz 65507                                      // 0000000628F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000628F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000628F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000628FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062900: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000062904: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000062908: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000006290C: 8C1C1E1C
	s_branch 65499                                             // 000000062910: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 000000062914: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000062918: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000006291C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000062920: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062924: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000062928: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000006292C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 000000062930: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006293C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000062940: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000062944: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000062948: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006294C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000062950: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062954: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062958: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 00000006295C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 000000062960: BE81007E
	.long 0xd4c6007e                                           // 000000062964: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 000000062968: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 00000006296C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000062970: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000062978: BE813001
	s_cbranch_execz 69                                         // 00000006297C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 000000062980: BE98007E
	.long 0xd4c1007e                                           // 000000062984: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000062988: 02033D82
	s_cbranch_execz 63                                         // 00000006298C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 000000062990: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000062994: BF840001
	s_branch 19                                                // 000000062998: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 00000006299C: BF800000
	s_nop 0                                                    // 0000000629A0: BF800000
	s_nop 0                                                    // 0000000629A4: BF800000
	s_nop 0                                                    // 0000000629A8: BF800000
	s_nop 0                                                    // 0000000629AC: BF800000
	s_nop 0                                                    // 0000000629B0: BF800000
	s_nop 0                                                    // 0000000629B4: BF800000
	s_nop 0                                                    // 0000000629B8: BF800000
	s_nop 0                                                    // 0000000629BC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000629C0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000629C4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000629C8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000629CC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000629D0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000629D4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000629D8: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000629DC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000629E0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000629E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 0000000629E8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000629EC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000629F0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000629F4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000629F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000629FC: 3509069F
	.long 0xd73c0086                                           // 000000062A00: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000062A04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062A08: BF870091
	.long 0xd7006a86                                           // 000000062A0C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000062A10: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000062A14: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 000000062A1C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000062A24: BF8903F7
	.long 0xd4c4007e                                           // 000000062A28: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 000000062A2C: 02030809
	s_cbranch_execz 65507                                      // 000000062A30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000062A34: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 000000062A38: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 000000062A3C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062A40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000062A44: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000062A48: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 000000062A4C: 8C1C1E1C
	s_branch 65499                                             // 000000062A50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 000000062A54: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000062A58: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 000000062A5C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000062A60: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062A64: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000062A68: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 000000062A6C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 000000062A70: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062A7C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000062A80: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000062A84: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000062A88: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062A8C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000062A90: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062A94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062A98: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 000000062A9C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 000000062AA0: BE81007E
	.long 0xd4c6007e                                           // 000000062AA4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 000000062AA8: 02034408
	s_xor_b32 s1, exec_lo, s1                                  // 000000062AAC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 000000062AB0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000062AB8: BE813001
	s_cbranch_execz 66                                         // 000000062ABC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 000000062AC0: BE89007E
	.long 0xd4c1007e                                           // 000000062AC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000062AC8: 02033D82
	s_cbranch_execz 60                                         // 000000062ACC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 000000062AD0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 000000062AD4: BF840001
	s_branch 19                                                // 000000062AD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 000000062ADC: BF800000
	s_nop 0                                                    // 000000062AE0: BF800000
	s_nop 0                                                    // 000000062AE4: BF800000
	s_nop 0                                                    // 000000062AE8: BF800000
	s_nop 0                                                    // 000000062AEC: BF800000
	s_nop 0                                                    // 000000062AF0: BF800000
	s_nop 0                                                    // 000000062AF4: BF800000
	s_nop 0                                                    // 000000062AF8: BF800000
	s_nop 0                                                    // 000000062AFC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 000000062B00: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000062B04: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000062B08: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 000000062B0C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000062B10: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000062B14: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062B18: BF870009
	s_or_b32 s24, s24, s28                                     // 000000062B1C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000062B20: 917E197E
	s_cbranch_execz 26                                         // 000000062B24: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000062B28: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 000000062B2C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000062B30: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000062B34: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062B38: BF870091
	.long 0xd73c0083                                           // 000000062B3C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000062B40: 02030482
	.long 0xd7006a83                                           // 000000062B44: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 000000062B48: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062B4C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 000000062B50: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 000000062B58: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000062B60: BF8903F7
	.long 0xd4c4007e                                           // 000000062B64: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 000000062B68: 02030608
	s_cbranch_execz 65508                                      // 000000062B6C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 000000062B70: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 000000062B74: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 000000062B78: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062B7C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000062B80: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 000000062B84: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 000000062B88: 8C1B1D1B
	s_branch 65500                                             // 000000062B8C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 000000062B90: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 000000062B94: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 000000062B98: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062B9C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 000000062BA0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 000000062BA4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 000000062BA8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062BB4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000062BB8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 000000062BBC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062BC0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000062BC4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062BC8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062BCC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000062BD0: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000062BD4: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 000000062BD8: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 000000062BE0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 000000062BE4: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000062BE8: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062BF0: BF870001
	v_readfirstlane_b32 s1, v130                               // 000000062BF4: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 000000062BF8: BF0C8001
	s_mov_b32 s1, 0                                            // 000000062BFC: BE810080
	s_cbranch_scc1 8                                           // 000000062C00: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1524>
	s_or_b32 s1, s2, 15                                        // 000000062C04: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000062C08: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v160                          // 000000062C0C: 7C874001
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 000000062C10: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 000000062C18: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 000000062C1C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000062C20: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 000000062C24: BE842003
	s_cbranch_execz 1626                                       // 000000062C28: BFA5065A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e94>
	ds_load_b32 v130, v164                                     // 000000062C2C: D8D80000 820000A4
	s_xor_b32 s1, s1, -1                                       // 000000062C34: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062C38: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000062C3C: 916A017E
	s_mov_b32 s1, -1                                           // 000000062C40: BE8100C1
	s_cbranch_vccnz 990                                        // 000000062C44: BFA403DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24c0>
	v_and_b32_e32 v131, 1, v133                                // 000000062C48: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 000000062C4C: 7C874602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000062C50: BF8704C2
	.long 0xd44a0001                                           // 000000062C54: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 000000062C58: 02030681
	s_waitcnt lgkmcnt(0)                                       // 000000062C5C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 000000062C60: 7F060382
	s_and_b32 s37, vcc_lo, s1                                  // 000000062C64: 8B25016A
	s_and_saveexec_b32 s1, s37                                 // 000000062C68: BE812025
	s_cbranch_execz 7                                          // 000000062C6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	ds_load_b32 v131, v165                                     // 000000062C70: D8D80000 830000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062C78: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 000000062C7C: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062C84: BF870001
	v_max_f32_e32 v131, v132, v131                             // 000000062C88: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062C8C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 000000062C90: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v163                          // 000000062C94: 7C834602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062C98: BF8704A2
	.long 0xd44d0001                                           // 000000062C9C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062CA0: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 000000062CA4: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 000000062CA8: BE812024
	s_cbranch_execz 7                                          // 000000062CAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v165 offset:4                            // 000000062CB0: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062CB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062CBC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062CC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062CC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062CCC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 000000062CD0: 37090A84
	s_or_b32 s1, s2, 2                                         // 000000062CD4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062CD8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062CDC: 7C874601
	.long 0xd44d0001                                           // 000000062CE0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062CE4: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 000000062CE8: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062CEC: BF870009
	s_and_saveexec_b32 s1, s35                                 // 000000062CF0: BE812023
	s_cbranch_execz 7                                          // 000000062CF4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v165 offset:8                            // 000000062CF8: D8D80008 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062D00: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062D04: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062D0C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062D10: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062D14: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 000000062D18: 37090A88
	s_or_b32 s1, s2, 3                                         // 000000062D1C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062D20: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062D24: 7C874601
	.long 0xd44d0001                                           // 000000062D28: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062D2C: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 000000062D30: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062D34: BF870009
	s_and_saveexec_b32 s1, s34                                 // 000000062D38: BE812022
	s_cbranch_execz 7                                          // 000000062D3C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x165c>
	ds_load_b32 v132, v165 offset:12                           // 000000062D40: D8D8000C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062D48: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062D4C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062D54: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062D58: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062D5C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 000000062D60: 37090A90
	s_or_b32 s1, s2, 4                                         // 000000062D64: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062D68: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062D6C: 7C874601
	.long 0xd44d0001                                           // 000000062D70: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062D74: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 000000062D78: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062D7C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000062D80: BE812021
	s_cbranch_execz 7                                          // 000000062D84: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16a4>
	ds_load_b32 v132, v165 offset:16                           // 000000062D88: D8D80010 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062D90: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062D94: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062D9C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062DA0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062DA4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 000000062DA8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 000000062DAC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062DB0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062DB4: 7C874601
	.long 0xd44d0001                                           // 000000062DB8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062DBC: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 000000062DC0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062DC4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000062DC8: BE81201F
	s_cbranch_execz 7                                          // 000000062DCC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ec>
	ds_load_b32 v132, v165 offset:20                           // 000000062DD0: D8D80014 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062DD8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062DDC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062DE4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062DE8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062DEC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 000000062DF0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 000000062DF4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062DF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062DFC: 7C874601
	.long 0xd44d0001                                           // 000000062E00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062E04: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 000000062E08: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062E0C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000062E10: BE81201E
	s_cbranch_execz 7                                          // 000000062E14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1734>
	ds_load_b32 v132, v165 offset:24                           // 000000062E18: D8D80018 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062E20: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062E24: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062E2C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062E30: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062E34: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 000000062E38: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 000000062E40: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062E44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062E48: 7C874601
	.long 0xd44d0001                                           // 000000062E4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062E50: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 000000062E54: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062E58: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000062E5C: BE81201D
	s_cbranch_execz 7                                          // 000000062E60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	ds_load_b32 v132, v165 offset:28                           // 000000062E64: D8D8001C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062E6C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062E70: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062E78: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062E7C: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062E80: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 000000062E84: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 000000062E8C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062E90: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062E94: 7C874601
	.long 0xd44d0001                                           // 000000062E98: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062E9C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 000000062EA0: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062EA4: BF870009
	s_and_saveexec_b32 s1, s28                                 // 000000062EA8: BE81201C
	s_cbranch_execz 7                                          // 000000062EAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17cc>
	ds_load_b32 v132, v165 offset:32                           // 000000062EB0: D8D80020 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062EB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062EBC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062EC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062EC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062ECC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 000000062ED0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 000000062ED8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062EDC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062EE0: 7C874601
	.long 0xd44d0001                                           // 000000062EE4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062EE8: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 000000062EEC: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062EF0: BF870009
	s_and_saveexec_b32 s1, s27                                 // 000000062EF4: BE81201B
	s_cbranch_execz 7                                          // 000000062EF8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1818>
	ds_load_b32 v132, v165 offset:36                           // 000000062EFC: D8D80024 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062F04: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062F08: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062F10: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062F14: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062F18: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 000000062F1C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 000000062F24: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062F28: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062F2C: 7C874601
	.long 0xd44d0001                                           // 000000062F30: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062F34: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 000000062F38: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062F3C: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000062F40: BE81201A
	s_cbranch_execz 7                                          // 000000062F44: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1864>
	ds_load_b32 v132, v165 offset:40                           // 000000062F48: D8D80028 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062F50: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062F54: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062F5C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062F60: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062F64: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 000000062F68: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000062F70: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062F74: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062F78: 7C874601
	.long 0xd44d0001                                           // 000000062F7C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062F80: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 000000062F84: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062F88: BF870009
	s_and_saveexec_b32 s1, s25                                 // 000000062F8C: BE812019
	s_cbranch_execz 7                                          // 000000062F90: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18b0>
	ds_load_b32 v132, v165 offset:44                           // 000000062F94: D8D8002C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062F9C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062FA0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062FA8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062FAC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062FB0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 000000062FB4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 000000062FBC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062FC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000062FC4: 7C874601
	.long 0xd44d0001                                           // 000000062FC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000062FCC: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 000000062FD0: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062FD4: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000062FD8: BE812018
	s_cbranch_execz 7                                          // 000000062FDC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18fc>
	ds_load_b32 v132, v165 offset:48                           // 000000062FE0: D8D80030 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000062FE8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000062FEC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062FF4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000062FF8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000062FFC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 000000063000: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 000000063008: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006300C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000063010: 7C874601
	.long 0xd44d0001                                           // 000000063014: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000063018: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000006301C: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000063020: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000063024: BE812009
	s_cbranch_execz 7                                          // 000000063028: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1948>
	ds_load_b32 v132, v165 offset:52                           // 00000006302C: D8D80034 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063034: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000063038: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063040: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000063044: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000063048: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000006304C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000063054: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063058: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000006305C: 7C874601
	.long 0xd44d0001                                           // 000000063060: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000063064: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 000000063068: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006306C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 000000063070: BE812008
	s_cbranch_execz 7                                          // 000000063074: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v165 offset:56                           // 000000063078: D8D80038 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063080: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000063084: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006308C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000063090: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000063094: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 000000063098: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000630A0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000630A4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 0000000630A8: 7C874602
	.long 0xd44d0001                                           // 0000000630AC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000630B0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000630B4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000630B8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000630BC: BE822001
	s_cbranch_execz 7                                          // 0000000630C0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v165 offset:60                           // 0000000630C4: D8D8003C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000630CC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000630D0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000630D8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000630DC: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000630E0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000630E4: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 0000000630EC: BE822025
	s_cbranch_execz 30                                         // 0000000630F0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a6c>
	ds_load_b32 v133, v165                                     // 0000000630F4: D8D80000 850000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000630FC: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 000000063100: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063104: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 000000063108: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 000000063110: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000006311C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063120: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 000000063124: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 000000063128: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 000000063130: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063138: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000006313C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 000000063140: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 000000063144: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063148: BF870095
	.long 0xd71c0086                                           // 00000006314C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 000000063150: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 000000063154: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000063158: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063160: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 000000063164: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006316C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063170: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 000000063174: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000006317C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v166, v134                             // 000000063188: DA840000 000086A6
	s_and_saveexec_b32 s2, s36                                 // 000000063190: BE822024
	s_cbranch_execz 30                                         // 000000063194: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b10>
	ds_load_b32 v132, v165 offset:4                            // 000000063198: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000631A0: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 0000000631A4: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000631A8: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 0000000631AC: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000631B4: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 0000000631BC: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000631C8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000631CC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000000631D0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000000631D8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000631DC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000631E0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000631E4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000631E8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000631EC: BF870095
	.long 0xd71c0086                                           // 0000000631F0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000631F4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000631F8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000631FC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063204: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 000000063208: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063210: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063214: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 000000063218: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 000000063220: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 000000063224: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 000000063230: 7F0C0280
	ds_store_b16_d16_hi v166, v136 offset:2                    // 000000063234: DA840002 000088A6
	s_and_saveexec_b32 s2, s35                                 // 00000006323C: BE822023
	s_cbranch_execz 30                                         // 000000063240: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bbc>
	ds_load_b32 v135, v165 offset:8                            // 000000063244: D8D80008 870000A5
	s_waitcnt lgkmcnt(0)                                       // 00000006324C: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 000000063250: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063254: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 000000063258: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 000000063260: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000006326C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063270: BF870221
	v_sub_f32_e32 v136, v136, v146                             // 000000063274: 09112588
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000063278: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 000000063280: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063288: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000006328C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000063290: 7F121192
	v_exp_f32_e32 v136, v136                                   // 000000063294: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063298: BF870095
	.long 0xd71c0088                                           // 00000006329C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000632A0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000632A4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000632A8: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000632B0: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000632B4: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000632BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000632C0: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000632C4: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000632CC: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v166, v136 offset:4                    // 0000000632D8: DA840004 000088A6
	s_and_saveexec_b32 s2, s34                                 // 0000000632E0: BE822022
	s_cbranch_execz 30                                         // 0000000632E4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c60>
	ds_load_b32 v134, v165 offset:12                           // 0000000632E8: D8D8000C 860000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000632F0: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 0000000632F4: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000632F8: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000632FC: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000063304: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000006330C: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 000000063318: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006331C: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 000000063320: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 000000063328: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006332C: BF870121
	v_add_f32_e32 v136, v136, v137                             // 000000063330: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000063334: 7F121192
	v_exp_f32_e32 v136, v136                                   // 000000063338: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006333C: BF870095
	.long 0xd71c0088                                           // 000000063340: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 000000063344: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 000000063348: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000006334C: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063354: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 000000063358: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063360: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063364: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 000000063368: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 000000063370: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 000000063374: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 000000063380: 7F100280
	ds_store_b16_d16_hi v166, v146 offset:6                    // 000000063384: DA840006 000092A6
	s_and_saveexec_b32 s2, s33                                 // 00000006338C: BE822021
	s_cbranch_execz 30                                         // 000000063390: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d0c>
	ds_load_b32 v137, v165 offset:16                           // 000000063394: D8D80010 890000A5
	s_waitcnt lgkmcnt(0)                                       // 00000006339C: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 0000000633A0: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000633A4: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000000633A8: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 0000000633B0: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 0000000633BC: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000633C0: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 0000000633C4: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000633C8: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 0000000633D0: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000633D8: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000000633DC: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000000633E0: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000000633E4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000633E8: BF870095
	.long 0xd71c0092                                           // 0000000633EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000000633F0: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000633F4: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000633F8: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063400: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 000000063404: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006340C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063410: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 000000063414: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000006341C: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v166, v146 offset:8                    // 000000063428: DA840008 000092A6
	s_and_saveexec_b32 s2, s31                                 // 000000063430: BE82201F
	s_cbranch_execz 30                                         // 000000063434: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1db0>
	ds_load_b32 v136, v165 offset:20                           // 000000063438: D8D80014 880000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063440: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 000000063444: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063448: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000006344C: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000063454: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 00000006345C: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000063468: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006346C: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 000000063470: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 000000063478: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006347C: BF870121
	v_add_f32_e32 v146, v146, v147                             // 000000063480: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 000000063484: 7F261194
	v_exp_f32_e32 v146, v146                                   // 000000063488: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006348C: BF870095
	.long 0xd71c0092                                           // 000000063490: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 000000063494: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000063498: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000006349C: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000634A4: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 0000000634A8: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000634B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000634B4: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 0000000634B8: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 0000000634C0: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 0000000634C4: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000000634D0: 7F240280
	ds_store_b16_d16_hi v166, v148 offset:10                   // 0000000634D4: DA84000A 000094A6
	s_and_saveexec_b32 s2, s30                                 // 0000000634DC: BE82201E
	s_cbranch_execz 30                                         // 0000000634E0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e5c>
	ds_load_b32 v147, v165 offset:24                           // 0000000634E4: D8D80018 930000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000634EC: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 0000000634F0: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000634F4: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 0000000634F8: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 000000063500: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000006350C: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063510: BF870221
	v_sub_f32_e32 v148, v148, v150                             // 000000063514: 09292D94
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 000000063518: 7C3726FF C2CE8ED0
	v_fmac_f32_e32 v149, 0x32a5705f, v147                      // 000000063520: 572B26FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063528: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000006352C: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 000000063530: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 000000063534: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063538: BF870095
	.long 0xd71c0094                                           // 00000006353C: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 000000063540: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 000000063544: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 000000063548: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063550: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 000000063554: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006355C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063560: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 000000063564: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000006356C: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v166, v148 offset:12                   // 000000063578: DA84000C 000094A6
	s_and_saveexec_b32 s2, s29                                 // 000000063580: BE82201D
	s_cbranch_execz 30                                         // 000000063584: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f00>
	ds_load_b32 v146, v165 offset:28                           // 000000063588: D8D8001C 920000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063590: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 000000063594: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063598: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 00000006359C: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000000635A4: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 0000000635AC: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000635B8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000635BC: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 0000000635C0: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 0000000635C8: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000635CC: BF870121
	v_add_f32_e32 v148, v148, v149                             // 0000000635D0: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000635D4: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 0000000635D8: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000635DC: BF870095
	.long 0xd71c0094                                           // 0000000635E0: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000635E4: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000635E8: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000000635EC: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000635F4: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 0000000635F8: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063600: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063604: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 000000063608: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 000000063610: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 000000063614: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 000000063620: 7F280280
	ds_store_b16_d16_hi v166, v150 offset:14                   // 000000063624: DA84000E 000096A6
	s_and_saveexec_b32 s2, s28                                 // 00000006362C: BE82201C
	s_cbranch_execz 30                                         // 000000063630: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fac>
	ds_load_b32 v149, v165 offset:32                           // 000000063634: D8D80020 950000A5
	s_waitcnt lgkmcnt(0)                                       // 00000006363C: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 000000063640: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063644: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 000000063648: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 000000063650: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000006365C: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063660: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 000000063664: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000063668: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 000000063670: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063678: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000006367C: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 000000063680: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 000000063684: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063688: BF870095
	.long 0xd71c0096                                           // 00000006368C: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000063690: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 000000063694: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000063698: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000636A0: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 0000000636A4: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000636AC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000636B0: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 0000000636B4: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 0000000636BC: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v166, v150 offset:16                   // 0000000636C8: DA840010 000096A6
	s_and_saveexec_b32 s2, s27                                 // 0000000636D0: BE82201B
	s_cbranch_execz 30                                         // 0000000636D4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2050>
	ds_load_b32 v148, v165 offset:36                           // 0000000636D8: D8D80024 940000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000636E0: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 0000000636E4: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000636E8: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 0000000636EC: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000000636F4: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 0000000636FC: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 000000063708: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006370C: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 000000063710: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 000000063718: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006371C: BF870121
	v_add_f32_e32 v150, v150, v151                             // 000000063720: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 000000063724: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 000000063728: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006372C: BF870095
	.long 0xd71c0096                                           // 000000063730: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000063734: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 000000063738: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000006373C: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063744: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 000000063748: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063750: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063754: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 000000063758: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 000000063760: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 000000063764: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 000000063770: 7F2C0280
	ds_store_b16_d16_hi v166, v152 offset:18                   // 000000063774: DA840012 000098A6
	s_and_saveexec_b32 s2, s26                                 // 00000006377C: BE82201A
	s_cbranch_execz 30                                         // 000000063780: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20fc>
	ds_load_b32 v151, v165 offset:40                           // 000000063784: D8D80028 970000A5
	s_waitcnt lgkmcnt(0)                                       // 00000006378C: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 000000063790: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063794: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 000000063798: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 0000000637A0: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 0000000637AC: 7F644798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000637B0: BF870221
	v_sub_f32_e32 v152, v152, v178                             // 0000000637B4: 09316598
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000637B8: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 0000000637C0: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000637C8: BF870121
	v_add_f32_e32 v152, v152, v153                             // 0000000637CC: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 0000000637D0: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 0000000637D4: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000637D8: BF870095
	.long 0xd71c0098                                           // 0000000637DC: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000000637E0: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000000637E4: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000637E8: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000637F0: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 0000000637F4: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000637FC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063800: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 000000063804: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 00000006380C: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v166, v152 offset:20                   // 000000063818: DA840014 000098A6
	s_and_saveexec_b32 s2, s25                                 // 000000063820: BE822019
	s_cbranch_execz 30                                         // 000000063824: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21a0>
	ds_load_b32 v150, v165 offset:44                           // 000000063828: D8D8002C 960000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063830: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 000000063834: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063838: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 00000006383C: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 000000063844: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 00000006384C: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 000000063858: 7F644798
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006385C: BF870112
	v_fmac_f32_e32 v153, 0x32a5705f, v150                      // 000000063860: 57332CFF 32A5705F
	v_sub_f32_e32 v152, v152, v178                             // 000000063868: 09316598
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006386C: BF870121
	v_add_f32_e32 v152, v152, v153                             // 000000063870: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 000000063874: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 000000063878: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006387C: BF870095
	.long 0xd71c0098                                           // 000000063880: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000063884: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 000000063888: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000006388C: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063894: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 000000063898: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000638A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000638A4: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 0000000638A8: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 0000000638B0: 7F320280
	v_add3_u32 v178, v150, v152, 0x7fff                        // 0000000638B4: D65500B2 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 0000000638C0: 7F300280
	ds_store_b16_d16_hi v166, v178 offset:22                   // 0000000638C4: DA840016 0000B2A6
	s_and_saveexec_b32 s2, s24                                 // 0000000638CC: BE822018
	s_cbranch_execz 30                                         // 0000000638D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x224c>
	ds_load_b32 v153, v165 offset:48                           // 0000000638D4: D8D80030 990000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000638DC: BF89FC07
	v_sub_f32_e32 v153, v153, v131                             // 0000000638E0: 09330799
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000638E4: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v153                       // 0000000638E8: 116532FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v153, -v178                    // 0000000638F0: D61300B3 86CB32FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 0000000638FC: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063900: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 000000063904: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000063908: 7C3732FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v153                      // 000000063910: 576732FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063918: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000006391C: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000063920: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000063924: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063928: BF870095
	.long 0xd71c00b2                                           // 00000006392C: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000063930: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000063934: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000063938: 7C3D32FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063940: BF870002
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 000000063944: 033364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006394C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063950: BF870091
	v_bfe_u32 v178, v153, 16, 1                                // 000000063954: D61000B2 02052199
	v_add3_u32 v178, v153, v178, 0x7fff                        // 00000006395C: D65500B2 03FF6599 00007FFF
	ds_store_b16_d16_hi v166, v178 offset:24                   // 000000063968: DA840018 0000B2A6
	s_and_saveexec_b32 s2, s9                                  // 000000063970: BE822009
	s_cbranch_execz 30                                         // 000000063974: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22f0>
	ds_load_b32 v152, v165 offset:52                           // 000000063978: D8D80034 980000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063980: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 000000063984: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063988: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v152                       // 00000006398C: 116530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000063994: 7C3730FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v152, -v178                    // 00000006399C: D61300B3 86CB30FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 0000000639A8: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000639AC: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v152                      // 0000000639B0: 576730FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 0000000639B8: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000639BC: BF870121
	v_add_f32_e32 v178, v178, v179                             // 0000000639C0: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 0000000639C4: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 0000000639C8: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000639CC: BF870095
	.long 0xd71c00b2                                           // 0000000639D0: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 0000000639D4: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 0000000639D8: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000639DC: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000639E4: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v178, vcc_lo           // 0000000639E8: 033164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000639F0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000639F4: BF870121
	v_bfe_u32 v178, v152, 16, 1                                // 0000000639F8: D61000B2 02052198
	v_mov_b32_e32 v179, 0                                      // 000000063A00: 7F660280
	v_add3_u32 v180, v152, v178, 0x7fff                        // 000000063A04: D65500B4 03FF6598 00007FFF
	v_mov_b32_e32 v178, 0                                      // 000000063A10: 7F640280
	ds_store_b16_d16_hi v166, v180 offset:26                   // 000000063A14: DA84001A 0000B4A6
	s_and_saveexec_b32 s2, s8                                  // 000000063A1C: BE822008
	s_cbranch_execz 30                                         // 000000063A20: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x239c>
	ds_load_b32 v179, v165 offset:56                           // 000000063A24: D8D80038 B30000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063A2C: BF89FC07
	v_sub_f32_e32 v179, v179, v131                             // 000000063A30: 096707B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063A34: BF870091
	v_mul_f32_e32 v180, 0x3fb8aa3b, v179                       // 000000063A38: 116966FF 3FB8AA3B
	v_fma_f32 v181, 0x3fb8aa3b, v179, -v180                    // 000000063A40: D61300B5 86D366FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 000000063A4C: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063A50: BF870221
	v_sub_f32_e32 v180, v180, v182                             // 000000063A54: 09696DB4
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v179                 // 000000063A58: 7C3766FF C2CE8ED0
	v_fmac_f32_e32 v181, 0x32a5705f, v179                      // 000000063A60: 576B66FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063A68: BF870121
	v_add_f32_e32 v180, v180, v181                             // 000000063A6C: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 000000063A70: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 000000063A74: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063A78: BF870095
	.long 0xd71c00b4                                           // 000000063A7C: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 000000063A80: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 000000063A84: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v179                 // 000000063A88: 7C3D66FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063A90: BF870002
	v_cndmask_b32_e32 v179, 0x7f800000, v180, vcc_lo           // 000000063A94: 036768FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063A9C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063AA0: BF870091
	v_bfe_u32 v180, v179, 16, 1                                // 000000063AA4: D61000B4 020521B3
	v_add3_u32 v180, v179, v180, 0x7fff                        // 000000063AAC: D65500B4 03FF69B3 00007FFF
	ds_store_b16_d16_hi v166, v180 offset:28                   // 000000063AB8: DA84001C 0000B4A6
	s_and_saveexec_b32 s2, s1                                  // 000000063AC0: BE822001
	s_cbranch_execz 30                                         // 000000063AC4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2440>
	ds_load_b32 v178, v165 offset:60                           // 000000063AC8: D8D8003C B20000A5
	s_waitcnt lgkmcnt(0)                                       // 000000063AD0: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 000000063AD4: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063AD8: BF870121
	v_mul_f32_e32 v180, 0x3fb8aa3b, v178                       // 000000063ADC: 116964FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 000000063AE4: 7C3764FF C2CE8ED0
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v180                    // 000000063AEC: D61300B5 86D364FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 000000063AF8: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063AFC: BF870112
	v_fmac_f32_e32 v181, 0x32a5705f, v178                      // 000000063B00: 576B64FF 32A5705F
	v_sub_f32_e32 v180, v180, v182                             // 000000063B08: 09696DB4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063B0C: BF870121
	v_add_f32_e32 v180, v180, v181                             // 000000063B10: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 000000063B14: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 000000063B18: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063B1C: BF870095
	.long 0xd71c00b4                                           // 000000063B20: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 000000063B24: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 000000063B28: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 000000063B2C: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063B34: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v180, vcc_lo           // 000000063B38: 036568FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000063B40: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 000000063B44: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063B48: BF870122
	v_bfe_u32 v133, v178, 16, 1                                // 000000063B4C: D6100085 020521B2
	s_mov_b32 s1, 0                                            // 000000063B54: BE810080
	v_add_f32_e32 v132, v132, v135                             // 000000063B58: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063B5C: BF870112
	v_add3_u32 v133, v178, v133, 0x7fff                        // 000000063B60: D6550085 03FF0BB2 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 000000063B6C: 07090D84
	ds_store_b16_d16_hi v166, v133 offset:30                   // 000000063B70: DA84001E 000085A6
	v_add_f32_e32 v132, v132, v137                             // 000000063B78: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063B7C: BF870091
	v_add_f32_e32 v132, v132, v136                             // 000000063B80: 07091184
	v_add_f32_e32 v132, v132, v147                             // 000000063B84: 07092784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063B88: BF870091
	v_add_f32_e32 v132, v132, v146                             // 000000063B8C: 07092584
	v_add_f32_e32 v132, v132, v149                             // 000000063B90: 07092B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063B94: BF870091
	v_add_f32_e32 v132, v132, v148                             // 000000063B98: 07092984
	v_add_f32_e32 v132, v132, v151                             // 000000063B9C: 07092F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063BA0: BF870091
	v_add_f32_e32 v132, v132, v150                             // 000000063BA4: 07092D84
	v_add_f32_e32 v132, v132, v153                             // 000000063BA8: 07093384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063BAC: BF870091
	v_add_f32_e32 v132, v132, v152                             // 000000063BB0: 07093184
	v_add_f32_e32 v132, v132, v179                             // 000000063BB4: 07096784
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063BB8: BF870001
	v_add_f32_e32 v132, v132, v178                             // 000000063BBC: 07096584
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000063BC0: 8B6A017E
	s_cbranch_vccz 584                                         // 000000063BC4: BFA30248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2de8>
	ds_load_2addr_b32 v[133:134], v165 offset1:1               // 000000063BC8: D8DC0100 850000A5
	ds_load_2addr_b32 v[135:136], v165 offset0:2 offset1:3     // 000000063BD0: D8DC0302 870000A5
	ds_load_2addr_b32 v[146:147], v165 offset0:4 offset1:5     // 000000063BD8: D8DC0504 920000A5
	ds_load_2addr_b32 v[148:149], v165 offset0:6 offset1:7     // 000000063BE0: D8DC0706 940000A5
	ds_load_2addr_b32 v[150:151], v165 offset0:8 offset1:9     // 000000063BE8: D8DC0908 960000A5
	ds_load_2addr_b32 v[152:153], v165 offset0:10 offset1:11   // 000000063BF0: D8DC0B0A 980000A5
	ds_load_2addr_b32 v[178:179], v165 offset0:12 offset1:13   // 000000063BF8: D8DC0D0C B20000A5
	ds_load_2addr_b32 v[180:181], v165 offset0:14 offset1:15   // 000000063C00: D8DC0F0E B40000A5
	.long 0xd59c4084                                           // 000000063C08: D59C4084
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 000000063C0C: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000063C10: BF8700D1
	.long 0xd59c4889                                           // 000000063C14: D59C4889
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000063C18: 02010184
	.long 0xd59c48b6                                           // 000000063C1C: D59C48B6
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000063C20: 02010184
	s_waitcnt lgkmcnt(7)                                       // 000000063C24: BF89FC77
	v_max3_f32 v131, v130, v133, v134                          // 000000063C28: D61C0083 061B0B82
	s_waitcnt lgkmcnt(6)                                       // 000000063C30: BF89FC67
	v_max3_f32 v131, v131, v135, v136                          // 000000063C34: D61C0083 06230F83
	s_waitcnt lgkmcnt(5)                                       // 000000063C3C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063C40: BF8700A1
	v_max3_f32 v131, v131, v146, v147                          // 000000063C44: D61C0083 064F2583
	s_waitcnt lgkmcnt(4)                                       // 000000063C4C: BF89FC47
	v_max3_f32 v131, v131, v148, v149                          // 000000063C50: D61C0083 06572983
	s_waitcnt lgkmcnt(3)                                       // 000000063C58: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063C5C: BF8700A1
	v_max3_f32 v131, v131, v150, v151                          // 000000063C60: D61C0083 065F2D83
	s_waitcnt lgkmcnt(2)                                       // 000000063C68: BF89FC27
	v_max3_f32 v131, v131, v152, v153                          // 000000063C6C: D61C0083 06673183
	s_waitcnt lgkmcnt(1)                                       // 000000063C74: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063C78: BF8700A1
	v_max3_f32 v131, v131, v178, v179                          // 000000063C7C: D61C0083 06CF6583
	s_waitcnt lgkmcnt(0)                                       // 000000063C84: BF89FC07
	v_max3_f32 v131, v131, v180, v181                          // 000000063C88: D61C0083 06D76983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000063C90: BF870241
	v_sub_f32_e32 v133, v133, v131                             // 000000063C94: 090B0785
	v_sub_f32_e32 v134, v134, v131                             // 000000063C98: 090D0786
	v_sub_f32_e32 v150, v150, v131                             // 000000063C9C: 092D0796
	v_sub_f32_e32 v153, v153, v131                             // 000000063CA0: 09330799
	v_dual_sub_f32 v152, v152, v131 :: v_dual_mul_f32 v183, 0x3fb8aa3b, v133// 000000063CA4: C9470798 98B70AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000063CB0: BF870004
	v_mul_f32_e32 v184, 0x3fb8aa3b, v134                       // 000000063CB4: 11710CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 000000063CBC: 7C370AFF C2CE8ED0
	v_sub_f32_e32 v151, v151, v131                             // 000000063CC4: 092F0797
	v_sub_f32_e32 v178, v178, v131                             // 000000063CC8: 096507B2
	v_fma_f32 v191, 0x3fb8aa3b, v133, -v183                    // 000000063CCC: D61300BF 86DF0AFF 3FB8AA3B
	v_rndne_f32_e32 v194, v184                                 // 000000063CD8: 7F8447B8
	v_sub_f32_e32 v149, v149, v131                             // 000000063CDC: 092B0795
	v_fma_f32 v193, 0x3fb8aa3b, v134, -v184                    // 000000063CE0: D61300C1 86E30CFF 3FB8AA3B
	v_rndne_f32_e32 v192, v183                                 // 000000063CEC: 7F8047B7
	v_dual_sub_f32 v148, v148, v131 :: v_dual_fmac_f32 v191, 0x32a5705f, v133// 000000063CF0: C9410794 94BF0AFF 32A5705F
	v_sub_f32_e32 v184, v184, v194                             // 000000063CFC: 097185B8
	v_dual_sub_f32 v136, v136, v131 :: v_dual_mul_f32 v189, 0x3fb8aa3b, v149// 000000063D00: C9470788 88BD2AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000063D0C: BF8701A4
	v_dual_sub_f32 v146, v146, v131 :: v_dual_sub_f32 v183, v183, v192// 000000063D10: C94B0792 92B781B7
	v_cvt_i32_f32_e32 v192, v192                               // 000000063D18: 7F8011C0
	v_mul_f32_e32 v185, 0x3fb8aa3b, v136                       // 000000063D1C: 117310FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063D24: BF870213
	v_dual_sub_f32 v135, v135, v131 :: v_dual_mul_f32 v188, 0x3fb8aa3b, v146// 000000063D28: C9470787 87BD24FF 3FB8AA3B
	v_add_f32_e32 v183, v183, v191                             // 000000063D34: 076F7FB7
	v_dual_sub_f32 v147, v147, v131 :: v_dual_mul_f32 v190, 0x3fb8aa3b, v148// 000000063D38: C9470793 93BF28FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063D44: BF870223
	v_mul_f32_e32 v186, 0x3fb8aa3b, v135                       // 000000063D48: 11750EFF 3FB8AA3B
	v_fma_f32 v195, 0x3fb8aa3b, v136, -v185                    // 000000063D50: D61300C3 86E710FF 3FB8AA3B
	v_exp_f32_e32 v183, v183                                   // 000000063D5C: 7F6E4BB7
	v_fma_f32 v201, 0x3fb8aa3b, v146, -v188                    // 000000063D60: D61300C9 86F324FF 3FB8AA3B
	v_rndne_f32_e32 v202, v188                                 // 000000063D6C: 7F9447BC
	v_fma_f32 v197, 0x3fb8aa3b, v135, -v186                    // 000000063D70: D61300C5 86EB0EFF 3FB8AA3B
	v_rndne_f32_e32 v198, v186                                 // 000000063D7C: 7F8C47BA
	v_fmac_f32_e32 v195, 0x32a5705f, v136                      // 000000063D80: 578710FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063D88: BF870224
	v_dual_mul_f32 v187, 0x3fb8aa3b, v147 :: v_dual_sub_f32 v188, v188, v202// 000000063D8C: C8CB26FF BBBD95BC 3FB8AA3B
	v_rndne_f32_e32 v196, v185                                 // 000000063D98: 7F8847B9
	v_sub_f32_e32 v186, v186, v198                             // 000000063D9C: 09758DBA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000063DA0: BF870005
	.long 0xd71c00b7                                           // 000000063DA4: D71C00B7
	v_cndmask_b32_e32 v1, v183, v192, vcc_lo                   // 000000063DA8: 020381B7
	v_cvt_i32_f32_e32 v194, v194                               // 000000063DAC: 7F8411C2
	v_fma_f32 v199, 0x3fb8aa3b, v147, -v187                    // 000000063DB0: D61300C7 86EF26FF 3FB8AA3B
	v_rndne_f32_e32 v200, v187                                 // 000000063DBC: 7F9047BB
	v_cvt_i32_f32_e32 v198, v198                               // 000000063DC0: 7F8C11C6
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 000000063DC4: 036F6E80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000063DC8: 7C370CFF C2CE8ED0
	v_fmac_f32_e32 v201, 0x32a5705f, v146                      // 000000063DD0: 579324FF 32A5705F
	v_fmac_f32_e32 v197, 0x32a5705f, v135                      // 000000063DD8: 578B0EFF 32A5705F
	v_rndne_f32_e32 v206, v190                                 // 000000063DE0: 7F9C47BE
	v_fmac_f32_e32 v199, 0x32a5705f, v147                      // 000000063DE4: 578F26FF 32A5705F
	v_fma_f32 v205, 0x3fb8aa3b, v148, -v190                    // 000000063DEC: D61300CD 86FB28FF 3FB8AA3B
	v_dual_add_f32 v188, v188, v201 :: v_dual_fmac_f32 v193, 0x32a5705f, v134// 000000063DF8: C90193BC BCC10CFF 32A5705F
	v_dual_add_f32 v186, v186, v197 :: v_dual_sub_f32 v185, v185, v196// 000000063E04: C90B8BBA BAB989B9
	v_cvt_i32_f32_e32 v196, v196                               // 000000063E0C: 7F8811C4
	v_sub_f32_e32 v190, v190, v206                             // 000000063E10: 097D9DBE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063E14: BF870214
	v_add_f32_e32 v184, v184, v193                             // 000000063E18: 077183B8
	v_exp_f32_e32 v186, v186                                   // 000000063E1C: 7F744BBA
	v_add_f32_e32 v185, v185, v195                             // 000000063E20: 077387B9
	v_exp_f32_e32 v188, v188                                   // 000000063E24: 7F784BBC
	v_cvt_i32_f32_e32 v202, v202                               // 000000063E28: 7F9411CA
	v_exp_f32_e32 v184, v184                                   // 000000063E2C: 7F704BB8
	v_fma_f32 v203, 0x3fb8aa3b, v149, -v189                    // 000000063E30: D61300CB 86F72AFF 3FB8AA3B
	v_exp_f32_e32 v185, v185                                   // 000000063E3C: 7F724BB9
	v_rndne_f32_e32 v204, v189                                 // 000000063E40: 7F9847BD
	v_sub_f32_e32 v180, v180, v131                             // 000000063E44: 096907B4
	.long 0xd71c00ba                                           // 000000063E48: D71C00BA
	v_cndmask_b32_e32 v1, v186, v198, vcc_lo                   // 000000063E4C: 02038DBA
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000063E50: BF870317
	.long 0xd71c00bc                                           // 000000063E54: D71C00BC
	v_cndmask_b32_e32 v1, v188, v202, vcc_lo                   // 000000063E58: 020395BC
	.long 0xd71c00b8                                           // 000000063E5C: D71C00B8
	v_cndmask_b32_e32 v1, v184, v194, vcc_lo                   // 000000063E60: 020385B8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063E64: BF870115
	.long 0xd71c00b9                                           // 000000063E68: D71C00B9
	v_cndmask_b32_e32 v1, v185, v196, vcc_lo                   // 000000063E6C: 020389B9
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 000000063E70: 03717080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000063E74: 7C3710FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000063E7C: BF870143
	v_cndmask_b32_e32 v185, 0, v185, vcc_lo                    // 000000063E80: 03737280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000063E84: 7C370EFF C2CE8ED0
	v_sub_f32_e32 v187, v187, v200                             // 000000063E8C: 097791BB
	v_cvt_i32_f32_e32 v200, v200                               // 000000063E90: 7F9011C8
	v_dual_cndmask_b32 v186, 0, v186 :: v_dual_add_f32 v187, v187, v199// 000000063E94: CA497480 BABB8FBB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 000000063E9C: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000063EA4: BF870292
	v_exp_f32_e32 v187, v187                                   // 000000063EA8: 7F764BBB
	.long 0xd71c00bb                                           // 000000063EAC: D71C00BB
	v_cndmask_b32_e32 v1, v187, v200, vcc_lo                   // 000000063EB0: 020391BB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000063EB4: BF870141
	v_cndmask_b32_e32 v187, 0, v187, vcc_lo                    // 000000063EB8: 03777680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000063EBC: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v184, vcc_lo           // 000000063EC4: 030D70FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000063ECC: 7C3D0AFF 42B17218
	.long 0xd59c0884                                           // 000000063ED4: D59C0884
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000063ED8: 02010186
	v_cndmask_b32_e32 v133, 0x7f800000, v183, vcc_lo           // 000000063EDC: 030B6EFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000063EE4: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000063EEC: BF870193
	v_and_b32_e32 v184, 1, v132                                // 000000063EF0: 37710881
	.long 0xd59c0889                                           // 000000063EF4: D59C0889
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000063EF8: 02010185
	v_cndmask_b32_e32 v135, 0x7f800000, v186, vcc_lo           // 000000063EFC: 030F74FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000063F04: 7C3D10FF 42B17218
	v_add_f32_e32 v183, v133, v134                             // 000000063F0C: 076F0D85
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063F10: BF870214
	v_and_b32_e32 v137, 1, v137                                // 000000063F14: 37131281
	.long 0xd59c08b6                                           // 000000063F18: D59C08B6
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000063F1C: 02010187
	v_cndmask_b32_e32 v136, 0x7f800000, v185, vcc_lo           // 000000063F20: 031172FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 000000063F28: 7C3724FF C2CE8ED0
	v_fmac_f32_e32 v203, 0x32a5705f, v149                      // 000000063F30: 57972AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000063F38: BF870004
	v_dual_add_f32 v183, v183, v135 :: v_dual_and_b32 v182, 1, v182// 000000063F3C: C9250FB7 B7B76C81
	v_fmac_f32_e32 v205, 0x32a5705f, v148                      // 000000063F44: 579B28FF 32A5705F
	v_sub_f32_e32 v189, v189, v204                             // 000000063F4C: 097B99BD
	v_cndmask_b32_e32 v185, 0, v188, vcc_lo                    // 000000063F50: 03737880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 000000063F54: 7C3D24FF 42B17218
	.long 0xd59c0884                                           // 000000063F5C: D59C0884
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000063F60: 02010188
	v_add3_u32 v137, v133, v137, 0x7fff                        // 000000063F64: D6550089 03FF1385 00007FFF
	v_add3_u32 v133, v134, v184, 0x7fff                        // 000000063F70: D6550085 03FF7186 00007FFF
	v_add3_u32 v182, v135, v182, 0x7fff                        // 000000063F7C: D65500B6 03FF6D87 00007FFF
	v_cndmask_b32_e32 v135, 0x7f800000, v185, vcc_lo           // 000000063F88: 030F72FF 7F800000
	v_add_f32_e32 v184, v190, v205                             // 000000063F90: 07719BBE
	v_add_f32_e32 v146, v189, v203                             // 000000063F94: 072597BD
	v_and_b32_e32 v186, 1, v132                                // 000000063F98: 37750881
	.long 0xd59c48b9                                           // 000000063F9C: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000063FA0: 02010184
	.long 0xd59c08b9                                           // 000000063FA4: D59C08B9
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000063FA8: 02010187
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 000000063FAC: 7C3D26FF 42B17218
	v_exp_f32_e32 v146, v146                                   // 000000063FB4: 7F244B92
	v_add3_u32 v134, v136, v186, 0x7fff                        // 000000063FB8: D6550086 03FF7588 00007FFF
	v_exp_f32_e32 v184, v184                                   // 000000063FC4: 7F704BB8
	v_add_f32_e32 v136, v183, v136                             // 000000063FC8: 071111B7
	v_cvt_i32_f32_e32 v183, v204                               // 000000063FCC: 7F6E11CC
	v_and_b32_e32 v185, 1, v185                                // 000000063FD0: 37737281
	.long 0xd59c0885                                           // 000000063FD4: D59C0885
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 000000063FD8: 02010189
	.long 0xd59c0886                                           // 000000063FDC: D59C0886
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 000000063FE0: 020101B6
	v_add_f32_e32 v136, v136, v135                             // 000000063FE4: 07110F88
	s_delay_alu instid0(TRANS32_DEP_2)                         // 000000063FE8: BF870006
	.long 0xd71c0092                                           // 000000063FEC: D71C0092
	v_cndmask_b32_e32 v1, v146, v183, vcc_lo                   // 000000063FF0: 02036F92
	v_add3_u32 v183, v135, v185, 0x7fff                        // 000000063FF4: D65500B7 03FF7387 00007FFF
	.long 0xd59c48b9                                           // 000000064000: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000064004: 02010184
	v_cndmask_b32_e32 v147, 0x7f800000, v187, vcc_lo           // 000000064008: 032776FF 7F800000
	v_cvt_i32_f32_e32 v187, v206                               // 000000064010: 7F7611CE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000064014: 7C372AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006401C: BF870193
	.long 0xd59c0884                                           // 000000064020: D59C0884
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 000000064024: 02010193
	.long 0xd71c00b8                                           // 000000064028: D71C00B8
	v_cndmask_b32_e32 v1, v184, v187, vcc_lo                   // 00000006402C: 020377B8
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000064030: 03252480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 000000064034: 7C3728FF C2CE8ED0
	v_add_f32_e32 v136, v136, v147                             // 00000006403C: 07112788
	v_and_b32_e32 v186, 1, v132                                // 000000064040: 37750881
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 000000064044: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000064048: 7C3D2AFF 42B17218
	v_mul_f32_e32 v149, 0x3fb8aa3b, v151                       // 000000064050: 112B2EFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000064058: BF8701D4
	v_add3_u32 v135, v147, v186, 0x7fff                        // 00000006405C: D6550087 03FF7593 00007FFF
	.long 0xd59c0887                                           // 000000064068: D59C0887
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 00000006406C: 020101B7
	v_cndmask_b32_e32 v146, 0x7f800000, v146, vcc_lo           // 000000064070: 032524FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 000000064078: 7C3D28FF 42B17218
	v_fma_f32 v148, 0x3fb8aa3b, v151, -v149                    // 000000064080: D6130094 86572EFF 3FB8AA3B
	.long 0xd59c0884                                           // 00000006408C: D59C0884
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 000000064090: 02010192
	v_cndmask_b32_e32 v147, 0x7f800000, v184, vcc_lo           // 000000064094: 032770FF 7F800000
	v_rndne_f32_e32 v184, v149                                 // 00000006409C: 7F704795
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000640A0: BF870194
	v_fmac_f32_e32 v148, 0x32a5705f, v151                      // 0000000640A4: 57292EFF 32A5705F
	.long 0xd59c08b9                                           // 0000000640AC: D59C08B9
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000000640B0: 02010193
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000640B4: BF870113
	v_dual_sub_f32 v149, v149, v184 :: v_dual_mul_f32 v186, 0x3fb8aa3b, v150// 0000000640B8: C9477195 95BB2CFF 3FB8AA3B
	v_dual_add_f32 v187, v136, v147 :: v_dual_and_b32 v136, 1, v185// 0000000640C4: C9252788 BB897281
	v_and_b32_e32 v185, 1, v132                                // 0000000640CC: 37730881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000640D0: BF870213
	v_add_f32_e32 v148, v149, v148                             // 0000000640D4: 07292995
	v_fma_f32 v149, 0x3fb8aa3b, v150, -v186                    // 0000000640D8: D6130095 86EB2CFF 3FB8AA3B
	v_rndne_f32_e32 v188, v186                                 // 0000000640E4: 7F7847BA
	v_add3_u32 v147, v147, v136, 0x7fff                        // 0000000640E8: D6550093 03FF1193 00007FFF
	v_add3_u32 v136, v146, v185, 0x7fff                        // 0000000640F4: D6550088 03FF7392 00007FFF
	v_exp_f32_e32 v148, v148                                   // 000000064100: 7F284B94
	v_fmac_f32_e32 v149, 0x32a5705f, v150                      // 000000064104: 572B2CFF 32A5705F
	v_sub_f32_e32 v185, v186, v188                             // 00000006410C: 097379BA
	.long 0xd59c0888                                           // 000000064110: D59C0888
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 000000064114: 02010193
	v_cvt_i32_f32_e32 v147, v184                               // 000000064118: 7F2611B8
	v_cvt_i32_f32_e32 v182, v188                               // 00000006411C: 7F6C11BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000064120: BF870004
	v_add_f32_e32 v149, v185, v149                             // 000000064124: 072B2BB9
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 000000064128: BF870185
	.long 0xd71c0089                                           // 00000006412C: D71C0089
	v_cndmask_b32_e32 v1, v148, v147, vcc_lo                   // 000000064130: 02032794
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000064134: BF870132
	v_exp_f32_e32 v147, v149                                   // 000000064138: 7F264B95
	v_dual_mul_f32 v149, 0x3fb8aa3b, v153 :: v_dual_mul_f32 v148, 0x3fb8aa3b, v152// 00000006413C: C8C732FF 959530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 000000064148: 7C372EFF C2CE8ED0
	v_fma_f32 v185, 0x3fb8aa3b, v153, -v149                    // 000000064150: D61300B9 865732FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000006415C: BF8702B3
	v_fma_f32 v183, 0x3fb8aa3b, v152, -v148                    // 000000064160: D61300B7 865330FF 3FB8AA3B
	v_cndmask_b32_e32 v137, 0, v137, vcc_lo                    // 00000006416C: 03131280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 000000064170: 7C372CFF C2CE8ED0
	.long 0xd71c0093                                           // 000000064178: D71C0093
	v_cndmask_b32_e32 v1, v147, v182, vcc_lo                   // 00000006417C: 02036D93
	v_rndne_f32_e32 v184, v148                                 // 000000064180: 7F704794
	v_rndne_f32_e32 v186, v149                                 // 000000064184: 7F744795
	v_fmac_f32_e32 v183, 0x32a5705f, v152                      // 000000064188: 576F30FF 32A5705F
	v_fmac_f32_e32 v185, 0x32a5705f, v153                      // 000000064190: 577332FF 32A5705F
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 000000064198: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000006419C: 7C3D2EFF 42B17218
	v_dual_sub_f32 v148, v148, v184 :: v_dual_sub_f32 v149, v149, v186// 0000000641A4: C94B7194 94957595
	v_cvt_i32_f32_e32 v151, v184                               // 0000000641AC: 7F2E11B8
	v_cvt_i32_f32_e32 v182, v186                               // 0000000641B0: 7F6C11BA
	v_cndmask_b32_e32 v137, 0x7f800000, v137, vcc_lo           // 0000000641B4: 031312FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000641BC: 7C3D2CFF 42B17218
	v_dual_add_f32 v148, v148, v183 :: v_dual_add_f32 v149, v149, v185// 0000000641C4: C9096F94 94957395
	.long 0xd59c4896                                           // 0000000641CC: D59C4896
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 0000000641D0: 02010184
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000641D4: BF870224
	.long 0xd59c0884                                           // 0000000641D8: D59C0884
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000641DC: 02010189
	v_cndmask_b32_e32 v147, 0x7f800000, v147, vcc_lo           // 0000000641E0: 032726FF 7F800000
	v_exp_f32_e32 v148, v148                                   // 0000000641E8: 7F284B94
	v_exp_f32_e32 v149, v149                                   // 0000000641EC: 7F2A4B95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000641F0: 7C3730FF C2CE8ED0
	v_and_b32_e32 v183, 1, v132                                // 0000000641F8: 376F0881
	.long 0xd59c0896                                           // 0000000641FC: D59C0896
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 000000064200: 02010193
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000064204: BF870321
	v_dual_mul_f32 v185, 0x3fb8aa3b, v180 :: v_dual_and_b32 v150, 1, v150// 000000064208: C8E568FF B9972C81 3FB8AA3B
	v_add_f32_e32 v146, v187, v146                             // 000000064214: 072525BB
	.long 0xd71c0094                                           // 000000064218: D71C0094
	v_cndmask_b32_e32 v1, v148, v151, vcc_lo                   // 00000006421C: 02032F94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064220: BF870215
	.long 0xd71c0095                                           // 000000064224: D71C0095
	v_cndmask_b32_e32 v1, v149, v182, vcc_lo                   // 000000064228: 02036D95
	v_fma_f32 v187, 0x3fb8aa3b, v180, -v185                    // 00000006422C: D61300BB 86E768FF 3FB8AA3B
	v_add3_u32 v150, v147, v150, 0x7fff                        // 000000064238: D6550096 03FF2D93 00007FFF
	v_add_f32_e32 v146, v146, v147                             // 000000064244: 07252792
	v_rndne_f32_e32 v188, v185                                 // 000000064248: 7F7847B9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006424C: BF870194
	v_fmac_f32_e32 v187, 0x32a5705f, v180                      // 000000064250: 577768FF 32A5705F
	v_dual_add_f32 v151, v146, v137 :: v_dual_cndmask_b32 v146, 0, v148// 000000064258: C9131392 97932880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000064260: 7C3732FF C2CE8ED0
	v_dual_cndmask_b32 v148, 0, v149 :: v_dual_sub_f32 v149, v179, v131// 000000064268: CA4B2A80 949507B3
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000064270: 7C3D30FF 42B17218
	.long 0xd59c48b3                                           // 000000064278: D59C48B3
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000006427C: 02010184
	v_cndmask_b32_e32 v152, 0x7f800000, v146, vcc_lo           // 000000064280: 033124FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000064288: 7C3D32FF 42B17218
	v_mul_f32_e32 v153, 0x3fb8aa3b, v149                       // 000000064290: 11332AFF 3FB8AA3B
	v_add3_u32 v146, v137, v183, 0x7fff                        // 000000064298: D6550092 03FF6F89 00007FFF
	v_mul_f32_e32 v183, 0x3fb8aa3b, v178                       // 0000000642A4: 116F64FF 3FB8AA3B
	v_add_f32_e32 v137, v151, v152                             // 0000000642AC: 07133197
	.long 0xd59c08b3                                           // 0000000642B0: D59C08B3
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 0000000642B4: 02010198
	v_fma_f32 v147, 0x3fb8aa3b, v149, -v153                    // 0000000642B8: D6130093 86672AFF 3FB8AA3B
	v_rndne_f32_e32 v151, v153                                 // 0000000642C4: 7F2E4799
	v_rndne_f32_e32 v184, v183                                 // 0000000642C8: 7F7047B7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000642CC: BF870214
	v_dual_cndmask_b32 v148, 0x7f800000, v148 :: v_dual_and_b32 v179, 1, v179// 0000000642D0: CA6528FF 94B36681 7F800000
	v_fmac_f32_e32 v147, 0x32a5705f, v149                      // 0000000642DC: 57272AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000642E4: BF870004
	v_sub_f32_e32 v153, v153, v151                             // 0000000642E8: 09332F99
	v_cvt_i32_f32_e32 v151, v151                               // 0000000642EC: 7F2E1197
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000642F0: 7C372AFF C2CE8ED0
	v_add3_u32 v152, v152, v179, 0x7fff                        // 0000000642F8: D6550098 03FF6798 00007FFF
	.long 0xd59c0884                                           // 000000064304: D59C0884
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 000000064308: 02010194
	v_add_f32_e32 v147, v153, v147                             // 00000006430C: 07272799
	v_sub_f32_e32 v153, v181, v131                             // 000000064310: 093307B5
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v183                    // 000000064314: D61300B5 86DF64FF 3FB8AA3B
	v_sub_f32_e32 v183, v183, v184                             // 000000064320: 096F71B7
	v_add_f32_e32 v137, v137, v148                             // 000000064324: 07132989
	v_exp_f32_e32 v147, v147                                   // 000000064328: 7F264B93
	v_mul_f32_e32 v186, 0x3fb8aa3b, v153                       // 00000006432C: 117532FF 3FB8AA3B
	v_dual_fmac_f32 v181, 0x32a5705f, v178 :: v_dual_and_b32 v182, 1, v132// 000000064334: C82564FF B5B70881 32A5705F
	.long 0xd59c0892                                           // 000000064340: D59C0892
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 000000064344: 02010196
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000064348: BF870193
	v_fma_f32 v189, 0x3fb8aa3b, v153, -v186                    // 00000006434C: D61300BD 86EB32FF 3FB8AA3B
	v_add_f32_e32 v181, v183, v181                             // 000000064358: 076B6BB7
	v_sub_f32_e32 v183, v185, v188                             // 00000006435C: 096F79B9
	v_rndne_f32_e32 v190, v186                                 // 000000064360: 7F7C47BA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000064364: BF870005
	.long 0xd71c0093                                           // 000000064368: D71C0093
	v_cndmask_b32_e32 v1, v147, v151, vcc_lo                   // 00000006436C: 02032F93
	v_fmac_f32_e32 v189, 0x32a5705f, v153                      // 000000064370: 577B32FF 32A5705F
	v_exp_f32_e32 v181, v181                                   // 000000064378: 7F6A4BB5
	v_add_f32_e32 v179, v183, v187                             // 00000006437C: 076777B7
	v_sub_f32_e32 v185, v186, v190                             // 000000064380: 09737DBA
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 000000064384: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000064388: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000064390: BF870004
	v_exp_f32_e32 v151, v179                                   // 000000064394: 7F2E4BB3
	v_cvt_i32_f32_e32 v179, v184                               // 000000064398: 7F6611B8
	v_add_f32_e32 v183, v185, v189                             // 00000006439C: 076F7BB9
	v_cvt_i32_f32_e32 v184, v188                               // 0000000643A0: 7F7011BC
	v_cndmask_b32_e32 v149, 0x7f800000, v147, vcc_lo           // 0000000643A4: 032B26FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000643AC: 7C3764FF C2CE8ED0
	.long 0xd71c00b3                                           // 0000000643B4: D71C00B3
	v_cndmask_b32_e32 v1, v181, v179, vcc_lo                   // 0000000643B8: 020367B5
	v_exp_f32_e32 v183, v183                                   // 0000000643BC: 7F6E4BB7
	v_cvt_i32_f32_e32 v181, v190                               // 0000000643C0: 7F6A11BE
	.long 0xd59c0884                                           // 0000000643C4: D59C0884
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 0000000643C8: 02010195
	.long 0xd71c0093                                           // 0000000643CC: D71C0093
	v_cndmask_b32_e32 v1, v151, v184, vcc_lo                   // 0000000643D0: 02037197
	v_cndmask_b32_e32 v151, 0, v179, vcc_lo                    // 0000000643D4: 032F6680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v180                 // 0000000643D8: 7C3768FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000000643E0: BF8702A3
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 0000000643E4: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000643E8: 7C3D64FF 42B17218
	.long 0xd71c00b3                                           // 0000000643F0: D71C00B3
	v_cndmask_b32_e32 v1, v183, v181, vcc_lo                   // 0000000643F4: 02036BB7
	v_cndmask_b32_e32 v151, 0x7f800000, v151, vcc_lo           // 0000000643F8: 032F2EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000064400: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064408: BF870212
	v_add_f32_e32 v137, v137, v151                             // 00000006440C: 07132F89
	v_cndmask_b32_e32 v178, 0, v179, vcc_lo                    // 000000064410: 03656680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v180                 // 000000064414: 7C3D68FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000006441C: BF870253
	v_dual_add_f32 v137, v137, v149 :: v_dual_and_b32 v180, 1, v132// 000000064420: C9252B89 89B50881
	v_cndmask_b32_e32 v179, 0x7f800000, v147, vcc_lo           // 000000064428: 036726FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000064430: 7C3D32FF 42B17218
	.long 0xd59c0893                                           // 000000064438: D59C0893
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000006443C: 02010197
	.long 0xd59c4893                                           // 000000064440: D59C4893
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000064444: 02010184
	v_add_f32_e32 v137, v137, v179                             // 000000064448: 07136789
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 00000006444C: 033364FF 7F800000
	.long 0xd59c08b2                                           // 000000064454: D59C08B2
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000064458: 020101B3
	.long 0xd59c48b2                                           // 00000006445C: D59C48B2
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000064460: 02010184
	v_and_b32_e32 v181, 1, v147                                // 000000064464: 376B2681
	v_add3_u32 v147, v148, v182, 0x7fff                        // 000000064468: D6550093 03FF6D94 00007FFF
	.long 0xd59c0884                                           // 000000064474: D59C0884
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 000000064478: 02010199
	v_add3_u32 v148, v149, v180, 0x7fff                        // 00000006447C: D6550094 03FF6995 00007FFF
	v_and_b32_e32 v178, 1, v178                                // 000000064488: 37656481
	v_add3_u32 v151, v151, v181, 0x7fff                        // 00000006448C: D6550097 03FF6B97 00007FFF
	.long 0xd59c0893                                           // 000000064498: D59C0893
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000006449C: 02010198
	v_and_b32_e32 v132, 1, v132                                // 0000000644A0: 37090881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000644A4: BF870214
	v_add3_u32 v178, v179, v178, 0x7fff                        // 0000000644A8: D65500B2 03FF65B3 00007FFF
	.long 0xd59c0894                                           // 0000000644B4: D59C0894
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 0000000644B8: 02010197
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000644BC: BF870223
	v_add3_u32 v149, v153, v132, 0x7fff                        // 0000000644C0: D6550095 03FF0999 00007FFF
	v_add_f32_e32 v132, v137, v153                             // 0000000644CC: 07093389
	.long 0xd59c0895                                           // 0000000644D0: D59C0895
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 0000000644D4: 020101B2
	ds_store_b128 v166, v[133:136]                             // 0000000644D8: DB7C0000 000085A6
	ds_store_b128 v166, v[146:149] offset:16                   // 0000000644E0: DB7C0010 000092A6
	v_mov_b32_e32 v133, 0                                      // 0000000644E8: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 0000000644EC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 0000000644F0: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 0000000644F4: 7D2304FF EFA18F08
	s_cbranch_execz 26                                         // 0000000644FC: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e68>
	v_sub_f32_e32 v130, v130, v131                             // 000000064500: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064504: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v130                       // 000000064508: 110B04FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v130, -v133                    // 000000064510: D6130086 861704FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 00000006451C: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064520: BF870091
	v_dual_fmac_f32 v134, 0x32a5705f, v130 :: v_dual_sub_f32 v133, v133, v135// 000000064524: C80B04FF 86850F85 32A5705F
	v_add_f32_e32 v133, v133, v134                             // 000000064530: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 000000064534: 7F0C1187
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000064538: 7C3704FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000064540: BF870293
	v_exp_f32_e32 v133, v133                                   // 000000064544: 7F0A4B85
	.long 0xd71c0085                                           // 000000064548: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 00000006454C: 02030D85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064550: BF870121
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 000000064554: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000064558: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v133, 0x7f800000, v133, vcc_lo           // 000000064560: 030B0AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000064568: 8C7E017E
	ds_load_b32 v130, v167                                     // 00000006456C: D8D80000 820000A7
	s_waitcnt lgkmcnt(0)                                       // 000000064574: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 000000064578: 57090585
	ds_store_b32 v164, v131                                    // 00000006457C: D8340000 000083A4
	ds_store_b32 v167, v132                                    // 000000064584: D8340000 000084A7
	ds_store_b32 v168, v133                                    // 00000006458C: D8340000 000085A8
	s_or_b32 exec_lo, exec_lo, s4                              // 000000064594: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 000000064598: BF89FC07
	s_barrier                                                  // 00000006459C: BFBD0000
	buffer_gl0_inv                                             // 0000000645A0: E0AC0000 00000000
	ds_load_2addr_b32 v[152:153], v169 offset1:2               // 0000000645A8: D8DC0200 980000A9
	ds_load_2addr_b32 v[150:151], v169 offset0:4 offset1:6     // 0000000645B0: D8DC0604 960000A9
	ds_load_2addr_b32 v[148:149], v169 offset0:8 offset1:10    // 0000000645B8: D8DC0A08 940000A9
	ds_load_2addr_b32 v[146:147], v169 offset0:12 offset1:14   // 0000000645C0: D8DC0E0C 920000A9
	s_waitcnt lgkmcnt(3)                                       // 0000000645C8: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 0000000645CC: 7C2530F2
	.long 0xd4120001                                           // 0000000645D0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000000645D4: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 0000000645D8: BF89FC27
	.long 0xd4120002                                           // 0000000645DC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000645E0: 02032CF2
	.long 0xd4120004                                           // 0000000645E4: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 0000000645E8: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000645EC: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000645F0: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 0000000645F4: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 0000000645F8: 8B020201
	.long 0xd4120001                                           // 0000000645FC: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000064600: 02032AF2
	s_and_b32 s4, s2, s4                                       // 000000064604: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000064608: BF89FC07
	.long 0xd4120002                                           // 00000006460C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 000000064610: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 000000064614: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 000000064618: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000006461C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000064620: BF870499
	s_and_b32 s1, s1, s2                                       // 000000064624: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000064628: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006462C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000064630: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 000000064638: 7C9B0480
	ds_load_b128 v[130:133], v170                              // 00000006463C: DBFC0000 820000AA
	ds_load_b128 v[134:137], v170 offset:16                    // 000000064644: DBFC0010 860000AA
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000006464C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000064650: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064654: BF870099
	v_cndmask_b32_e64 v178, 0, 1, s1                           // 000000064658: D50100B2 00050280
	v_readfirstlane_b32 s1, v178                               // 000000064660: 7E0205B2
	s_bitcmp1_b32 s1, 0                                        // 000000064664: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000064668: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006466C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000064670: 8B6A017E
	s_cbranch_vccnz 62966                                      // 000000064674: BFA4F5F6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 000000064678: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 000000064680: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 000000064688: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 000000064690: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 000000064698: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 0000000646A0: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 0000000646A8: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 0000000646B0: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 0000000646B8: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 0000000646C0: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 0000000646C8: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 0000000646D0: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 0000000646D8: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 0000000646E0: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 0000000646E8: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 0000000646F0: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 0000000646F8: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 000000064700: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 000000064708: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 000000064710: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 000000064718: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 000000064720: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 000000064728: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 000000064730: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 000000064738: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 000000064740: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 000000064748: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 000000064750: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 000000064758: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 000000064760: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 000000064768: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 000000064770: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 000000064778: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 000000064780: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 000000064788: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 000000064790: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 000000064798: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 0000000647A0: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 0000000647A8: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 0000000647B0: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 0000000647B8: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 0000000647C0: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 0000000647C8: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 0000000647D0: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 0000000647D8: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 0000000647E0: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 0000000647E8: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 0000000647F0: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 0000000647F8: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 000000064800: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 000000064808: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 000000064810: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 000000064818: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 000000064820: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 000000064828: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 000000064830: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 000000064838: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 000000064840: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 000000064848: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 000000064850: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 000000064858: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 000000064860: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 000000064868: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 000000064870: C8C60F92 07081193
	s_branch 62837                                             // 000000064878: BFA0F575 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000006487C: 30013A82
	.long 0xd700008b                                           // 000000064880: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 000000064884: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000064888: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000006488C: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 000000064894: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000006489C: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000648A0: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 0000000648A4: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 0000000648AC: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000648B4: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000648B8: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000648C0: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000648C8: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000648CC: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000648D0: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000648D8: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 0000000648DC: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 0000000648E4: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 0000000648EC: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000648F4: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000648F8: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 0000000648FC: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000064900: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 000000064904: 11252191
	.long 0xd73c0083                                           // 000000064908: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000006490C: 02030281
	.long 0xd7000081                                           // 000000064910: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 000000064914: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064918: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000006491C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 000000064924: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006492C: BF870094
	.long 0xd7000083                                           // 000000064930: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 000000064934: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 000000064938: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064940: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 000000064944: 57252194
	.long 0xd4440000                                           // 000000064948: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 00000006494C: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 000000064950: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000064958: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000006495C: D637008B 064B218B
	.long 0xd7006a83                                           // 000000064964: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 000000064968: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000006496C: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000064974: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 000000064978: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 000000064980: BE812000
	s_cbranch_execz 70                                         // 000000064984: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064988: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000006498C: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000064998: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000006499C: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000649A4: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000649A8: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000649AC: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000649B0: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000649B8: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000649C4: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000649C8: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000649CC: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000649D4: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000649D8: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000649DC: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000649E0: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000649E4: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000649EC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000649F0: BF870095
	.long 0xd71c008d                                           // 0000000649F4: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000649F8: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000649FC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 000000064A00: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A08: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 000000064A0C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 000000064A14: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A18: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 000000064A1C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 000000064A24: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A28: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 000000064A2C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 000000064A34: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 000000064A38: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A40: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000064A44: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 000000064A48: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A50: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000064A54: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 000000064A58: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A60: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 000000064A64: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 000000064A6C: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 000000064A74: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064A80: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000064A84: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000064A8C: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 000000064A98: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000064AA0: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 000000064AA4: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 000000064AAC: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000064AB4: BF870292
	v_rcp_f32_e32 v140, v121                                   // 000000064AB8: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 000000064ABC: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064AC4: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 000000064AC8: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 000000064ACC: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064AD0: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 000000064AD4: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 000000064ADC: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064AE0: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 000000064AE4: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 000000064AEC: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 000000064AF4: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064AF8: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 000000064AFC: D627008C 03CB1D8C
	.long 0xd4440001                                           // 000000064B04: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000064B08: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 000000064B0C: BE822001
	s_cbranch_execz 69                                         // 000000064B10: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3528>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000064B14: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 000000064B20: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 000000064B24: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000064B2C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000064B30: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064B34: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000064B38: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000064B40: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000064B4C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000064B50: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000064B54: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000064B58: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000064B60: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064B68: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000064B6C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000064B70: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000064B74: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064B78: BF870095
	.long 0xd71c008e                                           // 000000064B7C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000064B80: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000064B84: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000064B88: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064B90: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000064B94: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000064B9C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064BA0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000064BA4: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000064BAC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064BB0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000064BB4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000064BBC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000064BC0: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064BC8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000064BCC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000064BD0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064BD8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000064BDC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000064BE0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064BE8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000064BEC: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000064BF4: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 000000064BFC: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064C08: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 000000064C0C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000064C14: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000064C20: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 000000064C28: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 000000064C2C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000064C30: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000064C38: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000064C40: BF870292
	v_rcp_f32_e32 v141, v122                                   // 000000064C44: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 000000064C48: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064C50: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000064C54: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000064C58: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064C5C: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 000000064C60: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 000000064C68: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064C6C: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000064C70: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 000000064C78: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 000000064C80: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064C84: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 000000064C88: D6270089 03CB138D
	.long 0xd4440002                                           // 000000064C90: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 000000064C94: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 000000064C98: BE832002
	s_cbranch_execz 69                                         // 000000064C9C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000064CA0: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 000000064CAC: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000064CB0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000064CB8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000064CBC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064CC0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000064CC4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000064CCC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000064CD8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000064CDC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000064CE0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000064CE4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000064CEC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064CF4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000064CF8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000064CFC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000064D00: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D04: BF870095
	.long 0xd71c008e                                           // 000000064D08: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000064D0C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000064D10: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000064D14: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D1C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000064D20: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000064D28: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D2C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 000000064D30: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000064D38: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D3C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000064D40: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000064D48: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 000000064D4C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D54: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000064D58: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000064D5C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D64: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000064D68: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000064D6C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D74: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000064D78: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 000000064D80: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 000000064D88: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064D94: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 000000064D98: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000064DA0: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 000000064DAC: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000064DB4: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 000000064DB8: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 000000064DC0: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000064DC8: BF870292
	v_rcp_f32_e32 v141, v123                                   // 000000064DCC: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000064DD0: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064DD8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000064DDC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000064DE0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064DE4: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000064DE8: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000064DF0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064DF4: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000064DF8: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000064E00: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 000000064E08: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064E0C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000064E10: D627008A 03CB158D
	.long 0xd4440003                                           // 000000064E18: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 000000064E1C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 000000064E20: BE842003
	s_cbranch_execz 69                                         // 000000064E24: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 000000064E28: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 000000064E34: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 000000064E38: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000064E40: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000064E44: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064E48: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000064E4C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000064E54: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000064E60: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000064E64: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000064E68: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000064E6C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000064E74: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064E7C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000064E80: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000064E84: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000064E88: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064E8C: BF870095
	.long 0xd71c008e                                           // 000000064E90: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000064E94: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000064E98: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000064E9C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EA4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000064EA8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000064EB0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EB4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000064EB8: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000064EC0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EC4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000064EC8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000064ED0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000064ED4: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EDC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000064EE0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000064EE4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EEC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000064EF0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000064EF4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064EFC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000064F00: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000064F08: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 000000064F10: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064F1C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000064F20: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000064F28: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000064F34: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000064F3C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 000000064F40: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 000000064F44: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 000000064F4C: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000064F54: BF870292
	v_rcp_f32_e32 v141, v124                                   // 000000064F58: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 000000064F5C: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064F64: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000064F68: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000064F6C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064F70: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 000000064F74: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 000000064F7C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064F80: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 000000064F84: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 000000064F8C: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 000000064F94: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064F98: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 000000064F9C: D6270087 03CB0F8D
	.long 0xd4440004                                           // 000000064FA4: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 000000064FA8: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 000000064FAC: BE852004
	s_cbranch_execz 69                                         // 000000064FB0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 000000064FB4: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 000000064FC0: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000064FC4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000064FCC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000064FD0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064FD4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000064FD8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000064FE0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000064FEC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000064FF0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000064FF4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000064FF8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000065000: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065008: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000006500C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000065010: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000065014: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065018: BF870095
	.long 0xd71c008e                                           // 00000006501C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000065020: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000065024: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000065028: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065030: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000065034: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000006503C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065040: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 000000065044: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000006504C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065050: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000065054: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000006505C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 000000065060: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065068: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000006506C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000065070: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065078: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000006507C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000065080: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065088: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000006508C: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 000000065094: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000006509C: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000650A8: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000650AC: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000650B4: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000650C0: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000650C8: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000650CC: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000650D4: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000650DC: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000650E0: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000650E4: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000650EC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000650F0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000650F4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000650F8: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000650FC: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000065104: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065108: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000006510C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000065114: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000006511C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000065120: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 000000065124: D6270088 03CB118D
	.long 0xd4440005                                           // 00000006512C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000065130: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 000000065134: BE862005
	s_cbranch_execz 69                                         // 000000065138: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b50>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000006513C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 000000065148: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000006514C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000065154: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000065158: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006515C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000065160: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000065168: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000065174: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065178: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000006517C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000065180: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000065188: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065190: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000065194: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000065198: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000006519C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651A0: BF870095
	.long 0xd71c008e                                           // 0000000651A4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000651A8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000651AC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000651B0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651B8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000651BC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000651C4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651C8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000651CC: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000651D4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651D8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000651DC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000651E4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000651E8: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651F0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000651F4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000651F8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065200: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000065204: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000065208: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065210: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000065214: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000006521C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 000000065224: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065230: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000065234: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000006523C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 000000065248: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000065250: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000065254: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 000000065258: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 000000065260: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000065268: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000006526C: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 000000065270: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065278: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000006527C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000065280: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065284: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 000000065288: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 000000065290: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065294: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 000000065298: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000652A0: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000652A8: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000652AC: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000652B0: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000652B8: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000652BC: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000652C0: BE872006
	s_cbranch_execz 69                                         // 0000000652C4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cdc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000652C8: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000652D4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000652D8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000652E0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000652E4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000652E8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000652EC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000652F4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000065300: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065304: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000065308: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000006530C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000065314: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006531C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000065320: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000065324: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000065328: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006532C: BF870095
	.long 0xd71c008e                                           // 000000065330: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000065334: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000065338: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000006533C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065344: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000065348: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000065350: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065354: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 000000065358: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000065360: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065364: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000065368: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000065370: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 000000065374: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006537C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000065380: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000065384: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006538C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000065390: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000065394: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006539C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000653A0: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000653A8: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000653B0: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000653BC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000653C0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000653C8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000653D4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000653DC: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000653E0: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000653E8: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000653F0: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000653F4: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000653F8: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065400: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000065404: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000065408: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006540C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 000000065410: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 000000065418: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006541C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 000000065420: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 000000065428: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 000000065430: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000065434: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000065438: D6270086 03CB0D8D
	.long 0xd4440007                                           // 000000065440: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 000000065444: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 000000065448: BE882007
	s_cbranch_execnz 363                                       // 00000006544C: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065450: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065454: BE882000
	s_cbranch_execnz 432                                       // 000000065458: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x441c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006545C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065460: BE882001
	s_cbranch_execnz 501                                       // 000000065464: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x453c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065468: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006546C: BE882002
	s_cbranch_execnz 570                                       // 000000065470: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x465c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065474: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065478: BE882003
	s_cbranch_execnz 639                                       // 00000006547C: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x477c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065480: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065484: BE882004
	s_cbranch_execnz 708                                       // 000000065488: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x489c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006548C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065490: BE882005
	s_cbranch_execnz 777                                       // 000000065494: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065498: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006549C: BE882006
	s_cbranch_execnz 846                                       // 0000000654A0: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000654A8: BE882007
	s_cbranch_execnz 915                                       // 0000000654AC: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000654B4: BE882000
	s_cbranch_execnz 984                                       // 0000000654B8: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000654C0: BE882001
	s_cbranch_execnz 1053                                      // 0000000654C4: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000654CC: BE882002
	s_cbranch_execnz 1122                                      // 0000000654D0: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000654D8: BE882003
	s_cbranch_execnz 1191                                      // 0000000654DC: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x507c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000654E4: BE882004
	s_cbranch_execnz 1260                                      // 0000000654E8: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x519c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000654F0: BE882005
	s_cbranch_execnz 1329                                      // 0000000654F4: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000654F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000654FC: BE882006
	s_cbranch_execnz 1398                                      // 000000065500: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065504: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065508: BE882007
	s_cbranch_execnz 1467                                      // 00000006550C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065510: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065514: BE882000
	s_cbranch_execnz 1536                                      // 000000065518: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x561c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006551C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065520: BE882001
	s_cbranch_execnz 1605                                      // 000000065524: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x573c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065528: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006552C: BE882002
	s_cbranch_execnz 1674                                      // 000000065530: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x585c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065534: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065538: BE882003
	s_cbranch_execnz 1743                                      // 00000006553C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x597c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065540: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065544: BE882004
	s_cbranch_execnz 1812                                      // 000000065548: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006554C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065550: BE882005
	s_cbranch_execnz 1881                                      // 000000065554: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065558: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006555C: BE882006
	s_cbranch_execnz 1950                                      // 000000065560: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5cdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065564: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065568: BE882007
	s_cbranch_execnz 2019                                      // 00000006556C: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065570: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065574: BE882000
	s_cbranch_execnz 2088                                      // 000000065578: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006557C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065580: BE882001
	s_cbranch_execnz 2157                                      // 000000065584: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x603c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065588: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006558C: BE882002
	s_cbranch_execnz 2226                                      // 000000065590: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x615c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065594: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065598: BE882003
	s_cbranch_execnz 2295                                      // 00000006559C: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x627c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000655A4: BE882004
	s_cbranch_execnz 2364                                      // 0000000655A8: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x639c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000655B0: BE882005
	s_cbranch_execnz 2433                                      // 0000000655B4: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000655BC: BE882006
	s_cbranch_execnz 2502                                      // 0000000655C0: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000655C8: BE882007
	s_cbranch_execnz 2571                                      // 0000000655CC: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000655D4: BE882000
	s_cbranch_execnz 2640                                      // 0000000655D8: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x681c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000655E0: BE882001
	s_cbranch_execnz 2709                                      // 0000000655E4: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x693c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000655EC: BE882002
	s_cbranch_execnz 2778                                      // 0000000655F0: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000655F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000655F8: BE882003
	s_cbranch_execnz 2847                                      // 0000000655FC: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065600: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065604: BE882004
	s_cbranch_execnz 2916                                      // 000000065608: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006560C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065610: BE882005
	s_cbranch_execnz 2985                                      // 000000065614: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065618: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006561C: BE882006
	s_cbranch_execnz 3054                                      // 000000065620: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6edc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065624: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065628: BE882007
	s_cbranch_execnz 3123                                      // 00000006562C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ffc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065630: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065634: BE882000
	s_cbranch_execnz 3192                                      // 000000065638: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x711c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006563C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065640: BE882001
	s_cbranch_execnz 3261                                      // 000000065644: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x723c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065648: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006564C: BE882002
	s_cbranch_execnz 3330                                      // 000000065650: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x735c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065654: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065658: BE882003
	s_cbranch_execnz 3399                                      // 00000006565C: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x747c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065660: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065664: BE882004
	s_cbranch_execnz 3468                                      // 000000065668: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x759c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006566C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065670: BE882005
	s_cbranch_execnz 3537                                      // 000000065674: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065678: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006567C: BE882006
	s_cbranch_execnz 3606                                      // 000000065680: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065684: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065688: BE882007
	s_cbranch_execnz 3675                                      // 00000006568C: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065690: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065694: BE882000
	s_cbranch_execnz 3744                                      // 000000065698: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006569C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000656A0: BE882001
	s_cbranch_execnz 3813                                      // 0000000656A4: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000656AC: BE882002
	s_cbranch_execnz 3882                                      // 0000000656B0: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000656B8: BE882003
	s_cbranch_execnz 3951                                      // 0000000656BC: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000656C4: BE882004
	s_cbranch_execnz 4020                                      // 0000000656C8: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000656D0: BE882005
	s_cbranch_execnz 4089                                      // 0000000656D4: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000656DC: BE882006
	s_cbranch_execnz 4158                                      // 0000000656E0: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000656E8: BE882007
	s_cbranch_execnz 4227                                      // 0000000656EC: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000656F4: BE882000
	s_cbranch_execnz 4296                                      // 0000000656F8: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x831c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000656FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065700: BE882001
	s_cbranch_execnz 4365                                      // 000000065704: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x843c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065708: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006570C: BE882002
	s_cbranch_execnz 4434                                      // 000000065710: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x855c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065714: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065718: BE882003
	s_cbranch_execnz 4503                                      // 00000006571C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x867c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065720: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065724: BE882004
	s_cbranch_execnz 4572                                      // 000000065728: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x879c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006572C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065730: BE882005
	s_cbranch_execnz 4641                                      // 000000065734: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065738: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006573C: BE882006
	s_cbranch_execnz 4710                                      // 000000065740: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065744: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065748: BE882007
	s_cbranch_execnz 4779                                      // 00000006574C: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8afc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065750: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065754: BE882000
	s_cbranch_execnz 4848                                      // 000000065758: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006575C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065760: BE882001
	s_cbranch_execnz 4917                                      // 000000065764: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065768: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006576C: BE882002
	s_cbranch_execnz 4986                                      // 000000065770: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065774: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065778: BE882003
	s_cbranch_execnz 5055                                      // 00000006577C: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065780: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065784: BE882004
	s_cbranch_execnz 5124                                      // 000000065788: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x909c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006578C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065790: BE882005
	s_cbranch_execnz 5193                                      // 000000065794: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065798: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006579C: BE882006
	s_cbranch_execnz 5262                                      // 0000000657A0: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000657A8: BE882007
	s_cbranch_execnz 5331                                      // 0000000657AC: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000657B4: BE882000
	s_cbranch_execnz 5400                                      // 0000000657B8: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x951c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000657C0: BE882001
	s_cbranch_execnz 5469                                      // 0000000657C4: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x963c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000657CC: BE882002
	s_cbranch_execnz 5538                                      // 0000000657D0: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x975c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000657D8: BE882003
	s_cbranch_execnz 5607                                      // 0000000657DC: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x987c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000657E4: BE882004
	s_cbranch_execnz 5676                                      // 0000000657E8: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x999c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000657F0: BE882005
	s_cbranch_execnz 5745                                      // 0000000657F4: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9abc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000657F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000657FC: BE882006
	s_cbranch_execnz 5814                                      // 000000065800: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9bdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065804: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065808: BE882007
	s_cbranch_execnz 5883                                      // 00000006580C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065810: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065814: BE882000
	s_cbranch_execnz 5952                                      // 000000065818: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006581C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065820: BE882001
	s_cbranch_execnz 6021                                      // 000000065824: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065828: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006582C: BE882002
	s_cbranch_execnz 6090                                      // 000000065830: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa05c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065834: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065838: BE882003
	s_cbranch_execnz 6159                                      // 00000006583C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa17c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065840: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065844: BE882004
	s_cbranch_execnz 6228                                      // 000000065848: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa29c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006584C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065850: BE882005
	s_cbranch_execnz 6297                                      // 000000065854: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065858: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006585C: BE882006
	s_cbranch_execnz 6366                                      // 000000065860: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065864: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065868: BE882007
	s_cbranch_execnz 6435                                      // 00000006586C: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065870: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065874: BE882000
	s_cbranch_execnz 6504                                      // 000000065878: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa71c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006587C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065880: BE882001
	s_cbranch_execnz 6573                                      // 000000065884: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa83c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065888: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006588C: BE882002
	s_cbranch_execnz 6642                                      // 000000065890: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa95c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065894: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065898: BE882003
	s_cbranch_execnz 6711                                      // 00000006589C: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000658A4: BE882004
	s_cbranch_execnz 6780                                      // 0000000658A8: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000658B0: BE882005
	s_cbranch_execnz 6849                                      // 0000000658B4: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000658BC: BE882006
	s_cbranch_execnz 6918                                      // 0000000658C0: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaddc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000658C8: BE882007
	s_cbranch_execnz 6987                                      // 0000000658CC: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaefc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000658D4: BE882000
	s_cbranch_execnz 7056                                      // 0000000658D8: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb01c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000658E0: BE882001
	s_cbranch_execnz 7125                                      // 0000000658E4: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb13c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000658EC: BE882002
	s_cbranch_execnz 7194                                      // 0000000658F0: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb25c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000658F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000658F8: BE882003
	s_cbranch_execnz 7263                                      // 0000000658FC: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb37c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065900: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065904: BE882004
	s_cbranch_execnz 7332                                      // 000000065908: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb49c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006590C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065910: BE882005
	s_cbranch_execnz 7401                                      // 000000065914: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065918: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006591C: BE882006
	s_cbranch_execnz 7470                                      // 000000065920: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065924: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065928: BE882007
	s_cbranch_execnz 7539                                      // 00000006592C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065930: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065934: BE882000
	s_cbranch_execnz 7608                                      // 000000065938: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb91c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006593C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065940: BE882001
	s_cbranch_execnz 7677                                      // 000000065944: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065948: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006594C: BE882002
	s_cbranch_execnz 7746                                      // 000000065950: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065954: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065958: BE882003
	s_cbranch_execnz 7815                                      // 00000006595C: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065960: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065964: BE882004
	s_cbranch_execnz 7884                                      // 000000065968: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006596C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000065970: BE882005
	s_cbranch_execnz 7953                                      // 000000065974: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbebc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065978: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006597C: BE882006
	s_cbranch_execnz 8022                                      // 000000065980: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065984: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000065988: BE882007
	s_cbranch_execnz 8091                                      // 00000006598C: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065990: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065994: BE882000
	s_cbranch_execnz 8160                                      // 000000065998: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc21c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006599C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000659A0: BE802001
	s_cbranch_execnz 8229                                      // 0000000659A4: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc33c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659A8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000659AC: BE802002
	s_cbranch_execnz 8298                                      // 0000000659B0: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc45c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659B4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000659B8: BE802003
	s_cbranch_execnz 8367                                      // 0000000659BC: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc57c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659C0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000659C4: BE802004
	s_cbranch_execnz 8436                                      // 0000000659C8: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc69c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659CC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000659D0: BE802005
	s_cbranch_execnz 8505                                      // 0000000659D4: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc7bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659D8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000659DC: BE802006
	s_cbranch_execnz 8574                                      // 0000000659E0: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc8dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000659E4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000659E8: BE802007
	s_cbranch_execnz 8643                                      // 0000000659EC: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc9fc>
	s_nop 0                                                    // 0000000659F0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000659F4: BFB60003
	s_endpgm                                                   // 0000000659F8: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000659FC: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000065A08: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000065A0C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000065A14: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000065A18: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065A1C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000065A20: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000065A28: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000065A34: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065A38: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000065A3C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000065A40: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000065A48: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065A50: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000065A54: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000065A58: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000065A5C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065A60: BF870095
	.long 0xd71c008e                                           // 000000065A64: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000065A68: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000065A6C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000065A70: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065A78: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000065A7C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000065A84: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065A88: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 000000065A8C: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000065A94: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065A98: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000065A9C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000065AA4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000065AA8: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065AB0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000065AB4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000065AB8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065AC0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000065AC4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000065AC8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065AD0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000065AD4: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000065ADC: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000065AE4: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065AF0: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000065AF4: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000065AFC: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000065B08: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065B10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000065B14: BE882000
	s_cbranch_execz 65104                                      // 000000065B18: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d5c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000065B1C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000065B28: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000065B2C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 000000065B34: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 000000065B38: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065B3C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 000000065B40: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 000000065B48: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000065B54: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065B58: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 000000065B5C: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 000000065B60: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 000000065B68: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065B70: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000065B74: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000065B78: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 000000065B7C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065B80: BF870095
	.long 0xd71c008d                                           // 000000065B84: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000065B88: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000065B8C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000065B90: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065B98: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000065B9C: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000065BA4: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065BA8: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 000000065BAC: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 000000065BB4: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065BB8: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000065BBC: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 000000065BC4: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000065BC8: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065BD0: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 000000065BD4: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000065BD8: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065BE0: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 000000065BE4: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000065BE8: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065BF0: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000065BF4: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 000000065BFC: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000065C04: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065C10: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 000000065C14: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 000000065C1C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 000000065C28: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065C30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000065C34: BE882001
	s_cbranch_execz 65035                                      // 000000065C38: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d68>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000065C3C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 000000065C48: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 000000065C4C: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 000000065C54: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000065C58: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065C5C: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 000000065C60: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 000000065C68: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 000000065C74: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065C78: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 000000065C7C: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000065C80: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 000000065C88: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065C90: BF870121
	v_add_f32_e32 v128, v128, v141                             // 000000065C94: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 000000065C98: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 000000065C9C: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065CA0: BF870095
	.long 0xd71c0080                                           // 000000065CA4: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000065CA8: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 000000065CAC: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000065CB0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065CB8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 000000065CBC: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000065CC4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065CC8: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 000000065CCC: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000065CD4: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065CD8: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 000000065CDC: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000065CE4: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000065CE8: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065CF0: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000065CF4: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000065CF8: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D00: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000065D04: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000065D08: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D10: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000065D14: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000065D1C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000065D24: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D30: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000065D34: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 000000065D3C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 000000065D48: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065D50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000065D54: BE882002
	s_cbranch_execz 64966                                      // 000000065D58: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d74>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 000000065D5C: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000065D68: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000065D70: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000065D74: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D78: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000065D7C: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 000000065D84: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 000000065D90: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000065D94: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 000000065D98: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000065DA0: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000065DA4: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000065DA8: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 000000065DAC: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000065DB0: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000065DB8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065DBC: BF870095
	.long 0xd71c0072                                           // 000000065DC0: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 000000065DC4: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000065DC8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000065DCC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065DD4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000065DD8: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000065DE4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065DE8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000065DEC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000065DF4: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065DF8: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 000000065DFC: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000065E04: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000065E08: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065E10: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000065E14: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 000000065E18: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065E20: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000065E24: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 000000065E28: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065E30: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000065E34: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000065E3C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 000000065E44: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065E50: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 000000065E54: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 000000065E5C: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000065E68: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065E70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000065E74: BE882003
	s_cbranch_execz 64897                                      // 000000065E78: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d80>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 000000065E7C: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000065E88: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000065E90: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000065E94: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065E98: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000065E9C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000065EA4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000065EB0: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065EB4: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000065EB8: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000065EBC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000065EC4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065ECC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000065ED0: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000065ED4: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000065ED8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065EDC: BF870095
	.long 0xd71c0072                                           // 000000065EE0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000065EE4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000065EE8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000065EEC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065EF4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000065EF8: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000065F04: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F08: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000065F0C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000065F14: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F18: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 000000065F1C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000065F24: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 000000065F28: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F30: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000065F34: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 000000065F38: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F40: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 000000065F44: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 000000065F48: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F50: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 000000065F54: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000065F5C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 000000065F64: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065F70: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000065F74: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000065F7C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000065F88: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000065F90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000065F94: BE882004
	s_cbranch_execz 64828                                      // 000000065F98: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d8c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 000000065F9C: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000065FA8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000065FB0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000065FB4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065FB8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000065FBC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000065FC4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000065FD0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000065FD4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000065FD8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000065FDC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000065FE4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000065FEC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000065FF0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000065FF4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000065FF8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065FFC: BF870095
	.long 0xd71c0072                                           // 000000066000: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000066004: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000066008: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000006600C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066014: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 000000066018: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000066024: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066028: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000006602C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000066034: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066038: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000006603C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000066044: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000066048: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066050: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 000000066054: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 000000066058: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066060: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 000000066064: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 000000066068: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066070: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 000000066074: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000006607C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 000000066084: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066090: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000066094: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000006609C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000660A8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000660B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000660B4: BE882005
	s_cbranch_execz 64759                                      // 0000000660B8: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d98>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000660BC: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000660C8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000660D0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000660D4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000660D8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000660DC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000660E4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000660F0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000660F4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000660F8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000660FC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000066104: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006610C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000066110: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000066114: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000066118: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006611C: BF870095
	.long 0xd71c0072                                           // 000000066120: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000066124: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000066128: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000006612C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066134: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000066138: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 000000066140: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066148: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000006614C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000066154: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066158: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000006615C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000066164: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000066168: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066170: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000066174: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 000000066178: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066180: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 000000066184: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 000000066188: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066190: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000066194: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000006619C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000661A4: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000661B0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000661B4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000661BC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000661C8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000661D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000661D4: BE882006
	s_cbranch_execz 64690                                      // 0000000661D8: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000661DC: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000661E8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000661F0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000661F4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000661F8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000661FC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000066204: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000066210: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066214: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000066218: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000006621C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000066224: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006622C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000066230: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000066234: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000066238: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006623C: BF870095
	.long 0xd71c0072                                           // 000000066240: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000066244: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000066248: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000006624C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066254: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 000000066258: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000066264: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066268: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000006626C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000066274: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066278: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000006627C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000066284: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000066288: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066290: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000066294: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000066298: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000662A0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000662A4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000662A8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000662B0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000662B4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000662BC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000662C4: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000662D0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000662D4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000662DC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000662E8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000662F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000662F4: BE882007
	s_cbranch_execz 64621                                      // 0000000662F8: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000662FC: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000066308: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000066310: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000066314: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066318: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000006631C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000066324: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000066330: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066334: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000066338: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000006633C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000066344: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006634C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000066350: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000066354: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000066358: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006635C: BF870095
	.long 0xd71c0072                                           // 000000066360: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000066364: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000066368: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000006636C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066374: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 000000066378: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000066384: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066388: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000006638C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000066394: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066398: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000006639C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000663A4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000663A8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000663B0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000663B4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000663B8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000663C0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000663C4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000663C8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000663D0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000663D4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000663DC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000663E4: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000663F0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000663F4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000663FC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000066408: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066410: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000066414: BE882000
	s_cbranch_execz 64552                                      // 000000066418: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dbc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000006641C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000066428: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000006642C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000066434: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000066438: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006643C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000066440: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000066448: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000066454: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066458: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000006645C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000066460: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000066468: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066470: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000066474: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000066478: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000006647C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066480: BF870095
	.long 0xd71c0072                                           // 000000066484: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000066488: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000006648C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000066490: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066498: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000006649C: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000664A4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000664A8: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000664AC: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000664B4: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000664B8: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000664BC: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000664C4: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000664C8: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000664D0: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000664D4: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000664D8: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000664E0: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000664E4: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000664E8: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000664F0: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000664F4: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000664FC: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000066504: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066510: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000066514: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000006651C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000066528: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066530: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000066534: BE882001
	s_cbranch_execz 64483                                      // 000000066538: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dc8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000006653C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000066548: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000006654C: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 000000066554: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066558: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006655C: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000066560: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000066568: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 000000066570: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000006657C: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000066580: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 000000066584: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 00000006658C: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066590: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000066594: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000066598: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000006659C: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000665A0: BF870095
	.long 0xd71c0071                                           // 0000000665A4: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000665A8: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000665AC: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000665B0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000665B8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000665BC: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000665C4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000665C8: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000665CC: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000665D4: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000665D8: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000665DC: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000665E4: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000665E8: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000665F0: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000665F4: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000665F8: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066600: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000066604: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000066608: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066610: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000066614: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000006661C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000066624: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066630: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000066634: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000006663C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000066648: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066650: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000066654: BE882002
	s_cbranch_execz 64414                                      // 000000066658: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 00000006665C: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000066668: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000066670: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066674: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066678: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000006667C: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 000000066684: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000066690: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066694: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000066698: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000006669C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000666A4: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000666AC: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000666B0: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000666B4: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000666B8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000666BC: BF870095
	.long 0xd71c006a                                           // 0000000666C0: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000666C4: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000666C8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000666CC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000666D4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000666D8: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000666E4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000666E8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000666EC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000666F4: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000666F8: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000666FC: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000066704: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000066708: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066710: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000066714: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000066718: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066720: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000066724: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000066728: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066730: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000066734: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000006673C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000066744: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066750: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000066754: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 00000006675C: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000066768: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066770: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000066774: BE882003
	s_cbranch_execz 64345                                      // 000000066778: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3de0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 00000006677C: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000066788: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000066790: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066794: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066798: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000006679C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000667A4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000667B0: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000667B4: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000667B8: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000667C4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000667C8: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000667CC: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000667D4: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000667D8: 7ED44B6A
	.long 0xd71c006a                                           // 0000000667DC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000667E0: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000667E4: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000667E8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000667EC: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000667F4: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066800: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000066804: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000066808: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000066810: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000066814: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000066818: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000066820: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000066824: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000066828: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000066830: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066834: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000066838: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000066840: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066844: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000066848: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000066850: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066858: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000006685C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000066864: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000066870: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000066878: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000006687C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000066888: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066890: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000066894: BE882004
	s_cbranch_execz 64276                                      // 000000066898: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dec>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000006689C: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000668A8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000668B0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000668B4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000668B8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000668BC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000668C4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000668D0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000668D4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000668D8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000668DC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000668E4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000668EC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000668F0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000668F4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000668F8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000668FC: BF870095
	.long 0xd71c006a                                           // 000000066900: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000066904: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000066908: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000006690C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066914: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000066918: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000066924: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066928: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000006692C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000066934: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066938: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000006693C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000066944: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000066948: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066950: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000066954: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000066958: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066960: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000066964: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000066968: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066970: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000066974: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000006697C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000066984: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066990: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000066994: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000006699C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000669A8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000669B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000669B4: BE882005
	s_cbranch_execz 64207                                      // 0000000669B8: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3df8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000669BC: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000669C8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000669D0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000669D4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000669D8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000669DC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000669E4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000669F0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000669F4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000669F8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000669FC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000066A04: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066A0C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000066A10: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000066A14: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000066A18: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A1C: BF870095
	.long 0xd71c006a                                           // 000000066A20: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000066A24: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000066A28: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000066A2C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A34: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000066A38: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000066A40: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A48: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000066A4C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000066A54: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A58: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000066A5C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000066A64: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000066A68: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A70: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000066A74: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000066A78: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A80: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000066A84: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000066A88: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066A90: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000066A94: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000066A9C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000066AA4: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066AB0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000066AB4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000066ABC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000066AC8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066AD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000066AD4: BE882006
	s_cbranch_execz 64138                                      // 000000066AD8: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e04>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000066ADC: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000066AE8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000066AF0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066AF4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066AF8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000066AFC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000066B04: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000066B10: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066B14: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000066B18: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000066B1C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000066B24: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066B2C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000066B30: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000066B34: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000066B38: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066B3C: BF870095
	.long 0xd71c006a                                           // 000000066B40: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000066B44: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000066B48: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000066B4C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066B54: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 000000066B58: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000066B64: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066B68: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000066B6C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000066B74: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066B78: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000066B7C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000066B84: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000066B88: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066B90: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000066B94: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000066B98: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066BA0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000066BA4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000066BA8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066BB0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000066BB4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000066BBC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 000000066BC4: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066BD0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000066BD4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000066BDC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000066BE8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066BF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000066BF4: BE882007
	s_cbranch_execz 64069                                      // 000000066BF8: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e10>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 000000066BFC: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000066C08: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000066C10: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066C14: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066C18: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000066C1C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000066C24: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000066C30: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066C34: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000066C38: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000066C3C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000066C44: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066C4C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000066C50: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000066C54: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000066C58: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066C5C: BF870095
	.long 0xd71c006a                                           // 000000066C60: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000066C64: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000066C68: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000066C6C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066C74: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 000000066C78: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000066C84: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066C88: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000066C8C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000066C94: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066C98: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000066C9C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000066CA4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000066CA8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066CB0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000066CB4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000066CB8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066CC0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000066CC4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000066CC8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066CD0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000066CD4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000066CDC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 000000066CE4: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066CF0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000066CF4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000066CFC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000066D08: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066D10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000066D14: BE882000
	s_cbranch_execz 64000                                      // 000000066D18: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e1c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000066D1C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000066D28: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000066D2C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 000000066D34: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000066D38: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066D3C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000066D40: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000066D48: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000066D54: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066D58: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000066D5C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000066D60: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000066D68: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066D70: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000066D74: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000066D78: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000066D7C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066D80: BF870095
	.long 0xd71c006a                                           // 000000066D84: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000066D88: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000066D8C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000066D90: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066D98: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000066D9C: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000066DA4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066DA8: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 000000066DAC: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 000000066DB4: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066DB8: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000066DBC: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000066DC4: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 000000066DC8: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066DD0: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000066DD4: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000066DD8: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066DE0: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000066DE4: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000066DE8: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066DF0: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000066DF4: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 000000066DFC: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000066E04: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066E10: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000066E14: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000066E1C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 000000066E28: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066E30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000066E34: BE882001
	s_cbranch_execz 63931                                      // 000000066E38: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e28>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 000000066E3C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 000000066E48: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 000000066E4C: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 000000066E54: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000066E58: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066E5C: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 000000066E60: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000066E68: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 000000066E70: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000066E7C: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000066E80: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 000000066E84: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 000000066E8C: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066E90: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000066E94: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000066E98: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000066E9C: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066EA0: BF870095
	.long 0xd71c0069                                           // 000000066EA4: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000066EA8: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000066EAC: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000066EB0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066EB8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 000000066EBC: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000066EC4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066EC8: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 000000066ECC: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000066ED4: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066ED8: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000066EDC: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000066EE4: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000066EE8: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066EF0: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000066EF4: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000066EF8: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066F00: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000066F04: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000066F08: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066F10: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000066F14: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000066F1C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000066F24: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066F30: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000066F34: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 000000066F3C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 000000066F48: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000066F50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000066F54: BE882002
	s_cbranch_execz 63862                                      // 000000066F58: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e34>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 000000066F5C: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000066F68: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000066F70: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000066F74: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066F78: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000066F7C: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 000000066F84: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 000000066F90: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000066F94: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 000000066F98: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000066F9C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 000000066FA4: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000066FAC: BF870121
	v_add_f32_e32 v98, v98, v105                               // 000000066FB0: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 000000066FB4: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 000000066FB8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066FBC: BF870095
	.long 0xd71c0062                                           // 000000066FC0: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 000000066FC4: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000066FC8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000066FCC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066FD4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000066FD8: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000066FE4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066FE8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000066FEC: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 000000066FF4: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066FF8: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 000000066FFC: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 000000067004: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 000000067008: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067010: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 000000067014: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 000000067018: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067020: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 000000067024: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 000000067028: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067030: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 000000067034: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000006703C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 000000067044: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067050: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 000000067054: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000006705C: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000067068: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067070: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000067074: BE882003
	s_cbranch_execz 63793                                      // 000000067078: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e40>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000006707C: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000067088: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000067090: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000067094: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067098: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000006709C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000670A4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000670B0: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000670B4: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000670B8: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000670C4: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000670C8: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000670CC: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000670D4: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000670D8: 7EC44B62
	.long 0xd71c0062                                           // 0000000670DC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000670E0: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000670E4: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000670E8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000670EC: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000670F4: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067100: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 000000067104: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000067108: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000067110: BF870291
	v_rcp_f32_e32 v100, v99                                    // 000000067114: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 000000067118: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000067120: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 000000067124: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 000000067128: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 000000067130: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067134: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 000000067138: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 000000067140: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067144: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 000000067148: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 000000067150: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067158: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000006715C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 000000067164: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 000000067170: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 000000067178: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000006717C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000067188: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067190: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000067194: BE882004
	s_cbranch_execz 63724                                      // 000000067198: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e4c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000006719C: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000671A8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000671B0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000671B4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000671B8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000671BC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000671C4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000671D0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000671D4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000671D8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000671DC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000671E4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000671EC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000671F0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000671F4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000671F8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000671FC: BF870095
	.long 0xd71c0062                                           // 000000067200: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000067204: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000067208: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000006720C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067214: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 000000067218: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000067224: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067228: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000006722C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000067234: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067238: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000006723C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000067244: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000067248: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067250: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 000000067254: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 000000067258: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067260: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 000000067264: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 000000067268: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067270: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 000000067274: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000006727C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 000000067284: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067290: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000067294: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000006729C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000672A8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000672B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000672B4: BE882005
	s_cbranch_execz 63655                                      // 0000000672B8: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e58>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000672BC: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000672C8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000672D0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000672D4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000672D8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000672DC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000672E4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000672F0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000672F4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000672F8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000672FC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000067304: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006730C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000067310: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000067314: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000067318: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006731C: BF870095
	.long 0xd71c0062                                           // 000000067320: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000067324: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000067328: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000006732C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067334: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000067338: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000067340: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067348: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000006734C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000067354: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067358: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000006735C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000067364: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000067368: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067370: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000067374: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 000000067378: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067380: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 000000067384: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 000000067388: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067390: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000067394: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000006739C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000673A4: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000673B0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000673B4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000673BC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000673C8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000673D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000673D4: BE882006
	s_cbranch_execz 63586                                      // 0000000673D8: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e64>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000673DC: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000673E8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000673F0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000673F4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000673F8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000673FC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000067404: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000067410: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067414: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000067418: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000006741C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000067424: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006742C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000067430: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000067434: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000067438: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006743C: BF870095
	.long 0xd71c0062                                           // 000000067440: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000067444: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000067448: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000006744C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067454: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000067458: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000067464: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067468: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000006746C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000067474: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067478: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000006747C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000067484: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000067488: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067490: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000067494: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000067498: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000674A0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000674A4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000674A8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000674B0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000674B4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000674BC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000674C4: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000674D0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000674D4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000674DC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000674E8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000674F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000674F4: BE882007
	s_cbranch_execz 63517                                      // 0000000674F8: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e70>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000674FC: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000067508: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000067510: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000067514: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067518: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000006751C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000067524: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000067530: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067534: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000067538: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000006753C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000067544: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006754C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000067550: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000067554: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000067558: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006755C: BF870095
	.long 0xd71c0062                                           // 000000067560: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000067564: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000067568: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000006756C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067574: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000067578: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000067584: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067588: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000006758C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000067594: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067598: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000006759C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000675A4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000675A8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000675B0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000675B4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000675B8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000675C0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000675C4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000675C8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000675D0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000675D4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000675DC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000675E4: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000675F0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000675F4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000675FC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000067608: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067610: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000067614: BE882000
	s_cbranch_execz 63448                                      // 000000067618: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e7c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000006761C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000067628: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000006762C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000067634: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000067638: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006763C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000067640: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000067648: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000067654: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067658: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000006765C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000067660: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000067668: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067670: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000067674: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000067678: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000006767C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067680: BF870095
	.long 0xd71c0062                                           // 000000067684: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000067688: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000006768C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000067690: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067698: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000006769C: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000676A4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000676A8: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000676AC: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000676B4: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000676B8: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000676BC: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000676C4: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000676C8: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000676D0: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000676D4: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000676D8: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000676E0: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000676E4: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000676E8: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000676F0: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000676F4: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000676FC: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000067704: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067710: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000067714: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000006771C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000067728: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067730: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000067734: BE882001
	s_cbranch_execz 63379                                      // 000000067738: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e88>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000006773C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000067748: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000006774C: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000067754: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067758: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006775C: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000067760: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067768: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000067770: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000006777C: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000067780: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000067784: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 00000006778C: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067790: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000067794: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000067798: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000006779C: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000677A0: BF870095
	.long 0xd71c0061                                           // 0000000677A4: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000677A8: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000677AC: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000677B0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000677B8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000677BC: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000677C4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000677C8: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000677CC: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000677D4: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000677D8: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000677DC: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000677E4: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000677E8: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000677F0: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000677F4: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000677F8: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067800: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000067804: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000067808: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067810: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000067814: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 00000006781C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000067824: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067830: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000067834: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 00000006783C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000067848: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067850: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000067854: BE882002
	s_cbranch_execz 63310                                      // 000000067858: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e94>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 00000006785C: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067868: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067870: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067874: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067878: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000006787C: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000067884: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000067890: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067894: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000067898: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000006789C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000678A4: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000678AC: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000678B0: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000678B4: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000678B8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000678BC: BF870095
	.long 0xd71c005a                                           // 0000000678C0: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000678C4: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000678C8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000678CC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000678D4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000678D8: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000678E4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000678E8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000678EC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000678F4: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000678F8: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000678FC: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000067904: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000067908: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067910: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000067914: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000067918: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067920: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000067924: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000067928: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067930: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000067934: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000006793C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000067944: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067950: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000067954: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 00000006795C: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067968: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067970: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000067974: BE882003
	s_cbranch_execz 63241                                      // 000000067978: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000006797C: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067988: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067990: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067994: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067998: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000006799C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000679A4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000679B0: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000679B4: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000679B8: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000679C4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000679C8: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000679CC: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000679D4: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000679D8: 7EB44B5A
	.long 0xd71c005a                                           // 0000000679DC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000679E0: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000679E4: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000679E8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000679EC: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000679F4: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067A00: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000067A04: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000067A08: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000067A10: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000067A14: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000067A18: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000067A20: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000067A24: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000067A28: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000067A30: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067A34: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000067A38: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000067A40: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067A44: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000067A48: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000067A50: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067A58: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000067A5C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000067A64: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000067A70: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000067A78: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000067A7C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067A88: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067A90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000067A94: BE882004
	s_cbranch_execz 63172                                      // 000000067A98: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eac>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000067A9C: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067AA8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067AB0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067AB4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067AB8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000067ABC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000067AC4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000067AD0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067AD4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000067AD8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067ADC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000067AE4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067AEC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000067AF0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000067AF4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000067AF8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067AFC: BF870095
	.long 0xd71c005a                                           // 000000067B00: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000067B04: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000067B08: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000067B0C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B14: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000067B18: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000067B24: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B28: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000067B2C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000067B34: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B38: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000067B3C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000067B44: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000067B48: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B50: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000067B54: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000067B58: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B60: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000067B64: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000067B68: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B70: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000067B74: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000067B7C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000067B84: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067B90: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000067B94: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000067B9C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067BA8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067BB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000067BB4: BE882005
	s_cbranch_execz 63103                                      // 000000067BB8: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000067BBC: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067BC8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067BD0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067BD4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067BD8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000067BDC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000067BE4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000067BF0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067BF4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000067BF8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067BFC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000067C04: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067C0C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000067C10: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000067C14: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000067C18: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C1C: BF870095
	.long 0xd71c005a                                           // 000000067C20: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000067C24: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000067C28: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000067C2C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C34: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000067C38: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000067C40: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C48: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000067C4C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000067C54: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C58: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000067C5C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000067C64: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000067C68: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C70: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000067C74: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000067C78: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C80: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000067C84: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000067C88: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067C90: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000067C94: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000067C9C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000067CA4: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067CB0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000067CB4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000067CBC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067CC8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067CD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000067CD4: BE882006
	s_cbranch_execz 63034                                      // 000000067CD8: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000067CDC: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067CE8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067CF0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067CF4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067CF8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000067CFC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000067D04: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000067D10: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067D14: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000067D18: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067D1C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000067D24: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067D2C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000067D30: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000067D34: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000067D38: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067D3C: BF870095
	.long 0xd71c005a                                           // 000000067D40: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000067D44: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000067D48: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000067D4C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067D54: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 000000067D58: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000067D64: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067D68: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000067D6C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000067D74: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067D78: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000067D7C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000067D84: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000067D88: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067D90: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000067D94: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000067D98: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067DA0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000067DA4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000067DA8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067DB0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000067DB4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000067DBC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000067DC4: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067DD0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000067DD4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000067DDC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067DE8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067DF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000067DF4: BE882007
	s_cbranch_execz 62965                                      // 000000067DF8: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000067DFC: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000067E08: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067E10: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067E14: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067E18: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000067E1C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000067E24: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000067E30: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067E34: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000067E38: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067E3C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000067E44: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067E4C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000067E50: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000067E54: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000067E58: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067E5C: BF870095
	.long 0xd71c005a                                           // 000000067E60: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000067E64: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000067E68: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000067E6C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067E74: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 000000067E78: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000067E84: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067E88: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000067E8C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000067E94: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067E98: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000067E9C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000067EA4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000067EA8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067EB0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000067EB4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000067EB8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067EC0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000067EC4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000067EC8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067ED0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000067ED4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000067EDC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000067EE4: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067EF0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000067EF4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000067EFC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000067F08: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000067F10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000067F14: BE882000
	s_cbranch_execz 62896                                      // 000000067F18: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3edc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000067F1C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000067F28: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000067F2C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000067F34: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000067F38: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067F3C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000067F40: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000067F48: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000067F54: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000067F58: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000067F5C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000067F60: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000067F68: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000067F70: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000067F74: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000067F78: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000067F7C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067F80: BF870095
	.long 0xd71c005a                                           // 000000067F84: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000067F88: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000067F8C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000067F90: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067F98: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000067F9C: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000067FA4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067FA8: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 000000067FAC: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 000000067FB4: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067FB8: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000067FBC: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000067FC4: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000067FC8: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067FD0: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000067FD4: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000067FD8: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067FE0: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000067FE4: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000067FE8: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000067FF0: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000067FF4: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 000000067FFC: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000068004: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068010: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 000000068014: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000006801C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 000000068028: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068030: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000068034: BE882001
	s_cbranch_execz 62827                                      // 000000068038: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000006803C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 000000068048: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000006804C: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 000000068054: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000068058: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006805C: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 000000068060: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000068068: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 000000068070: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000006807C: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000068080: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 000000068084: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000006808C: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068090: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000068094: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000068098: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000006809C: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000680A0: BF870095
	.long 0xd71c0059                                           // 0000000680A4: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000680A8: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000680AC: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000680B0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000680B8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000680BC: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000680C4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000680C8: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000680CC: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000680D4: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000680D8: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000680DC: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000680E4: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000680E8: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000680F0: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000680F4: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000680F8: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068100: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000068104: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000068108: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068110: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 000000068114: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000006811C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 000000068124: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068130: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 000000068134: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000006813C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 000000068148: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068150: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000068154: BE882002
	s_cbranch_execz 62758                                      // 000000068158: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 00000006815C: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000068168: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000068170: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000068174: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068178: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000006817C: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 000000068184: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 000000068190: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068194: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 000000068198: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000006819C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000681A4: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000681AC: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000681B0: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000681B4: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000681B8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000681BC: BF870095
	.long 0xd71c0052                                           // 0000000681C0: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000681C4: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000681C8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000681CC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000681D4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000681D8: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000681E4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000681E8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000681EC: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000681F4: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000681F8: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000681FC: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000068204: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000068208: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068210: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 000000068214: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 000000068218: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068220: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 000000068224: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 000000068228: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068230: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 000000068234: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000006823C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 000000068244: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068250: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 000000068254: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000006825C: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000068268: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068270: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000068274: BE882003
	s_cbranch_execz 62689                                      // 000000068278: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f00>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000006827C: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000068288: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000068290: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000068294: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068298: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000006829C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000682A4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000682B0: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000682B4: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000682B8: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000682C4: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000682C8: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000682CC: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000682D4: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000682D8: 7EA44B52
	.long 0xd71c0052                                           // 0000000682DC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000682E0: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000682E4: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000682E8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000682EC: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000682F4: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068300: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 000000068304: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000068308: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000068310: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000068314: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000068318: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000068320: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000068324: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000068328: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000068330: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068334: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 000000068338: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 000000068340: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068344: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000068348: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 000000068350: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068358: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000006835C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 000000068364: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 000000068370: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 000000068378: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000006837C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000068388: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068390: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000068394: BE882004
	s_cbranch_execz 62620                                      // 000000068398: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f0c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000006839C: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000683A8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000683B0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000683B4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000683B8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000683BC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000683C4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000683D0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000683D4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000683D8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000683DC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000683E4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000683EC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000683F0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000683F4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000683F8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000683FC: BF870095
	.long 0xd71c0052                                           // 000000068400: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000068404: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000068408: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000006840C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068414: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000068418: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000068424: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068428: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000006842C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000068434: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068438: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000006843C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000068444: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000068448: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068450: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000068454: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000068458: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068460: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000068464: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000068468: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068470: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 000000068474: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000006847C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 000000068484: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068490: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000068494: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000006849C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000684A8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000684B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000684B4: BE882005
	s_cbranch_execz 62551                                      // 0000000684B8: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f18>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000684BC: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000684C8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000684D0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000684D4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000684D8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000684DC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000684E4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000684F0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000684F4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000684F8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000684FC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000068504: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006850C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000068510: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000068514: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000068518: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006851C: BF870095
	.long 0xd71c0052                                           // 000000068520: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000068524: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000068528: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000006852C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068534: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000068538: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000068540: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068548: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000006854C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000068554: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068558: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000006855C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000068564: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000068568: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068570: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000068574: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 000000068578: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068580: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 000000068584: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 000000068588: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068590: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000068594: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000006859C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000685A4: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000685B0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000685B4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000685BC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000685C8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000685D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000685D4: BE882006
	s_cbranch_execz 62482                                      // 0000000685D8: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f24>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000685DC: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000685E8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000685F0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000685F4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000685F8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000685FC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000068604: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000068610: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068614: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000068618: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000006861C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000068624: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006862C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000068630: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000068634: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000068638: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006863C: BF870095
	.long 0xd71c0052                                           // 000000068640: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000068644: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000068648: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000006864C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068654: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000068658: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000068664: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068668: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000006866C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000068674: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068678: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000006867C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000068684: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000068688: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068690: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000068694: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000068698: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000686A0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000686A4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000686A8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000686B0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000686B4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000686BC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000686C4: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000686D0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000686D4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000686DC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000686E8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000686F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000686F4: BE882007
	s_cbranch_execz 62413                                      // 0000000686F8: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f30>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000686FC: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000068708: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000068710: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000068714: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068718: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000006871C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000068724: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000068730: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068734: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000068738: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000006873C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000068744: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006874C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000068750: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000068754: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000068758: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006875C: BF870095
	.long 0xd71c0052                                           // 000000068760: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000068764: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000068768: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000006876C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068774: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000068778: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000068784: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068788: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000006878C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000068794: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068798: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000006879C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000687A4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000687A8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000687B0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000687B4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000687B8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000687C0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000687C4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000687C8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000687D0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000687D4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000687DC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000687E4: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000687F0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000687F4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000687FC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000068808: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068810: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000068814: BE882000
	s_cbranch_execz 62344                                      // 000000068818: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f3c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000006881C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000068828: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000006882C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000068834: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000068838: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006883C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000068840: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000068848: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000068854: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068858: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000006885C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000068860: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000068868: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068870: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000068874: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000068878: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000006887C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068880: BF870095
	.long 0xd71c0052                                           // 000000068884: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000068888: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000006888C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000068890: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068898: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000006889C: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000688A4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000688A8: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000688AC: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000688B4: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000688B8: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000688BC: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000688C4: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000688C8: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000688D0: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000688D4: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000688D8: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000688E0: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000688E4: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000688E8: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000688F0: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000688F4: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000688FC: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000068904: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068910: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000068914: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 00000006891C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000068928: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068930: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000068934: BE882001
	s_cbranch_execz 62275                                      // 000000068938: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f48>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 00000006893C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000068948: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 00000006894C: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000068954: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068958: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006895C: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000068960: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068968: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000068970: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000006897C: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000068980: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000068984: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000006898C: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068990: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000068994: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000068998: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000006899C: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000689A0: BF870095
	.long 0xd71c0051                                           // 0000000689A4: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000689A8: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000689AC: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000689B0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000689B8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000689BC: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000689C4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000689C8: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000689CC: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000689D4: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000689D8: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000689DC: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000689E4: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000689E8: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000689F0: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000689F4: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000689F8: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068A00: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000068A04: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000068A08: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068A10: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000068A14: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000068A1C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000068A24: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068A30: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000068A34: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000068A3C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000068A48: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068A50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000068A54: BE882002
	s_cbranch_execz 62206                                      // 000000068A58: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f54>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000068A5C: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000068A68: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000068A70: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068A74: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068A78: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000068A7C: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000068A84: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000068A90: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068A94: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000068A98: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068A9C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000068AA4: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068AAC: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000068AB0: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000068AB4: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000068AB8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068ABC: BF870095
	.long 0xd71c004a                                           // 000000068AC0: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000068AC4: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000068AC8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000068ACC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068AD4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000068AD8: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000068AE4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068AE8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000068AEC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000068AF4: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068AF8: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000068AFC: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000068B04: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000068B08: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068B10: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000068B14: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000068B18: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068B20: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000068B24: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000068B28: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068B30: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000068B34: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000068B3C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000068B44: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068B50: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000068B54: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000068B5C: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000068B68: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068B70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000068B74: BE882003
	s_cbranch_execz 62137                                      // 000000068B78: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f60>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000068B7C: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000068B88: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000068B90: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068B94: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068B98: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000068B9C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000068BA4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000068BB0: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068BB4: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000068BB8: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000068BC4: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000068BC8: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068BCC: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000068BD4: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000068BD8: 7E944B4A
	.long 0xd71c004a                                           // 000000068BDC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000068BE0: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068BE4: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000068BE8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000068BEC: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000068BF4: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068C00: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000068C04: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000068C08: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000068C10: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000068C14: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000068C18: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000068C20: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000068C24: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000068C28: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000068C30: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068C34: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000068C38: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000068C40: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068C44: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000068C48: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000068C50: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068C58: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000068C5C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000068C64: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000068C70: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000068C78: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000068C7C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000068C88: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068C90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000068C94: BE882004
	s_cbranch_execz 62068                                      // 000000068C98: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f6c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000068C9C: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000068CA8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000068CB0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068CB4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068CB8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000068CBC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000068CC4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000068CD0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068CD4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000068CD8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068CDC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000068CE4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068CEC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000068CF0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000068CF4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000068CF8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068CFC: BF870095
	.long 0xd71c004a                                           // 000000068D00: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000068D04: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000068D08: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000068D0C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D14: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000068D18: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000068D24: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D28: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000068D2C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000068D34: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D38: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000068D3C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000068D44: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000068D48: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D50: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000068D54: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000068D58: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D60: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000068D64: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000068D68: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D70: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000068D74: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000068D7C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000068D84: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068D90: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000068D94: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000068D9C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000068DA8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068DB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000068DB4: BE882005
	s_cbranch_execz 61999                                      // 000000068DB8: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f78>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 000000068DBC: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000068DC8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000068DD0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068DD4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068DD8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000068DDC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000068DE4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000068DF0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068DF4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000068DF8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068DFC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000068E04: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068E0C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000068E10: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000068E14: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000068E18: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E1C: BF870095
	.long 0xd71c004a                                           // 000000068E20: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000068E24: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000068E28: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000068E2C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E34: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000068E38: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000068E40: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E48: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000068E4C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000068E54: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E58: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000068E5C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000068E64: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000068E68: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E70: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000068E74: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000068E78: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E80: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 000000068E84: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000068E88: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068E90: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000068E94: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000068E9C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 000000068EA4: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068EB0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000068EB4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000068EBC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000068EC8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068ED0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000068ED4: BE882006
	s_cbranch_execz 61930                                      // 000000068ED8: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f84>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000068EDC: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000068EE8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000068EF0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000068EF4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068EF8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000068EFC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000068F04: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000068F10: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000068F14: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000068F18: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000068F1C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000068F24: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000068F2C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000068F30: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000068F34: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000068F38: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068F3C: BF870095
	.long 0xd71c004a                                           // 000000068F40: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000068F44: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000068F48: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000068F4C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068F54: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000068F58: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000068F64: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068F68: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000068F6C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000068F74: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068F78: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000068F7C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000068F84: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000068F88: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068F90: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000068F94: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000068F98: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068FA0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000068FA4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000068FA8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068FB0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000068FB4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000068FBC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 000000068FC4: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000068FD0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000068FD4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000068FDC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000068FE8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000068FF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000068FF4: BE882007
	s_cbranch_execz 61861                                      // 000000068FF8: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f90>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 000000068FFC: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000069008: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000069010: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000069014: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069018: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000006901C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000069024: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000069030: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069034: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000069038: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000006903C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000069044: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006904C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000069050: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000069054: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000069058: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006905C: BF870095
	.long 0xd71c004a                                           // 000000069060: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000069064: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000069068: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000006906C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069074: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000069078: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000069084: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069088: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000006908C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000069094: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069098: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000006909C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000690A4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000690A8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000690B0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000690B4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000690B8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000690C0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000690C4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000690C8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000690D0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000690D4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000690DC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000690E4: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000690F0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000690F4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000690FC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000069108: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069110: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000069114: BE882000
	s_cbranch_execz 61792                                      // 000000069118: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f9c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 00000006911C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000069128: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 00000006912C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000069134: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000069138: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006913C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000069140: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000069148: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000069154: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069158: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000006915C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000069160: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000069168: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069170: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000069174: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000069178: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000006917C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069180: BF870095
	.long 0xd71c004a                                           // 000000069184: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000069188: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000006918C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000069190: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069198: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000006919C: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000691A4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000691A8: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000691AC: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000691B4: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000691B8: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000691BC: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000691C4: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000691C8: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000691D0: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000691D4: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000691D8: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000691E0: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000691E4: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000691E8: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000691F0: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000691F4: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000691FC: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000069204: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069210: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000069214: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000006921C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000069228: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069230: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000069234: BE882001
	s_cbranch_execz 61723                                      // 000000069238: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000006923C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000069248: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000006924C: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 000000069254: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000069258: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006925C: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000069260: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000069268: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000069270: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000006927C: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000069280: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 000000069284: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 00000006928C: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069290: BF870121
	v_add_f32_e32 v73, v73, v74                                // 000000069294: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000069298: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000006929C: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000692A0: BF870095
	.long 0xd71c0049                                           // 0000000692A4: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000692A8: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000692AC: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000692B0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000692B8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000692BC: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000692C4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000692C8: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000692CC: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000692D4: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000692D8: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000692DC: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000692E4: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000692E8: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000692F0: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000692F4: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000692F8: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069300: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000069304: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000069308: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069310: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000069314: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000006931C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000069324: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069330: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000069334: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000006933C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000069348: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069350: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000069354: BE882002
	s_cbranch_execz 61654                                      // 000000069358: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 00000006935C: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000069368: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000069370: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000069374: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069378: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000006937C: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 000000069384: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000069390: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069394: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000069398: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000006939C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000693A4: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000693AC: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000693B0: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000693B4: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000693B8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000693BC: BF870095
	.long 0xd71c0042                                           // 0000000693C0: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000693C4: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000693C8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000693CC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000693D4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000693D8: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000693E4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000693E8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000693EC: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000693F4: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000693F8: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000693FC: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000069404: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000069408: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069410: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000069414: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000069418: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069420: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000069424: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000069428: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069430: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000069434: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000006943C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000069444: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069450: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000069454: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 00000006945C: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000069468: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069470: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000069474: BE882003
	s_cbranch_execz 61585                                      // 000000069478: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 00000006947C: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000069488: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000069490: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000069494: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069498: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000006949C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000694A4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000694B0: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000694B4: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000694B8: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000694C4: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000694C8: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000694CC: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000694D4: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000694D8: 7E844B42
	.long 0xd71c0042                                           // 0000000694DC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000694E0: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000694E4: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000694E8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000694EC: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000694F4: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069500: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000069504: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000069508: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000069510: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000069514: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000069518: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000069520: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000069524: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000069528: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000069530: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069534: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000069538: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000069540: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069544: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000069548: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000069550: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069558: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000006955C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000069564: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000069570: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000069578: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000006957C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000069588: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069590: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000069594: BE882004
	s_cbranch_execz 61516                                      // 000000069598: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fcc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 00000006959C: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000695A8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000695B0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000695B4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000695B8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000695BC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000695C4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000695D0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000695D4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000695D8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000695DC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000695E4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000695EC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000695F0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000695F4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000695F8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000695FC: BF870095
	.long 0xd71c0042                                           // 000000069600: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000069604: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000069608: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000006960C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069614: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000069618: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000069624: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069628: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000006962C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000069634: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069638: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000006963C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000069644: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000069648: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069650: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000069654: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000069658: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069660: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000069664: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000069668: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069670: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000069674: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000006967C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000069684: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069690: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000069694: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000006969C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000696A8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000696B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000696B4: BE882005
	s_cbranch_execz 61447                                      // 0000000696B8: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000696BC: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000696C8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000696D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000696D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000696D8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000696DC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000696E4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000696F0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000696F4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000696F8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000696FC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000069704: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006970C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000069710: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000069714: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000069718: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006971C: BF870095
	.long 0xd71c0042                                           // 000000069720: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000069724: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000069728: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000006972C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069734: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000069738: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000069740: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069748: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000006974C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000069754: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069758: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000006975C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000069764: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000069768: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069770: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000069774: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000069778: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069780: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000069784: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000069788: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069790: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000069794: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000006979C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000697A4: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000697B0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000697B4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000697BC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000697C8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000697D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000697D4: BE882006
	s_cbranch_execz 61378                                      // 0000000697D8: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000697DC: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000697E8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000697F0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000697F4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000697F8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000697FC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000069804: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000069810: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069814: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000069818: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000006981C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000069824: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006982C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000069830: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000069834: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000069838: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006983C: BF870095
	.long 0xd71c0042                                           // 000000069840: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000069844: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000069848: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000006984C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069854: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000069858: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000069864: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069868: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000006986C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000069874: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069878: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000006987C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000069884: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000069888: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069890: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000069894: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000069898: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000698A0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000698A4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000698A8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000698B0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000698B4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000698BC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000698C4: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000698D0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000698D4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000698DC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000698E8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000698F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000698F4: BE882007
	s_cbranch_execz 61309                                      // 0000000698F8: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000698FC: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000069908: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000069910: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000069914: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069918: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000006991C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000069924: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000069930: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069934: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000069938: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000006993C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000069944: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006994C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000069950: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000069954: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000069958: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006995C: BF870095
	.long 0xd71c0042                                           // 000000069960: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000069964: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000069968: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000006996C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069974: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000069978: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000069984: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069988: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000006998C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000069994: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069998: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000006999C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000699A4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000699A8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000699B0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000699B4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000699B8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000699C0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000699C4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000699C8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000699D0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000699D4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000699DC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000699E4: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000699F0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000699F4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000699FC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000069A08: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069A10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000069A14: BE882000
	s_cbranch_execz 61240                                      // 000000069A18: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ffc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000069A1C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000069A28: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000069A2C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000069A34: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000069A38: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069A3C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000069A40: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000069A48: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000069A54: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069A58: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000069A5C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000069A60: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000069A68: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069A70: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000069A74: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000069A78: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000069A7C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069A80: BF870095
	.long 0xd71c0042                                           // 000000069A84: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000069A88: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000069A8C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000069A90: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069A98: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000069A9C: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000069AA4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069AA8: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000069AAC: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000069AB4: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069AB8: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000069ABC: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000069AC4: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000069AC8: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069AD0: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000069AD4: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000069AD8: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069AE0: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000069AE4: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000069AE8: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069AF0: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000069AF4: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000069AFC: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000069B04: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069B10: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000069B14: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000069B1C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000069B28: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069B30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000069B34: BE882001
	s_cbranch_execz 61171                                      // 000000069B38: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4008>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000069B3C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000069B48: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000069B4C: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000069B54: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000069B58: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069B5C: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000069B60: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000069B68: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000069B70: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000069B7C: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000069B80: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000069B84: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000069B8C: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069B90: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000069B94: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000069B98: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000069B9C: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069BA0: BF870095
	.long 0xd71c0041                                           // 000000069BA4: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000069BA8: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000069BAC: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000069BB0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069BB8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000069BBC: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000069BC4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069BC8: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000069BCC: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000069BD4: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069BD8: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000069BDC: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000069BE4: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000069BE8: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069BF0: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000069BF4: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000069BF8: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069C00: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000069C04: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000069C08: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069C10: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000069C14: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000069C1C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000069C24: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069C30: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000069C34: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000069C3C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000069C48: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069C50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000069C54: BE882002
	s_cbranch_execz 61102                                      // 000000069C58: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4014>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000069C5C: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000069C68: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000069C70: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000069C74: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069C78: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000069C7C: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000069C84: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000069C90: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069C94: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000069C98: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000069C9C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000069CA4: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069CAC: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000069CB0: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000069CB4: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000069CB8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069CBC: BF870095
	.long 0xd71c003a                                           // 000000069CC0: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000069CC4: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000069CC8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000069CCC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069CD4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000069CD8: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000069CE4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069CE8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000069CEC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000069CF4: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069CF8: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000069CFC: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000069D04: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000069D08: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069D10: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000069D14: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000069D18: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069D20: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000069D24: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000069D28: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069D30: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000069D34: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000069D3C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000069D44: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069D50: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000069D54: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000069D5C: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000069D68: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069D70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000069D74: BE882003
	s_cbranch_execz 61033                                      // 000000069D78: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4020>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000069D7C: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000069D88: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000069D90: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000069D94: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069D98: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000069D9C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000069DA4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000069DB0: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069DB4: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000069DB8: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000069DC4: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000069DC8: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000069DCC: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000069DD4: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000069DD8: 7E744B3A
	.long 0xd71c003a                                           // 000000069DDC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000069DE0: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069DE4: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000069DE8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000069DEC: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000069DF4: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069E00: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000069E04: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000069E08: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000069E10: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000069E14: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000069E18: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000069E20: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000069E24: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000069E28: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000069E30: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069E34: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000069E38: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000069E40: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069E44: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000069E48: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000069E50: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069E58: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000069E5C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000069E64: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000069E70: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000069E78: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000069E7C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000069E88: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069E90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000069E94: BE882004
	s_cbranch_execz 60964                                      // 000000069E98: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x402c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 000000069E9C: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000069EA8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000069EB0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000069EB4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069EB8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000069EBC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000069EC4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000069ED0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069ED4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000069ED8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000069EDC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000069EE4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000069EEC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000069EF0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000069EF4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000069EF8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069EFC: BF870095
	.long 0xd71c003a                                           // 000000069F00: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000069F04: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000069F08: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000069F0C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F14: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000069F18: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000069F24: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F28: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000069F2C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000069F34: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F38: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000069F3C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000069F44: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000069F48: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F50: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 000000069F54: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000069F58: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F60: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 000000069F64: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000069F68: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F70: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 000000069F74: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000069F7C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 000000069F84: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069F90: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000069F94: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000069F9C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000069FA8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000069FB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000069FB4: BE882005
	s_cbranch_execz 60895                                      // 000000069FB8: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4038>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 000000069FBC: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000069FC8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000069FD0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000069FD4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000069FD8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000069FDC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000069FE4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000069FF0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000069FF4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000069FF8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000069FFC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000006A004: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A00C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000006A010: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000006A014: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000006A018: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A01C: BF870095
	.long 0xd71c003a                                           // 00000006A020: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000006A024: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000006A028: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000006A02C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A034: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000006A038: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 00000006A040: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A048: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000006A04C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000006A054: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A058: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000006A05C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000006A064: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000006A068: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A070: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000006A074: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 00000006A078: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A080: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 00000006A084: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 00000006A088: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A090: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000006A094: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000006A09C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000006A0A4: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A0B0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000006A0B4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000006A0BC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000006A0C8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A0D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006A0D4: BE882006
	s_cbranch_execz 60826                                      // 00000006A0D8: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4044>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 00000006A0DC: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000006A0E8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000006A0F0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000006A0F4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A0F8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000006A0FC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000006A104: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000006A110: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A114: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000006A118: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000006A11C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000006A124: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A12C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000006A130: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000006A134: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000006A138: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A13C: BF870095
	.long 0xd71c003a                                           // 00000006A140: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000006A144: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000006A148: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000006A14C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A154: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 00000006A158: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000006A164: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A168: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000006A16C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000006A174: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A178: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000006A17C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000006A184: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000006A188: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A190: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000006A194: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000006A198: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A1A0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000006A1A4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000006A1A8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A1B0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000006A1B4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000006A1BC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 00000006A1C4: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A1D0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000006A1D4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000006A1DC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000006A1E8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A1F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006A1F4: BE882007
	s_cbranch_execz 60757                                      // 00000006A1F8: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4050>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 00000006A1FC: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000006A208: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000006A210: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000006A214: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A218: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000006A21C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000006A224: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000006A230: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A234: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000006A238: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000006A23C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000006A244: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A24C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000006A250: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000006A254: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000006A258: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A25C: BF870095
	.long 0xd71c003a                                           // 00000006A260: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000006A264: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000006A268: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000006A26C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A274: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 00000006A278: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000006A284: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A288: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000006A28C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000006A294: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A298: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000006A29C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000006A2A4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000006A2A8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A2B0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000006A2B4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000006A2B8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A2C0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000006A2C4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000006A2C8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A2D0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000006A2D4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000006A2DC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 00000006A2E4: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A2F0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000006A2F4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000006A2FC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000006A308: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A310: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006A314: BE882000
	s_cbranch_execz 60688                                      // 00000006A318: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x405c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000006A31C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000006A328: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000006A32C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 00000006A334: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000006A338: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A33C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000006A340: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000006A348: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000006A354: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A358: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000006A35C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000006A360: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000006A368: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A370: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000006A374: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000006A378: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000006A37C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A380: BF870095
	.long 0xd71c003a                                           // 00000006A384: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000006A388: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000006A38C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000006A390: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A398: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000006A39C: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000006A3A4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A3A8: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 00000006A3AC: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 00000006A3B4: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A3B8: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000006A3BC: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000006A3C4: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 00000006A3C8: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A3D0: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000006A3D4: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000006A3D8: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A3E0: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000006A3E4: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000006A3E8: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A3F0: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000006A3F4: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 00000006A3FC: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 00000006A404: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A410: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 00000006A414: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000006A41C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 00000006A428: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A430: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006A434: BE882001
	s_cbranch_execz 60619                                      // 00000006A438: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4068>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000006A43C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 00000006A448: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000006A44C: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 00000006A454: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A458: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A45C: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 00000006A460: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006A468: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 00000006A470: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000006A47C: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006A480: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 00000006A484: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 00000006A48C: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A490: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000006A494: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000006A498: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000006A49C: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A4A0: BF870095
	.long 0xd71c0039                                           // 00000006A4A4: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000006A4A8: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000006A4AC: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006A4B0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A4B8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 00000006A4BC: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006A4C4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A4C8: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 00000006A4CC: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 00000006A4D4: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A4D8: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000006A4DC: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000006A4E4: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 00000006A4E8: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A4F0: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000006A4F4: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000006A4F8: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A500: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000006A504: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000006A508: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A510: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000006A514: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000006A51C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 00000006A524: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A530: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 00000006A534: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000006A53C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 00000006A548: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A550: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006A554: BE882002
	s_cbranch_execz 60550                                      // 00000006A558: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4074>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 00000006A55C: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006A568: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006A570: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A574: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A578: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006A57C: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 00000006A584: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 00000006A590: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A594: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 00000006A598: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006A59C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 00000006A5A4: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A5AC: BF870121
	v_add_f32_e32 v50, v50, v57                                // 00000006A5B0: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 00000006A5B4: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 00000006A5B8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A5BC: BF870095
	.long 0xd71c0032                                           // 00000006A5C0: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 00000006A5C4: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006A5C8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006A5CC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A5D4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 00000006A5D8: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006A5E4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A5E8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006A5EC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 00000006A5F4: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A5F8: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 00000006A5FC: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 00000006A604: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 00000006A608: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A610: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000006A614: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 00000006A618: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A620: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000006A624: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 00000006A628: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A630: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 00000006A634: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006A63C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 00000006A644: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A650: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 00000006A654: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 00000006A65C: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006A668: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A670: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006A674: BE882003
	s_cbranch_execz 60481                                      // 00000006A678: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4080>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 00000006A67C: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006A688: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006A690: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A694: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A698: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006A69C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006A6A4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 00000006A6B0: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A6B4: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 00000006A6B8: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 00000006A6C4: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 00000006A6C8: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006A6CC: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006A6D4: BF870293
	v_exp_f32_e32 v50, v50                                     // 00000006A6D8: 7E644B32
	.long 0xd71c0032                                           // 00000006A6DC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006A6E0: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A6E4: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006A6E8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006A6EC: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 00000006A6F4: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A700: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 00000006A704: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006A708: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006A710: BF870291
	v_rcp_f32_e32 v52, v51                                     // 00000006A714: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 00000006A718: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006A720: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 00000006A724: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 00000006A728: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 00000006A730: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A734: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 00000006A738: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 00000006A740: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A744: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 00000006A748: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 00000006A750: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A758: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006A75C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 00000006A764: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 00000006A770: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006A778: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000006A77C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006A788: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A790: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006A794: BE882004
	s_cbranch_execz 60412                                      // 00000006A798: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x408c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 00000006A79C: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006A7A8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006A7B0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A7B4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A7B8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006A7BC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006A7C4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000006A7D0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A7D4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000006A7D8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006A7DC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000006A7E4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A7EC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000006A7F0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000006A7F4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000006A7F8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A7FC: BF870095
	.long 0xd71c0032                                           // 00000006A800: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006A804: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006A808: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006A80C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A814: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 00000006A818: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006A824: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A828: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006A82C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000006A834: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A838: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000006A83C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000006A844: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000006A848: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A850: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 00000006A854: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 00000006A858: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A860: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 00000006A864: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 00000006A868: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A870: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 00000006A874: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006A87C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 00000006A884: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A890: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000006A894: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000006A89C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006A8A8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A8B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006A8B4: BE882005
	s_cbranch_execz 60343                                      // 00000006A8B8: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4098>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 00000006A8BC: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006A8C8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006A8D0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A8D4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A8D8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006A8DC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006A8E4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000006A8F0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006A8F4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000006A8F8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006A8FC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000006A904: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006A90C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000006A910: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000006A914: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000006A918: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A91C: BF870095
	.long 0xd71c0032                                           // 00000006A920: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006A924: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006A928: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006A92C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A934: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000006A938: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 00000006A940: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A948: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006A94C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000006A954: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A958: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000006A95C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000006A964: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000006A968: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A970: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000006A974: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 00000006A978: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A980: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 00000006A984: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 00000006A988: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A990: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000006A994: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006A99C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 00000006A9A4: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A9B0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000006A9B4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000006A9BC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006A9C8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006A9D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006A9D4: BE882006
	s_cbranch_execz 60274                                      // 00000006A9D8: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 00000006A9DC: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006A9E8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006A9F0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006A9F4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006A9F8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006A9FC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006AA04: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000006AA10: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006AA14: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000006AA18: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006AA1C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000006AA24: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AA2C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000006AA30: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000006AA34: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000006AA38: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AA3C: BF870095
	.long 0xd71c0032                                           // 00000006AA40: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006AA44: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006AA48: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006AA4C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AA54: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 00000006AA58: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006AA64: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AA68: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006AA6C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000006AA74: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AA78: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000006AA7C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000006AA84: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000006AA88: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AA90: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000006AA94: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000006AA98: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AAA0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000006AAA4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000006AAA8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AAB0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000006AAB4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006AABC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 00000006AAC4: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AAD0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000006AAD4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000006AADC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006AAE8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006AAF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006AAF4: BE882007
	s_cbranch_execz 60205                                      // 00000006AAF8: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 00000006AAFC: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000006AB08: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006AB10: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006AB14: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AB18: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006AB1C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006AB24: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000006AB30: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006AB34: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000006AB38: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006AB3C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000006AB44: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AB4C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000006AB50: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000006AB54: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000006AB58: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AB5C: BF870095
	.long 0xd71c0032                                           // 00000006AB60: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006AB64: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006AB68: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006AB6C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AB74: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 00000006AB78: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006AB84: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AB88: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000006AB8C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000006AB94: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AB98: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000006AB9C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000006ABA4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000006ABA8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ABB0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000006ABB4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000006ABB8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ABC0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000006ABC4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000006ABC8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ABD0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000006ABD4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000006ABDC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 00000006ABE4: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ABF0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000006ABF4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000006ABFC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000006AC08: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006AC10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006AC14: BE882000
	s_cbranch_execz 60136                                      // 00000006AC18: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40bc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 00000006AC1C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 00000006AC28: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 00000006AC2C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 00000006AC34: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000006AC38: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AC3C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000006AC40: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000006AC48: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000006AC54: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006AC58: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000006AC5C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000006AC60: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000006AC68: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AC70: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000006AC74: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000006AC78: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000006AC7C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AC80: BF870095
	.long 0xd71c0032                                           // 00000006AC84: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000006AC88: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000006AC8C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000006AC90: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AC98: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000006AC9C: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000006ACA4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ACA8: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 00000006ACAC: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 00000006ACB4: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ACB8: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000006ACBC: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000006ACC4: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 00000006ACC8: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ACD0: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000006ACD4: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000006ACD8: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ACE0: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000006ACE4: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000006ACE8: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ACF0: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000006ACF4: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 00000006ACFC: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 00000006AD04: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AD10: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 00000006AD14: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 00000006AD1C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 00000006AD28: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006AD30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006AD34: BE882001
	s_cbranch_execz 60067                                      // 00000006AD38: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 00000006AD3C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 00000006AD48: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 00000006AD4C: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 00000006AD54: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006AD58: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AD5C: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 00000006AD60: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006AD68: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 00000006AD70: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000006AD7C: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006AD80: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 00000006AD84: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 00000006AD8C: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AD90: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000006AD94: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000006AD98: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000006AD9C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ADA0: BF870095
	.long 0xd71c0031                                           // 00000006ADA4: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000006ADA8: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000006ADAC: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006ADB0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ADB8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 00000006ADBC: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006ADC4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ADC8: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 00000006ADCC: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 00000006ADD4: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ADD8: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000006ADDC: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000006ADE4: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 00000006ADE8: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ADF0: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000006ADF4: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000006ADF8: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AE00: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000006AE04: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000006AE08: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AE10: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000006AE14: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 00000006AE1C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 00000006AE24: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AE30: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 00000006AE34: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 00000006AE3C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 00000006AE48: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006AE50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006AE54: BE882002
	s_cbranch_execz 59998                                      // 00000006AE58: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 00000006AE5C: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006AE68: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006AE70: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006AE74: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AE78: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006AE7C: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 00000006AE84: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 00000006AE90: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006AE94: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 00000006AE98: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006AE9C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 00000006AEA4: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AEAC: BF870121
	v_add_f32_e32 v42, v42, v49                                // 00000006AEB0: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 00000006AEB4: 7E621132
	v_exp_f32_e32 v42, v42                                     // 00000006AEB8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AEBC: BF870095
	.long 0xd71c002a                                           // 00000006AEC0: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 00000006AEC4: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006AEC8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006AECC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AED4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 00000006AED8: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006AEE4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AEE8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006AEEC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 00000006AEF4: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AEF8: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 00000006AEFC: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 00000006AF04: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 00000006AF08: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AF10: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000006AF14: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 00000006AF18: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AF20: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000006AF24: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 00000006AF28: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AF30: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 00000006AF34: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006AF3C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 00000006AF44: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AF50: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 00000006AF54: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 00000006AF5C: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006AF68: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006AF70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006AF74: BE882003
	s_cbranch_execz 59929                                      // 00000006AF78: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 00000006AF7C: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006AF88: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006AF90: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006AF94: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AF98: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006AF9C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006AFA4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 00000006AFB0: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006AFB4: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 00000006AFB8: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 00000006AFC4: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 00000006AFC8: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006AFCC: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006AFD4: BF870293
	v_exp_f32_e32 v42, v42                                     // 00000006AFD8: 7E544B2A
	.long 0xd71c002a                                           // 00000006AFDC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006AFE0: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006AFE4: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006AFE8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006AFEC: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 00000006AFF4: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B000: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 00000006B004: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006B008: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006B010: BF870291
	v_rcp_f32_e32 v44, v43                                     // 00000006B014: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 00000006B018: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006B020: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 00000006B024: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 00000006B028: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 00000006B030: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B034: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 00000006B038: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 00000006B040: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B044: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 00000006B048: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 00000006B050: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B058: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006B05C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 00000006B064: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 00000006B070: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006B078: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000006B07C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006B088: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B090: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006B094: BE882004
	s_cbranch_execz 59860                                      // 00000006B098: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40ec>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 00000006B09C: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006B0A8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006B0B0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006B0B4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B0B8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006B0BC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006B0C4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000006B0D0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B0D4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000006B0D8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006B0DC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000006B0E4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B0EC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000006B0F0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000006B0F4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000006B0F8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B0FC: BF870095
	.long 0xd71c002a                                           // 00000006B100: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006B104: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006B108: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006B10C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B114: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 00000006B118: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006B124: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B128: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006B12C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000006B134: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B138: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000006B13C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000006B144: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000006B148: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B150: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 00000006B154: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 00000006B158: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B160: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 00000006B164: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 00000006B168: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B170: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 00000006B174: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006B17C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 00000006B184: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B190: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000006B194: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000006B19C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006B1A8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B1B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006B1B4: BE882005
	s_cbranch_execz 59791                                      // 00000006B1B8: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 00000006B1BC: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006B1C8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006B1D0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006B1D4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B1D8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006B1DC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006B1E4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000006B1F0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B1F4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000006B1F8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006B1FC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000006B204: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B20C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000006B210: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000006B214: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000006B218: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B21C: BF870095
	.long 0xd71c002a                                           // 00000006B220: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006B224: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006B228: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006B22C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B234: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000006B238: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 00000006B240: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B248: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006B24C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000006B254: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B258: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000006B25C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000006B264: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000006B268: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B270: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000006B274: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 00000006B278: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B280: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 00000006B284: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 00000006B288: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B290: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000006B294: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006B29C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000006B2A4: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B2B0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000006B2B4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000006B2BC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006B2C8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B2D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006B2D4: BE882006
	s_cbranch_execz 59722                                      // 00000006B2D8: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4104>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 00000006B2DC: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006B2E8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006B2F0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006B2F4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B2F8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006B2FC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006B304: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000006B310: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B314: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000006B318: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006B31C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000006B324: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B32C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000006B330: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000006B334: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000006B338: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B33C: BF870095
	.long 0xd71c002a                                           // 00000006B340: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006B344: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006B348: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006B34C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B354: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 00000006B358: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006B364: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B368: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006B36C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000006B374: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B378: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000006B37C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000006B384: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000006B388: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B390: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000006B394: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000006B398: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B3A0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000006B3A4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000006B3A8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B3B0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000006B3B4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006B3BC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 00000006B3C4: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B3D0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000006B3D4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000006B3DC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006B3E8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B3F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006B3F4: BE882007
	s_cbranch_execz 59653                                      // 00000006B3F8: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4110>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 00000006B3FC: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000006B408: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006B410: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006B414: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B418: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006B41C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006B424: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000006B430: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B434: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000006B438: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006B43C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000006B444: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B44C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000006B450: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000006B454: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000006B458: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B45C: BF870095
	.long 0xd71c002a                                           // 00000006B460: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006B464: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006B468: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006B46C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B474: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 00000006B478: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006B484: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B488: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000006B48C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000006B494: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B498: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000006B49C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000006B4A4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000006B4A8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B4B0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000006B4B4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000006B4B8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B4C0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000006B4C4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000006B4C8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B4D0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000006B4D4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000006B4DC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 00000006B4E4: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B4F0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000006B4F4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000006B4FC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000006B508: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B510: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006B514: BE882000
	s_cbranch_execz 59584                                      // 00000006B518: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x411c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000006B51C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000006B528: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000006B52C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 00000006B534: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000006B538: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B53C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000006B540: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000006B548: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000006B554: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B558: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000006B55C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000006B560: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000006B568: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B570: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000006B574: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000006B578: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000006B57C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B580: BF870095
	.long 0xd71c002a                                           // 00000006B584: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000006B588: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000006B58C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000006B590: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B598: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000006B59C: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000006B5A4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B5A8: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 00000006B5AC: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 00000006B5B4: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B5B8: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000006B5BC: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000006B5C4: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 00000006B5C8: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B5D0: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000006B5D4: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000006B5D8: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B5E0: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000006B5E4: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000006B5E8: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B5F0: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000006B5F4: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 00000006B5FC: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 00000006B604: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B610: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 00000006B614: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000006B61C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 00000006B628: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B630: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006B634: BE882001
	s_cbranch_execz 59515                                      // 00000006B638: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4128>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000006B63C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 00000006B648: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000006B64C: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 00000006B654: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006B658: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B65C: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 00000006B660: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006B668: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 00000006B670: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000006B67C: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006B680: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 00000006B684: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 00000006B68C: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B690: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000006B694: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000006B698: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000006B69C: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B6A0: BF870095
	.long 0xd71c0029                                           // 00000006B6A4: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000006B6A8: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000006B6AC: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006B6B0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B6B8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 00000006B6BC: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006B6C4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B6C8: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 00000006B6CC: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 00000006B6D4: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B6D8: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000006B6DC: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000006B6E4: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 00000006B6E8: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B6F0: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 00000006B6F4: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 00000006B6F8: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B700: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 00000006B704: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 00000006B708: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B710: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 00000006B714: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000006B71C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 00000006B724: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B730: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 00000006B734: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000006B73C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 00000006B748: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B750: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006B754: BE882002
	s_cbranch_execz 59446                                      // 00000006B758: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4134>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 00000006B75C: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006B768: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006B770: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006B774: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B778: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006B77C: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 00000006B784: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 00000006B790: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B794: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 00000006B798: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006B79C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 00000006B7A4: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B7AC: BF870121
	v_add_f32_e32 v34, v34, v41                                // 00000006B7B0: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 00000006B7B4: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 00000006B7B8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B7BC: BF870095
	.long 0xd71c0022                                           // 00000006B7C0: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 00000006B7C4: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006B7C8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006B7CC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B7D4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 00000006B7D8: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006B7E4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B7E8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006B7EC: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 00000006B7F4: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B7F8: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 00000006B7FC: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 00000006B804: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 00000006B808: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B810: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 00000006B814: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 00000006B818: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B820: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 00000006B824: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 00000006B828: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B830: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 00000006B834: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006B83C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 00000006B844: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B850: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 00000006B854: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 00000006B85C: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006B868: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B870: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006B874: BE882003
	s_cbranch_execz 59377                                      // 00000006B878: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4140>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 00000006B87C: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006B888: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006B890: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006B894: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B898: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006B89C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006B8A4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 00000006B8B0: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B8B4: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 00000006B8B8: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 00000006B8C4: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 00000006B8C8: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006B8CC: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006B8D4: BF870293
	v_exp_f32_e32 v34, v34                                     // 00000006B8D8: 7E444B22
	.long 0xd71c0022                                           // 00000006B8DC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006B8E0: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B8E4: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006B8E8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006B8EC: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 00000006B8F4: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B900: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 00000006B904: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006B908: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006B910: BF870291
	v_rcp_f32_e32 v36, v35                                     // 00000006B914: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 00000006B918: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006B920: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 00000006B924: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 00000006B928: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 00000006B930: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B934: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 00000006B938: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 00000006B940: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B944: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 00000006B948: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 00000006B950: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B958: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006B95C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 00000006B964: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000006B970: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006B978: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000006B97C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006B988: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006B990: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006B994: BE882004
	s_cbranch_execz 59308                                      // 00000006B998: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x414c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 00000006B99C: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006B9A8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006B9B0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006B9B4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B9B8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006B9BC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006B9C4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000006B9D0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006B9D4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000006B9D8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006B9DC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000006B9E4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006B9EC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000006B9F0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000006B9F4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000006B9F8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006B9FC: BF870095
	.long 0xd71c0022                                           // 00000006BA00: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006BA04: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006BA08: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006BA0C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA14: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 00000006BA18: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006BA24: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA28: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006BA2C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000006BA34: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA38: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000006BA3C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000006BA44: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000006BA48: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA50: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 00000006BA54: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 00000006BA58: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA60: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 00000006BA64: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 00000006BA68: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA70: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 00000006BA74: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006BA7C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 00000006BA84: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BA90: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000006BA94: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000006BA9C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006BAA8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006BAB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006BAB4: BE882005
	s_cbranch_execz 59239                                      // 00000006BAB8: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4158>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 00000006BABC: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006BAC8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006BAD0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006BAD4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BAD8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006BADC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006BAE4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000006BAF0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006BAF4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000006BAF8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006BAFC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000006BB04: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BB0C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000006BB10: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000006BB14: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000006BB18: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB1C: BF870095
	.long 0xd71c0022                                           // 00000006BB20: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006BB24: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006BB28: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006BB2C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB34: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000006BB38: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 00000006BB40: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB48: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006BB4C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000006BB54: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB58: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000006BB5C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000006BB64: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000006BB68: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB70: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000006BB74: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 00000006BB78: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB80: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 00000006BB84: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 00000006BB88: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BB90: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000006BB94: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006BB9C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 00000006BBA4: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BBB0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000006BBB4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000006BBBC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006BBC8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006BBD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006BBD4: BE882006
	s_cbranch_execz 59170                                      // 00000006BBD8: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4164>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 00000006BBDC: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006BBE8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006BBF0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006BBF4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BBF8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006BBFC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006BC04: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000006BC10: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006BC14: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000006BC18: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006BC1C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000006BC24: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BC2C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000006BC30: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000006BC34: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000006BC38: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BC3C: BF870095
	.long 0xd71c0022                                           // 00000006BC40: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006BC44: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006BC48: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006BC4C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BC54: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 00000006BC58: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006BC64: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BC68: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006BC6C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000006BC74: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BC78: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000006BC7C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000006BC84: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000006BC88: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BC90: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000006BC94: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000006BC98: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BCA0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000006BCA4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000006BCA8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BCB0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000006BCB4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006BCBC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 00000006BCC4: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BCD0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000006BCD4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000006BCDC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006BCE8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006BCF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006BCF4: BE882007
	s_cbranch_execz 59101                                      // 00000006BCF8: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4170>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 00000006BCFC: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000006BD08: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006BD10: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006BD14: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BD18: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006BD1C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006BD24: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000006BD30: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006BD34: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000006BD38: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006BD3C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000006BD44: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BD4C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000006BD50: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000006BD54: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000006BD58: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BD5C: BF870095
	.long 0xd71c0022                                           // 00000006BD60: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006BD64: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006BD68: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006BD6C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BD74: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 00000006BD78: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006BD84: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BD88: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000006BD8C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000006BD94: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BD98: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000006BD9C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000006BDA4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000006BDA8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BDB0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000006BDB4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000006BDB8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BDC0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000006BDC4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000006BDC8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BDD0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000006BDD4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000006BDDC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 00000006BDE4: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BDF0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000006BDF4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000006BDFC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000006BE08: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006BE10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006BE14: BE882000
	s_cbranch_execz 59032                                      // 00000006BE18: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x417c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 00000006BE1C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000006BE28: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 00000006BE2C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 00000006BE34: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000006BE38: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BE3C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000006BE40: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000006BE48: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000006BE54: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006BE58: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000006BE5C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000006BE60: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000006BE68: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BE70: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000006BE74: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000006BE78: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000006BE7C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BE80: BF870095
	.long 0xd71c0022                                           // 00000006BE84: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000006BE88: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000006BE8C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000006BE90: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BE98: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000006BE9C: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000006BEA4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BEA8: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 00000006BEAC: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 00000006BEB4: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BEB8: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000006BEBC: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000006BEC4: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 00000006BEC8: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BED0: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000006BED4: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000006BED8: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BEE0: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000006BEE4: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000006BEE8: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BEF0: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000006BEF4: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 00000006BEFC: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 00000006BF04: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BF10: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 00000006BF14: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000006BF1C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 00000006BF28: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006BF30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006BF34: BE882001
	s_cbranch_execz 58963                                      // 00000006BF38: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4188>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 00000006BF3C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 00000006BF48: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000006BF4C: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 00000006BF54: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006BF58: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BF5C: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 00000006BF60: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006BF68: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 00000006BF70: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000006BF7C: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006BF80: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 00000006BF84: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000006BF8C: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006BF90: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000006BF94: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000006BF98: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000006BF9C: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFA0: BF870095
	.long 0xd71c0021                                           // 00000006BFA4: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000006BFA8: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000006BFAC: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006BFB0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFB8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000006BFBC: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006BFC4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFC8: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000006BFCC: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 00000006BFD4: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFD8: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000006BFDC: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000006BFE4: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 00000006BFE8: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFF0: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000006BFF4: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000006BFF8: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C000: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000006C004: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000006C008: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C010: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000006C014: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000006C01C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000006C024: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C030: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000006C034: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000006C03C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 00000006C048: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C050: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006C054: BE882002
	s_cbranch_execz 58894                                      // 00000006C058: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4194>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 00000006C05C: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C068: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C070: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C074: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C078: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C07C: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 00000006C084: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 00000006C090: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C094: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 00000006C098: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C09C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000006C0A4: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C0AC: BF870121
	v_add_f32_e32 v26, v26, v33                                // 00000006C0B0: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 00000006C0B4: 7E421122
	v_exp_f32_e32 v26, v26                                     // 00000006C0B8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C0BC: BF870095
	.long 0xd71c001a                                           // 00000006C0C0: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 00000006C0C4: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C0C8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C0CC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C0D4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 00000006C0D8: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C0E4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C0E8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C0EC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 00000006C0F4: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C0F8: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000006C0FC: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 00000006C104: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 00000006C108: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C110: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000006C114: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 00000006C118: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C120: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000006C124: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 00000006C128: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C130: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000006C134: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C13C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 00000006C144: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C150: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 00000006C154: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000006C15C: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C168: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C170: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006C174: BE882003
	s_cbranch_execz 58825                                      // 00000006C178: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000006C17C: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C188: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C190: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C194: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C198: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C19C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C1A4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 00000006C1B0: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C1B4: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 00000006C1B8: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 00000006C1C4: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 00000006C1C8: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C1CC: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006C1D4: BF870293
	v_exp_f32_e32 v26, v26                                     // 00000006C1D8: 7E344B1A
	.long 0xd71c001a                                           // 00000006C1DC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C1E0: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C1E4: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C1E8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C1EC: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 00000006C1F4: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C200: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C204: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C208: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006C210: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000006C214: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 00000006C218: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C220: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000006C224: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 00000006C228: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 00000006C230: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C234: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 00000006C238: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 00000006C240: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C244: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 00000006C248: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 00000006C250: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C258: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C25C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 00000006C264: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000006C270: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006C278: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000006C27C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C288: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C290: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006C294: BE882004
	s_cbranch_execz 58756                                      // 00000006C298: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41ac>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000006C29C: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C2A8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C2B0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C2B4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C2B8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C2BC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C2C4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006C2D0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C2D4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000006C2D8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C2DC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000006C2E4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C2EC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006C2F0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000006C2F4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000006C2F8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C2FC: BF870095
	.long 0xd71c001a                                           // 00000006C300: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C304: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C308: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C30C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C314: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 00000006C318: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C324: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C328: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C32C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000006C334: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C338: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000006C33C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000006C344: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000006C348: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C350: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 00000006C354: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 00000006C358: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C360: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 00000006C364: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 00000006C368: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C370: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 00000006C374: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C37C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 00000006C384: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C390: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000006C394: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000006C39C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C3A8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C3B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006C3B4: BE882005
	s_cbranch_execz 58687                                      // 00000006C3B8: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 00000006C3BC: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C3C8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C3D0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C3D4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C3D8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C3DC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C3E4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006C3F0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C3F4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000006C3F8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C3FC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000006C404: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C40C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006C410: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000006C414: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000006C418: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C41C: BF870095
	.long 0xd71c001a                                           // 00000006C420: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C424: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C428: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C42C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C434: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000006C438: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 00000006C440: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C448: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C44C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000006C454: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C458: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000006C45C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000006C464: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000006C468: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C470: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000006C474: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 00000006C478: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C480: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 00000006C484: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 00000006C488: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C490: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000006C494: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C49C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 00000006C4A4: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C4B0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000006C4B4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000006C4BC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C4C8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C4D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006C4D4: BE882006
	s_cbranch_execz 58618                                      // 00000006C4D8: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 00000006C4DC: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C4E8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C4F0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C4F4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C4F8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C4FC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C504: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006C510: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C514: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000006C518: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C51C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000006C524: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C52C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006C530: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000006C534: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000006C538: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C53C: BF870095
	.long 0xd71c001a                                           // 00000006C540: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C544: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C548: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C54C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C554: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 00000006C558: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C564: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C568: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C56C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000006C574: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C578: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000006C57C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000006C584: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000006C588: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C590: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000006C594: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000006C598: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C5A0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000006C5A4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000006C5A8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C5B0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000006C5B4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C5BC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 00000006C5C4: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C5D0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000006C5D4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000006C5DC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C5E8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C5F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006C5F4: BE882007
	s_cbranch_execz 58549                                      // 00000006C5F8: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 00000006C5FC: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000006C608: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C610: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C614: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C618: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C61C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C624: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006C630: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C634: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000006C638: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C63C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000006C644: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C64C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006C650: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000006C654: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000006C658: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C65C: BF870095
	.long 0xd71c001a                                           // 00000006C660: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C664: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C668: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C66C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C674: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 00000006C678: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C684: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C688: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000006C68C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000006C694: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C698: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000006C69C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000006C6A4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000006C6A8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C6B0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000006C6B4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000006C6B8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C6C0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000006C6C4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000006C6C8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C6D0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000006C6D4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000006C6DC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 00000006C6E4: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C6F0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000006C6F4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000006C6FC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000006C708: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C710: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006C714: BE882000
	s_cbranch_execz 58480                                      // 00000006C718: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41dc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000006C71C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000006C728: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000006C72C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 00000006C734: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000006C738: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C73C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000006C740: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000006C748: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006C754: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C758: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000006C75C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000006C760: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000006C768: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C770: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006C774: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000006C778: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000006C77C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C780: BF870095
	.long 0xd71c001a                                           // 00000006C784: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000006C788: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000006C78C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000006C790: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C798: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000006C79C: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000006C7A4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C7A8: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 00000006C7AC: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 00000006C7B4: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C7B8: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000006C7BC: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000006C7C4: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 00000006C7C8: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C7D0: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000006C7D4: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000006C7D8: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C7E0: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000006C7E4: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000006C7E8: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C7F0: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000006C7F4: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 00000006C7FC: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 00000006C804: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C810: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 00000006C814: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000006C81C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 00000006C828: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C830: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006C834: BE882001
	s_cbranch_execz 58411                                      // 00000006C838: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 00000006C83C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 00000006C848: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 00000006C84C: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 00000006C854: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006C858: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C85C: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 00000006C860: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006C868: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 00000006C870: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000006C87C: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006C880: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 00000006C884: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000006C88C: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C890: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000006C894: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000006C898: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000006C89C: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C8A0: BF870095
	.long 0xd71c0019                                           // 00000006C8A4: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000006C8A8: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000006C8AC: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006C8B0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C8B8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 00000006C8BC: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006C8C4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C8C8: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 00000006C8CC: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 00000006C8D4: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C8D8: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000006C8DC: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000006C8E4: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 00000006C8E8: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C8F0: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000006C8F4: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000006C8F8: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C900: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000006C904: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000006C908: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C910: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000006C914: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 00000006C91C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 00000006C924: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C930: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 00000006C934: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000006C93C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 00000006C948: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006C950: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006C954: BE882002
	s_cbranch_execz 58342                                      // 00000006C958: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 00000006C95C: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006C968: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006C970: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006C974: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C978: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006C97C: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 00000006C984: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 00000006C990: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006C994: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 00000006C998: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006C99C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000006C9A4: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C9AC: BF870121
	v_add_f32_e32 v18, v18, v25                                // 00000006C9B0: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 00000006C9B4: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 00000006C9B8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C9BC: BF870095
	.long 0xd71c0012                                           // 00000006C9C0: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 00000006C9C4: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006C9C8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006C9CC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C9D4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 00000006C9D8: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006C9E4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C9E8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006C9EC: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 00000006C9F4: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C9F8: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 00000006C9FC: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 00000006CA04: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 00000006CA08: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CA10: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000006CA14: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 00000006CA18: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CA20: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000006CA24: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 00000006CA28: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CA30: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000006CA34: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CA3C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 00000006CA44: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CA50: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 00000006CA54: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000006CA5C: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006CA68: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006CA70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006CA74: BE882003
	s_cbranch_execz 58273                                      // 00000006CA78: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4200>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000006CA7C: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006CA88: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006CA90: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006CA94: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CA98: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006CA9C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006CAA4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 00000006CAB0: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CAB4: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 00000006CAB8: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 00000006CAC4: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 00000006CAC8: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006CACC: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006CAD4: BF870293
	v_exp_f32_e32 v18, v18                                     // 00000006CAD8: 7E244B12
	.long 0xd71c0012                                           // 00000006CADC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006CAE0: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CAE4: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006CAE8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006CAEC: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 00000006CAF4: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CB00: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 00000006CB04: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006CB08: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006CB10: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000006CB14: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000006CB18: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006CB20: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000006CB24: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 00000006CB28: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 00000006CB30: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CB34: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 00000006CB38: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 00000006CB40: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CB44: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 00000006CB48: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 00000006CB50: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CB58: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CB5C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 00000006CB64: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000006CB70: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006CB78: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006CB7C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006CB88: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006CB90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006CB94: BE882004
	s_cbranch_execz 58204                                      // 00000006CB98: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x420c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000006CB9C: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006CBA8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006CBB0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006CBB4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CBB8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006CBBC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006CBC4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000006CBD0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006CBD4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000006CBD8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006CBDC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000006CBE4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CBEC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000006CBF0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000006CBF4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000006CBF8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CBFC: BF870095
	.long 0xd71c0012                                           // 00000006CC00: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006CC04: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006CC08: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006CC0C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC14: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 00000006CC18: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006CC24: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC28: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006CC2C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000006CC34: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC38: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000006CC3C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000006CC44: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000006CC48: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC50: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 00000006CC54: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 00000006CC58: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC60: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 00000006CC64: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 00000006CC68: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC70: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 00000006CC74: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CC7C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 00000006CC84: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC90: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000006CC94: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006CC9C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006CCA8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006CCB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006CCB4: BE882005
	s_cbranch_execz 58135                                      // 00000006CCB8: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4218>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 00000006CCBC: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006CCC8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006CCD0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006CCD4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CCD8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006CCDC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006CCE4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000006CCF0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006CCF4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000006CCF8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006CCFC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000006CD04: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CD0C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000006CD10: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000006CD14: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000006CD18: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD1C: BF870095
	.long 0xd71c0012                                           // 00000006CD20: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006CD24: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006CD28: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006CD2C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD34: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000006CD38: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 00000006CD40: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD48: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006CD4C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000006CD54: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD58: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000006CD5C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000006CD64: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000006CD68: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD70: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000006CD74: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 00000006CD78: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD80: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 00000006CD84: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 00000006CD88: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CD90: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000006CD94: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CD9C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 00000006CDA4: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CDB0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000006CDB4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006CDBC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006CDC8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006CDD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006CDD4: BE882006
	s_cbranch_execz 58066                                      // 00000006CDD8: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4224>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000006CDDC: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006CDE8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006CDF0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006CDF4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CDF8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006CDFC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006CE04: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000006CE10: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006CE14: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000006CE18: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006CE1C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000006CE24: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CE2C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000006CE30: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000006CE34: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000006CE38: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE3C: BF870095
	.long 0xd71c0012                                           // 00000006CE40: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006CE44: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006CE48: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006CE4C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE54: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 00000006CE58: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006CE64: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE68: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006CE6C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000006CE74: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE78: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000006CE7C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000006CE84: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000006CE88: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE90: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000006CE94: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000006CE98: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CEA0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000006CEA4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000006CEA8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CEB0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000006CEB4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CEBC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 00000006CEC4: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CED0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000006CED4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006CEDC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006CEE8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006CEF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006CEF4: BE882007
	s_cbranch_execz 57997                                      // 00000006CEF8: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4230>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000006CEFC: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000006CF08: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006CF10: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006CF14: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF18: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006CF1C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006CF24: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000006CF30: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006CF34: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000006CF38: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006CF3C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000006CF44: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006CF4C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000006CF50: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000006CF54: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000006CF58: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF5C: BF870095
	.long 0xd71c0012                                           // 00000006CF60: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006CF64: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006CF68: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006CF6C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF74: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 00000006CF78: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006CF84: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF88: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006CF8C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000006CF94: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF98: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000006CF9C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000006CFA4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000006CFA8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CFB0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000006CFB4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000006CFB8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CFC0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000006CFC4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000006CFC8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CFD0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000006CFD4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006CFDC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 00000006CFE4: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CFF0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000006CFF4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006CFFC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000006D008: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D010: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006D014: BE882000
	s_cbranch_execz 57928                                      // 00000006D018: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x423c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000006D01C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000006D028: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000006D02C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000006D034: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000006D038: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D03C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006D040: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000006D048: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000006D054: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D058: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000006D05C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006D060: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000006D068: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D070: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000006D074: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000006D078: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000006D07C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D080: BF870095
	.long 0xd71c0012                                           // 00000006D084: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000006D088: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000006D08C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006D090: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D098: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000006D09C: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000006D0A4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D0A8: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 00000006D0AC: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 00000006D0B4: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D0B8: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000006D0BC: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000006D0C4: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 00000006D0C8: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D0D0: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000006D0D4: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000006D0D8: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D0E0: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000006D0E4: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000006D0E8: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D0F0: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000006D0F4: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000006D0FC: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 00000006D104: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D110: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 00000006D114: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000006D11C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 00000006D128: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D130: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000006D134: BE882001
	s_cbranch_execz 57859                                      // 00000006D138: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4248>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000006D13C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 00000006D148: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 00000006D14C: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 00000006D154: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D158: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D15C: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 00000006D160: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D168: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 00000006D170: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000006D17C: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006D180: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 00000006D184: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 00000006D18C: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D190: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000006D194: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000006D198: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000006D19C: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D1A0: BF870095
	.long 0xd71c0011                                           // 00000006D1A4: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000006D1A8: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000006D1AC: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D1B0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D1B8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000006D1BC: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D1C4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D1C8: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000006D1CC: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 00000006D1D4: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D1D8: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000006D1DC: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000006D1E4: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 00000006D1E8: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D1F0: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000006D1F4: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000006D1F8: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D200: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000006D204: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000006D208: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D210: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000006D214: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000006D21C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 00000006D224: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D230: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 00000006D234: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000006D23C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 00000006D248: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D250: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000006D254: BE882002
	s_cbranch_execz 57790                                      // 00000006D258: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4254>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 00000006D25C: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D268: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D270: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D274: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D278: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D27C: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 00000006D284: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 00000006D290: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D294: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 00000006D298: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D29C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 00000006D2A4: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D2AC: BF870121
	v_add_f32_e32 v10, v10, v17                                // 00000006D2B0: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 00000006D2B4: 7E221112
	v_exp_f32_e32 v10, v10                                     // 00000006D2B8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D2BC: BF870095
	.long 0xd71c000a                                           // 00000006D2C0: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 00000006D2C4: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D2C8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D2CC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D2D4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 00000006D2D8: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D2E4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D2E8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D2EC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 00000006D2F4: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D2F8: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 00000006D2FC: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 00000006D304: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 00000006D308: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D310: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000006D314: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 00000006D318: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D320: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000006D324: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 00000006D328: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D330: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 00000006D334: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D33C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 00000006D344: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D350: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 00000006D354: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000006D35C: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D368: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D370: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000006D374: BE882003
	s_cbranch_execz 57721                                      // 00000006D378: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4260>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 00000006D37C: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D388: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D390: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D394: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D398: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D39C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D3A4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 00000006D3B0: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D3B4: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 00000006D3B8: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 00000006D3C4: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 00000006D3C8: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D3CC: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006D3D4: BF870293
	v_exp_f32_e32 v10, v10                                     // 00000006D3D8: 7E144B0A
	.long 0xd71c000a                                           // 00000006D3DC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D3E0: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D3E4: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D3E8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D3EC: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 00000006D3F4: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D400: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D404: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D408: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006D410: BF870291
	v_rcp_f32_e32 v12, v11                                     // 00000006D414: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 00000006D418: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006D420: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 00000006D424: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 00000006D428: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 00000006D430: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D434: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 00000006D438: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 00000006D440: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D444: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 00000006D448: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 00000006D450: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D458: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D45C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 00000006D464: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000006D470: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006D478: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000006D47C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D488: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D490: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000006D494: BE882004
	s_cbranch_execz 57652                                      // 00000006D498: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x426c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 00000006D49C: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D4A8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D4B0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D4B4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D4B8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D4BC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D4C4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000006D4D0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D4D4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000006D4D8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D4DC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000006D4E4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D4EC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000006D4F0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000006D4F4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000006D4F8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D4FC: BF870095
	.long 0xd71c000a                                           // 00000006D500: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D504: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D508: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D50C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D514: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 00000006D518: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D524: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D528: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D52C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000006D534: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D538: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000006D53C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000006D544: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000006D548: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D550: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 00000006D554: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 00000006D558: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D560: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 00000006D564: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 00000006D568: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D570: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 00000006D574: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D57C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 00000006D584: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D590: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000006D594: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000006D59C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D5A8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D5B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000006D5B4: BE882005
	s_cbranch_execz 57583                                      // 00000006D5B8: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4278>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 00000006D5BC: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D5C8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D5D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D5D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D5D8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D5DC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D5E4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000006D5F0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D5F4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000006D5F8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D5FC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000006D604: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D60C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000006D610: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000006D614: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000006D618: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D61C: BF870095
	.long 0xd71c000a                                           // 00000006D620: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D624: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D628: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D62C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D634: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000006D638: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 00000006D640: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D648: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D64C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000006D654: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D658: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000006D65C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000006D664: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000006D668: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D670: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000006D674: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 00000006D678: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D680: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 00000006D684: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 00000006D688: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D690: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000006D694: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D69C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 00000006D6A4: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D6B0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000006D6B4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000006D6BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D6C8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D6D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000006D6D4: BE882006
	s_cbranch_execz 57514                                      // 00000006D6D8: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4284>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 00000006D6DC: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D6E8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D6F0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D6F4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D6F8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D6FC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D704: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000006D710: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D714: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000006D718: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D71C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000006D724: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D72C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000006D730: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000006D734: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000006D738: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D73C: BF870095
	.long 0xd71c000a                                           // 00000006D740: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D744: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D748: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D74C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D754: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 00000006D758: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D764: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D768: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D76C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000006D774: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D778: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000006D77C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000006D784: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000006D788: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D790: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000006D794: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000006D798: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D7A0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000006D7A4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000006D7A8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D7B0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000006D7B4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D7BC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 00000006D7C4: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D7D0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000006D7D4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000006D7DC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D7E8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D7F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000006D7F4: BE882007
	s_cbranch_execz 57445                                      // 00000006D7F8: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4290>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 00000006D7FC: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000006D808: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D810: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D814: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D818: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D81C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D824: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000006D830: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D834: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000006D838: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D83C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000006D844: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D84C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000006D850: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000006D854: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000006D858: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D85C: BF870095
	.long 0xd71c000a                                           // 00000006D860: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D864: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D868: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D86C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D874: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 00000006D878: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D884: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D888: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006D88C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000006D894: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D898: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000006D89C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000006D8A4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000006D8A8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D8B0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000006D8B4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000006D8B8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D8C0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000006D8C4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000006D8C8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D8D0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000006D8D4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006D8DC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 00000006D8E4: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D8F0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000006D8F4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000006D8FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000006D908: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006D910: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000006D914: BE882000
	s_cbranch_execz 57376                                      // 00000006D918: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x429c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 00000006D91C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000006D928: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 00000006D92C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000006D934: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000006D938: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D93C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006D940: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000006D948: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000006D954: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006D958: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000006D95C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006D960: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000006D968: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006D970: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000006D974: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000006D978: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000006D97C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D980: BF870095
	.long 0xd71c000a                                           // 00000006D984: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000006D988: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000006D98C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006D990: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D998: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000006D99C: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000006D9A4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D9A8: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000006D9AC: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 00000006D9B4: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D9B8: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000006D9BC: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000006D9C4: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 00000006D9C8: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D9D0: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000006D9D4: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000006D9D8: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D9E0: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000006D9E4: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000006D9E8: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D9F0: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000006D9F4: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 00000006D9FC: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 00000006DA04: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DA10: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000006DA14: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000006DA1C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 00000006DA28: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 00000006DA30: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000006DA34: BE802001
	s_cbranch_execz 57307                                      // 00000006DA38: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42a8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 00000006DA3C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DA48: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DA50: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DA54: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DA58: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DA5C: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 00000006DA64: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 00000006DA70: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006DA74: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 00000006DA78: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000006DA7C: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006DA84: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006DA8C: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 00000006DA90: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 00000006DA94: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 00000006DA98: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DA9C: BF870095
	.long 0xd71c0001                                           // 00000006DAA0: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000006DAA4: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006DAA8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006DAAC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DAB4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 00000006DAB8: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006DAC4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DAC8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006DACC: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 00000006DAD4: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DAD8: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 00000006DADC: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 00000006DAE4: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000006DAE8: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DAF0: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000006DAF4: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 00000006DAF8: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DB00: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000006DB04: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 00000006DB08: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DB10: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 00000006DB14: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006DB1C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 00000006DB24: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DB30: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 00000006DB34: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 00000006DB3C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006DB48: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006DB50: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000006DB54: BE802002
	s_cbranch_execz 57238                                      // 00000006DB58: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42b4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 00000006DB5C: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DB68: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DB70: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DB74: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DB78: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DB7C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006DB84: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 00000006DB90: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006DB94: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000006DB98: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006DB9C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006DBA4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006DBAC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006DBB0: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 00000006DBB4: 7E041109
	v_exp_f32_e32 v1, v1                                       // 00000006DBB8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DBBC: BF870095
	.long 0xd71c0001                                           // 00000006DBC0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006DBC4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006DBC8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006DBCC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DBD4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000006DBD8: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006DBE4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DBE8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006DBEC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006DBF4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DBF8: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 00000006DBFC: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 00000006DC04: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 00000006DC08: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DC10: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 00000006DC14: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 00000006DC18: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DC20: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 00000006DC24: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000006DC28: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DC30: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 00000006DC34: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006DC3C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 00000006DC44: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DC50: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006DC54: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006DC5C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006DC68: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006DC70: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000006DC74: BE802003
	s_cbranch_execz 57169                                      // 00000006DC78: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 00000006DC7C: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DC88: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DC90: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DC94: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DC98: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DC9C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006DCA4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000006DCB0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006DCB4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000006DCB8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006DCBC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006DCC4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006DCCC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006DCD0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000006DCD4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000006DCD8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DCDC: BF870095
	.long 0xd71c0001                                           // 00000006DCE0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006DCE4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006DCE8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006DCEC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DCF4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 00000006DCF8: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006DD04: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD08: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006DD0C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006DD14: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD18: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006DD1C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000006DD24: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000006DD28: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD30: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 00000006DD34: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 00000006DD38: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD40: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 00000006DD44: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 00000006DD48: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD50: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000006DD54: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006DD5C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 00000006DD64: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DD70: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006DD74: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006DD7C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006DD88: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006DD90: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000006DD94: BE802004
	s_cbranch_execz 57100                                      // 00000006DD98: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42cc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 00000006DD9C: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DDA8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DDB0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DDB4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DDB8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DDBC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006DDC4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000006DDD0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006DDD4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000006DDD8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006DDDC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006DDE4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006DDEC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006DDF0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000006DDF4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000006DDF8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DDFC: BF870095
	.long 0xd71c0001                                           // 00000006DE00: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006DE04: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006DE08: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006DE0C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE14: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000006DE18: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000006DE20: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE28: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006DE2C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006DE34: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE38: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006DE3C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000006DE44: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000006DE48: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE50: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000006DE54: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000006DE58: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE60: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000006DE64: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000006DE68: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE70: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000006DE74: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006DE7C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 00000006DE84: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE90: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006DE94: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006DE9C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006DEA8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006DEB0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000006DEB4: BE802005
	s_cbranch_execz 57031                                      // 00000006DEB8: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42d8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 00000006DEBC: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DEC8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DED0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DED4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DED8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DEDC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006DEE4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000006DEF0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006DEF4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000006DEF8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006DEFC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006DF04: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006DF0C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006DF10: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000006DF14: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000006DF18: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF1C: BF870095
	.long 0xd71c0001                                           // 00000006DF20: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006DF24: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006DF28: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006DF2C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF34: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000006DF38: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006DF44: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF48: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006DF4C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006DF54: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF58: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006DF5C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000006DF64: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000006DF68: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF70: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000006DF74: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000006DF78: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF80: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000006DF84: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000006DF88: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF90: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000006DF94: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006DF9C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000006DFA4: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DFB0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006DFB4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006DFBC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006DFC8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006DFD0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000006DFD4: BE802006
	s_cbranch_execz 56962                                      // 00000006DFD8: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42e4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 00000006DFDC: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006DFE8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006DFF0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006DFF4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DFF8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006DFFC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006E004: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000006E010: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006E014: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000006E018: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006E01C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006E024: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006E02C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006E030: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000006E034: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000006E038: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E03C: BF870095
	.long 0xd71c0001                                           // 00000006E040: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006E044: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006E048: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006E04C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E054: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000006E058: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006E064: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E068: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006E06C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006E074: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E078: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006E07C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000006E084: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000006E088: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E090: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000006E094: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000006E098: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E0A0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000006E0A4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000006E0A8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E0B0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000006E0B4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006E0BC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 00000006E0C4: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E0D0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006E0D4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006E0DC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006E0E8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006E0F0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000006E0F4: BE802007
	s_cbranch_execz 56893                                      // 00000006E0F8: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42f0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 00000006E0FC: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000006E108: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000006E110: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000006E114: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E118: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006E11C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000006E124: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000006E130: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006E134: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000006E138: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006E13C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000006E144: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006E14C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000006E150: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000006E154: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000006E158: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E15C: BF870095
	.long 0xd71c0001                                           // 00000006E160: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000006E164: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000006E168: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006E16C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E174: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 00000006E178: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000006E184: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E188: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006E18C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000006E194: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E198: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006E19C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000006E1A4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000006E1A8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1B0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000006E1B4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000006E1B8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1C0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000006E1C4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000006E1C8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1D0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000006E1D4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006E1DC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 00000006E1E4: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1F0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000006E1F4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006E1FC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000006E208: DC9601E0 007C0200
	s_nop 0                                                    // 00000006E210: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000006E214: BFB60003
	s_endpgm                                                   // 00000006E218: BFB00000
		...

