00000000001d3700 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001D3700: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001D3708: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001D370C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001D3710: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001D3714: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001D3718: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001D371C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001D3720: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001D3724: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001D372C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001D3730: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001D3738: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001D373C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001D3740: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 0000001D3744: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D3748: BF870009
	s_add_u32 s5, s5, s34                                      // 0000001D374C: 80052205
	s_addc_u32 s8, s8, s35                                     // 0000001D3750: 82082308
	s_waitcnt lgkmcnt(0)                                       // 0000001D3754: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001D3758: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001D3760: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001D3768: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001D376C: 82050F08
	s_lshl_b64 s[48:49], s[6:7], 2                             // 0000001D3770: 84B08206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D3774: BF8700B9
	s_add_u32 s4, s4, s48                                      // 0000001D3778: 80043004
	s_addc_u32 s5, s5, s49                                     // 0000001D377C: 82053105
	.long 0xd7000403                                           // 0000001D3780: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001D3784: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001D3788: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001D3790: BE840080
	s_nop 0                                                    // 0000001D3794: BF800000
	s_nop 0                                                    // 0000001D3798: BF800000
	s_nop 0                                                    // 0000001D379C: BF800000
	s_nop 0                                                    // 0000001D37A0: BF800000
	s_nop 0                                                    // 0000001D37A4: BF800000
	s_nop 0                                                    // 0000001D37A8: BF800000
	s_nop 0                                                    // 0000001D37AC: BF800000
	s_nop 0                                                    // 0000001D37B0: BF800000
	s_nop 0                                                    // 0000001D37B4: BF800000
	s_nop 0                                                    // 0000001D37B8: BF800000
	s_nop 0                                                    // 0000001D37BC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001D37C0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D37C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001D37C8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001D37CC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001D37D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001D37D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001D37DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001D37E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001D37E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001D37F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001D37F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001D3800: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001D3804: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001D3808: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001D380C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001D3814: 917E047E
	s_cbranch_execnz 65513                                     // 0000001D3818: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001D381C: 8C7E047E
	s_load_b32 s50, s[0:1], 0x58                               // 0000001D3820: F4000C80 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 0000001D3828: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001D3830: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 0000001D3834: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001D3838: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001D3840: 32080084
	s_mov_b32 s4, 0                                            // 0000001D3844: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001D3848: BF89FC07
	s_barrier                                                  // 0000001D384C: BFBD0000
	buffer_gl0_inv                                             // 0000001D3850: E0AC0000 00000000
	s_cmp_gt_i32 s50, 0                                        // 0000001D3858: BF028032
	s_cbranch_scc1 14                                          // 0000001D385C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 0000001D3860: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s48                                      // 0000001D386C: 7E020230
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001D3870: 380C00FF FFFFFF80
	v_and_or_b32 v124, v4, 4, v3                               // 0000001D3878: D657007C 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D3880: BF870004
	v_dual_mov_b32 v131, v107 :: v_dual_mov_b32 v2, s49        // 0000001D3884: CA10016B 83020031
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001D388C: 916A047E
	s_cbranch_vccz 1                                           // 0000001D3890: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 7315                                              // 0000001D3894: BFA01C93 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73e4>
	s_clause 0x3                                               // 0000001D3898: BF850003
	s_load_b128 s[28:31], s[0:1], 0x10                         // 0000001D389C: F4080700 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000001D38A4: F4040200 F8000020
	s_load_b64 s[10:11], s[0:1], 0x70                          // 0000001D38AC: F4040280 F8000070
	s_load_b128 s[44:47], s[0:1], 0x60                         // 0000001D38B4: F4080B00 F8000060
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001D38BC: 32020085
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 0000001D38C0: CA220080 6B020082
	s_add_i32 s5, s50, 63                                      // 0000001D38C8: 8105BF32
	s_add_i32 s52, s50, -1                                     // 0000001D38CC: 8134C132
	s_lshr_b32 s53, s5, 6                                      // 0000001D38D0: 85358605
	s_mul_i32 s5, s52, 48                                      // 0000001D38D4: 9605B034
	s_add_i32 s51, s2, 0xbd0                                   // 0000001D38D8: 8133FF02 00000BD0
	s_mul_hi_u32 s13, s52, 48                                  // 0000001D38E0: 968DB034
	s_add_u32 s12, s5, s2                                      // 0000001D38E4: 800C0205
	v_or_b32_e32 v120, 0xf000, v2                              // 0000001D38E8: 38F004FF 0000F000
	v_add_nc_u32_e32 v121, 0xf100, v2                          // 0000001D38F0: 4AF204FF 0000F100
	v_and_b32_e32 v6, 15, v0                                   // 0000001D38F8: 360C008F
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001D38FC: D6100007 02050900
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001D3904: 161002FF 00002100
	s_addc_u32 s13, s13, s3                                    // 0000001D390C: 820D030D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3910: BF89FC07
	.long 0xd700057a                                           // 0000001D3914: D700057A
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000001D3918: 0202041C
	v_dual_mov_b32 v131, v107 :: v_dual_lshlrev_b32 v2, 4, v1  // 0000001D391C: CA22016B 83020284
	v_add_co_ci_u32_e64 v123, null, s29, 0, s5                 // 0000001D3924: D5207C7B 0015001D
	s_lshl_b64 s[12:13], s[12:13], 9                           // 0000001D392C: 848C890C
	v_or_b32_e32 v128, v2, v6                                  // 0000001D3930: 39000D02
	v_or_b32_e32 v132, v7, v2                                  // 0000001D3934: 39080507
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001D3938: D60B0002 04220CFF 00000210
	.long 0xd700057d                                           // 0000001D3944: D700057D
	v_cndmask_b32_e32 v0, v122, v12, vcc_lo                    // 0000001D3948: 0200197A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D394C: BF870001
	v_add_co_ci_u32_e64 v126, null, s13, v123, s5              // 0000001D3950: D5207C7E 0016F60D
	s_add_u32 s5, s8, s48                                      // 0000001D3958: 80053008
	v_lshlrev_b32_e32 v8, 2, v6                                // 0000001D395C: 30100C82
	s_addc_u32 s12, s9, s49                                    // 0000001D3960: 820C3109
	s_lshl_b32 s8, s2, 7                                       // 0000001D3964: 84088702
	v_lshl_or_b32 v135, v7, 2, v2                              // 0000001D3968: D6560087 04090507
	v_lshlrev_b32_e32 v2, 7, v128                              // 0000001D3970: 30050087
	s_ashr_i32 s9, s8, 31                                      // 0000001D3974: 86099F08
	.long 0xd7000588                                           // 0000001D3978: D7000588
	v_cndmask_b32_e32 v1, s5, v8, vcc_lo                       // 0000001D397C: 02021005
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001D3980: 84888108
	v_add_co_ci_u32_e64 v137, null, s12, 0, s5                 // 0000001D3984: D5207C89 0015000C
	s_add_u32 s8, s22, s8                                      // 0000001D398C: 80080816
	.long 0xd700058b                                           // 0000001D3990: D700058B
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 0000001D3994: 0202040A
	v_lshlrev_b32_e32 v2, 1, v6                                // 0000001D3998: 30040C81
	s_addc_u32 s9, s23, s9                                     // 0000001D399C: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001D39A0: 84868106
	s_load_b256 s[36:43], s[0:1], 0x80                         // 0000001D39A4: F40C0900 F8000080
	s_add_u32 s8, s8, s6                                       // 0000001D39AC: 80080608
	s_addc_u32 s7, s9, s7                                      // 0000001D39B0: 82070709
	.long 0xd700086c                                           // 0000001D39B4: D700086C
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001D39B8: 02020408
	s_mov_b32 s13, 0xcc00                                      // 0000001D39BC: BE8D00FF 0000CC00
	v_add_co_ci_u32_e64 v109, null, s7, 0, s8                  // 0000001D39C4: D5207C6D 00210007
	s_load_b64 s[8:9], s[0:1], 0xa0                            // 0000001D39CC: F4040200 F80000A0
	v_mad_u32_u24 v130, 0x90, v6, s13                          // 0000001D39D4: D60B0082 00360CFF 00000090
	v_and_b32_e32 v106, 0x200, v5                              // 0000001D39E0: 36D40AFF 00000200
	s_add_u32 s0, s48, s34                                     // 0000001D39E8: 80002230
	v_add_co_ci_u32_e64 v140, null, s11, 0, s5                 // 0000001D39EC: D5207C8C 0015000B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D39F4: BF8700C3
	v_mad_u32_u24 v133, 0x900, v1, v130                        // 0000001D39F8: D60B0085 060A02FF 00000900
	.long 0xd44d0005                                           // 0000001D3A04: D44D0005
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001D3A08: 02020280
	s_addc_u32 s1, s49, s35                                    // 0000001D3A0C: 82012331
	.long 0xd7000001                                           // 0000001D3A10: D7000001
	v_cndmask_b32_e32 v1, s0, v106, vcc_lo                     // 0000001D3A14: 0202D400
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001D3A18: D5207C02 00010001
	s_movk_i32 s14, 0x90                                       // 0000001D3A20: B00E0090
	.long 0xd7000001                                           // 0000001D3A24: D7000001
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 0000001D3A28: 0202ED01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D3A2C: BF8701B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D3A30: D5207C02 00020480
	.long 0xd4490004                                           // 0000001D3A38: D4490004
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001D3A3C: 020200BF
	s_waitcnt lgkmcnt(0)                                       // 0000001D3A40: BF89FC07
	.long 0xd700006e                                           // 0000001D3A44: D700006E
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 0000001D3A48: 02020228
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3A4C: BF8700A1
	v_add_co_ci_u32_e64 v111, null, s41, v2, s0                // 0000001D3A50: D5207C6F 00020429
	.long 0xd7000070                                           // 0000001D3A58: D7000070
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 0000001D3A5C: 0202022A
	v_add_co_ci_u32_e64 v113, null, s43, v2, s0                // 0000001D3A60: D5207C71 0002042B
	.long 0xd7000072                                           // 0000001D3A68: D7000072
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000001D3A6C: 02020208
	v_mad_u32_u24 v127, v0, s14, 0x8400                        // 0000001D3A70: D60B007F 03FC1D00 00008400
	v_mul_u32_u24_e32 v129, 0x210, v6                          // 0000001D3A7C: 17020CFF 00000210
	v_mad_u32_u24 v134, v6, s14, 0x8400                        // 0000001D3A84: D60B0086 03FC1D06 00008400
	v_lshl_add_u32 v138, v132, 1, v130                         // 0000001D3A90: D646008A 06090384
	.long 0xd4490006                                           // 0000001D3A98: D4490006
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001D3A9C: 020200FF 0000005F
	v_lshl_or_b32 v141, v132, 2, 0xf100                        // 0000001D3AA4: D656008D 03FD0584 0000F100
	v_and_or_b32 v124, v4, 4, v3                               // 0000001D3AB0: D657007C 040D0904
	v_add_co_ci_u32_e64 v115, null, s9, v2, s0                 // 0000001D3AB8: D5207C73 00020409
	s_mov_b32 s20, 0                                           // 0000001D3AC0: BE940080
	s_mov_b32 s39, 0x41800000                                  // 0000001D3AC4: BEA700FF 41800000
	s_mov_b32 s21, s20                                         // 0000001D3ACC: BE950014
	s_mov_b32 s22, s20                                         // 0000001D3AD0: BE960014
	s_mov_b32 s23, s20                                         // 0000001D3AD4: BE970014
	s_mov_b32 s24, s20                                         // 0000001D3AD8: BE980014
	s_mov_b32 s25, s20                                         // 0000001D3ADC: BE990014
	s_mov_b32 s26, s20                                         // 0000001D3AE0: BE9A0014
	s_mov_b32 s27, s20                                         // 0000001D3AE4: BE9B0014
	s_mov_b32 s40, s20                                         // 0000001D3AE8: BEA80014
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001D3AEC: 7C9800C0
	s_branch 4                                                 // 0000001D3AF0: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x404>
	s_add_i32 s40, s40, 1                                      // 0000001D3AF4: 81288128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D3AF8: BF870009
	s_cmp_eq_u32 s40, s53                                      // 0000001D3AFC: BF063528
	s_cbranch_scc1 7157                                        // 0000001D3B00: BFA21BF5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73d8>
	s_mul_i32 s8, s40, 0xc00                                   // 0000001D3B04: 9608FF28 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D3B0C: BF870499
	s_add_i32 s0, s51, s8                                      // 0000001D3B10: 81000833
	s_ashr_i32 s1, s0, 31                                      // 0000001D3B14: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D3B18: BF870009
	s_lshl_b64 s[10:11], s[0:1], 2                             // 0000001D3B1C: 848A8200
	s_lshl_b32 s1, s40, 6                                      // 0000001D3B20: 84018628
	s_add_u32 s10, s30, s10                                    // 0000001D3B24: 800A0A1E
	s_addc_u32 s11, s31, s11                                   // 0000001D3B28: 820B0B1F
	global_load_b32 v1, v107, s[10:11]                         // 0000001D3B2C: DC520000 010A006B
	s_waitcnt vmcnt(0)                                         // 0000001D3B34: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 0000001D3B38: 7E520501
	s_and_saveexec_b32 s7, vcc_lo                              // 0000001D3B3C: BE87206A
	s_cbranch_execz 77                                         // 0000001D3B40: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x578>
	v_or_b32_e32 v1, s1, v0                                    // 0000001D3B44: 38020001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D3B48: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001D3B4C: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001D3B54: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D3B58: BF870091
	.long 0xd73c0001                                           // 0000001D3B5C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001D3B60: 02020282
	.long 0xd7000001                                           // 0000001D3B64: D7000001
	v_cndmask_b32_e32 v1, s30, v1, vcc_lo                      // 0000001D3B68: 0202021E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D3B6C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s31, v2, s0                  // 0000001D3B70: D5207C02 0002041F
	global_load_b32 v1, v[1:2], off                            // 0000001D3B78: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D3B80: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 0000001D3B84: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001D3B88: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D3B94: BF8701A1
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001D3B98: D6130007 841202FF 3FB8AA3B
	v_rndne_f32_e32 v8, v4                                     // 0000001D3BA4: 7E104704
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001D3BA8: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001D3BB4: 7E0C4703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D3BB8: BF870113
	v_dual_fmac_f32 v7, 0x32a5705f, v1 :: v_dual_sub_f32 v4, v4, v8// 0000001D3BBC: C80A02FF 07041104 32A5705F
	v_sub_f32_e32 v3, v3, v6                                   // 0000001D3BC8: 08060D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3BCC: BF870124
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001D3BD0: 560A04FF 32A5705F
	.long 0xd41b0000                                           // 0000001D3BD8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v2, vcc_lo               // 0000001D3BDC: 020204FF C2CE8ED0
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v3, v3, v5     // 0000001D3BE4: C9080F04 04020B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001D3BEC: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001D3BF0: 7E0C1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D3BF4: BF870193
	v_exp_f32_e32 v4, v4                                       // 0000001D3BF8: 7E084B04
	v_exp_f32_e32 v3, v3                                       // 0000001D3BFC: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D3C00: BF870296
	.long 0xd71c0004                                           // 0000001D3C04: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001D3C08: 02020D04
	.long 0xd71c0003                                           // 0000001D3C0C: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001D3C10: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3C14: BF8700A1
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 0000001D3C18: D5010003 00020680
	.long 0xd41b0000                                           // 0000001D3C20: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v1, vcc_lo               // 0000001D3C24: 020202FF C2CE8ED0
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 0000001D3C2C: D5010004 00020880
	.long 0xd41e0000                                           // 0000001D3C34: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v2, vcc_lo               // 0000001D3C38: 020204FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3C40: BF8700A1
	v_cndmask_b32_e64 v2, 0x7f800000, v3, s0                   // 0000001D3C44: D5010002 000206FF 7F800000
	.long 0xd41e0000                                           // 0000001D3C50: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v1, vcc_lo               // 0000001D3C54: 020202FF 42B17218
	v_cndmask_b32_e64 v1, 0x7f800000, v4, s0                   // 0000001D3C5C: D5010001 000208FF 7F800000
	ds_store_b32 v120, v2                                      // 0000001D3C68: D8340000 00000278
	ds_store_b32 v121, v1                                      // 0000001D3C70: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001D3C78: 8C7E077E
	s_sub_i32 s7, s50, s1                                      // 0000001D3C7C: 81870132
	s_mul_hi_u32 s0, s40, 0xc00                                // 0000001D3C80: 9680FF28 00000C00
	s_add_u32 s28, s8, s2                                      // 0000001D3C88: 801C0208
	s_addc_u32 s29, s0, s3                                     // 0000001D3C8C: 821D0300
	.long 0x7ec23880                                           // 0000001D3C90: 7EC23880
	s_lshl_b64 s[8:9], s[28:29], 9                             // 0000001D3C94: 8488891C
	s_cmp_gt_i32 s7, 0                                         // 0000001D3C98: BF028007
	.long 0xd7000001                                           // 0000001D3C9C: D7000001
	v_cndmask_b32_e32 v0, v122, v8, vcc_lo                     // 0000001D3CA0: 0200117A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3CA4: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v123, s0                 // 0000001D3CA8: D5207C02 0002F609
	s_cselect_b32 s0, -1, 0                                    // 0000001D3CB0: 980080C1
	s_cmp_gt_i32 s7, 1                                         // 0000001D3CB4: BF028107
	v_cndmask_b32_e64 v3, v125, v1, s0                         // 0000001D3CB8: D5010003 0002037D
	v_cndmask_b32_e64 v4, v126, v2, s0                         // 0000001D3CC0: D5010004 0002057E
	global_load_b32 v9, v[3:4], off                            // 0000001D3CC8: DC520000 097C0003
	.long 0xd7000003                                           // 0000001D3CD0: D7000003
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 0000001D3CD4: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3CDC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D3CE0: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D3CE8: D7000005
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 0000001D3CEC: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D3CF4: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3CFC: 980080C1
	s_cmp_gt_i32 s7, 2                                         // 0000001D3D00: BF028207
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D3D04: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D3D0C: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3D14: 980080C1
	s_cmp_gt_i32 s7, 3                                         // 0000001D3D18: BF028307
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D3D1C: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D3D24: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D3D2C: D7000007
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 0000001D3D30: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3D38: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D3D3C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3D44: 980080C1
	global_load_b32 v10, v[3:4], off                           // 0000001D3D48: DC520000 0A7C0003
	global_load_b32 v11, v[5:6], off                           // 0000001D3D50: DC520000 0B7C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D3D58: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D3D60: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D3D68: D7000005
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000001D3D6C: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3D74: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D3D78: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D3D80: D7000007
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000001D3D84: 020202FF 0001E000
	s_cmp_gt_i32 s7, 4                                         // 0000001D3D8C: BF028407
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D3D90: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3D98: 980080C1
	s_cmp_gt_i32 s7, 5                                         // 0000001D3D9C: BF028507
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D3DA0: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D3DA8: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3DB0: 980080C1
	s_cmp_gt_i32 s7, 6                                         // 0000001D3DB4: BF028607
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D3DB8: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D3DC0: D5010007 00020F7D
	.long 0xd700000c                                           // 0000001D3DC8: D700000C
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 0000001D3DCC: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3DD4: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v2, s0                   // 0000001D3DD8: D5207C0D 00020480
	.long 0xd700000e                                           // 0000001D3DE0: D700000E
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 0000001D3DE4: 020202FF 0002A000
	v_add_co_ci_u32_e64 v17, null, 0, v2, s0                   // 0000001D3DEC: D5207C11 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3DF4: 980080C1
	s_cmp_gt_i32 s7, 7                                         // 0000001D3DF8: BF028707
	v_cndmask_b32_e64 v16, v126, v13, s0                       // 0000001D3DFC: D5010010 00021B7E
	v_cndmask_b32_e64 v15, v125, v12, s0                       // 0000001D3E04: D501000F 0002197D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3E0C: 980080C1
	s_cmp_gt_i32 s7, 8                                         // 0000001D3E10: BF028807
	v_cndmask_b32_e64 v18, v126, v17, s0                       // 0000001D3E14: D5010012 0002237E
	v_cndmask_b32_e64 v17, v125, v14, s0                       // 0000001D3E1C: D5010011 00021D7D
	global_load_b32 v12, v[3:4], off                           // 0000001D3E24: DC520000 0C7C0003
	global_load_b32 v13, v[5:6], off                           // 0000001D3E2C: DC520000 0D7C0005
	global_load_b32 v14, v[7:8], off                           // 0000001D3E34: DC520000 0E7C0007
	global_load_b32 v15, v[15:16], off                         // 0000001D3E3C: DC520000 0F7C000F
	global_load_b32 v16, v[17:18], off                         // 0000001D3E44: DC520000 107C0011
	.long 0xd7000003                                           // 0000001D3E4C: D7000003
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000001D3E50: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3E58: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D3E5C: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D3E64: D7000005
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000001D3E68: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D3E70: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3E78: 980080C1
	s_cmp_gt_i32 s7, 9                                         // 0000001D3E7C: BF028907
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D3E80: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D3E88: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3E90: 980080C1
	s_cmp_gt_i32 s7, 10                                        // 0000001D3E94: BF028A07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D3E98: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D3EA0: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D3EA8: D7000007
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 0000001D3EAC: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3EB4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D3EB8: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3EC0: 980080C1
	global_load_b32 v25, v[3:4], off                           // 0000001D3EC4: DC520000 197C0003
	global_load_b32 v26, v[5:6], off                           // 0000001D3ECC: DC520000 1A7C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D3ED4: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D3EDC: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D3EE4: D7000005
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 0000001D3EE8: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3EF0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D3EF4: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D3EFC: D7000007
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 0000001D3F00: 020202FF 00048000
	s_cmp_gt_i32 s7, 11                                        // 0000001D3F08: BF028B07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D3F0C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3F14: 980080C1
	s_cmp_gt_i32 s7, 12                                        // 0000001D3F18: BF028C07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D3F1C: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D3F24: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3F2C: 980080C1
	s_cmp_gt_i32 s7, 13                                        // 0000001D3F30: BF028D07
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D3F34: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D3F3C: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D3F44: D7000011
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 0000001D3F48: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3F50: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D3F54: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D3F5C: D7000013
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000001D3F60: 020202FF 00054000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D3F68: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3F70: 980080C1
	s_cmp_gt_i32 s7, 14                                        // 0000001D3F74: BF028E07
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D3F78: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D3F80: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D3F88: 980080C1
	s_cmp_gt_i32 s7, 15                                        // 0000001D3F8C: BF028F07
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D3F90: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D3F98: D5010013 0002277D
	global_load_b32 v27, v[3:4], off                           // 0000001D3FA0: DC520000 1B7C0003
	global_load_b32 v28, v[5:6], off                           // 0000001D3FA8: DC520000 1C7C0005
	global_load_b32 v29, v[7:8], off                           // 0000001D3FB0: DC520000 1D7C0007
	global_load_b32 v30, v[17:18], off                         // 0000001D3FB8: DC520000 1E7C0011
	global_load_b32 v31, v[19:20], off                         // 0000001D3FC0: DC520000 1F7C0013
	.long 0xd7000003                                           // 0000001D3FC8: D7000003
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 0000001D3FCC: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D3FD4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D3FD8: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D3FE0: D7000005
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 0000001D3FE4: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D3FEC: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D3FF4: 980080C1
	s_cmp_gt_i32 s7, 16                                        // 0000001D3FF8: BF029007
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D3FFC: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D4004: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D400C: 980080C1
	s_cmp_gt_i32 s7, 17                                        // 0000001D4010: BF029107
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4014: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D401C: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D4024: D7000007
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 0000001D4028: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4030: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4034: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D403C: 980080C1
	global_load_b32 v32, v[3:4], off                           // 0000001D4040: DC520000 207C0003
	global_load_b32 v33, v[5:6], off                           // 0000001D4048: DC520000 217C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D4050: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D4058: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D4060: D7000005
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000001D4064: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D406C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4070: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D4078: D7000007
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000001D407C: 020202FF 00072000
	s_cmp_gt_i32 s7, 18                                        // 0000001D4084: BF029207
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4088: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4090: 980080C1
	s_cmp_gt_i32 s7, 19                                        // 0000001D4094: BF029307
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4098: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D40A0: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D40A8: 980080C1
	s_cmp_gt_i32 s7, 20                                        // 0000001D40AC: BF029407
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D40B0: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D40B8: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D40C0: D7000011
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 0000001D40C4: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D40CC: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D40D0: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D40D8: D7000013
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 0000001D40DC: 020202FF 0007E000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D40E4: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D40EC: 980080C1
	s_cmp_gt_i32 s7, 21                                        // 0000001D40F0: BF029507
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D40F4: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D40FC: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4104: 980080C1
	s_cmp_gt_i32 s7, 22                                        // 0000001D4108: BF029607
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D410C: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D4114: D5010013 0002277D
	global_load_b32 v40, v[3:4], off                           // 0000001D411C: DC520000 287C0003
	global_load_b32 v41, v[5:6], off                           // 0000001D4124: DC520000 297C0005
	global_load_b32 v42, v[7:8], off                           // 0000001D412C: DC520000 2A7C0007
	global_load_b32 v34, v[17:18], off                         // 0000001D4134: DC520000 227C0011
	global_load_b32 v35, v[19:20], off                         // 0000001D413C: DC520000 237C0013
	.long 0xd7000003                                           // 0000001D4144: D7000003
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 0000001D4148: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4150: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D4154: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D415C: D7000005
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000001D4160: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4168: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4170: 980080C1
	s_cmp_gt_i32 s7, 23                                        // 0000001D4174: BF029707
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D4178: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D4180: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4188: 980080C1
	s_cmp_gt_i32 s7, 24                                        // 0000001D418C: BF029807
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4190: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4198: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D41A0: D7000007
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000001D41A4: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D41AC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D41B0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D41B8: 980080C1
	global_load_b32 v37, v[3:4], off                           // 0000001D41BC: DC520000 257C0003
	global_load_b32 v36, v[5:6], off                           // 0000001D41C4: DC520000 247C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D41CC: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D41D4: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D41DC: D7000005
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 0000001D41E0: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D41E8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D41EC: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D41F4: D7000007
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 0000001D41F8: 020202FF 0009C000
	s_cmp_gt_i32 s7, 25                                        // 0000001D4200: BF029907
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4204: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D420C: 980080C1
	s_cmp_gt_i32 s7, 26                                        // 0000001D4210: BF029A07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4214: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D421C: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4224: 980080C1
	s_cmp_gt_i32 s7, 27                                        // 0000001D4228: BF029B07
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D422C: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D4234: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D423C: D7000011
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 0000001D4240: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4248: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D424C: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D4254: D7000013
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000001D4258: 020202FF 000A8000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D4260: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4268: 980080C1
	s_cmp_gt_i32 s7, 28                                        // 0000001D426C: BF029C07
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D4270: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D4278: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4280: 980080C1
	s_cmp_gt_i32 s7, 29                                        // 0000001D4284: BF029D07
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D4288: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D4290: D5010013 0002277D
	global_load_b32 v47, v[3:4], off                           // 0000001D4298: DC520000 2F7C0003
	global_load_b32 v44, v[5:6], off                           // 0000001D42A0: DC520000 2C7C0005
	global_load_b32 v43, v[7:8], off                           // 0000001D42A8: DC520000 2B7C0007
	global_load_b32 v38, v[17:18], off                         // 0000001D42B0: DC520000 267C0011
	global_load_b32 v39, v[19:20], off                         // 0000001D42B8: DC520000 277C0013
	.long 0xd7000003                                           // 0000001D42C0: D7000003
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 0000001D42C4: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D42CC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D42D0: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D42D8: D7000005
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 0000001D42DC: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D42E4: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D42EC: 980080C1
	s_cmp_gt_i32 s7, 30                                        // 0000001D42F0: BF029E07
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D42F4: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D42FC: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4304: 980080C1
	s_cmp_gt_i32 s7, 31                                        // 0000001D4308: BF029F07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D430C: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4314: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D431C: D7000007
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 0000001D4320: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4328: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D432C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4334: 980080C1
	global_load_b32 v45, v[3:4], off                           // 0000001D4338: DC520000 2D7C0003
	global_load_b32 v46, v[5:6], off                           // 0000001D4340: DC520000 2E7C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D4348: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D4350: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D4358: D7000005
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000001D435C: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4364: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4368: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D4370: D7000007
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000001D4374: 020202FF 000C6000
	s_cmp_gt_i32 s7, 32                                        // 0000001D437C: BF02A007
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4380: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4388: 980080C1
	s_cmp_gt_i32 s7, 33                                        // 0000001D438C: BF02A107
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4390: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4398: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D43A0: 980080C1
	s_cmp_gt_i32 s7, 34                                        // 0000001D43A4: BF02A207
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D43A8: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D43B0: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D43B8: D7000011
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 0000001D43BC: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D43C4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D43C8: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D43D0: D7000013
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 0000001D43D4: 020202FF 000D2000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D43DC: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D43E4: 980080C1
	s_cmp_gt_i32 s7, 35                                        // 0000001D43E8: BF02A307
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D43EC: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D43F4: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D43FC: 980080C1
	s_cmp_gt_i32 s7, 36                                        // 0000001D4400: BF02A407
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D4404: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D440C: D5010013 0002277D
	global_load_b32 v105, v[3:4], off                          // 0000001D4414: DC520000 697C0003
	global_load_b32 v102, v[5:6], off                          // 0000001D441C: DC520000 667C0005
	global_load_b32 v101, v[7:8], off                          // 0000001D4424: DC520000 657C0007
	global_load_b32 v48, v[17:18], off                         // 0000001D442C: DC520000 307C0011
	global_load_b32 v100, v[19:20], off                        // 0000001D4434: DC520000 647C0013
	.long 0xd7000003                                           // 0000001D443C: D7000003
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 0000001D4440: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4448: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D444C: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D4454: D7000005
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000001D4458: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4460: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4468: 980080C1
	s_cmp_gt_i32 s7, 37                                        // 0000001D446C: BF02A507
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D4470: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D4478: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4480: 980080C1
	s_cmp_gt_i32 s7, 38                                        // 0000001D4484: BF02A607
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4488: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4490: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D4498: D7000007
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000001D449C: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D44A4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D44A8: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D44B0: 980080C1
	global_load_b32 v104, v[3:4], off                          // 0000001D44B4: DC520000 687C0003
	global_load_b32 v103, v[5:6], off                          // 0000001D44BC: DC520000 677C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D44C4: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D44CC: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D44D4: D7000005
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 0000001D44D8: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D44E0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D44E4: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D44EC: D7000007
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 0000001D44F0: 020202FF 000F0000
	s_cmp_gt_i32 s7, 39                                        // 0000001D44F8: BF02A707
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D44FC: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4504: 980080C1
	s_cmp_gt_i32 s7, 40                                        // 0000001D4508: BF02A807
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D450C: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4514: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D451C: 980080C1
	s_cmp_gt_i32 s7, 41                                        // 0000001D4520: BF02A907
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D4524: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D452C: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D4534: D7000011
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 0000001D4538: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4540: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D4544: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D454C: D7000013
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000001D4550: 020202FF 000FC000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D4558: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4560: 980080C1
	s_cmp_gt_i32 s7, 42                                        // 0000001D4564: BF02AA07
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D4568: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D4570: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4578: 980080C1
	s_cmp_gt_i32 s7, 43                                        // 0000001D457C: BF02AB07
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D4580: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D4588: D5010013 0002277D
	global_load_b32 v145, v[3:4], off                          // 0000001D4590: DC520000 917C0003
	global_load_b32 v144, v[5:6], off                          // 0000001D4598: DC520000 907C0005
	global_load_b32 v142, v[7:8], off                          // 0000001D45A0: DC520000 8E7C0007
	global_load_b32 v117, v[17:18], off                        // 0000001D45A8: DC520000 757C0011
	global_load_b32 v116, v[19:20], off                        // 0000001D45B0: DC520000 747C0013
	.long 0xd7000003                                           // 0000001D45B8: D7000003
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 0000001D45BC: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D45C4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D45C8: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D45D0: D7000005
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 0000001D45D4: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D45DC: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D45E4: 980080C1
	s_cmp_gt_i32 s7, 44                                        // 0000001D45E8: BF02AC07
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D45EC: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D45F4: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D45FC: 980080C1
	s_cmp_gt_i32 s7, 45                                        // 0000001D4600: BF02AD07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4604: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D460C: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D4614: D7000007
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 0000001D4618: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4620: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4624: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D462C: 980080C1
	global_load_b32 v146, v[3:4], off                          // 0000001D4630: DC520000 927C0003
	global_load_b32 v143, v[5:6], off                          // 0000001D4638: DC520000 8F7C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D4640: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D4648: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D4650: D7000005
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000001D4654: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D465C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4660: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D4668: D7000007
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000001D466C: 020202FF 0011A000
	s_cmp_gt_i32 s7, 46                                        // 0000001D4674: BF02AE07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4678: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4680: 980080C1
	s_cmp_gt_i32 s7, 47                                        // 0000001D4684: BF02AF07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4688: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4690: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4698: 980080C1
	s_cmp_gt_i32 s7, 48                                        // 0000001D469C: BF02B007
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D46A0: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D46A8: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D46B0: D7000011
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 0000001D46B4: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D46BC: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D46C0: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D46C8: D7000013
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 0000001D46CC: 020202FF 00126000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D46D4: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D46DC: 980080C1
	s_cmp_gt_i32 s7, 49                                        // 0000001D46E0: BF02B107
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D46E4: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D46EC: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D46F4: 980080C1
	s_cmp_gt_i32 s7, 50                                        // 0000001D46F8: BF02B207
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D46FC: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D4704: D5010013 0002277D
	global_load_b32 v152, v[3:4], off                          // 0000001D470C: DC520000 987C0003
	global_load_b32 v150, v[5:6], off                          // 0000001D4714: DC520000 967C0005
	global_load_b32 v149, v[7:8], off                          // 0000001D471C: DC520000 957C0007
	global_load_b32 v148, v[17:18], off                        // 0000001D4724: DC520000 947C0011
	global_load_b32 v147, v[19:20], off                        // 0000001D472C: DC520000 937C0013
	.long 0xd7000003                                           // 0000001D4734: D7000003
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 0000001D4738: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4740: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D4744: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D474C: D7000005
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 0000001D4750: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4758: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4760: 980080C1
	s_cmp_gt_i32 s7, 51                                        // 0000001D4764: BF02B307
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D4768: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D4770: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4778: 980080C1
	s_cmp_gt_i32 s7, 52                                        // 0000001D477C: BF02B407
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4780: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4788: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D4790: D7000007
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 0000001D4794: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D479C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D47A0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D47A8: 980080C1
	global_load_b32 v153, v[3:4], off                          // 0000001D47AC: DC520000 997C0003
	global_load_b32 v151, v[5:6], off                          // 0000001D47B4: DC520000 977C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D47BC: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D47C4: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D47CC: D7000005
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 0000001D47D0: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D47D8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D47DC: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D47E4: D7000007
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 0000001D47E8: 020202FF 00144000
	s_cmp_gt_i32 s7, 53                                        // 0000001D47F0: BF02B507
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D47F4: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D47FC: 980080C1
	s_cmp_gt_i32 s7, 54                                        // 0000001D4800: BF02B607
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4804: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D480C: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4814: 980080C1
	s_cmp_gt_i32 s7, 55                                        // 0000001D4818: BF02B707
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D481C: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D4824: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D482C: D7000011
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 0000001D4830: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4838: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D483C: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D4844: D7000013
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 0000001D4848: 020202FF 00150000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D4850: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4858: 980080C1
	s_cmp_gt_i32 s7, 56                                        // 0000001D485C: BF02B807
	v_cndmask_b32_e64 v18, v126, v18, s0                       // 0000001D4860: D5010012 0002257E
	v_cndmask_b32_e64 v17, v125, v17, s0                       // 0000001D4868: D5010011 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4870: 980080C1
	s_cmp_gt_i32 s7, 57                                        // 0000001D4874: BF02B907
	v_cndmask_b32_e64 v20, v126, v20, s0                       // 0000001D4878: D5010014 0002297E
	v_cndmask_b32_e64 v19, v125, v19, s0                       // 0000001D4880: D5010013 0002277D
	global_load_b32 v158, v[3:4], off                          // 0000001D4888: DC520000 9E7C0003
	global_load_b32 v157, v[5:6], off                          // 0000001D4890: DC520000 9D7C0005
	global_load_b32 v156, v[7:8], off                          // 0000001D4898: DC520000 9C7C0007
	global_load_b32 v155, v[17:18], off                        // 0000001D48A0: DC520000 9B7C0011
	global_load_b32 v154, v[19:20], off                        // 0000001D48A8: DC520000 9A7C0013
	.long 0xd7000003                                           // 0000001D48B0: D7000003
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 0000001D48B4: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D48BC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001D48C0: D5207C04 00020480
	.long 0xd7000005                                           // 0000001D48C8: D7000005
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 0000001D48CC: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D48D4: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D48DC: 980080C1
	s_cmp_gt_i32 s7, 58                                        // 0000001D48E0: BF02BA07
	v_cndmask_b32_e64 v4, v126, v4, s0                         // 0000001D48E4: D5010004 0002097E
	v_cndmask_b32_e64 v3, v125, v3, s0                         // 0000001D48EC: D5010003 0002077D
	s_cselect_b32 s0, -1, 0                                    // 0000001D48F4: 980080C1
	s_cmp_gt_i32 s7, 59                                        // 0000001D48F8: BF02BB07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D48FC: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4904: D5010005 00020B7D
	.long 0xd7000007                                           // 0000001D490C: D7000007
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 0000001D4910: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4918: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D491C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4924: 980080C1
	global_load_b32 v159, v[3:4], off                          // 0000001D4928: DC520000 9F7C0003
	global_load_b32 v160, v[5:6], off                          // 0000001D4930: DC520000 A07C0005
	v_cndmask_b32_e64 v4, v126, v8, s0                         // 0000001D4938: D5010004 0002117E
	v_cndmask_b32_e64 v3, v125, v7, s0                         // 0000001D4940: D5010003 00020F7D
	.long 0xd7000005                                           // 0000001D4948: D7000005
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 0000001D494C: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4954: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001D4958: D5207C06 00020480
	.long 0xd7000007                                           // 0000001D4960: D7000007
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 0000001D4964: 020202FF 0016E000
	s_cmp_gt_i32 s7, 60                                        // 0000001D496C: BF02BC07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001D4970: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4978: 980080C1
	s_cmp_gt_i32 s7, 61                                        // 0000001D497C: BF02BD07
	v_cndmask_b32_e64 v6, v126, v6, s0                         // 0000001D4980: D5010006 00020D7E
	v_cndmask_b32_e64 v5, v125, v5, s0                         // 0000001D4988: D5010005 00020B7D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4990: 980080C1
	s_cmp_gt_i32 s7, 62                                        // 0000001D4994: BF02BE07
	v_cndmask_b32_e64 v8, v126, v8, s0                         // 0000001D4998: D5010008 0002117E
	v_cndmask_b32_e64 v7, v125, v7, s0                         // 0000001D49A0: D5010007 00020F7D
	.long 0xd7000011                                           // 0000001D49A8: D7000011
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 0000001D49AC: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D49B4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v2, s0                   // 0000001D49B8: D5207C12 00020480
	.long 0xd7000013                                           // 0000001D49C0: D7000013
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 0000001D49C4: 020202FF 0017A000
	v_add_co_ci_u32_e64 v20, null, 0, v2, s0                   // 0000001D49CC: D5207C14 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001D49D4: 980080C1
	s_cmp_gt_i32 s7, 63                                        // 0000001D49D8: BF02BF07
	v_cndmask_b32_e64 v2, v126, v18, s0                        // 0000001D49DC: D5010002 0002257E
	v_cndmask_b32_e64 v1, v125, v17, s0                        // 0000001D49E4: D5010001 0002237D
	s_cselect_b32 s0, -1, 0                                    // 0000001D49EC: 980080C1
	s_cmp_gt_i32 s50, s1                                       // 0000001D49F0: BF020132
	v_cndmask_b32_e64 v18, v126, v20, s0                       // 0000001D49F4: D5010012 0002297E
	v_cndmask_b32_e64 v17, v125, v19, s0                       // 0000001D49FC: D5010011 0002277D
	global_load_b32 v165, v[3:4], off                          // 0000001D4A04: DC520000 A57C0003
	global_load_b32 v164, v[5:6], off                          // 0000001D4A0C: DC520000 A47C0005
	global_load_b32 v162, v[7:8], off                          // 0000001D4A14: DC520000 A27C0007
	global_load_b32 v161, v[1:2], off                          // 0000001D4A1C: DC520000 A17C0001
	global_load_b32 v163, v[17:18], off                        // 0000001D4A24: DC520000 A37C0011
	s_cselect_b32 s7, -1, 0                                    // 0000001D4A2C: 980780C1
	s_or_b32 s0, s1, 1                                         // 0000001D4A30: 8C008101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4A34: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A38: BF043200
	s_cselect_b32 s8, -1, 0                                    // 0000001D4A3C: 980880C1
	s_or_b32 s0, s1, 2                                         // 0000001D4A40: 8C008201
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A44: BF043200
	s_cselect_b32 s9, -1, 0                                    // 0000001D4A48: 980980C1
	s_or_b32 s0, s1, 3                                         // 0000001D4A4C: 8C008301
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4A50: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A54: BF043200
	s_cselect_b32 s10, -1, 0                                   // 0000001D4A58: 980A80C1
	s_or_b32 s0, s1, 4                                         // 0000001D4A5C: 8C008401
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A60: BF043200
	s_cselect_b32 s11, -1, 0                                   // 0000001D4A64: 980B80C1
	s_or_b32 s0, s1, 5                                         // 0000001D4A68: 8C008501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4A6C: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A70: BF043200
	s_cselect_b32 s12, -1, 0                                   // 0000001D4A74: 980C80C1
	s_or_b32 s0, s1, 6                                         // 0000001D4A78: 8C008601
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A7C: BF043200
	s_cselect_b32 s13, -1, 0                                   // 0000001D4A80: 980D80C1
	s_or_b32 s0, s1, 7                                         // 0000001D4A84: 8C008701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4A88: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A8C: BF043200
	s_cselect_b32 s14, -1, 0                                   // 0000001D4A90: 980E80C1
	s_or_b32 s0, s1, 8                                         // 0000001D4A94: 8C008801
	s_cmp_lt_i32 s0, s50                                       // 0000001D4A98: BF043200
	s_cselect_b32 s42, -1, 0                                   // 0000001D4A9C: 982A80C1
	s_or_b32 s0, s1, 9                                         // 0000001D4AA0: 8C008901
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4AA4: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AA8: BF043200
	s_cselect_b32 s43, -1, 0                                   // 0000001D4AAC: 982B80C1
	s_or_b32 s0, s1, 10                                        // 0000001D4AB0: 8C008A01
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AB4: BF043200
	s_cselect_b32 s54, -1, 0                                   // 0000001D4AB8: 983680C1
	s_or_b32 s0, s1, 11                                        // 0000001D4ABC: 8C008B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4AC0: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AC4: BF043200
	s_cselect_b32 s55, -1, 0                                   // 0000001D4AC8: 983780C1
	s_or_b32 s0, s1, 12                                        // 0000001D4ACC: 8C008C01
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AD0: BF043200
	s_cselect_b32 s56, -1, 0                                   // 0000001D4AD4: 983880C1
	s_or_b32 s0, s1, 13                                        // 0000001D4AD8: 8C008D01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4ADC: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AE0: BF043200
	s_cselect_b32 s57, -1, 0                                   // 0000001D4AE4: 983980C1
	s_or_b32 s0, s1, 14                                        // 0000001D4AE8: 8C008E01
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AEC: BF043200
	s_cselect_b32 s58, -1, 0                                   // 0000001D4AF0: 983A80C1
	s_or_b32 s0, s1, 15                                        // 0000001D4AF4: 8C008F01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4AF8: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4AFC: BF043200
	s_cselect_b32 s59, -1, 0                                   // 0000001D4B00: 983B80C1
	s_or_b32 s0, s1, 16                                        // 0000001D4B04: 8C009001
	s_cmp_lt_i32 s0, s50                                       // 0000001D4B08: BF043200
	s_cselect_b32 s60, -1, 0                                   // 0000001D4B0C: 983C80C1
	s_or_b32 s0, s1, 17                                        // 0000001D4B10: 8C009101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D4B14: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 0000001D4B18: BF043200
	s_cselect_b32 s61, -1, 0                                   // 0000001D4B1C: 983D80C1
	s_or_b32 s62, s1, 18                                       // 0000001D4B20: 8C3E9201
	s_cmp_lt_i32 s62, s50                                      // 0000001D4B24: BF04323E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001D4B28: BF890007
	s_barrier                                                  // 0000001D4B2C: BFBD0000
	buffer_gl0_inv                                             // 0000001D4B30: E0AC0000 00000000
	ds_load_b128 v[166:169], v107 offset:61440                 // 0000001D4B38: DBFCF000 A600006B
	ds_load_b128 v[170:173], v107 offset:61456                 // 0000001D4B40: DBFCF010 AA00006B
	ds_load_b128 v[174:177], v107 offset:61472                 // 0000001D4B48: DBFCF020 AE00006B
	ds_load_b128 v[178:181], v107 offset:61488                 // 0000001D4B50: DBFCF030 B200006B
	ds_load_b128 v[182:185], v107 offset:61504                 // 0000001D4B58: DBFCF040 B600006B
	ds_load_b128 v[186:189], v107 offset:61520                 // 0000001D4B60: DBFCF050 BA00006B
	s_waitcnt lgkmcnt(5)                                       // 0000001D4B68: BF89FC57
	v_dual_mul_f32 v9, v9, v166 :: v_dual_add_nc_u32 v190, s1, v128// 0000001D4B6C: C8E14D09 09BF0001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D4B74: BF8701C1
	v_min_i32_e32 v1, s52, v190                                // 0000001D4B78: 22037C34
	v_dual_mul_f32 v10, v10, v167 :: v_dual_mul_f32 v11, v11, v168// 0000001D4B7C: C8C74F0A 0A0B510B
	s_waitcnt lgkmcnt(4)                                       // 0000001D4B84: BF89FC47
	v_dual_mul_f32 v12, v12, v169 :: v_dual_mul_f32 v13, v13, v170// 0000001D4B88: C8C7530C 0C0D550D
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001D4B90: D6FF7C01 00096101
	v_dual_mul_f32 v14, v14, v171 :: v_dual_mul_f32 v15, v15, v172// 0000001D4B98: C8C7570E 0E0F590F
	s_waitcnt lgkmcnt(3)                                       // 0000001D4BA0: BF89FC37
	v_dual_mul_f32 v16, v16, v173 :: v_dual_mul_f32 v25, v25, v174// 0000001D4BA4: C8C75B10 10195D19
	v_dual_mul_f32 v26, v26, v175 :: v_dual_mul_f32 v27, v27, v176// 0000001D4BAC: C8C75F1A 1A1B611B
	s_waitcnt lgkmcnt(2)                                       // 0000001D4BB4: BF89FC27
	v_dual_mul_f32 v28, v28, v177 :: v_dual_mul_f32 v29, v29, v178// 0000001D4BB8: C8C7631C 1C1D651D
	.long 0xd73c0062                                           // 0000001D4BC0: D73C0062
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000001D4BC4: 02020288
	v_dual_mul_f32 v30, v30, v179 :: v_dual_mul_f32 v31, v31, v180// 0000001D4BC8: C8C7671E 1E1F691F
	s_waitcnt lgkmcnt(1)                                       // 0000001D4BD0: BF89FC17
	v_dual_mul_f32 v32, v32, v181 :: v_dual_mul_f32 v33, v33, v182// 0000001D4BD4: C8C76B20 20216D21
	v_mul_f32_e32 v42, v42, v185                               // 0000001D4BDC: 1055732A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4BE0: BF870094
	.long 0xd7000005                                           // 0000001D4BE4: D7000005
	v_cndmask_b32_e32 v1, s46, v98, vcc_lo                     // 0000001D4BE8: 0202C42E
	v_add_co_ci_u32_e64 v6, null, s47, v99, s0                 // 0000001D4BEC: D5207C06 0002C62F
	s_clause 0xf                                               // 0000001D4BF4: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001D4BF8: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001D4C00: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001D4C08: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001D4C10: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001D4C18: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001D4C20: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001D4C28: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001D4C30: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001D4C38: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001D4C40: DC5E0090 3D7C0005
	global_load_b128 v[49:52], v[5:6], off offset:160          // 0000001D4C48: DC5E00A0 317C0005
	global_load_b128 v[53:56], v[5:6], off offset:176          // 0000001D4C50: DC5E00B0 357C0005
	global_load_b128 v[17:20], v[5:6], off offset:192          // 0000001D4C58: DC5E00C0 117C0005
	global_load_b128 v[21:24], v[5:6], off offset:208          // 0000001D4C60: DC5E00D0 157C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001D4C68: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001D4C70: DC5E00F0 057C0005
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D4C78: CC210009 02004F09
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D4C80: CC220009 02004F0A
	v_fma_mixlo_f16 v10, v11, s39, 0                           // 0000001D4C88: CC21000A 02004F0B
	v_fma_mixhi_f16 v10, v12, s39, 0                           // 0000001D4C90: CC22000A 02004F0C
	v_fma_mixlo_f16 v11, v13, s39, 0                           // 0000001D4C98: CC21000B 02004F0D
	v_fma_mixhi_f16 v11, v14, s39, 0                           // 0000001D4CA0: CC22000B 02004F0E
	v_fma_mixlo_f16 v12, v15, s39, 0                           // 0000001D4CA8: CC21000C 02004F0F
	v_fma_mixhi_f16 v12, v16, s39, 0                           // 0000001D4CB0: CC22000C 02004F10
	v_fma_mixlo_f16 v13, v25, s39, 0                           // 0000001D4CB8: CC21000D 02004F19
	v_fma_mixlo_f16 v14, v27, s39, 0                           // 0000001D4CC0: CC21000E 02004F1B
	v_fma_mixhi_f16 v14, v28, s39, 0                           // 0000001D4CC8: CC22000E 02004F1C
	v_fma_mixlo_f16 v15, v29, s39, 0                           // 0000001D4CD0: CC21000F 02004F1D
	v_fma_mixhi_f16 v15, v30, s39, 0                           // 0000001D4CD8: CC22000F 02004F1E
	v_fma_mixlo_f16 v16, v31, s39, 0                           // 0000001D4CE0: CC210010 02004F1F
	v_fma_mixhi_f16 v16, v32, s39, 0                           // 0000001D4CE8: CC220010 02004F20
	v_fma_mixlo_f16 v25, v33, s39, 0                           // 0000001D4CF0: CC210019 02004F21
	ds_load_b128 v[29:32], v107 offset:61536                   // 0000001D4CF8: DBFCF060 1D00006B
	s_waitcnt lgkmcnt(1)                                       // 0000001D4D00: BF89FC17
	v_dual_mul_f32 v27, v34, v186 :: v_dual_mul_f32 v28, v35, v187// 0000001D4D04: C8C77522 1B1D7723
	v_dual_mul_f32 v33, v37, v188 :: v_dual_mul_f32 v40, v40, v183// 0000001D4D0C: C8C77925 21296F28
	v_mul_f32_e32 v41, v41, v184                               // 0000001D4D14: 10537129
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D4D18: BF870213
	v_fma_mixlo_f16 v27, v27, s39, 0                           // 0000001D4D1C: CC21001B 02004F1B
	v_fma_mixhi_f16 v27, v28, s39, 0                           // 0000001D4D24: CC22001B 02004F1C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D4D2C: BF870004
	v_fma_mixlo_f16 v28, v33, s39, 0                           // 0000001D4D30: CC21001C 02004F21
	v_mul_f32_e32 v37, v36, v189                               // 0000001D4D38: 104B7B24
	ds_load_b128 v[33:36], v107 offset:61552                   // 0000001D4D3C: DBFCF070 2100006B
	v_fma_mixhi_f16 v13, v26, s39, 0                           // 0000001D4D44: CC22000D 02004F1A
	v_fma_mixlo_f16 v26, v41, s39, 0                           // 0000001D4D4C: CC21001A 02004F29
	v_cndmask_b16 v9, 0, v9, s7                                // 0000001D4D54: D65D0009 001E1280
	s_cselect_b32 s0, -1, 0                                    // 0000001D4D5C: 980080C1
	s_or_b32 s7, s1, 19                                        // 0000001D4D60: 8C079301
	v_fma_mixhi_f16 v26, v42, s39, 0                           // 0000001D4D64: CC22001A 02004F2A
	s_cmp_lt_i32 s7, s50                                       // 0000001D4D6C: BF043207
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001D4D70: D65D001A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4D78: 980080C1
	s_or_b32 s7, s1, 20                                        // 0000001D4D7C: 8C079401
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001D4D80: D65D501A 00023480
	s_cmp_lt_i32 s7, s50                                       // 0000001D4D88: BF043207
	s_waitcnt lgkmcnt(1)                                       // 0000001D4D8C: BF89FC17
	v_dual_mul_f32 v29, v47, v29 :: v_dual_mul_f32 v30, v44, v30// 0000001D4D90: C8C63B2F 1D1E3D2C
	s_cselect_b32 s0, -1, 0                                    // 0000001D4D98: 980080C1
	s_or_b32 s7, s1, 21                                        // 0000001D4D9C: 8C079501
	v_mul_f32_e32 v31, v43, v31                                // 0000001D4DA0: 103E3F2B
	s_cmp_lt_i32 s7, s50                                       // 0000001D4DA4: BF043207
	v_cndmask_b16 v9, 0, v9, s8                                // 0000001D4DA8: D65D5009 00221280
	s_cselect_b32 s7, -1, 0                                    // 0000001D4DB0: 980780C1
	s_or_b32 s8, s1, 22                                        // 0000001D4DB4: 8C089601
	v_cndmask_b16 v27, 0, v27, s0                              // 0000001D4DB8: D65D001B 00023680
	s_cmp_lt_i32 s8, s50                                       // 0000001D4DC0: BF043208
	v_fma_mixlo_f16 v29, v29, s39, 0                           // 0000001D4DC4: CC21001D 02004F1D
	s_cselect_b32 s0, -1, 0                                    // 0000001D4DCC: 980080C1
	v_fma_mixhi_f16 v29, v30, s39, 0                           // 0000001D4DD0: CC22001D 02004F1E
	v_fma_mixlo_f16 v30, v31, s39, 0                           // 0000001D4DD8: CC21001E 02004F1F
	s_waitcnt lgkmcnt(0)                                       // 0000001D4DE0: BF89FC07
	v_dual_mul_f32 v31, v38, v32 :: v_dual_mul_f32 v32, v39, v33// 0000001D4DE4: C8C64126 1F204327
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001D4DEC: D65D001C 00023880
	s_or_b32 s0, s1, 23                                        // 0000001D4DF4: 8C009701
	v_cndmask_b16 v27, 0, v27, s7                              // 0000001D4DF8: D65D501B 001E3680
	s_cmp_lt_i32 s0, s50                                       // 0000001D4E00: BF043200
	v_fma_mixhi_f16 v30, v31, s39, 0                           // 0000001D4E04: CC22001E 02004F1F
	v_fma_mixlo_f16 v31, v32, s39, 0                           // 0000001D4E0C: CC21001F 02004F20
	v_mul_f32_e32 v32, v45, v34                                // 0000001D4E14: 1040452D
	v_fma_mixhi_f16 v28, v37, s39, 0                           // 0000001D4E18: CC22001C 02004F25
	s_cselect_b32 s0, -1, 0                                    // 0000001D4E20: 980080C1
	s_or_b32 s7, s1, 24                                        // 0000001D4E24: 8C079801
	v_fma_mixhi_f16 v25, v40, s39, 0                           // 0000001D4E28: CC220019 02004F28
	s_cmp_lt_i32 s7, s50                                       // 0000001D4E30: BF043207
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001D4E34: D65D501C 00023880
	s_cselect_b32 s0, -1, 0                                    // 0000001D4E3C: 980080C1
	ds_load_b128 v[37:40], v107 offset:61568                   // 0000001D4E40: DBFCF080 2500006B
	v_cndmask_b16 v29, 0, v29, s0                              // 0000001D4E48: D65D001D 00023A80
	s_or_b32 s0, s1, 25                                        // 0000001D4E50: 8C009901
	v_cndmask_b16 v10, 0, v10, s9                              // 0000001D4E54: D65D000A 00261480
	s_cmp_lt_i32 s0, s50                                       // 0000001D4E5C: BF043200
	v_cndmask_b16 v10, 0, v10, s10                             // 0000001D4E60: D65D500A 002A1480
	s_cselect_b32 s0, -1, 0                                    // 0000001D4E68: 980080C1
	s_or_b32 s7, s1, 26                                        // 0000001D4E6C: 8C079A01
	v_cndmask_b16 v29, 0, v29, s0                              // 0000001D4E70: D65D501D 00023A80
	s_cmp_lt_i32 s7, s50                                       // 0000001D4E78: BF043207
	v_cndmask_b16 v11, 0, v11, s11                             // 0000001D4E7C: D65D000B 002E1680
	s_cselect_b32 s0, -1, 0                                    // 0000001D4E84: 980080C1
	v_cndmask_b16 v11, 0, v11, s12                             // 0000001D4E88: D65D500B 00321680
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001D4E90: D65D001E 00023C80
	s_or_b32 s0, s1, 27                                        // 0000001D4E98: 8C009B01
	v_cndmask_b16 v12, 0, v12, s13                             // 0000001D4E9C: D65D000C 00361880
	s_cmp_lt_i32 s0, s50                                       // 0000001D4EA4: BF043200
	v_cndmask_b16 v12, 0, v12, s14                             // 0000001D4EA8: D65D500C 003A1880
	s_cselect_b32 s0, -1, 0                                    // 0000001D4EB0: 980080C1
	s_or_b32 s7, s1, 28                                        // 0000001D4EB4: 8C079C01
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001D4EB8: D65D501E 00023C80
	s_cmp_lt_i32 s7, s50                                       // 0000001D4EC0: BF043207
	v_cndmask_b16 v13, 0, v13, s42                             // 0000001D4EC4: D65D000D 00AA1A80
	s_cselect_b32 s0, -1, 0                                    // 0000001D4ECC: 980080C1
	s_or_b32 s7, s1, 29                                        // 0000001D4ED0: 8C079D01
	v_cndmask_b16 v13, 0, v13, s43                             // 0000001D4ED4: D65D500D 00AE1A80
	v_cndmask_b16 v14, 0, v14, s54                             // 0000001D4EDC: D65D000E 00DA1C80
	v_cndmask_b16 v14, 0, v14, s55                             // 0000001D4EE4: D65D500E 00DE1C80
	v_cndmask_b16 v15, 0, v15, s56                             // 0000001D4EEC: D65D000F 00E21E80
	v_cndmask_b16 v15, 0, v15, s57                             // 0000001D4EF4: D65D500F 00E61E80
	v_cndmask_b16 v16, 0, v16, s58                             // 0000001D4EFC: D65D0010 00EA2080
	v_cndmask_b16 v16, 0, v16, s59                             // 0000001D4F04: D65D5010 00EE2080
	s_cmp_lt_i32 s7, s50                                       // 0000001D4F0C: BF043207
	v_cndmask_b16 v31, 0, v31, s0                              // 0000001D4F10: D65D001F 00023E80
	s_cselect_b32 s0, -1, 0                                    // 0000001D4F18: 980080C1
	s_or_b32 s7, s1, 30                                        // 0000001D4F1C: 8C079E01
	v_mul_f32_e32 v34, v105, v36                               // 0000001D4F20: 10444969
	s_cmp_lt_i32 s7, s50                                       // 0000001D4F24: BF043207
	ds_store_b128 v127, v[9:12]                                // 0000001D4F28: DB7C0000 0000097F
	ds_store_b128 v127, v[13:16] offset:16                     // 0000001D4F30: DB7C0010 00000D7F
	ds_load_b128 v[9:12], v107 offset:61584                    // 0000001D4F38: DBFCF090 0900006B
	v_fma_mixhi_f16 v31, v32, s39, 0                           // 0000001D4F40: CC22001F 02004F20
	s_waitcnt lgkmcnt(3)                                       // 0000001D4F48: BF89FC37
	v_dual_mul_f32 v33, v46, v35 :: v_dual_mul_f32 v14, v101, v38// 0000001D4F4C: C8C6472E 210E4D65
	s_cselect_b32 s7, -1, 0                                    // 0000001D4F54: 980780C1
	s_or_b32 s8, s1, 31                                        // 0000001D4F58: 8C089F01
	v_fma_mixhi_f16 v32, v34, s39, 0                           // 0000001D4F5C: CC220020 02004F22
	s_cmp_lt_i32 s8, s50                                       // 0000001D4F64: BF043208
	v_cndmask_b16 v31, 0, v31, s0                              // 0000001D4F68: D65D501F 00023E80
	s_cselect_b32 s0, -1, 0                                    // 0000001D4F70: 980080C1
	v_mul_f32_e32 v13, v102, v37                               // 0000001D4F74: 101A4B66
	v_fma_mixlo_f16 v32, v33, s39, 0                           // 0000001D4F78: CC210020 02004F21
	v_cndmask_b16 v32, 0, v32, s0                              // 0000001D4F80: D65D5020 00024080
	s_or_b32 s0, s1, 32                                        // 0000001D4F88: 8C00A001
	v_cndmask_b16 v25, 0, v25, s60                             // 0000001D4F8C: D65D0019 00F23280
	s_cmp_lt_i32 s0, s50                                       // 0000001D4F94: BF043200
	v_fma_mixlo_f16 v13, v13, s39, 0                           // 0000001D4F98: CC21000D 02004F0D
	v_cndmask_b16 v32, 0, v32, s7                              // 0000001D4FA0: D65D0020 001E4080
	s_cselect_b32 s0, -1, 0                                    // 0000001D4FA8: 980080C1
	s_or_b32 s7, s1, 33                                        // 0000001D4FAC: 8C07A101
	v_fma_mixhi_f16 v13, v14, s39, 0                           // 0000001D4FB0: CC22000D 02004F0E
	s_cmp_lt_i32 s7, s50                                       // 0000001D4FB8: BF043207
	v_cndmask_b16 v25, 0, v25, s61                             // 0000001D4FBC: D65D5019 00F63280
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001D4FC4: D65D000D 00021A80
	s_cselect_b32 s0, -1, 0                                    // 0000001D4FCC: 980080C1
	s_or_b32 s7, s1, 34                                        // 0000001D4FD0: 8C07A201
	v_mul_f32_e32 v14, v48, v39                                // 0000001D4FD4: 101C4F30
	s_cmp_lt_i32 s7, s50                                       // 0000001D4FD8: BF043207
	v_mul_f32_e32 v15, v100, v40                               // 0000001D4FDC: 101E5164
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001D4FE0: D65D500D 00021A80
	s_cselect_b32 s0, -1, 0                                    // 0000001D4FE8: 980080C1
	s_or_b32 s7, s1, 35                                        // 0000001D4FEC: 8C07A301
	s_waitcnt lgkmcnt(0)                                       // 0000001D4FF0: BF89FC07
	v_mul_f32_e32 v16, v104, v9                                // 0000001D4FF4: 10201368
	ds_store_b128 v127, v[25:28] offset:32                     // 0000001D4FF8: DB7C0020 0000197F
	ds_store_b128 v127, v[29:32] offset:48                     // 0000001D5000: DB7C0030 00001D7F
	ds_load_b128 v[25:28], v107 offset:61600                   // 0000001D5008: DBFCF0A0 1900006B
	s_cmp_lt_i32 s7, s50                                       // 0000001D5010: BF043207
	v_fma_mixlo_f16 v14, v14, s39, 0                           // 0000001D5014: CC21000E 02004F0E
	s_cselect_b32 s7, -1, 0                                    // 0000001D501C: 980780C1
	v_fma_mixlo_f16 v9, v15, s39, 0                            // 0000001D5020: CC210009 02004F0F
	s_or_b32 s8, s1, 36                                        // 0000001D5028: 8C08A401
	v_fma_mixhi_f16 v9, v16, s39, 0                            // 0000001D502C: CC220009 02004F10
	s_cmp_lt_i32 s8, s50                                       // 0000001D5034: BF043208
	v_cndmask_b16 v14, 0, v14, s0                              // 0000001D5038: D65D000E 00021C80
	s_cselect_b32 s0, -1, 0                                    // 0000001D5040: 980080C1
	v_cndmask_b16 v14, 0, v9, s7                               // 0000001D5044: D65D400E 001E1280
	s_or_b32 s7, s1, 37                                        // 0000001D504C: 8C07A501
	v_cndmask_b16 v15, 0, v9, s0                               // 0000001D5050: D65D100F 00021280
	v_dual_mul_f32 v9, v103, v10 :: v_dual_mul_f32 v10, v145, v11// 0000001D5058: C8C61567 090A1791
	s_cmp_lt_i32 s7, s50                                       // 0000001D5060: BF043207
	v_mul_f32_e32 v11, v144, v12                               // 0000001D5064: 10161990
	s_cselect_b32 s0, -1, 0                                    // 0000001D5068: 980080C1
	s_or_b32 s7, s1, 38                                        // 0000001D506C: 8C07A601
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D5070: CC210009 02004F09
	s_cmp_lt_i32 s7, s50                                       // 0000001D5078: BF043207
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D507C: CC220009 02004F0A
	s_cselect_b32 s7, -1, 0                                    // 0000001D5084: 980780C1
	s_or_b32 s8, s1, 39                                        // 0000001D5088: 8C08A701
	v_fma_mixhi_f16 v16, v11, s39, 0                           // 0000001D508C: CC220010 02004F0B
	s_cmp_lt_i32 s8, s50                                       // 0000001D5094: BF043208
	v_cndmask_b16 v15, 0, v9, s0                               // 0000001D5098: D65D400F 00021280
	v_cndmask_b16 v16, 0, v9, s7                               // 0000001D50A0: D65D1010 001E1280
	ds_load_b128 v[9:12], v107 offset:61616                    // 0000001D50A8: DBFCF0B0 0900006B
	s_cselect_b32 s0, -1, 0                                    // 0000001D50B0: 980080C1
	s_waitcnt lgkmcnt(1)                                       // 0000001D50B4: BF89FC17
	v_mul_f32_e32 v25, v142, v25                               // 0000001D50B8: 1032338E
	v_cndmask_b16 v16, 0, v16, s0                              // 0000001D50BC: D65D5010 00022080
	s_or_b32 s0, s1, 40                                        // 0000001D50C4: 8C00A801
	v_mul_f32_e32 v26, v117, v26                               // 0000001D50C8: 10343575
	s_cmp_lt_i32 s0, s50                                       // 0000001D50CC: BF043200
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000001D50D0: CC210019 02004F19
	s_cselect_b32 s0, -1, 0                                    // 0000001D50D8: 980080C1
	s_or_b32 s7, s1, 41                                        // 0000001D50DC: 8C07A901
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000001D50E0: CC220019 02004F1A
	s_cmp_lt_i32 s7, s50                                       // 0000001D50E8: BF043207
	v_cndmask_b16 v25, 0, v25, s0                              // 0000001D50EC: D65D0019 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001D50F4: 980080C1
	v_mul_f32_e32 v26, v116, v27                               // 0000001D50F8: 10343774
	v_cndmask_b16 v25, 0, v25, s0                              // 0000001D50FC: D65D5019 00023280
	s_or_b32 s0, s1, 42                                        // 0000001D5104: 8C00AA01
	v_mul_f32_e32 v27, v146, v28                               // 0000001D5108: 10363992
	s_cmp_lt_i32 s0, s50                                       // 0000001D510C: BF043200
	v_fma_mixlo_f16 v26, v26, s39, 0                           // 0000001D5110: CC21001A 02004F1A
	s_cselect_b32 s0, -1, 0                                    // 0000001D5118: 980080C1
	s_or_b32 s7, s1, 43                                        // 0000001D511C: 8C07AB01
	s_waitcnt lgkmcnt(0)                                       // 0000001D5120: BF89FC07
	v_mul_f32_e32 v10, v152, v10                               // 0000001D5124: 10141598
	s_cmp_lt_i32 s7, s50                                       // 0000001D5128: BF043207
	v_fma_mixhi_f16 v26, v27, s39, 0                           // 0000001D512C: CC22001A 02004F1B
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001D5134: D65D001A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001D513C: 980080C1
	s_or_b32 s7, s1, 44                                        // 0000001D5140: 8C07AC01
	v_mul_f32_e32 v9, v143, v9                                 // 0000001D5144: 1012138F
	ds_load_b128 v[28:31], v107 offset:61632                   // 0000001D5148: DBFCF0C0 1C00006B
	s_cmp_lt_i32 s7, s50                                       // 0000001D5150: BF043207
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001D5154: D65D501A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001D515C: 980080C1
	s_or_b32 s7, s1, 45                                        // 0000001D5160: 8C07AD01
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D5164: CC210009 02004F09
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D516C: CC220009 02004F0A
	v_mul_f32_e32 v10, v150, v11                               // 0000001D5174: 10141796
	s_cmp_lt_i32 s7, s50                                       // 0000001D5178: BF043207
	v_mul_f32_e32 v33, v149, v12                               // 0000001D517C: 10421995
	s_cselect_b32 s7, -1, 0                                    // 0000001D5180: 980780C1
	v_cndmask_b16 v27, 0, v9, s0                               // 0000001D5184: D65D001B 00021280
	v_cndmask_b16 v27, 0, v9, s7                               // 0000001D518C: D65D501B 001E1280
	v_fma_mixlo_f16 v32, v10, s39, 0                           // 0000001D5194: CC210020 02004F0A
	ds_load_b128 v[9:12], v107 offset:61648                    // 0000001D519C: DBFCF0D0 0900006B
	s_or_b32 s8, s1, 46                                        // 0000001D51A4: 8C08AE01
	.long 0xd443000d                                           // 0000001D51A8: D443000D
	v_cndmask_b32_e32 v1, s50, v190, vcc_lo                    // 0000001D51AC: 02037C32
	s_cmp_lt_i32 s8, s50                                       // 0000001D51B0: BF043208
	s_cselect_b32 s0, -1, 0                                    // 0000001D51B4: 980080C1
	s_or_b32 s8, s1, 47                                        // 0000001D51B8: 8C08AF01
	s_waitcnt lgkmcnt(1)                                       // 0000001D51BC: BF89FC17
	v_dual_mul_f32 v34, v148, v28 :: v_dual_mul_f32 v29, v147, v29// 0000001D51C0: C8C63994 221C3B93
	s_cmp_lt_i32 s8, s50                                       // 0000001D51C8: BF043208
	v_mul_f32_e32 v30, v153, v30                               // 0000001D51CC: 103C3D99
	s_cselect_b32 s7, -1, 0                                    // 0000001D51D0: 980780C1
	s_or_b32 s8, s1, 48                                        // 0000001D51D4: 8C08B001
	v_fma_mixlo_f16 v40, v34, s39, 0                           // 0000001D51D8: CC210028 02004F22
	s_cmp_lt_i32 s8, s50                                       // 0000001D51E0: BF043208
	v_cndmask_b16 v28, 0, v32, s0                              // 0000001D51E4: D65D001C 00024080
	s_cselect_b32 s0, -1, 0                                    // 0000001D51EC: 980080C1
	v_fma_mixlo_f16 v29, v29, s39, 0                           // 0000001D51F0: CC21001D 02004F1D
	v_fma_mixhi_f16 v29, v30, s39, 0                           // 0000001D51F8: CC22001D 02004F1E
	v_cndmask_b16 v40, 0, v40, s0                              // 0000001D5200: D65D0028 00025080
	s_waitcnt lgkmcnt(0)                                       // 0000001D5208: BF89FC07
	v_mul_f32_e32 v30, v158, v9                                // 0000001D520C: 103C139E
	v_fma_mixhi_f16 v28, v33, s39, 0                           // 0000001D5210: CC22001C 02004F21
	s_or_b32 s0, s1, 49                                        // 0000001D5218: 8C00B101
	ds_load_b128 v[32:35], v107 offset:61664                   // 0000001D521C: DBFCF0E0 2000006B
	ds_load_b128 v[36:39], v107 offset:61680                   // 0000001D5224: DBFCF0F0 2400006B
	s_cmp_lt_i32 s0, s50                                       // 0000001D522C: BF043200
	v_mul_f32_e32 v10, v157, v10                               // 0000001D5230: 1014159D
	v_cndmask_b16 v28, 0, v28, s7                              // 0000001D5234: D65D501C 001E3880
	s_cselect_b32 s0, -1, 0                                    // 0000001D523C: 980080C1
	s_or_b32 s7, s1, 50                                        // 0000001D5240: 8C07B201
	v_cndmask_b16 v40, 0, v29, s0                              // 0000001D5244: D65D4028 00023A80
	s_cmp_lt_i32 s7, s50                                       // 0000001D524C: BF043207
	v_fma_mixhi_f16 v9, v30, s39, 0                            // 0000001D5250: CC220009 02004F1E
	s_cselect_b32 s7, -1, 0                                    // 0000001D5258: 980780C1
	s_or_b32 s8, s1, 51                                        // 0000001D525C: 8C08B301
	v_cndmask_b16 v41, 0, v29, s7                              // 0000001D5260: D65D1029 001E3A80
	v_mul_f32_e32 v29, v151, v31                               // 0000001D5268: 103A3F97
	s_cmp_lt_i32 s8, s50                                       // 0000001D526C: BF043208
	s_cselect_b32 s0, -1, 0                                    // 0000001D5270: 980080C1
	s_or_b32 s7, s1, 52                                        // 0000001D5274: 8C07B401
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D5278: BF8700C1
	v_fma_mixlo_f16 v9, v29, s39, 0                            // 0000001D527C: CC210009 02004F1D
	s_cmp_lt_i32 s7, s50                                       // 0000001D5284: BF043207
	s_cselect_b32 s7, -1, 0                                    // 0000001D5288: 980780C1
	s_or_b32 s8, s1, 53                                        // 0000001D528C: 8C08B501
	v_cndmask_b16 v41, 0, v9, s0                               // 0000001D5290: D65D4029 00021280
	v_cndmask_b16 v42, 0, v9, s7                               // 0000001D5298: D65D102A 001E1280
	v_mul_f32_e32 v9, v156, v11                                // 0000001D52A0: 1012179C
	v_fma_mixlo_f16 v10, v10, s39, 0                           // 0000001D52A4: CC21000A 02004F0A
	s_cmp_lt_i32 s8, s50                                       // 0000001D52AC: BF043208
	s_waitcnt lgkmcnt(1)                                       // 0000001D52B0: BF89FC17
	v_mul_f32_e32 v11, v160, v34                               // 0000001D52B4: 101645A0
	s_cselect_b32 s0, -1, 0                                    // 0000001D52B8: 980080C1
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D52BC: CC210009 02004F09
	v_cndmask_b16 v42, 0, v10, s0                              // 0000001D52C4: D65D402A 00021480
	s_or_b32 s0, s1, 54                                        // 0000001D52CC: 8C00B601
	v_mul_f32_e32 v10, v155, v12                               // 0000001D52D0: 1014199B
	s_cmp_lt_i32 s0, s50                                       // 0000001D52D4: BF043200
	s_waitcnt lgkmcnt(0)                                       // 0000001D52D8: BF89FC07
	v_mul_f32_e32 v12, v164, v36                               // 0000001D52DC: 101849A4
	s_cselect_b32 s0, -1, 0                                    // 0000001D52E0: 980080C1
	s_or_b32 s7, s1, 55                                        // 0000001D52E4: 8C07B701
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D52E8: CC220009 02004F0A
	s_cmp_lt_i32 s7, s50                                       // 0000001D52F0: BF043207
	v_cndmask_b16 v43, 0, v9, s0                               // 0000001D52F4: D65D002B 00021280
	s_cselect_b32 s7, -1, 0                                    // 0000001D52FC: 980780C1
	s_or_b32 s8, s1, 56                                        // 0000001D5300: 8C08B801
	v_cndmask_b16 v43, 0, v9, s7                               // 0000001D5304: D65D502B 001E1280
	s_cmp_lt_i32 s8, s50                                       // 0000001D530C: BF043208
	v_dual_mul_f32 v9, v154, v32 :: v_dual_mul_f32 v10, v159, v33// 0000001D5310: C8C6419A 090A439F
	s_cselect_b32 s0, -1, 0                                    // 0000001D5318: 980080C1
	s_or_b32 s7, s1, 57                                        // 0000001D531C: 8C07B901
	v_mul_f32_e32 v29, v161, v38                               // 0000001D5320: 103A4DA1
	s_cmp_lt_i32 s7, s50                                       // 0000001D5324: BF043207
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D5328: CC210009 02004F09
	s_cselect_b32 s7, -1, 0                                    // 0000001D5330: 980780C1
	s_or_b32 s8, s1, 58                                        // 0000001D5334: 8C08BA01
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D5338: CC220009 02004F0A
	v_fma_mixlo_f16 v10, v11, s39, 0                           // 0000001D5340: CC21000A 02004F0B
	s_cmp_lt_i32 s8, s50                                       // 0000001D5348: BF043208
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001D534C: D65D0009 00021280
	s_cselect_b32 s0, -1, 0                                    // 0000001D5354: 980080C1
	v_mul_f32_e32 v11, v165, v35                               // 0000001D5358: 101647A5
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001D535C: D65D000A 00021480
	s_or_b32 s0, s1, 59                                        // 0000001D5364: 8C00BB01
	v_cndmask_b16 v9, 0, v9, s7                                // 0000001D5368: D65D5009 001E1280
	s_cmp_lt_i32 s0, s50                                       // 0000001D5370: BF043200
	v_fma_mixhi_f16 v10, v11, s39, 0                           // 0000001D5374: CC22000A 02004F0B
	s_cselect_b32 s0, -1, 0                                    // 0000001D537C: 980080C1
	s_or_b32 s7, s1, 60                                        // 0000001D5380: 8C07BC01
	v_fma_mixlo_f16 v11, v12, s39, 0                           // 0000001D5384: CC21000B 02004F0C
	s_cmp_lt_i32 s7, s50                                       // 0000001D538C: BF043207
	v_mul_f32_e32 v12, v162, v37                               // 0000001D5390: 10184BA2
	s_cselect_b32 s7, -1, 0                                    // 0000001D5394: 980780C1
	s_or_b32 s8, s1, 61                                        // 0000001D5398: 8C08BD01
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001D539C: D65D500A 00021480
	s_cmp_lt_i32 s8, s50                                       // 0000001D53A4: BF043208
	v_cndmask_b16 v11, 0, v11, s7                              // 0000001D53A8: D65D000B 001E1680
	s_cselect_b32 s0, -1, 0                                    // 0000001D53B0: 980080C1
	s_or_b32 s7, s1, 62                                        // 0000001D53B4: 8C07BE01
	v_mul_f32_e32 v30, v163, v39                               // 0000001D53B8: 103C4FA3
	s_cmp_lt_i32 s7, s50                                       // 0000001D53BC: BF043207
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001D53C0: CC22000B 02004F0C
	s_cselect_b32 s7, -1, 0                                    // 0000001D53C8: 980780C1
	s_or_b32 s8, s1, 63                                        // 0000001D53CC: 8C08BF01
	v_fma_mixlo_f16 v12, v29, s39, 0                           // 0000001D53D0: CC21000C 02004F1D
	v_fma_mixhi_f16 v12, v30, s39, 0                           // 0000001D53D8: CC22000C 02004F1E
	s_cmp_lt_i32 s8, s50                                       // 0000001D53E0: BF043208
	v_cndmask_b16 v11, 0, v11, s0                              // 0000001D53E4: D65D500B 00021680
	s_cselect_b32 s0, -1, 0                                    // 0000001D53EC: 980080C1
	v_cndmask_b16 v12, 0, v12, s7                              // 0000001D53F0: D65D000C 001E1880
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001D53F8: D65D500C 00021880
	ds_store_b128 v127, v[13:16] offset:64                     // 0000001D5400: DB7C0040 00000D7F
	ds_store_b128 v127, v[25:28] offset:80                     // 0000001D5408: DB7C0050 0000197F
	ds_store_b128 v127, v[40:43] offset:96                     // 0000001D5410: DB7C0060 0000287F
	ds_store_b128 v127, v[9:12] offset:112                     // 0000001D5418: DB7C0070 0000097F
	s_and_saveexec_b32 s0, s13                                 // 0000001D5420: BE80200D
	s_cbranch_execz 67                                         // 0000001D5424: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1e34>
	s_waitcnt vmcnt(1)                                         // 0000001D5428: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001D542C: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D5430: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001D5434: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001D5438: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001D543C: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001D5440: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001D5444: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001D5448: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001D544C: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001D5450: 7E100301
	v_mov_b32_e32 v17, v1                                      // 0000001D5454: 7E220301
	v_mov_b32_e32 v18, v1                                      // 0000001D5458: 7E240301
	v_mov_b32_e32 v19, v1                                      // 0000001D545C: 7E260301
	v_mov_b32_e32 v20, v1                                      // 0000001D5460: 7E280301
	v_mov_b32_e32 v21, v1                                      // 0000001D5464: 7E2A0301
	v_mov_b32_e32 v22, v1                                      // 0000001D5468: 7E2C0301
	v_mov_b32_e32 v23, v1                                      // 0000001D546C: 7E2E0301
	v_mov_b32_e32 v24, v1                                      // 0000001D5470: 7E300301
	v_mov_b32_e32 v49, v1                                      // 0000001D5474: 7E620301
	v_mov_b32_e32 v50, v1                                      // 0000001D5478: 7E640301
	v_mov_b32_e32 v51, v1                                      // 0000001D547C: 7E660301
	v_mov_b32_e32 v52, v1                                      // 0000001D5480: 7E680301
	v_mov_b32_e32 v53, v1                                      // 0000001D5484: 7E6A0301
	v_mov_b32_e32 v54, v1                                      // 0000001D5488: 7E6C0301
	v_mov_b32_e32 v55, v1                                      // 0000001D548C: 7E6E0301
	v_mov_b32_e32 v56, v1                                      // 0000001D5490: 7E700301
	v_mov_b32_e32 v57, v1                                      // 0000001D5494: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001D5498: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001D549C: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001D54A0: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001D54A4: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001D54A8: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001D54AC: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001D54B0: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001D54B4: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001D54B8: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001D54BC: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001D54C0: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001D54C4: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001D54C8: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001D54CC: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001D54D0: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001D54D4: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001D54D8: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001D54DC: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001D54E0: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001D54E4: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001D54E8: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001D54EC: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001D54F0: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001D54F4: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001D54F8: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001D54FC: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001D5500: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001D5504: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001D5508: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001D550C: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001D5510: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001D5514: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001D5518: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001D551C: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001D5520: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001D5524: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001D5528: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001D552C: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001D5530: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D5534: 8C7E007E
	ds_load_b128 v[9:12], v129                                 // 0000001D5538: DBFC0000 09000081
	ds_load_b128 v[13:16], v129 offset:16                      // 0000001D5540: DBFC0010 0D000081
	ds_load_b128 v[25:28], v129 offset:32                      // 0000001D5548: DBFC0020 19000081
	ds_load_b128 v[29:32], v129 offset:48                      // 0000001D5550: DBFC0030 1D000081
	ds_load_b128 v[33:36], v129 offset:8448                    // 0000001D5558: DBFC2100 21000081
	ds_load_b128 v[37:40], v129 offset:8464                    // 0000001D5560: DBFC2110 25000081
	ds_load_b128 v[41:44], v129 offset:8480                    // 0000001D5568: DBFC2120 29000081
	ds_load_b128 v[45:48], v129 offset:8496                    // 0000001D5570: DBFC2130 2D000081
	ds_load_b128 v[100:103], v129 offset:16896                 // 0000001D5578: DBFC4200 64000081
	ds_load_b128 v[150:153], v129 offset:16912                 // 0000001D5580: DBFC4210 96000081
	v_dual_mov_b32 v149, s27 :: v_dual_mov_b32 v148, s26       // 0000001D5588: CA10001B 9594001A
	v_dual_mov_b32 v147, s25 :: v_dual_mov_b32 v146, s24       // 0000001D5590: CA100019 93920018
	v_dual_mov_b32 v145, s23 :: v_dual_mov_b32 v144, s22       // 0000001D5598: CA100017 91900016
	v_dual_mov_b32 v143, s21 :: v_dual_mov_b32 v142, s20       // 0000001D55A0: CA100015 8F8E0014
	ds_load_b128 v[154:157], v129 offset:16928                 // 0000001D55A8: DBFC4220 9A000081
	ds_load_b128 v[158:161], v129 offset:16944                 // 0000001D55B0: DBFC4230 9E000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D55B8: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001D55BC: CC210009 02004F09
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001D55C4: CC220009 02004F0A
	v_fma_mixlo_f16 v10, v11, s39, 0                           // 0000001D55CC: CC21000A 02004F0B
	v_fma_mixhi_f16 v10, v12, s39, 0                           // 0000001D55D4: CC22000A 02004F0C
	s_waitcnt lgkmcnt(10)                                      // 0000001D55DC: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s39, 0                           // 0000001D55E0: CC21000B 02004F0D
	v_fma_mixhi_f16 v11, v14, s39, 0                           // 0000001D55E8: CC22000B 02004F0E
	v_fma_mixlo_f16 v12, v15, s39, 0                           // 0000001D55F0: CC21000C 02004F0F
	v_fma_mixhi_f16 v12, v16, s39, 0                           // 0000001D55F8: CC22000C 02004F10
	s_waitcnt lgkmcnt(9)                                       // 0000001D5600: BF89FC97
	v_fma_mixlo_f16 v13, v25, s39, 0                           // 0000001D5604: CC21000D 02004F19
	v_fma_mixhi_f16 v13, v26, s39, 0                           // 0000001D560C: CC22000D 02004F1A
	v_fma_mixlo_f16 v14, v27, s39, 0                           // 0000001D5614: CC21000E 02004F1B
	v_fma_mixhi_f16 v14, v28, s39, 0                           // 0000001D561C: CC22000E 02004F1C
	s_waitcnt lgkmcnt(8)                                       // 0000001D5624: BF89FC87
	v_fma_mixlo_f16 v15, v29, s39, 0                           // 0000001D5628: CC21000F 02004F1D
	v_fma_mixhi_f16 v15, v30, s39, 0                           // 0000001D5630: CC22000F 02004F1E
	v_fma_mixlo_f16 v16, v31, s39, 0                           // 0000001D5638: CC210010 02004F1F
	v_fma_mixhi_f16 v16, v32, s39, 0                           // 0000001D5640: CC220010 02004F20
	s_waitcnt lgkmcnt(5)                                       // 0000001D5648: BF89FC57
	v_fma_mixlo_f16 v29, v41, s39, 0                           // 0000001D564C: CC21001D 02004F29
	v_fma_mixhi_f16 v29, v42, s39, 0                           // 0000001D5654: CC22001D 02004F2A
	v_fma_mixlo_f16 v30, v43, s39, 0                           // 0000001D565C: CC21001E 02004F2B
	v_fma_mixhi_f16 v30, v44, s39, 0                           // 0000001D5664: CC22001E 02004F2C
	s_waitcnt lgkmcnt(4)                                       // 0000001D566C: BF89FC47
	v_fma_mixlo_f16 v31, v45, s39, 0                           // 0000001D5670: CC21001F 02004F2D
	v_fma_mixhi_f16 v31, v46, s39, 0                           // 0000001D5678: CC22001F 02004F2E
	v_fma_mixlo_f16 v32, v47, s39, 0                           // 0000001D5680: CC210020 02004F2F
	v_fma_mixhi_f16 v32, v48, s39, 0                           // 0000001D5688: CC220020 02004F30
	s_waitcnt vmcnt(14)                                        // 0000001D5690: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[9:16], v[142:149]// 0000001D5694: CC404029 1E3A1359
	s_waitcnt lgkmcnt(3)                                       // 0000001D569C: BF89FC37
	v_fma_mixlo_f16 v9, v100, s39, 0                           // 0000001D56A0: CC210009 02004F64
	v_fma_mixhi_f16 v9, v101, s39, 0                           // 0000001D56A8: CC220009 02004F65
	v_fma_mixlo_f16 v10, v102, s39, 0                          // 0000001D56B0: CC21000A 02004F66
	v_fma_mixhi_f16 v10, v103, s39, 0                          // 0000001D56B8: CC22000A 02004F67
	ds_load_b128 v[100:103], v129 offset:25376                 // 0000001D56C0: DBFC6320 64000081
	ds_load_b128 v[162:165], v129 offset:25392                 // 0000001D56C8: DBFC6330 A2000081
	v_fma_mixlo_f16 v25, v33, s39, 0                           // 0000001D56D0: CC210019 02004F21
	v_fma_mixhi_f16 v25, v34, s39, 0                           // 0000001D56D8: CC220019 02004F22
	v_fma_mixlo_f16 v26, v35, s39, 0                           // 0000001D56E0: CC21001A 02004F23
	v_fma_mixhi_f16 v26, v36, s39, 0                           // 0000001D56E8: CC22001A 02004F24
	v_fma_mixlo_f16 v27, v37, s39, 0                           // 0000001D56F0: CC21001B 02004F25
	v_fma_mixhi_f16 v27, v38, s39, 0                           // 0000001D56F8: CC22001B 02004F26
	v_fma_mixlo_f16 v28, v39, s39, 0                           // 0000001D5700: CC21001C 02004F27
	v_fma_mixhi_f16 v28, v40, s39, 0                           // 0000001D5708: CC22001C 02004F28
	s_waitcnt lgkmcnt(3)                                       // 0000001D5710: BF89FC37
	v_fma_mixlo_f16 v13, v154, s39, 0                          // 0000001D5714: CC21000D 02004F9A
	v_fma_mixhi_f16 v13, v155, s39, 0                          // 0000001D571C: CC22000D 02004F9B
	v_fma_mixlo_f16 v11, v150, s39, 0                          // 0000001D5724: CC21000B 02004F96
	v_fma_mixhi_f16 v11, v151, s39, 0                          // 0000001D572C: CC22000B 02004F97
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[25:32], v[142:149]// 0000001D5734: CC404021 1E3A3359
	ds_load_b128 v[25:28], v129 offset:25344                   // 0000001D573C: DBFC6300 19000081
	ds_load_b128 v[29:32], v129 offset:25360                   // 0000001D5744: DBFC6310 1D000081
	v_fma_mixlo_f16 v12, v152, s39, 0                          // 0000001D574C: CC21000C 02004F98
	v_fma_mixhi_f16 v12, v153, s39, 0                          // 0000001D5754: CC22000C 02004F99
	s_waitcnt lgkmcnt(3)                                       // 0000001D575C: BF89FC37
	v_fma_mixlo_f16 v154, v100, s39, 0                         // 0000001D5760: CC21009A 02004F64
	v_fma_mixhi_f16 v154, v101, s39, 0                         // 0000001D5768: CC22009A 02004F65
	v_fma_mixlo_f16 v155, v102, s39, 0                         // 0000001D5770: CC21009B 02004F66
	v_fma_mixhi_f16 v155, v103, s39, 0                         // 0000001D5778: CC22009B 02004F67
	ds_load_b128 v[100:103], v129 offset:96                    // 0000001D5780: DBFC0060 64000081
	v_fma_mixlo_f16 v14, v156, s39, 0                          // 0000001D5788: CC21000E 02004F9C
	v_fma_mixhi_f16 v14, v157, s39, 0                          // 0000001D5790: CC22000E 02004F9D
	v_fma_mixlo_f16 v15, v158, s39, 0                          // 0000001D5798: CC21000F 02004F9E
	v_fma_mixhi_f16 v15, v159, s39, 0                          // 0000001D57A0: CC22000F 02004F9F
	v_fma_mixlo_f16 v16, v160, s39, 0                          // 0000001D57A8: CC210010 02004FA0
	v_fma_mixhi_f16 v16, v161, s39, 0                          // 0000001D57B0: CC220010 02004FA1
	s_waitcnt lgkmcnt(3)                                       // 0000001D57B8: BF89FC37
	v_fma_mixlo_f16 v156, v162, s39, 0                         // 0000001D57BC: CC21009C 02004FA2
	v_fma_mixhi_f16 v156, v163, s39, 0                         // 0000001D57C4: CC22009C 02004FA3
	v_fma_mixlo_f16 v157, v164, s39, 0                         // 0000001D57CC: CC21009D 02004FA4
	v_fma_mixhi_f16 v157, v165, s39, 0                         // 0000001D57D4: CC22009D 02004FA5
	ds_load_b128 v[158:161], v129 offset:64                    // 0000001D57DC: DBFC0040 9E000081
	ds_load_b128 v[166:169], v129 offset:80                    // 0000001D57E4: DBFC0050 A6000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D57EC: BF89FC47
	v_fma_mixlo_f16 v150, v25, s39, 0                          // 0000001D57F0: CC210096 02004F19
	v_fma_mixhi_f16 v150, v26, s39, 0                          // 0000001D57F8: CC220096 02004F1A
	v_fma_mixlo_f16 v151, v27, s39, 0                          // 0000001D5800: CC210097 02004F1B
	v_fma_mixhi_f16 v151, v28, s39, 0                          // 0000001D5808: CC220097 02004F1C
	s_waitcnt lgkmcnt(3)                                       // 0000001D5810: BF89FC37
	v_fma_mixlo_f16 v152, v29, s39, 0                          // 0000001D5814: CC210098 02004F1D
	v_fma_mixhi_f16 v152, v30, s39, 0                          // 0000001D581C: CC220098 02004F1E
	v_fma_mixlo_f16 v153, v31, s39, 0                          // 0000001D5824: CC210099 02004F1F
	v_fma_mixhi_f16 v153, v32, s39, 0                          // 0000001D582C: CC220099 02004F20
	ds_load_b128 v[162:165], v129 offset:112                   // 0000001D5834: DBFC0070 A2000081
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[9:16], v[142:149]// 0000001D583C: CC404019 1E3A1359
	ds_load_b128 v[170:173], v129 offset:25424                 // 0000001D5844: DBFC6350 AA000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[150:157], v[142:149]// 0000001D584C: CC404009 1E3B2D59
	ds_load_b128 v[142:145], v129 offset:8512                  // 0000001D5854: DBFC2140 8E000081
	ds_load_b128 v[146:149], v129 offset:8528                  // 0000001D585C: DBFC2150 92000081
	ds_load_b128 v[150:153], v129 offset:8544                  // 0000001D5864: DBFC2160 96000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D586C: BF89FC77
	v_fma_mixlo_f16 v93, v100, s39, 0                          // 0000001D5870: CC21005D 02004F64
	v_fma_mixhi_f16 v93, v101, s39, 0                          // 0000001D5878: CC22005D 02004F65
	v_fma_mixlo_f16 v94, v102, s39, 0                          // 0000001D5880: CC21005E 02004F66
	v_fma_mixhi_f16 v94, v103, s39, 0                          // 0000001D5888: CC22005E 02004F67
	ds_load_b128 v[100:103], v129 offset:8560                  // 0000001D5890: DBFC2170 64000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D5898: BF89FC77
	v_fma_mixlo_f16 v89, v158, s39, 0                          // 0000001D589C: CC210059 02004F9E
	v_fma_mixhi_f16 v89, v159, s39, 0                          // 0000001D58A4: CC220059 02004F9F
	v_fma_mixlo_f16 v90, v160, s39, 0                          // 0000001D58AC: CC21005A 02004FA0
	v_fma_mixhi_f16 v90, v161, s39, 0                          // 0000001D58B4: CC22005A 02004FA1
	ds_load_b128 v[154:157], v129 offset:16960                 // 0000001D58BC: DBFC4240 9A000081
	ds_load_b128 v[158:161], v129 offset:16976                 // 0000001D58C4: DBFC4250 9E000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D58CC: BF89FC87
	v_fma_mixlo_f16 v91, v166, s39, 0                          // 0000001D58D0: CC21005B 02004FA6
	v_fma_mixhi_f16 v91, v167, s39, 0                          // 0000001D58D8: CC22005B 02004FA7
	v_fma_mixlo_f16 v92, v168, s39, 0                          // 0000001D58E0: CC21005C 02004FA8
	v_fma_mixhi_f16 v92, v169, s39, 0                          // 0000001D58E8: CC22005C 02004FA9
	s_waitcnt lgkmcnt(7)                                       // 0000001D58F0: BF89FC77
	v_fma_mixlo_f16 v95, v162, s39, 0                          // 0000001D58F4: CC21005F 02004FA2
	v_fma_mixhi_f16 v95, v163, s39, 0                          // 0000001D58FC: CC22005F 02004FA3
	s_waitcnt lgkmcnt(5)                                       // 0000001D5904: BF89FC57
	v_fma_mixlo_f16 v142, v142, s39, 0                         // 0000001D5908: CC21008E 02004F8E
	v_fma_mixhi_f16 v142, v143, s39, 0                         // 0000001D5910: CC22008E 02004F8F
	v_fma_mixhi_f16 v143, v145, s39, 0                         // 0000001D5918: CC22008F 02004F91
	s_waitcnt lgkmcnt(4)                                       // 0000001D5920: BF89FC47
	v_fma_mixlo_f16 v145, v148, s39, 0                         // 0000001D5924: CC210091 02004F94
	v_fma_mixhi_f16 v145, v149, s39, 0                         // 0000001D592C: CC220091 02004F95
	v_fma_mixlo_f16 v96, v164, s39, 0                          // 0000001D5934: CC210060 02004FA4
	v_fma_mixhi_f16 v96, v165, s39, 0                          // 0000001D593C: CC220060 02004FA5
	s_waitcnt lgkmcnt(2)                                       // 0000001D5944: BF89FC27
	v_fma_mixlo_f16 v148, v100, s39, 0                         // 0000001D5948: CC210094 02004F64
	v_fma_mixhi_f16 v148, v101, s39, 0                         // 0000001D5950: CC220094 02004F65
	v_fma_mixlo_f16 v149, v102, s39, 0                         // 0000001D5958: CC210095 02004F66
	v_fma_mixhi_f16 v149, v103, s39, 0                         // 0000001D5960: CC220095 02004F67
	ds_load_b128 v[100:103], v129 offset:25408                 // 0000001D5968: DBFC6340 64000081
	ds_load_b128 v[162:165], v129 offset:16992                 // 0000001D5970: DBFC4260 A2000081
	ds_load_b128 v[166:169], v129 offset:17008                 // 0000001D5978: DBFC4270 A6000081
	ds_load_b128 v[174:177], v129 offset:25440                 // 0000001D5980: DBFC6360 AE000081
	ds_load_b128 v[178:181], v129 offset:25456                 // 0000001D5988: DBFC6370 B2000081
	v_fma_mixlo_f16 v143, v144, s39, 0                         // 0000001D5990: CC21008F 02004F90
	v_fma_mixhi_f16 v144, v147, s39, 0                         // 0000001D5998: CC220090 02004F93
	v_fma_mixlo_f16 v147, v152, s39, 0                         // 0000001D59A0: CC210093 02004F98
	s_waitcnt lgkmcnt(5)                                       // 0000001D59A8: BF89FC57
	v_fma_mixlo_f16 v152, v158, s39, 0                         // 0000001D59AC: CC210098 02004F9E
	v_fma_mixhi_f16 v152, v159, s39, 0                         // 0000001D59B4: CC220098 02004F9F
	v_fma_mixlo_f16 v144, v146, s39, 0                         // 0000001D59BC: CC210090 02004F92
	v_fma_mixlo_f16 v146, v150, s39, 0                         // 0000001D59C4: CC210092 02004F96
	v_fma_mixhi_f16 v146, v151, s39, 0                         // 0000001D59CC: CC220092 02004F97
	v_fma_mixhi_f16 v147, v153, s39, 0                         // 0000001D59D4: CC220093 02004F99
	v_fma_mixlo_f16 v150, v154, s39, 0                         // 0000001D59DC: CC210096 02004F9A
	v_fma_mixhi_f16 v150, v155, s39, 0                         // 0000001D59E4: CC220096 02004F9B
	v_fma_mixlo_f16 v151, v156, s39, 0                         // 0000001D59EC: CC210097 02004F9C
	v_fma_mixhi_f16 v151, v157, s39, 0                         // 0000001D59F4: CC220097 02004F9D
	v_fma_mixlo_f16 v153, v160, s39, 0                         // 0000001D59FC: CC210099 02004FA0
	v_fma_mixhi_f16 v153, v161, s39, 0                         // 0000001D5A04: CC220099 02004FA1
	s_waitcnt lgkmcnt(4)                                       // 0000001D5A0C: BF89FC47
	v_fma_mixlo_f16 v158, v100, s39, 0                         // 0000001D5A10: CC21009E 02004F64
	v_fma_mixhi_f16 v158, v101, s39, 0                         // 0000001D5A18: CC22009E 02004F65
	v_fma_mixlo_f16 v159, v102, s39, 0                         // 0000001D5A20: CC21009F 02004F66
	v_fma_mixhi_f16 v159, v103, s39, 0                         // 0000001D5A28: CC22009F 02004F67
	ds_load_b128 v[100:103], v129 offset:128                   // 0000001D5A30: DBFC0080 64000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D5A38: BF89FC47
	v_fma_mixlo_f16 v154, v162, s39, 0                         // 0000001D5A3C: CC21009A 02004FA2
	v_fma_mixhi_f16 v154, v163, s39, 0                         // 0000001D5A44: CC22009A 02004FA3
	v_fma_mixlo_f16 v155, v164, s39, 0                         // 0000001D5A4C: CC21009B 02004FA4
	v_fma_mixhi_f16 v155, v165, s39, 0                         // 0000001D5A54: CC22009B 02004FA5
	s_waitcnt lgkmcnt(3)                                       // 0000001D5A5C: BF89FC37
	v_fma_mixlo_f16 v156, v166, s39, 0                         // 0000001D5A60: CC21009C 02004FA6
	v_fma_mixhi_f16 v156, v167, s39, 0                         // 0000001D5A68: CC22009C 02004FA7
	v_fma_mixlo_f16 v157, v168, s39, 0                         // 0000001D5A70: CC21009D 02004FA8
	v_fma_mixhi_f16 v157, v169, s39, 0                         // 0000001D5A78: CC22009D 02004FA9
	v_fma_mixlo_f16 v160, v170, s39, 0                         // 0000001D5A80: CC2100A0 02004FAA
	v_fma_mixhi_f16 v160, v171, s39, 0                         // 0000001D5A88: CC2200A0 02004FAB
	v_fma_mixlo_f16 v161, v172, s39, 0                         // 0000001D5A90: CC2100A1 02004FAC
	v_fma_mixhi_f16 v161, v173, s39, 0                         // 0000001D5A98: CC2200A1 02004FAD
	s_waitcnt lgkmcnt(2)                                       // 0000001D5AA0: BF89FC27
	v_fma_mixlo_f16 v162, v174, s39, 0                         // 0000001D5AA4: CC2100A2 02004FAE
	v_fma_mixhi_f16 v162, v175, s39, 0                         // 0000001D5AAC: CC2200A2 02004FAF
	v_fma_mixlo_f16 v163, v176, s39, 0                         // 0000001D5AB4: CC2100A3 02004FB0
	v_fma_mixhi_f16 v163, v177, s39, 0                         // 0000001D5ABC: CC2200A3 02004FB1
	s_waitcnt lgkmcnt(1)                                       // 0000001D5AC4: BF89FC17
	v_fma_mixlo_f16 v164, v178, s39, 0                         // 0000001D5AC8: CC2100A4 02004FB2
	v_fma_mixhi_f16 v164, v179, s39, 0                         // 0000001D5AD0: CC2200A4 02004FB3
	v_fma_mixlo_f16 v165, v180, s39, 0                         // 0000001D5AD8: CC2100A5 02004FB4
	v_fma_mixhi_f16 v165, v181, s39, 0                         // 0000001D5AE0: CC2200A5 02004FB5
	ds_load_b128 v[166:169], v129 offset:144                   // 0000001D5AE8: DBFC0090 A6000081
	ds_load_b128 v[170:173], v129 offset:160                   // 0000001D5AF0: DBFC00A0 AA000081
	s_waitcnt vmcnt(12)                                        // 0000001D5AF8: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 0000001D5AFC: CC404029 1CA6B351
	ds_load_b128 v[89:92], v129 offset:176                     // 0000001D5B04: DBFC00B0 59000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[81:88], v[142:149], v[33:40]// 0000001D5B0C: CC404021 1C871D51
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[150:157], v[25:32]// 0000001D5B14: CC404019 1C672D51
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[158:165], v[9:16]// 0000001D5B1C: CC404009 1C273D51
	ds_load_b128 v[93:96], v129 offset:8576                    // 0000001D5B24: DBFC2180 5D000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D5B2C: BF89FC47
	v_fma_mixlo_f16 v81, v100, s39, 0                          // 0000001D5B30: CC210051 02004F64
	v_fma_mixhi_f16 v81, v101, s39, 0                          // 0000001D5B38: CC220051 02004F65
	v_fma_mixlo_f16 v82, v102, s39, 0                          // 0000001D5B40: CC210052 02004F66
	v_fma_mixhi_f16 v82, v103, s39, 0                          // 0000001D5B48: CC220052 02004F67
	ds_load_b128 v[100:103], v129 offset:8592                  // 0000001D5B50: DBFC2190 64000081
	ds_load_b128 v[142:145], v129 offset:8608                  // 0000001D5B58: DBFC21A0 8E000081
	ds_load_b128 v[146:149], v129 offset:8624                  // 0000001D5B60: DBFC21B0 92000081
	ds_load_b128 v[150:153], v129 offset:17024                 // 0000001D5B68: DBFC4280 96000081
	ds_load_b128 v[154:157], v129 offset:17040                 // 0000001D5B70: DBFC4290 9A000081
	ds_load_b128 v[158:161], v129 offset:17072                 // 0000001D5B78: DBFC42B0 9E000081
	ds_load_b128 v[162:165], v129 offset:25472                 // 0000001D5B80: DBFC6380 A2000081
	ds_load_b128 v[174:177], v129 offset:25520                 // 0000001D5B88: DBFC63B0 AE000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D5B90: BF89FCB7
	v_fma_mixlo_f16 v83, v166, s39, 0                          // 0000001D5B94: CC210053 02004FA6
	v_fma_mixhi_f16 v83, v167, s39, 0                          // 0000001D5B9C: CC220053 02004FA7
	v_fma_mixlo_f16 v84, v168, s39, 0                          // 0000001D5BA4: CC210054 02004FA8
	s_waitcnt lgkmcnt(9)                                       // 0000001D5BAC: BF89FC97
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001D5BB0: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001D5BB8: CC220058 02004F5C
	v_fma_mixhi_f16 v84, v169, s39, 0                          // 0000001D5BC0: CC220054 02004FA9
	v_fma_mixlo_f16 v85, v170, s39, 0                          // 0000001D5BC8: CC210055 02004FAA
	v_fma_mixhi_f16 v85, v171, s39, 0                          // 0000001D5BD0: CC220055 02004FAB
	v_fma_mixlo_f16 v86, v172, s39, 0                          // 0000001D5BD8: CC210056 02004FAC
	v_fma_mixhi_f16 v86, v173, s39, 0                          // 0000001D5BE0: CC220056 02004FAD
	ds_load_b128 v[166:169], v129 offset:25488                 // 0000001D5BE8: DBFC6390 A6000081
	ds_load_b128 v[170:173], v129 offset:25504                 // 0000001D5BF0: DBFC63A0 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D5BF8: BF89FC97
	v_fma_mixlo_f16 v91, v100, s39, 0                          // 0000001D5BFC: CC21005B 02004F64
	v_fma_mixhi_f16 v91, v101, s39, 0                          // 0000001D5C04: CC22005B 02004F65
	v_fma_mixlo_f16 v92, v102, s39, 0                          // 0000001D5C0C: CC21005C 02004F66
	v_fma_mixhi_f16 v92, v103, s39, 0                          // 0000001D5C14: CC22005C 02004F67
	ds_load_b128 v[100:103], v129 offset:17056                 // 0000001D5C1C: DBFC42A0 64000081
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001D5C24: CC220057 02004F5A
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001D5C2C: CC21005A 02004F5F
	s_waitcnt lgkmcnt(8)                                       // 0000001D5C34: BF89FC87
	v_fma_mixlo_f16 v95, v146, s39, 0                          // 0000001D5C38: CC21005F 02004F92
	v_fma_mixhi_f16 v95, v147, s39, 0                          // 0000001D5C40: CC22005F 02004F93
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001D5C48: CC210057 02004F59
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001D5C50: CC210059 02004F5D
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001D5C58: CC220059 02004F5E
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001D5C60: CC22005A 02004F60
	v_fma_mixlo_f16 v93, v142, s39, 0                          // 0000001D5C68: CC21005D 02004F8E
	v_fma_mixhi_f16 v93, v143, s39, 0                          // 0000001D5C70: CC22005D 02004F8F
	v_fma_mixlo_f16 v94, v144, s39, 0                          // 0000001D5C78: CC21005E 02004F90
	v_fma_mixhi_f16 v94, v145, s39, 0                          // 0000001D5C80: CC22005E 02004F91
	v_fma_mixlo_f16 v96, v148, s39, 0                          // 0000001D5C88: CC210060 02004F94
	v_fma_mixhi_f16 v96, v149, s39, 0                          // 0000001D5C90: CC220060 02004F95
	s_waitcnt lgkmcnt(7)                                       // 0000001D5C98: BF89FC77
	v_fma_mixlo_f16 v142, v150, s39, 0                         // 0000001D5C9C: CC21008E 02004F96
	v_fma_mixhi_f16 v142, v151, s39, 0                         // 0000001D5CA4: CC22008E 02004F97
	v_fma_mixlo_f16 v143, v152, s39, 0                         // 0000001D5CAC: CC21008F 02004F98
	v_fma_mixhi_f16 v143, v153, s39, 0                         // 0000001D5CB4: CC22008F 02004F99
	s_waitcnt lgkmcnt(6)                                       // 0000001D5CBC: BF89FC67
	v_fma_mixlo_f16 v144, v154, s39, 0                         // 0000001D5CC0: CC210090 02004F9A
	s_waitcnt lgkmcnt(0)                                       // 0000001D5CC8: BF89FC07
	v_fma_mixlo_f16 v146, v100, s39, 0                         // 0000001D5CCC: CC210092 02004F64
	v_fma_mixhi_f16 v146, v101, s39, 0                         // 0000001D5CD4: CC220092 02004F65
	v_fma_mixlo_f16 v147, v102, s39, 0                         // 0000001D5CDC: CC210093 02004F66
	v_fma_mixhi_f16 v147, v103, s39, 0                         // 0000001D5CE4: CC220093 02004F67
	ds_load_b128 v[100:103], v129 offset:192                   // 0000001D5CEC: DBFC00C0 64000081
	v_fma_mixhi_f16 v144, v155, s39, 0                         // 0000001D5CF4: CC220090 02004F9B
	v_fma_mixlo_f16 v145, v156, s39, 0                         // 0000001D5CFC: CC210091 02004F9C
	v_fma_mixhi_f16 v145, v157, s39, 0                         // 0000001D5D04: CC220091 02004F9D
	v_fma_mixlo_f16 v148, v158, s39, 0                         // 0000001D5D0C: CC210094 02004F9E
	v_fma_mixhi_f16 v148, v159, s39, 0                         // 0000001D5D14: CC220094 02004F9F
	v_fma_mixlo_f16 v149, v160, s39, 0                         // 0000001D5D1C: CC210095 02004FA0
	v_fma_mixhi_f16 v149, v161, s39, 0                         // 0000001D5D24: CC220095 02004FA1
	v_fma_mixlo_f16 v150, v162, s39, 0                         // 0000001D5D2C: CC210096 02004FA2
	v_fma_mixhi_f16 v150, v163, s39, 0                         // 0000001D5D34: CC220096 02004FA3
	v_fma_mixlo_f16 v151, v164, s39, 0                         // 0000001D5D3C: CC210097 02004FA4
	v_fma_mixhi_f16 v151, v165, s39, 0                         // 0000001D5D44: CC220097 02004FA5
	v_fma_mixlo_f16 v152, v166, s39, 0                         // 0000001D5D4C: CC210098 02004FA6
	v_fma_mixhi_f16 v152, v167, s39, 0                         // 0000001D5D54: CC220098 02004FA7
	v_fma_mixlo_f16 v153, v168, s39, 0                         // 0000001D5D5C: CC210099 02004FA8
	v_fma_mixhi_f16 v153, v169, s39, 0                         // 0000001D5D64: CC220099 02004FA9
	v_fma_mixlo_f16 v154, v170, s39, 0                         // 0000001D5D6C: CC21009A 02004FAA
	v_fma_mixhi_f16 v154, v171, s39, 0                         // 0000001D5D74: CC22009A 02004FAB
	v_fma_mixlo_f16 v155, v172, s39, 0                         // 0000001D5D7C: CC21009B 02004FAC
	v_fma_mixhi_f16 v155, v173, s39, 0                         // 0000001D5D84: CC22009B 02004FAD
	v_fma_mixlo_f16 v156, v174, s39, 0                         // 0000001D5D8C: CC21009C 02004FAE
	v_fma_mixhi_f16 v156, v175, s39, 0                         // 0000001D5D94: CC22009C 02004FAF
	v_fma_mixlo_f16 v157, v176, s39, 0                         // 0000001D5D9C: CC21009D 02004FB0
	v_fma_mixhi_f16 v157, v177, s39, 0                         // 0000001D5DA4: CC22009D 02004FB1
	ds_load_b128 v[158:161], v129 offset:208                   // 0000001D5DAC: DBFC00D0 9E000081
	ds_load_b128 v[162:165], v129 offset:224                   // 0000001D5DB4: DBFC00E0 A2000081
	s_waitcnt vmcnt(10)                                        // 0000001D5DBC: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 0000001D5DC0: CC404029 1CA6A349
	ds_load_b128 v[81:84], v129 offset:240                     // 0000001D5DC8: DBFC00F0 51000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[73:80], v[89:96], v[33:40]// 0000001D5DD0: CC404021 1C86B349
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[142:149], v[25:32]// 0000001D5DD8: CC404019 1C671D49
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[150:157], v[9:16]// 0000001D5DE0: CC404009 1C272D49
	ds_load_b128 v[85:88], v129 offset:8640                    // 0000001D5DE8: DBFC21C0 55000081
	ds_load_b128 v[89:92], v129 offset:8656                    // 0000001D5DF0: DBFC21D0 59000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D5DF8: BF89FC57
	v_fma_mixlo_f16 v73, v100, s39, 0                          // 0000001D5DFC: CC210049 02004F64
	v_fma_mixhi_f16 v73, v101, s39, 0                          // 0000001D5E04: CC220049 02004F65
	v_fma_mixlo_f16 v74, v102, s39, 0                          // 0000001D5E0C: CC21004A 02004F66
	v_fma_mixhi_f16 v74, v103, s39, 0                          // 0000001D5E14: CC22004A 02004F67
	ds_load_b128 v[93:96], v129 offset:8672                    // 0000001D5E1C: DBFC21E0 5D000081
	ds_load_b128 v[100:103], v129 offset:8688                  // 0000001D5E24: DBFC21F0 64000081
	ds_load_b128 v[142:145], v129 offset:17088                 // 0000001D5E2C: DBFC42C0 8E000081
	ds_load_b128 v[146:149], v129 offset:17104                 // 0000001D5E34: DBFC42D0 92000081
	ds_load_b128 v[150:153], v129 offset:17120                 // 0000001D5E3C: DBFC42E0 96000081
	ds_load_b128 v[154:157], v129 offset:17136                 // 0000001D5E44: DBFC42F0 9A000081
	s_waitcnt lgkmcnt(10)                                      // 0000001D5E4C: BF89FCA7
	v_fma_mixlo_f16 v75, v158, s39, 0                          // 0000001D5E50: CC21004B 02004F9E
	v_fma_mixhi_f16 v75, v159, s39, 0                          // 0000001D5E58: CC22004B 02004F9F
	v_fma_mixlo_f16 v76, v160, s39, 0                          // 0000001D5E60: CC21004C 02004FA0
	s_waitcnt lgkmcnt(8)                                       // 0000001D5E68: BF89FC87
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001D5E6C: CC22004F 02004F52
	v_fma_mixhi_f16 v76, v161, s39, 0                          // 0000001D5E74: CC22004C 02004FA1
	v_fma_mixlo_f16 v77, v162, s39, 0                          // 0000001D5E7C: CC21004D 02004FA2
	v_fma_mixhi_f16 v77, v163, s39, 0                          // 0000001D5E84: CC22004D 02004FA3
	s_waitcnt lgkmcnt(7)                                       // 0000001D5E8C: BF89FC77
	v_fma_mixlo_f16 v82, v87, s39, 0                           // 0000001D5E90: CC210052 02004F57
	v_fma_mixhi_f16 v82, v88, s39, 0                           // 0000001D5E98: CC220052 02004F58
	v_fma_mixlo_f16 v78, v164, s39, 0                          // 0000001D5EA0: CC21004E 02004FA4
	v_fma_mixhi_f16 v78, v165, s39, 0                          // 0000001D5EA8: CC22004E 02004FA5
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001D5EB0: CC21004F 02004F51
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001D5EB8: CC220050 02004F54
	v_fma_mixlo_f16 v81, v85, s39, 0                           // 0000001D5EC0: CC210051 02004F55
	s_waitcnt lgkmcnt(4)                                       // 0000001D5EC8: BF89FC47
	v_fma_mixlo_f16 v87, v100, s39, 0                          // 0000001D5ECC: CC210057 02004F64
	v_fma_mixhi_f16 v87, v101, s39, 0                          // 0000001D5ED4: CC220057 02004F65
	v_fma_mixlo_f16 v88, v102, s39, 0                          // 0000001D5EDC: CC210058 02004F66
	v_fma_mixhi_f16 v88, v103, s39, 0                          // 0000001D5EE4: CC220058 02004F67
	ds_load_b128 v[100:103], v129 offset:25536                 // 0000001D5EEC: DBFC63C0 64000081
	ds_load_b128 v[158:161], v129 offset:25552                 // 0000001D5EF4: DBFC63D0 9E000081
	v_fma_mixhi_f16 v84, v92, s39, 0                           // 0000001D5EFC: CC220054 02004F5C
	v_fma_mixlo_f16 v85, v93, s39, 0                           // 0000001D5F04: CC210055 02004F5D
	s_waitcnt lgkmcnt(4)                                       // 0000001D5F0C: BF89FC47
	v_fma_mixlo_f16 v92, v148, s39, 0                          // 0000001D5F10: CC21005C 02004F94
	ds_load_b128 v[162:165], v129 offset:25568                 // 0000001D5F18: DBFC63E0 A2000081
	v_fma_mixhi_f16 v92, v149, s39, 0                          // 0000001D5F20: CC22005C 02004F95
	s_waitcnt lgkmcnt(4)                                       // 0000001D5F28: BF89FC47
	v_fma_mixlo_f16 v93, v150, s39, 0                          // 0000001D5F2C: CC21005D 02004F96
	v_fma_mixhi_f16 v93, v151, s39, 0                          // 0000001D5F34: CC22005D 02004F97
	ds_load_b128 v[148:151], v129 offset:25584                 // 0000001D5F3C: DBFC63F0 94000081
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001D5F44: CC210050 02004F53
	v_fma_mixlo_f16 v83, v89, s39, 0                           // 0000001D5F4C: CC210053 02004F59
	v_fma_mixlo_f16 v89, v142, s39, 0                          // 0000001D5F54: CC210059 02004F8E
	v_fma_mixhi_f16 v89, v143, s39, 0                          // 0000001D5F5C: CC220059 02004F8F
	v_fma_mixhi_f16 v81, v86, s39, 0                           // 0000001D5F64: CC220051 02004F56
	v_fma_mixhi_f16 v83, v90, s39, 0                           // 0000001D5F6C: CC220053 02004F5A
	v_fma_mixlo_f16 v84, v91, s39, 0                           // 0000001D5F74: CC210054 02004F5B
	v_fma_mixhi_f16 v85, v94, s39, 0                           // 0000001D5F7C: CC220055 02004F5E
	v_fma_mixlo_f16 v86, v95, s39, 0                           // 0000001D5F84: CC210056 02004F5F
	v_fma_mixhi_f16 v86, v96, s39, 0                           // 0000001D5F8C: CC220056 02004F60
	s_waitcnt lgkmcnt(3)                                       // 0000001D5F94: BF89FC37
	v_fma_mixlo_f16 v142, v100, s39, 0                         // 0000001D5F98: CC21008E 02004F64
	v_fma_mixhi_f16 v142, v101, s39, 0                         // 0000001D5FA0: CC22008E 02004F65
	v_fma_mixlo_f16 v143, v102, s39, 0                         // 0000001D5FA8: CC21008F 02004F66
	v_fma_mixhi_f16 v143, v103, s39, 0                         // 0000001D5FB0: CC22008F 02004F67
	ds_load_b128 v[100:103], v129 offset:256                   // 0000001D5FB8: DBFC0100 64000081
	v_fma_mixlo_f16 v90, v144, s39, 0                          // 0000001D5FC0: CC21005A 02004F90
	v_fma_mixhi_f16 v90, v145, s39, 0                          // 0000001D5FC8: CC22005A 02004F91
	v_fma_mixlo_f16 v91, v146, s39, 0                          // 0000001D5FD0: CC21005B 02004F92
	v_fma_mixhi_f16 v91, v147, s39, 0                          // 0000001D5FD8: CC22005B 02004F93
	v_fma_mixlo_f16 v94, v152, s39, 0                          // 0000001D5FE0: CC21005E 02004F98
	v_fma_mixhi_f16 v94, v153, s39, 0                          // 0000001D5FE8: CC22005E 02004F99
	v_fma_mixlo_f16 v95, v154, s39, 0                          // 0000001D5FF0: CC21005F 02004F9A
	v_fma_mixhi_f16 v95, v155, s39, 0                          // 0000001D5FF8: CC22005F 02004F9B
	v_fma_mixlo_f16 v96, v156, s39, 0                          // 0000001D6000: CC210060 02004F9C
	v_fma_mixhi_f16 v96, v157, s39, 0                          // 0000001D6008: CC220060 02004F9D
	s_waitcnt lgkmcnt(3)                                       // 0000001D6010: BF89FC37
	v_fma_mixlo_f16 v144, v158, s39, 0                         // 0000001D6014: CC210090 02004F9E
	v_fma_mixhi_f16 v144, v159, s39, 0                         // 0000001D601C: CC220090 02004F9F
	v_fma_mixlo_f16 v145, v160, s39, 0                         // 0000001D6024: CC210091 02004FA0
	v_fma_mixhi_f16 v145, v161, s39, 0                         // 0000001D602C: CC220091 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001D6034: BF89FC27
	v_fma_mixlo_f16 v146, v162, s39, 0                         // 0000001D6038: CC210092 02004FA2
	v_fma_mixhi_f16 v146, v163, s39, 0                         // 0000001D6040: CC220092 02004FA3
	v_fma_mixlo_f16 v147, v164, s39, 0                         // 0000001D6048: CC210093 02004FA4
	v_fma_mixhi_f16 v147, v165, s39, 0                         // 0000001D6050: CC220093 02004FA5
	s_waitcnt lgkmcnt(1)                                       // 0000001D6058: BF89FC17
	v_fma_mixlo_f16 v148, v148, s39, 0                         // 0000001D605C: CC210094 02004F94
	v_fma_mixhi_f16 v148, v149, s39, 0                         // 0000001D6064: CC220094 02004F95
	v_fma_mixlo_f16 v149, v150, s39, 0                         // 0000001D606C: CC210095 02004F96
	v_fma_mixhi_f16 v149, v151, s39, 0                         // 0000001D6074: CC220095 02004F97
	ds_load_b128 v[152:155], v129 offset:272                   // 0000001D607C: DBFC0110 98000081
	ds_load_b128 v[156:159], v129 offset:288                   // 0000001D6084: DBFC0120 9C000081
	s_waitcnt vmcnt(8)                                         // 0000001D608C: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 0000001D6090: CC404029 1CA69341
	ds_load_b128 v[73:76], v129 offset:304                     // 0000001D6098: DBFC0130 49000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[81:88], v[33:40]// 0000001D60A0: CC404021 1C86A341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[89:96], v[25:32]// 0000001D60A8: CC404019 1C66B341
	v_wmma_f32_16x16x16_f16 v[9:16], v[65:72], v[142:149], v[9:16]// 0000001D60B0: CC404009 1C271D41
	ds_load_b128 v[77:80], v129 offset:8704                    // 0000001D60B8: DBFC2200 4D000081
	ds_load_b128 v[81:84], v129 offset:8720                    // 0000001D60C0: DBFC2210 51000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D60C8: BF89FC57
	v_fma_mixlo_f16 v65, v100, s39, 0                          // 0000001D60CC: CC210041 02004F64
	v_fma_mixhi_f16 v65, v101, s39, 0                          // 0000001D60D4: CC220041 02004F65
	v_fma_mixlo_f16 v66, v102, s39, 0                          // 0000001D60DC: CC210042 02004F66
	v_fma_mixhi_f16 v66, v103, s39, 0                          // 0000001D60E4: CC220042 02004F67
	ds_load_b128 v[85:88], v129 offset:8736                    // 0000001D60EC: DBFC2220 55000081
	ds_load_b128 v[89:92], v129 offset:8752                    // 0000001D60F4: DBFC2230 59000081
	ds_load_b128 v[93:96], v129 offset:17152                   // 0000001D60FC: DBFC4300 5D000081
	ds_load_b128 v[100:103], v129 offset:17168                 // 0000001D6104: DBFC4310 64000081
	ds_load_b128 v[142:145], v129 offset:17184                 // 0000001D610C: DBFC4320 8E000081
	ds_load_b128 v[146:149], v129 offset:17200                 // 0000001D6114: DBFC4330 92000081
	s_waitcnt lgkmcnt(10)                                      // 0000001D611C: BF89FCA7
	v_fma_mixlo_f16 v67, v152, s39, 0                          // 0000001D6120: CC210043 02004F98
	v_fma_mixhi_f16 v67, v153, s39, 0                          // 0000001D6128: CC220043 02004F99
	ds_load_b128 v[150:153], v129 offset:25616                 // 0000001D6130: DBFC6410 96000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D6138: BF89FC97
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001D613C: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001D6144: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001D614C: CC220048 02004F4C
	v_fma_mixlo_f16 v68, v154, s39, 0                          // 0000001D6154: CC210044 02004F9A
	s_waitcnt lgkmcnt(8)                                       // 0000001D615C: BF89FC87
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001D6160: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001D6168: CC22004A 02004F50
	s_waitcnt lgkmcnt(7)                                       // 0000001D6170: BF89FC77
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001D6174: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001D617C: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001D6184: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001D618C: CC22004C 02004F54
	v_fma_mixhi_f16 v68, v155, s39, 0                          // 0000001D6194: CC220044 02004F9B
	s_waitcnt lgkmcnt(5)                                       // 0000001D619C: BF89FC57
	v_fma_mixlo_f16 v79, v89, s39, 0                           // 0000001D61A0: CC21004F 02004F59
	v_fma_mixhi_f16 v79, v90, s39, 0                           // 0000001D61A8: CC22004F 02004F5A
	v_fma_mixlo_f16 v80, v91, s39, 0                           // 0000001D61B0: CC210050 02004F5B
	v_fma_mixhi_f16 v80, v92, s39, 0                           // 0000001D61B8: CC220050 02004F5C
	ds_load_b128 v[89:92], v129 offset:25600                   // 0000001D61C0: DBFC6400 59000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D61C8: BF89FC57
	v_fma_mixlo_f16 v81, v93, s39, 0                           // 0000001D61CC: CC210051 02004F5D
	v_fma_mixhi_f16 v81, v94, s39, 0                           // 0000001D61D4: CC220051 02004F5E
	v_fma_mixlo_f16 v82, v95, s39, 0                           // 0000001D61DC: CC210052 02004F5F
	v_fma_mixhi_f16 v82, v96, s39, 0                           // 0000001D61E4: CC220052 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001D61EC: BF89FC47
	v_fma_mixlo_f16 v83, v100, s39, 0                          // 0000001D61F0: CC210053 02004F64
	v_fma_mixhi_f16 v83, v101, s39, 0                          // 0000001D61F8: CC220053 02004F65
	v_fma_mixlo_f16 v84, v102, s39, 0                          // 0000001D6200: CC210054 02004F66
	ds_load_b128 v[93:96], v129 offset:25632                   // 0000001D6208: DBFC6420 5D000081
	v_fma_mixhi_f16 v84, v103, s39, 0                          // 0000001D6210: CC220054 02004F67
	ds_load_b128 v[100:103], v129 offset:25648                 // 0000001D6218: DBFC6430 64000081
	v_fma_mixlo_f16 v69, v156, s39, 0                          // 0000001D6220: CC210045 02004F9C
	v_fma_mixhi_f16 v69, v157, s39, 0                          // 0000001D6228: CC220045 02004F9D
	v_fma_mixlo_f16 v70, v158, s39, 0                          // 0000001D6230: CC210046 02004F9E
	v_fma_mixhi_f16 v70, v159, s39, 0                          // 0000001D6238: CC220046 02004F9F
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001D6240: CC210047 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001D6248: CC210049 02004F4D
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001D6250: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001D6258: CC21004D 02004F55
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001D6260: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001D6268: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001D6270: CC22004E 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001D6278: BF89FC57
	v_fma_mixlo_f16 v85, v142, s39, 0                          // 0000001D627C: CC210055 02004F8E
	v_fma_mixhi_f16 v85, v143, s39, 0                          // 0000001D6284: CC220055 02004F8F
	v_fma_mixlo_f16 v86, v144, s39, 0                          // 0000001D628C: CC210056 02004F90
	v_fma_mixhi_f16 v86, v145, s39, 0                          // 0000001D6294: CC220056 02004F91
	s_waitcnt lgkmcnt(4)                                       // 0000001D629C: BF89FC47
	v_fma_mixlo_f16 v87, v146, s39, 0                          // 0000001D62A0: CC210057 02004F92
	v_fma_mixhi_f16 v87, v147, s39, 0                          // 0000001D62A8: CC220057 02004F93
	v_fma_mixlo_f16 v88, v148, s39, 0                          // 0000001D62B0: CC210058 02004F94
	v_fma_mixhi_f16 v88, v149, s39, 0                          // 0000001D62B8: CC220058 02004F95
	s_waitcnt lgkmcnt(2)                                       // 0000001D62C0: BF89FC27
	v_fma_mixlo_f16 v89, v89, s39, 0                           // 0000001D62C4: CC210059 02004F59
	v_fma_mixhi_f16 v89, v90, s39, 0                           // 0000001D62CC: CC220059 02004F5A
	v_fma_mixlo_f16 v90, v91, s39, 0                           // 0000001D62D4: CC21005A 02004F5B
	v_fma_mixhi_f16 v90, v92, s39, 0                           // 0000001D62DC: CC22005A 02004F5C
	v_fma_mixlo_f16 v91, v150, s39, 0                          // 0000001D62E4: CC21005B 02004F96
	v_fma_mixhi_f16 v91, v151, s39, 0                          // 0000001D62EC: CC22005B 02004F97
	v_fma_mixlo_f16 v92, v152, s39, 0                          // 0000001D62F4: CC21005C 02004F98
	v_fma_mixhi_f16 v92, v153, s39, 0                          // 0000001D62FC: CC22005C 02004F99
	s_waitcnt lgkmcnt(1)                                       // 0000001D6304: BF89FC17
	v_fma_mixlo_f16 v93, v93, s39, 0                           // 0000001D6308: CC21005D 02004F5D
	v_fma_mixhi_f16 v93, v94, s39, 0                           // 0000001D6310: CC22005D 02004F5E
	v_fma_mixlo_f16 v94, v95, s39, 0                           // 0000001D6318: CC21005E 02004F5F
	v_fma_mixhi_f16 v94, v96, s39, 0                           // 0000001D6320: CC22005E 02004F60
	s_waitcnt lgkmcnt(0)                                       // 0000001D6328: BF89FC07
	v_fma_mixlo_f16 v95, v100, s39, 0                          // 0000001D632C: CC21005F 02004F64
	v_fma_mixhi_f16 v95, v101, s39, 0                          // 0000001D6334: CC22005F 02004F65
	v_fma_mixlo_f16 v96, v102, s39, 0                          // 0000001D633C: CC210060 02004F66
	v_fma_mixhi_f16 v96, v103, s39, 0                          // 0000001D6344: CC220060 02004F67
	ds_load_b128 v[142:145], v129 offset:320                   // 0000001D634C: DBFC0140 8E000081
	ds_load_b128 v[146:149], v129 offset:336                   // 0000001D6354: DBFC0150 92000081
	ds_load_b128 v[150:153], v129 offset:352                   // 0000001D635C: DBFC0160 96000081
	s_waitcnt vmcnt(6)                                         // 0000001D6364: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 0000001D6368: CC404029 1CA68339
	ds_load_b128 v[65:68], v129 offset:368                     // 0000001D6370: DBFC0170 41000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[57:64], v[73:80], v[33:40]// 0000001D6378: CC404021 1C869339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[81:88], v[25:32]// 0000001D6380: CC404019 1C66A339
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[89:96], v[9:16]// 0000001D6388: CC404009 1C26B339
	ds_load_b128 v[69:72], v129 offset:8768                    // 0000001D6390: DBFC2240 45000081
	ds_load_b128 v[73:76], v129 offset:8784                    // 0000001D6398: DBFC2250 49000081
	ds_load_b128 v[77:80], v129 offset:8800                    // 0000001D63A0: DBFC2260 4D000081
	ds_load_b128 v[81:84], v129 offset:8816                    // 0000001D63A8: DBFC2270 51000081
	ds_load_b128 v[85:88], v129 offset:17216                   // 0000001D63B0: DBFC4340 55000081
	ds_load_b128 v[89:92], v129 offset:17232                   // 0000001D63B8: DBFC4350 59000081
	ds_load_b128 v[93:96], v129 offset:17248                   // 0000001D63C0: DBFC4360 5D000081
	ds_load_b128 v[100:103], v129 offset:17264                 // 0000001D63C8: DBFC4370 64000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D63D0: BF89FCB7
	v_fma_mixlo_f16 v57, v142, s39, 0                          // 0000001D63D4: CC210039 02004F8E
	v_fma_mixhi_f16 v57, v143, s39, 0                          // 0000001D63DC: CC220039 02004F8F
	v_fma_mixlo_f16 v58, v144, s39, 0                          // 0000001D63E4: CC21003A 02004F90
	v_fma_mixhi_f16 v58, v145, s39, 0                          // 0000001D63EC: CC22003A 02004F91
	s_waitcnt lgkmcnt(8)                                       // 0000001D63F4: BF89FC87
	v_fma_mixhi_f16 v63, v66, s39, 0                           // 0000001D63F8: CC22003F 02004F42
	v_fma_mixlo_f16 v64, v67, s39, 0                           // 0000001D6400: CC210040 02004F43
	v_fma_mixhi_f16 v64, v68, s39, 0                           // 0000001D6408: CC220040 02004F44
	ds_load_b128 v[142:145], v129 offset:25680                 // 0000001D6410: DBFC6450 8E000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D6418: BF89FC87
	v_fma_mixlo_f16 v66, v71, s39, 0                           // 0000001D641C: CC210042 02004F47
	v_fma_mixhi_f16 v66, v72, s39, 0                           // 0000001D6424: CC220042 02004F48
	s_waitcnt lgkmcnt(7)                                       // 0000001D642C: BF89FC77
	v_fma_mixlo_f16 v67, v73, s39, 0                           // 0000001D6430: CC210043 02004F49
	v_fma_mixhi_f16 v67, v74, s39, 0                           // 0000001D6438: CC220043 02004F4A
	v_fma_mixlo_f16 v68, v75, s39, 0                           // 0000001D6440: CC210044 02004F4B
	v_fma_mixhi_f16 v68, v76, s39, 0                           // 0000001D6448: CC220044 02004F4C
	s_waitcnt lgkmcnt(5)                                       // 0000001D6450: BF89FC57
	v_fma_mixlo_f16 v71, v81, s39, 0                           // 0000001D6454: CC210047 02004F51
	v_fma_mixhi_f16 v71, v82, s39, 0                           // 0000001D645C: CC220047 02004F52
	v_fma_mixlo_f16 v72, v83, s39, 0                           // 0000001D6464: CC210048 02004F53
	v_fma_mixhi_f16 v72, v84, s39, 0                           // 0000001D646C: CC220048 02004F54
	ds_load_b128 v[81:84], v129 offset:25664                   // 0000001D6474: DBFC6440 51000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D647C: BF89FC57
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001D6480: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001D6488: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001D6490: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001D6498: CC22004A 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001D64A0: BF89FC47
	v_fma_mixlo_f16 v75, v89, s39, 0                           // 0000001D64A4: CC21004B 02004F59
	v_fma_mixhi_f16 v75, v90, s39, 0                           // 0000001D64AC: CC22004B 02004F5A
	v_fma_mixlo_f16 v76, v91, s39, 0                           // 0000001D64B4: CC21004C 02004F5B
	ds_load_b128 v[85:88], v129 offset:25696                   // 0000001D64BC: DBFC6460 55000081
	v_fma_mixhi_f16 v76, v92, s39, 0                           // 0000001D64C4: CC22004C 02004F5C
	ds_load_b128 v[89:92], v129 offset:25712                   // 0000001D64CC: DBFC6470 59000081
	v_fma_mixlo_f16 v59, v146, s39, 0                          // 0000001D64D4: CC21003B 02004F92
	v_fma_mixhi_f16 v59, v147, s39, 0                          // 0000001D64DC: CC22003B 02004F93
	v_fma_mixlo_f16 v60, v148, s39, 0                          // 0000001D64E4: CC21003C 02004F94
	v_fma_mixhi_f16 v60, v149, s39, 0                          // 0000001D64EC: CC22003C 02004F95
	v_fma_mixlo_f16 v61, v150, s39, 0                          // 0000001D64F4: CC21003D 02004F96
	v_fma_mixhi_f16 v61, v151, s39, 0                          // 0000001D64FC: CC22003D 02004F97
	v_fma_mixlo_f16 v62, v152, s39, 0                          // 0000001D6504: CC21003E 02004F98
	v_fma_mixhi_f16 v62, v153, s39, 0                          // 0000001D650C: CC22003E 02004F99
	v_fma_mixlo_f16 v63, v65, s39, 0                           // 0000001D6514: CC21003F 02004F41
	v_fma_mixlo_f16 v65, v69, s39, 0                           // 0000001D651C: CC210041 02004F45
	v_fma_mixhi_f16 v65, v70, s39, 0                           // 0000001D6524: CC220041 02004F46
	v_fma_mixlo_f16 v69, v77, s39, 0                           // 0000001D652C: CC210045 02004F4D
	v_fma_mixhi_f16 v69, v78, s39, 0                           // 0000001D6534: CC220045 02004F4E
	v_fma_mixlo_f16 v70, v79, s39, 0                           // 0000001D653C: CC210046 02004F4F
	v_fma_mixhi_f16 v70, v80, s39, 0                           // 0000001D6544: CC220046 02004F50
	s_waitcnt lgkmcnt(5)                                       // 0000001D654C: BF89FC57
	v_fma_mixlo_f16 v77, v93, s39, 0                           // 0000001D6550: CC21004D 02004F5D
	v_fma_mixhi_f16 v77, v94, s39, 0                           // 0000001D6558: CC22004D 02004F5E
	v_fma_mixlo_f16 v78, v95, s39, 0                           // 0000001D6560: CC21004E 02004F5F
	v_fma_mixhi_f16 v78, v96, s39, 0                           // 0000001D6568: CC22004E 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001D6570: BF89FC47
	v_fma_mixlo_f16 v79, v100, s39, 0                          // 0000001D6574: CC21004F 02004F64
	v_fma_mixhi_f16 v79, v101, s39, 0                          // 0000001D657C: CC22004F 02004F65
	v_fma_mixlo_f16 v80, v102, s39, 0                          // 0000001D6584: CC210050 02004F66
	v_fma_mixhi_f16 v80, v103, s39, 0                          // 0000001D658C: CC220050 02004F67
	s_waitcnt lgkmcnt(2)                                       // 0000001D6594: BF89FC27
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001D6598: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001D65A0: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001D65A8: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001D65B0: CC220052 02004F54
	v_fma_mixlo_f16 v83, v142, s39, 0                          // 0000001D65B8: CC210053 02004F8E
	v_fma_mixhi_f16 v83, v143, s39, 0                          // 0000001D65C0: CC220053 02004F8F
	v_fma_mixlo_f16 v84, v144, s39, 0                          // 0000001D65C8: CC210054 02004F90
	v_fma_mixhi_f16 v84, v145, s39, 0                          // 0000001D65D0: CC220054 02004F91
	s_waitcnt lgkmcnt(1)                                       // 0000001D65D8: BF89FC17
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001D65DC: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001D65E4: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001D65EC: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001D65F4: CC220056 02004F58
	s_waitcnt lgkmcnt(0)                                       // 0000001D65FC: BF89FC07
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001D6600: CC210057 02004F59
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001D6608: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001D6610: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001D6618: CC220058 02004F5C
	ds_load_b128 v[93:96], v129 offset:384                     // 0000001D6620: DBFC0180 5D000081
	ds_load_b128 v[100:103], v129 offset:400                   // 0000001D6628: DBFC0190 64000081
	ds_load_b128 v[142:145], v129 offset:416                   // 0000001D6630: DBFC01A0 8E000081
	s_waitcnt vmcnt(4)                                         // 0000001D6638: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[57:64], v[41:48]// 0000001D663C: CC404029 1CA67331
	ds_load_b128 v[57:60], v129 offset:432                     // 0000001D6644: DBFC01B0 39000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[65:72], v[33:40]// 0000001D664C: CC404021 1C868331
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[73:80], v[25:32]// 0000001D6654: CC404019 1C669331
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[81:88], v[9:16]// 0000001D665C: CC404009 1C26A331
	ds_load_b128 v[61:64], v129 offset:8832                    // 0000001D6664: DBFC2280 3D000081
	ds_load_b128 v[65:68], v129 offset:8848                    // 0000001D666C: DBFC2290 41000081
	ds_load_b128 v[69:72], v129 offset:8864                    // 0000001D6674: DBFC22A0 45000081
	ds_load_b128 v[73:76], v129 offset:8880                    // 0000001D667C: DBFC22B0 49000081
	ds_load_b128 v[77:80], v129 offset:17280                   // 0000001D6684: DBFC4380 4D000081
	ds_load_b128 v[81:84], v129 offset:17296                   // 0000001D668C: DBFC4390 51000081
	ds_load_b128 v[85:88], v129 offset:17312                   // 0000001D6694: DBFC43A0 55000081
	ds_load_b128 v[89:92], v129 offset:17328                   // 0000001D669C: DBFC43B0 59000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D66A4: BF89FCB7
	v_fma_mixlo_f16 v49, v93, s39, 0                           // 0000001D66A8: CC210031 02004F5D
	v_fma_mixhi_f16 v49, v94, s39, 0                           // 0000001D66B0: CC220031 02004F5E
	v_fma_mixlo_f16 v50, v95, s39, 0                           // 0000001D66B8: CC210032 02004F5F
	v_fma_mixhi_f16 v50, v96, s39, 0                           // 0000001D66C0: CC220032 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001D66C8: BF89FC87
	v_fma_mixhi_f16 v55, v58, s39, 0                           // 0000001D66CC: CC220037 02004F3A
	v_fma_mixlo_f16 v56, v59, s39, 0                           // 0000001D66D4: CC210038 02004F3B
	v_fma_mixhi_f16 v56, v60, s39, 0                           // 0000001D66DC: CC220038 02004F3C
	ds_load_b128 v[93:96], v129 offset:25744                   // 0000001D66E4: DBFC6490 5D000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D66EC: BF89FC87
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001D66F0: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001D66F8: CC22003A 02004F40
	s_waitcnt lgkmcnt(7)                                       // 0000001D6700: BF89FC77
	v_fma_mixlo_f16 v59, v65, s39, 0                           // 0000001D6704: CC21003B 02004F41
	v_fma_mixhi_f16 v59, v66, s39, 0                           // 0000001D670C: CC22003B 02004F42
	v_fma_mixlo_f16 v60, v67, s39, 0                           // 0000001D6714: CC21003C 02004F43
	v_fma_mixhi_f16 v60, v68, s39, 0                           // 0000001D671C: CC22003C 02004F44
	s_waitcnt lgkmcnt(5)                                       // 0000001D6724: BF89FC57
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001D6728: CC21003F 02004F49
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001D6730: CC22003F 02004F4A
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001D6738: CC210040 02004F4B
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001D6740: CC220040 02004F4C
	ds_load_b128 v[73:76], v129 offset:25728                   // 0000001D6748: DBFC6480 49000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D6750: BF89FC57
	v_fma_mixlo_f16 v65, v77, s39, 0                           // 0000001D6754: CC210041 02004F4D
	v_fma_mixhi_f16 v65, v78, s39, 0                           // 0000001D675C: CC220041 02004F4E
	v_fma_mixlo_f16 v66, v79, s39, 0                           // 0000001D6764: CC210042 02004F4F
	v_fma_mixhi_f16 v66, v80, s39, 0                           // 0000001D676C: CC220042 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001D6774: BF89FC47
	v_fma_mixlo_f16 v67, v81, s39, 0                           // 0000001D6778: CC210043 02004F51
	v_fma_mixhi_f16 v67, v82, s39, 0                           // 0000001D6780: CC220043 02004F52
	v_fma_mixlo_f16 v68, v83, s39, 0                           // 0000001D6788: CC210044 02004F53
	ds_load_b128 v[77:80], v129 offset:25760                   // 0000001D6790: DBFC64A0 4D000081
	v_fma_mixhi_f16 v68, v84, s39, 0                           // 0000001D6798: CC220044 02004F54
	ds_load_b128 v[81:84], v129 offset:25776                   // 0000001D67A0: DBFC64B0 51000081
	v_fma_mixlo_f16 v51, v100, s39, 0                          // 0000001D67A8: CC210033 02004F64
	v_fma_mixhi_f16 v51, v101, s39, 0                          // 0000001D67B0: CC220033 02004F65
	v_fma_mixlo_f16 v52, v102, s39, 0                          // 0000001D67B8: CC210034 02004F66
	v_fma_mixhi_f16 v52, v103, s39, 0                          // 0000001D67C0: CC220034 02004F67
	v_fma_mixlo_f16 v53, v142, s39, 0                          // 0000001D67C8: CC210035 02004F8E
	v_fma_mixhi_f16 v53, v143, s39, 0                          // 0000001D67D0: CC220035 02004F8F
	v_fma_mixlo_f16 v54, v144, s39, 0                          // 0000001D67D8: CC210036 02004F90
	v_fma_mixhi_f16 v54, v145, s39, 0                          // 0000001D67E0: CC220036 02004F91
	v_fma_mixlo_f16 v55, v57, s39, 0                           // 0000001D67E8: CC210037 02004F39
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001D67F0: CC210039 02004F3D
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001D67F8: CC220039 02004F3E
	v_fma_mixlo_f16 v61, v69, s39, 0                           // 0000001D6800: CC21003D 02004F45
	v_fma_mixhi_f16 v61, v70, s39, 0                           // 0000001D6808: CC22003D 02004F46
	v_fma_mixlo_f16 v62, v71, s39, 0                           // 0000001D6810: CC21003E 02004F47
	v_fma_mixhi_f16 v62, v72, s39, 0                           // 0000001D6818: CC22003E 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000001D6820: BF89FC57
	v_fma_mixlo_f16 v69, v85, s39, 0                           // 0000001D6824: CC210045 02004F55
	v_fma_mixhi_f16 v69, v86, s39, 0                           // 0000001D682C: CC220045 02004F56
	v_fma_mixlo_f16 v70, v87, s39, 0                           // 0000001D6834: CC210046 02004F57
	v_fma_mixhi_f16 v70, v88, s39, 0                           // 0000001D683C: CC220046 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001D6844: BF89FC47
	v_fma_mixlo_f16 v71, v89, s39, 0                           // 0000001D6848: CC210047 02004F59
	v_fma_mixhi_f16 v71, v90, s39, 0                           // 0000001D6850: CC220047 02004F5A
	v_fma_mixlo_f16 v72, v91, s39, 0                           // 0000001D6858: CC210048 02004F5B
	v_fma_mixhi_f16 v72, v92, s39, 0                           // 0000001D6860: CC220048 02004F5C
	s_waitcnt lgkmcnt(2)                                       // 0000001D6868: BF89FC27
	v_fma_mixlo_f16 v73, v73, s39, 0                           // 0000001D686C: CC210049 02004F49
	v_fma_mixhi_f16 v73, v74, s39, 0                           // 0000001D6874: CC220049 02004F4A
	v_fma_mixlo_f16 v74, v75, s39, 0                           // 0000001D687C: CC21004A 02004F4B
	v_fma_mixhi_f16 v74, v76, s39, 0                           // 0000001D6884: CC22004A 02004F4C
	v_fma_mixlo_f16 v75, v93, s39, 0                           // 0000001D688C: CC21004B 02004F5D
	v_fma_mixhi_f16 v75, v94, s39, 0                           // 0000001D6894: CC22004B 02004F5E
	v_fma_mixlo_f16 v76, v95, s39, 0                           // 0000001D689C: CC21004C 02004F5F
	v_fma_mixhi_f16 v76, v96, s39, 0                           // 0000001D68A4: CC22004C 02004F60
	s_waitcnt lgkmcnt(1)                                       // 0000001D68AC: BF89FC17
	v_fma_mixlo_f16 v77, v77, s39, 0                           // 0000001D68B0: CC21004D 02004F4D
	v_fma_mixhi_f16 v77, v78, s39, 0                           // 0000001D68B8: CC22004D 02004F4E
	v_fma_mixlo_f16 v78, v79, s39, 0                           // 0000001D68C0: CC21004E 02004F4F
	v_fma_mixhi_f16 v78, v80, s39, 0                           // 0000001D68C8: CC22004E 02004F50
	s_waitcnt lgkmcnt(0)                                       // 0000001D68D0: BF89FC07
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001D68D4: CC21004F 02004F51
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001D68DC: CC22004F 02004F52
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001D68E4: CC210050 02004F53
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001D68EC: CC220050 02004F54
	ds_load_b128 v[85:88], v129 offset:448                     // 0000001D68F4: DBFC01C0 55000081
	ds_load_b128 v[89:92], v129 offset:464                     // 0000001D68FC: DBFC01D0 59000081
	ds_load_b128 v[93:96], v129 offset:480                     // 0000001D6904: DBFC01E0 5D000081
	s_waitcnt vmcnt(2)                                         // 0000001D690C: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[49:56], v[41:48]// 0000001D6910: CC404029 1CA66311
	ds_load_b128 v[49:52], v129 offset:496                     // 0000001D6918: DBFC01F0 31000081
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[57:64], v[33:40]// 0000001D6920: CC404021 1C867311
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[65:72], v[25:32]// 0000001D6928: CC404019 1C668311
	v_wmma_f32_16x16x16_f16 v[9:16], v[17:24], v[73:80], v[9:16]// 0000001D6930: CC404009 1C269311
	ds_load_b128 v[53:56], v129 offset:8896                    // 0000001D6938: DBFC22C0 35000081
	ds_load_b128 v[57:60], v129 offset:8912                    // 0000001D6940: DBFC22D0 39000081
	ds_load_b128 v[61:64], v129 offset:8928                    // 0000001D6948: DBFC22E0 3D000081
	ds_load_b128 v[65:68], v129 offset:8944                    // 0000001D6950: DBFC22F0 41000081
	ds_load_b128 v[69:72], v129 offset:17344                   // 0000001D6958: DBFC43C0 45000081
	ds_load_b128 v[73:76], v129 offset:17360                   // 0000001D6960: DBFC43D0 49000081
	ds_load_b128 v[77:80], v129 offset:17376                   // 0000001D6968: DBFC43E0 4D000081
	ds_load_b128 v[81:84], v129 offset:17392                   // 0000001D6970: DBFC43F0 51000081
	v_add_nc_u32_e32 v142, s1, v132                            // 0000001D6978: 4B1D0801
	s_waitcnt lgkmcnt(11)                                      // 0000001D697C: BF89FCB7
	v_fma_mixlo_f16 v17, v85, s39, 0                           // 0000001D6980: CC210011 02004F55
	v_fma_mixhi_f16 v17, v86, s39, 0                           // 0000001D6988: CC220011 02004F56
	v_fma_mixlo_f16 v18, v87, s39, 0                           // 0000001D6990: CC210012 02004F57
	v_fma_mixhi_f16 v18, v88, s39, 0                           // 0000001D6998: CC220012 02004F58
	s_waitcnt lgkmcnt(8)                                       // 0000001D69A0: BF89FC87
	v_fma_mixhi_f16 v23, v50, s39, 0                           // 0000001D69A4: CC220017 02004F32
	v_fma_mixlo_f16 v24, v51, s39, 0                           // 0000001D69AC: CC210018 02004F33
	v_fma_mixhi_f16 v24, v52, s39, 0                           // 0000001D69B4: CC220018 02004F34
	ds_load_b128 v[85:88], v129 offset:25808                   // 0000001D69BC: DBFC64D0 55000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D69C4: BF89FC87
	v_fma_mixlo_f16 v50, v55, s39, 0                           // 0000001D69C8: CC210032 02004F37
	v_fma_mixhi_f16 v50, v56, s39, 0                           // 0000001D69D0: CC220032 02004F38
	s_waitcnt lgkmcnt(7)                                       // 0000001D69D8: BF89FC77
	v_fma_mixlo_f16 v51, v57, s39, 0                           // 0000001D69DC: CC210033 02004F39
	v_fma_mixhi_f16 v51, v58, s39, 0                           // 0000001D69E4: CC220033 02004F3A
	v_fma_mixlo_f16 v52, v59, s39, 0                           // 0000001D69EC: CC210034 02004F3B
	v_fma_mixhi_f16 v52, v60, s39, 0                           // 0000001D69F4: CC220034 02004F3C
	s_waitcnt lgkmcnt(5)                                       // 0000001D69FC: BF89FC57
	v_fma_mixlo_f16 v55, v65, s39, 0                           // 0000001D6A00: CC210037 02004F41
	v_fma_mixhi_f16 v55, v66, s39, 0                           // 0000001D6A08: CC220037 02004F42
	v_fma_mixlo_f16 v56, v67, s39, 0                           // 0000001D6A10: CC210038 02004F43
	v_fma_mixhi_f16 v56, v68, s39, 0                           // 0000001D6A18: CC220038 02004F44
	ds_load_b128 v[65:68], v129 offset:25792                   // 0000001D6A20: DBFC64C0 41000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D6A28: BF89FC57
	v_fma_mixlo_f16 v57, v69, s39, 0                           // 0000001D6A2C: CC210039 02004F45
	v_fma_mixhi_f16 v57, v70, s39, 0                           // 0000001D6A34: CC220039 02004F46
	v_fma_mixlo_f16 v58, v71, s39, 0                           // 0000001D6A3C: CC21003A 02004F47
	v_fma_mixhi_f16 v58, v72, s39, 0                           // 0000001D6A44: CC22003A 02004F48
	s_waitcnt lgkmcnt(4)                                       // 0000001D6A4C: BF89FC47
	v_fma_mixlo_f16 v59, v73, s39, 0                           // 0000001D6A50: CC21003B 02004F49
	v_fma_mixhi_f16 v59, v74, s39, 0                           // 0000001D6A58: CC22003B 02004F4A
	ds_load_b128 v[69:72], v129 offset:25824                   // 0000001D6A60: DBFC64E0 45000081
	v_fma_mixlo_f16 v60, v75, s39, 0                           // 0000001D6A68: CC21003C 02004F4B
	v_fma_mixhi_f16 v60, v76, s39, 0                           // 0000001D6A70: CC22003C 02004F4C
	ds_load_b128 v[73:76], v129 offset:25840                   // 0000001D6A78: DBFC64F0 49000081
	v_fma_mixlo_f16 v19, v89, s39, 0                           // 0000001D6A80: CC210013 02004F59
	v_fma_mixhi_f16 v19, v90, s39, 0                           // 0000001D6A88: CC220013 02004F5A
	v_fma_mixlo_f16 v20, v91, s39, 0                           // 0000001D6A90: CC210014 02004F5B
	v_fma_mixhi_f16 v20, v92, s39, 0                           // 0000001D6A98: CC220014 02004F5C
	v_fma_mixlo_f16 v21, v93, s39, 0                           // 0000001D6AA0: CC210015 02004F5D
	v_fma_mixhi_f16 v21, v94, s39, 0                           // 0000001D6AA8: CC220015 02004F5E
	v_fma_mixlo_f16 v22, v95, s39, 0                           // 0000001D6AB0: CC210016 02004F5F
	v_fma_mixhi_f16 v22, v96, s39, 0                           // 0000001D6AB8: CC220016 02004F60
	v_fma_mixlo_f16 v23, v49, s39, 0                           // 0000001D6AC0: CC210017 02004F31
	v_fma_mixlo_f16 v49, v53, s39, 0                           // 0000001D6AC8: CC210031 02004F35
	v_fma_mixhi_f16 v49, v54, s39, 0                           // 0000001D6AD0: CC220031 02004F36
	v_fma_mixlo_f16 v53, v61, s39, 0                           // 0000001D6AD8: CC210035 02004F3D
	v_fma_mixhi_f16 v53, v62, s39, 0                           // 0000001D6AE0: CC220035 02004F3E
	v_fma_mixlo_f16 v54, v63, s39, 0                           // 0000001D6AE8: CC210036 02004F3F
	v_fma_mixhi_f16 v54, v64, s39, 0                           // 0000001D6AF0: CC220036 02004F40
	s_waitcnt lgkmcnt(5)                                       // 0000001D6AF8: BF89FC57
	v_fma_mixlo_f16 v61, v77, s39, 0                           // 0000001D6AFC: CC21003D 02004F4D
	v_fma_mixhi_f16 v61, v78, s39, 0                           // 0000001D6B04: CC22003D 02004F4E
	v_fma_mixlo_f16 v62, v79, s39, 0                           // 0000001D6B0C: CC21003E 02004F4F
	v_fma_mixhi_f16 v62, v80, s39, 0                           // 0000001D6B14: CC22003E 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001D6B1C: BF89FC47
	v_fma_mixlo_f16 v63, v81, s39, 0                           // 0000001D6B20: CC21003F 02004F51
	v_fma_mixhi_f16 v63, v82, s39, 0                           // 0000001D6B28: CC22003F 02004F52
	v_fma_mixlo_f16 v64, v83, s39, 0                           // 0000001D6B30: CC210040 02004F53
	v_fma_mixhi_f16 v64, v84, s39, 0                           // 0000001D6B38: CC220040 02004F54
	s_waitcnt lgkmcnt(2)                                       // 0000001D6B40: BF89FC27
	v_fma_mixlo_f16 v65, v65, s39, 0                           // 0000001D6B44: CC210041 02004F41
	v_fma_mixhi_f16 v65, v66, s39, 0                           // 0000001D6B4C: CC220041 02004F42
	v_fma_mixlo_f16 v66, v67, s39, 0                           // 0000001D6B54: CC210042 02004F43
	v_fma_mixhi_f16 v66, v68, s39, 0                           // 0000001D6B5C: CC220042 02004F44
	v_fma_mixlo_f16 v67, v85, s39, 0                           // 0000001D6B64: CC210043 02004F55
	v_fma_mixhi_f16 v67, v86, s39, 0                           // 0000001D6B6C: CC220043 02004F56
	v_fma_mixlo_f16 v68, v87, s39, 0                           // 0000001D6B74: CC210044 02004F57
	v_fma_mixhi_f16 v68, v88, s39, 0                           // 0000001D6B7C: CC220044 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001D6B84: BF89FC17
	v_fma_mixlo_f16 v69, v69, s39, 0                           // 0000001D6B88: CC210045 02004F45
	v_fma_mixhi_f16 v69, v70, s39, 0                           // 0000001D6B90: CC220045 02004F46
	v_fma_mixlo_f16 v70, v71, s39, 0                           // 0000001D6B98: CC210046 02004F47
	v_fma_mixhi_f16 v70, v72, s39, 0                           // 0000001D6BA0: CC220046 02004F48
	s_waitcnt lgkmcnt(0)                                       // 0000001D6BA8: BF89FC07
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001D6BAC: CC210047 02004F49
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001D6BB4: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001D6BBC: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001D6BC4: CC220048 02004F4C
	s_waitcnt vmcnt(0)                                         // 0000001D6BCC: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[17:24], v[41:48]// 0000001D6BD0: CC404029 1CA62301
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[49:56], v[33:40]// 0000001D6BD8: CC404021 1C866301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[57:64], v[25:32]// 0000001D6BE0: CC404019 1C667301
	.long 0xd4440000                                           // 0000001D6BE8: D4440000
	v_cndmask_b32_e32 v1, s50, v142, vcc_lo                    // 0000001D6BEC: 02031C32
	v_wmma_f32_16x16x16_f16 v[9:16], v[1:8], v[65:72], v[9:16] // 0000001D6BF0: CC404009 1C268301
	s_and_saveexec_b32 s7, s0                                  // 0000001D6BF8: BE872000
	s_cbranch_execz 17                                         // 0000001D6BFC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3544>
	v_mad_u64_u32 v[1:2], null, v142, 48, s[2:3]               // 0000001D6C00: D6FE7C01 0009618E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6C08: BF870091
	.long 0xd73c0001                                           // 0000001D6C0C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6C10: 02020289
	.long 0xd7000101                                           // 0000001D6C14: D7000101
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D6C18: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6C1C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s1                 // 0000001D6C20: D5207C02 00060589
	global_load_b32 v1, v[1:2], off                            // 0000001D6C28: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D6C30: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 0000001D6C34: 560252FF BB800000
	v_fma_mixlo_f16 v97, v1, s39, 0                            // 0000001D6C3C: CC210061 02004F01
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001D6C44: 8C7E077E
	v_add_nc_u32_e32 v143, 2, v142                             // 0000001D6C48: 4B1F1C82
	.long 0x7e023880                                           // 0000001D6C4C: 7E023880
	ds_store_b16 v138, v97                                     // 0000001D6C50: D87C0000 0000618A
	.long 0xd4440001                                           // 0000001D6C58: D4440001
	v_cndmask_b32_e32 v1, s50, v143, vcc_lo                    // 0000001D6C5C: 02031E32
	.long 0x7f023901                                           // 0000001D6C60: 7F023901
	s_and_saveexec_b32 s8, s1                                  // 0000001D6C64: BE882001
	s_cbranch_execz 17                                         // 0000001D6C68: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x35b0>
	v_mad_u64_u32 v[2:3], null, v143, 48, s[2:3]               // 0000001D6C6C: D6FE7C02 0009618F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6C74: BF870091
	.long 0xd73c0002                                           // 0000001D6C78: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D6C7C: 02020489
	.long 0xd7000702                                           // 0000001D6C80: D7000702
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D6C84: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6C88: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s7                 // 0000001D6C8C: D5207C03 001E0789
	global_load_b32 v2, v[2:3], off                            // 0000001D6C94: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D6C9C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v42                         // 0000001D6CA0: 560454FF BB800000
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001D6CA8: CC220001 02004F02
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001D6CB0: 8C7E087E
	v_add_nc_u32_e32 v144, 4, v142                             // 0000001D6CB4: 4B211C84
	ds_store_b16_d16_hi v138, v1 offset:4                      // 0000001D6CB8: DA840004 0000018A
	.long 0xd4440007                                           // 0000001D6CC0: D4440007
	v_cndmask_b32_e32 v1, s50, v144, vcc_lo                    // 0000001D6CC4: 02032032
	s_and_saveexec_b32 s9, s7                                  // 0000001D6CC8: BE892007
	s_cbranch_execz 17                                         // 0000001D6CCC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3614>
	v_mad_u64_u32 v[1:2], null, v144, 48, s[2:3]               // 0000001D6CD0: D6FE7C01 00096190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6CD8: BF870091
	.long 0xd73c0001                                           // 0000001D6CDC: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6CE0: 02020289
	.long 0xd7000801                                           // 0000001D6CE4: D7000801
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D6CE8: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6CEC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s8                 // 0000001D6CF0: D5207C02 00220589
	global_load_b32 v1, v[1:2], off                            // 0000001D6CF8: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D6D00: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v43                         // 0000001D6D04: 560256FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D6D0C: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001D6D14: 8C7E097E
	v_add_nc_u32_e32 v145, 6, v142                             // 0000001D6D18: 4B231C86
	.long 0x7f023880                                           // 0000001D6D1C: 7F023880
	ds_store_b16 v138, v1 offset:8                             // 0000001D6D20: D87C0008 0000018A
	.long 0xd4440008                                           // 0000001D6D28: D4440008
	v_cndmask_b32_e32 v1, s50, v145, vcc_lo                    // 0000001D6D2C: 02032232
	.long 0x7e043981                                           // 0000001D6D30: 7E043981
	s_and_saveexec_b32 s10, s8                                 // 0000001D6D34: BE8A2008
	s_cbranch_execz 17                                         // 0000001D6D38: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3680>
	v_mad_u64_u32 v[2:3], null, v145, 48, s[2:3]               // 0000001D6D3C: D6FE7C02 00096191
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6D44: BF870091
	.long 0xd73c0002                                           // 0000001D6D48: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D6D4C: 02020489
	.long 0xd7000902                                           // 0000001D6D50: D7000902
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D6D54: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6D58: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s9                 // 0000001D6D5C: D5207C03 00260789
	global_load_b32 v2, v[2:3], off                            // 0000001D6D64: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D6D6C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v44                         // 0000001D6D70: 560458FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D6D78: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001D6D80: 8C7E0A7E
	v_add_nc_u32_e32 v146, 8, v142                             // 0000001D6D84: 4B251C88
	ds_store_b16 v138, v2 offset:12                            // 0000001D6D88: D87C000C 0000028A
	.long 0xd4440009                                           // 0000001D6D90: D4440009
	v_cndmask_b32_e32 v1, s50, v146, vcc_lo                    // 0000001D6D94: 02032432
	s_and_saveexec_b32 s11, s9                                 // 0000001D6D98: BE8B2009
	s_cbranch_execz 17                                         // 0000001D6D9C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x36e4>
	v_mad_u64_u32 v[1:2], null, v146, 48, s[2:3]               // 0000001D6DA0: D6FE7C01 00096192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6DA8: BF870091
	.long 0xd73c0001                                           // 0000001D6DAC: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6DB0: 02020289
	.long 0xd7000a01                                           // 0000001D6DB4: D7000A01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D6DB8: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6DBC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s10                // 0000001D6DC0: D5207C02 002A0589
	global_load_b32 v1, v[1:2], off                            // 0000001D6DC8: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D6DD0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v45                         // 0000001D6DD4: 56025AFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D6DDC: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D6DE4: 8C7E0B7E
	v_add_nc_u32_e32 v147, 10, v142                            // 0000001D6DE8: 4B271C8A
	.long 0x7e043880                                           // 0000001D6DEC: 7E043880
	ds_store_b16_d16_hi v138, v1 offset:16                     // 0000001D6DF0: DA840010 0000018A
	.long 0xd444000a                                           // 0000001D6DF8: D444000A
	v_cndmask_b32_e32 v1, s50, v147, vcc_lo                    // 0000001D6DFC: 02032632
	.long 0x7e023902                                           // 0000001D6E00: 7E023902
	s_and_saveexec_b32 s12, s10                                // 0000001D6E04: BE8C200A
	s_cbranch_execz 17                                         // 0000001D6E08: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3750>
	v_mad_u64_u32 v[3:4], null, v147, 48, s[2:3]               // 0000001D6E0C: D6FE7C03 00096193
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6E14: BF870091
	.long 0xd73c0003                                           // 0000001D6E18: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001D6E1C: 02020689
	.long 0xd7000b03                                           // 0000001D6E20: D7000B03
	v_cndmask_b32_e32 v1, v136, v3, vcc_lo                     // 0000001D6E24: 02020788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6E28: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v137, v4, s11                // 0000001D6E2C: D5207C04 002E0989
	global_load_b32 v1, v[3:4], off                            // 0000001D6E34: DC520000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000001D6E3C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v46                         // 0000001D6E40: 56025CFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D6E48: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001D6E50: 8C7E0C7E
	v_add_nc_u32_e32 v148, 12, v142                            // 0000001D6E54: 4B291C8C
	ds_store_b16 v138, v1 offset:20                            // 0000001D6E58: D87C0014 0000018A
	.long 0xd444000b                                           // 0000001D6E60: D444000B
	v_cndmask_b32_e32 v1, s50, v148, vcc_lo                    // 0000001D6E64: 02032832
	s_and_saveexec_b32 s14, s11                                // 0000001D6E68: BE8E200B
	s_cbranch_execz 17                                         // 0000001D6E6C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x37b4>
	v_mad_u64_u32 v[1:2], null, v148, 48, s[2:3]               // 0000001D6E70: D6FE7C01 00096194
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6E78: BF870091
	.long 0xd73c0001                                           // 0000001D6E7C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6E80: 02020289
	.long 0xd7000c01                                           // 0000001D6E84: D7000C01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D6E88: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6E8C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s12                // 0000001D6E90: D5207C02 00320589
	global_load_b32 v1, v[1:2], off                            // 0000001D6E98: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D6EA0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v47                         // 0000001D6EA4: 56025EFF BB800000
	v_fma_mixlo_f16 v2, v1, s39, 0                             // 0000001D6EAC: CC210002 02004F01
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D6EB4: 8C7E0E7E
	v_add_nc_u32_e32 v149, 14, v142                            // 0000001D6EB8: 4B2B1C8E
	.long 0x7e023880                                           // 0000001D6EBC: 7E023880
	ds_store_b16 v138, v2 offset:24                            // 0000001D6EC0: D87C0018 0000028A
	.long 0xd444000c                                           // 0000001D6EC8: D444000C
	v_cndmask_b32_e32 v1, s50, v149, vcc_lo                    // 0000001D6ECC: 02032A32
	.long 0x7f023901                                           // 0000001D6ED0: 7F023901
	s_and_saveexec_b32 s42, s12                                // 0000001D6ED4: BEAA200C
	s_cbranch_execz 17                                         // 0000001D6ED8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3820>
	v_mad_u64_u32 v[2:3], null, v149, 48, s[2:3]               // 0000001D6EDC: D6FE7C02 00096195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6EE4: BF870091
	.long 0xd73c0002                                           // 0000001D6EE8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D6EEC: 02020489
	.long 0xd7000e02                                           // 0000001D6EF0: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D6EF4: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6EF8: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D6EFC: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off                            // 0000001D6F04: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D6F0C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v48                         // 0000001D6F10: 560460FF BB800000
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001D6F18: CC220001 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D6F20: 8C7E2A7E
	ds_store_b16_d16_hi v138, v1 offset:28                     // 0000001D6F24: DA84001C 0000018A
	s_and_saveexec_b32 s42, s0                                 // 0000001D6F2C: BEAA2000
	s_cbranch_execz 17                                         // 0000001D6F30: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3878>
	v_mad_u64_u32 v[1:2], null, v142, 48, s[2:3]               // 0000001D6F34: D6FE7C01 0009618E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6F3C: BF870091
	.long 0xd73c0001                                           // 0000001D6F40: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6F44: 02020289
	.long 0xd7000e01                                           // 0000001D6F48: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D6F4C: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6F50: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D6F54: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001D6F5C: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D6F64: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v33                         // 0000001D6F68: 560242FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D6F70: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D6F78: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D6F7C: 7F023880
	ds_store_b16 v138, v1 offset:2304                          // 0000001D6F80: D87C0900 0000018A
	.long 0x7e043981                                           // 0000001D6F88: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001D6F8C: BEAA2001
	s_cbranch_execz 17                                         // 0000001D6F90: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x38d8>
	v_mad_u64_u32 v[2:3], null, v143, 48, s[2:3]               // 0000001D6F94: D6FE7C02 0009618F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6F9C: BF870091
	.long 0xd73c0002                                           // 0000001D6FA0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D6FA4: 02020489
	.long 0xd7000e02                                           // 0000001D6FA8: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D6FAC: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D6FB0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D6FB4: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001D6FBC: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D6FC4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v34                         // 0000001D6FC8: 560444FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D6FD0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D6FD8: 8C7E2A7E
	ds_store_b16 v138, v2 offset:2308                          // 0000001D6FDC: D87C0904 0000028A
	s_and_saveexec_b32 s42, s7                                 // 0000001D6FE4: BEAA2007
	s_cbranch_execz 17                                         // 0000001D6FE8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3930>
	v_mad_u64_u32 v[1:2], null, v144, 48, s[2:3]               // 0000001D6FEC: D6FE7C01 00096190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FF4: BF870091
	.long 0xd73c0001                                           // 0000001D6FF8: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D6FFC: 02020289
	.long 0xd7000e01                                           // 0000001D7000: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D7004: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7008: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D700C: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001D7014: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D701C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v35                         // 0000001D7020: 560246FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D7028: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7030: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D7034: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:2312                   // 0000001D7038: DA840908 0000018A
	.long 0x7e043901                                           // 0000001D7040: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001D7044: BEAA2008
	s_cbranch_execz 17                                         // 0000001D7048: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3990>
	v_mad_u64_u32 v[2:3], null, v145, 48, s[2:3]               // 0000001D704C: D6FE7C02 00096191
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7054: BF870091
	.long 0xd73c0002                                           // 0000001D7058: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D705C: 02020489
	.long 0xd7000e02                                           // 0000001D7060: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D7064: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7068: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D706C: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001D7074: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D707C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v36                         // 0000001D7080: 560448FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7088: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7090: 8C7E2A7E
	ds_store_b16 v138, v2 offset:2316                          // 0000001D7094: D87C090C 0000028A
	s_and_saveexec_b32 s42, s9                                 // 0000001D709C: BEAA2009
	s_cbranch_execz 17                                         // 0000001D70A0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x39e8>
	v_mad_u64_u32 v[1:2], null, v146, 48, s[2:3]               // 0000001D70A4: D6FE7C01 00096192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D70AC: BF870091
	.long 0xd73c0001                                           // 0000001D70B0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D70B4: 02020289
	.long 0xd7000e01                                           // 0000001D70B8: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D70BC: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D70C0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D70C4: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001D70CC: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D70D4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v37                         // 0000001D70D8: 56024AFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D70E0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D70E8: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D70EC: 7F023880
	ds_store_b16 v138, v1 offset:2320                          // 0000001D70F0: D87C0910 0000018A
	.long 0x7e043981                                           // 0000001D70F8: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001D70FC: BEAA200A
	s_cbranch_execz 17                                         // 0000001D7100: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3a48>
	v_mad_u64_u32 v[2:3], null, v147, 48, s[2:3]               // 0000001D7104: D6FE7C02 00096193
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D710C: BF870091
	.long 0xd73c0002                                           // 0000001D7110: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D7114: 02020489
	.long 0xd7000e02                                           // 0000001D7118: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D711C: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7120: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D7124: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001D712C: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D7134: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v38                         // 0000001D7138: 56044CFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7140: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7148: 8C7E2A7E
	ds_store_b16 v138, v2 offset:2324                          // 0000001D714C: D87C0914 0000028A
	s_and_saveexec_b32 s42, s11                                // 0000001D7154: BEAA200B
	s_cbranch_execz 17                                         // 0000001D7158: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3aa0>
	v_mad_u64_u32 v[1:2], null, v148, 48, s[2:3]               // 0000001D715C: D6FE7C01 00096194
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7164: BF870091
	.long 0xd73c0001                                           // 0000001D7168: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D716C: 02020289
	.long 0xd7000e01                                           // 0000001D7170: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D7174: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7178: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D717C: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001D7184: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D718C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v39                         // 0000001D7190: 56024EFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D7198: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D71A0: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D71A4: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:2328                   // 0000001D71A8: DA840918 0000018A
	.long 0x7e043901                                           // 0000001D71B0: 7E043901
	s_and_saveexec_b32 s42, s12                                // 0000001D71B4: BEAA200C
	s_cbranch_execz 17                                         // 0000001D71B8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b00>
	v_mad_u64_u32 v[2:3], null, v149, 48, s[2:3]               // 0000001D71BC: D6FE7C02 00096195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D71C4: BF870091
	.long 0xd73c0002                                           // 0000001D71C8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D71CC: 02020489
	.long 0xd7000e02                                           // 0000001D71D0: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D71D4: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D71D8: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D71DC: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001D71E4: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D71EC: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v40                         // 0000001D71F0: 560450FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D71F8: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7200: 8C7E2A7E
	ds_store_b16 v138, v2 offset:2332                          // 0000001D7204: D87C091C 0000028A
	s_and_saveexec_b32 s42, s0                                 // 0000001D720C: BEAA2000
	s_cbranch_execz 17                                         // 0000001D7210: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b58>
	v_mad_u64_u32 v[1:2], null, v142, 48, s[2:3]               // 0000001D7214: D6FE7C01 0009618E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D721C: BF870091
	.long 0xd73c0001                                           // 0000001D7220: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D7224: 02020289
	.long 0xd7000e01                                           // 0000001D7228: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D722C: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7230: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D7234: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001D723C: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D7244: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v25                         // 0000001D7248: 560232FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D7250: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7258: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D725C: 7F023880
	ds_store_b16 v138, v1 offset:4608                          // 0000001D7260: D87C1200 0000018A
	.long 0x7e043981                                           // 0000001D7268: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001D726C: BEAA2001
	s_cbranch_execz 17                                         // 0000001D7270: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3bb8>
	v_mad_u64_u32 v[2:3], null, v143, 48, s[2:3]               // 0000001D7274: D6FE7C02 0009618F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D727C: BF870091
	.long 0xd73c0002                                           // 0000001D7280: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D7284: 02020489
	.long 0xd7000e02                                           // 0000001D7288: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D728C: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7290: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D7294: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001D729C: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D72A4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v26                         // 0000001D72A8: 560434FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D72B0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D72B8: 8C7E2A7E
	ds_store_b16 v138, v2 offset:4612                          // 0000001D72BC: D87C1204 0000028A
	s_and_saveexec_b32 s42, s7                                 // 0000001D72C4: BEAA2007
	s_cbranch_execz 17                                         // 0000001D72C8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3c10>
	v_mad_u64_u32 v[1:2], null, v144, 48, s[2:3]               // 0000001D72CC: D6FE7C01 00096190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D72D4: BF870091
	.long 0xd73c0001                                           // 0000001D72D8: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D72DC: 02020289
	.long 0xd7000e01                                           // 0000001D72E0: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D72E4: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D72E8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D72EC: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001D72F4: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D72FC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v27                         // 0000001D7300: 560236FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D7308: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7310: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D7314: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:4616                   // 0000001D7318: DA841208 0000018A
	.long 0x7e043901                                           // 0000001D7320: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001D7324: BEAA2008
	s_cbranch_execz 17                                         // 0000001D7328: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3c70>
	v_mad_u64_u32 v[2:3], null, v145, 48, s[2:3]               // 0000001D732C: D6FE7C02 00096191
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7334: BF870091
	.long 0xd73c0002                                           // 0000001D7338: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D733C: 02020489
	.long 0xd7000e02                                           // 0000001D7340: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D7344: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7348: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D734C: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001D7354: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D735C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v28                         // 0000001D7360: 560438FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7368: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7370: 8C7E2A7E
	ds_store_b16 v138, v2 offset:4620                          // 0000001D7374: D87C120C 0000028A
	s_and_saveexec_b32 s42, s9                                 // 0000001D737C: BEAA2009
	s_cbranch_execz 17                                         // 0000001D7380: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3cc8>
	v_mad_u64_u32 v[1:2], null, v146, 48, s[2:3]               // 0000001D7384: D6FE7C01 00096192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D738C: BF870091
	.long 0xd73c0001                                           // 0000001D7390: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D7394: 02020289
	.long 0xd7000e01                                           // 0000001D7398: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D739C: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D73A0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D73A4: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001D73AC: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D73B4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v29                         // 0000001D73B8: 56023AFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D73C0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D73C8: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D73CC: 7F023880
	ds_store_b16 v138, v1 offset:4624                          // 0000001D73D0: D87C1210 0000018A
	.long 0x7e043981                                           // 0000001D73D8: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001D73DC: BEAA200A
	s_cbranch_execz 17                                         // 0000001D73E0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3d28>
	v_mad_u64_u32 v[2:3], null, v147, 48, s[2:3]               // 0000001D73E4: D6FE7C02 00096193
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D73EC: BF870091
	.long 0xd73c0002                                           // 0000001D73F0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D73F4: 02020489
	.long 0xd7000e02                                           // 0000001D73F8: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D73FC: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7400: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D7404: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001D740C: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D7414: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v30                         // 0000001D7418: 56043CFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7420: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7428: 8C7E2A7E
	ds_store_b16 v138, v2 offset:4628                          // 0000001D742C: D87C1214 0000028A
	s_and_saveexec_b32 s42, s11                                // 0000001D7434: BEAA200B
	s_cbranch_execz 17                                         // 0000001D7438: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3d80>
	v_mad_u64_u32 v[1:2], null, v148, 48, s[2:3]               // 0000001D743C: D6FE7C01 00096194
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7444: BF870091
	.long 0xd73c0001                                           // 0000001D7448: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D744C: 02020289
	.long 0xd7000e01                                           // 0000001D7450: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D7454: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7458: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D745C: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001D7464: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D746C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v31                         // 0000001D7470: 56023EFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D7478: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7480: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D7484: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:4632                   // 0000001D7488: DA841218 0000018A
	.long 0x7e043901                                           // 0000001D7490: 7E043901
	s_and_saveexec_b32 s42, s12                                // 0000001D7494: BEAA200C
	s_cbranch_execz 17                                         // 0000001D7498: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3de0>
	v_mad_u64_u32 v[2:3], null, v149, 48, s[2:3]               // 0000001D749C: D6FE7C02 00096195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D74A4: BF870091
	.long 0xd73c0002                                           // 0000001D74A8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D74AC: 02020489
	.long 0xd7000e02                                           // 0000001D74B0: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D74B4: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D74B8: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D74BC: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001D74C4: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D74CC: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v32                         // 0000001D74D0: 560440FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D74D8: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D74E0: 8C7E2A7E
	ds_store_b16 v138, v2 offset:4636                          // 0000001D74E4: D87C121C 0000028A
	s_and_saveexec_b32 s42, s0                                 // 0000001D74EC: BEAA2000
	s_cbranch_execz 17                                         // 0000001D74F0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e38>
	v_mad_u64_u32 v[1:2], null, v142, 48, s[2:3]               // 0000001D74F4: D6FE7C01 0009618E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D74FC: BF870091
	.long 0xd73c0001                                           // 0000001D7500: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D7504: 02020289
	.long 0xd7000e01                                           // 0000001D7508: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D750C: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7510: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D7514: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001D751C: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D7524: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v9                          // 0000001D7528: 560212FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D7530: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7538: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D753C: 7F023880
	ds_store_b16 v138, v1 offset:6912                          // 0000001D7540: D87C1B00 0000018A
	.long 0x7e043981                                           // 0000001D7548: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001D754C: BEAA2001
	s_cbranch_execz 17                                         // 0000001D7550: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e98>
	v_mad_u64_u32 v[2:3], null, v143, 48, s[2:3]               // 0000001D7554: D6FE7C02 0009618F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D755C: BF870091
	.long 0xd73c0002                                           // 0000001D7560: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D7564: 02020489
	.long 0xd7000e02                                           // 0000001D7568: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D756C: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7570: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D7574: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001D757C: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D7584: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v10                         // 0000001D7588: 560414FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7590: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7598: 8C7E2A7E
	ds_store_b16 v138, v2 offset:6916                          // 0000001D759C: D87C1B04 0000028A
	s_and_saveexec_b32 s42, s7                                 // 0000001D75A4: BEAA2007
	s_cbranch_execz 17                                         // 0000001D75A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ef0>
	v_mad_u64_u32 v[1:2], null, v144, 48, s[2:3]               // 0000001D75AC: D6FE7C01 00096190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D75B4: BF870091
	.long 0xd73c0001                                           // 0000001D75B8: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D75BC: 02020289
	.long 0xd7000e01                                           // 0000001D75C0: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D75C4: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D75C8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D75CC: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001D75D4: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D75DC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v11                         // 0000001D75E0: 560216FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D75E8: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D75F0: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D75F4: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:6920                   // 0000001D75F8: DA841B08 0000018A
	.long 0x7e043901                                           // 0000001D7600: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001D7604: BEAA2008
	s_cbranch_execz 17                                         // 0000001D7608: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f50>
	v_mad_u64_u32 v[2:3], null, v145, 48, s[2:3]               // 0000001D760C: D6FE7C02 00096191
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7614: BF870091
	.long 0xd73c0002                                           // 0000001D7618: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D761C: 02020489
	.long 0xd7000e02                                           // 0000001D7620: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D7624: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7628: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D762C: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001D7634: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D763C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v12                         // 0000001D7640: 560418FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7648: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7650: 8C7E2A7E
	ds_store_b16 v138, v2 offset:6924                          // 0000001D7654: D87C1B0C 0000028A
	s_and_saveexec_b32 s42, s9                                 // 0000001D765C: BEAA2009
	s_cbranch_execz 17                                         // 0000001D7660: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fa8>
	v_mad_u64_u32 v[1:2], null, v146, 48, s[2:3]               // 0000001D7664: D6FE7C01 00096192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D766C: BF870091
	.long 0xd73c0001                                           // 0000001D7670: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D7674: 02020289
	.long 0xd7000e01                                           // 0000001D7678: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D767C: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7680: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D7684: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001D768C: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D7694: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v13                         // 0000001D7698: 56021AFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D76A0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D76A8: 8C7E2A7E
	.long 0x7f023880                                           // 0000001D76AC: 7F023880
	ds_store_b16 v138, v1 offset:6928                          // 0000001D76B0: D87C1B10 0000018A
	.long 0x7e043981                                           // 0000001D76B8: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001D76BC: BEAA200A
	s_cbranch_execz 17                                         // 0000001D76C0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4008>
	v_mad_u64_u32 v[2:3], null, v147, 48, s[2:3]               // 0000001D76C4: D6FE7C02 00096193
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D76CC: BF870091
	.long 0xd73c0002                                           // 0000001D76D0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001D76D4: 02020489
	.long 0xd7000e02                                           // 0000001D76D8: D7000E02
	v_cndmask_b32_e32 v1, v136, v2, vcc_lo                     // 0000001D76DC: 02020588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D76E0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v137, v3, s14                // 0000001D76E4: D5207C03 003A0789
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001D76EC: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001D76F4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v14                         // 0000001D76F8: 56041CFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001D7700: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7708: 8C7E2A7E
	ds_store_b16 v138, v2 offset:6932                          // 0000001D770C: D87C1B14 0000028A
	s_and_saveexec_b32 s42, s11                                // 0000001D7714: BEAA200B
	s_cbranch_execz 17                                         // 0000001D7718: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4060>
	v_mad_u64_u32 v[1:2], null, v148, 48, s[2:3]               // 0000001D771C: D6FE7C01 00096194
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7724: BF870091
	.long 0xd73c0001                                           // 0000001D7728: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D772C: 02020289
	.long 0xd7000e01                                           // 0000001D7730: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D7734: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7738: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D773C: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001D7744: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D774C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v15                         // 0000001D7750: 56021EFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001D7758: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D7760: 8C7E2A7E
	.long 0x7e023880                                           // 0000001D7764: 7E023880
	ds_store_b16_d16_hi v138, v1 offset:6936                   // 0000001D7768: DA841B18 0000018A
	s_and_saveexec_b32 s42, s12                                // 0000001D7770: BEAA200C
	s_cbranch_execz 17                                         // 0000001D7774: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x40bc>
	v_mad_u64_u32 v[1:2], null, v149, 48, s[2:3]               // 0000001D7778: D6FE7C01 00096195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D7780: BF870091
	.long 0xd73c0001                                           // 0000001D7784: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001D7788: 02020289
	.long 0xd7000e01                                           // 0000001D778C: D7000E01
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001D7790: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001D7794: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v137, v2, s14                // 0000001D7798: D5207C02 003A0589
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001D77A0: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001D77A8: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v16                         // 0000001D77AC: 560220FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D77B4: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001D77BC: 8C7E2A7E
	.long 0xd7000e02                                           // 0000001D77C0: D7000E02
	v_cndmask_b32_e32 v1, s44, v98, vcc_lo                     // 0000001D77C4: 0202C42C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D77C8: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, v99, s14                // 0000001D77CC: D5207C03 003AC62D
	ds_store_b16 v138, v1 offset:6940                          // 0000001D77D4: D87C1B1C 0000018A
	s_waitcnt lgkmcnt(0)                                       // 0000001D77DC: BF89FC07
	s_barrier                                                  // 0000001D77E0: BFBD0000
	buffer_gl0_inv                                             // 0000001D77E4: E0AC0000 00000000
	s_clause 0xf                                               // 0000001D77EC: BF85000F
	global_load_b128 v[97:100], v[2:3], off                    // 0000001D77F0: DC5E0000 617C0002
	global_load_b128 v[101:104], v[2:3], off offset:16         // 0000001D77F8: DC5E0010 657C0002
	global_load_b128 v[89:92], v[2:3], off offset:32           // 0000001D7800: DC5E0020 597C0002
	global_load_b128 v[93:96], v[2:3], off offset:48           // 0000001D7808: DC5E0030 5D7C0002
	global_load_b128 v[81:84], v[2:3], off offset:64           // 0000001D7810: DC5E0040 517C0002
	global_load_b128 v[85:88], v[2:3], off offset:80           // 0000001D7818: DC5E0050 557C0002
	global_load_b128 v[73:76], v[2:3], off offset:96           // 0000001D7820: DC5E0060 497C0002
	global_load_b128 v[77:80], v[2:3], off offset:112          // 0000001D7828: DC5E0070 4D7C0002
	global_load_b128 v[57:60], v[2:3], off offset:128          // 0000001D7830: DC5E0080 397C0002
	global_load_b128 v[61:64], v[2:3], off offset:144          // 0000001D7838: DC5E0090 3D7C0002
	global_load_b128 v[49:52], v[2:3], off offset:160          // 0000001D7840: DC5E00A0 317C0002
	global_load_b128 v[53:56], v[2:3], off offset:176          // 0000001D7848: DC5E00B0 357C0002
	global_load_b128 v[41:44], v[2:3], off offset:192          // 0000001D7850: DC5E00C0 297C0002
	global_load_b128 v[45:48], v[2:3], off offset:208          // 0000001D7858: DC5E00D0 2D7C0002
	global_load_b128 v[33:36], v[2:3], off offset:224          // 0000001D7860: DC5E00E0 217C0002
	global_load_b128 v[37:40], v[2:3], off offset:240          // 0000001D7868: DC5E00F0 257C0002
	s_and_saveexec_b32 s14, s13                                // 0000001D7870: BE8E200D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D7874: BF870009
	s_xor_b32 s13, exec_lo, s14                                // 0000001D7878: 8D0D0E7E
	s_cbranch_execz 81                                         // 0000001D787C: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x42c4>
	s_waitcnt vmcnt(15)                                        // 0000001D7880: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001D7884: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D7888: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001D788C: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001D7890: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001D7894: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001D7898: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001D789C: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001D78A0: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001D78A4: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001D78A8: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001D78AC: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001D78B0: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001D78B4: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001D78B8: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001D78BC: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001D78C0: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001D78C4: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001D78C8: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001D78CC: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001D78D0: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001D78D4: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001D78D8: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001D78DC: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001D78E0: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001D78E4: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001D78E8: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001D78EC: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001D78F0: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001D78F4: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001D78F8: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001D78FC: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001D7900: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001D7904: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001D7908: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001D790C: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001D7910: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001D7914: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001D7918: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001D791C: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001D7920: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001D7924: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001D7928: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001D792C: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001D7930: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001D7934: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001D7938: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001D793C: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001D7940: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001D7944: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001D7948: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001D794C: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001D7950: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001D7954: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001D7958: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001D795C: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001D7960: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001D7964: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001D7968: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001D796C: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001D7970: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001D7974: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001D7978: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001D797C: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001D7980: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001D7984: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001D7988: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001D798C: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001D7990: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001D7994: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001D7998: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001D799C: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001D79A0: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001D79A4: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001D79A8: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001D79AC: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001D79B0: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001D79B4: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001D79B8: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001D79BC: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001D79C0: 7E500361
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D79C4: 8C7E0D7E
	ds_load_b128 v[1:4], v129                                  // 0000001D79C8: DBFC0000 01000081
	ds_load_b128 v[5:8], v129 offset:16                        // 0000001D79D0: DBFC0010 05000081
	ds_load_b128 v[9:12], v129 offset:32                       // 0000001D79D8: DBFC0020 09000081
	ds_load_b128 v[13:16], v129 offset:48                      // 0000001D79E0: DBFC0030 0D000081
	ds_load_b128 v[17:20], v129 offset:8448                    // 0000001D79E8: DBFC2100 11000081
	ds_load_b128 v[21:24], v129 offset:8464                    // 0000001D79F0: DBFC2110 15000081
	ds_load_b128 v[25:28], v129 offset:8480                    // 0000001D79F8: DBFC2120 19000081
	ds_load_b128 v[29:32], v129 offset:8496                    // 0000001D7A00: DBFC2130 1D000081
	ds_load_b128 v[150:153], v129 offset:16896                 // 0000001D7A08: DBFC4200 96000081
	ds_load_b128 v[154:157], v129 offset:16912                 // 0000001D7A10: DBFC4210 9A000081
	ds_load_b128 v[158:161], v129 offset:16928                 // 0000001D7A18: DBFC4220 9E000081
	ds_load_b128 v[162:165], v129 offset:16944                 // 0000001D7A20: DBFC4230 A2000081
	ds_load_b128 v[166:169], v129 offset:25376                 // 0000001D7A28: DBFC6320 A6000081
	v_dual_mov_b32 v72, s27 :: v_dual_mov_b32 v71, s26         // 0000001D7A30: CA10001B 4846001A
	v_dual_mov_b32 v70, s25 :: v_dual_mov_b32 v69, s24         // 0000001D7A38: CA100019 46440018
	v_dual_mov_b32 v68, s23 :: v_dual_mov_b32 v67, s22         // 0000001D7A40: CA100017 44420016
	v_dual_mov_b32 v66, s21 :: v_dual_mov_b32 v65, s20         // 0000001D7A48: CA100015 42400014
	s_waitcnt lgkmcnt(12)                                      // 0000001D7A50: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001D7A54: CC210001 02004F01
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001D7A5C: CC220001 02004F02
	v_fma_mixlo_f16 v2, v3, s39, 0                             // 0000001D7A64: CC210002 02004F03
	v_fma_mixhi_f16 v2, v4, s39, 0                             // 0000001D7A6C: CC220002 02004F04
	s_waitcnt lgkmcnt(11)                                      // 0000001D7A74: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s39, 0                             // 0000001D7A78: CC210003 02004F05
	v_fma_mixhi_f16 v3, v6, s39, 0                             // 0000001D7A80: CC220003 02004F06
	v_fma_mixlo_f16 v4, v7, s39, 0                             // 0000001D7A88: CC210004 02004F07
	v_fma_mixhi_f16 v4, v8, s39, 0                             // 0000001D7A90: CC220004 02004F08
	s_waitcnt lgkmcnt(10)                                      // 0000001D7A98: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s39, 0                             // 0000001D7A9C: CC210005 02004F09
	v_fma_mixhi_f16 v5, v10, s39, 0                            // 0000001D7AA4: CC220005 02004F0A
	v_fma_mixlo_f16 v6, v11, s39, 0                            // 0000001D7AAC: CC210006 02004F0B
	v_fma_mixhi_f16 v6, v12, s39, 0                            // 0000001D7AB4: CC220006 02004F0C
	s_waitcnt lgkmcnt(9)                                       // 0000001D7ABC: BF89FC97
	v_fma_mixlo_f16 v7, v13, s39, 0                            // 0000001D7AC0: CC210007 02004F0D
	v_fma_mixhi_f16 v7, v14, s39, 0                            // 0000001D7AC8: CC220007 02004F0E
	v_fma_mixlo_f16 v8, v15, s39, 0                            // 0000001D7AD0: CC210008 02004F0F
	v_fma_mixhi_f16 v8, v16, s39, 0                            // 0000001D7AD8: CC220008 02004F10
	s_waitcnt lgkmcnt(8)                                       // 0000001D7AE0: BF89FC87
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001D7AE4: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001D7AEC: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001D7AF4: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001D7AFC: CC220012 02004F14
	s_waitcnt lgkmcnt(7)                                       // 0000001D7B04: BF89FC77
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001D7B08: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001D7B10: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001D7B18: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001D7B20: CC220014 02004F18
	s_waitcnt lgkmcnt(6)                                       // 0000001D7B28: BF89FC67
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001D7B2C: CC210015 02004F19
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001D7B34: CC220015 02004F1A
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001D7B3C: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001D7B44: CC220016 02004F1C
	s_waitcnt lgkmcnt(5)                                       // 0000001D7B4C: BF89FC57
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001D7B50: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001D7B58: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001D7B60: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001D7B68: CC220018 02004F20
	s_waitcnt vmcnt(14)                                        // 0000001D7B70: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001D7B74: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001D7B7C: BF89FC37
	v_fma_mixlo_f16 v4, v156, s39, 0                           // 0000001D7B80: CC210004 02004F9C
	v_fma_mixhi_f16 v4, v157, s39, 0                           // 0000001D7B88: CC220004 02004F9D
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001D7B90: CC404009 1D062361
	ds_load_b128 v[17:20], v129 offset:25344                   // 0000001D7B98: DBFC6300 11000081
	ds_load_b128 v[21:24], v129 offset:25360                   // 0000001D7BA0: DBFC6310 15000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D7BA8: BF89FC47
	v_fma_mixlo_f16 v5, v158, s39, 0                           // 0000001D7BAC: CC210005 02004F9E
	v_fma_mixhi_f16 v5, v159, s39, 0                           // 0000001D7BB4: CC220005 02004F9F
	ds_load_b128 v[156:159], v129 offset:25392                 // 0000001D7BBC: DBFC6330 9C000081
	v_fma_mixlo_f16 v3, v154, s39, 0                           // 0000001D7BC4: CC210003 02004F9A
	v_fma_mixlo_f16 v6, v160, s39, 0                           // 0000001D7BCC: CC210006 02004FA0
	v_fma_mixhi_f16 v6, v161, s39, 0                           // 0000001D7BD4: CC220006 02004FA1
	s_waitcnt lgkmcnt(4)                                       // 0000001D7BDC: BF89FC47
	v_fma_mixlo_f16 v7, v162, s39, 0                           // 0000001D7BE0: CC210007 02004FA2
	v_fma_mixhi_f16 v7, v163, s39, 0                           // 0000001D7BE8: CC220007 02004FA3
	v_fma_mixlo_f16 v8, v164, s39, 0                           // 0000001D7BF0: CC210008 02004FA4
	v_fma_mixhi_f16 v8, v165, s39, 0                           // 0000001D7BF8: CC220008 02004FA5
	ds_load_b128 v[160:163], v129 offset:64                    // 0000001D7C00: DBFC0040 A0000081
	ds_load_b128 v[170:173], v129 offset:80                    // 0000001D7C08: DBFC0050 AA000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D7C10: BF89FC57
	v_fma_mixlo_f16 v154, v166, s39, 0                         // 0000001D7C14: CC21009A 02004FA6
	v_fma_mixhi_f16 v154, v167, s39, 0                         // 0000001D7C1C: CC22009A 02004FA7
	ds_load_b128 v[164:167], v129 offset:96                    // 0000001D7C24: DBFC0060 A4000081
	ds_load_b128 v[174:177], v129 offset:112                   // 0000001D7C2C: DBFC0070 AE000081
	v_fma_mixlo_f16 v1, v150, s39, 0                           // 0000001D7C34: CC210001 02004F96
	v_fma_mixhi_f16 v1, v151, s39, 0                           // 0000001D7C3C: CC220001 02004F97
	v_fma_mixlo_f16 v2, v152, s39, 0                           // 0000001D7C44: CC210002 02004F98
	v_fma_mixhi_f16 v2, v153, s39, 0                           // 0000001D7C4C: CC220002 02004F99
	v_fma_mixhi_f16 v3, v155, s39, 0                           // 0000001D7C54: CC220003 02004F9B
	s_waitcnt lgkmcnt(6)                                       // 0000001D7C5C: BF89FC67
	v_fma_mixlo_f16 v150, v17, s39, 0                          // 0000001D7C60: CC210096 02004F11
	v_fma_mixhi_f16 v150, v18, s39, 0                          // 0000001D7C68: CC220096 02004F12
	v_fma_mixlo_f16 v151, v19, s39, 0                          // 0000001D7C70: CC210097 02004F13
	v_fma_mixhi_f16 v151, v20, s39, 0                          // 0000001D7C78: CC220097 02004F14
	s_waitcnt lgkmcnt(5)                                       // 0000001D7C80: BF89FC57
	v_fma_mixlo_f16 v152, v21, s39, 0                          // 0000001D7C84: CC210098 02004F15
	v_fma_mixhi_f16 v152, v22, s39, 0                          // 0000001D7C8C: CC220098 02004F16
	v_fma_mixlo_f16 v153, v23, s39, 0                          // 0000001D7C94: CC210099 02004F17
	v_fma_mixhi_f16 v153, v24, s39, 0                          // 0000001D7C9C: CC220099 02004F18
	v_fma_mixlo_f16 v155, v168, s39, 0                         // 0000001D7CA4: CC21009B 02004FA8
	v_fma_mixhi_f16 v155, v169, s39, 0                         // 0000001D7CAC: CC22009B 02004FA9
	s_waitcnt lgkmcnt(4)                                       // 0000001D7CB4: BF89FC47
	v_fma_mixlo_f16 v156, v156, s39, 0                         // 0000001D7CB8: CC21009C 02004F9C
	v_fma_mixhi_f16 v156, v157, s39, 0                         // 0000001D7CC0: CC22009C 02004F9D
	v_fma_mixlo_f16 v157, v158, s39, 0                         // 0000001D7CC8: CC21009D 02004F9E
	v_fma_mixhi_f16 v157, v159, s39, 0                         // 0000001D7CD0: CC22009D 02004F9F
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001D7CD8: CC404011 1D060361
	ds_load_b128 v[178:181], v129 offset:17008                 // 0000001D7CE0: DBFC4270 B2000081
	ds_load_b128 v[182:185], v129 offset:25408                 // 0000001D7CE8: DBFC6340 B6000081
	ds_load_b128 v[186:189], v129 offset:25424                 // 0000001D7CF0: DBFC6350 BA000081
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[150:157], v[65:72]// 0000001D7CF8: CC404001 1D072D61
	ds_load_b128 v[150:153], v129 offset:8512                  // 0000001D7D00: DBFC2140 96000081
	ds_load_b128 v[154:157], v129 offset:8528                  // 0000001D7D08: DBFC2150 9A000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D7D10: BF89FC87
	v_fma_mixlo_f16 v97, v160, s39, 0                          // 0000001D7D14: CC210061 02004FA0
	v_fma_mixhi_f16 v97, v161, s39, 0                          // 0000001D7D1C: CC220061 02004FA1
	v_fma_mixlo_f16 v98, v162, s39, 0                          // 0000001D7D24: CC210062 02004FA2
	v_fma_mixhi_f16 v98, v163, s39, 0                          // 0000001D7D2C: CC220062 02004FA3
	s_waitcnt lgkmcnt(7)                                       // 0000001D7D34: BF89FC77
	v_fma_mixlo_f16 v99, v170, s39, 0                          // 0000001D7D38: CC210063 02004FAA
	v_fma_mixhi_f16 v99, v171, s39, 0                          // 0000001D7D40: CC220063 02004FAB
	v_fma_mixlo_f16 v100, v172, s39, 0                         // 0000001D7D48: CC210064 02004FAC
	v_fma_mixhi_f16 v100, v173, s39, 0                         // 0000001D7D50: CC220064 02004FAD
	ds_load_b128 v[158:161], v129 offset:8544                  // 0000001D7D58: DBFC2160 9E000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D7D60: BF89FC77
	v_fma_mixlo_f16 v101, v164, s39, 0                         // 0000001D7D64: CC210065 02004FA4
	v_fma_mixhi_f16 v101, v165, s39, 0                         // 0000001D7D6C: CC220065 02004FA5
	v_fma_mixlo_f16 v102, v166, s39, 0                         // 0000001D7D74: CC210066 02004FA6
	v_fma_mixhi_f16 v102, v167, s39, 0                         // 0000001D7D7C: CC220066 02004FA7
	ds_load_b128 v[162:165], v129 offset:8560                  // 0000001D7D84: DBFC2170 A2000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D7D8C: BF89FC77
	v_fma_mixlo_f16 v103, v174, s39, 0                         // 0000001D7D90: CC210067 02004FAE
	v_fma_mixhi_f16 v103, v175, s39, 0                         // 0000001D7D98: CC220067 02004FAF
	v_fma_mixlo_f16 v104, v176, s39, 0                         // 0000001D7DA0: CC210068 02004FB0
	v_fma_mixhi_f16 v104, v177, s39, 0                         // 0000001D7DA8: CC220068 02004FB1
	ds_load_b128 v[166:169], v129 offset:16960                 // 0000001D7DB0: DBFC4240 A6000081
	ds_load_b128 v[170:173], v129 offset:16976                 // 0000001D7DB8: DBFC4250 AA000081
	ds_load_b128 v[174:177], v129 offset:16992                 // 0000001D7DC0: DBFC4260 AE000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D7DC8: BF89FC67
	v_fma_mixlo_f16 v150, v150, s39, 0                         // 0000001D7DCC: CC210096 02004F96
	v_fma_mixhi_f16 v150, v151, s39, 0                         // 0000001D7DD4: CC220096 02004F97
	v_fma_mixlo_f16 v151, v152, s39, 0                         // 0000001D7DDC: CC210097 02004F98
	v_fma_mixhi_f16 v151, v153, s39, 0                         // 0000001D7DE4: CC220097 02004F99
	s_waitcnt lgkmcnt(5)                                       // 0000001D7DEC: BF89FC57
	v_fma_mixhi_f16 v152, v155, s39, 0                         // 0000001D7DF0: CC220098 02004F9B
	v_fma_mixlo_f16 v153, v156, s39, 0                         // 0000001D7DF8: CC210099 02004F9C
	ds_load_b128 v[190:193], v129 offset:25440                 // 0000001D7E00: DBFC6360 BE000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D7E08: BF89FC57
	v_fma_mixhi_f16 v155, v161, s39, 0                         // 0000001D7E0C: CC22009B 02004FA1
	v_fma_mixlo_f16 v152, v154, s39, 0                         // 0000001D7E14: CC210098 02004F9A
	v_fma_mixhi_f16 v153, v157, s39, 0                         // 0000001D7E1C: CC220099 02004F9D
	v_fma_mixlo_f16 v154, v158, s39, 0                         // 0000001D7E24: CC21009A 02004F9E
	v_fma_mixhi_f16 v154, v159, s39, 0                         // 0000001D7E2C: CC22009A 02004F9F
	s_waitcnt lgkmcnt(4)                                       // 0000001D7E34: BF89FC47
	v_fma_mixlo_f16 v156, v162, s39, 0                         // 0000001D7E38: CC21009C 02004FA2
	v_fma_mixlo_f16 v155, v160, s39, 0                         // 0000001D7E40: CC21009B 02004FA0
	v_fma_mixhi_f16 v156, v163, s39, 0                         // 0000001D7E48: CC22009C 02004FA3
	v_fma_mixlo_f16 v157, v164, s39, 0                         // 0000001D7E50: CC21009D 02004FA4
	v_fma_mixhi_f16 v157, v165, s39, 0                         // 0000001D7E58: CC22009D 02004FA5
	s_waitcnt lgkmcnt(3)                                       // 0000001D7E60: BF89FC37
	v_fma_mixlo_f16 v158, v166, s39, 0                         // 0000001D7E64: CC21009E 02004FA6
	s_waitcnt lgkmcnt(2)                                       // 0000001D7E6C: BF89FC27
	v_fma_mixlo_f16 v161, v172, s39, 0                         // 0000001D7E70: CC2100A1 02004FAC
	v_fma_mixhi_f16 v161, v173, s39, 0                         // 0000001D7E78: CC2200A1 02004FAD
	s_waitcnt lgkmcnt(1)                                       // 0000001D7E80: BF89FC17
	v_fma_mixlo_f16 v162, v174, s39, 0                         // 0000001D7E84: CC2100A2 02004FAE
	v_fma_mixhi_f16 v162, v175, s39, 0                         // 0000001D7E8C: CC2200A2 02004FAF
	ds_load_b128 v[172:175], v129 offset:25456                 // 0000001D7E94: DBFC6370 AC000081
	v_fma_mixhi_f16 v158, v167, s39, 0                         // 0000001D7E9C: CC22009E 02004FA7
	v_fma_mixlo_f16 v159, v168, s39, 0                         // 0000001D7EA4: CC21009F 02004FA8
	v_fma_mixhi_f16 v159, v169, s39, 0                         // 0000001D7EAC: CC22009F 02004FA9
	v_fma_mixlo_f16 v160, v170, s39, 0                         // 0000001D7EB4: CC2100A0 02004FAA
	v_fma_mixhi_f16 v160, v171, s39, 0                         // 0000001D7EBC: CC2200A0 02004FAB
	v_fma_mixlo_f16 v163, v176, s39, 0                         // 0000001D7EC4: CC2100A3 02004FB0
	v_fma_mixhi_f16 v163, v177, s39, 0                         // 0000001D7ECC: CC2200A3 02004FB1
	v_fma_mixlo_f16 v164, v178, s39, 0                         // 0000001D7ED4: CC2100A4 02004FB2
	v_fma_mixhi_f16 v164, v179, s39, 0                         // 0000001D7EDC: CC2200A4 02004FB3
	v_fma_mixlo_f16 v165, v180, s39, 0                         // 0000001D7EE4: CC2100A5 02004FB4
	v_fma_mixhi_f16 v165, v181, s39, 0                         // 0000001D7EEC: CC2200A5 02004FB5
	v_fma_mixlo_f16 v166, v182, s39, 0                         // 0000001D7EF4: CC2100A6 02004FB6
	v_fma_mixhi_f16 v166, v183, s39, 0                         // 0000001D7EFC: CC2200A6 02004FB7
	v_fma_mixlo_f16 v167, v184, s39, 0                         // 0000001D7F04: CC2100A7 02004FB8
	v_fma_mixhi_f16 v167, v185, s39, 0                         // 0000001D7F0C: CC2200A7 02004FB9
	v_fma_mixlo_f16 v168, v186, s39, 0                         // 0000001D7F14: CC2100A8 02004FBA
	v_fma_mixhi_f16 v168, v187, s39, 0                         // 0000001D7F1C: CC2200A8 02004FBB
	v_fma_mixlo_f16 v169, v188, s39, 0                         // 0000001D7F24: CC2100A9 02004FBC
	v_fma_mixhi_f16 v169, v189, s39, 0                         // 0000001D7F2C: CC2200A9 02004FBD
	s_waitcnt lgkmcnt(1)                                       // 0000001D7F34: BF89FC17
	v_fma_mixlo_f16 v170, v190, s39, 0                         // 0000001D7F38: CC2100AA 02004FBE
	v_fma_mixhi_f16 v170, v191, s39, 0                         // 0000001D7F40: CC2200AA 02004FBF
	v_fma_mixlo_f16 v171, v192, s39, 0                         // 0000001D7F48: CC2100AB 02004FC0
	v_fma_mixhi_f16 v171, v193, s39, 0                         // 0000001D7F50: CC2200AB 02004FC1
	s_waitcnt lgkmcnt(0)                                       // 0000001D7F58: BF89FC07
	v_fma_mixlo_f16 v172, v172, s39, 0                         // 0000001D7F5C: CC2100AC 02004FAC
	v_fma_mixhi_f16 v172, v173, s39, 0                         // 0000001D7F64: CC2200AC 02004FAD
	v_fma_mixlo_f16 v173, v174, s39, 0                         // 0000001D7F6C: CC2100AD 02004FAE
	v_fma_mixhi_f16 v173, v175, s39, 0                         // 0000001D7F74: CC2200AD 02004FAF
	ds_load_b128 v[176:179], v129 offset:128                   // 0000001D7F7C: DBFC0080 B0000081
	ds_load_b128 v[180:183], v129 offset:144                   // 0000001D7F84: DBFC0090 B4000081
	ds_load_b128 v[184:187], v129 offset:160                   // 0000001D7F8C: DBFC00A0 B8000081
	s_waitcnt vmcnt(12)                                        // 0000001D7F94: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001D7F98: CC404019 1C66C359
	ds_load_b128 v[97:100], v129 offset:176                    // 0000001D7FA0: DBFC00B0 61000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[150:157], v[9:16]// 0000001D7FA8: CC404009 1C272D59
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[158:165], v[17:24]// 0000001D7FB0: CC404011 1C473D59
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[166:173], v[1:8]// 0000001D7FB8: CC404001 1C074D59
	ds_load_b128 v[101:104], v129 offset:8576                  // 0000001D7FC0: DBFC2180 65000081
	ds_load_b128 v[150:153], v129 offset:8592                  // 0000001D7FC8: DBFC2190 96000081
	ds_load_b128 v[154:157], v129 offset:8608                  // 0000001D7FD0: DBFC21A0 9A000081
	ds_load_b128 v[158:161], v129 offset:8624                  // 0000001D7FD8: DBFC21B0 9E000081
	ds_load_b128 v[162:165], v129 offset:17024                 // 0000001D7FE0: DBFC4280 A2000081
	ds_load_b128 v[166:169], v129 offset:17040                 // 0000001D7FE8: DBFC4290 A6000081
	ds_load_b128 v[170:173], v129 offset:17056                 // 0000001D7FF0: DBFC42A0 AA000081
	s_mul_hi_u32 s13, s40, 0xfffff430                          // 0000001D7FF8: 968DFF28 FFFFF430
	s_mul_i32 s14, s40, 0xfffff430                             // 0000001D8000: 960EFF28 FFFFF430
	s_sub_i32 s13, s13, s40                                    // 0000001D8008: 818D280D
	s_add_u32 s28, s28, s14                                    // 0000001D800C: 801C0E1C
	s_addc_u32 s29, s29, s13                                   // 0000001D8010: 821D0D1D
	s_waitcnt lgkmcnt(10)                                      // 0000001D8014: BF89FCA7
	v_fma_mixlo_f16 v89, v176, s39, 0                          // 0000001D8018: CC210059 02004FB0
	v_fma_mixhi_f16 v89, v177, s39, 0                          // 0000001D8020: CC220059 02004FB1
	v_fma_mixlo_f16 v90, v178, s39, 0                          // 0000001D8028: CC21005A 02004FB2
	v_fma_mixhi_f16 v90, v179, s39, 0                          // 0000001D8030: CC22005A 02004FB3
	s_waitcnt lgkmcnt(9)                                       // 0000001D8038: BF89FC97
	v_fma_mixlo_f16 v91, v180, s39, 0                          // 0000001D803C: CC21005B 02004FB4
	v_fma_mixhi_f16 v91, v181, s39, 0                          // 0000001D8044: CC22005B 02004FB5
	s_waitcnt lgkmcnt(7)                                       // 0000001D804C: BF89FC77
	v_fma_mixhi_f16 v95, v98, s39, 0                           // 0000001D8050: CC22005F 02004F62
	v_fma_mixlo_f16 v96, v99, s39, 0                           // 0000001D8058: CC210060 02004F63
	v_fma_mixhi_f16 v96, v100, s39, 0                          // 0000001D8060: CC220060 02004F64
	s_waitcnt lgkmcnt(6)                                       // 0000001D8068: BF89FC67
	v_fma_mixlo_f16 v98, v103, s39, 0                          // 0000001D806C: CC210062 02004F67
	v_fma_mixhi_f16 v98, v104, s39, 0                          // 0000001D8074: CC220062 02004F68
	s_waitcnt lgkmcnt(5)                                       // 0000001D807C: BF89FC57
	v_fma_mixlo_f16 v99, v150, s39, 0                          // 0000001D8080: CC210063 02004F96
	v_fma_mixhi_f16 v99, v151, s39, 0                          // 0000001D8088: CC220063 02004F97
	v_fma_mixlo_f16 v100, v152, s39, 0                         // 0000001D8090: CC210064 02004F98
	v_fma_mixhi_f16 v100, v153, s39, 0                         // 0000001D8098: CC220064 02004F99
	s_waitcnt lgkmcnt(3)                                       // 0000001D80A0: BF89FC37
	v_fma_mixlo_f16 v103, v158, s39, 0                         // 0000001D80A4: CC210067 02004F9E
	ds_load_b128 v[174:177], v129 offset:17072                 // 0000001D80AC: DBFC42B0 AE000081
	v_fma_mixhi_f16 v103, v159, s39, 0                         // 0000001D80B4: CC220067 02004F9F
	v_fma_mixlo_f16 v104, v160, s39, 0                         // 0000001D80BC: CC210068 02004FA0
	v_fma_mixhi_f16 v104, v161, s39, 0                         // 0000001D80C4: CC220068 02004FA1
	ds_load_b128 v[158:161], v129 offset:25472                 // 0000001D80CC: DBFC6380 9E000081
	ds_load_b128 v[178:181], v129 offset:25488                 // 0000001D80D4: DBFC6390 B2000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D80DC: BF89FC57
	v_fma_mixlo_f16 v150, v162, s39, 0                         // 0000001D80E0: CC210096 02004FA2
	v_fma_mixhi_f16 v150, v163, s39, 0                         // 0000001D80E8: CC220096 02004FA3
	v_fma_mixlo_f16 v151, v164, s39, 0                         // 0000001D80F0: CC210097 02004FA4
	v_fma_mixhi_f16 v151, v165, s39, 0                         // 0000001D80F8: CC220097 02004FA5
	s_waitcnt lgkmcnt(4)                                       // 0000001D8100: BF89FC47
	v_fma_mixlo_f16 v152, v166, s39, 0                         // 0000001D8104: CC210098 02004FA6
	v_fma_mixhi_f16 v152, v167, s39, 0                         // 0000001D810C: CC220098 02004FA7
	v_fma_mixlo_f16 v153, v168, s39, 0                         // 0000001D8114: CC210099 02004FA8
	ds_load_b128 v[162:165], v129 offset:25504                 // 0000001D811C: DBFC63A0 A2000081
	v_fma_mixhi_f16 v153, v169, s39, 0                         // 0000001D8124: CC220099 02004FA9
	ds_load_b128 v[166:169], v129 offset:25520                 // 0000001D812C: DBFC63B0 A6000081
	v_fma_mixlo_f16 v92, v182, s39, 0                          // 0000001D8134: CC21005C 02004FB6
	v_fma_mixhi_f16 v92, v183, s39, 0                          // 0000001D813C: CC22005C 02004FB7
	v_fma_mixlo_f16 v93, v184, s39, 0                          // 0000001D8144: CC21005D 02004FB8
	v_fma_mixhi_f16 v93, v185, s39, 0                          // 0000001D814C: CC22005D 02004FB9
	v_fma_mixlo_f16 v94, v186, s39, 0                          // 0000001D8154: CC21005E 02004FBA
	v_fma_mixhi_f16 v94, v187, s39, 0                          // 0000001D815C: CC22005E 02004FBB
	v_fma_mixlo_f16 v95, v97, s39, 0                           // 0000001D8164: CC21005F 02004F61
	v_fma_mixlo_f16 v97, v101, s39, 0                          // 0000001D816C: CC210061 02004F65
	v_fma_mixhi_f16 v97, v102, s39, 0                          // 0000001D8174: CC220061 02004F66
	v_fma_mixlo_f16 v101, v154, s39, 0                         // 0000001D817C: CC210065 02004F9A
	v_fma_mixhi_f16 v101, v155, s39, 0                         // 0000001D8184: CC220065 02004F9B
	v_fma_mixlo_f16 v102, v156, s39, 0                         // 0000001D818C: CC210066 02004F9C
	v_fma_mixhi_f16 v102, v157, s39, 0                         // 0000001D8194: CC220066 02004F9D
	s_waitcnt lgkmcnt(5)                                       // 0000001D819C: BF89FC57
	v_fma_mixlo_f16 v154, v170, s39, 0                         // 0000001D81A0: CC21009A 02004FAA
	v_fma_mixhi_f16 v154, v171, s39, 0                         // 0000001D81A8: CC22009A 02004FAB
	v_fma_mixlo_f16 v155, v172, s39, 0                         // 0000001D81B0: CC21009B 02004FAC
	v_fma_mixhi_f16 v155, v173, s39, 0                         // 0000001D81B8: CC22009B 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D81C0: BF89FC47
	v_fma_mixlo_f16 v156, v174, s39, 0                         // 0000001D81C4: CC21009C 02004FAE
	v_fma_mixhi_f16 v156, v175, s39, 0                         // 0000001D81CC: CC22009C 02004FAF
	v_fma_mixlo_f16 v157, v176, s39, 0                         // 0000001D81D4: CC21009D 02004FB0
	v_fma_mixhi_f16 v157, v177, s39, 0                         // 0000001D81DC: CC22009D 02004FB1
	s_waitcnt lgkmcnt(3)                                       // 0000001D81E4: BF89FC37
	v_fma_mixlo_f16 v158, v158, s39, 0                         // 0000001D81E8: CC21009E 02004F9E
	v_fma_mixhi_f16 v158, v159, s39, 0                         // 0000001D81F0: CC22009E 02004F9F
	v_fma_mixlo_f16 v159, v160, s39, 0                         // 0000001D81F8: CC21009F 02004FA0
	v_fma_mixhi_f16 v159, v161, s39, 0                         // 0000001D8200: CC22009F 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001D8208: BF89FC27
	v_fma_mixlo_f16 v160, v178, s39, 0                         // 0000001D820C: CC2100A0 02004FB2
	v_fma_mixhi_f16 v160, v179, s39, 0                         // 0000001D8214: CC2200A0 02004FB3
	v_fma_mixlo_f16 v161, v180, s39, 0                         // 0000001D821C: CC2100A1 02004FB4
	v_fma_mixhi_f16 v161, v181, s39, 0                         // 0000001D8224: CC2200A1 02004FB5
	s_waitcnt lgkmcnt(1)                                       // 0000001D822C: BF89FC17
	v_fma_mixlo_f16 v162, v162, s39, 0                         // 0000001D8230: CC2100A2 02004FA2
	v_fma_mixhi_f16 v162, v163, s39, 0                         // 0000001D8238: CC2200A2 02004FA3
	v_fma_mixlo_f16 v163, v164, s39, 0                         // 0000001D8240: CC2100A3 02004FA4
	v_fma_mixhi_f16 v163, v165, s39, 0                         // 0000001D8248: CC2200A3 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D8250: BF89FC07
	v_fma_mixlo_f16 v164, v166, s39, 0                         // 0000001D8254: CC2100A4 02004FA6
	v_fma_mixhi_f16 v164, v167, s39, 0                         // 0000001D825C: CC2200A4 02004FA7
	v_fma_mixlo_f16 v165, v168, s39, 0                         // 0000001D8264: CC2100A5 02004FA8
	v_fma_mixhi_f16 v165, v169, s39, 0                         // 0000001D826C: CC2200A5 02004FA9
	ds_load_b128 v[170:173], v129 offset:192                   // 0000001D8274: DBFC00C0 AA000081
	ds_load_b128 v[174:177], v129 offset:208                   // 0000001D827C: DBFC00D0 AE000081
	ds_load_b128 v[178:181], v129 offset:224                   // 0000001D8284: DBFC00E0 B2000081
	s_waitcnt vmcnt(10)                                        // 0000001D828C: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001D8290: CC404019 1C66B351
	ds_load_b128 v[89:92], v129 offset:240                     // 0000001D8298: DBFC00F0 59000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001D82A0: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[150:157], v[17:24]// 0000001D82A8: CC404011 1C472D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[158:165], v[1:8]// 0000001D82B0: CC404001 1C073D51
	ds_load_b128 v[93:96], v129 offset:8640                    // 0000001D82B8: DBFC21C0 5D000081
	ds_load_b128 v[97:100], v129 offset:8656                   // 0000001D82C0: DBFC21D0 61000081
	ds_load_b128 v[101:104], v129 offset:8672                  // 0000001D82C8: DBFC21E0 65000081
	ds_load_b128 v[150:153], v129 offset:8688                  // 0000001D82D0: DBFC21F0 96000081
	ds_load_b128 v[154:157], v129 offset:17088                 // 0000001D82D8: DBFC42C0 9A000081
	ds_load_b128 v[158:161], v129 offset:17104                 // 0000001D82E0: DBFC42D0 9E000081
	ds_load_b128 v[162:165], v129 offset:17120                 // 0000001D82E8: DBFC42E0 A2000081
	ds_load_b128 v[166:169], v129 offset:17136                 // 0000001D82F0: DBFC42F0 A6000081
	s_lshl_b64 s[28:29], s[28:29], 13                          // 0000001D82F8: 849C8D1C
	ds_load_b128 v[182:185], v129 offset:25616                 // 0000001D82FC: DBFC6410 B6000081
	.long 0xd7000d74                                           // 0000001D8304: D7000D74
	v_cndmask_b32_e32 v0, v139, v28, vcc_lo                    // 0000001D8308: 0200398B
	s_waitcnt lgkmcnt(12)                                      // 0000001D830C: BF89FCC7
	v_fma_mixlo_f16 v81, v170, s39, 0                          // 0000001D8310: CC210051 02004FAA
	v_fma_mixhi_f16 v81, v171, s39, 0                          // 0000001D8318: CC220051 02004FAB
	v_fma_mixlo_f16 v82, v172, s39, 0                          // 0000001D8320: CC210052 02004FAC
	v_fma_mixhi_f16 v82, v173, s39, 0                          // 0000001D8328: CC220052 02004FAD
	s_waitcnt lgkmcnt(9)                                       // 0000001D8330: BF89FC97
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001D8334: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001D833C: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001D8344: CC220058 02004F5C
	ds_load_b128 v[170:173], v129 offset:25552                 // 0000001D834C: DBFC63D0 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D8354: BF89FC97
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001D8358: CC21005A 02004F5F
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001D8360: CC22005A 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001D8368: BF89FC87
	v_fma_mixlo_f16 v91, v97, s39, 0                           // 0000001D836C: CC21005B 02004F61
	v_fma_mixhi_f16 v91, v98, s39, 0                           // 0000001D8374: CC22005B 02004F62
	v_fma_mixlo_f16 v92, v99, s39, 0                           // 0000001D837C: CC21005C 02004F63
	v_fma_mixhi_f16 v92, v100, s39, 0                          // 0000001D8384: CC22005C 02004F64
	s_waitcnt lgkmcnt(6)                                       // 0000001D838C: BF89FC67
	v_fma_mixlo_f16 v95, v150, s39, 0                          // 0000001D8390: CC21005F 02004F96
	v_fma_mixhi_f16 v95, v151, s39, 0                          // 0000001D8398: CC22005F 02004F97
	v_fma_mixlo_f16 v96, v152, s39, 0                          // 0000001D83A0: CC210060 02004F98
	v_fma_mixhi_f16 v96, v153, s39, 0                          // 0000001D83A8: CC220060 02004F99
	ds_load_b128 v[150:153], v129 offset:25536                 // 0000001D83B0: DBFC63C0 96000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D83B8: BF89FC67
	v_fma_mixlo_f16 v97, v154, s39, 0                          // 0000001D83BC: CC210061 02004F9A
	v_fma_mixhi_f16 v97, v155, s39, 0                          // 0000001D83C4: CC220061 02004F9B
	v_fma_mixlo_f16 v98, v156, s39, 0                          // 0000001D83CC: CC210062 02004F9C
	v_fma_mixhi_f16 v98, v157, s39, 0                          // 0000001D83D4: CC220062 02004F9D
	s_waitcnt lgkmcnt(5)                                       // 0000001D83DC: BF89FC57
	v_fma_mixlo_f16 v99, v158, s39, 0                          // 0000001D83E0: CC210063 02004F9E
	v_fma_mixhi_f16 v99, v159, s39, 0                          // 0000001D83E8: CC220063 02004F9F
	v_fma_mixlo_f16 v100, v160, s39, 0                         // 0000001D83F0: CC210064 02004FA0
	v_fma_mixhi_f16 v100, v161, s39, 0                         // 0000001D83F8: CC220064 02004FA1
	ds_load_b128 v[154:157], v129 offset:25568                 // 0000001D8400: DBFC63E0 9A000081
	ds_load_b128 v[158:161], v129 offset:25584                 // 0000001D8408: DBFC63F0 9E000081
	v_fma_mixlo_f16 v83, v174, s39, 0                          // 0000001D8410: CC210053 02004FAE
	v_fma_mixhi_f16 v83, v175, s39, 0                          // 0000001D8418: CC220053 02004FAF
	v_fma_mixlo_f16 v84, v176, s39, 0                          // 0000001D8420: CC210054 02004FB0
	v_fma_mixhi_f16 v84, v177, s39, 0                          // 0000001D8428: CC220054 02004FB1
	v_fma_mixlo_f16 v85, v178, s39, 0                          // 0000001D8430: CC210055 02004FB2
	v_fma_mixhi_f16 v85, v179, s39, 0                          // 0000001D8438: CC220055 02004FB3
	v_fma_mixlo_f16 v86, v180, s39, 0                          // 0000001D8440: CC210056 02004FB4
	v_fma_mixhi_f16 v86, v181, s39, 0                          // 0000001D8448: CC220056 02004FB5
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001D8450: CC210057 02004F59
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001D8458: CC210059 02004F5D
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001D8460: CC220059 02004F5E
	v_fma_mixlo_f16 v93, v101, s39, 0                          // 0000001D8468: CC21005D 02004F65
	v_fma_mixhi_f16 v93, v102, s39, 0                          // 0000001D8470: CC22005D 02004F66
	v_fma_mixlo_f16 v94, v103, s39, 0                          // 0000001D8478: CC21005E 02004F67
	v_fma_mixhi_f16 v94, v104, s39, 0                          // 0000001D8480: CC22005E 02004F68
	s_waitcnt lgkmcnt(6)                                       // 0000001D8488: BF89FC67
	v_fma_mixlo_f16 v101, v162, s39, 0                         // 0000001D848C: CC210065 02004FA2
	v_fma_mixhi_f16 v101, v163, s39, 0                         // 0000001D8494: CC220065 02004FA3
	v_fma_mixlo_f16 v102, v164, s39, 0                         // 0000001D849C: CC210066 02004FA4
	v_fma_mixhi_f16 v102, v165, s39, 0                         // 0000001D84A4: CC220066 02004FA5
	s_waitcnt lgkmcnt(5)                                       // 0000001D84AC: BF89FC57
	v_fma_mixlo_f16 v103, v166, s39, 0                         // 0000001D84B0: CC210067 02004FA6
	v_fma_mixhi_f16 v103, v167, s39, 0                         // 0000001D84B8: CC220067 02004FA7
	v_fma_mixlo_f16 v104, v168, s39, 0                         // 0000001D84C0: CC210068 02004FA8
	v_fma_mixhi_f16 v104, v169, s39, 0                         // 0000001D84C8: CC220068 02004FA9
	s_waitcnt vmcnt(8)                                         // 0000001D84D0: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001D84D4: CC404019 1C66A349
	ds_load_b128 v[81:84], v129 offset:8704                    // 0000001D84DC: DBFC2200 51000081
	ds_load_b128 v[85:88], v129 offset:8720                    // 0000001D84E4: DBFC2210 55000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D84EC: BF89FC47
	v_fma_mixlo_f16 v150, v150, s39, 0                         // 0000001D84F0: CC210096 02004F96
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001D84F8: CC404011 1C46C349
	ds_load_b128 v[102:105], v129 offset:8736                  // 0000001D8500: DBFC2220 66000081
	v_fma_mixhi_f16 v150, v151, s39, 0                         // 0000001D8508: CC220096 02004F97
	v_fma_mixlo_f16 v151, v152, s39, 0                         // 0000001D8510: CC210097 02004F98
	v_fma_mixhi_f16 v151, v153, s39, 0                         // 0000001D8518: CC220097 02004F99
	v_fma_mixlo_f16 v152, v170, s39, 0                         // 0000001D8520: CC210098 02004FAA
	v_fma_mixhi_f16 v152, v171, s39, 0                         // 0000001D8528: CC220098 02004FAB
	v_fma_mixlo_f16 v153, v172, s39, 0                         // 0000001D8530: CC210099 02004FAC
	v_fma_mixhi_f16 v153, v173, s39, 0                         // 0000001D8538: CC220099 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D8540: BF89FC47
	v_fma_mixlo_f16 v154, v154, s39, 0                         // 0000001D8544: CC21009A 02004F9A
	v_fma_mixhi_f16 v154, v155, s39, 0                         // 0000001D854C: CC22009A 02004F9B
	v_fma_mixlo_f16 v155, v156, s39, 0                         // 0000001D8554: CC21009B 02004F9C
	v_fma_mixhi_f16 v155, v157, s39, 0                         // 0000001D855C: CC22009B 02004F9D
	s_waitcnt lgkmcnt(3)                                       // 0000001D8564: BF89FC37
	v_fma_mixlo_f16 v156, v158, s39, 0                         // 0000001D8568: CC21009C 02004F9E
	v_fma_mixhi_f16 v156, v159, s39, 0                         // 0000001D8570: CC22009C 02004F9F
	v_fma_mixlo_f16 v157, v160, s39, 0                         // 0000001D8578: CC21009D 02004FA0
	v_fma_mixhi_f16 v157, v161, s39, 0                         // 0000001D8580: CC22009D 02004FA1
	v_add_co_ci_u32_e64 v117, null, s29, v140, s13             // 0000001D8588: D5207C75 0037181D
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001D8590: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001D8598: BF89FC27
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001D859C: CC210051 02004F51
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[150:157], v[1:8]// 0000001D85A4: CC404001 1C072D49
	s_clause 0x1                                               // 0000001D85AC: BF850001
	global_load_b128 v[154:157], v[116:117], off offset:16     // 0000001D85B0: DC5E0010 9A7C0074
	global_load_b128 v[150:153], v[116:117], off               // 0000001D85B8: DC5E0000 967C0074
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001D85C0: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001D85C8: CC210052 02004F53
	ds_load_b128 v[158:161], v129 offset:8752                  // 0000001D85D0: DBFC2230 9E000081
	s_waitcnt lgkmcnt(2)                                       // 0000001D85D8: BF89FC27
	v_fma_mixlo_f16 v83, v85, s39, 0                           // 0000001D85DC: CC210053 02004F55
	v_fma_mixhi_f16 v83, v86, s39, 0                           // 0000001D85E4: CC220053 02004F56
	s_waitcnt lgkmcnt(1)                                       // 0000001D85EC: BF89FC17
	v_fma_mixlo_f16 v85, v102, s39, 0                          // 0000001D85F0: CC210055 02004F66
	v_fma_mixhi_f16 v85, v103, s39, 0                          // 0000001D85F8: CC220055 02004F67
	v_fma_mixlo_f16 v86, v104, s39, 0                          // 0000001D8600: CC210056 02004F68
	s_clause 0x3                                               // 0000001D8608: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 0000001D860C: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 0000001D8614: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 0000001D861C: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 0000001D8624: DC5E0060 597C0074
	ds_load_b128 v[162:165], v129 offset:256                   // 0000001D862C: DBFC0100 A2000081
	ds_load_b128 v[166:169], v129 offset:272                   // 0000001D8634: DBFC0110 A6000081
	ds_load_b128 v[170:173], v129 offset:288                   // 0000001D863C: DBFC0120 AA000081
	ds_load_b128 v[174:177], v129 offset:304                   // 0000001D8644: DBFC0130 AE000081
	ds_load_b128 v[178:181], v129 offset:25600                 // 0000001D864C: DBFC6400 B2000081
	ds_load_b128 v[186:189], v129 offset:25632                 // 0000001D8654: DBFC6420 BA000081
	ds_load_b128 v[190:193], v129 offset:25648                 // 0000001D865C: DBFC6430 BE000081
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001D8664: CC220052 02004F54
	v_fma_mixlo_f16 v84, v87, s39, 0                           // 0000001D866C: CC210054 02004F57
	v_fma_mixhi_f16 v84, v88, s39, 0                           // 0000001D8674: CC220054 02004F58
	v_fma_mixhi_f16 v86, v105, s39, 0                          // 0000001D867C: CC220056 02004F69
	s_waitcnt lgkmcnt(7)                                       // 0000001D8684: BF89FC77
	v_fma_mixlo_f16 v87, v158, s39, 0                          // 0000001D8688: CC210057 02004F9E
	v_fma_mixhi_f16 v87, v159, s39, 0                          // 0000001D8690: CC220057 02004F9F
	v_fma_mixlo_f16 v88, v160, s39, 0                          // 0000001D8698: CC210058 02004FA0
	v_fma_mixhi_f16 v88, v161, s39, 0                          // 0000001D86A0: CC220058 02004FA1
	s_waitcnt lgkmcnt(6)                                       // 0000001D86A8: BF89FC67
	v_fma_mixlo_f16 v73, v162, s39, 0                          // 0000001D86AC: CC210049 02004FA2
	v_fma_mixhi_f16 v73, v163, s39, 0                          // 0000001D86B4: CC220049 02004FA3
	v_fma_mixlo_f16 v74, v164, s39, 0                          // 0000001D86BC: CC21004A 02004FA4
	v_fma_mixhi_f16 v74, v165, s39, 0                          // 0000001D86C4: CC22004A 02004FA5
	s_waitcnt lgkmcnt(5)                                       // 0000001D86CC: BF89FC57
	v_fma_mixlo_f16 v75, v166, s39, 0                          // 0000001D86D0: CC21004B 02004FA6
	v_fma_mixhi_f16 v75, v167, s39, 0                          // 0000001D86D8: CC22004B 02004FA7
	v_fma_mixlo_f16 v76, v168, s39, 0                          // 0000001D86E0: CC21004C 02004FA8
	v_fma_mixhi_f16 v76, v169, s39, 0                          // 0000001D86E8: CC22004C 02004FA9
	s_waitcnt lgkmcnt(4)                                       // 0000001D86F0: BF89FC47
	v_fma_mixlo_f16 v77, v170, s39, 0                          // 0000001D86F4: CC21004D 02004FAA
	v_fma_mixhi_f16 v77, v171, s39, 0                          // 0000001D86FC: CC22004D 02004FAB
	v_fma_mixlo_f16 v78, v172, s39, 0                          // 0000001D8704: CC21004E 02004FAC
	v_fma_mixhi_f16 v78, v173, s39, 0                          // 0000001D870C: CC22004E 02004FAD
	s_waitcnt lgkmcnt(3)                                       // 0000001D8714: BF89FC37
	v_fma_mixlo_f16 v79, v174, s39, 0                          // 0000001D8718: CC21004F 02004FAE
	v_fma_mixhi_f16 v79, v175, s39, 0                          // 0000001D8720: CC22004F 02004FAF
	v_fma_mixlo_f16 v80, v176, s39, 0                          // 0000001D8728: CC210050 02004FB0
	v_fma_mixhi_f16 v80, v177, s39, 0                          // 0000001D8730: CC220050 02004FB1
	ds_load_b128 v[162:165], v129 offset:17152                 // 0000001D8738: DBFC4300 A2000081
	ds_load_b128 v[166:169], v129 offset:17168                 // 0000001D8740: DBFC4310 A6000081
	ds_load_b128 v[170:173], v129 offset:17184                 // 0000001D8748: DBFC4320 AA000081
	ds_load_b128 v[174:177], v129 offset:17200                 // 0000001D8750: DBFC4330 AE000081
	s_waitcnt vmcnt(12)                                        // 0000001D8758: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001D875C: CC404019 1C669339
	ds_load_b128 v[73:76], v129 offset:368                     // 0000001D8764: DBFC0170 49000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001D876C: CC404009 1C26A339
	ds_load_b128 v[77:80], v129 offset:8768                    // 0000001D8774: DBFC2240 4D000081
	ds_load_b128 v[81:84], v129 offset:8784                    // 0000001D877C: DBFC2250 51000081
	ds_load_b128 v[85:88], v129 offset:8800                    // 0000001D8784: DBFC2260 55000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D878C: BF89FC77
	v_fma_mixlo_f16 v158, v162, s39, 0                         // 0000001D8790: CC21009E 02004FA2
	v_fma_mixhi_f16 v158, v163, s39, 0                         // 0000001D8798: CC22009E 02004FA3
	v_fma_mixlo_f16 v159, v164, s39, 0                         // 0000001D87A0: CC21009F 02004FA4
	v_fma_mixhi_f16 v159, v165, s39, 0                         // 0000001D87A8: CC22009F 02004FA5
	s_waitcnt lgkmcnt(6)                                       // 0000001D87B0: BF89FC67
	v_fma_mixlo_f16 v160, v166, s39, 0                         // 0000001D87B4: CC2100A0 02004FA6
	v_fma_mixhi_f16 v160, v167, s39, 0                         // 0000001D87BC: CC2200A0 02004FA7
	v_fma_mixlo_f16 v161, v168, s39, 0                         // 0000001D87C4: CC2100A1 02004FA8
	v_fma_mixhi_f16 v161, v169, s39, 0                         // 0000001D87CC: CC2200A1 02004FA9
	s_waitcnt lgkmcnt(5)                                       // 0000001D87D4: BF89FC57
	v_fma_mixlo_f16 v162, v170, s39, 0                         // 0000001D87D8: CC2100A2 02004FAA
	v_fma_mixhi_f16 v162, v171, s39, 0                         // 0000001D87E0: CC2200A2 02004FAB
	v_fma_mixlo_f16 v163, v172, s39, 0                         // 0000001D87E8: CC2100A3 02004FAC
	v_fma_mixhi_f16 v163, v173, s39, 0                         // 0000001D87F0: CC2200A3 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D87F8: BF89FC47
	v_fma_mixlo_f16 v164, v174, s39, 0                         // 0000001D87FC: CC2100A4 02004FAE
	v_fma_mixhi_f16 v164, v175, s39, 0                         // 0000001D8804: CC2200A4 02004FAF
	v_fma_mixlo_f16 v165, v176, s39, 0                         // 0000001D880C: CC2100A5 02004FB0
	v_fma_mixhi_f16 v165, v177, s39, 0                         // 0000001D8814: CC2200A5 02004FB1
	v_fma_mixlo_f16 v166, v178, s39, 0                         // 0000001D881C: CC2100A6 02004FB2
	v_fma_mixhi_f16 v166, v179, s39, 0                         // 0000001D8824: CC2200A6 02004FB3
	v_fma_mixlo_f16 v167, v180, s39, 0                         // 0000001D882C: CC2100A7 02004FB4
	v_fma_mixhi_f16 v167, v181, s39, 0                         // 0000001D8834: CC2200A7 02004FB5
	v_fma_mixlo_f16 v168, v182, s39, 0                         // 0000001D883C: CC2100A8 02004FB6
	v_fma_mixhi_f16 v168, v183, s39, 0                         // 0000001D8844: CC2200A8 02004FB7
	v_fma_mixlo_f16 v169, v184, s39, 0                         // 0000001D884C: CC2100A9 02004FB8
	v_fma_mixhi_f16 v169, v185, s39, 0                         // 0000001D8854: CC2200A9 02004FB9
	v_fma_mixlo_f16 v170, v186, s39, 0                         // 0000001D885C: CC2100AA 02004FBA
	v_fma_mixhi_f16 v170, v187, s39, 0                         // 0000001D8864: CC2200AA 02004FBB
	v_fma_mixlo_f16 v171, v188, s39, 0                         // 0000001D886C: CC2100AB 02004FBC
	v_fma_mixhi_f16 v171, v189, s39, 0                         // 0000001D8874: CC2200AB 02004FBD
	v_fma_mixlo_f16 v172, v190, s39, 0                         // 0000001D887C: CC2100AC 02004FBE
	v_fma_mixhi_f16 v172, v191, s39, 0                         // 0000001D8884: CC2200AC 02004FBF
	v_fma_mixlo_f16 v173, v192, s39, 0                         // 0000001D888C: CC2100AD 02004FC0
	v_fma_mixhi_f16 v173, v193, s39, 0                         // 0000001D8894: CC2200AD 02004FC1
	ds_load_b128 v[174:177], v129 offset:320                   // 0000001D889C: DBFC0140 AE000081
	ds_load_b128 v[178:181], v129 offset:336                   // 0000001D88A4: DBFC0150 B2000081
	ds_load_b128 v[182:185], v129 offset:352                   // 0000001D88AC: DBFC0160 B6000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[158:165], v[17:24]// 0000001D88B4: CC404011 1C473D39
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[166:173], v[1:8]// 0000001D88BC: CC404001 1C074D39
	ds_load_b128 v[158:161], v129 offset:8816                  // 0000001D88C4: DBFC2270 9E000081
	ds_load_b128 v[162:165], v129 offset:17216                 // 0000001D88CC: DBFC4340 A2000081
	ds_load_b128 v[166:169], v129 offset:17232                 // 0000001D88D4: DBFC4350 A6000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D88DC: BF89FC97
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001D88E0: CC22003F 02004F4A
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001D88E8: CC210040 02004F4B
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001D88F0: CC220040 02004F4C
	s_waitcnt lgkmcnt(8)                                       // 0000001D88F8: BF89FC87
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001D88FC: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001D8904: CC22004A 02004F50
	s_waitcnt lgkmcnt(7)                                       // 0000001D890C: BF89FC77
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001D8910: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001D8918: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001D8920: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001D8928: CC22004C 02004F54
	ds_load_b128 v[170:173], v129 offset:17248                 // 0000001D8930: DBFC4360 AA000081
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001D8938: CC21003F 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001D8940: CC210049 02004F4D
	s_waitcnt lgkmcnt(6)                                       // 0000001D8948: BF89FC67
	v_fma_mixlo_f16 v57, v174, s39, 0                          // 0000001D894C: CC210039 02004FAE
	v_fma_mixhi_f16 v57, v175, s39, 0                          // 0000001D8954: CC220039 02004FAF
	v_fma_mixlo_f16 v58, v176, s39, 0                          // 0000001D895C: CC21003A 02004FB0
	v_fma_mixhi_f16 v58, v177, s39, 0                          // 0000001D8964: CC22003A 02004FB1
	s_waitcnt lgkmcnt(5)                                       // 0000001D896C: BF89FC57
	v_fma_mixlo_f16 v59, v178, s39, 0                          // 0000001D8970: CC21003B 02004FB2
	v_fma_mixhi_f16 v59, v179, s39, 0                          // 0000001D8978: CC22003B 02004FB3
	v_fma_mixlo_f16 v60, v180, s39, 0                          // 0000001D8980: CC21003C 02004FB4
	v_fma_mixhi_f16 v60, v181, s39, 0                          // 0000001D8988: CC22003C 02004FB5
	s_waitcnt lgkmcnt(3)                                       // 0000001D8990: BF89FC37
	v_fma_mixlo_f16 v79, v158, s39, 0                          // 0000001D8994: CC21004F 02004F9E
	ds_load_b128 v[174:177], v129 offset:17264                 // 0000001D899C: DBFC4370 AE000081
	v_fma_mixhi_f16 v79, v159, s39, 0                          // 0000001D89A4: CC22004F 02004F9F
	v_fma_mixlo_f16 v80, v160, s39, 0                          // 0000001D89AC: CC210050 02004FA0
	v_fma_mixhi_f16 v80, v161, s39, 0                          // 0000001D89B4: CC220050 02004FA1
	ds_load_b128 v[158:161], v129 offset:25664                 // 0000001D89BC: DBFC6440 9E000081
	ds_load_b128 v[178:181], v129 offset:25680                 // 0000001D89C4: DBFC6450 B2000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D89CC: BF89FC57
	v_fma_mixlo_f16 v81, v162, s39, 0                          // 0000001D89D0: CC210051 02004FA2
	v_fma_mixhi_f16 v81, v163, s39, 0                          // 0000001D89D8: CC220051 02004FA3
	v_fma_mixlo_f16 v82, v164, s39, 0                          // 0000001D89E0: CC210052 02004FA4
	v_fma_mixhi_f16 v82, v165, s39, 0                          // 0000001D89E8: CC220052 02004FA5
	s_waitcnt lgkmcnt(4)                                       // 0000001D89F0: BF89FC47
	v_fma_mixlo_f16 v83, v166, s39, 0                          // 0000001D89F4: CC210053 02004FA6
	v_fma_mixhi_f16 v83, v167, s39, 0                          // 0000001D89FC: CC220053 02004FA7
	v_fma_mixlo_f16 v84, v168, s39, 0                          // 0000001D8A04: CC210054 02004FA8
	ds_load_b128 v[162:165], v129 offset:25696                 // 0000001D8A0C: DBFC6460 A2000081
	v_fma_mixhi_f16 v84, v169, s39, 0                          // 0000001D8A14: CC220054 02004FA9
	ds_load_b128 v[166:169], v129 offset:25712                 // 0000001D8A1C: DBFC6470 A6000081
	v_fma_mixlo_f16 v61, v182, s39, 0                          // 0000001D8A24: CC21003D 02004FB6
	v_fma_mixhi_f16 v61, v183, s39, 0                          // 0000001D8A2C: CC22003D 02004FB7
	v_fma_mixlo_f16 v62, v184, s39, 0                          // 0000001D8A34: CC21003E 02004FB8
	v_fma_mixhi_f16 v62, v185, s39, 0                          // 0000001D8A3C: CC22003E 02004FB9
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001D8A44: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001D8A4C: CC21004D 02004F55
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001D8A54: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001D8A5C: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001D8A64: CC22004E 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001D8A6C: BF89FC57
	v_fma_mixlo_f16 v85, v170, s39, 0                          // 0000001D8A70: CC210055 02004FAA
	v_fma_mixhi_f16 v85, v171, s39, 0                          // 0000001D8A78: CC220055 02004FAB
	v_fma_mixlo_f16 v86, v172, s39, 0                          // 0000001D8A80: CC210056 02004FAC
	v_fma_mixhi_f16 v86, v173, s39, 0                          // 0000001D8A88: CC220056 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D8A90: BF89FC47
	v_fma_mixlo_f16 v87, v174, s39, 0                          // 0000001D8A94: CC210057 02004FAE
	v_fma_mixhi_f16 v87, v175, s39, 0                          // 0000001D8A9C: CC220057 02004FAF
	v_fma_mixlo_f16 v88, v176, s39, 0                          // 0000001D8AA4: CC210058 02004FB0
	v_fma_mixhi_f16 v88, v177, s39, 0                          // 0000001D8AAC: CC220058 02004FB1
	s_waitcnt lgkmcnt(3)                                       // 0000001D8AB4: BF89FC37
	v_fma_mixlo_f16 v158, v158, s39, 0                         // 0000001D8AB8: CC21009E 02004F9E
	v_fma_mixhi_f16 v158, v159, s39, 0                         // 0000001D8AC0: CC22009E 02004F9F
	v_fma_mixlo_f16 v159, v160, s39, 0                         // 0000001D8AC8: CC21009F 02004FA0
	v_fma_mixhi_f16 v159, v161, s39, 0                         // 0000001D8AD0: CC22009F 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001D8AD8: BF89FC27
	v_fma_mixlo_f16 v160, v178, s39, 0                         // 0000001D8ADC: CC2100A0 02004FB2
	v_fma_mixhi_f16 v160, v179, s39, 0                         // 0000001D8AE4: CC2200A0 02004FB3
	v_fma_mixlo_f16 v161, v180, s39, 0                         // 0000001D8AEC: CC2100A1 02004FB4
	v_fma_mixhi_f16 v161, v181, s39, 0                         // 0000001D8AF4: CC2200A1 02004FB5
	s_waitcnt lgkmcnt(1)                                       // 0000001D8AFC: BF89FC17
	v_fma_mixlo_f16 v162, v162, s39, 0                         // 0000001D8B00: CC2100A2 02004FA2
	v_fma_mixhi_f16 v162, v163, s39, 0                         // 0000001D8B08: CC2200A2 02004FA3
	v_fma_mixlo_f16 v163, v164, s39, 0                         // 0000001D8B10: CC2100A3 02004FA4
	v_fma_mixhi_f16 v163, v165, s39, 0                         // 0000001D8B18: CC2200A3 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D8B20: BF89FC07
	v_fma_mixlo_f16 v164, v166, s39, 0                         // 0000001D8B24: CC2100A4 02004FA6
	v_fma_mixhi_f16 v164, v167, s39, 0                         // 0000001D8B2C: CC2200A4 02004FA7
	v_fma_mixlo_f16 v165, v168, s39, 0                         // 0000001D8B34: CC2100A5 02004FA8
	v_fma_mixhi_f16 v165, v169, s39, 0                         // 0000001D8B3C: CC2200A5 02004FA9
	ds_load_b128 v[170:173], v129 offset:384                   // 0000001D8B44: DBFC0180 AA000081
	ds_load_b128 v[174:177], v129 offset:400                   // 0000001D8B4C: DBFC0190 AE000081
	ds_load_b128 v[178:181], v129 offset:416                   // 0000001D8B54: DBFC01A0 B2000081
	s_waitcnt vmcnt(10)                                        // 0000001D8B5C: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001D8B60: CC404019 1C667331
	ds_load_b128 v[57:60], v129 offset:432                     // 0000001D8B68: DBFC01B0 39000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001D8B70: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001D8B78: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[158:165], v[1:8]// 0000001D8B80: CC404001 1C073D31
	ds_load_b128 v[61:64], v129 offset:8832                    // 0000001D8B88: DBFC2280 3D000081
	ds_load_b128 v[73:76], v129 offset:8848                    // 0000001D8B90: DBFC2290 49000081
	ds_load_b128 v[77:80], v129 offset:8864                    // 0000001D8B98: DBFC22A0 4D000081
	ds_load_b128 v[81:84], v129 offset:8880                    // 0000001D8BA0: DBFC22B0 51000081
	ds_load_b128 v[85:88], v129 offset:17280                   // 0000001D8BA8: DBFC4380 55000081
	ds_load_b128 v[158:161], v129 offset:17296                 // 0000001D8BB0: DBFC4390 9E000081
	ds_load_b128 v[162:165], v129 offset:17312                 // 0000001D8BB8: DBFC43A0 A2000081
	ds_load_b128 v[166:169], v129 offset:17328                 // 0000001D8BC0: DBFC43B0 A6000081
	ds_load_b128 v[185:188], v129 offset:25840                 // 0000001D8BC8: DBFC64F0 B9000081
	s_waitcnt lgkmcnt(12)                                      // 0000001D8BD0: BF89FCC7
	v_fma_mixlo_f16 v49, v170, s39, 0                          // 0000001D8BD4: CC210031 02004FAA
	v_fma_mixhi_f16 v49, v171, s39, 0                          // 0000001D8BDC: CC220031 02004FAB
	v_fma_mixlo_f16 v50, v172, s39, 0                          // 0000001D8BE4: CC210032 02004FAC
	v_fma_mixhi_f16 v50, v173, s39, 0                          // 0000001D8BEC: CC220032 02004FAD
	s_waitcnt lgkmcnt(9)                                       // 0000001D8BF4: BF89FC97
	v_fma_mixhi_f16 v55, v58, s39, 0                           // 0000001D8BF8: CC220037 02004F3A
	v_fma_mixlo_f16 v56, v59, s39, 0                           // 0000001D8C00: CC210038 02004F3B
	v_fma_mixhi_f16 v56, v60, s39, 0                           // 0000001D8C08: CC220038 02004F3C
	ds_load_b128 v[170:173], v129 offset:25744                 // 0000001D8C10: DBFC6490 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D8C18: BF89FC97
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001D8C1C: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001D8C24: CC22003A 02004F40
	s_waitcnt lgkmcnt(8)                                       // 0000001D8C2C: BF89FC87
	v_fma_mixlo_f16 v59, v73, s39, 0                           // 0000001D8C30: CC21003B 02004F49
	v_fma_mixhi_f16 v59, v74, s39, 0                           // 0000001D8C38: CC22003B 02004F4A
	v_fma_mixlo_f16 v60, v75, s39, 0                           // 0000001D8C40: CC21003C 02004F4B
	v_fma_mixhi_f16 v60, v76, s39, 0                           // 0000001D8C48: CC22003C 02004F4C
	s_waitcnt lgkmcnt(6)                                       // 0000001D8C50: BF89FC67
	v_fma_mixlo_f16 v63, v81, s39, 0                           // 0000001D8C54: CC21003F 02004F51
	v_fma_mixhi_f16 v63, v82, s39, 0                           // 0000001D8C5C: CC22003F 02004F52
	v_fma_mixlo_f16 v64, v83, s39, 0                           // 0000001D8C64: CC210040 02004F53
	v_fma_mixhi_f16 v64, v84, s39, 0                           // 0000001D8C6C: CC220040 02004F54
	ds_load_b128 v[81:84], v129 offset:25728                   // 0000001D8C74: DBFC6480 51000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D8C7C: BF89FC67
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001D8C80: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001D8C88: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001D8C90: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001D8C98: CC22004A 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001D8CA0: BF89FC57
	v_fma_mixlo_f16 v75, v158, s39, 0                          // 0000001D8CA4: CC21004B 02004F9E
	v_fma_mixhi_f16 v75, v159, s39, 0                          // 0000001D8CAC: CC22004B 02004F9F
	v_fma_mixlo_f16 v76, v160, s39, 0                          // 0000001D8CB4: CC21004C 02004FA0
	ds_load_b128 v[85:88], v129 offset:25760                   // 0000001D8CBC: DBFC64A0 55000081
	v_fma_mixhi_f16 v76, v161, s39, 0                          // 0000001D8CC4: CC22004C 02004FA1
	ds_load_b128 v[158:161], v129 offset:25776                 // 0000001D8CCC: DBFC64B0 9E000081
	v_fma_mixlo_f16 v55, v57, s39, 0                           // 0000001D8CD4: CC210037 02004F39
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001D8CDC: CC210039 02004F3D
	v_fma_mixlo_f16 v61, v77, s39, 0                           // 0000001D8CE4: CC21003D 02004F4D
	v_fma_mixhi_f16 v61, v78, s39, 0                           // 0000001D8CEC: CC22003D 02004F4E
	s_waitcnt lgkmcnt(6)                                       // 0000001D8CF4: BF89FC67
	v_fma_mixlo_f16 v77, v162, s39, 0                          // 0000001D8CF8: CC21004D 02004FA2
	v_fma_mixhi_f16 v77, v163, s39, 0                          // 0000001D8D00: CC22004D 02004FA3
	v_fma_mixlo_f16 v78, v164, s39, 0                          // 0000001D8D08: CC21004E 02004FA4
	v_fma_mixhi_f16 v78, v165, s39, 0                          // 0000001D8D10: CC22004E 02004FA5
	ds_load_b128 v[162:165], v129 offset:448                   // 0000001D8D18: DBFC01C0 A2000081
	s_waitcnt lgkmcnt(3)                                       // 0000001D8D20: BF89FC37
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001D8D24: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001D8D2C: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001D8D34: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001D8D3C: CC220052 02004F54
	v_fma_mixlo_f16 v83, v170, s39, 0                          // 0000001D8D44: CC210053 02004FAA
	v_fma_mixhi_f16 v83, v171, s39, 0                          // 0000001D8D4C: CC220053 02004FAB
	v_fma_mixlo_f16 v84, v172, s39, 0                          // 0000001D8D54: CC210054 02004FAC
	v_fma_mixhi_f16 v84, v173, s39, 0                          // 0000001D8D5C: CC220054 02004FAD
	s_waitcnt lgkmcnt(2)                                       // 0000001D8D64: BF89FC27
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001D8D68: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001D8D70: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001D8D78: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001D8D80: CC220056 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001D8D88: BF89FC17
	v_fma_mixlo_f16 v87, v158, s39, 0                          // 0000001D8D8C: CC210057 02004F9E
	ds_load_b128 v[170:173], v129 offset:480                   // 0000001D8D94: DBFC01E0 AA000081
	v_fma_mixhi_f16 v87, v159, s39, 0                          // 0000001D8D9C: CC220057 02004F9F
	v_fma_mixlo_f16 v88, v160, s39, 0                          // 0000001D8DA4: CC210058 02004FA0
	v_fma_mixhi_f16 v88, v161, s39, 0                          // 0000001D8DAC: CC220058 02004FA1
	ds_load_b128 v[158:161], v129 offset:496                   // 0000001D8DB4: DBFC01F0 9E000081
	v_fma_mixlo_f16 v51, v174, s39, 0                          // 0000001D8DBC: CC210033 02004FAE
	v_fma_mixhi_f16 v51, v175, s39, 0                          // 0000001D8DC4: CC220033 02004FAF
	v_fma_mixlo_f16 v52, v176, s39, 0                          // 0000001D8DCC: CC210034 02004FB0
	v_fma_mixhi_f16 v52, v177, s39, 0                          // 0000001D8DD4: CC220034 02004FB1
	v_fma_mixlo_f16 v53, v178, s39, 0                          // 0000001D8DDC: CC210035 02004FB2
	v_fma_mixhi_f16 v53, v179, s39, 0                          // 0000001D8DE4: CC220035 02004FB3
	v_fma_mixlo_f16 v54, v180, s39, 0                          // 0000001D8DEC: CC210036 02004FB4
	v_fma_mixhi_f16 v54, v181, s39, 0                          // 0000001D8DF4: CC220036 02004FB5
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001D8DFC: CC220039 02004F3E
	v_fma_mixlo_f16 v62, v79, s39, 0                           // 0000001D8E04: CC21003E 02004F4F
	v_fma_mixhi_f16 v62, v80, s39, 0                           // 0000001D8E0C: CC22003E 02004F50
	v_fma_mixlo_f16 v79, v166, s39, 0                          // 0000001D8E14: CC21004F 02004FA6
	v_fma_mixhi_f16 v79, v167, s39, 0                          // 0000001D8E1C: CC22004F 02004FA7
	v_fma_mixlo_f16 v80, v168, s39, 0                          // 0000001D8E24: CC210050 02004FA8
	v_fma_mixhi_f16 v80, v169, s39, 0                          // 0000001D8E2C: CC220050 02004FA9
	ds_load_b128 v[166:169], v129 offset:464                   // 0000001D8E34: DBFC01D0 A6000081
	s_waitcnt vmcnt(8)                                         // 0000001D8E3C: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001D8E40: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001D8E48: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001D8E50: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001D8E58: CC404011 1C469329
	ds_load_b128 v[49:52], v129 offset:8896                    // 0000001D8E60: DBFC22C0 31000081
	ds_load_b128 v[53:56], v129 offset:8912                    // 0000001D8E68: DBFC22D0 35000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D8E70: BF89FC57
	v_fma_mixlo_f16 v41, v162, s39, 0                          // 0000001D8E74: CC210029 02004FA2
	v_fma_mixhi_f16 v41, v163, s39, 0                          // 0000001D8E7C: CC220029 02004FA3
	v_fma_mixlo_f16 v42, v164, s39, 0                          // 0000001D8E84: CC21002A 02004FA4
	v_fma_mixhi_f16 v42, v165, s39, 0                          // 0000001D8E8C: CC22002A 02004FA5
	ds_load_b128 v[57:60], v129 offset:8928                    // 0000001D8E94: DBFC22E0 39000081
	ds_load_b128 v[61:64], v129 offset:8944                    // 0000001D8E9C: DBFC22F0 3D000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D8EA4: BF89FC57
	v_fma_mixlo_f16 v47, v158, s39, 0                          // 0000001D8EA8: CC21002F 02004F9E
	v_fma_mixhi_f16 v47, v159, s39, 0                          // 0000001D8EB0: CC22002F 02004F9F
	v_fma_mixlo_f16 v48, v160, s39, 0                          // 0000001D8EB8: CC210030 02004FA0
	v_fma_mixhi_f16 v48, v161, s39, 0                          // 0000001D8EC0: CC220030 02004FA1
	ds_load_b128 v[73:76], v129 offset:17344                   // 0000001D8EC8: DBFC43C0 49000081
	ds_load_b128 v[77:80], v129 offset:17360                   // 0000001D8ED0: DBFC43D0 4D000081
	ds_load_b128 v[81:84], v129 offset:17376                   // 0000001D8ED8: DBFC43E0 51000081
	ds_load_b128 v[85:88], v129 offset:17392                   // 0000001D8EE0: DBFC43F0 55000081
	ds_load_b128 v[158:161], v129 offset:25792                 // 0000001D8EE8: DBFC64C0 9E000081
	ds_load_b128 v[162:165], v129 offset:25808                 // 0000001D8EF0: DBFC64D0 A2000081
	ds_load_b128 v[181:184], v129 offset:25824                 // 0000001D8EF8: DBFC64E0 B5000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D8F00: BF89FCB7
	v_fma_mixlo_f16 v43, v166, s39, 0                          // 0000001D8F04: CC21002B 02004FA6
	v_fma_mixhi_f16 v43, v167, s39, 0                          // 0000001D8F0C: CC22002B 02004FA7
	v_fma_mixlo_f16 v44, v168, s39, 0                          // 0000001D8F14: CC21002C 02004FA8
	v_fma_mixhi_f16 v44, v169, s39, 0                          // 0000001D8F1C: CC22002C 02004FA9
	v_fma_mixlo_f16 v45, v170, s39, 0                          // 0000001D8F24: CC21002D 02004FAA
	v_fma_mixhi_f16 v45, v171, s39, 0                          // 0000001D8F2C: CC22002D 02004FAB
	v_fma_mixlo_f16 v46, v172, s39, 0                          // 0000001D8F34: CC21002E 02004FAC
	v_fma_mixhi_f16 v46, v173, s39, 0                          // 0000001D8F3C: CC22002E 02004FAD
	s_waitcnt lgkmcnt(10)                                      // 0000001D8F44: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 0000001D8F48: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 0000001D8F50: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 0000001D8F58: CC210032 02004F33
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 0000001D8F60: CC220032 02004F34
	s_waitcnt lgkmcnt(9)                                       // 0000001D8F68: BF89FC97
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001D8F6C: CC210033 02004F35
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000001D8F74: CC220033 02004F36
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001D8F7C: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000001D8F84: CC220034 02004F38
	s_waitcnt lgkmcnt(8)                                       // 0000001D8F8C: BF89FC87
	v_fma_mixlo_f16 v53, v57, s39, 0                           // 0000001D8F90: CC210035 02004F39
	v_fma_mixhi_f16 v53, v58, s39, 0                           // 0000001D8F98: CC220035 02004F3A
	v_fma_mixlo_f16 v54, v59, s39, 0                           // 0000001D8FA0: CC210036 02004F3B
	s_waitcnt lgkmcnt(7)                                       // 0000001D8FA8: BF89FC77
	v_fma_mixlo_f16 v55, v61, s39, 0                           // 0000001D8FAC: CC210037 02004F3D
	v_fma_mixhi_f16 v55, v62, s39, 0                           // 0000001D8FB4: CC220037 02004F3E
	v_fma_mixlo_f16 v56, v63, s39, 0                           // 0000001D8FBC: CC210038 02004F3F
	v_fma_mixhi_f16 v56, v64, s39, 0                           // 0000001D8FC4: CC220038 02004F40
	s_waitcnt lgkmcnt(6)                                       // 0000001D8FCC: BF89FC67
	v_fma_mixlo_f16 v57, v73, s39, 0                           // 0000001D8FD0: CC210039 02004F49
	v_fma_mixhi_f16 v57, v74, s39, 0                           // 0000001D8FD8: CC220039 02004F4A
	v_fma_mixlo_f16 v58, v75, s39, 0                           // 0000001D8FE0: CC21003A 02004F4B
	v_fma_mixhi_f16 v58, v76, s39, 0                           // 0000001D8FE8: CC22003A 02004F4C
	s_waitcnt lgkmcnt(5)                                       // 0000001D8FF0: BF89FC57
	v_fma_mixlo_f16 v59, v77, s39, 0                           // 0000001D8FF4: CC21003B 02004F4D
	s_waitcnt lgkmcnt(4)                                       // 0000001D8FFC: BF89FC47
	v_fma_mixlo_f16 v61, v81, s39, 0                           // 0000001D9000: CC21003D 02004F51
	v_fma_mixhi_f16 v61, v82, s39, 0                           // 0000001D9008: CC22003D 02004F52
	v_fma_mixlo_f16 v62, v83, s39, 0                           // 0000001D9010: CC21003E 02004F53
	v_fma_mixhi_f16 v62, v84, s39, 0                           // 0000001D9018: CC22003E 02004F54
	s_waitcnt lgkmcnt(3)                                       // 0000001D9020: BF89FC37
	v_fma_mixlo_f16 v63, v85, s39, 0                           // 0000001D9024: CC21003F 02004F55
	v_fma_mixhi_f16 v63, v86, s39, 0                           // 0000001D902C: CC22003F 02004F56
	v_fma_mixlo_f16 v64, v87, s39, 0                           // 0000001D9034: CC210040 02004F57
	v_fma_mixhi_f16 v64, v88, s39, 0                           // 0000001D903C: CC220040 02004F58
	s_waitcnt lgkmcnt(2)                                       // 0000001D9044: BF89FC27
	v_fma_mixlo_f16 v73, v158, s39, 0                          // 0000001D9048: CC210049 02004F9E
	v_fma_mixhi_f16 v73, v159, s39, 0                          // 0000001D9050: CC220049 02004F9F
	v_fma_mixlo_f16 v74, v160, s39, 0                          // 0000001D9058: CC21004A 02004FA0
	v_fma_mixhi_f16 v74, v161, s39, 0                          // 0000001D9060: CC22004A 02004FA1
	s_waitcnt lgkmcnt(1)                                       // 0000001D9068: BF89FC17
	v_fma_mixlo_f16 v75, v162, s39, 0                          // 0000001D906C: CC21004B 02004FA2
	v_fma_mixhi_f16 v75, v163, s39, 0                          // 0000001D9074: CC22004B 02004FA3
	v_fma_mixlo_f16 v76, v164, s39, 0                          // 0000001D907C: CC21004C 02004FA4
	v_fma_mixhi_f16 v76, v165, s39, 0                          // 0000001D9084: CC22004C 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D908C: BF89FC07
	v_fma_mixlo_f16 v77, v181, s39, 0                          // 0000001D9090: CC21004D 02004FB5
	ds_load_b128 v[81:84], v130                                // 0000001D9098: DBFC0000 51000082
	ds_load_b128 v[85:88], v130 offset:16                      // 0000001D90A0: DBFC0010 55000082
	ds_load_b128 v[162:165], v130 offset:2320                  // 0000001D90A8: DBFC0910 A2000082
	ds_load_b128 v[158:161], v130 offset:2304                  // 0000001D90B0: DBFC0900 9E000082
	ds_load_b128 v[170:173], v130 offset:4624                  // 0000001D90B8: DBFC1210 AA000082
	ds_load_b128 v[166:169], v130 offset:4608                  // 0000001D90C0: DBFC1200 A6000082
	ds_load_b128 v[178:181], v130 offset:6928                  // 0000001D90C8: DBFC1B10 B2000082
	ds_load_b128 v[174:177], v130 offset:6912                  // 0000001D90D0: DBFC1B00 AE000082
	v_fma_mixhi_f16 v54, v60, s39, 0                           // 0000001D90D8: CC220036 02004F3C
	v_fma_mixhi_f16 v59, v78, s39, 0                           // 0000001D90E0: CC22003B 02004F4E
	v_fma_mixlo_f16 v60, v79, s39, 0                           // 0000001D90E8: CC21003C 02004F4F
	v_fma_mixhi_f16 v60, v80, s39, 0                           // 0000001D90F0: CC22003C 02004F50
	v_fma_mixhi_f16 v77, v182, s39, 0                          // 0000001D90F8: CC22004D 02004FB6
	v_fma_mixlo_f16 v78, v183, s39, 0                          // 0000001D9100: CC21004E 02004FB7
	v_fma_mixhi_f16 v78, v184, s39, 0                          // 0000001D9108: CC22004E 02004FB8
	v_fma_mixlo_f16 v79, v185, s39, 0                          // 0000001D9110: CC21004F 02004FB9
	v_fma_mixhi_f16 v79, v186, s39, 0                          // 0000001D9118: CC22004F 02004FBA
	v_fma_mixlo_f16 v80, v187, s39, 0                          // 0000001D9120: CC210050 02004FBB
	v_fma_mixhi_f16 v80, v188, s39, 0                          // 0000001D9128: CC220050 02004FBC
	s_waitcnt vmcnt(6)                                         // 0000001D9130: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001D9134: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001D913C: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001D9144: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001D914C: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[150:157], v[81:88], v[65:72]// 0000001D9150: CC404039 1D06A396
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001D9158: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001D9160: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[150:157], v[158:165], v[65:72]// 0000001D9164: CC404031 1D073D96
	s_waitcnt lgkmcnt(2)                                       // 0000001D916C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[150:157], v[166:173], v[65:72]// 0000001D9170: CC404029 1D074D96
	s_waitcnt lgkmcnt(0)                                       // 0000001D9178: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[150:157], v[174:181], v[65:72]// 0000001D917C: CC404021 1D075D96
	s_and_saveexec_b32 s13, s5                                 // 0000001D9184: BE8D2005
	s_cbranch_execnz 735                                       // 0000001D9188: BFA602DF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6608>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D918C: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 0000001D9190: BE8D2004
	s_cbranch_execnz 768                                       // 0000001D9194: BFA60300 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6698>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9198: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 0000001D919C: BE8D2006
	s_cbranch_execnz 796                                       // 0000001D91A0: BFA6031C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6714>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91A4: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001D91A8: BE8D2000
	s_cbranch_execnz 826                                       // 0000001D91AC: BFA6033A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6798>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91B0: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001D91B4: BE8D2001
	s_cbranch_execnz 845                                       // 0000001D91B8: BFA6034D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91BC: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001D91C0: BE8D2007
	s_cbranch_execnz 864                                       // 0000001D91C4: BFA60360 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6848>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91C8: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001D91CC: BE8D2008
	s_cbranch_execnz 883                                       // 0000001D91D0: BFA60373 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68a0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91D4: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001D91D8: BE8D2009
	s_cbranch_execnz 902                                       // 0000001D91DC: BFA60386 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68f8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91E0: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001D91E4: BE8D200A
	s_cbranch_execnz 921                                       // 0000001D91E8: BFA60399 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6950>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91EC: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001D91F0: BE8D200B
	s_cbranch_execnz 940                                       // 0000001D91F4: BFA603AC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x69a8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D91F8: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001D91FC: BE8D200C
	s_cbranch_execnz 959                                       // 0000001D9200: BFA603BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a00>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9204: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001D9208: BE8D2000
	s_cbranch_execnz 977                                       // 0000001D920C: BFA603D1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a54>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9210: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001D9214: BE8D2001
	s_cbranch_execnz 996                                       // 0000001D9218: BFA603E4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6aac>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D921C: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001D9220: BE8D2007
	s_cbranch_execnz 1015                                      // 0000001D9224: BFA603F7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b04>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9228: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001D922C: BE8D2008
	s_cbranch_execnz 1034                                      // 0000001D9230: BFA6040A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b5c>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9234: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001D9238: BE8D2009
	s_cbranch_execnz 1053                                      // 0000001D923C: BFA6041D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6bb4>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9240: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001D9244: BE8D200A
	s_cbranch_execnz 1072                                      // 0000001D9248: BFA60430 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c0c>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D924C: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001D9250: BE8D200B
	s_cbranch_execnz 1091                                      // 0000001D9254: BFA60443 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c64>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9258: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001D925C: BE8D200C
	s_cbranch_execnz 1110                                      // 0000001D9260: BFA60456 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6cbc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9264: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001D9268: BE8D2000
	s_cbranch_execnz 1128                                      // 0000001D926C: BFA60468 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d10>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9270: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001D9274: BE8D2001
	s_cbranch_execnz 1147                                      // 0000001D9278: BFA6047B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d68>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D927C: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001D9280: BE8D2007
	s_cbranch_execnz 1166                                      // 0000001D9284: BFA6048E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6dc0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9288: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001D928C: BE8D2008
	s_cbranch_execnz 1185                                      // 0000001D9290: BFA604A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e18>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9294: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001D9298: BE8D2009
	s_cbranch_execnz 1204                                      // 0000001D929C: BFA604B4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e70>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D92A0: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001D92A4: BE8D200A
	s_cbranch_execnz 1223                                      // 0000001D92A8: BFA604C7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6ec8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D92AC: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001D92B0: BE8D200B
	s_cbranch_execnz 1242                                      // 0000001D92B4: BFA604DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f20>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D92B8: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001D92BC: BE8D200C
	s_cbranch_execnz 1261                                      // 0000001D92C0: BFA604ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f78>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D92C4: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001D92C8: BE8D2000
	s_cbranch_execnz 1279                                      // 0000001D92CC: BFA604FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6fcc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D92D0: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 0000001D92D4: BE802001
	s_cbranch_execnz 1298                                      // 0000001D92D8: BFA60512 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7024>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D92DC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001D92E0: BE802007
	s_cbranch_execnz 1317                                      // 0000001D92E4: BFA60525 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x707c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D92E8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001D92EC: BE802008
	s_cbranch_execnz 1336                                      // 0000001D92F0: BFA60538 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x70d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D92F4: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001D92F8: BE802009
	s_cbranch_execnz 1355                                      // 0000001D92FC: BFA6054B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x712c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D9300: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001D9304: BE80200A
	s_cbranch_execnz 1374                                      // 0000001D9308: BFA6055E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7184>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D930C: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001D9310: BE80200B
	s_cbranch_execnz 1393                                      // 0000001D9314: BFA60571 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x71dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D9318: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001D931C: BE80200C
	s_cbranch_execz 18                                         // 0000001D9320: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c6c>
	ds_load_b32 v1, v141 offset:56                             // 0000001D9324: D8D80038 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D932C: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001D9330: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v149, v[108:109]       // 0000001D9334: D6FE7C01 05B32AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9340: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001D9344: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D934C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9354: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D9358: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D9364: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D936C: 8C7E007E
	s_waitcnt vmcnt(0)                                         // 0000001D9370: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001D9374: BC7C0000
	s_barrier                                                  // 0000001D9378: BFBD0000
	buffer_gl0_inv                                             // 0000001D937C: E0AC0000 00000000
	ds_load_b128 v[1:4], v133                                  // 0000001D9384: DBFC0000 01000085
	ds_load_b128 v[5:8], v133 offset:16                        // 0000001D938C: DBFC0010 05000085
	ds_load_b128 v[25:28], v134                                // 0000001D9394: DBFC0000 19000086
	ds_load_b128 v[29:32], v134 offset:16                      // 0000001D939C: DBFC0010 1D000086
	ds_load_b128 v[9:12], v133 offset:32                       // 0000001D93A4: DBFC0020 09000085
	ds_load_b128 v[13:16], v133 offset:48                      // 0000001D93AC: DBFC0030 0D000085
	ds_load_b128 v[33:36], v134 offset:2304                    // 0000001D93B4: DBFC0900 21000086
	ds_load_b128 v[37:40], v134 offset:2320                    // 0000001D93BC: DBFC0910 25000086
	ds_load_b128 v[41:44], v134 offset:4608                    // 0000001D93C4: DBFC1200 29000086
	ds_load_b128 v[45:48], v134 offset:4624                    // 0000001D93CC: DBFC1210 2D000086
	ds_load_b128 v[49:52], v134 offset:6912                    // 0000001D93D4: DBFC1B00 31000086
	ds_load_b128 v[53:56], v134 offset:6928                    // 0000001D93DC: DBFC1B10 35000086
	ds_load_b128 v[57:60], v134 offset:9216                    // 0000001D93E4: DBFC2400 39000086
	ds_load_b128 v[61:64], v134 offset:9232                    // 0000001D93EC: DBFC2410 3D000086
	ds_load_b128 v[65:68], v134 offset:11520                   // 0000001D93F4: DBFC2D00 41000086
	ds_load_b128 v[69:72], v134 offset:11536                   // 0000001D93FC: DBFC2D10 45000086
	ds_load_b128 v[73:76], v134 offset:13824                   // 0000001D9404: DBFC3600 49000086
	ds_load_b128 v[77:80], v134 offset:13840                   // 0000001D940C: DBFC3610 4D000086
	ds_load_b128 v[81:84], v134 offset:16128                   // 0000001D9414: DBFC3F00 51000086
	ds_load_b128 v[85:88], v134 offset:16144                   // 0000001D941C: DBFC3F10 55000086
	ds_load_b128 v[89:92], v134 offset:32                      // 0000001D9424: DBFC0020 59000086
	ds_load_b128 v[93:96], v134 offset:48                      // 0000001D942C: DBFC0030 5D000086
	v_dual_mov_b32 v17, s20 :: v_dual_mov_b32 v18, s21         // 0000001D9434: CA100014 11120015
	v_dual_mov_b32 v19, s22 :: v_dual_mov_b32 v20, s23         // 0000001D943C: CA100016 13140017
	v_dual_mov_b32 v21, s24 :: v_dual_mov_b32 v22, s25         // 0000001D9444: CA100018 15160019
	v_dual_mov_b32 v23, s26 :: v_dual_mov_b32 v24, s27         // 0000001D944C: CA10001A 1718001B
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000001D9454: A200FF29 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001D945C: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001D9460: 8D01FF00 80000000
	s_rndne_f32 s7, s0                                         // 0000001D9468: BE876300
	s_waitcnt lgkmcnt(14)                                      // 0000001D946C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[142:149], v[33:40], v[1:8], v[17:24]// 0000001D9470: CC40408E 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001D9478: CC404061 1C460319
	ds_load_b128 v[25:28], v134 offset:2336                    // 0000001D9480: DBFC0920 19000086
	ds_load_b128 v[29:32], v134 offset:2352                    // 0000001D9488: DBFC0930 1D000086
	s_waitcnt lgkmcnt(14)                                      // 0000001D9490: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001D9494: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001D949C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001D94A0: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001D94A8: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001D94AC: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001D94B4: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001D94B8: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001D94C0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001D94C4: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001D94CC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001D94D0: CC404049 1C460351
	ds_load_b128 v[1:4], v134 offset:4640                      // 0000001D94D8: DBFC1220 01000086
	ds_load_b128 v[5:8], v134 offset:4656                      // 0000001D94E0: DBFC1230 05000086
	ds_load_b128 v[17:20], v134 offset:6944                    // 0000001D94E8: DBFC1B20 11000086
	ds_load_b128 v[21:24], v134 offset:6960                    // 0000001D94F0: DBFC1B30 15000086
	ds_load_b128 v[81:84], v134 offset:9248                    // 0000001D94F8: DBFC2420 51000086
	ds_load_b128 v[85:88], v134 offset:9264                    // 0000001D9500: DBFC2430 55000086
	s_waitcnt lgkmcnt(8)                                       // 0000001D9508: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001D950C: CC404061 1D861359
	s_fmamk_f32 s1, s41, 0x3fb8aa3b, s1                        // 0000001D9514: A3010129 3FB8AA3B
	s_sub_f32 s0, s0, s7                                       // 0000001D951C: A0800700
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 0000001D9520: BF4EFF29 C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001D9528: BF89FC67
	v_wmma_f32_16x16x16_f16 v[142:149], v[25:32], v[9:16], v[142:149]// 0000001D952C: CC40408E 1E3A1319
	ds_load_b128 v[25:28], v134 offset:11552                   // 0000001D9534: DBFC2D20 19000086
	ds_load_b128 v[29:32], v134 offset:11568                   // 0000001D953C: DBFC2D30 1D000086
	s_fmamk_f32 s1, s41, 0x32a5705f, s1                        // 0000001D9544: A3010129 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001D954C: BF87059B
	s_add_f32 s0, s0, s1                                       // 0000001D9550: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001D9554: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001D9558: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001D955C: CC404021 1C861301
	ds_load_b128 v[1:4], v134 offset:13856                     // 0000001D9564: DBFC3620 01000086
	ds_load_b128 v[5:8], v134 offset:13872                     // 0000001D956C: DBFC3630 05000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9574: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001D9578: CC404029 1CA61311
	ds_load_b128 v[17:20], v134 offset:16160                   // 0000001D9580: DBFC3F20 11000086
	ds_load_b128 v[21:24], v134 offset:16176                   // 0000001D9588: DBFC3F30 15000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9590: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001D9594: CC404031 1CC61351
	ds_load_b128 v[85:88], v133 offset:80                      // 0000001D959C: DBFC0050 55000085
	ds_load_b128 v[81:84], v133 offset:64                      // 0000001D95A4: DBFC0040 51000085
	s_cvt_i32_f32 s0, s7                                       // 0000001D95AC: BE806607
	s_waitcnt lgkmcnt(6)                                       // 0000001D95B0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001D95B4: CC404039 1CE61319
	ds_load_b128 v[29:32], v134 offset:80                      // 0000001D95BC: DBFC0050 1D000086
	ds_load_b128 v[25:28], v134 offset:64                      // 0000001D95C4: DBFC0040 19000086
	.long 0xd71c005b                                           // 0000001D95CC: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001D95D0: 0200015B
	s_cselect_b32 s0, -1, 0                                    // 0000001D95D4: 980080C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 0000001D95D8: BF4BFF29 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000001D95E0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001D95E4: CC404041 1D061301
	ds_load_b128 v[5:8], v134 offset:2384                      // 0000001D95EC: DBFC0950 05000086
	ds_load_b128 v[1:4], v134 offset:2368                      // 0000001D95F4: DBFC0940 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D95FC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001D9600: CC404049 1D261311
	ds_load_b128 v[13:16], v134 offset:4688                    // 0000001D9608: DBFC1250 0D000086
	ds_load_b128 v[9:12], v134 offset:4672                     // 0000001D9610: DBFC1240 09000086
	ds_load_b128 v[21:24], v134 offset:6992                    // 0000001D9618: DBFC1B50 15000086
	ds_load_b128 v[17:20], v134 offset:6976                    // 0000001D9620: DBFC1B40 11000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9628: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001D962C: CC404061 1D86A319
	ds_load_b128 v[29:32], v134 offset:9296                    // 0000001D9634: DBFC2450 1D000086
	ds_load_b128 v[25:28], v134 offset:9280                    // 0000001D963C: DBFC2440 19000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9644: BF89FC67
	v_wmma_f32_16x16x16_f16 v[142:149], v[1:8], v[81:88], v[142:149]// 0000001D9648: CC40408E 1E3AA301
	ds_load_b128 v[5:8], v134 offset:11600                     // 0000001D9650: DBFC2D50 05000086
	ds_load_b128 v[1:4], v134 offset:11584                     // 0000001D9658: DBFC2D40 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9660: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001D9664: CC404021 1C86A309
	ds_load_b128 v[13:16], v134 offset:13904                   // 0000001D966C: DBFC3650 0D000086
	ds_load_b128 v[9:12], v134 offset:13888                    // 0000001D9674: DBFC3640 09000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D967C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001D9680: CC404029 1CA6A311
	ds_load_b128 v[21:24], v134 offset:16208                   // 0000001D9688: DBFC3F50 15000086
	ds_load_b128 v[17:20], v134 offset:16192                   // 0000001D9690: DBFC3F40 11000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9698: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001D969C: CC404031 1CC6A319
	ds_load_b128 v[29:32], v133 offset:112                     // 0000001D96A4: DBFC0070 1D000085
	ds_load_b128 v[25:28], v133 offset:96                      // 0000001D96AC: DBFC0060 19000085
	s_waitcnt lgkmcnt(6)                                       // 0000001D96B4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001D96B8: CC404039 1CE6A301
	ds_load_b128 v[5:8], v134 offset:112                       // 0000001D96C0: DBFC0070 05000086
	ds_load_b128 v[1:4], v134 offset:96                        // 0000001D96C8: DBFC0060 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D96D0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001D96D4: CC404041 1D06A309
	ds_load_b128 v[13:16], v134 offset:2416                    // 0000001D96DC: DBFC0970 0D000086
	ds_load_b128 v[9:12], v134 offset:2400                     // 0000001D96E4: DBFC0960 09000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D96EC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001D96F0: CC404049 1D26A311
	ds_load_b128 v[21:24], v134 offset:4720                    // 0000001D96F8: DBFC1270 15000086
	ds_load_b128 v[17:20], v134 offset:4704                    // 0000001D9700: DBFC1260 11000086
	ds_load_b128 v[85:88], v134 offset:7024                    // 0000001D9708: DBFC1B70 55000086
	ds_load_b128 v[81:84], v134 offset:7008                    // 0000001D9710: DBFC1B60 51000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9718: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001D971C: CC404061 1D863301
	ds_load_b128 v[5:8], v134 offset:9328                      // 0000001D9724: DBFC2470 05000086
	ds_load_b128 v[1:4], v134 offset:9312                      // 0000001D972C: DBFC2460 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D9734: BF89FC67
	v_wmma_f32_16x16x16_f16 v[142:149], v[9:16], v[25:32], v[142:149]// 0000001D9738: CC40408E 1E3A3309
	ds_load_b128 v[13:16], v134 offset:11632                   // 0000001D9740: DBFC2D70 0D000086
	ds_load_b128 v[9:12], v134 offset:11616                    // 0000001D9748: DBFC2D60 09000086
	ds_load_2addr_b32 v[89:90], v135 offset1:2                 // 0000001D9750: D8DC0200 59000087
	s_waitcnt lgkmcnt(7)                                       // 0000001D9758: BF89FC77
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001D975C: CC404021 1C863311
	ds_load_b128 v[21:24], v134 offset:13936                   // 0000001D9764: DBFC3670 15000086
	ds_load_b128 v[17:20], v134 offset:13920                   // 0000001D976C: DBFC3660 11000086
	s_waitcnt lgkmcnt(7)                                       // 0000001D9774: BF89FC77
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001D9778: CC404029 1CA63351
	ds_load_b128 v[85:88], v134 offset:16240                   // 0000001D9780: DBFC3F70 55000086
	ds_load_b128 v[81:84], v134 offset:16224                   // 0000001D9788: DBFC3F60 51000086
	s_waitcnt lgkmcnt(7)                                       // 0000001D9790: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001D9794: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v135 offset0:4 offset1:6         // 0000001D979C: D8DC0604 01000087
	ds_load_2addr_b32 v[3:4], v135 offset0:8 offset1:10        // 0000001D97A4: D8DC0A08 03000087
	ds_load_2addr_b32 v[5:6], v135 offset0:12 offset1:14       // 0000001D97AC: D8DC0E0C 05000087
	ds_load_2addr_b32 v[7:8], v135 offset0:16 offset1:18       // 0000001D97B4: D8DC1210 07000087
	s_waitcnt lgkmcnt(9)                                       // 0000001D97BC: BF89FC97
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001D97C0: CC404039 1CE63309
	ds_load_2addr_b32 v[9:10], v135 offset0:20 offset1:22      // 0000001D97C8: D8DC1614 09000087
	ds_load_2addr_b32 v[11:12], v135 offset0:24 offset1:26     // 0000001D97D0: D8DC1A18 0B000087
	ds_load_2addr_b32 v[13:14], v135 offset0:28 offset1:30     // 0000001D97D8: D8DC1E1C 0D000087
	s_waitcnt lgkmcnt(9)                                       // 0000001D97E0: BF89FC97
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001D97E4: CC404041 1D063311
	s_waitcnt lgkmcnt(7)                                       // 0000001D97EC: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001D97F0: CC404049 1D263351
	v_cndmask_b32_e64 v31, 0, v91, s0                          // 0000001D97F8: D501001F 0002B680
	s_cselect_b32 s0, -1, 0                                    // 0000001D9800: 980080C1
	ds_load_2addr_b32 v[15:16], v135 offset0:32 offset1:34     // 0000001D9804: D8DC2220 0F000087
	ds_load_2addr_b32 v[17:18], v135 offset0:36 offset1:38     // 0000001D980C: D8DC2624 11000087
	ds_load_2addr_b32 v[19:20], v135 offset0:40 offset1:42     // 0000001D9814: D8DC2A28 13000087
	ds_load_2addr_b32 v[21:22], v135 offset0:44 offset1:46     // 0000001D981C: D8DC2E2C 15000087
	ds_load_2addr_b32 v[23:24], v135 offset0:48 offset1:50     // 0000001D9824: D8DC3230 17000087
	v_cndmask_b32_e64 v91, 0x7f800000, v31, s0                 // 0000001D982C: D501005B 00023EFF 7F800000
	ds_load_2addr_b32 v[25:26], v135 offset0:52 offset1:54     // 0000001D9838: D8DC3634 19000087
	ds_load_2addr_b32 v[27:28], v135 offset0:56 offset1:58     // 0000001D9840: D8DC3A38 1B000087
	ds_load_2addr_b32 v[29:30], v135 offset0:60 offset1:62     // 0000001D9848: D8DC3E3C 1D000087
	ds_load_2addr_b32 v[31:32], v135 offset0:64 offset1:66     // 0000001D9850: D8DC4240 1F000087
	ds_load_2addr_b32 v[81:82], v135 offset0:68 offset1:70     // 0000001D9858: D8DC4644 51000087
	ds_load_2addr_b32 v[83:84], v135 offset0:72 offset1:74     // 0000001D9860: D8DC4A48 53000087
	ds_load_2addr_b32 v[85:86], v135 offset0:76 offset1:78     // 0000001D9868: D8DC4E4C 55000087
	s_cmp_lg_u32 s40, s36                                      // 0000001D9870: BF072428
	v_mul_f32_e32 v90, v91, v90                                // 0000001D9874: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001D9878: 10B2B35B
	s_waitcnt lgkmcnt(18)                                      // 0000001D987C: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001D9880: 10BA055B
	s_waitcnt lgkmcnt(16)                                      // 0000001D9884: BF89FD07
	v_mul_f32_e32 v105, v91, v6                                // 0000001D9888: 10D20D5B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001D988C: 10B8035B
	v_mul_f32_e32 v95, v91, v4                                 // 0000001D9890: 10BE095B
	v_mul_f32_e32 v94, v91, v3                                 // 0000001D9894: 10BC075B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D9898: BF870004
	v_dual_mul_f32 v96, v91, v5 :: v_dual_fmac_f32 v105, 0x3b800000, v104// 0000001D989C: C8C00B5B 6068D0FF 3B800000
	v_dual_fmac_f32 v90, 0x3b800000, v98 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001D98A8: C800C4FF 5A58C2FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001D98B4: BF89FCE7
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_mul_f32 v100, v91, v10// 0000001D98B8: C806C8FF 5D64155B 3B800000
	v_mul_f32_e32 v97, v91, v7                                 // 0000001D98C4: 10C20F5B
	s_waitcnt lgkmcnt(12)                                      // 0000001D98C8: BF89FCC7
	v_mul_f32_e32 v104, v91, v14                               // 0000001D98CC: 10D01D5B
	v_dual_fmac_f32 v92, 0x3b800000, v99 :: v_dual_fmac_f32 v95, 0x3b800000, v102// 0000001D98D0: C800C6FF 5C5ECCFF 3B800000
	v_dual_fmac_f32 v94, 0x3b800000, v101 :: v_dual_mul_f32 v101, v91, v11// 0000001D98DC: C806CAFF 5E64175B 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D98E8: BF870003
	v_fmac_f32_e32 v104, 0x3b800000, v149                      // 0000001D98EC: 56D12AFF 3B800000
	v_mul_f32_e32 v102, v91, v12                               // 0000001D98F4: 10CC195B
	v_fmac_f32_e32 v100, 0x3b800000, v145                      // 0000001D98F8: 56C922FF 3B800000
	v_dual_mul_f32 v98, v91, v8 :: v_dual_fmac_f32 v97, 0x3b800000, v142// 0000001D9900: C8C0115B 62611CFF 3B800000
	v_dual_mul_f32 v99, v91, v9 :: v_dual_fmac_f32 v96, 0x3b800000, v103// 0000001D990C: C8C0135B 6360CEFF 3B800000
	ds_load_2addr_b32 v[1:2], v135 offset0:80 offset1:82       // 0000001D9918: D8DC5250 01000087
	ds_load_2addr_b32 v[3:4], v135 offset0:84 offset1:86       // 0000001D9920: D8DC5654 03000087
	ds_load_2addr_b32 v[5:6], v135 offset0:88 offset1:90       // 0000001D9928: D8DC5A58 05000087
	ds_load_2addr_b32 v[87:88], v135 offset0:92 offset1:94     // 0000001D9930: D8DC5E5C 57000087
	v_dual_fmac_f32 v98, 0x3b800000, v143 :: v_dual_fmac_f32 v101, 0x3b800000, v146// 0000001D9938: C8011EFF 626524FF 3B800000
	v_dual_mul_f32 v103, v91, v13 :: v_dual_fmac_f32 v102, 0x3b800000, v147// 0000001D9944: C8C01B5B 676726FF 3B800000
	v_fmac_f32_e32 v99, 0x3b800000, v144                       // 0000001D9950: 56C720FF 3B800000
	ds_load_2addr_b32 v[7:8], v135 offset0:96 offset1:98       // 0000001D9958: D8DC6260 07000087
	ds_load_2addr_b32 v[9:10], v135 offset0:100 offset1:102    // 0000001D9960: D8DC6664 09000087
	ds_load_2addr_b32 v[11:12], v135 offset0:104 offset1:106   // 0000001D9968: D8DC6A68 0B000087
	ds_load_2addr_b32 v[13:14], v135 offset0:108 offset1:110   // 0000001D9970: D8DC6E6C 0D000087
	s_waitcnt lgkmcnt(19)                                      // 0000001D9978: BF89FD37
	v_mul_f32_e32 v117, v91, v16                               // 0000001D997C: 10EA215B
	v_mul_f32_e32 v116, v91, v15                               // 0000001D9980: 10E81F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001D9984: BF89FD27
	v_mul_f32_e32 v143, v91, v18                               // 0000001D9988: 111E255B
	v_mul_f32_e32 v142, v91, v17                               // 0000001D998C: 111C235B
	s_waitcnt lgkmcnt(17)                                      // 0000001D9990: BF89FD17
	v_mul_f32_e32 v145, v91, v20                               // 0000001D9994: 1122295B
	v_mul_f32_e32 v144, v91, v19                               // 0000001D9998: 1120275B
	s_waitcnt lgkmcnt(16)                                      // 0000001D999C: BF89FD07
	v_mul_f32_e32 v147, v91, v22                               // 0000001D99A0: 11262D5B
	v_mul_f32_e32 v146, v91, v21                               // 0000001D99A4: 11242B5B
	ds_load_2addr_b32 v[15:16], v135 offset0:112 offset1:114   // 0000001D99A8: D8DC7270 0F000087
	ds_load_2addr_b32 v[17:18], v135 offset0:116 offset1:118   // 0000001D99B0: D8DC7674 11000087
	ds_load_2addr_b32 v[19:20], v135 offset0:120 offset1:122   // 0000001D99B8: D8DC7A78 13000087
	ds_load_2addr_b32 v[21:22], v135 offset0:124 offset1:126   // 0000001D99C0: D8DC7E7C 15000087
	v_dual_fmac_f32 v117, 0x3b800000, v34 :: v_dual_fmac_f32 v116, 0x3b800000, v33// 0000001D99C8: C80044FF 757442FF 3B800000
	v_dual_fmac_f32 v143, 0x3b800000, v36 :: v_dual_fmac_f32 v142, 0x3b800000, v35// 0000001D99D4: C80048FF 8F8E46FF 3B800000
	v_dual_fmac_f32 v145, 0x3b800000, v38 :: v_dual_fmac_f32 v144, 0x3b800000, v37// 0000001D99E0: C8004CFF 91904AFF 3B800000
	v_dual_fmac_f32 v147, 0x3b800000, v40 :: v_dual_fmac_f32 v146, 0x3b800000, v39// 0000001D99EC: C80050FF 93924EFF 3B800000
	s_waitcnt lgkmcnt(19)                                      // 0000001D99F8: BF89FD37
	v_mul_f32_e32 v24, v91, v24                                // 0000001D99FC: 1030315B
	v_mul_f32_e32 v23, v91, v23                                // 0000001D9A00: 102E2F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001D9A04: BF89FD27
	v_mul_f32_e32 v26, v91, v26                                // 0000001D9A08: 1034355B
	v_mul_f32_e32 v25, v91, v25                                // 0000001D9A0C: 1032335B
	s_waitcnt lgkmcnt(17)                                      // 0000001D9A10: BF89FD17
	v_mul_f32_e32 v28, v91, v28                                // 0000001D9A14: 1038395B
	v_mul_f32_e32 v27, v91, v27                                // 0000001D9A18: 1036375B
	s_waitcnt lgkmcnt(16)                                      // 0000001D9A1C: BF89FD07
	v_mul_f32_e32 v30, v91, v30                                // 0000001D9A20: 103C3D5B
	v_mul_f32_e32 v29, v91, v29                                // 0000001D9A24: 103A3B5B
	s_waitcnt lgkmcnt(15)                                      // 0000001D9A28: BF89FCF7
	v_mul_f32_e32 v32, v91, v32                                // 0000001D9A2C: 1040415B
	v_mul_f32_e32 v31, v91, v31                                // 0000001D9A30: 103E3F5B
	s_waitcnt lgkmcnt(14)                                      // 0000001D9A34: BF89FCE7
	v_mul_f32_e32 v34, v91, v82                                // 0000001D9A38: 1044A55B
	v_mul_f32_e32 v33, v91, v81                                // 0000001D9A3C: 1042A35B
	s_waitcnt lgkmcnt(13)                                      // 0000001D9A40: BF89FCD7
	v_mul_f32_e32 v36, v91, v84                                // 0000001D9A44: 1048A95B
	v_mul_f32_e32 v35, v91, v83                                // 0000001D9A48: 1046A75B
	s_waitcnt lgkmcnt(12)                                      // 0000001D9A4C: BF89FCC7
	v_mul_f32_e32 v38, v91, v86                                // 0000001D9A50: 104CAD5B
	v_mul_f32_e32 v37, v91, v85                                // 0000001D9A54: 104AAB5B
	s_waitcnt lgkmcnt(11)                                      // 0000001D9A58: BF89FCB7
	v_mul_f32_e32 v2, v91, v2                                  // 0000001D9A5C: 1004055B
	v_mul_f32_e32 v1, v91, v1                                  // 0000001D9A60: 1002035B
	s_waitcnt lgkmcnt(10)                                      // 0000001D9A64: BF89FCA7
	v_mul_f32_e32 v4, v91, v4                                  // 0000001D9A68: 1008095B
	v_mul_f32_e32 v3, v91, v3                                  // 0000001D9A6C: 1006075B
	s_waitcnt lgkmcnt(9)                                       // 0000001D9A70: BF89FC97
	v_mul_f32_e32 v6, v91, v6                                  // 0000001D9A74: 100C0D5B
	v_mul_f32_e32 v5, v91, v5                                  // 0000001D9A78: 100A0B5B
	s_waitcnt lgkmcnt(8)                                       // 0000001D9A7C: BF89FC87
	v_mul_f32_e32 v40, v91, v88                                // 0000001D9A80: 1050B15B
	v_mul_f32_e32 v39, v91, v87                                // 0000001D9A84: 104EAF5B
	s_waitcnt lgkmcnt(7)                                       // 0000001D9A88: BF89FC77
	v_mul_f32_e32 v8, v91, v8                                  // 0000001D9A8C: 1010115B
	v_mul_f32_e32 v7, v91, v7                                  // 0000001D9A90: 100E0F5B
	s_waitcnt lgkmcnt(6)                                       // 0000001D9A94: BF89FC67
	v_mul_f32_e32 v10, v91, v10                                // 0000001D9A98: 1014155B
	v_mul_f32_e32 v9, v91, v9                                  // 0000001D9A9C: 1012135B
	s_waitcnt lgkmcnt(5)                                       // 0000001D9AA0: BF89FC57
	v_mul_f32_e32 v12, v91, v12                                // 0000001D9AA4: 1018195B
	v_mul_f32_e32 v11, v91, v11                                // 0000001D9AA8: 1016175B
	s_waitcnt lgkmcnt(4)                                       // 0000001D9AAC: BF89FC47
	v_mul_f32_e32 v14, v91, v14                                // 0000001D9AB0: 101C1D5B
	v_mul_f32_e32 v13, v91, v13                                // 0000001D9AB4: 101A1B5B
	s_waitcnt lgkmcnt(3)                                       // 0000001D9AB8: BF89FC37
	v_mul_f32_e32 v16, v91, v16                                // 0000001D9ABC: 1020215B
	v_mul_f32_e32 v15, v91, v15                                // 0000001D9AC0: 101E1F5B
	s_waitcnt lgkmcnt(2)                                       // 0000001D9AC4: BF89FC27
	v_mul_f32_e32 v18, v91, v18                                // 0000001D9AC8: 1024255B
	v_mul_f32_e32 v17, v91, v17                                // 0000001D9ACC: 1022235B
	s_waitcnt lgkmcnt(1)                                       // 0000001D9AD0: BF89FC17
	v_mul_f32_e32 v20, v91, v20                                // 0000001D9AD4: 1028295B
	v_mul_f32_e32 v19, v91, v19                                // 0000001D9AD8: 1026275B
	s_waitcnt lgkmcnt(0)                                       // 0000001D9ADC: BF89FC07
	v_mul_f32_e32 v22, v91, v22                                // 0000001D9AE0: 102C2D5B
	v_mul_f32_e32 v21, v91, v21                                // 0000001D9AE4: 102A2B5B
	v_dual_fmac_f32 v103, 0x3b800000, v148 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001D9AE8: C80128FF 671854FF 3B800000
	v_dual_fmac_f32 v23, 0x3b800000, v41 :: v_dual_fmac_f32 v26, 0x3b800000, v44// 0000001D9AF4: C80052FF 171A58FF 3B800000
	v_dual_fmac_f32 v25, 0x3b800000, v43 :: v_dual_fmac_f32 v28, 0x3b800000, v46// 0000001D9B00: C80056FF 191C5CFF 3B800000
	v_dual_fmac_f32 v27, 0x3b800000, v45 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001D9B0C: C8005AFF 1B1E60FF 3B800000
	v_dual_fmac_f32 v29, 0x3b800000, v47 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001D9B18: C8005EFF 1D2064FF 3B800000
	v_dual_fmac_f32 v31, 0x3b800000, v49 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001D9B24: C80062FF 1F2268FF 3B800000
	v_dual_fmac_f32 v33, 0x3b800000, v51 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001D9B30: C80066FF 21246CFF 3B800000
	v_dual_fmac_f32 v35, 0x3b800000, v53 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001D9B3C: C8006AFF 232670FF 3B800000
	v_dual_fmac_f32 v37, 0x3b800000, v55 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001D9B48: C8006EFF 250274FF 3B800000
	v_dual_fmac_f32 v1, 0x3b800000, v57 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001D9B54: C80072FF 010478FF 3B800000
	v_dual_fmac_f32 v3, 0x3b800000, v59 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001D9B60: C80076FF 03067CFF 3B800000
	v_dual_fmac_f32 v5, 0x3b800000, v61 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001D9B6C: C8007AFF 052880FF 3B800000
	v_dual_fmac_f32 v39, 0x3b800000, v63 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001D9B78: C8007EFF 270884FF 3B800000
	v_dual_fmac_f32 v7, 0x3b800000, v65 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001D9B84: C80082FF 070A88FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v67 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001D9B90: C80086FF 090C8CFF 3B800000
	v_dual_fmac_f32 v11, 0x3b800000, v69 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001D9B9C: C8008AFF 0B0E90FF 3B800000
	v_dual_fmac_f32 v13, 0x3b800000, v71 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001D9BA8: C8008EFF 0D1094FF 3B800000
	v_dual_fmac_f32 v15, 0x3b800000, v73 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001D9BB4: C80092FF 0F1298FF 3B800000
	v_dual_fmac_f32 v17, 0x3b800000, v75 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001D9BC0: C80096FF 11149CFF 3B800000
	v_dual_fmac_f32 v19, 0x3b800000, v77 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001D9BCC: C8009AFF 1316A0FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001D9BD8: 562A9EFF 3B800000
	ds_store_2addr_b32 v135, v89, v90 offset1:2                // 0000001D9BE0: D8380200 005A5987
	ds_store_2addr_b32 v135, v92, v93 offset0:4 offset1:6      // 0000001D9BE8: D8380604 005D5C87
	ds_store_2addr_b32 v135, v94, v95 offset0:8 offset1:10     // 0000001D9BF0: D8380A08 005F5E87
	ds_store_2addr_b32 v135, v96, v105 offset0:12 offset1:14   // 0000001D9BF8: D8380E0C 00696087
	ds_store_2addr_b32 v135, v97, v98 offset0:16 offset1:18    // 0000001D9C00: D8381210 00626187
	ds_store_2addr_b32 v135, v99, v100 offset0:20 offset1:22   // 0000001D9C08: D8381614 00646387
	ds_store_2addr_b32 v135, v101, v102 offset0:24 offset1:26  // 0000001D9C10: D8381A18 00666587
	ds_store_2addr_b32 v135, v103, v104 offset0:28 offset1:30  // 0000001D9C18: D8381E1C 00686787
	ds_store_2addr_b32 v135, v116, v117 offset0:32 offset1:34  // 0000001D9C20: D8382220 00757487
	ds_store_2addr_b32 v135, v142, v143 offset0:36 offset1:38  // 0000001D9C28: D8382624 008F8E87
	ds_store_2addr_b32 v135, v144, v145 offset0:40 offset1:42  // 0000001D9C30: D8382A28 00919087
	ds_store_2addr_b32 v135, v146, v147 offset0:44 offset1:46  // 0000001D9C38: D8382E2C 00939287
	ds_store_2addr_b32 v135, v23, v24 offset0:48 offset1:50    // 0000001D9C40: D8383230 00181787
	ds_store_2addr_b32 v135, v25, v26 offset0:52 offset1:54    // 0000001D9C48: D8383634 001A1987
	ds_store_2addr_b32 v135, v27, v28 offset0:56 offset1:58    // 0000001D9C50: D8383A38 001C1B87
	ds_store_2addr_b32 v135, v29, v30 offset0:60 offset1:62    // 0000001D9C58: D8383E3C 001E1D87
	ds_store_2addr_b32 v135, v31, v32 offset0:64 offset1:66    // 0000001D9C60: D8384240 00201F87
	ds_store_2addr_b32 v135, v33, v34 offset0:68 offset1:70    // 0000001D9C68: D8384644 00222187
	ds_store_2addr_b32 v135, v35, v36 offset0:72 offset1:74    // 0000001D9C70: D8384A48 00242387
	ds_store_2addr_b32 v135, v37, v38 offset0:76 offset1:78    // 0000001D9C78: D8384E4C 00262587
	ds_store_2addr_b32 v135, v1, v2 offset0:80 offset1:82      // 0000001D9C80: D8385250 00020187
	ds_store_2addr_b32 v135, v3, v4 offset0:84 offset1:86      // 0000001D9C88: D8385654 00040387
	ds_store_2addr_b32 v135, v5, v6 offset0:88 offset1:90      // 0000001D9C90: D8385A58 00060587
	ds_store_2addr_b32 v135, v39, v40 offset0:92 offset1:94    // 0000001D9C98: D8385E5C 00282787
	ds_store_2addr_b32 v135, v7, v8 offset0:96 offset1:98      // 0000001D9CA0: D8386260 00080787
	ds_store_2addr_b32 v135, v9, v10 offset0:100 offset1:102   // 0000001D9CA8: D8386664 000A0987
	ds_store_2addr_b32 v135, v11, v12 offset0:104 offset1:106  // 0000001D9CB0: D8386A68 000C0B87
	ds_store_2addr_b32 v135, v13, v14 offset0:108 offset1:110  // 0000001D9CB8: D8386E6C 000E0D87
	ds_store_2addr_b32 v135, v15, v16 offset0:112 offset1:114  // 0000001D9CC0: D8387270 00100F87
	ds_store_2addr_b32 v135, v17, v18 offset0:116 offset1:118  // 0000001D9CC8: D8387674 00121187
	ds_store_2addr_b32 v135, v19, v20 offset0:120 offset1:122  // 0000001D9CD0: D8387A78 00141387
	ds_store_2addr_b32 v135, v21, v22 offset0:124 offset1:126  // 0000001D9CD8: D8387E7C 00161587
	s_waitcnt lgkmcnt(0)                                       // 0000001D9CE0: BF89FC07
	s_barrier                                                  // 0000001D9CE4: BFBD0000
	buffer_gl0_inv                                             // 0000001D9CE8: E0AC0000 00000000
	s_cbranch_scc0 785                                         // 0000001D9CF0: BFA10311 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7238>
	s_cmp_lg_u32 s40, s37                                      // 0000001D9CF4: BF072528
	s_cbranch_scc0 824                                         // 0000001D9CF8: BFA10338 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72dc>
	s_cmp_lg_u32 s40, s38                                      // 0000001D9CFC: BF072628
	s_cbranch_scc1 59260                                       // 0000001D9D00: BFA2E77C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f4>
	s_branch 853                                               // 0000001D9D04: BFA00355 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x735c>
	s_clause 0x1                                               // 0000001D9D08: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 0000001D9D0C: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 0000001D9D14: DC5E0020 417C0074
	ds_load_b128 v[73:76], v130 offset:32                      // 0000001D9D1C: DBFC0020 49000082
	ds_load_b128 v[77:80], v130 offset:48                      // 0000001D9D24: DBFC0030 4D000082
	ds_load_b128 v[85:88], v130 offset:2352                    // 0000001D9D2C: DBFC0930 55000082
	ds_load_b128 v[81:84], v130 offset:2336                    // 0000001D9D34: DBFC0920 51000082
	ds_load_b128 v[154:157], v130 offset:4656                  // 0000001D9D3C: DBFC1230 9A000082
	ds_load_b128 v[150:153], v130 offset:4640                  // 0000001D9D44: DBFC1220 96000082
	ds_load_b128 v[162:165], v130 offset:6960                  // 0000001D9D4C: DBFC1B30 A2000082
	ds_load_b128 v[158:161], v130 offset:6944                  // 0000001D9D54: DBFC1B20 9E000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001D9D5C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001D9D60: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001D9D68: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001D9D6C: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001D9D74: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[150:157], v[41:48]// 0000001D9D78: CC404029 1CA72D41
	s_waitcnt lgkmcnt(0)                                       // 0000001D9D80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[158:165], v[33:40]// 0000001D9D84: CC404021 1C873D41
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9D8C: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 0000001D9D90: BE8D2004
	s_cbranch_execz 64768                                      // 0000001D9D94: BFA5FD00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a98>
	ds_load_b128 v[65:68], v130 offset:64                      // 0000001D9D98: DBFC0040 41000082
	ds_load_b128 v[69:72], v130 offset:80                      // 0000001D9DA0: DBFC0050 45000082
	ds_load_b128 v[77:80], v130 offset:2384                    // 0000001D9DA8: DBFC0950 4D000082
	ds_load_b128 v[73:76], v130 offset:2368                    // 0000001D9DB0: DBFC0940 49000082
	ds_load_b128 v[85:88], v130 offset:4688                    // 0000001D9DB8: DBFC1250 55000082
	ds_load_b128 v[81:84], v130 offset:4672                    // 0000001D9DC0: DBFC1240 51000082
	ds_load_b128 v[154:157], v130 offset:6992                  // 0000001D9DC8: DBFC1B50 9A000082
	ds_load_b128 v[150:153], v130 offset:6976                  // 0000001D9DD0: DBFC1B40 96000082
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001D9DD8: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001D9DDC: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001D9DE4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001D9DE8: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001D9DF0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001D9DF4: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001D9DFC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[150:157], v[33:40]// 0000001D9E00: CC404021 1C872D61
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9E08: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 0000001D9E0C: BE8D2006
	s_cbranch_execz 64740                                      // 0000001D9E10: BFA5FCE4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5aa4>
	ds_load_b128 v[65:68], v130 offset:96                      // 0000001D9E14: DBFC0060 41000082
	ds_load_b128 v[69:72], v130 offset:112                     // 0000001D9E1C: DBFC0070 45000082
	ds_load_b128 v[77:80], v130 offset:2416                    // 0000001D9E24: DBFC0970 4D000082
	ds_load_b128 v[73:76], v130 offset:2400                    // 0000001D9E2C: DBFC0960 49000082
	ds_load_b128 v[85:88], v130 offset:4720                    // 0000001D9E34: DBFC1270 55000082
	ds_load_b128 v[81:84], v130 offset:4704                    // 0000001D9E3C: DBFC1260 51000082
	s_waitcnt vmcnt(3)                                         // 0000001D9E44: BF890FF7
	ds_load_b128 v[101:104], v130 offset:7024                  // 0000001D9E48: DBFC1B70 65000082
	s_waitcnt vmcnt(2)                                         // 0000001D9E50: BF890BF7
	ds_load_b128 v[97:100], v130 offset:7008                   // 0000001D9E54: DBFC1B60 61000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001D9E5C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001D9E60: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001D9E68: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001D9E6C: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001D9E74: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001D9E78: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001D9E80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001D9E84: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9E8C: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001D9E90: BE8D2000
	s_cbranch_execz 64710                                      // 0000001D9E94: BFA5FCC6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ab0>
	ds_load_b32 v65, v141                                      // 0000001D9E98: D8D80000 4100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D9EA0: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001D9EA4: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v142, v[108:109]     // 0000001D9EAC: D6FE7C41 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9EB8: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001D9EBC: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001D9EC4: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9ECC: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001D9ED0: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001D9EDC: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9EE4: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001D9EE8: BE8D2001
	s_cbranch_execz 64691                                      // 0000001D9EEC: BFA5FCB3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5abc>
	ds_load_b32 v25, v141 offset:8                             // 0000001D9EF0: D8D80008 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D9EF8: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001D9EFC: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D9F04: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001D9F08: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v143, v[108:109]     // 0000001D9F10: D6FE7C19 05B31EFF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001D9F1C: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9F24: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001D9F28: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001D9F34: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9F3C: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001D9F40: BE8D2007
	s_cbranch_execz 64672                                      // 0000001D9F44: BFA5FCA0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ac8>
	ds_load_b32 v25, v141 offset:16                            // 0000001D9F48: D8D80010 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D9F50: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001D9F54: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D9F5C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D9F60: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v144, v[108:109]     // 0000001D9F68: D6FE7C19 05B320FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001D9F74: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9F7C: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001D9F80: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D9F8C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9F94: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001D9F98: BE8D2008
	s_cbranch_execz 64653                                      // 0000001D9F9C: BFA5FC8D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ad4>
	ds_load_b32 v25, v141 offset:24                            // 0000001D9FA0: D8D80018 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D9FA8: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001D9FAC: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D9FB4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D9FB8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v145, v[108:109]     // 0000001D9FC0: D6FE7C19 05B322FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D9FCC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9FD4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D9FD8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D9FE4: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001D9FEC: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001D9FF0: BE8D2009
	s_cbranch_execz 64634                                      // 0000001D9FF4: BFA5FC7A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ae0>
	ds_load_b32 v25, v141 offset:32                            // 0000001D9FF8: D8D80020 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA000: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001DA004: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA00C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001DA010: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v146, v[108:109]     // 0000001DA018: D6FE7C19 05B324FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001DA024: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA02C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001DA030: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001DA03C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA044: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001DA048: BE8D200A
	s_cbranch_execz 64615                                      // 0000001DA04C: BFA5FC67 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5aec>
	ds_load_b32 v25, v141 offset:40                            // 0000001DA050: D8D80028 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA058: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001DA05C: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA064: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001DA068: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v147, v[108:109]     // 0000001DA070: D6FE7C19 05B326FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001DA07C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA084: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001DA088: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001DA094: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA09C: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001DA0A0: BE8D200B
	s_cbranch_execz 64596                                      // 0000001DA0A4: BFA5FC54 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5af8>
	ds_load_b32 v25, v141 offset:48                            // 0000001DA0A8: D8D80030 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA0B0: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001DA0B4: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA0BC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001DA0C0: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v148, v[108:109]     // 0000001DA0C8: D6FE7C19 05B328FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001DA0D4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA0DC: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001DA0E0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001DA0EC: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA0F4: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001DA0F8: BE8D200C
	s_cbranch_execz 64577                                      // 0000001DA0FC: BFA5FC41 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b04>
	ds_load_b32 v25, v141 offset:56                            // 0000001DA100: D8D80038 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA108: BF89FC07
	v_fmac_f32_e32 v64, v32, v25                               // 0000001DA10C: 56803320
	v_mad_u64_u32 v[25:26], null, 0x3000, v149, v[108:109]     // 0000001DA110: D6FE7C19 05B32AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DA11C: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v64                         // 0000001DA120: 103680FF 3B800000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001DA128: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA130: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001DA134: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001DA140: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA148: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001DA14C: BE8D2000
	s_cbranch_execz 64559                                      // 0000001DA150: BFA5FC2F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b10>
	ds_load_b32 v25, v141                                      // 0000001DA154: D8D80000 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA15C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001DA160: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v142, v[108:109]     // 0000001DA168: D6FE7C19 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DA174: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001DA178: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001DA180: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA188: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001DA18C: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001DA198: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA1A0: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001DA1A4: BE8D2001
	s_cbranch_execz 64540                                      // 0000001DA1A8: BFA5FC1C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b1c>
	ds_load_b32 v9, v141 offset:8                              // 0000001DA1AC: D8D80008 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA1B4: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001DA1B8: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA1C0: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001DA1C4: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v143, v[108:109]      // 0000001DA1CC: D6FE7C09 05B31EFF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001DA1D8: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA1E0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001DA1E4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001DA1F0: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA1F8: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001DA1FC: BE8D2007
	s_cbranch_execz 64521                                      // 0000001DA200: BFA5FC09 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b28>
	ds_load_b32 v9, v141 offset:16                             // 0000001DA204: D8D80010 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA20C: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001DA210: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA218: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA21C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v144, v[108:109]      // 0000001DA224: D6FE7C09 05B320FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001DA230: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA238: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001DA23C: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA248: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA250: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001DA254: BE8D2008
	s_cbranch_execz 64502                                      // 0000001DA258: BFA5FBF6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b34>
	ds_load_b32 v9, v141 offset:24                             // 0000001DA25C: D8D80018 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA264: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001DA268: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA270: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA274: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[108:109]      // 0000001DA27C: D6FE7C09 05B322FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA288: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA290: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA294: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA2A0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA2A8: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001DA2AC: BE8D2009
	s_cbranch_execz 64483                                      // 0000001DA2B0: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b40>
	ds_load_b32 v9, v141 offset:32                             // 0000001DA2B4: D8D80020 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA2BC: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001DA2C0: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA2C8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA2CC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[108:109]      // 0000001DA2D4: D6FE7C09 05B324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA2E0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA2E8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA2EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA2F8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA300: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001DA304: BE8D200A
	s_cbranch_execz 64464                                      // 0000001DA308: BFA5FBD0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b4c>
	ds_load_b32 v9, v141 offset:40                             // 0000001DA30C: D8D80028 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA314: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001DA318: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA320: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA324: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[108:109]      // 0000001DA32C: D6FE7C09 05B326FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA338: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA340: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA344: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA350: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA358: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001DA35C: BE8D200B
	s_cbranch_execz 64445                                      // 0000001DA360: BFA5FBBD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b58>
	ds_load_b32 v9, v141 offset:48                             // 0000001DA364: D8D80030 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA36C: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001DA370: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA378: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA37C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[108:109]      // 0000001DA384: D6FE7C09 05B328FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA390: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA398: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA39C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA3A8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA3B0: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001DA3B4: BE8D200C
	s_cbranch_execz 64426                                      // 0000001DA3B8: BFA5FBAA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b64>
	ds_load_b32 v9, v141 offset:56                             // 0000001DA3BC: D8D80038 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA3C4: BF89FC07
	v_fmac_f32_e32 v56, v16, v9                                // 0000001DA3C8: 56701310
	v_mad_u64_u32 v[9:10], null, 0x3000, v149, v[108:109]      // 0000001DA3CC: D6FE7C09 05B32AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DA3D8: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v56                         // 0000001DA3DC: 101670FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA3E4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA3EC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA3F0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001DA3FC: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA404: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001DA408: BE8D2000
	s_cbranch_execz 64408                                      // 0000001DA40C: BFA5FB98 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b70>
	ds_load_b32 v9, v141                                       // 0000001DA410: D8D80000 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA418: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001DA41C: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA424: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA428: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v142, v[108:109]      // 0000001DA430: D6FE7C09 05B31CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA43C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA444: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA448: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA454: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA45C: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000001DA460: BE8D2001
	s_cbranch_execz 64389                                      // 0000001DA464: BFA5FB85 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b7c>
	ds_load_b32 v9, v141 offset:8                              // 0000001DA468: D8D80008 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA470: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001DA474: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA47C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA480: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v143, v[108:109]      // 0000001DA488: D6FE7C09 05B31EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA494: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA49C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA4A0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA4AC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA4B4: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000001DA4B8: BE8D2007
	s_cbranch_execz 64370                                      // 0000001DA4BC: BFA5FB72 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b88>
	ds_load_b32 v9, v141 offset:16                             // 0000001DA4C0: D8D80010 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA4C8: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001DA4CC: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA4D4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA4D8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v144, v[108:109]      // 0000001DA4E0: D6FE7C09 05B320FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA4EC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA4F4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA4F8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA504: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA50C: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000001DA510: BE8D2008
	s_cbranch_execz 64351                                      // 0000001DA514: BFA5FB5F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b94>
	ds_load_b32 v9, v141 offset:24                             // 0000001DA518: D8D80018 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA520: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001DA524: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA52C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA530: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[108:109]      // 0000001DA538: D6FE7C09 05B322FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA544: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA54C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA550: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA55C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA564: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000001DA568: BE8D2009
	s_cbranch_execz 64332                                      // 0000001DA56C: BFA5FB4C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ba0>
	ds_load_b32 v9, v141 offset:32                             // 0000001DA570: D8D80020 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA578: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001DA57C: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA584: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA588: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[108:109]      // 0000001DA590: D6FE7C09 05B324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA59C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA5A4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA5A8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA5B4: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA5BC: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 0000001DA5C0: BE8D200A
	s_cbranch_execz 64313                                      // 0000001DA5C4: BFA5FB39 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bac>
	ds_load_b32 v9, v141 offset:40                             // 0000001DA5C8: D8D80028 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA5D0: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001DA5D4: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA5DC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA5E0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[108:109]      // 0000001DA5E8: D6FE7C09 05B326FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA5F4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA5FC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA600: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA60C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA614: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 0000001DA618: BE8D200B
	s_cbranch_execz 64294                                      // 0000001DA61C: BFA5FB26 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bb8>
	ds_load_b32 v9, v141 offset:48                             // 0000001DA620: D8D80030 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA628: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001DA62C: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA634: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001DA638: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[108:109]      // 0000001DA640: D6FE7C09 05B328FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA64C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA654: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA658: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA664: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA66C: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000001DA670: BE8D200C
	s_cbranch_execz 64275                                      // 0000001DA674: BFA5FB13 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bc4>
	ds_load_b32 v9, v141 offset:56                             // 0000001DA678: D8D80038 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA680: BF89FC07
	v_fmac_f32_e32 v48, v24, v9                                // 0000001DA684: 56601318
	v_mad_u64_u32 v[9:10], null, 0x3000, v149, v[108:109]      // 0000001DA688: D6FE7C09 05B32AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DA694: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 0000001DA698: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001DA6A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA6A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001DA6AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001DA6B8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA6C0: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000001DA6C4: BE8D2000
	s_cbranch_execz 64257                                      // 0000001DA6C8: BFA5FB01 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bd0>
	ds_load_b32 v9, v141                                       // 0000001DA6CC: D8D80000 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA6D4: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001DA6D8: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v142, v[108:109]      // 0000001DA6E0: D6FE7C09 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DA6EC: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001DA6F0: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001DA6F8: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA700: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001DA704: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001DA710: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001DA718: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 0000001DA71C: BE802001
	s_cbranch_execz 64238                                      // 0000001DA720: BFA5FAEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bdc>
	ds_load_b32 v1, v141 offset:8                              // 0000001DA724: D8D80008 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA72C: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001DA730: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA738: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001DA73C: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v143, v[108:109]       // 0000001DA744: D6FE7C01 05B31EFF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001DA750: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA758: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001DA75C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001DA768: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA770: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001DA774: BE802007
	s_cbranch_execz 64219                                      // 0000001DA778: BFA5FADB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5be8>
	ds_load_b32 v1, v141 offset:16                             // 0000001DA77C: D8D80010 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA784: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001DA788: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA790: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001DA794: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v144, v[108:109]       // 0000001DA79C: D6FE7C01 05B320FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001DA7A8: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA7B0: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001DA7B4: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001DA7C0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA7C8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001DA7CC: BE802008
	s_cbranch_execz 64200                                      // 0000001DA7D0: BFA5FAC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5bf4>
	ds_load_b32 v1, v141 offset:24                             // 0000001DA7D4: D8D80018 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA7DC: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001DA7E0: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA7E8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001DA7EC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v145, v[108:109]       // 0000001DA7F4: D6FE7C01 05B322FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001DA800: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA808: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001DA80C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001DA818: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA820: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001DA824: BE802009
	s_cbranch_execz 64181                                      // 0000001DA828: BFA5FAB5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c00>
	ds_load_b32 v1, v141 offset:32                             // 0000001DA82C: D8D80020 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA834: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001DA838: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA840: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001DA844: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v146, v[108:109]       // 0000001DA84C: D6FE7C01 05B324FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001DA858: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA860: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001DA864: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001DA870: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA878: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001DA87C: BE80200A
	s_cbranch_execz 64162                                      // 0000001DA880: BFA5FAA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c0c>
	ds_load_b32 v1, v141 offset:40                             // 0000001DA884: D8D80028 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA88C: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001DA890: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA898: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001DA89C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v147, v[108:109]       // 0000001DA8A4: D6FE7C01 05B326FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001DA8B0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA8B8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001DA8BC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001DA8C8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA8D0: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001DA8D4: BE80200B
	s_cbranch_execz 64143                                      // 0000001DA8D8: BFA5FA8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c18>
	ds_load_b32 v1, v141 offset:48                             // 0000001DA8DC: D8D80030 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001DA8E4: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001DA8E8: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DA8F0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001DA8F4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v148, v[108:109]       // 0000001DA8FC: D6FE7C01 05B328FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001DA908: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DA910: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001DA914: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001DA920: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DA928: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001DA92C: BE80200C
	s_cbranch_execnz 64124                                     // 0000001DA930: BFA6FA7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c24>
	s_branch 64141                                             // 0000001DA934: BFA0FA8D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5c6c>
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v4, v119         // 0000001DA938: CA10016E 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v111         // 0000001DA940: CA10017C 0302016F
	s_mov_b32 s7, 0                                            // 0000001DA948: BE870080
	s_nop 0                                                    // 0000001DA94C: BF800000
	s_nop 0                                                    // 0000001DA950: BF800000
	s_nop 0                                                    // 0000001DA954: BF800000
	s_nop 0                                                    // 0000001DA958: BF800000
	s_nop 0                                                    // 0000001DA95C: BF800000
	s_nop 0                                                    // 0000001DA960: BF800000
	s_nop 0                                                    // 0000001DA964: BF800000
	s_nop 0                                                    // 0000001DA968: BF800000
	s_nop 0                                                    // 0000001DA96C: BF800000
	s_nop 0                                                    // 0000001DA970: BF800000
	s_nop 0                                                    // 0000001DA974: BF800000
	s_nop 0                                                    // 0000001DA978: BF800000
	s_nop 0                                                    // 0000001DA97C: BF800000
	ds_load_b32 v5, v3                                         // 0000001DA980: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001DA988: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001DA990: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001DA994: BF8700D2
	.long 0xd4490000                                           // 0000001DA998: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001DA99C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001DA9A4: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001DA9A8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001DA9AC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001DA9B4: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001DA9B8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001DA9C0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001DA9C8: 917E077E
	s_cbranch_execnz 65516                                     // 0000001DA9CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7280>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001DA9D0: 8C7E077E
	s_cmp_lg_u32 s40, s37                                      // 0000001DA9D4: BF072528
	s_cbranch_scc1 64712                                       // 0000001DA9D8: BFA2FCC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x65fc>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 0000001DA9DC: CA100170 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v113         // 0000001DA9E4: CA10017C 03020171
	s_mov_b32 s7, 0                                            // 0000001DA9EC: BE870080
	s_nop 0                                                    // 0000001DA9F0: BF800000
	s_nop 0                                                    // 0000001DA9F4: BF800000
	s_nop 0                                                    // 0000001DA9F8: BF800000
	s_nop 0                                                    // 0000001DA9FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001DAA00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001DAA08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001DAA10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001DAA14: BF8700D2
	.long 0xd4490000                                           // 0000001DAA18: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001DAA1C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001DAA24: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001DAA28: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001DAA2C: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001DAA34: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001DAA38: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001DAA40: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001DAA48: 917E077E
	s_cbranch_execnz 65516                                     // 0000001DAA4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7300>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001DAA50: 8C7E077E
	s_cmp_lg_u32 s40, s38                                      // 0000001DAA54: BF072628
	s_cbranch_scc1 58406                                       // 0000001DAA58: BFA2E426 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f4>
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v4, v119         // 0000001DAA5C: CA100172 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v115         // 0000001DAA64: CA10017C 03020173
	s_mov_b32 s7, 0                                            // 0000001DAA6C: BE870080
	s_nop 0                                                    // 0000001DAA70: BF800000
	s_nop 0                                                    // 0000001DAA74: BF800000
	s_nop 0                                                    // 0000001DAA78: BF800000
	s_nop 0                                                    // 0000001DAA7C: BF800000
	ds_load_b32 v5, v3                                         // 0000001DAA80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001DAA88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001DAA90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001DAA94: BF8700D2
	.long 0xd4490000                                           // 0000001DAA98: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001DAA9C: 020208FF 00001F7F
	s_or_b32 s7, s0, s7                                        // 0000001DAAA4: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000001DAAA8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001DAAAC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001DAAB4: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001DAAB8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001DAAC0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001DAAC8: 917E077E
	s_cbranch_execnz 65516                                     // 0000001DAACC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7380>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001DAAD0: 8C7E077E
	s_branch 58375                                             // 0000001DAAD4: BFA0E407 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f4>
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 0000001DAAD8: CA100030 01020031
	v_mov_b32_e32 v6, v119                                     // 0000001DAAE0: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DAAE4: BF870092
	.long 0xd7006a00                                           // 0000001DAAE8: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001DAAEC: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001DAAF0: D5207C01 01AA0413
	s_add_u32 s0, s33, s34                                     // 0000001DAAF8: 80002221
	s_addc_u32 s1, s15, s35                                    // 0000001DAAFC: 8201230F
	.long 0xd7006a00                                           // 0000001DAB00: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001DAB04: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001DAB08: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001DAB0C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001DAB14: BE810080
	.long 0xd7006a00                                           // 0000001DAB18: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001DAB1C: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001DAB20: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DAB28: BF870092
	.long 0xd7006a00                                           // 0000001DAB2C: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 0000001DAB30: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v131, vcc_lo             // 0000001DAB34: D5207C01 01AB0701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DAB3C: BF870092
	.long 0xd7006a00                                           // 0000001DAB40: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001DAB44: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001DAB48: D5207C01 01AA0211
	s_nop 0                                                    // 0000001DAB50: BF800000
	s_nop 0                                                    // 0000001DAB54: BF800000
	s_nop 0                                                    // 0000001DAB58: BF800000
	s_nop 0                                                    // 0000001DAB5C: BF800000
	s_nop 0                                                    // 0000001DAB60: BF800000
	s_nop 0                                                    // 0000001DAB64: BF800000
	s_nop 0                                                    // 0000001DAB68: BF800000
	s_nop 0                                                    // 0000001DAB6C: BF800000
	s_nop 0                                                    // 0000001DAB70: BF800000
	s_nop 0                                                    // 0000001DAB74: BF800000
	s_nop 0                                                    // 0000001DAB78: BF800000
	s_nop 0                                                    // 0000001DAB7C: BF800000
	ds_load_b32 v2, v124                                       // 0000001DAB80: D8D80000 0200007C
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001DAB88: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v124, 8, v124                             // 0000001DAB90: 4AF8F888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001DAB94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001DAB98: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001DABA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001DABA4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001DABA8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001DABB0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001DABB4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001DABBC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001DABC4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001DABC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7480>
	s_nop 0                                                    // 0000001DABCC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001DABD0: BFB60003
	s_endpgm                                                   // 0000001DABD4: BFB00000
		...

