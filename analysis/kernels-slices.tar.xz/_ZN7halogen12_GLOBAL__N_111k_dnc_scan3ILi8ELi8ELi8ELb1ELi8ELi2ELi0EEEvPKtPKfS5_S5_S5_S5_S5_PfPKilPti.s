0000000000094100 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000094100: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000094104: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000009410C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000094114: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000094118: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000009411C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000094120: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000094128: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000009412C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000094130: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000094134: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000009413C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000094140: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000094144: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000094148: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000009414C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000094150: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000094154: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000094158: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000009415C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000094164: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000009416C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000094170: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000094174: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000094178: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000009417C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000094180: 821E191E
	.long 0xd7001f02                                           // 000000094184: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000094188: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000009418C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000094194: BE9E0080
	s_nop 0                                                    // 000000094198: BF800000
	s_nop 0                                                    // 00000009419C: BF800000
	s_nop 0                                                    // 0000000941A0: BF800000
	s_nop 0                                                    // 0000000941A4: BF800000
	s_nop 0                                                    // 0000000941A8: BF800000
	s_nop 0                                                    // 0000000941AC: BF800000
	s_nop 0                                                    // 0000000941B0: BF800000
	s_nop 0                                                    // 0000000941B4: BF800000
	s_nop 0                                                    // 0000000941B8: BF800000
	s_nop 0                                                    // 0000000941BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000941C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000941C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000941CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000941D0: 300C1089
	.long 0xd7006a06                                           // 0000000941D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000941D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000941DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000941E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000941E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000941F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000941F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000941FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000094208: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000009420C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000094210: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000094218: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000009421C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000094220: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000094224: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000009422C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000094234: 32040084
	s_mov_b32 s0, 0                                            // 000000094238: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000009423C: BF89FC07
	s_barrier                                                  // 000000094240: BFBD0000
	buffer_gl0_inv                                             // 000000094244: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000009424C: BF02801E
	s_cbranch_scc1 12                                          // 000000094250: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000094254: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000009425C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000094264: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000094268: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000094270: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000094274: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000094278: 916A007E
	s_cbranch_vccz 2                                           // 00000009427C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2216                                              // 000000094280: BFA008A8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2424>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000094284: 304E0A82
	s_add_i32 s0, s30, 63                                      // 000000094288: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000009428C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000094294: 85218600
	s_add_u32 s34, s10, s24                                    // 000000094298: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000009429C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000942A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000942A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000942AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000942B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000942B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000942B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000942BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000942C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000942C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000942C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000942D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000942D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000942DC: B00A0204
	.long 0xd7000b2c                                           // 0000000942E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000942E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000942E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000942EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000942F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000094300: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000094304: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 000000094310: 3816500A
	.long 0xd7000a05                                           // 000000094314: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000094318: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009431C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000094320: D5207C06 00290001
	.long 0xd7000107                                           // 000000094328: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000009432C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000094330: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000094334: D5207C08 0006180D
	.long 0xd7000109                                           // 00000009433C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000094340: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000094344: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000009434C: 84848E02
	.long 0xd700010b                                           // 000000094350: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000094354: 02021606
	s_add_u32 s4, s14, s4                                      // 000000094358: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000009435C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000094364: 8205050F
	.long 0xd700010d                                           // 000000094368: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000009436C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000094370: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000094374: D5207C0E 00050005
	.long 0xd700010f                                           // 00000009437C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000094380: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000094388: D5207C10 00061880
	.long 0xd7000111                                           // 000000094390: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000094394: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009439C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000943A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000943A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000943AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000943B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000943BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000943C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000943C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000943CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000943D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000943D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000943E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000943E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000943EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000943F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000943F8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000094400: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000094404: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000009440C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000094414: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000094418: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000094420: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000094424: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000009442C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000094434: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000009443C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000094444: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000009444C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000094454: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000009445C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000094464: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000009446C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000094474: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000009447C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000094484: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000009448C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000094494: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000009449C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000944A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000944A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000944AC: BF870499
	s_add_i32 s6, s31, s1                                      // 0000000944B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000000944B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000944B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000000944BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000000944C0: 84078605
	s_add_u32 s10, s8, s10                                     // 0000000944C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000000944C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000000944CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000944D4: BE84206A
	s_cbranch_execz 77                                         // 0000000944D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 0000000944DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000944E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000944E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000944EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000944F0: BF870091
	.long 0xd73c001d                                           // 0000000944F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000944F8: 02023A82
	.long 0xd700011d                                           // 0000000944FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000094500: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000094504: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000094508: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000094510: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000094518: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000009451C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000094520: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000009452C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000094530: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000009453C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000094540: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000009454C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000094550: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000094554: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000094560: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000094564: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000094568: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000094570: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000094574: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000009457C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000094584: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000094588: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009458C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000094590: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000094594: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000094598: BF870296
	.long 0xd71c0020                                           // 00000009459C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000945A0: 02024520
	.long 0xd71c001f                                           // 0000000945A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000945A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000945AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000945B0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000945B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000945BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000945C4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000945CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000945D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000945D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000945DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000945E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000945EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000945F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000094600: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000094608: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000094610: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000094614: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000009461C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000094620: BF89FC07
	s_barrier                                                  // 000000094624: BFBD0000
	buffer_gl0_inv                                             // 000000094628: E0AC0000 00000000
	s_branch 15                                                // 000000094630: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000094634: 8C7E047E
	.long 0xd700011d                                           // 000000094638: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000009463C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094644: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000094648: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000094650: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000094654: BF08B70A
	s_mov_b32 s10, s1                                          // 000000094658: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000009465C: BF89FC07
	s_barrier                                                  // 000000094660: BFBD0000
	buffer_gl0_inv                                             // 000000094664: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000009466C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000094670: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000094678: CA100128 21220126
	s_mov_b32 s11, 0                                           // 000000094680: BE8B0080
	s_nop 0                                                    // 000000094684: BF800000
	s_nop 0                                                    // 000000094688: BF800000
	s_nop 0                                                    // 00000009468C: BF800000
	s_nop 0                                                    // 000000094690: BF800000
	s_nop 0                                                    // 000000094694: BF800000
	s_nop 0                                                    // 000000094698: BF800000
	s_nop 0                                                    // 00000009469C: BF800000
	s_nop 0                                                    // 0000000946A0: BF800000
	s_nop 0                                                    // 0000000946A4: BF800000
	s_nop 0                                                    // 0000000946A8: BF800000
	s_nop 0                                                    // 0000000946AC: BF800000
	s_nop 0                                                    // 0000000946B0: BF800000
	s_nop 0                                                    // 0000000946B4: BF800000
	s_nop 0                                                    // 0000000946B8: BF800000
	s_nop 0                                                    // 0000000946BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000946C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000946C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000946D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000946D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000946DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000946E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000946E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000946EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000000946F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000000946F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000946FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000094704: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000009470C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000094710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000094714: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000094718: BF89FC07
	s_barrier                                                  // 00000009471C: BFBD0000
	buffer_gl0_inv                                             // 000000094720: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000094728: BE842000
	s_cbranch_execz 65473                                      // 00000009472C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000094730: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 000000094738: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 000000094740: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 000000094748: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000094750: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 000000094758: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000094760: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 000000094768: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 000000094770: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 000000094778: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 000000094780: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 000000094788: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 000000094790: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 000000094798: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000947A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000947A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000947AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000947B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000947B4: BF870091
	.long 0xd7000146                                           // 0000000947B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000947BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000947C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000947C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000947D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000947D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000947DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000947E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000947E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000947EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000947F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000947FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 000000094804: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000009480C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 000000094814: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094818: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000009481C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 000000094824: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000009482C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094830: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 000000094834: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000009483C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 000000094844: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094848: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000009484C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 000000094854: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000009485C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094860: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094864: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000009486C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 000000094874: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000009487C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 000000094884: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000009488C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 000000094894: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000009489C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000948A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000948AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000948B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000948B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000948BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000948C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000948CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000948D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000948D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000948E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000948E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000948E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000948F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000948F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000948FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 000000094900: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000094908: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 000000094910: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 000000094918: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 000000094920: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 000000094928: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 000000094930: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 000000094938: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 000000094940: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 000000094948: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 000000094950: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094954: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 000000094958: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 000000094960: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 000000094968: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009496C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094970: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094978: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094980: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094984: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 000000094988: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 000000094990: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 000000094998: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009499C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000949A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000949A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000949B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000949B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000949C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000949C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000949D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000949D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000949E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000949E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000949F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000949F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000949F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000094A00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000094A08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094A0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 000000094A10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 000000094A18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 000000094A20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094A24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000094A28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000094A30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 000000094A38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094A3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 000000094A40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 000000094A48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 000000094A50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 000000094A58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 000000094A60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 000000094A68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 000000094A70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 000000094A78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 000000094A80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 000000094A88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 000000094A90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094A94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000094A98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000094AA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000094AA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094AAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094AB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094AB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094AC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094AC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 000000094AC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 000000094AD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 000000094AD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094ADC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094AE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 000000094AE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 000000094AF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 000000094AF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 000000094B00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 000000094B08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 000000094B10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000094B18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 000000094B20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 000000094B28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000094B30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094B34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000094B38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000094B40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000094B48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094B4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000094B50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000094B58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000094B60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094B64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000094B68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094B70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094B78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094B7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000094B80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 000000094B88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 000000094B90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 000000094B98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 000000094BA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 000000094BA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 000000094BB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 000000094BB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 000000094BC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 000000094BC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000094BD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094BD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000094BD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000094BE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000094BE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094BEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094BF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094BF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094C00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094C04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000094C08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094C10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094C18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094C1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094C20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 000000094C28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 000000094C30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 000000094C38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 000000094C40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 000000094C48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 000000094C50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000094C58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 000000094C60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 000000094C68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000094C70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094C74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000094C78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000094C80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000094C88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094C8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000094C90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000094C98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000094CA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094CA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000094CA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094CB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094CB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094CBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000094CC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 000000094CC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 000000094CD0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 000000094CD8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 000000094CE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 000000094CE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 000000094CF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 000000094CF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 000000094D00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 000000094D08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000094D10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094D14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000094D18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000094D20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000094D28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094D2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094D30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094D38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094D40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094D44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000094D48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094D50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094D58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094D5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094D60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 000000094D68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 000000094D70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 000000094D78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 000000094D80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 000000094D88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 000000094D90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000094D98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 000000094DA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 000000094DA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000094DB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094DB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000094DB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000094DC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000094DC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094DCC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000094DD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000094DD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000094DE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094DE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000094DE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094DF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094DF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094DFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000094E00: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 000000094E08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 000000094E10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 000000094E18: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 000000094E20: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 000000094E28: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 000000094E30: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 000000094E38: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 000000094E40: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 000000094E48: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000094E50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094E54: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000094E58: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000094E60: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000094E68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094E6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094E70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094E78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094E80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094E84: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000094E88: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094E90: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094E98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094E9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094EA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 000000094EA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 000000094EB0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 000000094EB8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 000000094EC0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 000000094EC8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 000000094ED0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 000000094ED8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 000000094EE0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 000000094EE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000094EF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094EF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000094EF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000094F00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000094F08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094F0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000094F10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000094F18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000094F20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094F24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000094F28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094F30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094F38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094F3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000094F40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 000000094F48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 000000094F50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 000000094F58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 000000094F60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 000000094F68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 000000094F70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 000000094F78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 000000094F80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 000000094F88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000094F90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094F94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000094F98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000094FA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000094FA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094FAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000094FB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000094FB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000094FC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000094FC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000094FC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000094FD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000094FD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000094FDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000094FE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 000000094FE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 000000094FF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 000000094FF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 000000095000: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 000000095008: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 000000095010: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000095018: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 000000095020: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 000000095028: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000095030: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095034: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000095038: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000095040: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000095048: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009504C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000095050: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000095058: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000095060: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095064: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000095068: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000095070: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000095078: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009507C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000095080: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000095088: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000095090: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000095098: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000950A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000950A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000950B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000950B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000950C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000950C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000950D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000950D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000950D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000950E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000950E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000950EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000950F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000950F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000095100: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095104: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000095108: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000095110: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000095118: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009511C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 000000095120: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 000000095128: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 000000095130: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095134: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 000000095138: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 000000095140: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 000000095148: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000009514C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 000000095150: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 000000095158: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 000000095164: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000009516C: D8340000 0000201F
	s_branch 64815                                             // 000000095174: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000095178: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000009517C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000095184: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 000000095188: 7E46032B
	s_mov_b32 s10, 0                                           // 00000009518C: BE8A0080
	s_branch 21                                                // 000000095190: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000095194: 8C7E0B7E
	.long 0xd700011f                                           // 000000095198: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000009519C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000951A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000951A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000951B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000951B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000951BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000951C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 0000000951C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000951CC: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000951D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000951D4: BC7C0000
	s_barrier                                                  // 0000000951D8: BFBD0000
	buffer_gl0_inv                                             // 0000000951DC: E0AC0000 00000000
	s_cbranch_scc1 214                                         // 0000000951E4: BFA200D6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1440>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000951E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000951EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000951F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000951F8: 7E780326
	s_mov_b32 s11, 0                                           // 0000000951FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 000000095200: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000095208: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000095210: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000095214: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009521C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000095220: D5207C22 00064480
	.long 0xd4490004                                           // 000000095228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000009522C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000095234: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000095238: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000009523C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000095244: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000009524C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000095250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000095254: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000095258: BF89FC07
	s_barrier                                                  // 00000009525C: BFBD0000
	buffer_gl0_inv                                             // 000000095260: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000095268: BE8B2000
	s_cbranch_execz 65481                                      // 00000009526C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 000000095270: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095274: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000095278: 38484207
	.long 0xd4440001                                           // 00000009527C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000095280: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000095284: 8B7E017E
	s_cbranch_execz 65474                                      // 000000095288: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 00000009528C: 7E780280
	s_mov_b32 s1, 0                                            // 000000095290: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000095294: BF870009
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 000000095298: D6FE7C3D 040402FF 00000044
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000952A4: D6460022 04B90401
	s_add_i32 s4, s1, 16                                       // 0000000952AC: 81049001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000952B0: B6810070
	s_mov_b32 s1, s4                                           // 0000000952B4: BE810004
	ds_load_2addr_b32 v[64:65], v34 offset0:2 offset1:3        // 0000000952B8: D8DC0302 40000022
	ds_load_2addr_b32 v[66:67], v34 offset0:4 offset1:5        // 0000000952C0: D8DC0504 42000022
	ds_load_2addr_b32 v[62:63], v61 offset0:68 offset1:85      // 0000000952C8: D8DC5544 3E00003D
	ds_load_2addr_b32 v[68:69], v34 offset0:6 offset1:7        // 0000000952D0: D8DC0706 44000022
	ds_load_2addr_b32 v[72:73], v34 offset0:8 offset1:9        // 0000000952D8: D8DC0908 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:10 offset1:11      // 0000000952E0: D8DC0B0A 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:12 offset1:13      // 0000000952E8: D8DC0D0C 4C000022
	ds_load_2addr_b32 v[78:79], v34 offset0:14 offset1:15      // 0000000952F0: D8DC0F0E 4E000022
	s_waitcnt lgkmcnt(5)                                       // 0000000952F8: BF89FC57
	v_cvt_f16_f32_e32 v88, v62                                 // 0000000952FC: 7EB0153E
	v_cvt_f16_f32_e32 v89, v63                                 // 000000095300: 7EB2153F
	ds_load_2addr_b32 v[62:63], v61 offset0:34 offset1:51      // 000000095304: D8DC3322 3E00003D
	s_waitcnt lgkmcnt(0)                                       // 00000009530C: BF89FC07
	v_cvt_f16_f32_e32 v90, v62                                 // 000000095310: 7EB4153E
	v_cvt_f16_f32_e32 v91, v63                                 // 000000095314: 7EB6153F
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 000000095318: D8DC1100 3E00003D
	s_waitcnt lgkmcnt(0)                                       // 000000095320: BF89FC07
	v_cvt_f16_f32_e32 v92, v62                                 // 000000095324: 7EB8153E
	v_cvt_f16_f32_e32 v93, v63                                 // 000000095328: 7EBA153F
	ds_load_2addr_b32 v[62:63], v34 offset1:1                  // 00000009532C: D8DC0100 3E000022
	s_waitcnt lgkmcnt(0)                                       // 000000095334: BF89FC07
	v_cvt_f16_f32_e32 v34, v62                                 // 000000095338: 7E44153E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009533C: BF870001
	v_fma_mix_f32 v34, v34, v92, v60 op_sel_hi:[1,1,0]         // 000000095340: CC200022 1CF2B922
	v_cvt_f16_f32_e32 v60, v64                                 // 000000095348: 7E781540
	ds_load_2addr_b32 v[70:71], v61 offset0:102 offset1:119    // 00000009534C: D8DC7766 4600003D
	ds_load_2addr_b32 v[80:81], v61 offset0:136 offset1:153    // 000000095354: D8DC9988 5000003D
	ds_load_2addr_b32 v[82:83], v61 offset0:170 offset1:187    // 00000009535C: D8DCBBAA 5200003D
	ds_load_2addr_b32 v[84:85], v61 offset0:204 offset1:221    // 000000095364: D8DCDDCC 5400003D
	ds_load_2addr_b32 v[86:87], v61 offset0:238 offset1:255    // 00000009536C: D8DCFFEE 5600003D
	v_cvt_f16_f32_e32 v61, v63                                 // 000000095374: 7E7A153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000095378: BF870121
	v_fma_mix_f32 v34, v61, v93, v34 op_sel_hi:[1,1,0]         // 00000009537C: CC200022 1C8ABB3D
	v_cvt_f16_f32_e32 v61, v65                                 // 000000095384: 7E7A1541
	v_fma_mix_f32 v34, v60, v90, v34 op_sel_hi:[1,1,0]         // 000000095388: CC200022 1C8AB53C
	v_cvt_f16_f32_e32 v60, v66                                 // 000000095390: 7E781542
	s_delay_alu instid0(VALU_DEP_2)                            // 000000095394: BF870002
	v_fma_mix_f32 v34, v61, v91, v34 op_sel_hi:[1,1,0]         // 000000095398: CC200022 1C8AB73D
	v_cvt_f16_f32_e32 v61, v67                                 // 0000000953A0: 7E7A1543
	s_waitcnt lgkmcnt(4)                                       // 0000000953A4: BF89FC47
	v_cvt_f16_f32_e32 v62, v70                                 // 0000000953A8: 7E7C1546
	v_cvt_f16_f32_e32 v63, v71                                 // 0000000953AC: 7E7E1547
	v_fma_mix_f32 v34, v60, v88, v34 op_sel_hi:[1,1,0]         // 0000000953B0: CC200022 1C8AB13C
	v_cvt_f16_f32_e32 v60, v68                                 // 0000000953B8: 7E781544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000953BC: BF870122
	v_fma_mix_f32 v34, v61, v89, v34 op_sel_hi:[1,1,0]         // 0000000953C0: CC200022 1C8AB33D
	v_cvt_f16_f32_e32 v61, v69                                 // 0000000953C8: 7E7A1545
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 0000000953CC: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v72                                 // 0000000953D4: 7E781548
	s_waitcnt lgkmcnt(3)                                       // 0000000953D8: BF89FC37
	v_cvt_f16_f32_e32 v62, v80                                 // 0000000953DC: 7E7C1550
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000953E0: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 0000000953E4: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v73                                 // 0000000953EC: 7E7A1549
	v_cvt_f16_f32_e32 v63, v81                                 // 0000000953F0: 7E7E1551
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 0000000953F4: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v74                                 // 0000000953FC: 7E78154A
	s_waitcnt lgkmcnt(2)                                       // 000000095400: BF89FC27
	v_cvt_f16_f32_e32 v62, v82                                 // 000000095404: 7E7C1552
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000095408: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 00000009540C: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v75                                 // 000000095414: 7E7A154B
	v_cvt_f16_f32_e32 v63, v83                                 // 000000095418: 7E7E1553
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 00000009541C: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v76                                 // 000000095424: 7E78154C
	s_waitcnt lgkmcnt(1)                                       // 000000095428: BF89FC17
	v_cvt_f16_f32_e32 v62, v84                                 // 00000009542C: 7E7C1554
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000095430: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000095434: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v77                                 // 00000009543C: 7E7A154D
	v_cvt_f16_f32_e32 v63, v85                                 // 000000095440: 7E7E1555
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 000000095444: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v78                                 // 00000009544C: 7E78154E
	s_waitcnt lgkmcnt(0)                                       // 000000095450: BF89FC07
	v_cvt_f16_f32_e32 v62, v86                                 // 000000095454: 7E7C1556
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000095458: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 00000009545C: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v79                                 // 000000095464: 7E7A154F
	v_cvt_f16_f32_e32 v63, v87                                 // 000000095468: 7E7E1557
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 00000009546C: CC200022 1C8A7D3C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000095474: BF870001
	v_fma_mix_f32 v60, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000095478: CC20003C 1C8A7F3D
	s_cbranch_scc1 65412                                       // 000000095480: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000095484: 30424282
	v_mov_b32_e32 v61, v1                                      // 000000095488: 7E7A0301
	s_mov_b32 s12, 0                                           // 00000009548C: BE8C0080
	ds_load_b32 v62, v33 offset:17440                          // 000000095490: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000095498: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000954A0: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000954A4: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000954A8: 7E7C0323
	s_nop 0                                                    // 0000000954AC: BF800000
	s_nop 0                                                    // 0000000954B0: BF800000
	s_nop 0                                                    // 0000000954B4: BF800000
	s_nop 0                                                    // 0000000954B8: BF800000
	s_nop 0                                                    // 0000000954BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000954C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000954C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000954D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000954D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000954D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000954DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000954E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000954E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000954EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000954F0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 0000000954F8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000954FC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000095500: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000095504: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000095508: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000009550C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000095510: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000095514: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000009551C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000095528: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000095534: DC960000 007C2421
	s_branch 65301                                             // 00000009553C: BFA0FF15 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000095540: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000095548: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000009554C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000095550: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000095558: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000009555C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000095564: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000009556C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000095570: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000095574: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000009557C: A0010401
	s_mov_b32 s4, 0                                            // 000000095580: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000095584: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000095588: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000009558C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000095590: BF870585
	.long 0xd71c001d                                           // 000000095594: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000095598: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000009559C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000000955A0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000955A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000955AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000955B4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000955B8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000955BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000955C8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000955D0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000955D8: BF870001
	.long 0xd4490001                                           // 0000000955DC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000955E0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000955E8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000955EC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000955F0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000955F4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000955FC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000095604: 917E047E
	s_cbranch_execnz 65519                                     // 000000095608: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009560C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000095610: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000095618: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000095620: 7E420326
	s_mov_b32 s6, 0                                            // 000000095624: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000095628: BF89FC07
	s_barrier                                                  // 00000009562C: BFBD0000
	buffer_gl0_inv                                             // 000000095630: E0AC0000 00000000
	s_nop 0                                                    // 000000095638: BF800000
	s_nop 0                                                    // 00000009563C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000095640: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000095648: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000095650: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000095658: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000009565C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000095664: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000095668: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000095670: BF870004
	.long 0xd4490004                                           // 000000095674: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000095678: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095680: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095684: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095688: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000009568C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000095694: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009569C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000956A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000956A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000956A8: BF89FC07
	s_barrier                                                  // 0000000956AC: BFBD0000
	buffer_gl0_inv                                             // 0000000956B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000956B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000956C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000956C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000956D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000956D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000956DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000956E0: BF840001
	s_nop 0                                                    // 0000000956E4: BF800000
	s_nop 0                                                    // 0000000956E8: BF800000
	s_nop 0                                                    // 0000000956EC: BF800000
	s_nop 0                                                    // 0000000956F0: BF800000
	s_nop 0                                                    // 0000000956F4: BF800000
	s_nop 0                                                    // 0000000956F8: BF800000
	s_nop 0                                                    // 0000000956FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000095700: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000095704: 327A7884
	.long 0xd4490001                                           // 000000095708: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000009570C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000095714: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000095718: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000095724: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000095728: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000095730: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000095738: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000095740: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000095748: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000095750: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000095758: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000095760: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000095764: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000095770: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000095774: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000095778: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000095780: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000095784: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000095788: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000009578C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095790: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000095794: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000095798: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000009579C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000957A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000957A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000957B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000957B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000957C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000957C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1600>
	s_set_inst_prefetch_distance 0x2                           // 0000000957C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000957CC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000957D0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000957D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000957E0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000957E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000957E8: BF89FC07
	s_barrier                                                  // 0000000957EC: BFBD0000
	buffer_gl0_inv                                             // 0000000957F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000957F8: BF800000
	s_nop 0                                                    // 0000000957FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000095800: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000095808: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000095810: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000095818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000009581C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000095824: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000095828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000095830: BF870004
	.long 0xd4490004                                           // 000000095834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000095838: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095840: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095844: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095848: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000009584C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000095854: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009585C: 917E067E
	s_cbranch_execnz 65511                                     // 000000095860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1700>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000095864: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000095868: BF89FC07
	s_barrier                                                  // 00000009586C: BFBD0000
	buffer_gl0_inv                                             // 000000095870: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000095878: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000095880: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000095888: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000095890: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000095898: 7E780300
	s_mov_b32 s4, 0                                            // 00000009589C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000958A0: BF840001
	s_nop 0                                                    // 0000000958A4: BF800000
	s_nop 0                                                    // 0000000958A8: BF800000
	s_nop 0                                                    // 0000000958AC: BF800000
	s_nop 0                                                    // 0000000958B0: BF800000
	s_nop 0                                                    // 0000000958B4: BF800000
	s_nop 0                                                    // 0000000958B8: BF800000
	s_nop 0                                                    // 0000000958BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000958C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000958C4: 327A7884
	.long 0xd4490001                                           // 0000000958C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000958CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000958D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000958D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000958E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000958E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000958F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000958F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000095900: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000095908: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000095910: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000095918: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000095920: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000095924: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000095930: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000095934: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000095938: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000095940: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000095944: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000095948: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000009594C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095950: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000095954: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000095958: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000009595C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095960: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000095964: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000095970: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000095978: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000095980: 917E047E
	s_cbranch_execnz 65486                                     // 000000095984: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17c0>
	s_set_inst_prefetch_distance 0x2                           // 000000095988: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009598C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000095990: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000095998: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000959A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000959A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000959A8: BF89FC07
	s_barrier                                                  // 0000000959AC: BFBD0000
	buffer_gl0_inv                                             // 0000000959B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000959B8: BF800000
	s_nop 0                                                    // 0000000959BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000959C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000959C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000959D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000959D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000959DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000959E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000959E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000959F0: BF870004
	.long 0xd4490004                                           // 0000000959F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000959F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095A00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095A04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095A08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000095A0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000095A14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000095A1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000095A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000095A24: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 000000095A28: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000095A30: BF89FC07
	s_barrier                                                  // 000000095A34: BFBD0000
	buffer_gl0_inv                                             // 000000095A38: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 000000095A40: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000095A44: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 000000095A4C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000095A54: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 000000095A5C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000095A64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000095A68: BF840001
	s_nop 0                                                    // 000000095A6C: BF800000
	s_nop 0                                                    // 000000095A70: BF800000
	s_nop 0                                                    // 000000095A74: BF800000
	s_nop 0                                                    // 000000095A78: BF800000
	s_nop 0                                                    // 000000095A7C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000095A80: 327C7A84
	.long 0xd4490001                                           // 000000095A84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000095A88: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000095A90: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000095A94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000095A98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000095AA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000095AA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000095AB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000095AB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000095AC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000095AC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000095AD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000095AD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000095AE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000095AE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000095AE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000095AEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000095AF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000095B00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000095B04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000095B08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000095B0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095B10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000095B14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000095B18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000095B1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095B20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000095B24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000095B30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000095B38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000095B40: 917E047E
	s_cbranch_execnz 65486                                     // 000000095B44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_set_inst_prefetch_distance 0x2                           // 000000095B48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000095B4C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000095B50: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000095B58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000095B60: 7E420326
	s_mov_b32 s6, 0                                            // 000000095B64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000095B68: BF89FC07
	s_barrier                                                  // 000000095B6C: BFBD0000
	buffer_gl0_inv                                             // 000000095B70: E0AC0000 00000000
	s_nop 0                                                    // 000000095B78: BF800000
	s_nop 0                                                    // 000000095B7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000095B80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000095B88: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000095B90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000095B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000095B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000095BA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000095BA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000095BB0: BF870004
	.long 0xd4490004                                           // 000000095BB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000095BB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095BC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095BC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095BC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000095BCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000095BD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000095BDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000095BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000095BE4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000095BE8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000095BF0: BF89FC07
	s_barrier                                                  // 000000095BF4: BFBD0000
	buffer_gl0_inv                                             // 000000095BF8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000095C00: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000095C08: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000095C10: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000095C18: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000095C20: 7E780300
	s_mov_b32 s4, 0                                            // 000000095C24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000095C28: BF840001
	s_nop 0                                                    // 000000095C2C: BF800000
	s_nop 0                                                    // 000000095C30: BF800000
	s_nop 0                                                    // 000000095C34: BF800000
	s_nop 0                                                    // 000000095C38: BF800000
	s_nop 0                                                    // 000000095C3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000095C40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000095C44: 327A7884
	.long 0xd4490001                                           // 000000095C48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000095C4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000095C54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000095C58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000095C64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000095C68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000095C70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000095C78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000095C80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000095C88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000095C90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000095C98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000095CA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000095CA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000095CB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000095CB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000095CB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000095CC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000095CC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000095CC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000095CCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095CD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000095CD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000095CD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000095CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095CE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000095CE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000095CF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000095CF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000095D00: 917E047E
	s_cbranch_execnz 65486                                     // 000000095D04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000095D08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000095D0C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000095D10: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000095D18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000095D20: 7E420326
	s_mov_b32 s6, 0                                            // 000000095D24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000095D28: BF89FC07
	s_barrier                                                  // 000000095D2C: BFBD0000
	buffer_gl0_inv                                             // 000000095D30: E0AC0000 00000000
	s_nop 0                                                    // 000000095D38: BF800000
	s_nop 0                                                    // 000000095D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000095D40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000095D48: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000095D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000095D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000095D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000095D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000095D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000095D70: BF870004
	.long 0xd4490004                                           // 000000095D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000095D78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095D80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095D84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095D88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000095D8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000095D94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000095D9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000095DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000095DA4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 000000095DA8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000095DB0: BF89FC07
	s_barrier                                                  // 000000095DB4: BFBD0000
	buffer_gl0_inv                                             // 000000095DB8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 000000095DC0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000095DC4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 000000095DCC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000095DD4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 000000095DDC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000095DE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000095DE8: BF840001
	s_nop 0                                                    // 000000095DEC: BF800000
	s_nop 0                                                    // 000000095DF0: BF800000
	s_nop 0                                                    // 000000095DF4: BF800000
	s_nop 0                                                    // 000000095DF8: BF800000
	s_nop 0                                                    // 000000095DFC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000095E00: 327C7884
	.long 0xd4490001                                           // 000000095E04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000095E08: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000095E10: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000095E14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000095E18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000095E24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000095E28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000095E30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000095E38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000095E40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000095E48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000095E50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000095E58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000095E60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000095E64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000095E68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000095E6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000095E78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000095E80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000095E84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000095E88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000095E8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095E90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000095E94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000095E98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000095E9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000095EA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000095EA4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 000000095EB0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000095EB4: BF870002
	v_mov_b32_e32 v60, v63                                     // 000000095EB8: 7E78033F
	ds_store_b32 v62, v70                                      // 000000095EBC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000095EC4: 917E047E
	s_cbranch_execnz 65485                                     // 000000095EC8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 000000095ECC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000095ED0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000095ED4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000095EDC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000095EE4: 7E420326
	s_mov_b32 s6, 0                                            // 000000095EE8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000095EEC: BF89FC07
	s_barrier                                                  // 000000095EF0: BFBD0000
	buffer_gl0_inv                                             // 000000095EF4: E0AC0000 00000000
	s_nop 0                                                    // 000000095EFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000095F00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000095F08: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000095F10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000095F18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000095F1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000095F24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000095F28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000095F30: BF870004
	.long 0xd4490004                                           // 000000095F34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000095F38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000095F40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000095F44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000095F48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000095F4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000095F54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000095F5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000095F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000095F64: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000095F68: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000095F70: BF89FC07
	s_barrier                                                  // 000000095F74: BFBD0000
	buffer_gl0_inv                                             // 000000095F78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000095F80: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000095F88: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000095F90: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000095F98: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000095FA0: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000095FA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000095FA8: BF840001
	s_nop 0                                                    // 000000095FAC: BF800000
	s_nop 0                                                    // 000000095FB0: BF800000
	s_nop 0                                                    // 000000095FB4: BF800000
	s_nop 0                                                    // 000000095FB8: BF800000
	s_nop 0                                                    // 000000095FBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000095FC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000095FC4: 327C7A84
	.long 0xd4490001                                           // 000000095FC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000095FCC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000095FD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000095FD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000095FE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000095FE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000095FF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000095FF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000096000: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000096008: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000096010: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000096018: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000096020: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000096024: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000096028: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000009602C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000096038: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000096040: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000096044: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000096048: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000009604C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000096050: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000096054: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000096058: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000009605C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000096060: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000096064: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000096070: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000096078: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000096080: 917E047E
	s_cbranch_execnz 65486                                     // 000000096084: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000096088: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009608C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000096090: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000096098: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000960A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000960A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000960A8: BF89FC07
	s_barrier                                                  // 0000000960AC: BFBD0000
	buffer_gl0_inv                                             // 0000000960B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000960B8: BF800000
	s_nop 0                                                    // 0000000960BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000960C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000960C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000960D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000960D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000960DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000960E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000960E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000960F0: BF870004
	.long 0xd4490004                                           // 0000000960F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000960F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000096100: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000096104: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000096108: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000009610C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000096114: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009611C: 917E067E
	s_cbranch_execnz 65511                                     // 000000096120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000096124: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000096128: BF89FC07
	s_barrier                                                  // 00000009612C: BFBD0000
	buffer_gl0_inv                                             // 000000096130: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000096138: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000096140: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000096148: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000096150: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000096158: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000009615C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000096160: BF840001
	s_nop 0                                                    // 000000096164: BF800000
	s_nop 0                                                    // 000000096168: BF800000
	s_nop 0                                                    // 00000009616C: BF800000
	s_nop 0                                                    // 000000096170: BF800000
	s_nop 0                                                    // 000000096174: BF800000
	s_nop 0                                                    // 000000096178: BF800000
	s_nop 0                                                    // 00000009617C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000096180: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000096184: 327C7A84
	.long 0xd4490001                                           // 000000096188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000009618C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000096194: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000096198: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000961A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000961A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000961B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000961B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000961C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000961C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000961D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000961D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000961E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000961E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000961E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000961EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000961F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000096200: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000096204: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000096208: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000009620C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000096210: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000096214: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000096218: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000009621C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000096220: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000096224: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000096230: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000096238: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000096240: 917E047E
	s_cbranch_execnz 65486                                     // 000000096244: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000096248: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009624C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000096250: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000096258: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000096260: 7E420326
	s_mov_b32 s6, 0                                            // 000000096264: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000096268: BF89FC07
	s_barrier                                                  // 00000009626C: BFBD0000
	buffer_gl0_inv                                             // 000000096270: E0AC0000 00000000
	s_nop 0                                                    // 000000096278: BF800000
	s_nop 0                                                    // 00000009627C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000096280: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000096288: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000096290: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000096298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000009629C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000962A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000962A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000962B0: BF870004
	.long 0xd4490004                                           // 0000000962B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000962B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000962C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000962C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000962C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000962CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000962D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000962DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000962E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000962E4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000962E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000962F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000962F8: BF89FC07
	s_barrier                                                  // 0000000962FC: BFBD0000
	buffer_gl0_inv                                             // 000000096300: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000096308: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000096310: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000096318: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000096320: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000096328: 7E780300
	s_mov_b32 s4, 0                                            // 00000009632C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000096330: BF840001
	s_nop 0                                                    // 000000096334: BF800000
	s_nop 0                                                    // 000000096338: BF800000
	s_nop 0                                                    // 00000009633C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000096340: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000096344: 327A7884
	.long 0xd4490001                                           // 000000096348: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000009634C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000096354: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000096358: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000096364: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000096368: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000096370: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000096378: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000096380: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000096388: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000096390: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000096398: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000963A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000963A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000963B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000963B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000963B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000963C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000963C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000963C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000963CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000963D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000963D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000963D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000963DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000963E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000963E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000963F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000963F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000096400: 917E047E
	s_cbranch_execnz 65486                                     // 000000096404: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000096408: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009640C: 8C7E047E
	.long 0xd7000107                                           // 000000096410: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000096414: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009641C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000096420: D5207C08 00061080
	.long 0xd7000109                                           // 000000096428: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000009642C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000096434: D5207C0A 00061480
	.long 0xd700010d                                           // 00000009643C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000096440: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000096448: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000009644C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000096454: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000096458: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000096460: D5207C0C 00061880
	.long 0xd700010f                                           // 000000096468: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000009646C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000096474: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000096478: D5207C10 00062080
	.long 0xd7000111                                           // 000000096480: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000096484: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000009648C: D5207C12 00062480
	.long 0xd7000113                                           // 000000096494: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000096498: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000964A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000964A4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000964AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000964B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000964B8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000964C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000964C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000964CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000964D0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000964D8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000964DC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000964E4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000964EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000964F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000964F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000964FC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000096504: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000096508: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000009650C: BF062105
	s_barrier                                                  // 000000096510: BFBD0000
	buffer_gl0_inv                                             // 000000096514: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 00000009651C: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000096520: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000096524: 8000141C
	.long 0xd73c0000                                           // 000000096528: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000009652C: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000096530: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000096534: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000096538: 82031319
	s_add_u32 s0, s2, s0                                       // 00000009653C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000096540: 82010103
	.long 0xd7006a00                                           // 000000096544: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000096548: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000009654C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000096550: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000096558: BE810080
	.long 0xd7006a00                                           // 00000009655C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000096560: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000096564: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009656C: BF870092
	.long 0xd7006a00                                           // 000000096570: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000096574: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000096578: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 000000096580: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000096588: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000096590: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000096598: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000009659C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000965A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000965A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000965AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000965B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000965B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000965C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000965C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000965CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000965D0: BFB00000
		...

