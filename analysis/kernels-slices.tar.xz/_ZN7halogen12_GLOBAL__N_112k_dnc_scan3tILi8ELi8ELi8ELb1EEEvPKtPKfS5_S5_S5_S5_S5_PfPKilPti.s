0000000000134300 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000134300: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000134304: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000013430C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000134314: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000134318: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000013431C: 861B9F1A
	v_dual_mov_b32 v3, v0 :: v_dual_and_b32 v80, 15, v0        // 000000134320: CA240100 0350008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000134328: BF8704D1
	v_lshlrev_b32_e32 v1, 2, v80                               // 00000013432C: 3002A082
	v_mul_u32_u24_e32 v81, 0x210, v80                          // 000000134330: 16A2A0FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 000000134338: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000013433C: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 000000134344: 84928214
	s_add_u32 s25, s16, s18                                    // 000000134348: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000013434C: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000134350: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134354: BF870009
	s_add_u32 s25, s25, s20                                    // 000000134358: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000013435C: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000134360: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 000000134364: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000013436C: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 000000134374: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000134378: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000013437C: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000134380: BF8700B9
	s_add_u32 s31, s31, s24                                    // 000000134384: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000134388: 821E191E
	.long 0xd7001f01                                           // 00000013438C: D7001F01
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000134390: 0202021F
	v_add_co_ci_u32_e64 v2, null, s30, 0, s31                  // 000000134394: D5207C02 007D001E
	s_mov_b32 s30, 0                                           // 00000013439C: BE9E0080
	s_nop 0                                                    // 0000001343A0: BF800000
	s_nop 0                                                    // 0000001343A4: BF800000
	s_nop 0                                                    // 0000001343A8: BF800000
	s_nop 0                                                    // 0000001343AC: BF800000
	s_nop 0                                                    // 0000001343B0: BF800000
	s_nop 0                                                    // 0000001343B4: BF800000
	s_nop 0                                                    // 0000001343B8: BF800000
	s_nop 0                                                    // 0000001343BC: BF800000
	v_lshrrev_b32_e32 v6, 4, v3                                // 0000001343C0: 320C0684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001343C4: BF870121
	v_lshlrev_b32_e32 v4, 9, v6                                // 0000001343C8: 30080C89
	v_lshl_add_u32 v6, v6, 2, v81                              // 0000001343CC: D6460006 05450506
	.long 0xd7006a04                                           // 0000001343D4: D7006A04
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000001343D8: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001343DC: BF8700D1
	v_add_co_ci_u32_e64 v5, null, 0, v2, vcc_lo                // 0000001343E0: D5207C05 01AA0480
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v3                         // 0000001343E8: 7C9206FF 0000077F
	global_load_b32 v4, v[4:5], off                            // 0000001343F0: DC520000 047C0004
	v_add_nc_u32_e32 v5, 0x80, v3                              // 0000001343F8: 4A0A06FF 00000080
	s_or_b32 s30, vcc_lo, s30                                  // 000000134400: 8C1E1E6A
	v_mov_b32_e32 v3, v5                                       // 000000134404: 7E060305
	s_waitcnt vmcnt(0)                                         // 000000134408: BF8903F7
	ds_store_b32 v6, v4                                        // 00000013440C: D8340000 00000406
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000134414: 917E1E7E
	s_cbranch_execnz 65513                                     // 000000134418: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000013441C: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000134420: F4000780 F8000058
	v_or_b32_e32 v82, 0xffffff80, v0                           // 000000134428: 38A400FF FFFFFF80
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000134430: 32020084
	s_mov_b32 s0, 0                                            // 000000134434: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000134438: BF89FC07
	s_barrier                                                  // 00000013443C: BFBD0000
	buffer_gl0_inv                                             // 000000134440: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 000000134448: BF02801E
	s_cbranch_scc1 10                                          // 00000013444C: BFA2000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x178>
	v_lshrrev_b32_e32 v14, 4, v0                               // 000000134450: 321C0084
	v_or_b32_e32 v2, 0xffffff80, v0                            // 000000134454: 380400FF FFFFFF80
	v_mov_b32_e32 v15, 0                                       // 00000013445C: 7E1E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000134460: BF870003
	v_mov_b32_e32 v3, v14                                      // 000000134464: 7E06030E
	v_lshlrev_b32_e32 v83, 2, v80                              // 000000134468: 30A6A082
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000013446C: 916A007E
	s_cbranch_vccz 2                                           // 000000134470: BFA30002 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17c>
	s_branch 6620                                              // 000000134474: BFA019DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x68e8>
	v_lshlrev_b32_e32 v83, 2, v80                              // 000000134478: 30A6A082
	s_add_i32 s0, s30, 63                                      // 00000013447C: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 000000134480: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000134488: 85218600
	s_add_u32 s34, s10, s24                                    // 00000013448C: 8022180A
	s_addc_u32 s35, s11, s25                                   // 000000134490: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 000000134494: 84008702
	v_mul_u32_u24_e32 v4, 0x44, v1                             // 000000134498: 160802FF 00000044
	s_ashr_i32 s1, s0, 31                                      // 0000001344A0: 86019F00
	v_lshlrev_b32_e32 v5, 1, v80                               // 0000001344A4: 300AA081
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000001344A8: 84808100
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 0000001344AC: CA220080 02020082
	s_add_u32 s22, s22, s0                                     // 0000001344B4: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000001344B8: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000001344BC: 848A811A
	v_add3_u32 v89, v4, v83, 0x2100                            // 0000001344C0: D6550059 03FEA704 00002100
	s_add_u32 s10, s22, s10                                    // 0000001344CC: 800A0A16
	s_addc_u32 s1, s1, s11                                     // 0000001344D0: 82010B01
	.long 0xd7000b56                                           // 0000001344D4: D7000B56
	v_cndmask_b32_e32 v1, s34, v83, vcc_lo                     // 0000001344D8: 0202A622
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001344DC: BF870001
	v_add_co_ci_u32_e64 v87, null, s35, 0, s11                 // 0000001344E0: D5207C57 002D0023
	s_movk_i32 s11, 0x210                                      // 0000001344E8: B00B0210
	.long 0xd7000a04                                           // 0000001344EC: D7000A04
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000001344F0: 02020A0A
	v_mad_u32_u24 v88, v1, s11, 0x3200                         // 0000001344F4: D60B0058 03FC1701 00003200
	v_add_co_ci_u32_e64 v5, null, s1, 0, s10                   // 000000134500: D5207C05 00290001
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000134508: 848A8902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000013450C: BF8701D9
	v_dual_mov_b32 v57, s11 :: v_dual_add_nc_u32 v84, 0x4280, v3// 000000134510: CA20000B 395406FF 00004280
	v_or_b32_e32 v56, s10, v3                                  // 00000013451C: 3870060A
	v_lshlrev_b32_e32 v26, 8, v1                               // 000000134520: 30340288
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000134524: 848A8E02
	v_dual_mov_b32 v15, v2 :: v_dual_add_nc_u32 v98, 1, v1     // 000000134528: CA200102 0F620281
	.long 0xd700013a                                           // 000000134530: D700013A
	v_cndmask_b32_e32 v1, 0x30000, v56, vcc_lo                 // 000000134534: 020270FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013453C: BF8700A1
	v_add_co_ci_u32_e64 v59, null, 0, v57, s1                  // 000000134540: D5207C3B 00067280
	.long 0xd7000106                                           // 000000134548: D7000106
	v_cndmask_b32_e32 v1, s12, v56, vcc_lo                     // 00000013454C: 0202700C
	v_add_co_ci_u32_e64 v7, null, s13, v57, s1                 // 000000134550: D5207C07 0006720D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134558: BF870094
	.long 0xd7000108                                           // 00000013455C: D7000108
	v_cndmask_b32_e32 v1, s12, v58, vcc_lo                     // 000000134560: 0202740C
	v_add_co_ci_u32_e64 v9, null, s13, v59, s1                 // 000000134564: D5207C09 0006760D
	.long 0xd700013c                                           // 00000013456C: D700013C
	v_cndmask_b32_e32 v1, 0x60000, v56, vcc_lo                 // 000000134570: 020270FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134578: BF8700A1
	v_add_co_ci_u32_e64 v61, null, 0, v57, s1                  // 00000013457C: D5207C3D 00067280
	.long 0xd700013e                                           // 000000134584: D700013E
	v_cndmask_b32_e32 v1, 0x90000, v56, vcc_lo                 // 000000134588: 020270FF 00090000
	v_add_co_ci_u32_e64 v63, null, 0, v57, s1                  // 000000134590: D5207C3F 00067280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134598: BF870094
	.long 0xd700010a                                           // 00000013459C: D700010A
	v_cndmask_b32_e32 v1, s12, v60, vcc_lo                     // 0000001345A0: 0202780C
	v_add_co_ci_u32_e64 v11, null, s13, v61, s1                // 0000001345A4: D5207C0B 00067A0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001345AC: BF870094
	.long 0xd700010c                                           // 0000001345B0: D700010C
	v_cndmask_b32_e32 v1, s12, v62, vcc_lo                     // 0000001345B4: 02027C0C
	v_add_co_ci_u32_e64 v13, null, s13, v63, s1                // 0000001345B8: D5207C0D 00067E0D
	.long 0xd7000140                                           // 0000001345C0: D7000140
	v_cndmask_b32_e32 v1, 0xc0000, v56, vcc_lo                 // 0000001345C4: 020270FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001345CC: BF8700A1
	v_add_co_ci_u32_e64 v65, null, 0, v57, s1                  // 0000001345D0: D5207C41 00067280
	.long 0xd7000142                                           // 0000001345D8: D7000142
	v_cndmask_b32_e32 v1, 0xf0000, v56, vcc_lo                 // 0000001345DC: 020270FF 000F0000
	v_add_co_ci_u32_e64 v67, null, 0, v57, s1                  // 0000001345E4: D5207C43 00067280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001345EC: BF870094
	.long 0xd7000110                                           // 0000001345F0: D7000110
	v_cndmask_b32_e32 v1, s12, v64, vcc_lo                     // 0000001345F4: 0202800C
	v_add_co_ci_u32_e64 v17, null, s13, v65, s1                // 0000001345F8: D5207C11 0006820D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134600: BF870094
	.long 0xd7000112                                           // 000000134604: D7000112
	v_cndmask_b32_e32 v1, s12, v66, vcc_lo                     // 000000134608: 0202840C
	v_add_co_ci_u32_e64 v19, null, s13, v67, s1                // 00000013460C: D5207C13 0006860D
	.long 0xd7000144                                           // 000000134614: D7000144
	v_cndmask_b32_e32 v1, 0x120000, v56, vcc_lo                // 000000134618: 020270FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134620: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v57, s1                  // 000000134624: D5207C45 00067280
	.long 0xd7000146                                           // 00000013462C: D7000146
	v_cndmask_b32_e32 v1, 0x150000, v56, vcc_lo                // 000000134630: 020270FF 00150000
	v_add_co_ci_u32_e64 v71, null, 0, v57, s1                  // 000000134638: D5207C47 00067280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134640: BF870094
	.long 0xd7000114                                           // 000000134644: D7000114
	v_cndmask_b32_e32 v1, s12, v68, vcc_lo                     // 000000134648: 0202880C
	v_add_co_ci_u32_e64 v21, null, s13, v69, s1                // 00000013464C: D5207C15 00068A0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134654: BF870094
	.long 0xd7000116                                           // 000000134658: D7000116
	v_cndmask_b32_e32 v1, s12, v70, vcc_lo                     // 00000013465C: 02028C0C
	v_add_co_ci_u32_e64 v23, null, s13, v71, s1                // 000000134660: D5207C17 00068E0D
	.long 0xd7000118                                           // 000000134668: D7000118
	v_cndmask_b32_e32 v1, s4, v56, vcc_lo                      // 00000013466C: 02027004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000134670: BF8700C1
	v_add_co_ci_u32_e64 v25, null, s5, v57, s1                 // 000000134674: D5207C19 00067205
	s_add_u32 s1, s14, s10                                     // 00000013467C: 80010A0E
	s_addc_u32 s10, s15, s11                                   // 000000134680: 820A0B0F
	.long 0xd700011a                                           // 000000134684: D700011A
	v_cndmask_b32_e32 v1, s1, v26, vcc_lo                      // 000000134688: 02023401
	v_add_co_ci_u32_e64 v27, null, s10, 0, s1                  // 00000013468C: D5207C1B 0005000A
	.long 0xd700011c                                           // 000000134694: D700011C
	v_cndmask_b32_e32 v1, s4, v58, vcc_lo                      // 000000134698: 02027404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000013469C: BF870211
	v_add_co_ci_u32_e64 v29, null, s5, v59, s1                 // 0000001346A0: D5207C1D 00067605
	.long 0xd700011e                                           // 0000001346A8: D700011E
	v_cndmask_b32_e32 v1, 0x800, v26, vcc_lo                   // 0000001346AC: 020234FF 00000800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001346B4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v27, s1                  // 0000001346B8: D5207C1F 00063680
	.long 0xd7000120                                           // 0000001346C0: D7000120
	v_cndmask_b32_e32 v1, s4, v60, vcc_lo                      // 0000001346C4: 02027804
	v_add_co_ci_u32_e64 v33, null, s5, v61, s1                 // 0000001346C8: D5207C21 00067A05
	.long 0xd7000122                                           // 0000001346D0: D7000122
	v_cndmask_b32_e32 v1, 0x1000, v26, vcc_lo                  // 0000001346D4: 020234FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001346DC: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v27, s1                  // 0000001346E0: D5207C23 00063680
	.long 0xd7000124                                           // 0000001346E8: D7000124
	v_cndmask_b32_e32 v1, s4, v62, vcc_lo                      // 0000001346EC: 02027C04
	v_add_co_ci_u32_e64 v37, null, s5, v63, s1                 // 0000001346F0: D5207C25 00067E05
	.long 0xd7000126                                           // 0000001346F8: D7000126
	v_cndmask_b32_e32 v1, 0x1800, v26, vcc_lo                  // 0000001346FC: 020234FF 00001800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134704: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v27, s1                  // 000000134708: D5207C27 00063680
	.long 0xd7000128                                           // 000000134710: D7000128
	v_cndmask_b32_e32 v1, s4, v64, vcc_lo                      // 000000134714: 02028004
	v_add_co_ci_u32_e64 v41, null, s5, v65, s1                 // 000000134718: D5207C29 00068205
	.long 0xd700012a                                           // 000000134720: D700012A
	v_cndmask_b32_e32 v1, 0x2000, v26, vcc_lo                  // 000000134724: 020234FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013472C: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v27, s1                  // 000000134730: D5207C2B 00063680
	.long 0xd700012c                                           // 000000134738: D700012C
	v_cndmask_b32_e32 v1, s4, v66, vcc_lo                      // 00000013473C: 02028404
	v_add_co_ci_u32_e64 v45, null, s5, v67, s1                 // 000000134740: D5207C2D 00068605
	.long 0xd700012e                                           // 000000134748: D700012E
	v_cndmask_b32_e32 v1, 0x2800, v26, vcc_lo                  // 00000013474C: 020234FF 00002800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134754: BF8700A1
	v_add_co_ci_u32_e64 v47, null, 0, v27, s1                  // 000000134758: D5207C2F 00063680
	.long 0xd7000130                                           // 000000134760: D7000130
	v_cndmask_b32_e32 v1, s4, v68, vcc_lo                      // 000000134764: 02028804
	v_add_co_ci_u32_e64 v49, null, s5, v69, s1                 // 000000134768: D5207C31 00068A05
	.long 0xd7000132                                           // 000000134770: D7000132
	v_cndmask_b32_e32 v1, 0x3000, v26, vcc_lo                  // 000000134774: 020234FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013477C: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v27, s1                  // 000000134780: D5207C33 00063680
	.long 0xd7000134                                           // 000000134788: D7000134
	v_cndmask_b32_e32 v1, s4, v70, vcc_lo                      // 00000013478C: 02028C04
	v_add_co_ci_u32_e64 v53, null, s5, v71, s1                 // 000000134790: D5207C35 00068E05
	.long 0xd7000136                                           // 000000134798: D7000136
	v_cndmask_b32_e32 v1, 0x3800, v26, vcc_lo                  // 00000013479C: 020234FF 00003800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001347A4: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v27, s1                  // 0000001347A8: D5207C37 00063680
	.long 0xd7000138                                           // 0000001347B0: D7000138
	v_cndmask_b32_e32 v1, s6, v56, vcc_lo                      // 0000001347B4: 02027006
	v_add_co_ci_u32_e64 v57, null, s7, v57, s1                 // 0000001347B8: D5207C39 00067207
	.long 0xd700013a                                           // 0000001347C0: D700013A
	v_cndmask_b32_e32 v1, s6, v58, vcc_lo                      // 0000001347C4: 02027406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001347C8: BF8700A1
	v_add_co_ci_u32_e64 v59, null, s7, v59, s1                 // 0000001347CC: D5207C3B 00067607
	.long 0xd700013c                                           // 0000001347D4: D700013C
	v_cndmask_b32_e32 v1, s6, v60, vcc_lo                      // 0000001347D8: 02027806
	v_add_co_ci_u32_e64 v61, null, s7, v61, s1                 // 0000001347DC: D5207C3D 00067A07
	.long 0xd700013e                                           // 0000001347E4: D700013E
	v_cndmask_b32_e32 v1, s6, v62, vcc_lo                      // 0000001347E8: 02027C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001347EC: BF8700A1
	v_add_co_ci_u32_e64 v63, null, s7, v63, s1                 // 0000001347F0: D5207C3F 00067E07
	.long 0xd7000140                                           // 0000001347F8: D7000140
	v_cndmask_b32_e32 v1, s6, v64, vcc_lo                      // 0000001347FC: 02028006
	v_add_co_ci_u32_e64 v65, null, s7, v65, s1                 // 000000134800: D5207C41 00068207
	.long 0xd7000142                                           // 000000134808: D7000142
	v_cndmask_b32_e32 v1, s6, v66, vcc_lo                      // 00000013480C: 02028406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134810: BF8700A1
	v_add_co_ci_u32_e64 v67, null, s7, v67, s1                 // 000000134814: D5207C43 00068607
	.long 0xd7000144                                           // 00000013481C: D7000144
	v_cndmask_b32_e32 v1, s6, v68, vcc_lo                      // 000000134820: 02028806
	v_add_co_ci_u32_e64 v69, null, s7, v69, s1                 // 000000134824: D5207C45 00068A07
	.long 0xd7000146                                           // 00000013482C: D7000146
	v_cndmask_b32_e32 v1, s6, v70, vcc_lo                      // 000000134830: 02028C06
	v_dual_mov_b32 v14, v1 :: v_dual_add_nc_u32 v85, 0x4380, v3// 000000134834: CA200101 0E5406FF 00004380
	.long 0xd44c0000                                           // 000000134840: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000134844: 020200FF 00000080
	v_lshl_or_b32 v90, v1, 2, 0x4380                           // 00000013484C: D656005A 03FD0501 00004380
	v_or_b32_e32 v91, 8, v1                                    // 000000134858: 38B60288
	v_or_b32_e32 v92, 16, v1                                   // 00000013485C: 38B80290
	v_or_b32_e32 v93, 24, v1                                   // 000000134860: 38BA0298
	v_or_b32_e32 v94, 32, v1                                   // 000000134864: 38BC02A0
	v_or_b32_e32 v95, 40, v1                                   // 000000134868: 38BE02A8
	v_or_b32_e32 v96, 48, v1                                   // 00000013486C: 38C002B0
	v_or_b32_e32 v97, 56, v1                                   // 000000134870: 38C202B8
	v_add_nc_u32_e32 v2, 9, v1                                 // 000000134874: 4A040289
	v_add_nc_u32_e32 v99, 17, v1                               // 000000134878: 4AC60291
	v_add_nc_u32_e32 v100, 25, v1                              // 00000013487C: 4AC80299
	v_add_nc_u32_e32 v101, 33, v1                              // 000000134880: 4ACA02A1
	v_add_nc_u32_e32 v102, 41, v1                              // 000000134884: 4ACC02A9
	v_add_nc_u32_e32 v103, 49, v1                              // 000000134888: 4ACE02B1
	v_add_nc_u32_e32 v104, 57, v1                              // 00000013488C: 4AD002B9
	v_add_co_ci_u32_e64 v71, null, s7, v71, s1                 // 000000134890: D5207C47 00068E07
	s_mov_b32 s5, 0                                            // 000000134898: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000013489C: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000001348A0: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001348A8: BF870499
	s_add_i32 s6, s31, s1                                      // 0000001348AC: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000001348B0: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001348B4: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000001348B8: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000001348BC: 84078605
	s_add_u32 s10, s8, s10                                     // 0000001348C0: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000001348C4: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000001348C8: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001348D0: BE84206A
	s_cbranch_execz 77                                         // 0000001348D4: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x70c>
	v_or_b32_e32 v72, s7, v0                                   // 0000001348D8: 38900007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001348DC: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 0000001348E0: D6FE7C48 00096148
	v_ashrrev_i32_e32 v73, 31, v72                             // 0000001348E8: 3492909F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001348EC: BF870091
	.long 0xd73c0048                                           // 0000001348F0: D73C0048
	v_cndmask_b32_e32 v1, 2, v72, vcc_lo                       // 0000001348F4: 02029082
	.long 0xd7000148                                           // 0000001348F8: D7000148
	v_cndmask_b32_e32 v1, s8, v72, vcc_lo                      // 0000001348FC: 02029008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000134900: BF8700C1
	v_add_co_ci_u32_e64 v73, null, s9, v73, s1                 // 000000134904: D5207C49 00069209
	global_load_b32 v72, v[72:73], off                         // 00000013490C: DC520000 487C0048
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134914: BF890007
	v_sub_f32_e32 v73, s6, v72                                 // 000000134918: 08929006
	v_dual_mul_f32 v75, 0x3fb8aa3b, v72 :: v_dual_mul_f32 v74, 0x3fb8aa3b, v73// 00000013491C: C8C690FF 4B4A92FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000134928: BF8701A1
	v_fma_f32 v78, 0x3fb8aa3b, v72, -v75                       // 00000013492C: D613004E 852E90FF 3FB8AA3B
	v_rndne_f32_e32 v79, v75                                   // 000000134938: 7E9E474B
	v_fma_f32 v76, 0x3fb8aa3b, v73, -v74                       // 00000013493C: D613004C 852A92FF 3FB8AA3B
	v_rndne_f32_e32 v77, v74                                   // 000000134948: 7E9A474A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013494C: BF870113
	v_dual_fmac_f32 v78, 0x32a5705f, v72 :: v_dual_sub_f32 v75, v75, v79// 000000134950: C80A90FF 4E4A9F4B 32A5705F
	v_sub_f32_e32 v74, v74, v77                                // 00000013495C: 08949B4A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000134960: BF870124
	v_fmac_f32_e32 v76, 0x32a5705f, v73                        // 000000134964: 569892FF 32A5705F
	.long 0xd41b0001                                           // 00000013496C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 000000134970: 020292FF C2CE8ED0
	v_dual_add_f32 v75, v75, v78 :: v_dual_add_f32 v74, v74, v76// 000000134978: C9089D4B 4B4A994A
	v_cvt_i32_f32_e32 v76, v77                                 // 000000134980: 7E98114D
	v_cvt_i32_f32_e32 v77, v79                                 // 000000134984: 7E9A114F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000134988: BF870193
	v_exp_f32_e32 v75, v75                                     // 00000013498C: 7E964B4B
	v_exp_f32_e32 v74, v74                                     // 000000134990: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000134994: BF870296
	.long 0xd71c004b                                           // 000000134998: D71C004B
	v_cndmask_b32_e32 v1, v75, v77, vcc_lo                     // 00000013499C: 02029B4B
	.long 0xd71c004a                                           // 0000001349A0: D71C004A
	v_cndmask_b32_e32 v1, v74, v76, vcc_lo                     // 0000001349A4: 0202994A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001349A8: BF8700A1
	v_cndmask_b32_e64 v74, 0, v74, s1                          // 0000001349AC: D501004A 00069480
	.long 0xd41b0001                                           // 0000001349B4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v72, vcc_lo              // 0000001349B8: 020290FF C2CE8ED0
	v_cndmask_b32_e64 v75, 0, v75, s1                          // 0000001349C0: D501004B 00069680
	.long 0xd41e0001                                           // 0000001349C8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001349CC: 020292FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001349D4: BF8700A1
	v_cndmask_b32_e64 v73, 0x7f800000, v74, s1                 // 0000001349D8: D5010049 000694FF 7F800000
	.long 0xd41e0001                                           // 0000001349E4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v72, vcc_lo              // 0000001349E8: 020290FF 42B17218
	v_cndmask_b32_e64 v72, 0x7f800000, v75, s1                 // 0000001349F0: D5010048 000696FF 7F800000
	ds_store_b32 v84, v73                                      // 0000001349FC: D8340000 00004954
	ds_store_b32 v85, v72                                      // 000000134A04: D8340000 00004855
	s_or_b32 exec_lo, exec_lo, s4                              // 000000134A0C: 8C7E047E
	v_dual_mov_b32 v73, v7 :: v_dual_mov_b32 v72, v6           // 000000134A10: CA100107 49480106
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000134A18: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000134A20: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000134A24: BF89FC07
	s_barrier                                                  // 000000134A28: BFBD0000
	buffer_gl0_inv                                             // 000000134A2C: E0AC0000 00000000
	s_nop 0                                                    // 000000134A34: BF800000
	s_nop 0                                                    // 000000134A38: BF800000
	s_nop 0                                                    // 000000134A3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000134A40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000134A48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000134A50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000134A54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000134A5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000134A60: D5207C49 00069280
	.long 0xd4490004                                           // 000000134A68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000134A6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000134A74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000134A78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000134A7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000134A84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000134A8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000134A90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x740>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000134A94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000134A98: BF89FC07
	s_barrier                                                  // 000000134A9C: BFBD0000
	buffer_gl0_inv                                             // 000000134AA0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000134AA8: BE842000
	s_cbranch_execz 141                                        // 000000134AAC: BFA5008D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9e4>
	v_or_b32_e32 v72, s7, v1                                   // 000000134AB0: 38900207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134AB4: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 000000134AB8: D6FE7C48 00096148
	.long 0xd73c0048                                           // 000000134AC0: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 000000134AC4: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134AC8: BF870091
	.long 0xd7000148                                           // 000000134ACC: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 000000134AD0: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 000000134AD4: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 000000134ADC: BE810080
	global_load_b32 v72, v[72:73], off                         // 000000134AE0: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 000000134AE8: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134AEC: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 000000134AF0: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 000000134AF4: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 000000134AF8: 810AA001
	s_cmpk_gt_u32 s1, 0x5f                                     // 000000134AFC: B581005F
	s_mov_b32 s1, s10                                          // 000000134B00: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000134B04: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000134B0C: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000134B14: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000134B1C: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000134B24: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 000000134B28: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134B30: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000134B34: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000134B3C: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134B44: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 000000134B48: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000134B50: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000134B54: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134B5C: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000134B60: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 000000134B68: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134B70: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000134B74: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000134B7C: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000134B84: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000134B8C: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000134B94: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 000000134B9C: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 000000134BA0: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134BA8: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 000000134BAC: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 000000134BB4: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134BBC: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 000000134BC0: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000134BC8: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 000000134BCC: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134BD4: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 000000134BD8: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 000000134BE0: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000134BE8: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 000000134BEC: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 000000134BF4: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000134BFC: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000134C04: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 000000134C08: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000134C10: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134C18: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000134C1C: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000134C24: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000134C2C: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000134C34: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000134C3C: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000134C44: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000134C4C: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000134C50: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134C58: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000134C5C: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000134C64: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000134C6C: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000134C70: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 000000134C78: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000134C80: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 000000134C88: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000134C90: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134C98: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000134C9C: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 000000134CA4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000134CAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134CB0: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 000000134CB4: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 000000134CBC: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134CC4: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 000000134CC8: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 000000134CD0: D6130048 2522E16C
	s_cbranch_scc0 65411                                       // 000000134CD8: BFA1FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7e8>
	ds_store_b32 v89, v72                                      // 000000134CDC: D8340000 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 000000134CE4: 8C7E047E
	v_dual_mov_b32 v73, v9 :: v_dual_mov_b32 v72, v8           // 000000134CE8: CA100109 49480108
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000134CF0: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000134CF8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000134CFC: BF89FC07
	s_barrier                                                  // 000000134D00: BFBD0000
	buffer_gl0_inv                                             // 000000134D04: E0AC0000 00000000
	s_nop 0                                                    // 000000134D0C: BF800000
	s_nop 0                                                    // 000000134D10: BF800000
	s_nop 0                                                    // 000000134D14: BF800000
	s_nop 0                                                    // 000000134D18: BF800000
	s_nop 0                                                    // 000000134D1C: BF800000
	s_nop 0                                                    // 000000134D20: BF800000
	s_nop 0                                                    // 000000134D24: BF800000
	s_nop 0                                                    // 000000134D28: BF800000
	s_nop 0                                                    // 000000134D2C: BF800000
	s_nop 0                                                    // 000000134D30: BF800000
	s_nop 0                                                    // 000000134D34: BF800000
	s_nop 0                                                    // 000000134D38: BF800000
	s_nop 0                                                    // 000000134D3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000134D40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000134D48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000134D50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000134D54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000134D5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000134D60: D5207C49 00069280
	.long 0xd4490004                                           // 000000134D68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000134D6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000134D74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000134D78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000134D7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000134D84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000134D8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000134D90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000134D94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000134D98: BF89FC07
	s_barrier                                                  // 000000134D9C: BFBD0000
	buffer_gl0_inv                                             // 000000134DA0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000134DA8: BE842000
	s_cbranch_execz 142                                        // 000000134DAC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xce8>
	v_add3_u32 v72, v1, s7, 8                                  // 000000134DB0: D6550048 02200F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134DB8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 000000134DBC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 000000134DC4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 000000134DC8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134DCC: BF870091
	.long 0xd7000148                                           // 000000134DD0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 000000134DD4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 000000134DD8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 000000134DE0: BE810080
	global_load_b32 v72, v[72:73], off                         // 000000134DE4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 000000134DEC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134DF0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 000000134DF4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 000000134DF8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 000000134DFC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000134E00: B6810060
	s_mov_b32 s1, s10                                          // 000000134E04: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000134E08: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000134E10: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000134E18: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000134E20: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000134E28: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 000000134E2C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134E34: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000134E38: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000134E40: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134E48: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 000000134E4C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000134E54: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000134E58: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134E60: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000134E64: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 000000134E6C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134E74: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000134E78: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000134E80: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000134E88: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000134E90: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000134E98: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 000000134EA0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 000000134EA4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134EAC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 000000134EB0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 000000134EB8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134EC0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 000000134EC4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000134ECC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 000000134ED0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134ED8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 000000134EDC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 000000134EE4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000134EEC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 000000134EF0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 000000134EF8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000134F00: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000134F08: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 000000134F0C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000134F14: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134F1C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000134F20: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000134F28: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000134F30: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000134F38: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000134F40: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000134F48: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000134F50: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000134F54: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134F5C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000134F60: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000134F68: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000134F70: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000134F74: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 000000134F7C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000134F84: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 000000134F8C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000134F94: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134F9C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000134FA0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 000000134FA8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000134FB0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134FB4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 000000134FB8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 000000134FC0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134FC8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 000000134FCC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 000000134FD4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 000000134FDC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xaec>
	ds_store_b32 v89, v72 offset:544                           // 000000134FE0: D8340220 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 000000134FE8: 8C7E047E
	v_dual_mov_b32 v73, v11 :: v_dual_mov_b32 v72, v10         // 000000134FEC: CA10010B 4948010A
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000134FF4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000134FFC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135000: BF89FC07
	s_barrier                                                  // 000000135004: BFBD0000
	buffer_gl0_inv                                             // 000000135008: E0AC0000 00000000
	s_nop 0                                                    // 000000135010: BF800000
	s_nop 0                                                    // 000000135014: BF800000
	s_nop 0                                                    // 000000135018: BF800000
	s_nop 0                                                    // 00000013501C: BF800000
	s_nop 0                                                    // 000000135020: BF800000
	s_nop 0                                                    // 000000135024: BF800000
	s_nop 0                                                    // 000000135028: BF800000
	s_nop 0                                                    // 00000013502C: BF800000
	s_nop 0                                                    // 000000135030: BF800000
	s_nop 0                                                    // 000000135034: BF800000
	s_nop 0                                                    // 000000135038: BF800000
	s_nop 0                                                    // 00000013503C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135040: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135048: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135050: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135054: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013505C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135060: D5207C49 00069280
	.long 0xd4490004                                           // 000000135068: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013506C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135074: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135078: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013507C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135084: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013508C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135090: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135094: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135098: BF89FC07
	s_barrier                                                  // 00000013509C: BFBD0000
	buffer_gl0_inv                                             // 0000001350A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000001350A8: BE842000
	s_cbranch_execz 142                                        // 0000001350AC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfe8>
	v_add3_u32 v72, v1, s7, 16                                 // 0000001350B0: D6550048 02400F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001350B8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 0000001350BC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 0000001350C4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001350C8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001350CC: BF870091
	.long 0xd7000148                                           // 0000001350D0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 0000001350D4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 0000001350D8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 0000001350E0: BE810080
	global_load_b32 v72, v[72:73], off                         // 0000001350E4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 0000001350EC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001350F0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 0000001350F4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 0000001350F8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 0000001350FC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000135100: B6810060
	s_mov_b32 s1, s10                                          // 000000135104: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000135108: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000135110: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000135118: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000135120: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000135128: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 00000013512C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135134: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000135138: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000135140: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135148: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 00000013514C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000135154: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000135158: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135160: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000135164: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 00000013516C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135174: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000135178: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000135180: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000135188: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000135190: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000135198: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 0000001351A0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 0000001351A4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001351AC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 0000001351B0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 0000001351B8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001351C0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 0000001351C4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001351CC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 0000001351D0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001351D8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 0000001351DC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 0000001351E4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001351EC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 0000001351F0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 0000001351F8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000135200: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000135208: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 00000013520C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135214: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013521C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135220: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000135228: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000135230: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000135238: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000135240: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000135248: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000135250: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000135254: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013525C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000135260: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000135268: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000135270: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000135274: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 00000013527C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000135284: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 00000013528C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135294: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013529C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 0000001352A0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 0000001352A8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001352B0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001352B4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 0000001352B8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 0000001352C0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001352C8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 0000001352CC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 0000001352D4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 0000001352DC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdec>
	ds_store_b32 v89, v72 offset:1088                          // 0000001352E0: D8340440 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001352E8: 8C7E047E
	v_dual_mov_b32 v73, v13 :: v_dual_mov_b32 v72, v12         // 0000001352EC: CA10010D 4948010C
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 0000001352F4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 0000001352FC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135300: BF89FC07
	s_barrier                                                  // 000000135304: BFBD0000
	buffer_gl0_inv                                             // 000000135308: E0AC0000 00000000
	s_nop 0                                                    // 000000135310: BF800000
	s_nop 0                                                    // 000000135314: BF800000
	s_nop 0                                                    // 000000135318: BF800000
	s_nop 0                                                    // 00000013531C: BF800000
	s_nop 0                                                    // 000000135320: BF800000
	s_nop 0                                                    // 000000135324: BF800000
	s_nop 0                                                    // 000000135328: BF800000
	s_nop 0                                                    // 00000013532C: BF800000
	s_nop 0                                                    // 000000135330: BF800000
	s_nop 0                                                    // 000000135334: BF800000
	s_nop 0                                                    // 000000135338: BF800000
	s_nop 0                                                    // 00000013533C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135340: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135348: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135350: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135354: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013535C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135360: D5207C49 00069280
	.long 0xd4490004                                           // 000000135368: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013536C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135374: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135378: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013537C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135384: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013538C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135390: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1040>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135394: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135398: BF89FC07
	s_barrier                                                  // 00000013539C: BFBD0000
	buffer_gl0_inv                                             // 0000001353A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000001353A8: BE842000
	s_cbranch_execz 142                                        // 0000001353AC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12e8>
	v_add3_u32 v72, v1, s7, 24                                 // 0000001353B0: D6550048 02600F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001353B8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 0000001353BC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 0000001353C4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001353C8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001353CC: BF870091
	.long 0xd7000148                                           // 0000001353D0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 0000001353D4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 0000001353D8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 0000001353E0: BE810080
	global_load_b32 v72, v[72:73], off                         // 0000001353E4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 0000001353EC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001353F0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 0000001353F4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 0000001353F8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 0000001353FC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000135400: B6810060
	s_mov_b32 s1, s10                                          // 000000135404: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000135408: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000135410: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000135418: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000135420: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000135428: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 00000013542C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135434: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000135438: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000135440: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135448: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 00000013544C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000135454: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000135458: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135460: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000135464: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 00000013546C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135474: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000135478: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000135480: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000135488: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000135490: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000135498: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 0000001354A0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 0000001354A4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001354AC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 0000001354B0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 0000001354B8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001354C0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 0000001354C4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001354CC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 0000001354D0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001354D8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 0000001354DC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 0000001354E4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001354EC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 0000001354F0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 0000001354F8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000135500: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000135508: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 00000013550C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135514: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013551C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135520: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000135528: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000135530: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000135538: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000135540: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000135548: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000135550: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000135554: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013555C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000135560: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000135568: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000135570: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000135574: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 00000013557C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000135584: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 00000013558C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135594: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013559C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 0000001355A0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 0000001355A8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001355B0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001355B4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 0000001355B8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 0000001355C0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001355C8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 0000001355CC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 0000001355D4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 0000001355DC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10ec>
	ds_store_b32 v89, v72 offset:1632                          // 0000001355E0: D8340660 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001355E8: 8C7E047E
	v_dual_mov_b32 v73, v17 :: v_dual_mov_b32 v72, v16         // 0000001355EC: CA100111 49480110
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 0000001355F4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 0000001355FC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135600: BF89FC07
	s_barrier                                                  // 000000135604: BFBD0000
	buffer_gl0_inv                                             // 000000135608: E0AC0000 00000000
	s_nop 0                                                    // 000000135610: BF800000
	s_nop 0                                                    // 000000135614: BF800000
	s_nop 0                                                    // 000000135618: BF800000
	s_nop 0                                                    // 00000013561C: BF800000
	s_nop 0                                                    // 000000135620: BF800000
	s_nop 0                                                    // 000000135624: BF800000
	s_nop 0                                                    // 000000135628: BF800000
	s_nop 0                                                    // 00000013562C: BF800000
	s_nop 0                                                    // 000000135630: BF800000
	s_nop 0                                                    // 000000135634: BF800000
	s_nop 0                                                    // 000000135638: BF800000
	s_nop 0                                                    // 00000013563C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135640: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135648: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135650: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135654: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013565C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135660: D5207C49 00069280
	.long 0xd4490004                                           // 000000135668: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013566C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135674: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135678: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013567C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135684: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013568C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135690: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135694: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135698: BF89FC07
	s_barrier                                                  // 00000013569C: BFBD0000
	buffer_gl0_inv                                             // 0000001356A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000001356A8: BE842000
	s_cbranch_execz 142                                        // 0000001356AC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15e8>
	v_add3_u32 v72, v1, s7, 32                                 // 0000001356B0: D6550048 02800F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001356B8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 0000001356BC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 0000001356C4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001356C8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001356CC: BF870091
	.long 0xd7000148                                           // 0000001356D0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 0000001356D4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 0000001356D8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 0000001356E0: BE810080
	global_load_b32 v72, v[72:73], off                         // 0000001356E4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 0000001356EC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001356F0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 0000001356F4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 0000001356F8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 0000001356FC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000135700: B6810060
	s_mov_b32 s1, s10                                          // 000000135704: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000135708: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000135710: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000135718: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000135720: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000135728: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 00000013572C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135734: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000135738: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000135740: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135748: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 00000013574C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000135754: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000135758: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135760: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000135764: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 00000013576C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135774: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000135778: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000135780: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000135788: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000135790: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000135798: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 0000001357A0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 0000001357A4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001357AC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 0000001357B0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 0000001357B8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001357C0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 0000001357C4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001357CC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 0000001357D0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001357D8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 0000001357DC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 0000001357E4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001357EC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 0000001357F0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 0000001357F8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000135800: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000135808: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 00000013580C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135814: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013581C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135820: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000135828: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000135830: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000135838: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000135840: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000135848: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000135850: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000135854: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013585C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000135860: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000135868: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000135870: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000135874: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 00000013587C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000135884: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 00000013588C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135894: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013589C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 0000001358A0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 0000001358A8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001358B0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001358B4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 0000001358B8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 0000001358C0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001358C8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 0000001358CC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 0000001358D4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 0000001358DC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13ec>
	ds_store_b32 v89, v72 offset:2176                          // 0000001358E0: D8340880 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001358E8: 8C7E047E
	v_dual_mov_b32 v73, v19 :: v_dual_mov_b32 v72, v18         // 0000001358EC: CA100113 49480112
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 0000001358F4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 0000001358FC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135900: BF89FC07
	s_barrier                                                  // 000000135904: BFBD0000
	buffer_gl0_inv                                             // 000000135908: E0AC0000 00000000
	s_nop 0                                                    // 000000135910: BF800000
	s_nop 0                                                    // 000000135914: BF800000
	s_nop 0                                                    // 000000135918: BF800000
	s_nop 0                                                    // 00000013591C: BF800000
	s_nop 0                                                    // 000000135920: BF800000
	s_nop 0                                                    // 000000135924: BF800000
	s_nop 0                                                    // 000000135928: BF800000
	s_nop 0                                                    // 00000013592C: BF800000
	s_nop 0                                                    // 000000135930: BF800000
	s_nop 0                                                    // 000000135934: BF800000
	s_nop 0                                                    // 000000135938: BF800000
	s_nop 0                                                    // 00000013593C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135940: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135948: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135950: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135954: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013595C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135960: D5207C49 00069280
	.long 0xd4490004                                           // 000000135968: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013596C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135974: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135978: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013597C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135984: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013598C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135990: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1640>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135994: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135998: BF89FC07
	s_barrier                                                  // 00000013599C: BFBD0000
	buffer_gl0_inv                                             // 0000001359A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000001359A8: BE842000
	s_cbranch_execz 142                                        // 0000001359AC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18e8>
	v_add3_u32 v72, v1, s7, 40                                 // 0000001359B0: D6550048 02A00F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001359B8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 0000001359BC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 0000001359C4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001359C8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001359CC: BF870091
	.long 0xd7000148                                           // 0000001359D0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 0000001359D4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 0000001359D8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 0000001359E0: BE810080
	global_load_b32 v72, v[72:73], off                         // 0000001359E4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 0000001359EC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001359F0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 0000001359F4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 0000001359F8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 0000001359FC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000135A00: B6810060
	s_mov_b32 s1, s10                                          // 000000135A04: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000135A08: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000135A10: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000135A18: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000135A20: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000135A28: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 000000135A2C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135A34: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000135A38: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000135A40: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135A48: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 000000135A4C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000135A54: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000135A58: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135A60: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000135A64: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 000000135A6C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135A74: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000135A78: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000135A80: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000135A88: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000135A90: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000135A98: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 000000135AA0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 000000135AA4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135AAC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 000000135AB0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 000000135AB8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135AC0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 000000135AC4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000135ACC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 000000135AD0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135AD8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 000000135ADC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 000000135AE4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000135AEC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 000000135AF0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 000000135AF8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000135B00: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000135B08: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 000000135B0C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135B14: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B1C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135B20: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000135B28: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000135B30: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000135B38: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000135B40: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000135B48: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000135B50: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000135B54: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B5C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000135B60: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000135B68: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000135B70: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000135B74: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 000000135B7C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000135B84: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 000000135B8C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135B94: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B9C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135BA0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 000000135BA8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000135BB0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135BB4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 000000135BB8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 000000135BC0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135BC8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 000000135BCC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 000000135BD4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 000000135BDC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16ec>
	ds_store_b32 v89, v72 offset:2720                          // 000000135BE0: D8340AA0 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 000000135BE8: 8C7E047E
	v_dual_mov_b32 v73, v21 :: v_dual_mov_b32 v72, v20         // 000000135BEC: CA100115 49480114
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000135BF4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000135BFC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135C00: BF89FC07
	s_barrier                                                  // 000000135C04: BFBD0000
	buffer_gl0_inv                                             // 000000135C08: E0AC0000 00000000
	s_nop 0                                                    // 000000135C10: BF800000
	s_nop 0                                                    // 000000135C14: BF800000
	s_nop 0                                                    // 000000135C18: BF800000
	s_nop 0                                                    // 000000135C1C: BF800000
	s_nop 0                                                    // 000000135C20: BF800000
	s_nop 0                                                    // 000000135C24: BF800000
	s_nop 0                                                    // 000000135C28: BF800000
	s_nop 0                                                    // 000000135C2C: BF800000
	s_nop 0                                                    // 000000135C30: BF800000
	s_nop 0                                                    // 000000135C34: BF800000
	s_nop 0                                                    // 000000135C38: BF800000
	s_nop 0                                                    // 000000135C3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135C40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135C48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135C50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135C54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000135C5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135C60: D5207C49 00069280
	.long 0xd4490004                                           // 000000135C68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000135C6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135C74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135C78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000135C7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135C84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000135C8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135C90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135C94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135C98: BF89FC07
	s_barrier                                                  // 000000135C9C: BFBD0000
	buffer_gl0_inv                                             // 000000135CA0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000135CA8: BE842000
	s_cbranch_execz 142                                        // 000000135CAC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1be8>
	v_add3_u32 v72, v1, s7, 48                                 // 000000135CB0: D6550048 02C00F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135CB8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 000000135CBC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 000000135CC4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 000000135CC8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135CCC: BF870091
	.long 0xd7000148                                           // 000000135CD0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 000000135CD4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 000000135CD8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 000000135CE0: BE810080
	global_load_b32 v72, v[72:73], off                         // 000000135CE4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 000000135CEC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135CF0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 000000135CF4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 000000135CF8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 000000135CFC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000135D00: B6810060
	s_mov_b32 s1, s10                                          // 000000135D04: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000135D08: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000135D10: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000135D18: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000135D20: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000135D28: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 000000135D2C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D34: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000135D38: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000135D40: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135D48: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 000000135D4C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000135D54: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000135D58: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D60: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000135D64: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 000000135D6C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135D74: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000135D78: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000135D80: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000135D88: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000135D90: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000135D98: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 000000135DA0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 000000135DA4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135DAC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 000000135DB0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 000000135DB8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135DC0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 000000135DC4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000135DCC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 000000135DD0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135DD8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 000000135DDC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 000000135DE4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000135DEC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 000000135DF0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 000000135DF8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000135E00: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000135E08: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 000000135E0C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135E14: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135E1C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135E20: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000135E28: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000135E30: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000135E38: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000135E40: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000135E48: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000135E50: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000135E54: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135E5C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000135E60: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000135E68: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000135E70: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000135E74: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 000000135E7C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000135E84: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 000000135E8C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000135E94: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135E9C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000135EA0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 000000135EA8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 000000135EB0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135EB4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 000000135EB8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 000000135EC0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135EC8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 000000135ECC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 000000135ED4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 000000135EDC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19ec>
	ds_store_b32 v89, v72 offset:3264                          // 000000135EE0: D8340CC0 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 000000135EE8: 8C7E047E
	v_dual_mov_b32 v73, v23 :: v_dual_mov_b32 v72, v22         // 000000135EEC: CA100117 49480116
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000135EF4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000135EFC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000135F00: BF89FC07
	s_barrier                                                  // 000000135F04: BFBD0000
	buffer_gl0_inv                                             // 000000135F08: E0AC0000 00000000
	s_nop 0                                                    // 000000135F10: BF800000
	s_nop 0                                                    // 000000135F14: BF800000
	s_nop 0                                                    // 000000135F18: BF800000
	s_nop 0                                                    // 000000135F1C: BF800000
	s_nop 0                                                    // 000000135F20: BF800000
	s_nop 0                                                    // 000000135F24: BF800000
	s_nop 0                                                    // 000000135F28: BF800000
	s_nop 0                                                    // 000000135F2C: BF800000
	s_nop 0                                                    // 000000135F30: BF800000
	s_nop 0                                                    // 000000135F34: BF800000
	s_nop 0                                                    // 000000135F38: BF800000
	s_nop 0                                                    // 000000135F3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000135F40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000135F48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000135F50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000135F54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000135F5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000135F60: D5207C49 00069280
	.long 0xd4490004                                           // 000000135F68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000135F6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000135F74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000135F78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000135F7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000135F84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000135F8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000135F90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000135F94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000135F98: BF89FC07
	s_barrier                                                  // 000000135F9C: BFBD0000
	buffer_gl0_inv                                             // 000000135FA0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000135FA8: BE842000
	s_cbranch_execz 142                                        // 000000135FAC: BFA5008E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ee8>
	v_add3_u32 v72, v1, s7, 56                                 // 000000135FB0: D6550048 02E00F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135FB8: BF870091
	v_mad_u64_u32 v[72:73], null, v72, 48, s[2:3]              // 000000135FBC: D6FE7C48 00096148
	.long 0xd73c0048                                           // 000000135FC4: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 000000135FC8: 02029089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135FCC: BF870091
	.long 0xd7000148                                           // 000000135FD0: D7000148
	v_cndmask_b32_e32 v1, v86, v72, vcc_lo                     // 000000135FD4: 02029156
	v_add_co_ci_u32_e64 v73, null, v87, v73, s1                // 000000135FD8: D5207C49 00069357
	s_mov_b32 s1, 0                                            // 000000135FE0: BE810080
	global_load_b32 v72, v[72:73], off                         // 000000135FE4: DC520000 487C0048
	s_lshl_b32 s10, s1, 2                                      // 000000135FEC: 840A8201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135FF0: BF870009
	v_add_nc_u32_e32 v117, s10, v88                            // 000000135FF4: 4AEAB00A
	v_add_nc_u32_e32 v118, s10, v81                            // 000000135FF8: 4AECA20A
	s_add_i32 s10, s1, 32                                      // 000000135FFC: 810AA001
	s_cmpk_lt_u32 s1, 0x60                                     // 000000136000: B6810060
	s_mov_b32 s1, s10                                          // 000000136004: BE81000A
	ds_load_b128 v[73:76], v117                                // 000000136008: DBFC0000 49000075
	ds_load_b128 v[105:108], v118                              // 000000136010: DBFC0000 69000076
	ds_load_b128 v[109:112], v117 offset:16                    // 000000136018: DBFC0010 6D000075
	ds_load_b128 v[113:116], v118 offset:16                    // 000000136020: DBFC0010 71000076
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000136028: BF890027
	v_fma_f32 v72, -v73, v105, v72                             // 00000013602C: D6130048 2522D349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136034: BF870091
	v_fma_f32 v72, -v74, v106, v72                             // 000000136038: D6130048 2522D54A
	v_fma_f32 v72, -v75, v107, v72                             // 000000136040: D6130048 2522D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136048: BF8700A1
	v_fma_f32 v72, -v76, v108, v72                             // 00000013604C: D6130048 2522D94C
	s_waitcnt lgkmcnt(0)                                       // 000000136054: BF89FC07
	v_fma_f32 v72, -v109, v113, v72                            // 000000136058: D6130048 2522E36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136060: BF870091
	v_fma_f32 v72, -v110, v114, v72                            // 000000136064: D6130048 2522E56E
	v_fma_f32 v72, -v111, v115, v72                            // 00000013606C: D6130048 2522E76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136074: BF870001
	v_fma_f32 v113, -v112, v116, v72                           // 000000136078: D6130071 2522E970
	ds_load_b128 v[72:75], v117 offset:32                      // 000000136080: DBFC0020 48000075
	ds_load_b128 v[76:79], v118 offset:32                      // 000000136088: DBFC0020 4C000076
	ds_load_b128 v[105:108], v117 offset:48                    // 000000136090: DBFC0030 69000075
	ds_load_b128 v[109:112], v118 offset:48                    // 000000136098: DBFC0030 6D000076
	s_waitcnt lgkmcnt(2)                                       // 0000001360A0: BF89FC27
	v_fma_f32 v72, -v72, v76, v113                             // 0000001360A4: D6130048 25C69948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001360AC: BF870091
	v_fma_f32 v72, -v73, v77, v72                              // 0000001360B0: D6130048 25229B49
	v_fma_f32 v72, -v74, v78, v72                              // 0000001360B8: D6130048 25229D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001360C0: BF8700A1
	v_fma_f32 v72, -v75, v79, v72                              // 0000001360C4: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001360CC: BF89FC07
	v_fma_f32 v72, -v105, v109, v72                            // 0000001360D0: D6130048 2522DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001360D8: BF870091
	v_fma_f32 v72, -v106, v110, v72                            // 0000001360DC: D6130048 2522DD6A
	v_fma_f32 v72, -v107, v111, v72                            // 0000001360E4: D6130048 2522DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001360EC: BF8700D1
	v_fma_f32 v113, -v108, v112, v72                           // 0000001360F0: D6130071 2522E16C
	ds_load_b128 v[72:75], v117 offset:64                      // 0000001360F8: DBFC0040 48000075
	ds_load_b128 v[76:79], v118 offset:64                      // 000000136100: DBFC0040 4C000076
	s_waitcnt lgkmcnt(0)                                       // 000000136108: BF89FC07
	v_fma_f32 v72, -v72, v76, v113                             // 00000013610C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000136114: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013611C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 000000136120: D6130048 25229D4A
	v_fma_f32 v113, -v75, v79, v72                             // 000000136128: D6130071 25229F4B
	ds_load_b128 v[72:75], v117 offset:96                      // 000000136130: DBFC0060 48000075
	ds_load_b128 v[76:79], v118 offset:96                      // 000000136138: DBFC0060 4C000076
	ds_load_b128 v[105:108], v117 offset:80                    // 000000136140: DBFC0050 69000075
	ds_load_b128 v[109:112], v118 offset:80                    // 000000136148: DBFC0050 6D000076
	s_waitcnt lgkmcnt(0)                                       // 000000136150: BF89FC07
	v_fma_f32 v105, -v105, v109, v113                          // 000000136154: D6130069 25C6DB69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013615C: BF870091
	v_fma_f32 v105, -v106, v110, v105                          // 000000136160: D6130069 25A6DD6A
	v_fma_f32 v105, -v107, v111, v105                          // 000000136168: D6130069 25A6DF6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000136170: BF8700C1
	v_fma_f32 v113, -v108, v112, v105                          // 000000136174: D6130071 25A6E16C
	ds_load_b128 v[105:108], v117 offset:112                   // 00000013617C: DBFC0070 69000075
	ds_load_b128 v[109:112], v118 offset:112                   // 000000136184: DBFC0070 6D000076
	v_fma_f32 v72, -v72, v76, v113                             // 00000013618C: D6130048 25C69948
	v_fma_f32 v72, -v73, v77, v72                              // 000000136194: D6130048 25229B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013619C: BF870091
	v_fma_f32 v72, -v74, v78, v72                              // 0000001361A0: D6130048 25229D4A
	v_fma_f32 v72, -v75, v79, v72                              // 0000001361A8: D6130048 25229F4B
	s_waitcnt lgkmcnt(0)                                       // 0000001361B0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001361B4: BF870091
	v_fma_f32 v72, -v105, v109, v72                            // 0000001361B8: D6130048 2522DB69
	v_fma_f32 v72, -v106, v110, v72                            // 0000001361C0: D6130048 2522DD6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001361C8: BF870091
	v_fma_f32 v72, -v107, v111, v72                            // 0000001361CC: D6130048 2522DF6B
	v_fma_f32 v72, -v108, v112, v72                            // 0000001361D4: D6130048 2522E16C
	s_cbranch_scc1 65411                                       // 0000001361DC: BFA2FF83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cec>
	ds_store_b32 v89, v72 offset:3808                          // 0000001361E0: D8340EE0 00004859
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001361E8: 8C7E047E
	v_dual_mov_b32 v73, v25 :: v_dual_mov_b32 v72, v24         // 0000001361EC: CA100119 49480118
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 0000001361F4: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 0000001361FC: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000136200: BF89FC07
	s_barrier                                                  // 000000136204: BFBD0000
	buffer_gl0_inv                                             // 000000136208: E0AC0000 00000000
	s_nop 0                                                    // 000000136210: BF800000
	s_nop 0                                                    // 000000136214: BF800000
	s_nop 0                                                    // 000000136218: BF800000
	s_nop 0                                                    // 00000013621C: BF800000
	s_nop 0                                                    // 000000136220: BF800000
	s_nop 0                                                    // 000000136224: BF800000
	s_nop 0                                                    // 000000136228: BF800000
	s_nop 0                                                    // 00000013622C: BF800000
	s_nop 0                                                    // 000000136230: BF800000
	s_nop 0                                                    // 000000136234: BF800000
	s_nop 0                                                    // 000000136238: BF800000
	s_nop 0                                                    // 00000013623C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000136240: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000136248: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000136250: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000136254: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013625C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000136260: D5207C49 00069280
	.long 0xd4490004                                           // 000000136268: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013626C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000136274: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000136278: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013627C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000136284: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013628C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000136290: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000136294: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000136298: BF89FC07
	s_barrier                                                  // 00000013629C: BFBD0000
	buffer_gl0_inv                                             // 0000001362A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001362A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001362AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25fc>
	v_or_b32_e32 v74, s7, v1                                   // 0000001362B0: 38940207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001362B4: BF870001
	.long 0xd4440001                                           // 0000001362B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001362BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001362C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001362C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25fc>
	ds_load_b128 v[75:78], v88                                 // 0000001362C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001362D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001362D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001362E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v27 :: v_dual_mov_b32 v72, v26         // 0000001362E8: CA10011B 4948011A
	s_mov_b32 s11, 0                                           // 0000001362F0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 0000001362F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001362F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136300: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000136304: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000136308: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013630C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000136310: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000136314: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000136318: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013631C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000136320: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000136324: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136328: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 00000013632C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000136330: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000136338: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000136340: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000136348: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136350: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136354: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136358: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013635C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136360: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136364: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136368: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013636C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136370: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136374: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136378: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013637C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136380: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136384: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000136388: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000136390: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000136398: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 0000001363A0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001363A8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001363AC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001363B0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001363B4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001363B8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001363BC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001363C0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001363C4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001363C8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001363CC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001363D0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001363D4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001363D8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001363DC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 0000001363E0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 0000001363E8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 0000001363F0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 0000001363F8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136400: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136404: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136408: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013640C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136410: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136414: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136418: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013641C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136420: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136424: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136428: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013642C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136430: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136434: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000136438: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000136440: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000136448: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000136450: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136458: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013645C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136460: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136464: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136468: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013646C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136470: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136474: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136478: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013647C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136480: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136484: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136488: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013648C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000136490: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000136498: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001364A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001364A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001364B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001364B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001364B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001364BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001364C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001364C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001364C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001364CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001364D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001364D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001364D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001364DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001364E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001364E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001364E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001364F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001364F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000136500: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136508: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013650C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136510: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136514: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136518: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013651C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136520: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136524: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136528: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013652C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136530: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136534: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136538: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013653C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000136540: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000136548: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000136550: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000136558: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136560: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136564: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136568: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013656C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136570: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136574: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136578: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013657C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136580: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136584: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136588: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013658C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136590: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136594: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000136598: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 0000001365A0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 0000001365A8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 0000001365B0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001365B8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001365BC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001365C0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001365C4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001365C8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001365CC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001365D0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001365D4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001365D8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001365DC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001365E0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001365E4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001365E8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001365EC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 0000001365F0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 0000001365F8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000136600: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000136608: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136610: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136614: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136618: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013661C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136620: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136624: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136628: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013662C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136630: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136634: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136638: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013663C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136640: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136644: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000136648: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000136650: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000136658: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000136660: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136668: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013666C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136670: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136674: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136678: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013667C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136680: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136684: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136688: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013668C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136690: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136694: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136698: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013669C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001366A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001366A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001366B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001366B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001366C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001366C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001366C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001366CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001366D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001366D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001366D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001366DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001366E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001366E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001366E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001366EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001366F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001366F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001366F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000136700: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000136708: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000136710: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136718: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013671C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136720: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136724: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136728: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013672C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136730: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136734: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136738: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013673C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136740: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136744: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136748: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013674C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000136750: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000136758: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000136760: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000136768: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136770: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136774: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136778: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013677C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136780: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136784: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136788: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013678C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136790: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136794: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136798: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013679C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001367A0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001367A4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 0000001367A8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 0000001367B0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 0000001367B8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 0000001367C0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001367C8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001367CC: 569EDB4B
	ds_load_b32 v75, v90                                       // 0000001367D0: D8D80000 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 0000001367D8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001367E0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 0000001367E4: 569EDF4D
	v_mov_b32_e32 v77, v98                                     // 0000001367E8: 7E9A0362
	v_fmac_f32_e32 v79, v78, v112                              // 0000001367EC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 0000001367F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001367F4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 0000001367F8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 0000001367FC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136800: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000136804: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000136808: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 00000013680C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000136814: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 00000013681C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000136824: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 00000013682C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136830: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136834: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136838: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 00000013683C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136840: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136844: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136848: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 00000013684C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136850: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136854: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136858: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013685C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000136860: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000136864: 1096974F
	s_nop 0                                                    // 000000136868: BF800000
	s_nop 0                                                    // 00000013686C: BF800000
	s_nop 0                                                    // 000000136870: BF800000
	s_nop 0                                                    // 000000136874: BF800000
	s_nop 0                                                    // 000000136878: BF800000
	s_nop 0                                                    // 00000013687C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000136880: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000136888: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000136890: 4A9A9AC1
	.long 0xd7000148                                           // 000000136894: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000136898: 02010948
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013689C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 0000001368A0: D5207C49 00069280
	.long 0xd44a0004                                           // 0000001368A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 0000001368AC: 02029A80
	v_add_nc_u32_e32 v76, 0x44, v76                            // 0000001368B0: 4A9898FF 00000044
	s_or_b32 s11, s4, s11                                      // 0000001368B8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001368BC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 0000001368C0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000001368C4: 917E0B7E
	s_cbranch_execnz 65517                                     // 0000001368C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2580>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001368CC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001368D0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001368D4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 0000001368DC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000001368E8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 0000001368F4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001368FC: 8C7E0A7E
	v_dual_mov_b32 v73, v29 :: v_dual_mov_b32 v72, v28         // 000000136900: CA10011D 4948011C
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000136908: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000136910: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000136914: BC7C0000
	s_barrier                                                  // 000000136918: BFBD0000
	buffer_gl0_inv                                             // 00000013691C: E0AC0000 00000000
	s_nop 0                                                    // 000000136924: BF800000
	s_nop 0                                                    // 000000136928: BF800000
	s_nop 0                                                    // 00000013692C: BF800000
	s_nop 0                                                    // 000000136930: BF800000
	s_nop 0                                                    // 000000136934: BF800000
	s_nop 0                                                    // 000000136938: BF800000
	s_nop 0                                                    // 00000013693C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000136940: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000136948: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000136950: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000136954: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013695C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000136960: D5207C49 00069280
	.long 0xd4490004                                           // 000000136968: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013696C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000136974: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000136978: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013697C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000136984: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013698C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000136990: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2640>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000136994: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000136998: BF89FC07
	s_barrier                                                  // 00000013699C: BFBD0000
	buffer_gl0_inv                                             // 0000001369A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001369A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001369AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cfc>
	v_or_b32_e32 v74, s7, v91                                  // 0000001369B0: 3894B607
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001369B4: BF870001
	.long 0xd4440001                                           // 0000001369B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001369BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001369C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001369C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cfc>
	ds_load_b128 v[75:78], v88                                 // 0000001369C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001369D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001369D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001369E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v31 :: v_dual_mov_b32 v72, v30         // 0000001369E8: CA10011F 4948011E
	s_mov_b32 s11, 0                                           // 0000001369F0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 0000001369F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001369F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136A00: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000136A04: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000136A08: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136A0C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000136A10: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000136A14: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000136A18: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136A1C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000136A20: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000136A24: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136A28: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 000000136A2C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000136A30: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000136A38: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000136A40: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000136A48: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136A50: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136A54: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136A58: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136A5C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136A60: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136A64: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136A68: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136A6C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136A70: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136A74: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136A78: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136A7C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136A80: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136A84: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000136A88: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000136A90: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000136A98: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 000000136AA0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136AA8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136AAC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136AB0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136AB4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136AB8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136ABC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136AC0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136AC4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136AC8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136ACC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136AD0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136AD4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136AD8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136ADC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 000000136AE0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 000000136AE8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 000000136AF0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 000000136AF8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136B00: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136B04: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B08: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136B0C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136B10: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136B14: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136B18: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136B1C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136B20: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B24: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136B28: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136B2C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136B30: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136B34: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000136B38: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000136B40: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000136B48: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000136B50: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136B58: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136B5C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B60: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136B64: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136B68: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136B6C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136B70: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136B74: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136B78: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B7C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136B80: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136B84: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136B88: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136B8C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000136B90: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000136B98: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 000000136BA0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 000000136BA8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136BB0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136BB4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BB8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136BBC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136BC0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136BC4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136BC8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136BCC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136BD0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BD4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136BD8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136BDC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136BE0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136BE4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 000000136BE8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 000000136BF0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 000000136BF8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000136C00: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136C08: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136C0C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C10: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136C14: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136C18: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136C1C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136C20: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136C24: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136C28: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C2C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136C30: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136C34: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136C38: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136C3C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000136C40: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000136C48: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000136C50: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000136C58: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136C60: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136C64: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C68: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136C6C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136C70: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136C74: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136C78: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136C7C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136C80: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C84: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136C88: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136C8C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136C90: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136C94: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000136C98: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 000000136CA0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 000000136CA8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 000000136CB0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136CB8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136CBC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136CC0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136CC4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136CC8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136CCC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136CD0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136CD4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136CD8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136CDC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136CE0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136CE4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136CE8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136CEC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 000000136CF0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 000000136CF8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000136D00: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000136D08: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136D10: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136D14: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D18: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136D1C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136D20: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136D24: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136D28: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136D2C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136D30: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D34: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136D38: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136D3C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136D40: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136D44: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000136D48: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000136D50: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000136D58: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000136D60: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136D68: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136D6C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D70: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136D74: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136D78: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136D7C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136D80: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136D84: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136D88: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D8C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136D90: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136D94: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136D98: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136D9C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 000000136DA0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 000000136DA8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 000000136DB0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 000000136DB8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136DC0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136DC4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136DC8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136DCC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136DD0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136DD4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136DD8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136DDC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136DE0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136DE4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136DE8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136DEC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136DF0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136DF4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 000000136DF8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000136E00: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000136E08: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000136E10: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136E18: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136E1C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E20: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000136E24: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000136E28: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136E2C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000136E30: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000136E34: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000136E38: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E3C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000136E40: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000136E44: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136E48: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000136E4C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000136E50: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000136E58: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000136E60: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000136E68: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136E70: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136E74: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E78: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136E7C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136E80: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136E84: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136E88: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136E8C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136E90: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E94: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136E98: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136E9C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000136EA0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000136EA4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 000000136EA8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 000000136EB0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 000000136EB8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 000000136EC0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000136EC8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000136ECC: 569EDB4B
	ds_load_b32 v75, v90 offset:32                             // 000000136ED0: D8D80020 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 000000136ED8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136EE0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 000000136EE4: 569EDF4D
	v_mov_b32_e32 v77, v2                                      // 000000136EE8: 7E9A0302
	v_fmac_f32_e32 v79, v78, v112                              // 000000136EEC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 000000136EF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136EF4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 000000136EF8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 000000136EFC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F00: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000136F04: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000136F08: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 000000136F0C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000136F14: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 000000136F1C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000136F24: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000136F2C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000136F30: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F34: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000136F38: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000136F3C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136F40: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000136F44: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000136F48: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000136F4C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F50: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000136F54: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000136F58: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F5C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000136F60: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000136F64: 1096974F
	s_nop 0                                                    // 000000136F68: BF800000
	s_nop 0                                                    // 000000136F6C: BF800000
	s_nop 0                                                    // 000000136F70: BF800000
	s_nop 0                                                    // 000000136F74: BF800000
	s_nop 0                                                    // 000000136F78: BF800000
	s_nop 0                                                    // 000000136F7C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000136F80: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000136F88: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000136F90: 4A9A9AC1
	.long 0xd7000148                                           // 000000136F94: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000136F98: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 000000136F9C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000136FA4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000136FAC: BF870004
	.long 0xd44a0004                                           // 000000136FB0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 000000136FB4: 02029A80
	s_or_b32 s11, s4, s11                                      // 000000136FB8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000136FBC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 000000136FC0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000136FC4: 917E0B7E
	s_cbranch_execnz 65517                                     // 000000136FC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c80>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000136FCC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136FD0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 000000136FD4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 000000136FDC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 000000136FE8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 000000136FF4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 000000136FFC: 8C7E0A7E
	v_dual_mov_b32 v73, v33 :: v_dual_mov_b32 v72, v32         // 000000137000: CA100121 49480120
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000137008: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000137010: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000137014: BC7C0000
	s_barrier                                                  // 000000137018: BFBD0000
	buffer_gl0_inv                                             // 00000013701C: E0AC0000 00000000
	s_nop 0                                                    // 000000137024: BF800000
	s_nop 0                                                    // 000000137028: BF800000
	s_nop 0                                                    // 00000013702C: BF800000
	s_nop 0                                                    // 000000137030: BF800000
	s_nop 0                                                    // 000000137034: BF800000
	s_nop 0                                                    // 000000137038: BF800000
	s_nop 0                                                    // 00000013703C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000137040: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000137048: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000137050: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000137054: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013705C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000137060: D5207C49 00069280
	.long 0xd4490004                                           // 000000137068: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013706C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000137074: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000137078: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013707C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000137084: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013708C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000137090: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000137094: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000137098: BF89FC07
	s_barrier                                                  // 00000013709C: BFBD0000
	buffer_gl0_inv                                             // 0000001370A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001370A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001370AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33fc>
	v_or_b32_e32 v74, s7, v92                                  // 0000001370B0: 3894B807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001370B4: BF870001
	.long 0xd4440001                                           // 0000001370B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001370BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001370C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001370C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33fc>
	ds_load_b128 v[75:78], v88                                 // 0000001370C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001370D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001370D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001370E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v35 :: v_dual_mov_b32 v72, v34         // 0000001370E8: CA100123 49480122
	s_mov_b32 s11, 0                                           // 0000001370F0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 0000001370F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001370F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137100: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000137104: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000137108: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013710C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000137110: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000137114: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000137118: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013711C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000137120: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000137124: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137128: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 00000013712C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000137130: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000137138: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000137140: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000137148: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137150: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137154: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137158: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013715C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137160: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137164: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137168: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013716C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137170: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137174: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137178: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013717C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137180: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137184: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000137188: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000137190: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000137198: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 0000001371A0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001371A8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001371AC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001371B0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001371B4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001371B8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001371BC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001371C0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001371C4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001371C8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001371CC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001371D0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001371D4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001371D8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001371DC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 0000001371E0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 0000001371E8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 0000001371F0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 0000001371F8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137200: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137204: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137208: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013720C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137210: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137214: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137218: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013721C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137220: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137224: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137228: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013722C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137230: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137234: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000137238: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000137240: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000137248: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000137250: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137258: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013725C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137260: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137264: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137268: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013726C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137270: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137274: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137278: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013727C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137280: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137284: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137288: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013728C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000137290: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000137298: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001372A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001372A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001372B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001372B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001372B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001372BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001372C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001372C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001372C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001372CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001372D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001372D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001372D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001372DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001372E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001372E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001372E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001372F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001372F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000137300: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137308: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013730C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137310: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137314: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137318: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013731C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137320: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137324: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137328: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013732C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137330: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137334: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137338: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013733C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000137340: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000137348: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000137350: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000137358: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137360: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137364: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137368: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013736C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137370: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137374: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137378: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013737C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137380: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137384: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137388: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013738C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137390: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137394: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000137398: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 0000001373A0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 0000001373A8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 0000001373B0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001373B8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001373BC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373C0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001373C4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001373C8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001373CC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001373D0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001373D4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001373D8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373DC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001373E0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001373E4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001373E8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001373EC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 0000001373F0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 0000001373F8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000137400: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000137408: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137410: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137414: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137418: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013741C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137420: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137424: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137428: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013742C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137430: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137434: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137438: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013743C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137440: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137444: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000137448: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000137450: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000137458: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000137460: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137468: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013746C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137470: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137474: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137478: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013747C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137480: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137484: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137488: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013748C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137490: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137494: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137498: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013749C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001374A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001374A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001374B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001374B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001374C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001374C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001374C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001374CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001374D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001374D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001374D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001374DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001374E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001374E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001374E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001374EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001374F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001374F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001374F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000137500: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000137508: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000137510: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137518: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013751C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137520: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137524: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137528: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013752C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137530: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137534: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137538: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013753C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137540: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137544: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137548: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013754C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000137550: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000137558: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000137560: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000137568: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137570: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137574: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137578: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013757C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137580: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137584: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137588: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013758C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137590: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137594: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137598: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013759C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001375A0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001375A4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 0000001375A8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 0000001375B0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 0000001375B8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 0000001375C0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001375C8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001375CC: 569EDB4B
	ds_load_b32 v75, v90 offset:64                             // 0000001375D0: D8D80040 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 0000001375D8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001375E0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 0000001375E4: 569EDF4D
	v_mov_b32_e32 v77, v99                                     // 0000001375E8: 7E9A0363
	v_fmac_f32_e32 v79, v78, v112                              // 0000001375EC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 0000001375F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001375F4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 0000001375F8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 0000001375FC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137600: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000137604: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000137608: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 00000013760C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000137614: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 00000013761C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000137624: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 00000013762C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137630: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137634: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137638: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 00000013763C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137640: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137644: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137648: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 00000013764C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137650: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137654: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137658: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013765C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000137660: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000137664: 1096974F
	s_nop 0                                                    // 000000137668: BF800000
	s_nop 0                                                    // 00000013766C: BF800000
	s_nop 0                                                    // 000000137670: BF800000
	s_nop 0                                                    // 000000137674: BF800000
	s_nop 0                                                    // 000000137678: BF800000
	s_nop 0                                                    // 00000013767C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000137680: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000137688: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000137690: 4A9A9AC1
	.long 0xd7000148                                           // 000000137694: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000137698: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 00000013769C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 0000001376A4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001376AC: BF870004
	.long 0xd44a0004                                           // 0000001376B0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 0000001376B4: 02029A80
	s_or_b32 s11, s4, s11                                      // 0000001376B8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001376BC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 0000001376C0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000001376C4: 917E0B7E
	s_cbranch_execnz 65517                                     // 0000001376C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3380>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001376CC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001376D0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001376D4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 0000001376DC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000001376E8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 0000001376F4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001376FC: 8C7E0A7E
	v_dual_mov_b32 v73, v37 :: v_dual_mov_b32 v72, v36         // 000000137700: CA100125 49480124
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000137708: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000137710: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000137714: BC7C0000
	s_barrier                                                  // 000000137718: BFBD0000
	buffer_gl0_inv                                             // 00000013771C: E0AC0000 00000000
	s_nop 0                                                    // 000000137724: BF800000
	s_nop 0                                                    // 000000137728: BF800000
	s_nop 0                                                    // 00000013772C: BF800000
	s_nop 0                                                    // 000000137730: BF800000
	s_nop 0                                                    // 000000137734: BF800000
	s_nop 0                                                    // 000000137738: BF800000
	s_nop 0                                                    // 00000013773C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000137740: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000137748: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000137750: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000137754: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013775C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000137760: D5207C49 00069280
	.long 0xd4490004                                           // 000000137768: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013776C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000137774: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000137778: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013777C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000137784: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013778C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000137790: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3440>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000137794: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000137798: BF89FC07
	s_barrier                                                  // 00000013779C: BFBD0000
	buffer_gl0_inv                                             // 0000001377A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001377A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001377AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3afc>
	v_or_b32_e32 v74, s7, v93                                  // 0000001377B0: 3894BA07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001377B4: BF870001
	.long 0xd4440001                                           // 0000001377B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001377BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001377C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001377C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3afc>
	ds_load_b128 v[75:78], v88                                 // 0000001377C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001377D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001377D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001377E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v39 :: v_dual_mov_b32 v72, v38         // 0000001377E8: CA100127 49480126
	s_mov_b32 s11, 0                                           // 0000001377F0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 0000001377F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001377F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137800: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000137804: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000137808: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013780C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000137810: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000137814: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000137818: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013781C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000137820: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000137824: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137828: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 00000013782C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000137830: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000137838: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000137840: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000137848: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137850: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137854: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137858: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013785C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137860: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137864: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137868: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013786C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137870: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137874: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137878: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013787C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137880: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137884: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000137888: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000137890: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000137898: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 0000001378A0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001378A8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001378AC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001378B0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001378B4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001378B8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001378BC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001378C0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001378C4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001378C8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001378CC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001378D0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001378D4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001378D8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001378DC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 0000001378E0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 0000001378E8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 0000001378F0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 0000001378F8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137900: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137904: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137908: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013790C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137910: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137914: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137918: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013791C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137920: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137924: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137928: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013792C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137930: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137934: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000137938: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000137940: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000137948: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000137950: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137958: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013795C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137960: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137964: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137968: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013796C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137970: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137974: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137978: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013797C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137980: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137984: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137988: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013798C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000137990: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000137998: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001379A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001379A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001379B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001379B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001379B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001379BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001379C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001379C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001379C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001379CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001379D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001379D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001379D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001379DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001379E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001379E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001379E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001379F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001379F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000137A00: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137A08: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137A0C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137A10: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137A14: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137A18: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137A1C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137A20: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137A24: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137A28: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137A2C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137A30: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137A34: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137A38: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000137A3C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000137A40: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000137A48: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000137A50: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000137A58: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137A60: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137A64: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137A68: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137A6C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137A70: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137A74: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137A78: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137A7C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137A80: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137A84: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137A88: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137A8C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137A90: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137A94: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000137A98: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 000000137AA0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 000000137AA8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 000000137AB0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137AB8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137ABC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137AC0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137AC4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137AC8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137ACC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137AD0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137AD4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137AD8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137ADC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137AE0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137AE4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137AE8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000137AEC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 000000137AF0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 000000137AF8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000137B00: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000137B08: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137B10: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137B14: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137B18: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137B1C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137B20: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137B24: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137B28: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137B2C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137B30: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137B34: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137B38: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137B3C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137B40: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137B44: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000137B48: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000137B50: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000137B58: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000137B60: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137B68: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137B6C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137B70: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137B74: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137B78: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137B7C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137B80: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137B84: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137B88: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137B8C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137B90: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137B94: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137B98: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000137B9C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 000000137BA0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 000000137BA8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 000000137BB0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 000000137BB8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137BC0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137BC4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137BC8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137BCC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137BD0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137BD4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137BD8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137BDC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137BE0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137BE4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137BE8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137BEC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137BF0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137BF4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 000000137BF8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000137C00: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000137C08: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000137C10: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137C18: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137C1C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C20: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137C24: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137C28: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137C2C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137C30: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137C34: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137C38: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C3C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137C40: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137C44: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137C48: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000137C4C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000137C50: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000137C58: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000137C60: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000137C68: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137C70: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137C74: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C78: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137C7C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137C80: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137C84: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137C88: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137C8C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137C90: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C94: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137C98: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137C9C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137CA0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137CA4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 000000137CA8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 000000137CB0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 000000137CB8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 000000137CC0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137CC8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137CCC: 569EDB4B
	ds_load_b32 v75, v90 offset:96                             // 000000137CD0: D8D80060 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 000000137CD8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137CE0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 000000137CE4: 569EDF4D
	v_mov_b32_e32 v77, v100                                    // 000000137CE8: 7E9A0364
	v_fmac_f32_e32 v79, v78, v112                              // 000000137CEC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 000000137CF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137CF4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 000000137CF8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 000000137CFC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D00: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000137D04: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000137D08: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 000000137D0C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000137D14: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 000000137D1C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000137D24: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137D2C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137D30: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D34: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137D38: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137D3C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137D40: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137D44: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137D48: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137D4C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D50: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137D54: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137D58: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D5C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000137D60: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000137D64: 1096974F
	s_nop 0                                                    // 000000137D68: BF800000
	s_nop 0                                                    // 000000137D6C: BF800000
	s_nop 0                                                    // 000000137D70: BF800000
	s_nop 0                                                    // 000000137D74: BF800000
	s_nop 0                                                    // 000000137D78: BF800000
	s_nop 0                                                    // 000000137D7C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000137D80: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000137D88: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000137D90: 4A9A9AC1
	.long 0xd7000148                                           // 000000137D94: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000137D98: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 000000137D9C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000137DA4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000137DAC: BF870004
	.long 0xd44a0004                                           // 000000137DB0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 000000137DB4: 02029A80
	s_or_b32 s11, s4, s11                                      // 000000137DB8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000137DBC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 000000137DC0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000137DC4: 917E0B7E
	s_cbranch_execnz 65517                                     // 000000137DC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a80>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000137DCC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137DD0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 000000137DD4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 000000137DDC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 000000137DE8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 000000137DF4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 000000137DFC: 8C7E0A7E
	v_dual_mov_b32 v73, v41 :: v_dual_mov_b32 v72, v40         // 000000137E00: CA100129 49480128
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000137E08: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000137E10: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000137E14: BC7C0000
	s_barrier                                                  // 000000137E18: BFBD0000
	buffer_gl0_inv                                             // 000000137E1C: E0AC0000 00000000
	s_nop 0                                                    // 000000137E24: BF800000
	s_nop 0                                                    // 000000137E28: BF800000
	s_nop 0                                                    // 000000137E2C: BF800000
	s_nop 0                                                    // 000000137E30: BF800000
	s_nop 0                                                    // 000000137E34: BF800000
	s_nop 0                                                    // 000000137E38: BF800000
	s_nop 0                                                    // 000000137E3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000137E40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000137E48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000137E50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000137E54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000137E5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000137E60: D5207C49 00069280
	.long 0xd4490004                                           // 000000137E68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000137E6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000137E74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000137E78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000137E7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000137E84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000137E8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000137E90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000137E94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000137E98: BF89FC07
	s_barrier                                                  // 000000137E9C: BFBD0000
	buffer_gl0_inv                                             // 000000137EA0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 000000137EA8: BE8A2000
	s_cbranch_execz 403                                        // 000000137EAC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41fc>
	v_or_b32_e32 v74, s7, v94                                  // 000000137EB0: 3894BC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137EB4: BF870001
	.long 0xd4440001                                           // 000000137EB8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 000000137EBC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000137EC0: 8B7E017E
	s_cbranch_execz 397                                        // 000000137EC4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41fc>
	ds_load_b128 v[75:78], v88                                 // 000000137EC8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 000000137ED0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 000000137ED8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 000000137EE0: DBFC0010 71000051
	v_dual_mov_b32 v73, v43 :: v_dual_mov_b32 v72, v42         // 000000137EE8: CA10012B 4948012A
	s_mov_b32 s11, 0                                           // 000000137EF0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 000000137EF4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 000000137EF8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F00: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000137F04: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000137F08: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137F0C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000137F10: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000137F14: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000137F18: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F1C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000137F20: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000137F24: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137F28: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 000000137F2C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000137F30: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000137F38: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000137F40: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000137F48: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000137F50: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000137F54: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F58: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000137F5C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000137F60: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137F64: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000137F68: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000137F6C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000137F70: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F74: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000137F78: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000137F7C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137F80: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000137F84: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000137F88: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000137F90: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000137F98: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 000000137FA0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000137FA8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000137FAC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FB0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000137FB4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000137FB8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137FBC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000137FC0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000137FC4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000137FC8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FCC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000137FD0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000137FD4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137FD8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000137FDC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 000000137FE0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 000000137FE8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 000000137FF0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 000000137FF8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138000: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138004: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138008: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013800C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138010: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138014: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138018: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013801C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138020: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138024: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138028: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013802C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138030: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138034: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000138038: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000138040: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000138048: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000138050: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138058: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013805C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138060: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138064: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138068: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013806C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138070: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138074: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138078: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013807C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138080: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138084: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138088: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013808C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000138090: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000138098: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001380A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001380A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001380B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001380B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001380BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001380C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001380C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001380C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001380CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001380D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001380D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001380DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001380E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001380E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001380E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001380F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001380F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000138100: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138108: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013810C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138110: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138114: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138118: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013811C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138120: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138124: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138128: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013812C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138130: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138134: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138138: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013813C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000138140: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000138148: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000138150: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000138158: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138160: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138164: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138168: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013816C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138170: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138174: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138178: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013817C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138180: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138184: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138188: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013818C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138190: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138194: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000138198: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 0000001381A0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 0000001381A8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 0000001381B0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001381B8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001381BC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381C0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001381C4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001381C8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001381CC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001381D0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001381D4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001381D8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381DC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001381E0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001381E4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001381E8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001381EC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 0000001381F0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 0000001381F8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000138200: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000138208: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138210: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138214: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138218: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013821C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138220: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138224: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138228: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013822C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138230: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138234: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138238: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013823C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138240: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138244: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000138248: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000138250: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000138258: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000138260: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138268: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013826C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138270: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138274: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138278: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013827C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138280: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138284: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138288: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013828C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138290: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138294: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138298: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013829C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001382A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001382A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001382B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001382B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001382C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001382C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001382C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001382CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001382D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001382D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001382D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001382DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001382E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001382E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001382E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001382EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001382F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001382F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001382F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000138300: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000138308: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000138310: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138318: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013831C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138320: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138324: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138328: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013832C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138330: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138334: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138338: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013833C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138340: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138344: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138348: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013834C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000138350: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000138358: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000138360: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000138368: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138370: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138374: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138378: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013837C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138380: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138384: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138388: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013838C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138390: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138394: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138398: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013839C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001383A0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001383A4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 0000001383A8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 0000001383B0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 0000001383B8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 0000001383C0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001383C8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001383CC: 569EDB4B
	ds_load_b32 v75, v90 offset:128                            // 0000001383D0: D8D80080 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 0000001383D8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001383E0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 0000001383E4: 569EDF4D
	v_mov_b32_e32 v77, v101                                    // 0000001383E8: 7E9A0365
	v_fmac_f32_e32 v79, v78, v112                              // 0000001383EC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 0000001383F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001383F4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 0000001383F8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 0000001383FC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138400: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000138404: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000138408: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 00000013840C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000138414: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 00000013841C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000138424: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 00000013842C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138430: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138434: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138438: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 00000013843C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138440: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138444: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138448: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 00000013844C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138450: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138454: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138458: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013845C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000138460: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000138464: 1096974F
	s_nop 0                                                    // 000000138468: BF800000
	s_nop 0                                                    // 00000013846C: BF800000
	s_nop 0                                                    // 000000138470: BF800000
	s_nop 0                                                    // 000000138474: BF800000
	s_nop 0                                                    // 000000138478: BF800000
	s_nop 0                                                    // 00000013847C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000138480: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000138488: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000138490: 4A9A9AC1
	.long 0xd7000148                                           // 000000138494: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000138498: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 00000013849C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 0000001384A4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001384AC: BF870004
	.long 0xd44a0004                                           // 0000001384B0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 0000001384B4: 02029A80
	s_or_b32 s11, s4, s11                                      // 0000001384B8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001384BC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 0000001384C0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000001384C4: 917E0B7E
	s_cbranch_execnz 65517                                     // 0000001384C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4180>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001384CC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001384D0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001384D4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 0000001384DC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000001384E8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 0000001384F4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001384FC: 8C7E0A7E
	v_dual_mov_b32 v73, v45 :: v_dual_mov_b32 v72, v44         // 000000138500: CA10012D 4948012C
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000138508: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000138510: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000138514: BC7C0000
	s_barrier                                                  // 000000138518: BFBD0000
	buffer_gl0_inv                                             // 00000013851C: E0AC0000 00000000
	s_nop 0                                                    // 000000138524: BF800000
	s_nop 0                                                    // 000000138528: BF800000
	s_nop 0                                                    // 00000013852C: BF800000
	s_nop 0                                                    // 000000138530: BF800000
	s_nop 0                                                    // 000000138534: BF800000
	s_nop 0                                                    // 000000138538: BF800000
	s_nop 0                                                    // 00000013853C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000138540: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000138548: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000138550: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000138554: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013855C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000138560: D5207C49 00069280
	.long 0xd4490004                                           // 000000138568: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013856C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000138574: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000138578: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013857C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000138584: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013858C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000138590: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4240>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000138594: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000138598: BF89FC07
	s_barrier                                                  // 00000013859C: BFBD0000
	buffer_gl0_inv                                             // 0000001385A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001385A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001385AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48fc>
	v_or_b32_e32 v74, s7, v95                                  // 0000001385B0: 3894BE07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001385B4: BF870001
	.long 0xd4440001                                           // 0000001385B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001385BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001385C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001385C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48fc>
	ds_load_b128 v[75:78], v88                                 // 0000001385C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001385D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001385D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001385E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v47 :: v_dual_mov_b32 v72, v46         // 0000001385E8: CA10012F 4948012E
	s_mov_b32 s11, 0                                           // 0000001385F0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 0000001385F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001385F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138600: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000138604: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000138608: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013860C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000138610: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000138614: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000138618: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013861C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000138620: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000138624: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138628: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 00000013862C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000138630: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000138638: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000138640: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000138648: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138650: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138654: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138658: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013865C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138660: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138664: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138668: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013866C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138670: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138674: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138678: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013867C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138680: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138684: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000138688: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000138690: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000138698: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 0000001386A0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001386A8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001386AC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001386B0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001386B4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001386B8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001386BC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001386C0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001386C4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001386C8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001386CC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001386D0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001386D4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001386D8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001386DC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 0000001386E0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 0000001386E8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 0000001386F0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 0000001386F8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138700: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138704: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138708: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013870C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138710: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138714: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138718: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013871C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138720: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138724: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138728: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013872C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138730: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138734: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000138738: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000138740: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000138748: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000138750: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138758: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013875C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138760: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138764: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138768: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013876C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138770: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138774: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138778: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013877C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138780: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138784: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138788: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013878C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000138790: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000138798: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001387A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001387A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001387B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001387B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001387BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001387C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001387C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001387C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001387CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001387D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001387D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001387DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001387E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001387E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001387E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001387F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001387F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000138800: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138808: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013880C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138810: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138814: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138818: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013881C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138820: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138824: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138828: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013882C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138830: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138834: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138838: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013883C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000138840: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000138848: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000138850: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000138858: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138860: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138864: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138868: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013886C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138870: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138874: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138878: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013887C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138880: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138884: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138888: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013888C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138890: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138894: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000138898: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 0000001388A0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 0000001388A8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 0000001388B0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001388B8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001388BC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388C0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001388C4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001388C8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001388CC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001388D0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001388D4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001388D8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388DC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001388E0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001388E4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001388E8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001388EC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 0000001388F0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 0000001388F8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000138900: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000138908: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138910: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138914: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138918: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013891C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138920: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138924: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138928: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013892C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138930: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138934: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138938: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013893C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138940: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138944: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000138948: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000138950: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000138958: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000138960: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138968: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013896C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138970: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138974: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138978: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013897C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138980: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138984: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138988: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013898C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138990: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138994: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138998: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013899C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001389A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001389A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001389B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001389B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001389C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001389C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001389C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001389CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001389D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001389D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001389D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001389DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001389E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001389E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001389E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001389EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001389F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001389F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001389F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000138A00: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000138A08: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000138A10: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138A18: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138A1C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A20: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138A24: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138A28: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138A2C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138A30: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138A34: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138A38: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A3C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138A40: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138A44: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138A48: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000138A4C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000138A50: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000138A58: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000138A60: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000138A68: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138A70: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138A74: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A78: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138A7C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138A80: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138A84: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138A88: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138A8C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138A90: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A94: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138A98: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138A9C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138AA0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138AA4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 000000138AA8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 000000138AB0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 000000138AB8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 000000138AC0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138AC8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138ACC: 569EDB4B
	ds_load_b32 v75, v90 offset:160                            // 000000138AD0: D8D800A0 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 000000138AD8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138AE0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 000000138AE4: 569EDF4D
	v_mov_b32_e32 v77, v102                                    // 000000138AE8: 7E9A0366
	v_fmac_f32_e32 v79, v78, v112                              // 000000138AEC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 000000138AF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138AF4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 000000138AF8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 000000138AFC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B00: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000138B04: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000138B08: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 000000138B0C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000138B14: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 000000138B1C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000138B24: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138B2C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138B30: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B34: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138B38: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138B3C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138B40: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138B44: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138B48: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138B4C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B50: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138B54: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138B58: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B5C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000138B60: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000138B64: 1096974F
	s_nop 0                                                    // 000000138B68: BF800000
	s_nop 0                                                    // 000000138B6C: BF800000
	s_nop 0                                                    // 000000138B70: BF800000
	s_nop 0                                                    // 000000138B74: BF800000
	s_nop 0                                                    // 000000138B78: BF800000
	s_nop 0                                                    // 000000138B7C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000138B80: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000138B88: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000138B90: 4A9A9AC1
	.long 0xd7000148                                           // 000000138B94: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000138B98: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 000000138B9C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000138BA4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000138BAC: BF870004
	.long 0xd44a0004                                           // 000000138BB0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 000000138BB4: 02029A80
	s_or_b32 s11, s4, s11                                      // 000000138BB8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000138BBC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 000000138BC0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000138BC4: 917E0B7E
	s_cbranch_execnz 65517                                     // 000000138BC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4880>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000138BCC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138BD0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 000000138BD4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 000000138BDC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 000000138BE8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 000000138BF4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 000000138BFC: 8C7E0A7E
	v_dual_mov_b32 v73, v49 :: v_dual_mov_b32 v72, v48         // 000000138C00: CA100131 49480130
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000138C08: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000138C10: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000138C14: BC7C0000
	s_barrier                                                  // 000000138C18: BFBD0000
	buffer_gl0_inv                                             // 000000138C1C: E0AC0000 00000000
	s_nop 0                                                    // 000000138C24: BF800000
	s_nop 0                                                    // 000000138C28: BF800000
	s_nop 0                                                    // 000000138C2C: BF800000
	s_nop 0                                                    // 000000138C30: BF800000
	s_nop 0                                                    // 000000138C34: BF800000
	s_nop 0                                                    // 000000138C38: BF800000
	s_nop 0                                                    // 000000138C3C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000138C40: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000138C48: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000138C50: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000138C54: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000138C5C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000138C60: D5207C49 00069280
	.long 0xd4490004                                           // 000000138C68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 000000138C6C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000138C74: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000138C78: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 000000138C7C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000138C84: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000138C8C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000138C90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4940>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000138C94: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000138C98: BF89FC07
	s_barrier                                                  // 000000138C9C: BFBD0000
	buffer_gl0_inv                                             // 000000138CA0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 000000138CA8: BE8A2000
	s_cbranch_execz 403                                        // 000000138CAC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ffc>
	v_or_b32_e32 v74, s7, v96                                  // 000000138CB0: 3894C007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138CB4: BF870001
	.long 0xd4440001                                           // 000000138CB8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 000000138CBC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000138CC0: 8B7E017E
	s_cbranch_execz 397                                        // 000000138CC4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ffc>
	ds_load_b128 v[75:78], v88                                 // 000000138CC8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 000000138CD0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 000000138CD8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 000000138CE0: DBFC0010 71000051
	v_dual_mov_b32 v73, v51 :: v_dual_mov_b32 v72, v50         // 000000138CE8: CA100133 49480132
	s_mov_b32 s11, 0                                           // 000000138CF0: BE8B0080
	s_waitcnt lgkmcnt(2)                                       // 000000138CF4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 000000138CF8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D00: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000138D04: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000138D08: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138D0C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000138D10: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000138D14: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000138D18: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D1C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000138D20: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000138D24: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138D28: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 000000138D2C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000138D30: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000138D38: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000138D40: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000138D48: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138D50: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138D54: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D58: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138D5C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138D60: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138D64: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138D68: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138D6C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138D70: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D74: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138D78: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138D7C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138D80: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138D84: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000138D88: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000138D90: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000138D98: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 000000138DA0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138DA8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138DAC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138DB0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138DB4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138DB8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138DBC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138DC0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138DC4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138DC8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138DCC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138DD0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138DD4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138DD8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000138DDC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 000000138DE0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 000000138DE8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 000000138DF0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 000000138DF8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138E00: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138E04: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E08: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138E0C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138E10: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138E14: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138E18: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138E1C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138E20: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E24: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138E28: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138E2C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138E30: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138E34: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000138E38: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000138E40: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000138E48: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000138E50: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138E58: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138E5C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E60: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138E64: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138E68: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138E6C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138E70: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138E74: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138E78: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E7C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138E80: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138E84: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138E88: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000138E8C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000138E90: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000138E98: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 000000138EA0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 000000138EA8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138EB0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138EB4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138EB8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138EBC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138EC0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138EC4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138EC8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138ECC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138ED0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138ED4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138ED8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138EDC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138EE0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138EE4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 000000138EE8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 000000138EF0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 000000138EF8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000138F00: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138F08: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138F0C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F10: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138F14: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138F18: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138F1C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138F20: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138F24: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138F28: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F2C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138F30: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138F34: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138F38: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000138F3C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000138F40: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000138F48: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000138F50: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000138F58: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000138F60: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000138F64: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F68: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000138F6C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000138F70: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138F74: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000138F78: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000138F7C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000138F80: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F84: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000138F88: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000138F8C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138F90: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000138F94: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000138F98: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 000000138FA0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 000000138FA8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 000000138FB0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000138FB8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 000000138FBC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138FC0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000138FC4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000138FC8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000138FCC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000138FD0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000138FD4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000138FD8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138FDC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000138FE0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000138FE4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138FE8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 000000138FEC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 000000138FF0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 000000138FF8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000139000: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000139008: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139010: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139014: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139018: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013901C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139020: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139024: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139028: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013902C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139030: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139034: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139038: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013903C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139040: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000139044: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000139048: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000139050: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000139058: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000139060: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139068: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013906C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139070: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139074: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139078: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013907C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139080: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139084: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139088: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013908C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139090: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139094: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139098: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013909C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001390A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001390A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001390B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001390B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001390C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001390C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001390CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001390D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001390D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001390D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001390DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001390E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001390E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001390EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001390F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001390F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001390F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000139100: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000139108: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000139110: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139118: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013911C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139120: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139124: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139128: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013912C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139130: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139134: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139138: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013913C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139140: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139144: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139148: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013914C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000139150: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000139158: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000139160: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000139168: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139170: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139174: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139178: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013917C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139180: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139184: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139188: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013918C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139190: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139194: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139198: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013919C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001391A0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001391A4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 0000001391A8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 0000001391B0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 0000001391B8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 0000001391C0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001391C8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001391CC: 569EDB4B
	ds_load_b32 v75, v90 offset:192                            // 0000001391D0: D8D800C0 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 0000001391D8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001391E0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 0000001391E4: 569EDF4D
	v_mov_b32_e32 v77, v103                                    // 0000001391E8: 7E9A0367
	v_fmac_f32_e32 v79, v78, v112                              // 0000001391EC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 0000001391F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391F4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 0000001391F8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 0000001391FC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139200: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000139204: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000139208: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 00000013920C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000139214: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 00000013921C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000139224: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 00000013922C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139230: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139234: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000139238: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 00000013923C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139240: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139244: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000139248: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 00000013924C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139250: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139254: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000139258: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013925C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000139260: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000139264: 1096974F
	s_nop 0                                                    // 000000139268: BF800000
	s_nop 0                                                    // 00000013926C: BF800000
	s_nop 0                                                    // 000000139270: BF800000
	s_nop 0                                                    // 000000139274: BF800000
	s_nop 0                                                    // 000000139278: BF800000
	s_nop 0                                                    // 00000013927C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000139280: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000139288: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000139290: 4A9A9AC1
	.long 0xd7000148                                           // 000000139294: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000139298: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 00000013929C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 0000001392A4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001392AC: BF870004
	.long 0xd44a0004                                           // 0000001392B0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 0000001392B4: 02029A80
	s_or_b32 s11, s4, s11                                      // 0000001392B8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001392BC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 0000001392C0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000001392C4: 917E0B7E
	s_cbranch_execnz 65517                                     // 0000001392C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f80>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001392CC: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001392D0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001392D4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 0000001392DC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000001392E8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 0000001392F4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001392FC: 8C7E0A7E
	v_dual_mov_b32 v73, v53 :: v_dual_mov_b32 v72, v52         // 000000139300: CA100135 49480134
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, v82          // 000000139308: CA100103 4A4A0152
	s_mov_b32 s10, 0                                           // 000000139310: BE8A0080
	s_waitcnt_vscnt null, 0x0                                  // 000000139314: BC7C0000
	s_barrier                                                  // 000000139318: BFBD0000
	buffer_gl0_inv                                             // 00000013931C: E0AC0000 00000000
	s_nop 0                                                    // 000000139324: BF800000
	s_nop 0                                                    // 000000139328: BF800000
	s_nop 0                                                    // 00000013932C: BF800000
	s_nop 0                                                    // 000000139330: BF800000
	s_nop 0                                                    // 000000139334: BF800000
	s_nop 0                                                    // 000000139338: BF800000
	s_nop 0                                                    // 00000013933C: BF800000
	global_load_b32 v76, v[72:73], off                         // 000000139340: DC520000 4C7C0048
	v_add_nc_u32_e32 v75, 0x80, v75                            // 000000139348: 4A9696FF 00000080
	.long 0xd7000148                                           // 000000139350: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000139354: 020290FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013935C: BF870191
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000139360: D5207C49 00069280
	.long 0xd4490004                                           // 000000139368: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v75, vcc_lo                   // 00000013936C: 020296FF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000139374: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000139378: BF8903F7
	ds_store_b32 v74, v76 offset:12800                         // 00000013937C: D8343200 00004C4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000139384: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000013938C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000139390: BFA6FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5040>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000139394: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000139398: BF89FC07
	s_barrier                                                  // 00000013939C: BFBD0000
	buffer_gl0_inv                                             // 0000001393A0: E0AC0000 00000000
	s_and_saveexec_b32 s10, s0                                 // 0000001393A8: BE8A2000
	s_cbranch_execz 403                                        // 0000001393AC: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x56fc>
	v_or_b32_e32 v74, s7, v97                                  // 0000001393B0: 3894C207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001393B4: BF870001
	.long 0xd4440001                                           // 0000001393B8: D4440001
	v_cndmask_b32_e32 v1, s30, v74, vcc_lo                     // 0000001393BC: 0202941E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000001393C0: 8B7E017E
	s_cbranch_execz 397                                        // 0000001393C4: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x56fc>
	ds_load_b128 v[75:78], v88                                 // 0000001393C8: DBFC0000 4B000058
	ds_load_b128 v[105:108], v81                               // 0000001393D0: DBFC0000 69000051
	ds_load_b128 v[109:112], v88 offset:16                     // 0000001393D8: DBFC0010 6D000058
	ds_load_b128 v[113:116], v81 offset:16                     // 0000001393E0: DBFC0010 71000051
	v_dual_mov_b32 v73, v55 :: v_dual_mov_b32 v72, v54         // 0000001393E8: CA100137 49480136
	s_mov_b32 s7, 0                                            // 0000001393F0: BE870080
	s_waitcnt lgkmcnt(2)                                       // 0000001393F4: BF89FC27
	v_fma_f32 v79, v75, v105, 0                                // 0000001393F8: D613004F 0202D34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139400: BF870091
	v_fmac_f32_e32 v79, v76, v106                              // 000000139404: 569ED54C
	v_fmac_f32_e32 v79, v77, v107                              // 000000139408: 569ED74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013940C: BF8700A1
	v_fmac_f32_e32 v79, v78, v108                              // 000000139410: 569ED94E
	s_waitcnt lgkmcnt(0)                                       // 000000139414: BF89FC07
	v_fmac_f32_e32 v79, v109, v113                             // 000000139418: 569EE36D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013941C: BF870091
	v_fmac_f32_e32 v79, v110, v114                             // 000000139420: 569EE56E
	v_fmac_f32_e32 v79, v111, v115                             // 000000139424: 569EE76F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139428: BF870001
	v_fmac_f32_e32 v79, v112, v116                             // 00000013942C: 569EE970
	ds_load_b128 v[117:120], v88 offset:32                     // 000000139430: DBFC0020 75000058
	ds_load_b128 v[125:128], v81 offset:32                     // 000000139438: DBFC0020 7D000051
	ds_load_b128 v[121:124], v88 offset:48                     // 000000139440: DBFC0030 79000058
	ds_load_b128 v[129:132], v81 offset:48                     // 000000139448: DBFC0030 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139450: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139454: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139458: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013945C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139460: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139464: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139468: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013946C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139470: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139474: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139478: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013947C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139480: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000139484: 569F097C
	ds_load_b128 v[75:78], v88 offset:64                       // 000000139488: DBFC0040 4B000058
	ds_load_b128 v[109:112], v81 offset:64                     // 000000139490: DBFC0040 6D000051
	ds_load_b128 v[105:108], v88 offset:80                     // 000000139498: DBFC0050 69000058
	ds_load_b128 v[113:116], v81 offset:80                     // 0000001394A0: DBFC0050 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001394A8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001394AC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001394B0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001394B4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001394B8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001394BC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001394C0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001394C4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001394C8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001394CC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001394D0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001394D4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001394D8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001394DC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:96                     // 0000001394E0: DBFC0060 75000058
	ds_load_b128 v[125:128], v81 offset:96                     // 0000001394E8: DBFC0060 7D000051
	ds_load_b128 v[121:124], v88 offset:112                    // 0000001394F0: DBFC0070 79000058
	ds_load_b128 v[129:132], v81 offset:112                    // 0000001394F8: DBFC0070 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139500: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139504: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139508: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013950C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139510: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139514: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139518: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013951C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139520: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139524: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139528: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013952C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139530: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000139534: 569F097C
	ds_load_b128 v[75:78], v88 offset:128                      // 000000139538: DBFC0080 4B000058
	ds_load_b128 v[109:112], v81 offset:128                    // 000000139540: DBFC0080 6D000051
	ds_load_b128 v[105:108], v88 offset:144                    // 000000139548: DBFC0090 69000058
	ds_load_b128 v[113:116], v81 offset:144                    // 000000139550: DBFC0090 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139558: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013955C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139560: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139564: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139568: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013956C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139570: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139574: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139578: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013957C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139580: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139584: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139588: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013958C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:160                    // 000000139590: DBFC00A0 75000058
	ds_load_b128 v[125:128], v81 offset:160                    // 000000139598: DBFC00A0 7D000051
	ds_load_b128 v[121:124], v88 offset:176                    // 0000001395A0: DBFC00B0 79000058
	ds_load_b128 v[129:132], v81 offset:176                    // 0000001395A8: DBFC00B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001395B0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001395B4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001395B8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001395BC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001395C0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001395C4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001395C8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001395CC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001395D0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001395D4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001395D8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001395DC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001395E0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001395E4: 569F097C
	ds_load_b128 v[75:78], v88 offset:192                      // 0000001395E8: DBFC00C0 4B000058
	ds_load_b128 v[109:112], v81 offset:192                    // 0000001395F0: DBFC00C0 6D000051
	ds_load_b128 v[105:108], v88 offset:208                    // 0000001395F8: DBFC00D0 69000058
	ds_load_b128 v[113:116], v81 offset:208                    // 000000139600: DBFC00D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139608: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013960C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139610: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139614: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139618: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013961C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139620: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139624: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139628: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013962C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139630: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139634: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139638: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013963C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:224                    // 000000139640: DBFC00E0 75000058
	ds_load_b128 v[125:128], v81 offset:224                    // 000000139648: DBFC00E0 7D000051
	ds_load_b128 v[121:124], v88 offset:240                    // 000000139650: DBFC00F0 79000058
	ds_load_b128 v[129:132], v81 offset:240                    // 000000139658: DBFC00F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139660: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139664: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139668: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013966C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139670: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139674: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139678: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013967C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139680: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139684: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139688: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013968C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139690: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000139694: 569F097C
	ds_load_b128 v[75:78], v88 offset:256                      // 000000139698: DBFC0100 4B000058
	ds_load_b128 v[109:112], v81 offset:256                    // 0000001396A0: DBFC0100 6D000051
	ds_load_b128 v[105:108], v88 offset:272                    // 0000001396A8: DBFC0110 69000058
	ds_load_b128 v[113:116], v81 offset:272                    // 0000001396B0: DBFC0110 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001396B8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001396BC: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001396C0: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 0000001396C4: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 0000001396C8: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001396CC: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 0000001396D0: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 0000001396D4: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 0000001396D8: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001396DC: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 0000001396E0: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 0000001396E4: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001396E8: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 0000001396EC: 569EE96C
	ds_load_b128 v[117:120], v88 offset:288                    // 0000001396F0: DBFC0120 75000058
	ds_load_b128 v[125:128], v81 offset:288                    // 0000001396F8: DBFC0120 7D000051
	ds_load_b128 v[121:124], v88 offset:304                    // 000000139700: DBFC0130 79000058
	ds_load_b128 v[129:132], v81 offset:304                    // 000000139708: DBFC0130 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139710: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139714: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139718: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013971C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139720: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139724: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139728: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013972C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139730: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139734: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139738: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013973C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139740: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 000000139744: 569F097C
	ds_load_b128 v[75:78], v88 offset:320                      // 000000139748: DBFC0140 4B000058
	ds_load_b128 v[109:112], v81 offset:320                    // 000000139750: DBFC0140 6D000051
	ds_load_b128 v[105:108], v88 offset:336                    // 000000139758: DBFC0150 69000058
	ds_load_b128 v[113:116], v81 offset:336                    // 000000139760: DBFC0150 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139768: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013976C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139770: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139774: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139778: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013977C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139780: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139784: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139788: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013978C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139790: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139794: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139798: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013979C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:352                    // 0000001397A0: DBFC0160 75000058
	ds_load_b128 v[125:128], v81 offset:352                    // 0000001397A8: DBFC0160 7D000051
	ds_load_b128 v[121:124], v88 offset:368                    // 0000001397B0: DBFC0170 79000058
	ds_load_b128 v[129:132], v81 offset:368                    // 0000001397B8: DBFC0170 81000051
	s_waitcnt lgkmcnt(2)                                       // 0000001397C0: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 0000001397C4: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001397C8: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 0000001397CC: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 0000001397D0: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001397D4: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 0000001397D8: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 0000001397DC: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 0000001397E0: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001397E4: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 0000001397E8: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 0000001397EC: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001397F0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001397F4: 569F097C
	ds_load_b128 v[75:78], v88 offset:384                      // 0000001397F8: DBFC0180 4B000058
	ds_load_b128 v[109:112], v81 offset:384                    // 000000139800: DBFC0180 6D000051
	ds_load_b128 v[105:108], v88 offset:400                    // 000000139808: DBFC0190 69000058
	ds_load_b128 v[113:116], v81 offset:400                    // 000000139810: DBFC0190 71000051
	s_waitcnt lgkmcnt(2)                                       // 000000139818: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 00000013981C: 569EDB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139820: BF870091
	v_fmac_f32_e32 v79, v76, v110                              // 000000139824: 569EDD4C
	v_fmac_f32_e32 v79, v77, v111                              // 000000139828: 569EDF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013982C: BF8700A1
	v_fmac_f32_e32 v79, v78, v112                              // 000000139830: 569EE14E
	s_waitcnt lgkmcnt(0)                                       // 000000139834: BF89FC07
	v_fmac_f32_e32 v79, v105, v113                             // 000000139838: 569EE369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013983C: BF870091
	v_fmac_f32_e32 v79, v106, v114                             // 000000139840: 569EE56A
	v_fmac_f32_e32 v79, v107, v115                             // 000000139844: 569EE76B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139848: BF870001
	v_fmac_f32_e32 v79, v108, v116                             // 00000013984C: 569EE96C
	ds_load_b128 v[117:120], v88 offset:416                    // 000000139850: DBFC01A0 75000058
	ds_load_b128 v[125:128], v81 offset:416                    // 000000139858: DBFC01A0 7D000051
	ds_load_b128 v[121:124], v88 offset:432                    // 000000139860: DBFC01B0 79000058
	ds_load_b128 v[129:132], v81 offset:432                    // 000000139868: DBFC01B0 81000051
	s_waitcnt lgkmcnt(2)                                       // 000000139870: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139874: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139878: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 00000013987C: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 000000139880: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139884: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139888: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 00000013988C: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 000000139890: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139894: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139898: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 00000013989C: 569F077B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001398A0: BF870001
	v_fmac_f32_e32 v79, v124, v132                             // 0000001398A4: 569F097C
	ds_load_b128 v[75:78], v88 offset:448                      // 0000001398A8: DBFC01C0 4B000058
	ds_load_b128 v[109:112], v81 offset:448                    // 0000001398B0: DBFC01C0 6D000051
	ds_load_b128 v[105:108], v88 offset:464                    // 0000001398B8: DBFC01D0 69000058
	ds_load_b128 v[113:116], v81 offset:464                    // 0000001398C0: DBFC01D0 71000051
	s_waitcnt lgkmcnt(2)                                       // 0000001398C8: BF89FC27
	v_fmac_f32_e32 v79, v75, v109                              // 0000001398CC: 569EDB4B
	ds_load_b32 v75, v90 offset:224                            // 0000001398D0: D8D800E0 4B00005A
	v_dual_fmac_f32 v79, v76, v110 :: v_dual_mov_b32 v76, v83  // 0000001398D8: C810DD4C 4F4C0153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001398E0: BF870121
	v_fmac_f32_e32 v79, v77, v111                              // 0000001398E4: 569EDF4D
	v_mov_b32_e32 v77, v104                                    // 0000001398E8: 7E9A0368
	v_fmac_f32_e32 v79, v78, v112                              // 0000001398EC: 569EE14E
	s_waitcnt lgkmcnt(1)                                       // 0000001398F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001398F4: BF870091
	v_fmac_f32_e32 v79, v105, v113                             // 0000001398F8: 569EE369
	v_fmac_f32_e32 v79, v106, v114                             // 0000001398FC: 569EE56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139900: BF870091
	v_fmac_f32_e32 v79, v107, v115                             // 000000139904: 569EE76B
	v_fmac_f32_e32 v79, v108, v116                             // 000000139908: 569EE96C
	ds_load_b128 v[117:120], v88 offset:480                    // 00000013990C: DBFC01E0 75000058
	ds_load_b128 v[125:128], v81 offset:480                    // 000000139914: DBFC01E0 7D000051
	ds_load_b128 v[121:124], v88 offset:496                    // 00000013991C: DBFC01F0 79000058
	ds_load_b128 v[129:132], v81 offset:496                    // 000000139924: DBFC01F0 81000051
	s_waitcnt lgkmcnt(2)                                       // 00000013992C: BF89FC27
	v_fmac_f32_e32 v79, v117, v125                             // 000000139930: 569EFB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139934: BF870091
	v_fmac_f32_e32 v79, v118, v126                             // 000000139938: 569EFD76
	v_fmac_f32_e32 v79, v119, v127                             // 00000013993C: 569EFF77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139940: BF8700A1
	v_fmac_f32_e32 v79, v120, v128                             // 000000139944: 569F0178
	s_waitcnt lgkmcnt(0)                                       // 000000139948: BF89FC07
	v_fmac_f32_e32 v79, v121, v129                             // 00000013994C: 569F0379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139950: BF870091
	v_fmac_f32_e32 v79, v122, v130                             // 000000139954: 569F057A
	v_fmac_f32_e32 v79, v123, v131                             // 000000139958: 569F077B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013995C: BF870091
	v_fmac_f32_e32 v79, v124, v132                             // 000000139960: 569F097C
	v_mul_f32_e32 v75, v79, v75                                // 000000139964: 1096974F
	s_nop 0                                                    // 000000139968: BF800000
	s_nop 0                                                    // 00000013996C: BF800000
	s_nop 0                                                    // 000000139970: BF800000
	s_nop 0                                                    // 000000139974: BF800000
	s_nop 0                                                    // 000000139978: BF800000
	s_nop 0                                                    // 00000013997C: BF800000
	global_load_b32 v78, v[72:73], off                         // 000000139980: DC520000 4E7C0048
	ds_load_b32 v79, v76 offset:8448                           // 000000139988: D8D82100 4F00004C
	v_add_nc_u32_e32 v77, -1, v77                              // 000000139990: 4A9A9AC1
	.long 0xd7000148                                           // 000000139994: D7000148
	v_cndmask_b32_e32 v0, v72, v132, vcc_lo                    // 000000139998: 02010948
	v_add_nc_u32_e32 v76, 0x44, v76                            // 00000013999C: 4A9898FF 00000044
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 0000001399A4: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001399AC: BF870004
	.long 0xd44a0004                                           // 0000001399B0: D44A0004
	v_cndmask_b32_e32 v1, 0, v77, vcc_lo                       // 0000001399B4: 02029A80
	s_or_b32 s7, s4, s7                                        // 0000001399B8: 8C070704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001399BC: BF890007
	v_fmac_f32_e32 v75, v78, v79                               // 0000001399C0: 56969F4E
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000001399C4: 917E077E
	s_cbranch_execnz 65517                                     // 0000001399C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5680>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001399CC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001399D0: BF870121
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001399D4: D610004C 0205214B
	v_mad_u64_u32 v[72:73], null, 0x3000, v74, v[4:5]          // 0000001399DC: D6FE7C48 041294FF 00003000
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000001399E8: D655004A 03FE994B 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off                 // 0000001399F4: DC960000 007C4A48
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001399FC: 8C7E0A7E
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000139A00: A201FF06 3FB8AA3B
	v_mov_b32_e32 v74, v82                                     // 000000139A08: 7E940352
	s_waitcnt_vscnt null, 0x0                                  // 000000139A0C: BC7C0000
	s_barrier                                                  // 000000139A10: BFBD0000
	s_xor_b32 s4, s1, 0x80000000                               // 000000139A14: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000139A1C: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000139A20: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000139A28: BF4EFF06 C2CE8ED0
	buffer_gl0_inv                                             // 000000139A30: E0AC0000 00000000
	s_sub_f32 s1, s1, s7                                       // 000000139A38: A0810701
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000139A3C: A3040406 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000139A44: BF87052B
	s_add_f32 s1, s1, s4                                       // 000000139A48: A0010401
	s_mov_b32 s4, 0                                            // 000000139A4C: BE840080
	v_exp_f32_e32 v72, s1                                      // 000000139A50: 7E904A01
	s_cvt_i32_f32 s1, s7                                       // 000000139A54: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000139A58: BF870585
	.long 0xd71c0048                                           // 000000139A5C: D71C0048
	v_cndmask_b32_e32 v0, v72, v1, vcc_lo                      // 000000139A60: 02000348
	s_cselect_b32 s1, -1, 0                                    // 000000139A64: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000139A68: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000139A70: BF870131
	v_cndmask_b32_e64 v73, 0, v72, s1                          // 000000139A74: D5010049 00069080
	s_cselect_b32 s1, -1, 0                                    // 000000139A7C: 980180C1
	v_mov_b32_e32 v72, v3                                      // 000000139A80: 7E900303
	v_cndmask_b32_e64 v73, 0x7f800000, v73, s1                 // 000000139A84: D5010049 000692FF 7F800000
	ds_load_b32 v75, v72                                       // 000000139A90: D8D80000 4B000048
	v_add_nc_u32_e32 v74, 0x80, v74                            // 000000139A98: 4A9494FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139AA0: BF870001
	.long 0xd4490001                                           // 000000139AA4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v74, vcc_lo                   // 000000139AA8: 020294FF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000139AB0: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000139AB4: BF89FC07
	v_mul_f32_e32 v75, v73, v75                                // 000000139AB8: 10969749
	ds_store_b32 v72, v75                                      // 000000139ABC: D8340000 00004B48
	v_add_nc_u32_e32 v72, 0x210, v72                           // 000000139AC4: 4A9090FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000139ACC: 917E047E
	s_cbranch_execnz 65519                                     // 000000139AD0: BFA6FFEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5790>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000139AD4: 8C7E047E
	v_dual_mov_b32 v73, v57 :: v_dual_mov_b32 v72, v56         // 000000139AD8: CA100139 49480138
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v75, v3            // 000000139AE0: CA100080 4A4A0103
	v_mov_b32_e32 v76, v82                                     // 000000139AE8: 7E980352
	s_mov_b32 s6, 0                                            // 000000139AEC: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000139AF0: BF89FC07
	s_barrier                                                  // 000000139AF4: BFBD0000
	buffer_gl0_inv                                             // 000000139AF8: E0AC0000 00000000
	global_load_b32 v77, v[72:73], off                         // 000000139B00: DC520000 4D7C0048
	ds_load_b32 v78, v74 offset:17024                          // 000000139B08: D8D84280 4E00004A
	v_add_nc_u32_e32 v76, 0x80, v76                            // 000000139B10: 4A9898FF 00000080
	.long 0xd7000148                                           // 000000139B18: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000139B1C: 020290FF 00006000
	v_add_nc_u32_e32 v74, 4, v74                               // 000000139B24: 4A949484
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000139B28: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000139B30: BF870004
	.long 0xd4490004                                           // 000000139B34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 000000139B38: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000139B40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000139B44: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 000000139B48: 109A9D4D
	ds_store_b32 v75, v77 offset:12800                         // 000000139B4C: D8343200 00004D4B
	v_add_nc_u32_e32 v75, 0x210, v75                           // 000000139B54: 4A9696FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000139B5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000139B60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5800>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000139B64: 8C7E067E
	v_add_nc_u32_e32 v105, 0x3200, v3                          // 000000139B68: 4AD206FF 00003200
	v_add_nc_u32_e32 v106, 0x3600, v3                          // 000000139B70: 4AD406FF 00003600
	v_add_nc_u32_e32 v107, 0x3a00, v3                          // 000000139B78: 4AD606FF 00003A00
	v_add_nc_u32_e32 v108, 0x3e00, v3                          // 000000139B80: 4AD806FF 00003E00
	s_waitcnt lgkmcnt(0)                                       // 000000139B88: BF89FC07
	s_barrier                                                  // 000000139B8C: BFBD0000
	buffer_gl0_inv                                             // 000000139B90: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 000000139B98: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 000000139BA0: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 000000139BA8: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 000000139BB0: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 000000139BB8: 7EDA0300
	s_mov_b32 s4, 0                                            // 000000139BBC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000139BC0: BF840001
	s_nop 0                                                    // 000000139BC4: BF800000
	s_nop 0                                                    // 000000139BC8: BF800000
	s_nop 0                                                    // 000000139BCC: BF800000
	s_nop 0                                                    // 000000139BD0: BF800000
	s_nop 0                                                    // 000000139BD4: BF800000
	s_nop 0                                                    // 000000139BD8: BF800000
	s_nop 0                                                    // 000000139BDC: BF800000
	s_nop 0                                                    // 000000139BE0: BF800000
	s_nop 0                                                    // 000000139BE4: BF800000
	s_nop 0                                                    // 000000139BE8: BF800000
	s_nop 0                                                    // 000000139BEC: BF800000
	s_nop 0                                                    // 000000139BF0: BF800000
	s_nop 0                                                    // 000000139BF4: BF800000
	s_nop 0                                                    // 000000139BF8: BF800000
	s_nop 0                                                    // 000000139BFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139C00: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 000000139C04: 32DCDA87
	.long 0xd4490001                                           // 000000139C08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 000000139C0C: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v112, 2, v110                            // 000000139C14: 30E0DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 000000139C18: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 000000139C24: 8C040401
	v_add_nc_u32_e32 v117, 0x2000, v112                        // 000000139C28: 4AEAE0FF 00002000
	ds_load_b32 v118, v110                                     // 000000139C30: D8D80000 7600006E
	ds_load_2addr_b32 v[111:112], v117 offset0:64 offset1:81   // 000000139C38: D8DC5140 6F000075
	ds_load_2addr_b32 v[113:114], v117 offset0:98 offset1:115  // 000000139C40: D8DC7362 71000075
	ds_load_2addr_b32 v[115:116], v117 offset0:132 offset1:149 // 000000139C48: D8DC9584 73000075
	s_waitcnt lgkmcnt(2)                                       // 000000139C50: BF89FC27
	v_fmac_f32_e32 v118, v72, v111                             // 000000139C54: 56ECDF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000139C58: BF8700C1
	v_fmac_f32_e32 v118, v73, v112                             // 000000139C5C: 56ECE149
	ds_load_2addr_b32 v[111:112], v117 offset0:166 offset1:183 // 000000139C60: D8DCB7A6 6F000075
	s_waitcnt lgkmcnt(2)                                       // 000000139C68: BF89FC27
	v_fmac_f32_e32 v118, v74, v113                             // 000000139C6C: 56ECE34A
	v_fmac_f32_e32 v118, v75, v114                             // 000000139C70: 56ECE54B
	s_waitcnt lgkmcnt(1)                                       // 000000139C74: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139C78: BF870091
	v_fmac_f32_e32 v118, v76, v115                             // 000000139C7C: 56ECE74C
	v_fmac_f32_e32 v118, v77, v116                             // 000000139C80: 56ECE94D
	s_waitcnt lgkmcnt(0)                                       // 000000139C84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139C88: BF870091
	v_dual_fmac_f32 v118, v78, v111 :: v_dual_add_nc_u32 v111, 0x80, v109// 000000139C8C: C820DF4E 766EDAFF 00000080
	v_fmac_f32_e32 v118, v79, v112                             // 000000139C98: 56ECE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000139C9C: BF870002
	v_mov_b32_e32 v109, v111                                   // 000000139CA0: 7EDA036F
	ds_store_b32 v110, v118                                    // 000000139CA4: D8340000 0000766E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000139CAC: 917E047E
	s_cbranch_execnz 65491                                     // 000000139CB0: BFA6FFD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5900>
	s_set_inst_prefetch_distance 0x2                           // 000000139CB4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000139CB8: 8C7E047E
	v_dual_mov_b32 v73, v59 :: v_dual_mov_b32 v72, v58         // 000000139CBC: CA10013B 4948013A
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 000000139CC4: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 000000139CCC: 7E980352
	s_mov_b32 s6, 0                                            // 000000139CD0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000139CD4: BF89FC07
	s_barrier                                                  // 000000139CD8: BFBD0000
	buffer_gl0_inv                                             // 000000139CDC: E0AC0000 00000000
	s_nop 0                                                    // 000000139CE4: BF800000
	s_nop 0                                                    // 000000139CE8: BF800000
	s_nop 0                                                    // 000000139CEC: BF800000
	s_nop 0                                                    // 000000139CF0: BF800000
	s_nop 0                                                    // 000000139CF4: BF800000
	s_nop 0                                                    // 000000139CF8: BF800000
	s_nop 0                                                    // 000000139CFC: BF800000
	global_load_b32 v77, v[72:73], off                         // 000000139D00: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17056                          // 000000139D08: D8D842A0 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 000000139D10: 4A9898FF 00000080
	.long 0xd7000148                                           // 000000139D18: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000139D1C: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 000000139D24: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000139D28: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000139D30: BF870004
	.long 0xd4490004                                           // 000000139D34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 000000139D38: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000139D40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000139D44: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 000000139D48: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 000000139D4C: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000139D54: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000139D5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000139D60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000139D64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000139D68: BF89FC07
	s_barrier                                                  // 000000139D6C: BFBD0000
	buffer_gl0_inv                                             // 000000139D70: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 000000139D78: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 000000139D80: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 000000139D88: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 000000139D90: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 000000139D98: 7EDA0300
	s_mov_b32 s4, 0                                            // 000000139D9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000139DA0: BF840001
	s_nop 0                                                    // 000000139DA4: BF800000
	s_nop 0                                                    // 000000139DA8: BF800000
	s_nop 0                                                    // 000000139DAC: BF800000
	s_nop 0                                                    // 000000139DB0: BF800000
	s_nop 0                                                    // 000000139DB4: BF800000
	s_nop 0                                                    // 000000139DB8: BF800000
	s_nop 0                                                    // 000000139DBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139DC0: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 000000139DC4: 32DCDA87
	.long 0xd4490001                                           // 000000139DC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 000000139DCC: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v115, 2, v110                            // 000000139DD4: 30E6DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 000000139DD8: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 000000139DE4: 8C040401
	v_add_nc_u32_e32 v113, 0x2000, v115                        // 000000139DE8: 4AE2E6FF 00002000
	v_add_nc_u32_e32 v118, 0x2400, v115                        // 000000139DF0: 4AECE6FF 00002400
	ds_load_b32 v117, v110                                     // 000000139DF8: D8D80000 7500006E
	ds_load_2addr_b32 v[111:112], v113 offset0:200 offset1:217 // 000000139E00: D8DCD9C8 6F000071
	ds_load_2addr_b32 v[113:114], v113 offset0:234 offset1:251 // 000000139E08: D8DCFBEA 71000071
	ds_load_2addr_b32 v[115:116], v118 offset0:12 offset1:29   // 000000139E10: D8DC1D0C 73000076
	s_waitcnt lgkmcnt(2)                                       // 000000139E18: BF89FC27
	v_fmac_f32_e32 v117, v72, v111                             // 000000139E1C: 56EADF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000139E20: BF8700C1
	v_fmac_f32_e32 v117, v73, v112                             // 000000139E24: 56EAE149
	ds_load_2addr_b32 v[111:112], v118 offset0:46 offset1:63   // 000000139E28: D8DC3F2E 6F000076
	s_waitcnt lgkmcnt(2)                                       // 000000139E30: BF89FC27
	v_fmac_f32_e32 v117, v74, v113                             // 000000139E34: 56EAE34A
	v_fmac_f32_e32 v117, v75, v114                             // 000000139E38: 56EAE54B
	s_waitcnt lgkmcnt(1)                                       // 000000139E3C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E40: BF870091
	v_fmac_f32_e32 v117, v76, v115                             // 000000139E44: 56EAE74C
	v_fmac_f32_e32 v117, v77, v116                             // 000000139E48: 56EAE94D
	s_waitcnt lgkmcnt(0)                                       // 000000139E4C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139E50: BF870121
	v_fmac_f32_e32 v117, v78, v111                             // 000000139E54: 56EADF4E
	v_add_nc_u32_e32 v111, 0x80, v109                          // 000000139E58: 4ADEDAFF 00000080
	v_fmac_f32_e32 v117, v79, v112                             // 000000139E60: 56EAE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000139E64: BF870002
	v_mov_b32_e32 v109, v111                                   // 000000139E68: 7EDA036F
	ds_store_b32 v110, v117                                    // 000000139E6C: D8340000 0000756E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000139E74: 917E047E
	s_cbranch_execnz 65489                                     // 000000139E78: BFA6FFD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ac0>
	s_set_inst_prefetch_distance 0x2                           // 000000139E7C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000139E80: 8C7E047E
	v_dual_mov_b32 v73, v61 :: v_dual_mov_b32 v72, v60         // 000000139E84: CA10013D 4948013C
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 000000139E8C: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 000000139E94: 7E980352
	s_mov_b32 s6, 0                                            // 000000139E98: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000139E9C: BF89FC07
	s_barrier                                                  // 000000139EA0: BFBD0000
	buffer_gl0_inv                                             // 000000139EA4: E0AC0000 00000000
	s_nop 0                                                    // 000000139EAC: BF800000
	s_nop 0                                                    // 000000139EB0: BF800000
	s_nop 0                                                    // 000000139EB4: BF800000
	s_nop 0                                                    // 000000139EB8: BF800000
	s_nop 0                                                    // 000000139EBC: BF800000
	global_load_b32 v77, v[72:73], off                         // 000000139EC0: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17088                          // 000000139EC8: D8D842C0 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 000000139ED0: 4A9898FF 00000080
	.long 0xd7000148                                           // 000000139ED8: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 000000139EDC: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 000000139EE4: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 000000139EE8: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000139EF0: BF870004
	.long 0xd4490004                                           // 000000139EF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 000000139EF8: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000139F00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000139F04: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 000000139F08: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 000000139F0C: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 000000139F14: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000139F1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000139F20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000139F24: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000139F28: BF89FC07
	s_barrier                                                  // 000000139F2C: BFBD0000
	buffer_gl0_inv                                             // 000000139F30: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 000000139F38: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 000000139F40: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 000000139F48: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 000000139F50: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 000000139F58: 7EDA0300
	s_mov_b32 s4, 0                                            // 000000139F5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000139F60: BF840001
	s_nop 0                                                    // 000000139F64: BF800000
	s_nop 0                                                    // 000000139F68: BF800000
	s_nop 0                                                    // 000000139F6C: BF800000
	s_nop 0                                                    // 000000139F70: BF800000
	s_nop 0                                                    // 000000139F74: BF800000
	s_nop 0                                                    // 000000139F78: BF800000
	s_nop 0                                                    // 000000139F7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139F80: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 000000139F84: 32DCDA87
	.long 0xd4490001                                           // 000000139F88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 000000139F8C: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v112, 2, v110                            // 000000139F94: 30E0DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 000000139F98: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 000000139FA4: 8C040401
	v_add_nc_u32_e32 v117, 0x2400, v112                        // 000000139FA8: 4AEAE0FF 00002400
	ds_load_b32 v118, v110                                     // 000000139FB0: D8D80000 7600006E
	ds_load_2addr_b32 v[111:112], v117 offset0:80 offset1:97   // 000000139FB8: D8DC6150 6F000075
	ds_load_2addr_b32 v[113:114], v117 offset0:114 offset1:131 // 000000139FC0: D8DC8372 71000075
	ds_load_2addr_b32 v[115:116], v117 offset0:148 offset1:165 // 000000139FC8: D8DCA594 73000075
	s_waitcnt lgkmcnt(2)                                       // 000000139FD0: BF89FC27
	v_fmac_f32_e32 v118, v72, v111                             // 000000139FD4: 56ECDF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000139FD8: BF8700C1
	v_fmac_f32_e32 v118, v73, v112                             // 000000139FDC: 56ECE149
	ds_load_2addr_b32 v[111:112], v117 offset0:182 offset1:199 // 000000139FE0: D8DCC7B6 6F000075
	s_waitcnt lgkmcnt(2)                                       // 000000139FE8: BF89FC27
	v_fmac_f32_e32 v118, v74, v113                             // 000000139FEC: 56ECE34A
	v_fmac_f32_e32 v118, v75, v114                             // 000000139FF0: 56ECE54B
	s_waitcnt lgkmcnt(1)                                       // 000000139FF4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139FF8: BF870091
	v_fmac_f32_e32 v118, v76, v115                             // 000000139FFC: 56ECE74C
	v_fmac_f32_e32 v118, v77, v116                             // 00000013A000: 56ECE94D
	s_waitcnt lgkmcnt(0)                                       // 00000013A004: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A008: BF870091
	v_dual_fmac_f32 v118, v78, v111 :: v_dual_add_nc_u32 v111, 0x80, v109// 00000013A00C: C820DF4E 766EDAFF 00000080
	v_fmac_f32_e32 v118, v79, v112                             // 00000013A018: 56ECE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A01C: BF870002
	v_mov_b32_e32 v109, v111                                   // 00000013A020: 7EDA036F
	ds_store_b32 v110, v118                                    // 00000013A024: D8340000 0000766E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A02C: 917E047E
	s_cbranch_execnz 65491                                     // 00000013A030: BFA6FFD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c80>
	s_set_inst_prefetch_distance 0x2                           // 00000013A034: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A038: 8C7E047E
	v_dual_mov_b32 v73, v63 :: v_dual_mov_b32 v72, v62         // 00000013A03C: CA10013F 4948013E
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 00000013A044: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 00000013A04C: 7E980352
	s_mov_b32 s6, 0                                            // 00000013A050: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000013A054: BF89FC07
	s_barrier                                                  // 00000013A058: BFBD0000
	buffer_gl0_inv                                             // 00000013A05C: E0AC0000 00000000
	s_nop 0                                                    // 00000013A064: BF800000
	s_nop 0                                                    // 00000013A068: BF800000
	s_nop 0                                                    // 00000013A06C: BF800000
	s_nop 0                                                    // 00000013A070: BF800000
	s_nop 0                                                    // 00000013A074: BF800000
	s_nop 0                                                    // 00000013A078: BF800000
	s_nop 0                                                    // 00000013A07C: BF800000
	global_load_b32 v77, v[72:73], off                         // 00000013A080: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17120                          // 00000013A088: D8D842E0 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 00000013A090: 4A9898FF 00000080
	.long 0xd7000148                                           // 00000013A098: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 00000013A09C: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 00000013A0A4: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 00000013A0A8: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013A0B0: BF870004
	.long 0xd4490004                                           // 00000013A0B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 00000013A0B8: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000013A0C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013A0C4: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 00000013A0C8: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 00000013A0CC: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 00000013A0D4: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013A0DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000013A0E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d80>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013A0E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000013A0E8: BF89FC07
	s_barrier                                                  // 00000013A0EC: BFBD0000
	buffer_gl0_inv                                             // 00000013A0F0: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 00000013A0F8: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 00000013A100: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 00000013A108: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 00000013A110: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 00000013A118: 7EDA0300
	s_mov_b32 s4, 0                                            // 00000013A11C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000013A120: BF840001
	s_nop 0                                                    // 00000013A124: BF800000
	s_nop 0                                                    // 00000013A128: BF800000
	s_nop 0                                                    // 00000013A12C: BF800000
	s_nop 0                                                    // 00000013A130: BF800000
	s_nop 0                                                    // 00000013A134: BF800000
	s_nop 0                                                    // 00000013A138: BF800000
	s_nop 0                                                    // 00000013A13C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A140: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 00000013A144: 32DCDA87
	.long 0xd4490001                                           // 00000013A148: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 00000013A14C: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v115, 2, v110                            // 00000013A154: 30E6DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 00000013A158: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 00000013A164: 8C040401
	v_add_nc_u32_e32 v111, 0x2400, v115                        // 00000013A168: 4ADEE6FF 00002400
	v_add_nc_u32_e32 v113, 0x2600, v115                        // 00000013A170: 4AE2E6FF 00002600
	v_add_nc_u32_e32 v118, 0x2800, v115                        // 00000013A178: 4AECE6FF 00002800
	ds_load_b32 v117, v110                                     // 00000013A180: D8D80000 7500006E
	ds_load_2addr_b32 v[111:112], v111 offset0:216 offset1:233 // 00000013A188: D8DCE9D8 6F00006F
	ds_load_2addr_b32 v[113:114], v113 offset0:122 offset1:139 // 00000013A190: D8DC8B7A 71000071
	ds_load_2addr_b32 v[115:116], v118 offset0:28 offset1:45   // 00000013A198: D8DC2D1C 73000076
	s_waitcnt lgkmcnt(2)                                       // 00000013A1A0: BF89FC27
	v_fmac_f32_e32 v117, v72, v111                             // 00000013A1A4: 56EADF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013A1A8: BF8700C1
	v_fmac_f32_e32 v117, v73, v112                             // 00000013A1AC: 56EAE149
	ds_load_2addr_b32 v[111:112], v118 offset0:62 offset1:79   // 00000013A1B0: D8DC4F3E 6F000076
	s_waitcnt lgkmcnt(2)                                       // 00000013A1B8: BF89FC27
	v_fmac_f32_e32 v117, v74, v113                             // 00000013A1BC: 56EAE34A
	v_fmac_f32_e32 v117, v75, v114                             // 00000013A1C0: 56EAE54B
	s_waitcnt lgkmcnt(1)                                       // 00000013A1C4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A1C8: BF870091
	v_fmac_f32_e32 v117, v76, v115                             // 00000013A1CC: 56EAE74C
	v_fmac_f32_e32 v117, v77, v116                             // 00000013A1D0: 56EAE94D
	s_waitcnt lgkmcnt(0)                                       // 00000013A1D4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A1D8: BF870121
	v_fmac_f32_e32 v117, v78, v111                             // 00000013A1DC: 56EADF4E
	v_add_nc_u32_e32 v111, 0x80, v109                          // 00000013A1E0: 4ADEDAFF 00000080
	v_fmac_f32_e32 v117, v79, v112                             // 00000013A1E8: 56EAE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A1EC: BF870002
	v_mov_b32_e32 v109, v111                                   // 00000013A1F0: 7EDA036F
	ds_store_b32 v110, v117                                    // 00000013A1F4: D8340000 0000756E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A1FC: 917E047E
	s_cbranch_execnz 65487                                     // 00000013A200: BFA6FFCF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e40>
	s_set_inst_prefetch_distance 0x2                           // 00000013A204: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A208: 8C7E047E
	v_dual_mov_b32 v73, v65 :: v_dual_mov_b32 v72, v64         // 00000013A20C: CA100141 49480140
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 00000013A214: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 00000013A21C: 7E980352
	s_mov_b32 s6, 0                                            // 00000013A220: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000013A224: BF89FC07
	s_barrier                                                  // 00000013A228: BFBD0000
	buffer_gl0_inv                                             // 00000013A22C: E0AC0000 00000000
	s_nop 0                                                    // 00000013A234: BF800000
	s_nop 0                                                    // 00000013A238: BF800000
	s_nop 0                                                    // 00000013A23C: BF800000
	global_load_b32 v77, v[72:73], off                         // 00000013A240: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17152                          // 00000013A248: D8D84300 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 00000013A250: 4A9898FF 00000080
	.long 0xd7000148                                           // 00000013A258: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 00000013A25C: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 00000013A264: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 00000013A268: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013A270: BF870004
	.long 0xd4490004                                           // 00000013A274: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 00000013A278: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000013A280: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013A284: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 00000013A288: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 00000013A28C: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 00000013A294: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013A29C: 917E067E
	s_cbranch_execnz 65511                                     // 00000013A2A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f40>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013A2A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000013A2A8: BF89FC07
	s_barrier                                                  // 00000013A2AC: BFBD0000
	buffer_gl0_inv                                             // 00000013A2B0: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 00000013A2B8: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 00000013A2C0: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 00000013A2C8: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 00000013A2D0: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 00000013A2D8: 7EDA0300
	s_mov_b32 s4, 0                                            // 00000013A2DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000013A2E0: BF840001
	s_nop 0                                                    // 00000013A2E4: BF800000
	s_nop 0                                                    // 00000013A2E8: BF800000
	s_nop 0                                                    // 00000013A2EC: BF800000
	s_nop 0                                                    // 00000013A2F0: BF800000
	s_nop 0                                                    // 00000013A2F4: BF800000
	s_nop 0                                                    // 00000013A2F8: BF800000
	s_nop 0                                                    // 00000013A2FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A300: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 00000013A304: 32DCDA87
	.long 0xd4490001                                           // 00000013A308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 00000013A30C: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v112, 2, v110                            // 00000013A314: 30E0DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 00000013A318: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 00000013A324: 8C040401
	v_add_nc_u32_e32 v117, 0x2800, v112                        // 00000013A328: 4AEAE0FF 00002800
	ds_load_b32 v118, v110                                     // 00000013A330: D8D80000 7600006E
	ds_load_2addr_b32 v[111:112], v117 offset0:96 offset1:113  // 00000013A338: D8DC7160 6F000075
	ds_load_2addr_b32 v[113:114], v117 offset0:130 offset1:147 // 00000013A340: D8DC9382 71000075
	ds_load_2addr_b32 v[115:116], v117 offset0:164 offset1:181 // 00000013A348: D8DCB5A4 73000075
	s_waitcnt lgkmcnt(2)                                       // 00000013A350: BF89FC27
	v_fmac_f32_e32 v118, v72, v111                             // 00000013A354: 56ECDF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013A358: BF8700C1
	v_fmac_f32_e32 v118, v73, v112                             // 00000013A35C: 56ECE149
	ds_load_2addr_b32 v[111:112], v117 offset0:198 offset1:215 // 00000013A360: D8DCD7C6 6F000075
	s_waitcnt lgkmcnt(2)                                       // 00000013A368: BF89FC27
	v_fmac_f32_e32 v118, v74, v113                             // 00000013A36C: 56ECE34A
	v_fmac_f32_e32 v118, v75, v114                             // 00000013A370: 56ECE54B
	s_waitcnt lgkmcnt(1)                                       // 00000013A374: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A378: BF870091
	v_fmac_f32_e32 v118, v76, v115                             // 00000013A37C: 56ECE74C
	v_fmac_f32_e32 v118, v77, v116                             // 00000013A380: 56ECE94D
	s_waitcnt lgkmcnt(0)                                       // 00000013A384: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A388: BF870091
	v_dual_fmac_f32 v118, v78, v111 :: v_dual_add_nc_u32 v111, 0x80, v109// 00000013A38C: C820DF4E 766EDAFF 00000080
	v_fmac_f32_e32 v118, v79, v112                             // 00000013A398: 56ECE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A39C: BF870002
	v_mov_b32_e32 v109, v111                                   // 00000013A3A0: 7EDA036F
	ds_store_b32 v110, v118                                    // 00000013A3A4: D8340000 0000766E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A3AC: 917E047E
	s_cbranch_execnz 65491                                     // 00000013A3B0: BFA6FFD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6000>
	s_set_inst_prefetch_distance 0x2                           // 00000013A3B4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A3B8: 8C7E047E
	v_dual_mov_b32 v73, v67 :: v_dual_mov_b32 v72, v66         // 00000013A3BC: CA100143 49480142
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 00000013A3C4: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 00000013A3CC: 7E980352
	s_mov_b32 s6, 0                                            // 00000013A3D0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000013A3D4: BF89FC07
	s_barrier                                                  // 00000013A3D8: BFBD0000
	buffer_gl0_inv                                             // 00000013A3DC: E0AC0000 00000000
	s_nop 0                                                    // 00000013A3E4: BF800000
	s_nop 0                                                    // 00000013A3E8: BF800000
	s_nop 0                                                    // 00000013A3EC: BF800000
	s_nop 0                                                    // 00000013A3F0: BF800000
	s_nop 0                                                    // 00000013A3F4: BF800000
	s_nop 0                                                    // 00000013A3F8: BF800000
	s_nop 0                                                    // 00000013A3FC: BF800000
	global_load_b32 v77, v[72:73], off                         // 00000013A400: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17184                          // 00000013A408: D8D84320 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 00000013A410: 4A9898FF 00000080
	.long 0xd7000148                                           // 00000013A418: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 00000013A41C: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 00000013A424: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 00000013A428: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013A430: BF870004
	.long 0xd4490004                                           // 00000013A434: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 00000013A438: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000013A440: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013A444: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 00000013A448: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 00000013A44C: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 00000013A454: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013A45C: 917E067E
	s_cbranch_execnz 65511                                     // 00000013A460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6100>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013A464: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000013A468: BF89FC07
	s_barrier                                                  // 00000013A46C: BFBD0000
	buffer_gl0_inv                                             // 00000013A470: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 00000013A478: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 00000013A480: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 00000013A488: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 00000013A490: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 00000013A498: 7EDA0300
	s_mov_b32 s4, 0                                            // 00000013A49C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000013A4A0: BF840001
	s_nop 0                                                    // 00000013A4A4: BF800000
	s_nop 0                                                    // 00000013A4A8: BF800000
	s_nop 0                                                    // 00000013A4AC: BF800000
	s_nop 0                                                    // 00000013A4B0: BF800000
	s_nop 0                                                    // 00000013A4B4: BF800000
	s_nop 0                                                    // 00000013A4B8: BF800000
	s_nop 0                                                    // 00000013A4BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A4C0: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 00000013A4C4: 32DCDA87
	.long 0xd4490001                                           // 00000013A4C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 00000013A4CC: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v113, 2, v110                            // 00000013A4D4: 30E2DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 00000013A4D8: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 00000013A4E4: 8C040401
	v_add_nc_u32_e32 v111, 0x2800, v113                        // 00000013A4E8: 4ADEE2FF 00002800
	v_add_nc_u32_e32 v118, 0x2c00, v113                        // 00000013A4F0: 4AECE2FF 00002C00
	ds_load_b32 v117, v110                                     // 00000013A4F8: D8D80000 7500006E
	ds_load_2addr_b32 v[111:112], v111 offset0:232 offset1:249 // 00000013A500: D8DCF9E8 6F00006F
	ds_load_2addr_b32 v[113:114], v118 offset0:10 offset1:27   // 00000013A508: D8DC1B0A 71000076
	ds_load_2addr_b32 v[115:116], v118 offset0:44 offset1:61   // 00000013A510: D8DC3D2C 73000076
	s_waitcnt lgkmcnt(2)                                       // 00000013A518: BF89FC27
	v_fmac_f32_e32 v117, v72, v111                             // 00000013A51C: 56EADF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013A520: BF8700C1
	v_fmac_f32_e32 v117, v73, v112                             // 00000013A524: 56EAE149
	ds_load_2addr_b32 v[111:112], v118 offset0:78 offset1:95   // 00000013A528: D8DC5F4E 6F000076
	s_waitcnt lgkmcnt(2)                                       // 00000013A530: BF89FC27
	v_fmac_f32_e32 v117, v74, v113                             // 00000013A534: 56EAE34A
	v_fmac_f32_e32 v117, v75, v114                             // 00000013A538: 56EAE54B
	s_waitcnt lgkmcnt(1)                                       // 00000013A53C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A540: BF870091
	v_fmac_f32_e32 v117, v76, v115                             // 00000013A544: 56EAE74C
	v_fmac_f32_e32 v117, v77, v116                             // 00000013A548: 56EAE94D
	s_waitcnt lgkmcnt(0)                                       // 00000013A54C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A550: BF870121
	v_fmac_f32_e32 v117, v78, v111                             // 00000013A554: 56EADF4E
	v_add_nc_u32_e32 v111, 0x80, v109                          // 00000013A558: 4ADEDAFF 00000080
	v_fmac_f32_e32 v117, v79, v112                             // 00000013A560: 56EAE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A564: BF870002
	v_mov_b32_e32 v109, v111                                   // 00000013A568: 7EDA036F
	ds_store_b32 v110, v117                                    // 00000013A56C: D8340000 0000756E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A574: 917E047E
	s_cbranch_execnz 65489                                     // 00000013A578: BFA6FFD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x61c0>
	s_set_inst_prefetch_distance 0x2                           // 00000013A57C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A580: 8C7E047E
	v_dual_mov_b32 v73, v69 :: v_dual_mov_b32 v72, v68         // 00000013A584: CA100145 49480144
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 00000013A58C: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 00000013A594: 7E980352
	s_mov_b32 s6, 0                                            // 00000013A598: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000013A59C: BF89FC07
	s_barrier                                                  // 00000013A5A0: BFBD0000
	buffer_gl0_inv                                             // 00000013A5A4: E0AC0000 00000000
	s_nop 0                                                    // 00000013A5AC: BF800000
	s_nop 0                                                    // 00000013A5B0: BF800000
	s_nop 0                                                    // 00000013A5B4: BF800000
	s_nop 0                                                    // 00000013A5B8: BF800000
	s_nop 0                                                    // 00000013A5BC: BF800000
	global_load_b32 v77, v[72:73], off                         // 00000013A5C0: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17216                          // 00000013A5C8: D8D84340 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 00000013A5D0: 4A9898FF 00000080
	.long 0xd7000148                                           // 00000013A5D8: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 00000013A5DC: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 00000013A5E4: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 00000013A5E8: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013A5F0: BF870004
	.long 0xd4490004                                           // 00000013A5F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 00000013A5F8: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000013A600: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013A604: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 00000013A608: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 00000013A60C: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 00000013A614: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013A61C: 917E067E
	s_cbranch_execnz 65511                                     // 00000013A620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013A624: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000013A628: BF89FC07
	s_barrier                                                  // 00000013A62C: BFBD0000
	buffer_gl0_inv                                             // 00000013A630: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 00000013A638: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 00000013A640: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 00000013A648: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 00000013A650: D8DC9C18 4E00006C
	v_mov_b32_e32 v109, v0                                     // 00000013A658: 7EDA0300
	s_mov_b32 s4, 0                                            // 00000013A65C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000013A660: BF840001
	s_nop 0                                                    // 00000013A664: BF800000
	s_nop 0                                                    // 00000013A668: BF800000
	s_nop 0                                                    // 00000013A66C: BF800000
	s_nop 0                                                    // 00000013A670: BF800000
	s_nop 0                                                    // 00000013A674: BF800000
	s_nop 0                                                    // 00000013A678: BF800000
	s_nop 0                                                    // 00000013A67C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A680: BF870121
	v_lshrrev_b32_e32 v110, 7, v109                            // 00000013A684: 32DCDA87
	.long 0xd4490001                                           // 00000013A688: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v109, vcc_lo                  // 00000013A68C: 0202DAFF 0000077F
	v_lshlrev_b32_e32 v112, 2, v110                            // 00000013A694: 30E0DC82
	v_mad_u64_u32 v[110:111], null, 0x210, v110, v[3:4]        // 00000013A698: D6FE7C6E 040EDCFF 00000210
	s_or_b32 s4, s1, s4                                        // 00000013A6A4: 8C040401
	v_add_nc_u32_e32 v117, 0x2c00, v112                        // 00000013A6A8: 4AEAE0FF 00002C00
	ds_load_b32 v118, v110                                     // 00000013A6B0: D8D80000 7600006E
	ds_load_2addr_b32 v[111:112], v117 offset0:112 offset1:129 // 00000013A6B8: D8DC8170 6F000075
	ds_load_2addr_b32 v[113:114], v117 offset0:146 offset1:163 // 00000013A6C0: D8DCA392 71000075
	ds_load_2addr_b32 v[115:116], v117 offset0:180 offset1:197 // 00000013A6C8: D8DCC5B4 73000075
	s_waitcnt lgkmcnt(2)                                       // 00000013A6D0: BF89FC27
	v_fmac_f32_e32 v118, v72, v111                             // 00000013A6D4: 56ECDF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013A6D8: BF8700C1
	v_fmac_f32_e32 v118, v73, v112                             // 00000013A6DC: 56ECE149
	ds_load_2addr_b32 v[111:112], v117 offset0:214 offset1:231 // 00000013A6E0: D8DCE7D6 6F000075
	s_waitcnt lgkmcnt(2)                                       // 00000013A6E8: BF89FC27
	v_fmac_f32_e32 v118, v74, v113                             // 00000013A6EC: 56ECE34A
	v_fmac_f32_e32 v118, v75, v114                             // 00000013A6F0: 56ECE54B
	s_waitcnt lgkmcnt(1)                                       // 00000013A6F4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A6F8: BF870091
	v_fmac_f32_e32 v118, v76, v115                             // 00000013A6FC: 56ECE74C
	v_fmac_f32_e32 v118, v77, v116                             // 00000013A700: 56ECE94D
	s_waitcnt lgkmcnt(0)                                       // 00000013A704: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A708: BF870091
	v_dual_fmac_f32 v118, v78, v111 :: v_dual_add_nc_u32 v111, 0x80, v109// 00000013A70C: C820DF4E 766EDAFF 00000080
	v_fmac_f32_e32 v118, v79, v112                             // 00000013A718: 56ECE14F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A71C: BF870002
	v_mov_b32_e32 v109, v111                                   // 00000013A720: 7EDA036F
	ds_store_b32 v110, v118                                    // 00000013A724: D8340000 0000766E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A72C: 917E047E
	s_cbranch_execnz 65491                                     // 00000013A730: BFA6FFD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6380>
	s_set_inst_prefetch_distance 0x2                           // 00000013A734: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A738: 8C7E047E
	v_dual_mov_b32 v73, v71 :: v_dual_mov_b32 v72, v70         // 00000013A73C: CA100147 49480146
	v_dual_mov_b32 v74, v3 :: v_dual_mov_b32 v75, 0            // 00000013A744: CA100103 4A4A0080
	v_mov_b32_e32 v76, v82                                     // 00000013A74C: 7E980352
	s_mov_b32 s6, 0                                            // 00000013A750: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000013A754: BF89FC07
	s_barrier                                                  // 00000013A758: BFBD0000
	buffer_gl0_inv                                             // 00000013A75C: E0AC0000 00000000
	s_nop 0                                                    // 00000013A764: BF800000
	s_nop 0                                                    // 00000013A768: BF800000
	s_nop 0                                                    // 00000013A76C: BF800000
	s_nop 0                                                    // 00000013A770: BF800000
	s_nop 0                                                    // 00000013A774: BF800000
	s_nop 0                                                    // 00000013A778: BF800000
	s_nop 0                                                    // 00000013A77C: BF800000
	global_load_b32 v77, v[72:73], off                         // 00000013A780: DC520000 4D7C0048
	ds_load_b32 v78, v75 offset:17248                          // 00000013A788: D8D84360 4E00004B
	v_add_nc_u32_e32 v76, 0x80, v76                            // 00000013A790: 4A9898FF 00000080
	.long 0xd7000148                                           // 00000013A798: D7000148
	v_cndmask_b32_e32 v1, 0x6000, v72, vcc_lo                  // 00000013A79C: 020290FF 00006000
	v_add_nc_u32_e32 v75, 4, v75                               // 00000013A7A4: 4A969684
	v_add_co_ci_u32_e64 v73, null, 0, v73, s1                  // 00000013A7A8: D5207C49 00069280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013A7B0: BF870004
	.long 0xd4490004                                           // 00000013A7B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v76, vcc_lo                   // 00000013A7B8: 020298FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000013A7C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013A7C4: BF890007
	v_mul_f32_e32 v77, v77, v78                                // 00000013A7C8: 109A9D4D
	ds_store_b32 v74, v77 offset:12800                         // 00000013A7CC: D8343200 00004D4A
	v_add_nc_u32_e32 v74, 0x210, v74                           // 00000013A7D4: 4A9494FF 00000210
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013A7DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000013A7E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6480>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013A7E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000013A7E8: BF89FC07
	s_barrier                                                  // 00000013A7EC: BFBD0000
	buffer_gl0_inv                                             // 00000013A7F0: E0AC0000 00000000
	ds_load_2addr_b32 v[72:73], v105 offset1:132               // 00000013A7F8: D8DC8400 48000069
	ds_load_2addr_b32 v[74:75], v106 offset0:8 offset1:140     // 00000013A800: D8DC8C08 4A00006A
	ds_load_2addr_b32 v[76:77], v107 offset0:16 offset1:148    // 00000013A808: D8DC9410 4C00006B
	ds_load_2addr_b32 v[78:79], v108 offset0:24 offset1:156    // 00000013A810: D8DC9C18 4E00006C
	v_mov_b32_e32 v105, v0                                     // 00000013A818: 7ED20300
	s_mov_b32 s4, 0                                            // 00000013A81C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000013A820: BF840001
	s_nop 0                                                    // 00000013A824: BF800000
	s_nop 0                                                    // 00000013A828: BF800000
	s_nop 0                                                    // 00000013A82C: BF800000
	s_nop 0                                                    // 00000013A830: BF800000
	s_nop 0                                                    // 00000013A834: BF800000
	s_nop 0                                                    // 00000013A838: BF800000
	s_nop 0                                                    // 00000013A83C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A840: BF870121
	v_lshrrev_b32_e32 v106, 7, v105                            // 00000013A844: 32D4D287
	.long 0xd4490001                                           // 00000013A848: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v105, vcc_lo                  // 00000013A84C: 0202D2FF 0000077F
	v_lshlrev_b32_e32 v109, 2, v106                            // 00000013A854: 30DAD482
	v_mad_u64_u32 v[106:107], null, 0x210, v106, v[3:4]        // 00000013A858: D6FE7C6A 040ED4FF 00000210
	s_or_b32 s4, s1, s4                                        // 00000013A864: 8C040401
	v_add_nc_u32_e32 v107, 0x2e00, v109                        // 00000013A868: 4AD6DAFF 00002E00
	v_add_nc_u32_e32 v114, 0x3000, v109                        // 00000013A870: 4AE4DAFF 00003000
	ds_load_b32 v113, v106                                     // 00000013A878: D8D80000 7100006A
	ds_load_2addr_b32 v[107:108], v107 offset0:120 offset1:137 // 00000013A880: D8DC8978 6B00006B
	ds_load_2addr_b32 v[109:110], v114 offset0:26 offset1:43   // 00000013A888: D8DC2B1A 6D000072
	ds_load_2addr_b32 v[111:112], v114 offset0:60 offset1:77   // 00000013A890: D8DC4D3C 6F000072
	s_waitcnt lgkmcnt(2)                                       // 00000013A898: BF89FC27
	v_fmac_f32_e32 v113, v72, v107                             // 00000013A89C: 56E2D748
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013A8A0: BF8700C1
	v_fmac_f32_e32 v113, v73, v108                             // 00000013A8A4: 56E2D949
	ds_load_2addr_b32 v[107:108], v114 offset0:94 offset1:111  // 00000013A8A8: D8DC6F5E 6B000072
	s_waitcnt lgkmcnt(2)                                       // 00000013A8B0: BF89FC27
	v_fmac_f32_e32 v113, v74, v109                             // 00000013A8B4: 56E2DB4A
	v_fmac_f32_e32 v113, v75, v110                             // 00000013A8B8: 56E2DD4B
	s_waitcnt lgkmcnt(1)                                       // 00000013A8BC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A8C0: BF870091
	v_fmac_f32_e32 v113, v76, v111                             // 00000013A8C4: 56E2DF4C
	v_fmac_f32_e32 v113, v77, v112                             // 00000013A8C8: 56E2E14D
	s_waitcnt lgkmcnt(0)                                       // 00000013A8CC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A8D0: BF870121
	v_fmac_f32_e32 v113, v78, v107                             // 00000013A8D4: 56E2D74E
	v_add_nc_u32_e32 v107, 0x80, v105                          // 00000013A8D8: 4AD6D2FF 00000080
	v_fmac_f32_e32 v113, v79, v108                             // 00000013A8E0: 56E2D94F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013A8E4: BF870002
	v_mov_b32_e32 v105, v107                                   // 00000013A8E8: 7ED2036B
	ds_store_b32 v106, v113                                    // 00000013A8EC: D8340000 0000716A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013A8F4: 917E047E
	s_cbranch_execnz 65489                                     // 00000013A8F8: BFA6FFD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6540>
	s_set_inst_prefetch_distance 0x2                           // 00000013A8FC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013A900: 8C7E047E
	.long 0xd7000106                                           // 00000013A904: D7000106
	v_cndmask_b32_e32 v1, 0x180000, v6, vcc_lo                 // 00000013A908: 02020CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A910: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, s1                    // 00000013A914: D5207C07 00060E80
	.long 0xd7000108                                           // 00000013A91C: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000013A920: 020210FF 00180000
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 00000013A928: D5207C09 00061280
	.long 0xd700010a                                           // 00000013A930: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 00000013A934: 020214FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A93C: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 00000013A940: D5207C0B 00061680
	.long 0xd700010c                                           // 00000013A948: D700010C
	v_cndmask_b32_e32 v1, 0x180000, v12, vcc_lo                // 00000013A94C: 020218FF 00180000
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 00000013A954: D5207C0D 00061A80
	.long 0xd7000110                                           // 00000013A95C: D7000110
	v_cndmask_b32_e32 v1, 0x180000, v16, vcc_lo                // 00000013A960: 020220FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A968: BF8700A1
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000013A96C: D5207C11 00062280
	.long 0xd7000112                                           // 00000013A974: D7000112
	v_cndmask_b32_e32 v1, 0x180000, v18, vcc_lo                // 00000013A978: 020224FF 00180000
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000013A980: D5207C13 00062680
	.long 0xd7000114                                           // 00000013A988: D7000114
	v_cndmask_b32_e32 v1, 0x180000, v20, vcc_lo                // 00000013A98C: 020228FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A994: BF8700A1
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 00000013A998: D5207C15 00062A80
	.long 0xd7000116                                           // 00000013A9A0: D7000116
	v_cndmask_b32_e32 v1, 0x180000, v22, vcc_lo                // 00000013A9A4: 02022CFF 00180000
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 00000013A9AC: D5207C17 00062E80
	.long 0xd7000118                                           // 00000013A9B4: D7000118
	v_cndmask_b32_e32 v1, 0x180000, v24, vcc_lo                // 00000013A9B8: 020230FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A9C0: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v25, s1                  // 00000013A9C4: D5207C19 00063280
	.long 0xd700011a                                           // 00000013A9CC: D700011A
	v_cndmask_b32_e32 v1, 0xc0000, v26, vcc_lo                 // 00000013A9D0: 020234FF 000C0000
	v_add_co_ci_u32_e64 v27, null, 0, v27, s1                  // 00000013A9D8: D5207C1B 00063680
	.long 0xd700011c                                           // 00000013A9E0: D700011C
	v_cndmask_b32_e32 v1, 0x180000, v28, vcc_lo                // 00000013A9E4: 020238FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A9EC: BF8700A1
	v_add_co_ci_u32_e64 v29, null, 0, v29, s1                  // 00000013A9F0: D5207C1D 00063A80
	.long 0xd700011e                                           // 00000013A9F8: D700011E
	v_cndmask_b32_e32 v1, 0xc0000, v30, vcc_lo                 // 00000013A9FC: 02023CFF 000C0000
	v_add_co_ci_u32_e64 v31, null, 0, v31, s1                  // 00000013AA04: D5207C1F 00063E80
	.long 0xd7000120                                           // 00000013AA0C: D7000120
	v_cndmask_b32_e32 v1, 0x180000, v32, vcc_lo                // 00000013AA10: 020240FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AA18: BF8700A1
	v_add_co_ci_u32_e64 v33, null, 0, v33, s1                  // 00000013AA1C: D5207C21 00064280
	.long 0xd7000122                                           // 00000013AA24: D7000122
	v_cndmask_b32_e32 v1, 0xc0000, v34, vcc_lo                 // 00000013AA28: 020244FF 000C0000
	v_add_co_ci_u32_e64 v35, null, 0, v35, s1                  // 00000013AA30: D5207C23 00064680
	.long 0xd7000124                                           // 00000013AA38: D7000124
	v_cndmask_b32_e32 v1, 0x180000, v36, vcc_lo                // 00000013AA3C: 020248FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AA44: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v37, s1                  // 00000013AA48: D5207C25 00064A80
	.long 0xd7000126                                           // 00000013AA50: D7000126
	v_cndmask_b32_e32 v1, 0xc0000, v38, vcc_lo                 // 00000013AA54: 02024CFF 000C0000
	v_add_co_ci_u32_e64 v39, null, 0, v39, s1                  // 00000013AA5C: D5207C27 00064E80
	.long 0xd7000128                                           // 00000013AA64: D7000128
	v_cndmask_b32_e32 v1, 0x180000, v40, vcc_lo                // 00000013AA68: 020250FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AA70: BF8700A1
	v_add_co_ci_u32_e64 v41, null, 0, v41, s1                  // 00000013AA74: D5207C29 00065280
	.long 0xd700012a                                           // 00000013AA7C: D700012A
	v_cndmask_b32_e32 v1, 0xc0000, v42, vcc_lo                 // 00000013AA80: 020254FF 000C0000
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000013AA88: D5207C2B 00065680
	.long 0xd700012c                                           // 00000013AA90: D700012C
	v_cndmask_b32_e32 v1, 0x180000, v44, vcc_lo                // 00000013AA94: 020258FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AA9C: BF8700A1
	v_add_co_ci_u32_e64 v45, null, 0, v45, s1                  // 00000013AAA0: D5207C2D 00065A80
	.long 0xd700012e                                           // 00000013AAA8: D700012E
	v_cndmask_b32_e32 v1, 0xc0000, v46, vcc_lo                 // 00000013AAAC: 02025CFF 000C0000
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 00000013AAB4: D5207C2F 00065E80
	.long 0xd7000130                                           // 00000013AABC: D7000130
	v_cndmask_b32_e32 v1, 0x180000, v48, vcc_lo                // 00000013AAC0: 020260FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AAC8: BF8700A1
	v_add_co_ci_u32_e64 v49, null, 0, v49, s1                  // 00000013AACC: D5207C31 00066280
	.long 0xd7000132                                           // 00000013AAD4: D7000132
	v_cndmask_b32_e32 v1, 0xc0000, v50, vcc_lo                 // 00000013AAD8: 020264FF 000C0000
	v_add_co_ci_u32_e64 v51, null, 0, v51, s1                  // 00000013AAE0: D5207C33 00066680
	.long 0xd7000134                                           // 00000013AAE8: D7000134
	v_cndmask_b32_e32 v1, 0x180000, v52, vcc_lo                // 00000013AAEC: 020268FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AAF4: BF8700A1
	v_add_co_ci_u32_e64 v53, null, 0, v53, s1                  // 00000013AAF8: D5207C35 00066A80
	.long 0xd7000136                                           // 00000013AB00: D7000136
	v_cndmask_b32_e32 v1, 0xc0000, v54, vcc_lo                 // 00000013AB04: 02026CFF 000C0000
	v_add_co_ci_u32_e64 v55, null, 0, v55, s1                  // 00000013AB0C: D5207C37 00066E80
	.long 0xd7000138                                           // 00000013AB14: D7000138
	v_cndmask_b32_e32 v1, 0x180000, v56, vcc_lo                // 00000013AB18: 020270FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AB20: BF8700A1
	v_add_co_ci_u32_e64 v57, null, 0, v57, s1                  // 00000013AB24: D5207C39 00067280
	.long 0xd700013a                                           // 00000013AB2C: D700013A
	v_cndmask_b32_e32 v1, 0x180000, v58, vcc_lo                // 00000013AB30: 020274FF 00180000
	v_add_co_ci_u32_e64 v59, null, 0, v59, s1                  // 00000013AB38: D5207C3B 00067680
	.long 0xd700013c                                           // 00000013AB40: D700013C
	v_cndmask_b32_e32 v1, 0x180000, v60, vcc_lo                // 00000013AB44: 020278FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AB4C: BF8700A1
	v_add_co_ci_u32_e64 v61, null, 0, v61, s1                  // 00000013AB50: D5207C3D 00067A80
	.long 0xd700013e                                           // 00000013AB58: D700013E
	v_cndmask_b32_e32 v1, 0x180000, v62, vcc_lo                // 00000013AB5C: 02027CFF 00180000
	v_add_co_ci_u32_e64 v63, null, 0, v63, s1                  // 00000013AB64: D5207C3F 00067E80
	.long 0xd7000140                                           // 00000013AB6C: D7000140
	v_cndmask_b32_e32 v1, 0x180000, v64, vcc_lo                // 00000013AB70: 020280FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013AB78: BF8700A1
	v_add_co_ci_u32_e64 v65, null, 0, v65, s1                  // 00000013AB7C: D5207C41 00068280
	.long 0xd7000142                                           // 00000013AB84: D7000142
	v_cndmask_b32_e32 v1, 0x180000, v66, vcc_lo                // 00000013AB88: 020284FF 00180000
	v_add_co_ci_u32_e64 v67, null, 0, v67, s1                  // 00000013AB90: D5207C43 00068680
	.long 0xd7000144                                           // 00000013AB98: D7000144
	v_cndmask_b32_e32 v1, 0x180000, v68, vcc_lo                // 00000013AB9C: 020288FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013ABA4: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v69, s1                  // 00000013ABA8: D5207C45 00068A80
	.long 0xd7000146                                           // 00000013ABB0: D7000146
	v_cndmask_b32_e32 v1, 0x180000, v70, vcc_lo                // 00000013ABB4: 02028CFF 00180000
	v_add_co_ci_u32_e64 v71, null, 0, v71, s1                  // 00000013ABBC: D5207C47 00068E80
	s_add_i32 s5, s5, 1                                        // 00000013ABC4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000013ABC8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000013ABCC: BF062105
	s_barrier                                                  // 00000013ABD0: BFBD0000
	buffer_gl0_inv                                             // 00000013ABD4: E0AC0000 00000000
	s_cbranch_scc0 59184                                       // 00000013ABDC: BFA1E730 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a0>
	v_dual_mov_b32 v2, v82 :: v_dual_mov_b32 v3, v1            // 00000013ABE0: CA100152 02020101
	s_add_u32 s0, s28, s20                                     // 00000013ABE8: 8000141C
	.long 0xd73c0000                                           // 00000013ABEC: D73C0000
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 00000013ABF0: 02021C89
	s_addc_u32 s1, s29, s21                                    // 00000013ABF4: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000013ABF8: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000013ABFC: 82031319
	s_add_u32 s0, s2, s0                                       // 00000013AC00: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000013AC04: 82010103
	.long 0xd7006a00                                           // 00000013AC08: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000013AC0C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000013AC10: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000013AC14: D5207C01 01AA0201
	v_mul_u32_u24_e32 v4, 0x210, v80                           // 00000013AC1C: 1608A0FF 00000210
	.long 0xd7006a00                                           // 00000013AC24: D7006A00
	v_cndmask_b32_e32 v1, v0, v83, vcc_lo                      // 00000013AC28: 0202A700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013AC2C: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000013AC30: D5207C01 01AA0280
	v_lshl_add_u32 v3, v3, 2, v4                               // 00000013AC38: D6460003 04110503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AC40: BF870093
	.long 0xd7006a00                                           // 00000013AC44: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000013AC48: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000013AC4C: D5207C01 01AA0211
	s_mov_b32 s1, 0                                            // 00000013AC54: BE810080
	s_nop 0                                                    // 00000013AC58: BF800000
	s_nop 0                                                    // 00000013AC5C: BF800000
	s_nop 0                                                    // 00000013AC60: BF800000
	s_nop 0                                                    // 00000013AC64: BF800000
	s_nop 0                                                    // 00000013AC68: BF800000
	s_nop 0                                                    // 00000013AC6C: BF800000
	s_nop 0                                                    // 00000013AC70: BF800000
	s_nop 0                                                    // 00000013AC74: BF800000
	s_nop 0                                                    // 00000013AC78: BF800000
	s_nop 0                                                    // 00000013AC7C: BF800000
	ds_load_b32 v4, v3                                         // 00000013AC80: D8D80000 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 00000013AC88: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 32, v3                                // 00000013AC90: 4A0606A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000013AC94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v2                         // 00000013AC98: 7C9204FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000013ACA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000013ACA4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 00000013ACA8: DC6A0000 007C0400
	.long 0xd7000000                                           // 00000013ACB0: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000013ACB4: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000013ACBC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000013ACC4: 917E017E
	s_cbranch_execnz 65517                                     // 00000013ACC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3tILi8ELi8ELi8ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6980>
	s_nop 0                                                    // 00000013ACCC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000013ACD0: BFB60003
	s_endpgm                                                   // 00000013ACD4: BFB00000
		...

