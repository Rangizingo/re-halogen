0000000000121600 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000121600: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000121604: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000012160C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000121614: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000121618: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000012161C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000121620: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000121628: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000012162C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000121630: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000121634: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000012163C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000121640: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000121644: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000121648: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012164C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000121650: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000121654: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000121658: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000012165C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000121664: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000012166C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000121670: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000121674: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000121678: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000012167C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000121680: 821E191E
	.long 0xd7001f02                                           // 000000121684: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000121688: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000012168C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000121694: BE9E0080
	s_nop 0                                                    // 000000121698: BF800000
	s_nop 0                                                    // 00000012169C: BF800000
	s_nop 0                                                    // 0000001216A0: BF800000
	s_nop 0                                                    // 0000001216A4: BF800000
	s_nop 0                                                    // 0000001216A8: BF800000
	s_nop 0                                                    // 0000001216AC: BF800000
	s_nop 0                                                    // 0000001216B0: BF800000
	s_nop 0                                                    // 0000001216B4: BF800000
	s_nop 0                                                    // 0000001216B8: BF800000
	s_nop 0                                                    // 0000001216BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000001216C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000001216C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001216CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001216D0: 300C1089
	.long 0xd7006a06                                           // 0000001216D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000001216D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001216DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000001216E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000001216E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000001216F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000001216F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000001216FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000121708: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000012170C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000121710: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000121718: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000012171C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000121720: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000121724: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000012172C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000121734: 32040084
	s_mov_b32 s0, 0                                            // 000000121738: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000012173C: BF89FC07
	s_barrier                                                  // 000000121740: BFBD0000
	buffer_gl0_inv                                             // 000000121744: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000012174C: BF02801E
	s_cbranch_scc1 12                                          // 000000121750: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000121754: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000012175C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000121764: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000121768: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000121770: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000121774: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000121778: 916A007E
	s_cbranch_vccz 2                                           // 00000012177C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2551                                              // 000000121780: BFA009F7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2960>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000121784: 304E0A82
	s_add_i32 s0, s30, 63                                      // 000000121788: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000012178C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000121794: 85218600
	s_add_u32 s34, s10, s24                                    // 000000121798: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000012179C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000001217A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000001217A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000001217AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000001217B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000001217B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000001217B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000001217BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000001217C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000001217C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000001217C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000001217D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000001217D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000001217DC: B00A0204
	.long 0xd7000b2c                                           // 0000001217E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000001217E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001217E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000001217EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000001217F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000121800: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000121804: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 000000121810: 3816500A
	.long 0xd7000a05                                           // 000000121814: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000121818: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012181C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000121820: D5207C06 00290001
	.long 0xd7000107                                           // 000000121828: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000012182C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121830: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000121834: D5207C08 0006180D
	.long 0xd7000109                                           // 00000012183C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000121840: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000121844: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000012184C: 84848E02
	.long 0xd700010b                                           // 000000121850: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000121854: 02021606
	s_add_u32 s4, s14, s4                                      // 000000121858: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000012185C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000121864: 8205050F
	.long 0xd700010d                                           // 000000121868: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000012186C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121870: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000121874: D5207C0E 00050005
	.long 0xd700010f                                           // 00000012187C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000121880: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000121888: D5207C10 00061880
	.long 0xd7000111                                           // 000000121890: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000121894: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012189C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000001218A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000001218A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000001218AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000001218B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000001218BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000001218C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001218C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000001218CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000001218D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000001218D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000001218E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000001218E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000001218EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001218F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000001218F8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000121900: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000121904: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000012190C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000121914: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000121918: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000121920: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000121924: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000012192C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000121934: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000012193C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000121944: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000012194C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000121954: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000012195C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000121964: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000012196C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000121974: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000012197C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000121984: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000012198C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000121994: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000012199C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001219A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000001219A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001219AC: BF870499
	s_add_i32 s6, s31, s1                                      // 0000001219B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000001219B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001219B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000001219BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000001219C0: 84078605
	s_add_u32 s10, s8, s10                                     // 0000001219C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000001219C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000001219CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001219D4: BE84206A
	s_cbranch_execz 77                                         // 0000001219D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 0000001219DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000001219E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000001219EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219F0: BF870091
	.long 0xd73c001d                                           // 0000001219F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000001219F8: 02023A82
	.long 0xd700011d                                           // 0000001219FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000121A00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121A04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000121A08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000121A10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000121A18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 000000121A1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000121A20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000121A2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000121A30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 000000121A3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000121A40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 000000121A4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000121A50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000121A54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000121A60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121A64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000121A68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000121A70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000121A74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 000000121A7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000121A84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000121A88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000121A8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000121A90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000121A94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000121A98: BF870296
	.long 0xd71c0020                                           // 000000121A9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 000000121AA0: 02024520
	.long 0xd71c001f                                           // 000000121AA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 000000121AA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121AAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 000000121AB0: D501001F 00063E80
	.long 0xd41b0001                                           // 000000121AB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 000000121ABC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 000000121AC4: D5010020 00064080
	.long 0xd41e0001                                           // 000000121ACC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 000000121AD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121AD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 000000121ADC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 000000121AE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 000000121AEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 000000121AF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000121B00: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000121B08: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000121B10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000121B14: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 000000121B1C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000121B20: BF89FC07
	s_barrier                                                  // 000000121B24: BFBD0000
	buffer_gl0_inv                                             // 000000121B28: E0AC0000 00000000
	s_branch 15                                                // 000000121B30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000121B34: 8C7E047E
	.long 0xd700011d                                           // 000000121B38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 000000121B3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000121B44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000121B48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000121B50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000121B54: BF08B70A
	s_mov_b32 s10, s1                                          // 000000121B58: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 000000121B5C: BF89FC07
	s_barrier                                                  // 000000121B60: BFBD0000
	buffer_gl0_inv                                             // 000000121B64: E0AC0000 00000000
	s_cbranch_scc1 676                                         // 000000121B6C: BFA202A4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000121B70: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000121B78: CA100128 21220126
	s_mov_b32 s11, 0                                           // 000000121B80: BE8B0080
	s_nop 0                                                    // 000000121B84: BF800000
	s_nop 0                                                    // 000000121B88: BF800000
	s_nop 0                                                    // 000000121B8C: BF800000
	s_nop 0                                                    // 000000121B90: BF800000
	s_nop 0                                                    // 000000121B94: BF800000
	s_nop 0                                                    // 000000121B98: BF800000
	s_nop 0                                                    // 000000121B9C: BF800000
	s_nop 0                                                    // 000000121BA0: BF800000
	s_nop 0                                                    // 000000121BA4: BF800000
	s_nop 0                                                    // 000000121BA8: BF800000
	s_nop 0                                                    // 000000121BAC: BF800000
	s_nop 0                                                    // 000000121BB0: BF800000
	s_nop 0                                                    // 000000121BB4: BF800000
	s_nop 0                                                    // 000000121BB8: BF800000
	s_nop 0                                                    // 000000121BBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 000000121BC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000121BC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 000000121BD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 000000121BD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000121BDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000121BE0: D5207C20 00064080
	.long 0xd4490004                                           // 000000121BE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000121BEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000121BF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000121BF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 000000121BFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000121C04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000121C0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000121C10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000121C14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000121C18: BF89FC07
	s_barrier                                                  // 000000121C1C: BFBD0000
	buffer_gl0_inv                                             // 000000121C20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000121C28: BE842000
	s_cbranch_execz 65473                                      // 000000121C2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s10, s7, v2                                 // 000000121C30: D658001F 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C38: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 000000121C3C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 000000121C44: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 000000121C48: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C4C: BF870091
	.long 0xd700011f                                           // 000000121C50: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 000000121C54: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 000000121C58: D5207C20 0006412D
	global_load_b32 v68, v[31:32], off                         // 000000121C60: DC520000 447C001F
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000121C68: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v1 offset1:17                  // 000000121C70: D8DC1100 21000001
	ds_load_2addr_b32 v[35:36], v1 offset0:34 offset1:51       // 000000121C78: D8DC3322 23000001
	ds_load_2addr_b32 v[60:61], v46 offset0:2 offset1:3        // 000000121C80: D8DC0302 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:4 offset1:5        // 000000121C88: D8DC0504 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:6 offset1:7        // 000000121C90: D8DC0706 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000121C98: D8DC5544 42000001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 000000121CA0: BF890057
	v_fma_f32 v31, -v31, v33, v68                              // 000000121CA4: D613001F 2512431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121CAC: BF8700C1
	v_fma_f32 v33, -v32, v34, v31                              // 000000121CB0: D6130021 247E4520
	ds_load_2addr_b32 v[31:32], v1 offset0:102 offset1:119     // 000000121CB8: D8DC7766 1F000001
	s_waitcnt lgkmcnt(4)                                       // 000000121CC0: BF89FC47
	v_fma_f32 v33, -v60, v35, v33                              // 000000121CC4: D6130021 2486473C
	v_fma_f32 v60, -v61, v36, v33                              // 000000121CCC: D613003C 2486493D
	ds_load_2addr_b32 v[33:34], v46 offset0:8 offset1:9        // 000000121CD4: D8DC0908 2100002E
	ds_load_2addr_b32 v[35:36], v1 offset0:136 offset1:153     // 000000121CDC: D8DC9988 23000001
	s_waitcnt lgkmcnt(3)                                       // 000000121CE4: BF89FC37
	v_fma_f32 v60, -v62, v66, v60                              // 000000121CE8: D613003C 24F2853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121CF0: BF8700D1
	v_fma_f32 v66, -v63, v67, v60                              // 000000121CF4: D6130042 24F2873F
	ds_load_2addr_b32 v[60:61], v46 offset0:10 offset1:11      // 000000121CFC: D8DC0B0A 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 000000121D04: D8DCBBAA 3E000001
	s_waitcnt lgkmcnt(4)                                       // 000000121D0C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000121D10: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000121D18: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:12 offset1:13      // 000000121D20: D8DC0D0C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 000000121D28: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:204 offset1:221     // 000000121D30: D8DCDDCC 42000001
	s_waitcnt lgkmcnt(5)                                       // 000000121D38: BF89FC57
	v_fma_f32 v33, -v33, v35, v68                              // 000000121D3C: D6130021 25124721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121D44: BF8700C1
	v_fma_f32 v35, -v34, v36, v33                              // 000000121D48: D6130023 24864922
	ds_load_2addr_b32 v[33:34], v1 offset0:238 offset1:255     // 000000121D50: D8DCFFEE 21000001
	s_waitcnt lgkmcnt(4)                                       // 000000121D58: BF89FC47
	v_fma_f32 v35, -v60, v62, v35                              // 000000121D5C: D6130023 248E7D3C
	v_fma_f32 v62, -v61, v63, v35                              // 000000121D64: D613003E 248E7F3D
	ds_load_2addr_b32 v[35:36], v46 offset0:16 offset1:17      // 000000121D6C: D8DC1110 2300002E
	ds_load_2addr_b32 v[60:61], v48 offset0:16 offset1:33      // 000000121D74: D8DC2110 3C000030
	s_waitcnt lgkmcnt(3)                                       // 000000121D7C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000121D80: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121D88: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000121D8C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:18 offset1:19      // 000000121D94: D8DC1312 1F00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:50 offset1:67      // 000000121D9C: D8DC4332 3E000030
	s_waitcnt lgkmcnt(4)                                       // 000000121DA4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000121DA8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000121DB0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:20 offset1:21      // 000000121DB8: D8DC1514 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:22 offset1:23      // 000000121DC0: D8DC1716 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:84 offset1:101     // 000000121DC8: D8DC6554 42000030
	s_waitcnt lgkmcnt(5)                                       // 000000121DD0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000121DD4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121DDC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000121DE0: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v48 offset0:118 offset1:135    // 000000121DE8: D8DC8776 23000030
	s_waitcnt lgkmcnt(4)                                       // 000000121DF0: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000121DF4: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000121DFC: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000121E04: D8DC1918 1F00002E
	ds_load_2addr_b32 v[60:61], v48 offset0:152 offset1:169    // 000000121E0C: D8DCA998 3C000030
	s_waitcnt lgkmcnt(3)                                       // 000000121E14: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000121E18: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121E20: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000121E24: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:26 offset1:27      // 000000121E2C: D8DC1B1A 2100002E
	ds_load_2addr_b32 v[62:63], v48 offset0:186 offset1:203    // 000000121E34: D8DCCBBA 3E000030
	s_waitcnt lgkmcnt(4)                                       // 000000121E3C: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000121E40: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000121E48: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:28 offset1:29      // 000000121E50: D8DC1D1C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:30 offset1:31      // 000000121E58: D8DC1F1E 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:220 offset1:237    // 000000121E60: D8DCEDDC 42000030
	s_waitcnt lgkmcnt(5)                                       // 000000121E68: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000121E6C: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121E74: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000121E78: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v49 offset0:126 offset1:143    // 000000121E80: D8DC8F7E 1F000031
	s_waitcnt lgkmcnt(4)                                       // 000000121E88: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000121E8C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000121E94: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:32 offset1:33      // 000000121E9C: D8DC2120 2100002E
	ds_load_2addr_b32 v[60:61], v50 offset0:32 offset1:49      // 000000121EA4: D8DC3120 3C000032
	s_waitcnt lgkmcnt(3)                                       // 000000121EAC: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000121EB0: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121EB8: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000121EBC: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:34 offset1:35      // 000000121EC4: D8DC2322 2300002E
	ds_load_2addr_b32 v[62:63], v50 offset0:66 offset1:83      // 000000121ECC: D8DC5342 3E000032
	s_waitcnt lgkmcnt(4)                                       // 000000121ED4: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000121ED8: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000121EE0: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:36 offset1:37      // 000000121EE8: D8DC2524 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 000000121EF0: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:100 offset1:117    // 000000121EF8: D8DC7564 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000121F00: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000121F04: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121F0C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000121F10: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v50 offset0:134 offset1:151    // 000000121F18: D8DC9786 21000032
	s_waitcnt lgkmcnt(4)                                       // 000000121F20: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000121F24: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000121F2C: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:40 offset1:41      // 000000121F34: D8DC2928 2300002E
	ds_load_2addr_b32 v[60:61], v50 offset0:168 offset1:185    // 000000121F3C: D8DCB9A8 3C000032
	s_waitcnt lgkmcnt(3)                                       // 000000121F44: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000121F48: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121F50: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000121F54: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:42 offset1:43      // 000000121F5C: D8DC2B2A 1F00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:202 offset1:219    // 000000121F64: D8DCDBCA 3E000032
	s_waitcnt lgkmcnt(4)                                       // 000000121F6C: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000121F70: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000121F78: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:44 offset1:45      // 000000121F80: D8DC2D2C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:46 offset1:47      // 000000121F88: D8DC2F2E 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:236 offset1:253    // 000000121F90: D8DCFDEC 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000121F98: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000121F9C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000121FA4: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000121FA8: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v51 offset0:14 offset1:31      // 000000121FB0: D8DC1F0E 23000033
	s_waitcnt lgkmcnt(4)                                       // 000000121FB8: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000121FBC: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000121FC4: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 000000121FCC: D8DC3130 1F00002E
	ds_load_2addr_b32 v[60:61], v51 offset0:48 offset1:65      // 000000121FD4: D8DC4130 3C000033
	s_waitcnt lgkmcnt(3)                                       // 000000121FDC: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000121FE0: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000121FE8: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000121FEC: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 000000121FF4: D8DC3332 2100002E
	ds_load_2addr_b32 v[62:63], v51 offset0:82 offset1:99      // 000000121FFC: D8DC6352 3E000033
	s_waitcnt lgkmcnt(4)                                       // 000000122004: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000122008: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000122010: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 000000122018: D8DC3534 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:54 offset1:55      // 000000122020: D8DC3736 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:116 offset1:133    // 000000122028: D8DC8574 42000033
	s_waitcnt lgkmcnt(5)                                       // 000000122030: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000122034: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012203C: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000122040: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v51 offset0:150 offset1:167    // 000000122048: D8DCA796 1F000033
	s_waitcnt lgkmcnt(4)                                       // 000000122050: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000122054: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000012205C: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:56 offset1:57      // 000000122064: D8DC3938 2100002E
	ds_load_2addr_b32 v[60:61], v51 offset0:184 offset1:201    // 00000012206C: D8DCC9B8 3C000033
	s_waitcnt lgkmcnt(3)                                       // 000000122074: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000122078: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122080: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000122084: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:58 offset1:59      // 00000012208C: D8DC3B3A 2300002E
	ds_load_2addr_b32 v[62:63], v51 offset0:218 offset1:235    // 000000122094: D8DCEBDA 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000012209C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 0000001220A0: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 0000001220A8: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:60 offset1:61      // 0000001220B0: D8DC3D3C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 0000001220B8: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v52 offset0:124 offset1:141    // 0000001220C0: D8DC8D7C 42000034
	s_waitcnt lgkmcnt(5)                                       // 0000001220C8: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 0000001220CC: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001220D4: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 0000001220D8: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v53 offset0:30 offset1:47      // 0000001220E0: D8DC2F1E 21000035
	s_waitcnt lgkmcnt(4)                                       // 0000001220E8: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 0000001220EC: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 0000001220F4: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:64 offset1:65      // 0000001220FC: D8DC4140 2300002E
	ds_load_2addr_b32 v[60:61], v53 offset0:64 offset1:81      // 000000122104: D8DC5140 3C000035
	s_waitcnt lgkmcnt(3)                                       // 00000012210C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000122110: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122118: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000012211C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:66 offset1:67      // 000000122124: D8DC4342 1F00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:98 offset1:115     // 00000012212C: D8DC7362 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000122134: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000122138: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000122140: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:68 offset1:69      // 000000122148: D8DC4544 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:70 offset1:71      // 000000122150: D8DC4746 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:132 offset1:149    // 000000122158: D8DC9584 42000035
	s_waitcnt lgkmcnt(5)                                       // 000000122160: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000122164: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012216C: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000122170: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v53 offset0:166 offset1:183    // 000000122178: D8DCB7A6 23000035
	s_waitcnt lgkmcnt(4)                                       // 000000122180: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000122184: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000012218C: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 000000122194: D8DC4948 1F00002E
	ds_load_2addr_b32 v[60:61], v53 offset0:200 offset1:217    // 00000012219C: D8DCD9C8 3C000035
	s_waitcnt lgkmcnt(3)                                       // 0000001221A4: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 0000001221A8: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001221B0: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 0000001221B4: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:74 offset1:75      // 0000001221BC: D8DC4B4A 2100002E
	ds_load_2addr_b32 v[62:63], v53 offset0:234 offset1:251    // 0000001221C4: D8DCFBEA 3E000035
	s_waitcnt lgkmcnt(4)                                       // 0000001221CC: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 0000001221D0: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 0000001221D8: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:76 offset1:77      // 0000001221E0: D8DC4D4C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:78 offset1:79      // 0000001221E8: D8DC4F4E 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:12 offset1:29      // 0000001221F0: D8DC1D0C 42000036
	s_waitcnt lgkmcnt(5)                                       // 0000001221F8: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 0000001221FC: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122204: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000122208: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v54 offset0:46 offset1:63      // 000000122210: D8DC3F2E 1F000036
	s_waitcnt lgkmcnt(4)                                       // 000000122218: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000012221C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000122224: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:80 offset1:81      // 00000012222C: D8DC5150 2100002E
	ds_load_2addr_b32 v[60:61], v54 offset0:80 offset1:97      // 000000122234: D8DC6150 3C000036
	s_waitcnt lgkmcnt(3)                                       // 00000012223C: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000122240: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122248: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000012224C: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:82 offset1:83      // 000000122254: D8DC5352 2300002E
	ds_load_2addr_b32 v[62:63], v54 offset0:114 offset1:131    // 00000012225C: D8DC8372 3E000036
	s_waitcnt lgkmcnt(4)                                       // 000000122264: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000122268: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000122270: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:84 offset1:85      // 000000122278: D8DC5554 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 000000122280: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:148 offset1:165    // 000000122288: D8DCA594 42000036
	s_waitcnt lgkmcnt(5)                                       // 000000122290: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000122294: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012229C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 0000001222A0: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v54 offset0:182 offset1:199    // 0000001222A8: D8DCC7B6 21000036
	s_waitcnt lgkmcnt(4)                                       // 0000001222B0: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 0000001222B4: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 0000001222BC: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:88 offset1:89      // 0000001222C4: D8DC5958 2300002E
	ds_load_2addr_b32 v[60:61], v54 offset0:216 offset1:233    // 0000001222CC: D8DCE9D8 3C000036
	s_waitcnt lgkmcnt(3)                                       // 0000001222D4: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 0000001222D8: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001222E0: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 0000001222E4: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:90 offset1:91      // 0000001222EC: D8DC5B5A 1F00002E
	ds_load_2addr_b32 v[62:63], v55 offset0:122 offset1:139    // 0000001222F4: D8DC8B7A 3E000037
	s_waitcnt lgkmcnt(4)                                       // 0000001222FC: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000122300: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000122308: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:92 offset1:93      // 000000122310: D8DC5D5C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:94 offset1:95      // 000000122318: D8DC5F5E 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:28 offset1:45      // 000000122320: D8DC2D1C 42000038
	s_waitcnt lgkmcnt(5)                                       // 000000122328: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000012232C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122334: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000122338: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v56 offset0:62 offset1:79      // 000000122340: D8DC4F3E 23000038
	s_waitcnt lgkmcnt(4)                                       // 000000122348: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000012234C: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000122354: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000012235C: D8DC6160 1F00002E
	ds_load_2addr_b32 v[60:61], v56 offset0:96 offset1:113     // 000000122364: D8DC7160 3C000038
	s_waitcnt lgkmcnt(3)                                       // 00000012236C: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000122370: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122378: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000012237C: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 000000122384: D8DC6362 2100002E
	ds_load_2addr_b32 v[62:63], v56 offset0:130 offset1:147    // 00000012238C: D8DC9382 3E000038
	s_waitcnt lgkmcnt(4)                                       // 000000122394: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000122398: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 0000001223A0: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000001223A8: D8DC6564 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:102 offset1:103    // 0000001223B0: D8DC6766 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:164 offset1:181    // 0000001223B8: D8DCB5A4 42000038
	s_waitcnt lgkmcnt(5)                                       // 0000001223C0: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 0000001223C4: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001223CC: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 0000001223D0: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v56 offset0:198 offset1:215    // 0000001223D8: D8DCD7C6 1F000038
	s_waitcnt lgkmcnt(4)                                       // 0000001223E0: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 0000001223E4: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 0000001223EC: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:104 offset1:105    // 0000001223F4: D8DC6968 2100002E
	ds_load_2addr_b32 v[60:61], v56 offset0:232 offset1:249    // 0000001223FC: D8DCF9E8 3C000038
	s_waitcnt lgkmcnt(3)                                       // 000000122404: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000122408: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122410: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000122414: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:106 offset1:107    // 00000012241C: D8DC6B6A 2300002E
	ds_load_2addr_b32 v[62:63], v57 offset0:10 offset1:27      // 000000122424: D8DC1B0A 3E000039
	s_waitcnt lgkmcnt(4)                                       // 00000012242C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000122430: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000122438: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:108 offset1:109    // 000000122440: D8DC6D6C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 000000122448: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:44 offset1:61      // 000000122450: D8DC3D2C 42000039
	s_waitcnt lgkmcnt(5)                                       // 000000122458: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 00000012245C: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122464: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000122468: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v57 offset0:78 offset1:95      // 000000122470: D8DC5F4E 21000039
	s_waitcnt lgkmcnt(4)                                       // 000000122478: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 00000012247C: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000122484: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:112 offset1:113    // 00000012248C: D8DC7170 2300002E
	ds_load_2addr_b32 v[60:61], v57 offset0:112 offset1:129    // 000000122494: D8DC8170 3C000039
	s_waitcnt lgkmcnt(3)                                       // 00000012249C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 0000001224A0: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001224A8: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 0000001224AC: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:114 offset1:115    // 0000001224B4: D8DC7372 1F00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:146 offset1:163    // 0000001224BC: D8DCA392 3E000039
	s_waitcnt lgkmcnt(4)                                       // 0000001224C4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 0000001224C8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 0000001224D0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:116 offset1:117    // 0000001224D8: D8DC7574 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:118 offset1:119    // 0000001224E0: D8DC7776 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:180 offset1:197    // 0000001224E8: D8DCC5B4 42000039
	s_waitcnt lgkmcnt(5)                                       // 0000001224F0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 0000001224F4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001224FC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000122500: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v57 offset0:214 offset1:231    // 000000122508: D8DCE7D6 23000039
	s_waitcnt lgkmcnt(4)                                       // 000000122510: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000122514: D613001F 24F27D1F
	v_fma_f32 v60, -v32, v63, v31                              // 00000012251C: D613003C 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000122524: D8DC7978 1F00002E
	s_waitcnt lgkmcnt(2)                                       // 00000012252C: BF89FC27
	v_fma_f32 v33, -v33, v66, v60                              // 000000122530: D6130021 24F28521
	ds_load_2addr_b32 v[60:61], v58 offset0:120 offset1:137    // 000000122538: D8DC8978 3C00003A
	v_fma_f32 v62, -v34, v67, v33                              // 000000122540: D613003E 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:122 offset1:123    // 000000122548: D8DC7B7A 2100002E
	s_waitcnt lgkmcnt(3)                                       // 000000122550: BF89FC37
	v_fma_f32 v35, -v64, v35, v62                              // 000000122554: D6130023 24FA4740
	ds_load_2addr_b32 v[62:63], v59 offset0:26 offset1:43      // 00000012255C: D8DC2B1A 3E00003B
	v_fma_f32 v68, -v65, v36, v35                              // 000000122564: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:124 offset1:125    // 00000012256C: D8DC7D7C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:126 offset1:127    // 000000122574: D8DC7F7E 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:60 offset1:77      // 00000012257C: D8DC4D3C 4200003B
	s_waitcnt lgkmcnt(5)                                       // 000000122584: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000122588: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122590: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000122594: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v59 offset0:94 offset1:111     // 00000012259C: D8DC6F5E 1F00003B
	s_waitcnt lgkmcnt(4)                                       // 0000001225A4: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 0000001225A8: D6130021 24F27D21
	v_fma_f32 v33, -v34, v63, v33                              // 0000001225B0: D6130021 24867F22
	s_waitcnt lgkmcnt(1)                                       // 0000001225B8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001225BC: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000001225C0: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000001225C8: D6130021 24868724
	s_waitcnt lgkmcnt(0)                                       // 0000001225D0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001225D4: BF870121
	v_fma_f32 v31, -v64, v31, v33                              // 0000001225D8: D613001F 24863F40
	v_mad_u64_u32 v[33:34], null, 0x44, s10, v[4:5]            // 0000001225E0: D6FE7C21 041014FF 00000044
	v_fma_f32 v31, -v65, v32, v31                              // 0000001225EC: D613001F 247E4141
	ds_store_b32 v33, v31                                      // 0000001225F4: D8340000 00001F21
	s_branch 64845                                             // 0000001225FC: BFA0FD4D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_dual_mov_b32 v30, v14 :: v_dual_mov_b32 v29, v13         // 000000122600: CA10010E 1E1C010D
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v31, v9          // 000000122608: CA10010A 201E0109
	v_mov_b32_e32 v35, v43                                     // 000000122610: 7E46032B
	s_mov_b32 s10, 0                                           // 000000122614: BE8A0080
	s_branch 21                                                // 000000122618: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1070>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012261C: 8C7E0B7E
	.long 0xd700011f                                           // 000000122620: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 000000122624: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012262C: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000122630: D5207C20 00064080
	.long 0xd700011d                                           // 000000122638: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000012263C: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 000000122644: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000122648: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000122650: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000122654: BF08B70A
	s_mov_b32 s10, s1                                          // 000000122658: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000012265C: BC7C0000
	s_barrier                                                  // 000000122660: BFBD0000
	buffer_gl0_inv                                             // 000000122664: E0AC0000 00000000
	s_cbranch_scc1 580                                         // 00000012266C: BFA20244 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000122670: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 000000122674: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000012267C: 7E480328
	v_mov_b32_e32 v60, v38                                     // 000000122680: 7E780326
	s_mov_b32 s11, 0                                           // 000000122684: BE8B0080
	s_nop 0                                                    // 000000122688: BF800000
	s_nop 0                                                    // 00000012268C: BF800000
	s_nop 0                                                    // 000000122690: BF800000
	s_nop 0                                                    // 000000122694: BF800000
	s_nop 0                                                    // 000000122698: BF800000
	s_nop 0                                                    // 00000012269C: BF800000
	s_nop 0                                                    // 0000001226A0: BF800000
	s_nop 0                                                    // 0000001226A4: BF800000
	s_nop 0                                                    // 0000001226A8: BF800000
	s_nop 0                                                    // 0000001226AC: BF800000
	s_nop 0                                                    // 0000001226B0: BF800000
	s_nop 0                                                    // 0000001226B4: BF800000
	s_nop 0                                                    // 0000001226B8: BF800000
	s_nop 0                                                    // 0000001226BC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000001226C0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000001226C8: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000001226D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000001226D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001226DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000001226E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000001226E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000001226EC: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000001226F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000001226F8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000001226FC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000122704: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012270C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000122710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000122714: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000122718: BF89FC07
	s_barrier                                                  // 00000012271C: BFBD0000
	buffer_gl0_inv                                             // 000000122720: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000122728: BE8B2000
	s_cbranch_execz 65467                                      // 00000012272C: BFA5FFBB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	v_or_b32_e32 v33, s10, v2                                  // 000000122730: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122734: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000122738: 38484207
	.long 0xd4440001                                           // 00000012273C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000122740: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000122744: 8B7E017E
	s_cbranch_execz 65460                                      // 000000122748: BFA5FFB4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000012274C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000122754: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000012275C: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v46 offset0:2 offset1:3        // 000000122764: D8DC0302 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000012276C: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 000000122774: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000012277C: D8DC5544 48000001
	s_mov_b32 s12, 0                                           // 000000122784: BE8C0080
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000122788: 30424282
	s_waitcnt lgkmcnt(5)                                       // 00000012278C: BF89FC57
	v_fma_f32 v74, v60, v62, 0                                 // 000000122790: D613004A 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122798: BF8700C1
	v_fmac_f32_e32 v74, v61, v63                               // 00000012279C: 56947F3D
	ds_load_2addr_b32 v[60:61], v1 offset0:102 offset1:119     // 0000001227A0: D8DC7766 3C000001
	s_waitcnt lgkmcnt(4)                                       // 0000001227A8: BF89FC47
	v_fmac_f32_e32 v74, v66, v64                               // 0000001227AC: 56948142
	v_fmac_f32_e32 v74, v67, v65                               // 0000001227B0: 56948343
	ds_load_2addr_b32 v[62:63], v46 offset0:8 offset1:9        // 0000001227B4: D8DC0908 3E00002E
	ds_load_2addr_b32 v[64:65], v1 offset0:136 offset1:153     // 0000001227BC: D8DC9988 40000001
	s_waitcnt lgkmcnt(3)                                       // 0000001227C4: BF89FC37
	v_fmac_f32_e32 v74, v68, v72                               // 0000001227C8: 56949144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001227CC: BF8700D1
	v_fmac_f32_e32 v74, v69, v73                               // 0000001227D0: 56949345
	ds_load_2addr_b32 v[66:67], v46 offset0:10 offset1:11      // 0000001227D4: D8DC0B0A 4200002E
	ds_load_2addr_b32 v[68:69], v1 offset0:170 offset1:187     // 0000001227DC: D8DCBBAA 44000001
	s_waitcnt lgkmcnt(4)                                       // 0000001227E4: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 0000001227E8: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 0000001227EC: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:12 offset1:13      // 0000001227F0: D8DC0D0C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000001227F8: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 000000122800: D8DCDDCC 48000001
	s_waitcnt lgkmcnt(5)                                       // 000000122808: BF89FC57
	v_fmac_f32_e32 v74, v62, v64                               // 00000012280C: 5694813E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122810: BF8700C1
	v_fmac_f32_e32 v74, v63, v65                               // 000000122814: 5694833F
	ds_load_2addr_b32 v[62:63], v1 offset0:238 offset1:255     // 000000122818: D8DCFFEE 3E000001
	s_waitcnt lgkmcnt(4)                                       // 000000122820: BF89FC47
	v_fmac_f32_e32 v74, v66, v68                               // 000000122824: 56948942
	v_fmac_f32_e32 v74, v67, v69                               // 000000122828: 56948B43
	ds_load_2addr_b32 v[64:65], v46 offset0:16 offset1:17      // 00000012282C: D8DC1110 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:16 offset1:33      // 000000122834: D8DC2110 42000030
	s_waitcnt lgkmcnt(3)                                       // 00000012283C: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000122840: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122844: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000122848: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:18 offset1:19      // 00000012284C: D8DC1312 3C00002E
	ds_load_2addr_b32 v[68:69], v48 offset0:50 offset1:67      // 000000122854: D8DC4332 44000030
	s_waitcnt lgkmcnt(4)                                       // 00000012285C: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000122860: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000122864: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:20 offset1:21      // 000000122868: D8DC1514 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 000000122870: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 000000122878: D8DC6554 48000030
	s_waitcnt lgkmcnt(5)                                       // 000000122880: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000122884: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122888: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 00000012288C: 56948741
	ds_load_2addr_b32 v[64:65], v48 offset0:118 offset1:135    // 000000122890: D8DC8776 40000030
	s_waitcnt lgkmcnt(4)                                       // 000000122898: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 00000012289C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 0000001228A0: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000001228A4: D8DC1918 3C00002E
	ds_load_2addr_b32 v[66:67], v48 offset0:152 offset1:169    // 0000001228AC: D8DCA998 42000030
	s_waitcnt lgkmcnt(3)                                       // 0000001228B4: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 0000001228B8: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001228BC: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 0000001228C0: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000001228C4: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[68:69], v48 offset0:186 offset1:203    // 0000001228CC: D8DCCBBA 44000030
	s_waitcnt lgkmcnt(4)                                       // 0000001228D4: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 0000001228D8: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 0000001228DC: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000001228E0: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000001228E8: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000001228F0: D8DCEDDC 48000030
	s_waitcnt lgkmcnt(5)                                       // 0000001228F8: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 0000001228FC: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122900: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 000000122904: 5694873D
	ds_load_2addr_b32 v[60:61], v49 offset0:126 offset1:143    // 000000122908: D8DC8F7E 3C000031
	s_waitcnt lgkmcnt(4)                                       // 000000122910: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000122914: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000122918: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:32 offset1:33      // 00000012291C: D8DC2120 3E00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 000000122924: D8DC3120 42000032
	s_waitcnt lgkmcnt(3)                                       // 00000012292C: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000122930: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122934: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000122938: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000012293C: D8DC2322 4000002E
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 000000122944: D8DC5342 44000032
	s_waitcnt lgkmcnt(4)                                       // 00000012294C: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000122950: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000122954: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:36 offset1:37      // 000000122958: D8DC2524 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 000000122960: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 000000122968: D8DC7564 48000032
	s_waitcnt lgkmcnt(5)                                       // 000000122970: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000122974: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122978: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 00000012297C: 5694873F
	ds_load_2addr_b32 v[62:63], v50 offset0:134 offset1:151    // 000000122980: D8DC9786 3E000032
	s_waitcnt lgkmcnt(4)                                       // 000000122988: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 00000012298C: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000122990: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:40 offset1:41      // 000000122994: D8DC2928 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:168 offset1:185    // 00000012299C: D8DCB9A8 42000032
	s_waitcnt lgkmcnt(3)                                       // 0000001229A4: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 0000001229A8: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001229AC: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 0000001229B0: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:42 offset1:43      // 0000001229B4: D8DC2B2A 3C00002E
	ds_load_2addr_b32 v[68:69], v50 offset0:202 offset1:219    // 0000001229BC: D8DCDBCA 44000032
	s_waitcnt lgkmcnt(4)                                       // 0000001229C4: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 0000001229C8: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 0000001229CC: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:44 offset1:45      // 0000001229D0: D8DC2D2C 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000001229D8: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000001229E0: D8DCFDEC 48000032
	s_waitcnt lgkmcnt(5)                                       // 0000001229E8: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 0000001229EC: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001229F0: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 0000001229F4: 56948741
	ds_load_2addr_b32 v[64:65], v51 offset0:14 offset1:31      // 0000001229F8: D8DC1F0E 40000033
	s_waitcnt lgkmcnt(4)                                       // 000000122A00: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 000000122A04: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000122A08: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 000000122A0C: D8DC3130 3C00002E
	ds_load_2addr_b32 v[66:67], v51 offset0:48 offset1:65      // 000000122A14: D8DC4130 42000033
	s_waitcnt lgkmcnt(3)                                       // 000000122A1C: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000122A20: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122A24: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000122A28: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:50 offset1:51      // 000000122A2C: D8DC3332 3E00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:82 offset1:99      // 000000122A34: D8DC6352 44000033
	s_waitcnt lgkmcnt(4)                                       // 000000122A3C: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000122A40: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000122A44: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:52 offset1:53      // 000000122A48: D8DC3534 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 000000122A50: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000122A58: D8DC8574 48000033
	s_waitcnt lgkmcnt(5)                                       // 000000122A60: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000122A64: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122A68: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 000000122A6C: 5694873D
	ds_load_2addr_b32 v[60:61], v51 offset0:150 offset1:167    // 000000122A70: D8DCA796 3C000033
	s_waitcnt lgkmcnt(4)                                       // 000000122A78: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000122A7C: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000122A80: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:56 offset1:57      // 000000122A84: D8DC3938 3E00002E
	ds_load_2addr_b32 v[66:67], v51 offset0:184 offset1:201    // 000000122A8C: D8DCC9B8 42000033
	s_waitcnt lgkmcnt(3)                                       // 000000122A94: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000122A98: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122A9C: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000122AA0: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 000000122AA4: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[68:69], v51 offset0:218 offset1:235    // 000000122AAC: D8DCEBDA 44000033
	s_waitcnt lgkmcnt(4)                                       // 000000122AB4: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000122AB8: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000122ABC: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:60 offset1:61      // 000000122AC0: D8DC3D3C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 000000122AC8: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 000000122AD0: D8DC8D7C 48000034
	s_waitcnt lgkmcnt(5)                                       // 000000122AD8: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000122ADC: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122AE0: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 000000122AE4: 5694873F
	ds_load_2addr_b32 v[62:63], v53 offset0:30 offset1:47      // 000000122AE8: D8DC2F1E 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000122AF0: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 000000122AF4: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000122AF8: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:64 offset1:65      // 000000122AFC: D8DC4140 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:64 offset1:81      // 000000122B04: D8DC5140 42000035
	s_waitcnt lgkmcnt(3)                                       // 000000122B0C: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000122B10: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122B14: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000122B18: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:66 offset1:67      // 000000122B1C: D8DC4342 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:98 offset1:115     // 000000122B24: D8DC7362 44000035
	s_waitcnt lgkmcnt(4)                                       // 000000122B2C: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000122B30: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000122B34: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:68 offset1:69      // 000000122B38: D8DC4544 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 000000122B40: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000122B48: D8DC9584 48000035
	s_waitcnt lgkmcnt(5)                                       // 000000122B50: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000122B54: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122B58: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 000000122B5C: 56948741
	ds_load_2addr_b32 v[64:65], v53 offset0:166 offset1:183    // 000000122B60: D8DCB7A6 40000035
	s_waitcnt lgkmcnt(4)                                       // 000000122B68: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 000000122B6C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000122B70: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 000000122B74: D8DC4948 3C00002E
	ds_load_2addr_b32 v[66:67], v53 offset0:200 offset1:217    // 000000122B7C: D8DCD9C8 42000035
	s_waitcnt lgkmcnt(3)                                       // 000000122B84: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000122B88: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122B8C: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000122B90: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 000000122B94: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:234 offset1:251    // 000000122B9C: D8DCFBEA 44000035
	s_waitcnt lgkmcnt(4)                                       // 000000122BA4: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000122BA8: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000122BAC: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 000000122BB0: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 000000122BB8: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 000000122BC0: D8DC1D0C 48000036
	s_waitcnt lgkmcnt(5)                                       // 000000122BC8: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000122BCC: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122BD0: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 000000122BD4: 5694873D
	ds_load_2addr_b32 v[60:61], v54 offset0:46 offset1:63      // 000000122BD8: D8DC3F2E 3C000036
	s_waitcnt lgkmcnt(4)                                       // 000000122BE0: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000122BE4: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000122BE8: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:80 offset1:81      // 000000122BEC: D8DC5150 3E00002E
	ds_load_2addr_b32 v[66:67], v54 offset0:80 offset1:97      // 000000122BF4: D8DC6150 42000036
	s_waitcnt lgkmcnt(3)                                       // 000000122BFC: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000122C00: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122C04: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000122C08: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 000000122C0C: D8DC5352 4000002E
	ds_load_2addr_b32 v[68:69], v54 offset0:114 offset1:131    // 000000122C14: D8DC8372 44000036
	s_waitcnt lgkmcnt(4)                                       // 000000122C1C: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000122C20: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000122C24: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:84 offset1:85      // 000000122C28: D8DC5554 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 000000122C30: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000122C38: D8DCA594 48000036
	s_waitcnt lgkmcnt(5)                                       // 000000122C40: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000122C44: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122C48: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 000000122C4C: 5694873F
	ds_load_2addr_b32 v[62:63], v54 offset0:182 offset1:199    // 000000122C50: D8DCC7B6 3E000036
	s_waitcnt lgkmcnt(4)                                       // 000000122C58: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 000000122C5C: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000122C60: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:88 offset1:89      // 000000122C64: D8DC5958 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:216 offset1:233    // 000000122C6C: D8DCE9D8 42000036
	s_waitcnt lgkmcnt(3)                                       // 000000122C74: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000122C78: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122C7C: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000122C80: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:90 offset1:91      // 000000122C84: D8DC5B5A 3C00002E
	ds_load_2addr_b32 v[68:69], v55 offset0:122 offset1:139    // 000000122C8C: D8DC8B7A 44000037
	s_waitcnt lgkmcnt(4)                                       // 000000122C94: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000122C98: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000122C9C: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:92 offset1:93      // 000000122CA0: D8DC5D5C 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 000000122CA8: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 000000122CB0: D8DC2D1C 48000038
	s_waitcnt lgkmcnt(5)                                       // 000000122CB8: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000122CBC: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122CC0: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 000000122CC4: 56948741
	ds_load_2addr_b32 v[64:65], v56 offset0:62 offset1:79      // 000000122CC8: D8DC4F3E 40000038
	s_waitcnt lgkmcnt(4)                                       // 000000122CD0: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 000000122CD4: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000122CD8: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 000000122CDC: D8DC6160 3C00002E
	ds_load_2addr_b32 v[66:67], v56 offset0:96 offset1:113     // 000000122CE4: D8DC7160 42000038
	s_waitcnt lgkmcnt(3)                                       // 000000122CEC: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000122CF0: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122CF4: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000122CF8: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:98 offset1:99      // 000000122CFC: D8DC6362 3E00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:130 offset1:147    // 000000122D04: D8DC9382 44000038
	s_waitcnt lgkmcnt(4)                                       // 000000122D0C: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000122D10: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000122D14: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:100 offset1:101    // 000000122D18: D8DC6564 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 000000122D20: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 000000122D28: D8DCB5A4 48000038
	s_waitcnt lgkmcnt(5)                                       // 000000122D30: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000122D34: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122D38: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 000000122D3C: 5694873D
	ds_load_2addr_b32 v[60:61], v56 offset0:198 offset1:215    // 000000122D40: D8DCD7C6 3C000038
	s_waitcnt lgkmcnt(4)                                       // 000000122D48: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000122D4C: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000122D50: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:104 offset1:105    // 000000122D54: D8DC6968 3E00002E
	ds_load_2addr_b32 v[66:67], v56 offset0:232 offset1:249    // 000000122D5C: D8DCF9E8 42000038
	s_waitcnt lgkmcnt(3)                                       // 000000122D64: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000122D68: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122D6C: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000122D70: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 000000122D74: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[68:69], v57 offset0:10 offset1:27      // 000000122D7C: D8DC1B0A 44000039
	s_waitcnt lgkmcnt(4)                                       // 000000122D84: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000122D88: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000122D8C: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:108 offset1:109    // 000000122D90: D8DC6D6C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 000000122D98: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 000000122DA0: D8DC3D2C 48000039
	s_waitcnt lgkmcnt(5)                                       // 000000122DA8: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000122DAC: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122DB0: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 000000122DB4: 5694873F
	ds_load_2addr_b32 v[62:63], v57 offset0:78 offset1:95      // 000000122DB8: D8DC5F4E 3E000039
	s_waitcnt lgkmcnt(4)                                       // 000000122DC0: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 000000122DC4: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000122DC8: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:112 offset1:113    // 000000122DCC: D8DC7170 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:112 offset1:129    // 000000122DD4: D8DC8170 42000039
	s_waitcnt lgkmcnt(3)                                       // 000000122DDC: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000122DE0: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122DE4: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000122DE8: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:114 offset1:115    // 000000122DEC: D8DC7372 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:146 offset1:163    // 000000122DF4: D8DCA392 44000039
	s_waitcnt lgkmcnt(4)                                       // 000000122DFC: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000122E00: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000122E04: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:116 offset1:117    // 000000122E08: D8DC7574 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 000000122E10: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000122E18: D8DCC5B4 48000039
	s_waitcnt lgkmcnt(5)                                       // 000000122E20: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000122E24: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000122E28: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 000000122E2C: 56948741
	ds_load_2addr_b32 v[64:65], v57 offset0:214 offset1:231    // 000000122E30: D8DCE7D6 40000039
	s_waitcnt lgkmcnt(4)                                       // 000000122E38: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 000000122E3C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000122E40: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 000000122E44: D8DC7978 3C00002E
	ds_load_2addr_b32 v[66:67], v58 offset0:120 offset1:137    // 000000122E4C: D8DC8978 4200003A
	s_waitcnt lgkmcnt(3)                                       // 000000122E54: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000122E58: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000122E5C: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000122E60: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000122E64: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[68:69], v59 offset0:26 offset1:43      // 000000122E6C: D8DC2B1A 4400003B
	s_waitcnt lgkmcnt(4)                                       // 000000122E74: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000122E78: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000122E7C: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000122E80: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 000000122E88: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 000000122E90: D8DC4D3C 4800003B
	s_waitcnt lgkmcnt(5)                                       // 000000122E98: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000122E9C: 5694853C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000122EA0: BF870001
	v_fmac_f32_e32 v74, v61, v67                               // 000000122EA4: 5694873D
	ds_load_2addr_b32 v[60:61], v59 offset0:94 offset1:111     // 000000122EA8: D8DC6F5E 3C00003B
	s_waitcnt lgkmcnt(4)                                       // 000000122EB0: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000122EB4: 5694893E
	ds_load_b32 v62, v33 offset:17440                          // 000000122EB8: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000122EC0: CA10011E 2220011D
	v_fmac_f32_e32 v74, v63, v69                               // 000000122EC8: 56948B3F
	s_waitcnt lgkmcnt(2)                                       // 000000122ECC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122ED0: BF870091
	v_fmac_f32_e32 v74, v64, v72                               // 000000122ED4: 56949140
	v_fmac_f32_e32 v74, v65, v73                               // 000000122ED8: 56949341
	s_waitcnt lgkmcnt(1)                                       // 000000122EDC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122EE0: BF870091
	v_fmac_f32_e32 v74, v70, v60                               // 000000122EE4: 56947946
	v_dual_fmac_f32 v74, v71, v61 :: v_dual_mov_b32 v61, v1    // 000000122EE8: C8107B47 4A3C0101
	s_waitcnt lgkmcnt(0)                                       // 000000122EF0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000122EF4: BF870001
	v_mul_f32_e32 v60, v74, v62                                // 000000122EF8: 10787D4A
	v_mov_b32_e32 v62, v35                                     // 000000122EFC: 7E7C0323
	global_load_b32 v63, v[33:34], off                         // 000000122F00: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000122F08: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000122F10: 4A7C7CC1
	.long 0xd7000121                                           // 000000122F14: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000122F18: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000122F1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000122F20: D5207C22 00064480
	.long 0xd44a0004                                           // 000000122F28: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 000000122F2C: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000122F30: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000122F38: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000122F3C: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000122F40: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000122F44: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000122F48: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000122F4C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122F50: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000122F54: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 000000122F5C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000122F68: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000122F74: DC960000 007C2421
	s_branch 64935                                             // 000000122F7C: BFA0FDA7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000122F80: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000122F88: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000122F8C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000122F90: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000122F98: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000122F9C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000122FA4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 000000122FAC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000122FB0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000122FB4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000122FBC: A0010401
	s_mov_b32 s4, 0                                            // 000000122FC0: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000122FC4: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000122FC8: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 000000122FCC: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000122FD0: BF870585
	.long 0xd71c001d                                           // 000000122FD4: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000122FD8: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 000000122FDC: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000122FE0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000122FE8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 000000122FEC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 000000122FF4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000122FF8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000122FFC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000123008: D8D80000 2000001D
	s_waitcnt lgkmcnt(0)                                       // 000000123010: BF89FC07
	v_dual_mul_f32 v32, v30, v32 :: v_dual_add_nc_u32 v31, 0x80, v31// 000000123014: C8E0411E 201E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000123020: BF8704C1
	.long 0xd4490001                                           // 000000123024: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000123028: 02023EFF 0000077F
	ds_store_b32 v29, v32                                      // 000000123030: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000123038: 4A3A3AFF 00000220
	s_or_b32 s4, s1, s4                                        // 000000123040: 8C040401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123044: 917E047E
	s_cbranch_execnz 65519                                     // 000000123048: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012304C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000123050: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000123058: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000123060: 7E420326
	s_mov_b32 s6, 0                                            // 000000123064: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123068: BF89FC07
	s_barrier                                                  // 00000012306C: BFBD0000
	buffer_gl0_inv                                             // 000000123070: E0AC0000 00000000
	s_nop 0                                                    // 000000123078: BF800000
	s_nop 0                                                    // 00000012307C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123080: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000123088: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123090: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123098: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012309C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000001230A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001230A8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001230B0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001230B4: 10444722
	.long 0xd4490004                                           // 0000001230B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001230BC: 020242FF 0000037F
	ds_store_b32 v32, v34 offset:13056                         // 0000001230C4: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000001230CC: 4A4040FF 00000204
	s_or_b32 s6, s4, s6                                        // 0000001230D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001230D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001230DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001230E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001230E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001230E8: BF89FC07
	s_barrier                                                  // 0000001230EC: BFBD0000
	buffer_gl0_inv                                             // 0000001230F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000001230F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000123100: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000123108: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000123110: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000123118: 7E780300
	s_mov_b32 s4, 0                                            // 00000012311C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000123120: BF840001
	s_nop 0                                                    // 000000123124: BF800000
	s_nop 0                                                    // 000000123128: BF800000
	s_nop 0                                                    // 00000012312C: BF800000
	s_nop 0                                                    // 000000123130: BF800000
	s_nop 0                                                    // 000000123134: BF800000
	s_nop 0                                                    // 000000123138: BF800000
	s_nop 0                                                    // 00000012313C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123140: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000123144: 327A7884
	.long 0xd4490001                                           // 000000123148: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012314C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000123154: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000123158: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123164: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000123168: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000123170: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000123178: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000123180: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000123184: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123188: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012318C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000123198: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001231A0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001231A8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001231B0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001231B8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 0000001231C0: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 0000001231C4: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001231C8: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 0000001231CC: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 0000001231D0: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001231D4: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 0000001231D8: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000001231DC: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001231E8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001231EC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001231F4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001231FC: 917E047E
	s_cbranch_execnz 65487                                     // 000000123200: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000123204: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000123208: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000012320C: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123214: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012321C: 7E420326
	s_mov_b32 s6, 0                                            // 000000123220: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123224: BF89FC07
	s_barrier                                                  // 000000123228: BFBD0000
	buffer_gl0_inv                                             // 00000012322C: E0AC0000 00000000
	s_nop 0                                                    // 000000123234: BF800000
	s_nop 0                                                    // 000000123238: BF800000
	s_nop 0                                                    // 00000012323C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123240: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000123248: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123250: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123258: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012325C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000123264: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000123268: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000123270: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000123274: 10444722
	.long 0xd4490004                                           // 000000123278: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012327C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123284: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012328C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123294: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123298: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012329C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001232A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001232A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001232A8: BF89FC07
	s_barrier                                                  // 0000001232AC: BFBD0000
	buffer_gl0_inv                                             // 0000001232B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000001232B8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000001232C0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000001232C8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000001232D0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000001232D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000001232DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001232E0: BF840001
	s_nop 0                                                    // 0000001232E4: BF800000
	s_nop 0                                                    // 0000001232E8: BF800000
	s_nop 0                                                    // 0000001232EC: BF800000
	s_nop 0                                                    // 0000001232F0: BF800000
	s_nop 0                                                    // 0000001232F4: BF800000
	s_nop 0                                                    // 0000001232F8: BF800000
	s_nop 0                                                    // 0000001232FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123300: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000123304: 327A7884
	.long 0xd4490001                                           // 000000123308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012330C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000123314: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000123318: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123324: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000123328: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000123330: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000123338: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000123340: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000123344: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123348: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012334C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000123358: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000123360: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000123368: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000123370: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000123378: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000123380: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000123384: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123388: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012338C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000123390: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123394: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000123398: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012339C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001233A8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001233AC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001233B4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001233BC: 917E047E
	s_cbranch_execnz 65487                                     // 0000001233C0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 0000001233C4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001233C8: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000001233CC: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001233D4: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001233DC: 7E420326
	s_mov_b32 s6, 0                                            // 0000001233E0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001233E4: BF89FC07
	s_barrier                                                  // 0000001233E8: BFBD0000
	buffer_gl0_inv                                             // 0000001233EC: E0AC0000 00000000
	s_nop 0                                                    // 0000001233F4: BF800000
	s_nop 0                                                    // 0000001233F8: BF800000
	s_nop 0                                                    // 0000001233FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123400: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000123408: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123410: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123418: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012341C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000123424: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000123428: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000123430: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000123434: 10444722
	.long 0xd4490004                                           // 000000123438: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012343C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123444: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012344C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123454: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123458: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012345C: 917E067E
	s_cbranch_execnz 65511                                     // 000000123460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000123464: 8C7E067E
	v_dual_mov_b32 v61, v0 :: v_dual_add_nc_u32 v60, 0x400, v47// 000000123468: CA200100 3D3C5EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000123474: BF89FC07
	s_barrier                                                  // 000000123478: BFBD0000
	buffer_gl0_inv                                             // 00000012347C: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000123484: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000012348C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000123494: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000012349C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000001234A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001234A8: BF840001
	s_nop 0                                                    // 0000001234AC: BF800000
	s_nop 0                                                    // 0000001234B0: BF800000
	s_nop 0                                                    // 0000001234B4: BF800000
	s_nop 0                                                    // 0000001234B8: BF800000
	s_nop 0                                                    // 0000001234BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000001234C0: 327C7A84
	.long 0xd4490001                                           // 0000001234C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000001234C8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001234D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000001234D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000001234D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001234E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001234E8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 0000001234F0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001234F8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123500: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000123504: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123508: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012350C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000123518: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000123520: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000123524: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000123530: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000123538: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012353C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123540: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000123544: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000123548: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000123554: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012355C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000123560: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012356C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000123570: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000123578: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123580: 917E047E
	s_cbranch_execnz 65486                                     // 000000123584: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000123588: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012358C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000123590: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123598: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001235A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001235A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001235A8: BF89FC07
	s_barrier                                                  // 0000001235AC: BFBD0000
	buffer_gl0_inv                                             // 0000001235B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001235B8: BF800000
	s_nop 0                                                    // 0000001235BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001235C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000001235C8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001235D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001235D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001235DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001235E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001235E8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001235F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001235F4: 10444722
	.long 0xd4490004                                           // 0000001235F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001235FC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123604: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012360C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123614: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123618: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012361C: 917E067E
	s_cbranch_execnz 65511                                     // 000000123620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000123624: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000123628: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000123630: BF89FC07
	s_barrier                                                  // 000000123634: BFBD0000
	buffer_gl0_inv                                             // 000000123638: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000123640: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000123648: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000123650: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000123658: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000123660: 7E780300
	s_mov_b32 s4, 0                                            // 000000123664: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000123668: BF840001
	s_nop 0                                                    // 00000012366C: BF800000
	s_nop 0                                                    // 000000123670: BF800000
	s_nop 0                                                    // 000000123674: BF800000
	s_nop 0                                                    // 000000123678: BF800000
	s_nop 0                                                    // 00000012367C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123680: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000123684: 327A7884
	.long 0xd4490001                                           // 000000123688: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012368C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000123694: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000123698: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001236A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001236A8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 0000001236B0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000001236B8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 0000001236C0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 0000001236C4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001236C8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 0000001236CC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 0000001236D8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001236E0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001236E8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001236F0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001236F8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000123700: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000123704: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123708: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012370C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000123710: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123714: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000123718: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012371C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123728: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012372C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000123734: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012373C: 917E047E
	s_cbranch_execnz 65487                                     // 000000123740: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000123744: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000123748: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000012374C: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123754: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012375C: 7E420326
	s_mov_b32 s6, 0                                            // 000000123760: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123764: BF89FC07
	s_barrier                                                  // 000000123768: BFBD0000
	buffer_gl0_inv                                             // 00000012376C: E0AC0000 00000000
	s_nop 0                                                    // 000000123774: BF800000
	s_nop 0                                                    // 000000123778: BF800000
	s_nop 0                                                    // 00000012377C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123780: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000123788: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123790: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123798: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012379C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001237A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001237A8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001237B0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001237B4: 10444722
	.long 0xd4490004                                           // 0000001237B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001237BC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 0000001237C4: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000001237CC: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000001237D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001237D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001237DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001237E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001237E4: 8C7E067E
	v_dual_mov_b32 v60, v0 :: v_dual_add_nc_u32 v61, 0x800, v47// 0000001237E8: CA200100 3C3C5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000001237F4: BF89FC07
	s_barrier                                                  // 0000001237F8: BFBD0000
	buffer_gl0_inv                                             // 0000001237FC: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000123804: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000012380C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000123814: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000012381C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000123824: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000123828: BF840001
	s_nop 0                                                    // 00000012382C: BF800000
	s_nop 0                                                    // 000000123830: BF800000
	s_nop 0                                                    // 000000123834: BF800000
	s_nop 0                                                    // 000000123838: BF800000
	s_nop 0                                                    // 00000012383C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000123840: 327C7884
	.long 0xd4490001                                           // 000000123844: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000123848: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000123850: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000123854: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000123858: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123864: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000123868: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000123870: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000123878: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123880: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000123884: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123888: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012388C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000123898: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 0000001238A0: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 0000001238A4: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000001238B0: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 0000001238B8: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 0000001238BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001238C0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000001238C4: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000001238C8: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000001238D4: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000001238DC: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000001238E0: C820473F 463E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001238EC: BF870111
	v_fmac_f32_e32 v70, v64, v36                               // 0000001238F0: 568C4940
	v_mov_b32_e32 v60, v63                                     // 0000001238F4: 7E78033F
	ds_store_b32 v62, v70                                      // 0000001238F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123900: 917E047E
	s_cbranch_execnz 65486                                     // 000000123904: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000123908: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012390C: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000123910: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123918: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000123920: 7E420326
	s_mov_b32 s6, 0                                            // 000000123924: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123928: BF89FC07
	s_barrier                                                  // 00000012392C: BFBD0000
	buffer_gl0_inv                                             // 000000123930: E0AC0000 00000000
	s_nop 0                                                    // 000000123938: BF800000
	s_nop 0                                                    // 00000012393C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123940: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000123948: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123950: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123958: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012395C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000123964: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000123968: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000123970: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000123974: 10444722
	.long 0xd4490004                                           // 000000123978: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012397C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123984: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012398C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123994: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123998: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012399C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001239A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001239A4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000001239A8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000001239B0: BF89FC07
	s_barrier                                                  // 0000001239B4: BFBD0000
	buffer_gl0_inv                                             // 0000001239B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000001239C0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000001239C8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000001239D0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000001239D8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000001239E0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000001239E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001239E8: BF840001
	s_nop 0                                                    // 0000001239EC: BF800000
	s_nop 0                                                    // 0000001239F0: BF800000
	s_nop 0                                                    // 0000001239F4: BF800000
	s_nop 0                                                    // 0000001239F8: BF800000
	s_nop 0                                                    // 0000001239FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123A00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000123A04: 327C7A84
	.long 0xd4490001                                           // 000000123A08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000123A0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000123A14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000123A18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123A24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000123A28: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000123A30: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000123A38: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123A40: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000123A44: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123A48: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000123A4C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000123A58: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000123A60: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000123A64: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000123A70: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000123A78: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000123A7C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A80: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000123A84: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000123A88: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000123A94: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123A9C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000123AA0: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123AAC: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000123AB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000123AB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123AC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000123AC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_set_inst_prefetch_distance 0x2                           // 000000123AC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000123ACC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000123AD0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123AD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000123AE0: 7E420326
	s_mov_b32 s6, 0                                            // 000000123AE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123AE8: BF89FC07
	s_barrier                                                  // 000000123AEC: BFBD0000
	buffer_gl0_inv                                             // 000000123AF0: E0AC0000 00000000
	s_nop 0                                                    // 000000123AF8: BF800000
	s_nop 0                                                    // 000000123AFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123B00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000123B08: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123B10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123B18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000123B1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000123B24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000123B28: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000123B30: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000123B34: 10444722
	.long 0xd4490004                                           // 000000123B38: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000123B3C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123B44: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000123B4C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123B54: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123B58: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000123B5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000123B60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000123B64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000123B68: BF89FC07
	s_barrier                                                  // 000000123B6C: BFBD0000
	buffer_gl0_inv                                             // 000000123B70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000123B78: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000123B80: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000123B88: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000123B90: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000123B98: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000123B9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000123BA0: BF840001
	s_nop 0                                                    // 000000123BA4: BF800000
	s_nop 0                                                    // 000000123BA8: BF800000
	s_nop 0                                                    // 000000123BAC: BF800000
	s_nop 0                                                    // 000000123BB0: BF800000
	s_nop 0                                                    // 000000123BB4: BF800000
	s_nop 0                                                    // 000000123BB8: BF800000
	s_nop 0                                                    // 000000123BBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123BC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000123BC4: 327C7A84
	.long 0xd4490001                                           // 000000123BC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000123BCC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000123BD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000123BD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123BE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000123BE8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000123BF0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000123BF8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123C00: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000123C04: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123C08: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000123C0C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000123C18: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000123C20: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000123C24: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000123C30: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000123C38: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000123C3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123C40: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000123C44: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000123C48: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000123C54: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000123C5C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000123C60: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123C6C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000123C70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000123C78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123C80: 917E047E
	s_cbranch_execnz 65486                                     // 000000123C84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_set_inst_prefetch_distance 0x2                           // 000000123C88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000123C8C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000123C90: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000123C98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000123CA0: 7E420326
	s_mov_b32 s6, 0                                            // 000000123CA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000123CA8: BF89FC07
	s_barrier                                                  // 000000123CAC: BFBD0000
	buffer_gl0_inv                                             // 000000123CB0: E0AC0000 00000000
	s_nop 0                                                    // 000000123CB8: BF800000
	s_nop 0                                                    // 000000123CBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000123CC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000123CC8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000123CD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000123CD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000123CDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000123CE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000123CE8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000123CF0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000123CF4: 10444722
	.long 0xd4490004                                           // 000000123CF8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000123CFC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000123D04: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000123D0C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000123D14: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000123D18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000123D1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000123D20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000123D24: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000123D28: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000123D30: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000123D38: BF89FC07
	s_barrier                                                  // 000000123D3C: BFBD0000
	buffer_gl0_inv                                             // 000000123D40: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000123D48: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000123D50: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000123D58: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000123D60: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000123D68: 7E780300
	s_mov_b32 s4, 0                                            // 000000123D6C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000123D70: BF840001
	s_nop 0                                                    // 000000123D74: BF800000
	s_nop 0                                                    // 000000123D78: BF800000
	s_nop 0                                                    // 000000123D7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123D80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000123D84: 327A7884
	.long 0xd4490001                                           // 000000123D88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000123D8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000123D94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000123D98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000123DA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000123DA8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000123DB0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000123DB8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000123DC0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000123DC4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123DC8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 000000123DCC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000123DD8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000123DE0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000123DE8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000123DF0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000123DF8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000123E00: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000123E04: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123E08: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 000000123E0C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000123E10: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123E14: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000123E18: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000123E1C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123E28: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000123E2C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000123E34: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000123E3C: 917E047E
	s_cbranch_execnz 65487                                     // 000000123E40: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_set_inst_prefetch_distance 0x2                           // 000000123E44: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000123E48: 8C7E047E
	.long 0xd7000107                                           // 000000123E4C: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000123E50: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000123E58: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000123E5C: D5207C08 00061080
	.long 0xd7000109                                           // 000000123E64: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000123E68: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000123E70: D5207C0A 00061480
	.long 0xd700010d                                           // 000000123E78: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000123E7C: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000123E84: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000123E88: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000123E90: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000123E94: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000123E9C: D5207C0C 00061880
	.long 0xd700010f                                           // 000000123EA4: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 000000123EA8: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000123EB0: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000123EB4: D5207C10 00062080
	.long 0xd7000111                                           // 000000123EBC: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000123EC0: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 000000123EC8: D5207C12 00062480
	.long 0xd7000113                                           // 000000123ED0: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000123ED4: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000123EDC: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 000000123EE0: D5207C14 00062880
	.long 0xd7000115                                           // 000000123EE8: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 000000123EEC: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 000000123EF4: D5207C16 00062C80
	.long 0xd7000117                                           // 000000123EFC: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000123F00: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000123F08: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000123F0C: D5207C18 00063080
	.long 0xd7000119                                           // 000000123F14: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000123F18: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000123F20: D5207C1A 00063480
	.long 0xd700011b                                           // 000000123F28: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000123F2C: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000123F34: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000123F38: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000123F40: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000123F44: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000123F48: BF062105
	s_barrier                                                  // 000000123F4C: BFBD0000
	buffer_gl0_inv                                             // 000000123F50: E0AC0000 00000000
	s_cbranch_scc0 63122                                       // 000000123F58: BFA1F692 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000123F5C: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000123F60: 8000141C
	.long 0xd73c0000                                           // 000000123F64: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000123F68: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000123F6C: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000123F70: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000123F74: 82031319
	s_add_u32 s0, s2, s0                                       // 000000123F78: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000123F7C: 82010103
	.long 0xd7006a00                                           // 000000123F80: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000123F84: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000123F88: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000123F8C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000123F94: BE810080
	.long 0xd7006a00                                           // 000000123F98: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000123F9C: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000123FA0: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123FA8: BF870092
	.long 0xd7006a00                                           // 000000123FAC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000123FB0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000123FB4: D5207C01 01AA0211
	s_nop 0                                                    // 000000123FBC: BF800000
	ds_load_b32 v2, v37                                        // 000000123FC0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000123FC8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000123FD0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000123FD8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000123FDC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000123FE4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000123FE8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000123FEC: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000123FF4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000123FF8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000124000: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000124008: 917E017E
	s_cbranch_execnz 65516                                     // 00000012400C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29c0>
	s_endpgm                                                   // 000000124010: BFB00000
		...

