00000000001a0100 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001A0100: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001A0104: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001A010C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001A0114: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001A0118: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 0000001A011C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001A0124: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 0000001A0128: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 0000001A0130: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001A0138: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001A013C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 0000001A0140: 810E020E
	s_add_u32 s0, s18, s0                                      // 0000001A0144: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001A0148: 82010113
	s_add_i32 s15, s14, 1                                      // 0000001A014C: 810F810E
	s_load_b32 s3, s[0:1], null                                // 0000001A0150: F40000C0 F8000000
	s_ashr_i32 s0, s15, 31                                     // 0000001A0158: 86009F0F
	s_mul_hi_i32 s1, s21, s2                                   // 0000001A015C: 97010215
	s_lshr_b32 s0, s0, 30                                      // 0000001A0160: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001A0164: BF870499
	s_add_i32 s15, s15, s0                                     // 0000001A0168: 810F000F
	s_and_b32 s0, s15, -4                                      // 0000001A016C: 8B00C40F
	s_ashr_i32 s18, s15, 2                                     // 0000001A0170: 8612820F
	s_sub_i32 s14, s14, s0                                     // 0000001A0174: 818E000E
	s_mul_i32 s0, s21, s2                                      // 0000001A0178: 96000215
	s_cmp_gt_i32 s14, -1                                       // 0000001A017C: BF02C10E
	s_mov_b32 s19, s18                                         // 0000001A0180: BE930012
	s_cselect_b32 s15, -1, 0                                   // 0000001A0184: 980F80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0188: BF870009
	s_and_b32 vcc_lo, exec_lo, s15                             // 0000001A018C: 8B6A0F7E
	s_cbranch_vccnz 15                                         // 0000001A0190: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 0000001A0194: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001A0198: BF8704D9
	s_add_u32 s19, s16, s22                                    // 0000001A019C: 80131610
	s_addc_u32 s21, s17, s23                                   // 0000001A01A0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 0000001A01A4: BF89FC07
	s_max_i32 s22, s3, 1                                       // 0000001A01A8: 8A168103
	s_mov_b32 s23, 0                                           // 0000001A01AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001A01B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A01B4: BF870009
	s_add_u32 s19, s19, s22                                    // 0000001A01B8: 80131613
	s_addc_u32 s21, s21, s23                                   // 0000001A01BC: 82151715
	s_add_u32 s22, s19, -4                                     // 0000001A01C0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 0000001A01C4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 0000001A01C8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s15                            // 0000001A01D0: D5010001 003D0280
	s_mov_b32 s23, exec_lo                                     // 0000001A01D8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001A01DC: BF8704B1
	v_readfirstlane_b32 s15, v1                                // 0000001A01E0: 7E1E0501
	s_waitcnt lgkmcnt(0)                                       // 0000001A01E4: BF89FC07
	s_add_i32 s21, s3, s15                                     // 0000001A01E8: 81150F03
	s_add_i32 s15, s21, 3                                      // 0000001A01EC: 810F8315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001A01F0: BF870499
	s_and_b32 s22, s15, -4                                     // 0000001A01F4: 8B16C40F
	.long 0xd4c4007e                                           // 0000001A01F8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 0000001A01FC: 02020016
	s_cbranch_execz 45                                         // 0000001A0200: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001A0204: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001A020C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A0210: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001A0214: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001A0218: 82010111
	.long 0xd7000001                                           // 0000001A021C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001A0220: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0224: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001A0228: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001A0230: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001A0234: BF840001
	s_branch 18                                                // 0000001A0238: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 0000001A023C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A0240: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 0000001A0244: 4A0808C0
	.long 0xd7000001                                           // 0000001A0248: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 0000001A024C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000001A0254: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 0000001A0258: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001A0260: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 0000001A0268: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000001A026C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 0000001A0274: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0278: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001A027C: 917E017E
	s_cbranch_execz 13                                         // 0000001A0280: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 0000001A0284: BE80007E
	.long 0xd4c3007e                                           // 0000001A0288: D4C3007E
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000001A028C: 02020803
	s_xor_b32 s0, exec_lo, s0                                  // 0000001A0290: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 0000001A0294: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 0000001A0298: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A029C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001A02A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 0000001A02A4: BE803000
	s_cbranch_execz 65509                                      // 0000001A02A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001A02AC: DC520000 057C0001
	s_branch 65506                                             // 0000001A02B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001A02B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 0000001A02BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001A02C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 0000001A02C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001A02C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 0000001A02D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A02D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001A02D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001A02E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 0000001A02E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 0000001A02EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 0000001A02F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001A02F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 0000001A0300: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001A0304: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001A030C: 30020084
	s_add_u32 s4, s4, s16                                      // 0000001A0310: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000001A0314: 82051105
	s_add_u32 s4, s4, s18                                      // 0000001A0318: 80041204
	s_addc_u32 s0, s5, s0                                      // 0000001A031C: 82000005
	.long 0xd7000401                                           // 0000001A0320: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001A0324: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001A0328: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 0000001A0334: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 0000001A033C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 0000001A0340: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001A0348: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001A0350: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001A0354: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A035C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001A0360: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001A0368: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001A036C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 0000001A0374: 8C040400
	s_waitcnt vmcnt(0)                                         // 0000001A0378: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 0000001A037C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001A0384: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001A038C: 917E047E
	s_cbranch_execnz 65515                                     // 0000001A0390: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A0394: 8C7E017E
	v_lshlrev_b32_e32 v84, 7, v7                               // 0000001A0398: 30A80E87
	s_ashr_i32 s1, s15, 2                                      // 0000001A039C: 8601820F
	s_mov_b32 s0, 0                                            // 0000001A03A0: BE800080
	s_cmp_gt_i32 s1, 0                                         // 0000001A03A4: BF028001
	s_waitcnt lgkmcnt(0)                                       // 0000001A03A8: BF89FC07
	s_barrier                                                  // 0000001A03AC: BFBD0000
	buffer_gl0_inv                                             // 0000001A03B0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 0000001A03B8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001A03BC: 30100E87
	s_branch 1                                                 // 0000001A03C0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s0, -1                                           // 0000001A03C4: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 0000001A03C8: 7E4C0280
	v_and_b32_e32 v82, 15, v0                                  // 0000001A03CC: 36A4008F
	v_bfe_u32 v83, v0, 4, 1                                    // 0000001A03D0: D6100053 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001A03D8: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A03DC: BF870003
	v_mov_b32_e32 v37, v38                                     // 0000001A03E0: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001A03E4: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001A03E8: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001A03EC: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001A03F0: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001A03F4: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001A03F8: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001A03FC: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001A0400: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001A0404: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001A0408: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001A040C: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001A0410: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001A0414: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001A0418: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001A041C: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001A0420: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001A0424: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001A0428: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001A042C: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001A0430: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001A0434: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001A0438: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001A043C: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001A0440: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001A0444: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001A0448: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001A044C: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001A0450: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001A0454: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001A0458: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001A045C: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001A0460: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001A0464: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001A0468: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001A046C: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001A0470: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001A0474: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001A0478: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001A047C: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001A0480: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001A0484: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001A0488: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001A048C: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001A0490: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001A0494: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001A0498: 7E020326
	v_mov_b32_e32 v86, v38                                     // 0000001A049C: 7EAC0326
	v_mov_b32_e32 v85, v38                                     // 0000001A04A0: 7EAA0326
	v_mov_b32_e32 v75, v38                                     // 0000001A04A4: 7E960326
	v_mov_b32_e32 v74, v38                                     // 0000001A04A8: 7E940326
	v_mov_b32_e32 v81, v38                                     // 0000001A04AC: 7EA20326
	v_mov_b32_e32 v73, v38                                     // 0000001A04B0: 7E920326
	s_cbranch_vccnz 1331                                       // 0000001A04B4: BFA40533 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1884>
	v_cmp_gt_u32_e32 vcc_lo, 12, v82                           // 0000001A04B8: 7C98A48C
	s_ashr_i32 s21, s20, 31                                    // 0000001A04BC: 86159F14
	s_lshl2_add_u32 s0, s3, s14                                // 0000001A04C0: 87800E03
	s_lshl_b64 s[4:5], s[20:21], 11                            // 0000001A04C4: 84848B14
	s_add_i32 s3, s0, 1                                        // 0000001A04C8: 81038100
	v_dual_cndmask_b32 v1, 0, v82 :: v_dual_lshlrev_b32 v2, 10, v7// 0000001A04CC: CA62A480 01020E8A
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 0000001A04D4: CA220080 41000085
	s_add_u32 s0, s6, s4                                       // 0000001A04DC: 80000406
	s_addc_u32 s4, s7, s5                                      // 0000001A04E0: 82040507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A04E4: BF870092
	.long 0xd7000002                                           // 0000001A04E8: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000001A04EC: 02020400
	v_add_co_ci_u32_e64 v4, null, s4, 0, s0                    // 0000001A04F0: D5207C04 00010004
	s_lshl_b64 s[4:5], s[20:21], 8                             // 0000001A04F8: 84848814
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A04FC: BF870009
	v_dual_mov_b32 v91, s5 :: v_dual_and_b32 v0, 0x60, v0      // 0000001A0500: CA240005 5B0000FF 00000060
	s_movk_i32 s0, 0x210                                       // 0000001A050C: B0000210
	v_dual_mov_b32 v66, v65 :: v_dual_lshlrev_b32 v3, 9, v7    // 0000001A0510: CA220141 42020E89
	v_dual_mov_b32 v68, v65 :: v_dual_lshlrev_b32 v5, 5, v83   // 0000001A0518: CA220141 4404A685
	v_dual_mov_b32 v109, 0xf149f2ca :: v_dual_lshlrev_b32 v6, 1, v82// 0000001A0520: CA2200FF 6D06A481 F149F2CA
	.long 0xd7006a00                                           // 0000001A052C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000001A0530: 02020102
	v_mad_u32_u24 v1, v1, s0, 0x2410                           // 0000001A0534: D60B0001 03FC0101 00002410
	v_dual_mov_b32 v67, v65 :: v_dual_lshlrev_b32 v2, 8, v7    // 0000001A0540: CA220141 43020E88
	v_add_co_ci_u32_e64 v87, null, 0, v4, vcc_lo               // 0000001A0548: D5207C57 01AA0880
	v_or3_b32 v88, v3, v5, v6                                  // 0000001A0550: D6580058 041A0B03
	v_lshl_or_b32 v89, v82, 5, v3                              // 0000001A0558: D6560059 040D0B52
	v_or3_b32 v90, s4, v82, v84                                // 0000001A0560: D658005A 0552A404
	v_dual_mov_b32 v69, v65 :: v_dual_and_b32 v92, 12, v82     // 0000001A0568: CA240141 455CA48C
	v_dual_mov_b32 v112, 0xf149f2ca :: v_dual_add_nc_u32 v93, v1, v2// 0000001A0570: CA2000FF 705C0501 F149F2CA
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v111, 0xf149f2ca // 0000001A057C: CA100141 466E00FF F149F2CA
	v_dual_mov_b32 v71, v65 :: v_dual_mov_b32 v110, 0xf149f2ca // 0000001A0588: CA100141 476E00FF F149F2CA
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v113, 0xf149f2ca // 0000001A0594: CA100141 487000FF F149F2CA
	v_dual_mov_b32 v108, 0xf149f2ca :: v_dual_mov_b32 v105, 0xf149f2ca// 0000001A05A0: CA1000FF 6C6800FF F149F2CA
	v_dual_mov_b32 v103, 0xf149f2ca :: v_dual_mov_b32 v96, v65 // 0000001A05AC: CA1000FF 67600141 F149F2CA
	v_mov_b32_e32 v95, v65                                     // 0000001A05B8: 7EBE0341
	v_mov_b32_e32 v97, v65                                     // 0000001A05BC: 7EC20341
	v_mov_b32_e32 v98, v65                                     // 0000001A05C0: 7EC40341
	v_mov_b32_e32 v99, v65                                     // 0000001A05C4: 7EC60341
	v_mov_b32_e32 v100, v65                                    // 0000001A05C8: 7EC80341
	v_mov_b32_e32 v101, v65                                    // 0000001A05CC: 7ECA0341
	v_mov_b32_e32 v94, v65                                     // 0000001A05D0: 7EBC0341
	v_mov_b32_e32 v1, v65                                      // 0000001A05D4: 7E020341
	v_mov_b32_e32 v2, v65                                      // 0000001A05D8: 7E040341
	v_mov_b32_e32 v3, v65                                      // 0000001A05DC: 7E060341
	v_mov_b32_e32 v4, v65                                      // 0000001A05E0: 7E080341
	v_mov_b32_e32 v5, v65                                      // 0000001A05E4: 7E0A0341
	v_mov_b32_e32 v6, v65                                      // 0000001A05E8: 7E0C0341
	v_mov_b32_e32 v7, v65                                      // 0000001A05EC: 7E0E0341
	v_mov_b32_e32 v8, v65                                      // 0000001A05F0: 7E100341
	v_mov_b32_e32 v9, v65                                      // 0000001A05F4: 7E120341
	v_mov_b32_e32 v10, v65                                     // 0000001A05F8: 7E140341
	v_mov_b32_e32 v11, v65                                     // 0000001A05FC: 7E160341
	v_mov_b32_e32 v12, v65                                     // 0000001A0600: 7E180341
	v_mov_b32_e32 v13, v65                                     // 0000001A0604: 7E1A0341
	v_mov_b32_e32 v14, v65                                     // 0000001A0608: 7E1C0341
	v_mov_b32_e32 v15, v65                                     // 0000001A060C: 7E1E0341
	v_mov_b32_e32 v16, v65                                     // 0000001A0610: 7E200341
	v_mov_b32_e32 v17, v65                                     // 0000001A0614: 7E220341
	v_mov_b32_e32 v18, v65                                     // 0000001A0618: 7E240341
	v_mov_b32_e32 v19, v65                                     // 0000001A061C: 7E260341
	v_mov_b32_e32 v20, v65                                     // 0000001A0620: 7E280341
	v_mov_b32_e32 v21, v65                                     // 0000001A0624: 7E2A0341
	v_mov_b32_e32 v22, v65                                     // 0000001A0628: 7E2C0341
	v_mov_b32_e32 v23, v65                                     // 0000001A062C: 7E2E0341
	v_mov_b32_e32 v24, v65                                     // 0000001A0630: 7E300341
	v_mov_b32_e32 v25, v65                                     // 0000001A0634: 7E320341
	v_mov_b32_e32 v26, v65                                     // 0000001A0638: 7E340341
	v_mov_b32_e32 v27, v65                                     // 0000001A063C: 7E360341
	v_mov_b32_e32 v28, v65                                     // 0000001A0640: 7E380341
	v_mov_b32_e32 v29, v65                                     // 0000001A0644: 7E3A0341
	v_mov_b32_e32 v30, v65                                     // 0000001A0648: 7E3C0341
	v_mov_b32_e32 v31, v65                                     // 0000001A064C: 7E3E0341
	v_mov_b32_e32 v32, v65                                     // 0000001A0650: 7E400341
	v_mov_b32_e32 v57, v65                                     // 0000001A0654: 7E720341
	v_mov_b32_e32 v58, v65                                     // 0000001A0658: 7E740341
	v_mov_b32_e32 v59, v65                                     // 0000001A065C: 7E760341
	v_mov_b32_e32 v60, v65                                     // 0000001A0660: 7E780341
	v_mov_b32_e32 v61, v65                                     // 0000001A0664: 7E7A0341
	v_mov_b32_e32 v62, v65                                     // 0000001A0668: 7E7C0341
	v_mov_b32_e32 v63, v65                                     // 0000001A066C: 7E7E0341
	v_mov_b32_e32 v64, v65                                     // 0000001A0670: 7E800341
	v_mov_b32_e32 v49, v65                                     // 0000001A0674: 7E620341
	v_mov_b32_e32 v50, v65                                     // 0000001A0678: 7E640341
	v_mov_b32_e32 v51, v65                                     // 0000001A067C: 7E660341
	v_mov_b32_e32 v52, v65                                     // 0000001A0680: 7E680341
	v_mov_b32_e32 v53, v65                                     // 0000001A0684: 7E6A0341
	v_mov_b32_e32 v54, v65                                     // 0000001A0688: 7E6C0341
	v_mov_b32_e32 v55, v65                                     // 0000001A068C: 7E6E0341
	v_mov_b32_e32 v56, v65                                     // 0000001A0690: 7E700341
	v_mov_b32_e32 v41, v65                                     // 0000001A0694: 7E520341
	v_mov_b32_e32 v42, v65                                     // 0000001A0698: 7E540341
	v_mov_b32_e32 v43, v65                                     // 0000001A069C: 7E560341
	v_mov_b32_e32 v44, v65                                     // 0000001A06A0: 7E580341
	v_mov_b32_e32 v45, v65                                     // 0000001A06A4: 7E5A0341
	v_mov_b32_e32 v46, v65                                     // 0000001A06A8: 7E5C0341
	v_mov_b32_e32 v47, v65                                     // 0000001A06AC: 7E5E0341
	v_mov_b32_e32 v48, v65                                     // 0000001A06B0: 7E600341
	v_mov_b32_e32 v33, v65                                     // 0000001A06B4: 7E420341
	v_mov_b32_e32 v34, v65                                     // 0000001A06B8: 7E440341
	v_mov_b32_e32 v35, v65                                     // 0000001A06BC: 7E460341
	v_mov_b32_e32 v36, v65                                     // 0000001A06C0: 7E480341
	v_mov_b32_e32 v37, v65                                     // 0000001A06C4: 7E4A0341
	v_mov_b32_e32 v38, v65                                     // 0000001A06C8: 7E4C0341
	v_mov_b32_e32 v39, v65                                     // 0000001A06CC: 7E4E0341
	v_mov_b32_e32 v40, v65                                     // 0000001A06D0: 7E500341
	s_mov_b32 s18, 0                                           // 0000001A06D4: BE920080
	s_branch 250                                               // 0000001A06D8: BFA000FA <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x9c4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A06DC: 8C7E007E
	s_ashr_i32 s17, s16, 31                                    // 0000001A06E0: 86119F10
	s_ashr_i32 s15, s14, 31                                    // 0000001A06E4: 860F9F0E
	s_lshl_b64 s[16:17], s[16:17], 9                           // 0000001A06E8: 84908910
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000001A06EC: 848E890E
	.long 0xd7006a7c                                           // 0000001A06F0: D7006A7C
	v_cndmask_b32_e32 v1, s16, v90, vcc_lo                     // 0000001A06F4: 0202B410
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A06F8: BF870001
	v_add_co_ci_u32_e64 v125, null, s17, v91, vcc_lo           // 0000001A06FC: D5207C7D 01AAB611
	s_ashr_i32 s5, s4, 31                                      // 0000001A0704: 86059F04
	.long 0xd7006a7e                                           // 0000001A0708: D7006A7E
	v_cndmask_b32_e32 v1, s14, v90, vcc_lo                     // 0000001A070C: 0202B40E
	s_lshl_b64 s[4:5], s[4:5], 9                               // 0000001A0710: 84848904
	.long 0xd73c007c                                           // 0000001A0714: D73C007C
	v_cndmask_b32_e32 v1, 3, v124, vcc_lo                      // 0000001A0718: 0202F883
	v_add_co_ci_u32_e64 v127, null, s15, v91, vcc_lo           // 0000001A071C: D5207C7F 01AAB60F
	.long 0xd7006a80                                           // 0000001A0724: D7006A80
	v_cndmask_b32_e32 v1, s4, v90, vcc_lo                      // 0000001A0728: 0202B404
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A072C: BF870001
	v_add_co_ci_u32_e64 v129, null, s5, v91, vcc_lo            // 0000001A0730: D5207C81 01AAB605
	s_ashr_i32 s7, s6, 31                                      // 0000001A0738: 86079F06
	.long 0xd7006a9e                                           // 0000001A073C: D7006A9E
	v_cndmask_b32_e32 v1, s8, v124, vcc_lo                     // 0000001A0740: 0202F808
	s_lshl_b64 s[6:7], s[6:7], 9                               // 0000001A0744: 84868906
	v_add_co_ci_u32_e64 v159, null, s9, v125, vcc_lo           // 0000001A0748: D5207C9F 01AAFA09
	.long 0xd73c007c                                           // 0000001A0750: D73C007C
	v_cndmask_b32_e32 v1, 3, v126, vcc_lo                      // 0000001A0754: 0202FC83
	.long 0xd73c007e                                           // 0000001A0758: D73C007E
	v_cndmask_b32_e32 v1, 3, v128, vcc_lo                      // 0000001A075C: 02030083
	.long 0xd7006a80                                           // 0000001A0760: D7006A80
	v_cndmask_b32_e32 v1, s6, v90, vcc_lo                      // 0000001A0764: 0202B406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A0768: BF870211
	v_add_co_ci_u32_e64 v129, null, s7, v91, vcc_lo            // 0000001A076C: D5207C81 01AAB607
	.long 0xd7006aa0                                           // 0000001A0774: D7006AA0
	v_cndmask_b32_e32 v1, s8, v124, vcc_lo                     // 0000001A0778: 0202F808
	v_bfe_u32 v103, v115, 16, 1                                // 0000001A077C: D6100067 02052173
	v_add_co_ci_u32_e64 v161, null, s9, v125, vcc_lo           // 0000001A0784: D5207CA1 01AAFA09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A078C: BF870224
	.long 0xd73c007c                                           // 0000001A0790: D73C007C
	v_cndmask_b32_e32 v1, 3, v128, vcc_lo                      // 0000001A0794: 02030083
	.long 0xd7006aa2                                           // 0000001A0798: D7006AA2
	v_cndmask_b32_e32 v1, s8, v126, vcc_lo                     // 0000001A079C: 0202FC08
	v_add3_u32 v103, v115, v103, 0x7fff                        // 0000001A07A0: D6550067 03FECF73 00007FFF
	v_add_co_ci_u32_e64 v163, null, s9, v127, vcc_lo           // 0000001A07AC: D5207CA3 01AAFE09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A07B4: BF870094
	.long 0xd7006aba                                           // 0000001A07B8: D7006ABA
	v_cndmask_b32_e32 v1, s8, v124, vcc_lo                     // 0000001A07BC: 0202F808
	v_add_co_ci_u32_e64 v187, null, s9, v125, vcc_lo           // 0000001A07C0: D5207CBB 01AAFA09
	ds_store_b16_d16_hi v88, v103 offset:448                   // 0000001A07C8: DA8401C0 00006758
	ds_load_b128 v[116:119], v89                               // 0000001A07D0: DBFC0000 74000059
	ds_load_b128 v[120:123], v89 offset:16                     // 0000001A07D8: DBFC0010 78000059
	s_clause 0x1f                                              // 0000001A07E0: BF85001F
	global_load_b64 v[124:125], v[158:159], off                // 0000001A07E4: DC560000 7C7C009E
	global_load_b64 v[132:133], v[158:159], off offset:128     // 0000001A07EC: DC560080 847C009E
	global_load_b64 v[140:141], v[158:159], off offset:256     // 0000001A07F4: DC560100 8C7C009E
	global_load_b64 v[148:149], v[158:159], off offset:384     // 0000001A07FC: DC560180 947C009E
	global_load_b64 v[126:127], v[160:161], off                // 0000001A0804: DC560000 7E7C00A0
	global_load_b64 v[134:135], v[160:161], off offset:128     // 0000001A080C: DC560080 867C00A0
	global_load_b64 v[142:143], v[160:161], off offset:256     // 0000001A0814: DC560100 8E7C00A0
	global_load_b64 v[150:151], v[160:161], off offset:384     // 0000001A081C: DC560180 967C00A0
	global_load_b64 v[128:129], v[162:163], off                // 0000001A0824: DC560000 807C00A2
	global_load_b64 v[136:137], v[162:163], off offset:128     // 0000001A082C: DC560080 887C00A2
	global_load_b64 v[144:145], v[162:163], off offset:256     // 0000001A0834: DC560100 907C00A2
	global_load_b64 v[152:153], v[162:163], off offset:384     // 0000001A083C: DC560180 987C00A2
	global_load_b64 v[130:131], v[186:187], off                // 0000001A0844: DC560000 827C00BA
	global_load_b64 v[138:139], v[186:187], off offset:128     // 0000001A084C: DC560080 8A7C00BA
	global_load_b64 v[146:147], v[186:187], off offset:256     // 0000001A0854: DC560100 927C00BA
	global_load_b64 v[154:155], v[186:187], off offset:384     // 0000001A085C: DC560180 9A7C00BA
	global_load_b64 v[156:157], v[158:159], off offset:512     // 0000001A0864: DC560200 9C7C009E
	global_load_b64 v[164:165], v[158:159], off offset:640     // 0000001A086C: DC560280 A47C009E
	global_load_b64 v[172:173], v[158:159], off offset:768     // 0000001A0874: DC560300 AC7C009E
	global_load_b64 v[180:181], v[158:159], off offset:896     // 0000001A087C: DC560380 B47C009E
	global_load_b64 v[158:159], v[160:161], off offset:512     // 0000001A0884: DC560200 9E7C00A0
	global_load_b64 v[166:167], v[160:161], off offset:640     // 0000001A088C: DC560280 A67C00A0
	global_load_b64 v[174:175], v[160:161], off offset:768     // 0000001A0894: DC560300 AE7C00A0
	global_load_b64 v[182:183], v[160:161], off offset:896     // 0000001A089C: DC560380 B67C00A0
	global_load_b64 v[160:161], v[162:163], off offset:512     // 0000001A08A4: DC560200 A07C00A2
	global_load_b64 v[168:169], v[162:163], off offset:640     // 0000001A08AC: DC560280 A87C00A2
	global_load_b64 v[176:177], v[162:163], off offset:768     // 0000001A08B4: DC560300 B07C00A2
	global_load_b64 v[184:185], v[162:163], off offset:896     // 0000001A08BC: DC560380 B87C00A2
	global_load_b64 v[162:163], v[186:187], off offset:512     // 0000001A08C4: DC560200 A27C00BA
	global_load_b64 v[170:171], v[186:187], off offset:640     // 0000001A08CC: DC560280 AA7C00BA
	global_load_b64 v[178:179], v[186:187], off offset:768     // 0000001A08D4: DC560300 B27C00BA
	global_load_b64 v[186:187], v[186:187], off offset:896     // 0000001A08DC: DC560380 BA7C00BA
	v_dual_fmac_f32 v73, v95, v106 :: v_dual_fmac_f32 v74, v97, v111// 0000001A08E4: C800D55F 494ADF61
	v_dual_fmac_f32 v81, v96, v109 :: v_dual_fmac_f32 v114, v101, v108// 0000001A08EC: C800DB60 5172D965
	v_dual_fmac_f32 v75, v98, v113 :: v_dual_fmac_f32 v86, v100, v110// 0000001A08F4: C800E362 4B56DD64
	v_dual_fmac_f32 v85, v99, v112 :: v_dual_mul_f32 v58, v58, v109// 0000001A08FC: C806E163 553ADB3A
	v_dual_mul_f32 v57, v57, v106 :: v_dual_mul_f32 v60, v60, v113// 0000001A0904: C8C6D539 393CE33C
	v_dual_mul_f32 v59, v59, v111 :: v_dual_mul_f32 v62, v62, v110// 0000001A090C: C8C6DF3B 3B3EDD3E
	v_dual_mul_f32 v61, v61, v112 :: v_dual_mul_f32 v64, v64, v105// 0000001A0914: C8C6E13D 3D40D340
	v_dual_mul_f32 v63, v63, v108 :: v_dual_mul_f32 v50, v50, v109// 0000001A091C: C8C6D93F 3F32DB32
	v_dual_mul_f32 v49, v49, v106 :: v_dual_mul_f32 v52, v52, v113// 0000001A0924: C8C6D531 3134E334
	v_dual_mul_f32 v51, v51, v111 :: v_dual_mul_f32 v54, v54, v110// 0000001A092C: C8C6DF33 3336DD36
	v_dual_mul_f32 v53, v53, v112 :: v_dual_mul_f32 v56, v56, v105// 0000001A0934: C8C6E135 3538D338
	v_dual_mul_f32 v55, v55, v108 :: v_dual_mul_f32 v42, v42, v109// 0000001A093C: C8C6D937 372ADB2A
	v_dual_mul_f32 v41, v41, v106 :: v_dual_mul_f32 v44, v44, v113// 0000001A0944: C8C6D529 292CE32C
	v_dual_mul_f32 v43, v43, v111 :: v_dual_mul_f32 v46, v46, v110// 0000001A094C: C8C6DF2B 2B2EDD2E
	v_dual_mul_f32 v45, v45, v112 :: v_dual_mul_f32 v48, v48, v105// 0000001A0954: C8C6E12D 2D30D330
	v_dual_mul_f32 v47, v47, v108 :: v_dual_mul_f32 v34, v34, v109// 0000001A095C: C8C6D92F 2F22DB22
	v_dual_mul_f32 v33, v33, v106 :: v_dual_mul_f32 v36, v36, v113// 0000001A0964: C8C6D521 2124E324
	v_dual_mul_f32 v35, v35, v111 :: v_dual_mul_f32 v38, v38, v110// 0000001A096C: C8C6DF23 2326DD26
	v_dual_mul_f32 v37, v37, v112 :: v_dual_mul_f32 v40, v40, v105// 0000001A0974: C8C6E125 2528D328
	v_dual_mul_f32 v39, v39, v108 :: v_dual_mul_f32 v26, v26, v109// 0000001A097C: C8C6D927 271ADB1A
	v_dual_mul_f32 v25, v25, v106 :: v_dual_mul_f32 v28, v28, v113// 0000001A0984: C8C6D519 191CE31C
	v_dual_mul_f32 v27, v27, v111 :: v_dual_mul_f32 v30, v30, v110// 0000001A098C: C8C6DF1B 1B1EDD1E
	v_dual_mul_f32 v29, v29, v112 :: v_dual_mul_f32 v32, v32, v105// 0000001A0994: C8C6E11D 1D20D320
	v_dual_mul_f32 v31, v31, v108 :: v_dual_mul_f32 v18, v18, v109// 0000001A099C: C8C6D91F 1F12DB12
	v_dual_mul_f32 v17, v17, v106 :: v_dual_mul_f32 v20, v20, v113// 0000001A09A4: C8C6D511 1114E314
	v_dual_mul_f32 v19, v19, v111 :: v_dual_mul_f32 v22, v22, v110// 0000001A09AC: C8C6DF13 1316DD16
	v_dual_mul_f32 v21, v21, v112 :: v_dual_mul_f32 v24, v24, v105// 0000001A09B4: C8C6E115 1518D318
	v_dual_mul_f32 v23, v23, v108 :: v_dual_mul_f32 v10, v10, v109// 0000001A09BC: C8C6D917 170ADB0A
	v_dual_mul_f32 v9, v9, v106 :: v_dual_mul_f32 v12, v12, v113// 0000001A09C4: C8C6D509 090CE30C
	v_dual_mul_f32 v11, v11, v111 :: v_dual_mul_f32 v14, v14, v110// 0000001A09CC: C8C6DF0B 0B0EDD0E
	v_dual_mul_f32 v13, v13, v112 :: v_dual_mul_f32 v16, v16, v105// 0000001A09D4: C8C6E10D 0D10D310
	v_dual_mul_f32 v15, v15, v108 :: v_dual_mul_f32 v2, v2, v109// 0000001A09DC: C8C6D90F 0F02DB02
	v_dual_mul_f32 v1, v1, v106 :: v_dual_mul_f32 v4, v4, v113 // 0000001A09E4: C8C6D501 0104E304
	v_dual_mul_f32 v3, v3, v111 :: v_dual_mul_f32 v6, v6, v110 // 0000001A09EC: C8C6DF03 0306DD06
	v_dual_mul_f32 v5, v5, v112 :: v_dual_mul_f32 v8, v8, v105 // 0000001A09F4: C8C6E105 0508D308
	v_dual_mul_f32 v7, v7, v108 :: v_dual_mov_b32 v112, v76    // 0000001A09FC: C8D0D907 0770014C
	v_fma_f32 v94, v94, v105, v115                             // 0000001A0A04: D613005E 05CED35E
	v_dual_mov_b32 v109, v102 :: v_dual_mov_b32 v110, v77      // 0000001A0A0C: CA100166 6D6E014D
	v_dual_mov_b32 v111, v104 :: v_dual_mov_b32 v108, v78      // 0000001A0A14: CA100168 6F6C014E
	v_dual_mov_b32 v113, v107 :: v_dual_mov_b32 v96, v81       // 0000001A0A1C: CA10016B 71600151
	v_dual_mov_b32 v105, v79 :: v_dual_mov_b32 v100, v86       // 0000001A0A24: CA10014F 69640156
	v_dual_mov_b32 v103, v80 :: v_dual_mov_b32 v98, v75        // 0000001A0A2C: CA100150 6762014B
	v_mov_b32_e32 v95, v73                                     // 0000001A0A34: 7EBE0349
	v_mov_b32_e32 v97, v74                                     // 0000001A0A38: 7EC2034A
	v_mov_b32_e32 v99, v85                                     // 0000001A0A3C: 7EC60355
	v_mov_b32_e32 v101, v114                                   // 0000001A0A40: 7ECA0372
	s_add_i32 s1, s1, -1                                       // 0000001A0A44: 8101C101
	s_add_i32 s3, s3, -16                                      // 0000001A0A48: 8103D003
	s_add_i32 s18, s18, 16                                     // 0000001A0A4C: 81129012
	s_cmp_lg_u32 s1, 0                                         // 0000001A0A50: BF078001
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001A0A54: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[116:123], v[124:131], v[57:64]// 0000001A0A58: CC414039 1CE6F974
	s_waitcnt vmcnt(18)                                        // 0000001A0A60: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[116:123], v[132:139], v[49:56]// 0000001A0A64: CC414031 1CC70974
	s_waitcnt vmcnt(17)                                        // 0000001A0A6C: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[116:123], v[140:147], v[41:48]// 0000001A0A70: CC414029 1CA71974
	s_waitcnt vmcnt(16)                                        // 0000001A0A78: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[116:123], v[148:155], v[33:40]// 0000001A0A7C: CC414021 1C872974
	s_waitcnt vmcnt(3)                                         // 0000001A0A84: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[116:123], v[156:163], v[25:32]// 0000001A0A88: CC414019 1C673974
	s_waitcnt vmcnt(2)                                         // 0000001A0A90: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[116:123], v[164:171], v[17:24]// 0000001A0A94: CC414011 1C474974
	s_waitcnt vmcnt(1)                                         // 0000001A0A9C: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[116:123], v[172:179], v[9:16]// 0000001A0AA0: CC414009 1C275974
	s_waitcnt vmcnt(0)                                         // 0000001A0AA8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[116:123], v[180:187], v[1:8]// 0000001A0AAC: CC414001 1C076974
	s_barrier                                                  // 0000001A0AB4: BFBD0000
	buffer_gl0_inv                                             // 0000001A0AB8: E0AC0000 00000000
	s_cbranch_scc0 943                                         // 0000001A0AC0: BFA103AF <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1880>
	v_dual_mov_b32 v86, s18 :: v_dual_add_nc_u32 v73, s18, v92 // 0000001A0AC4: CA200012 5648B812
	ds_load_b128 v[178:181], v93                               // 0000001A0ACC: DBFC0000 B200005D
	ds_load_b128 v[182:185], v93 offset:16                     // 0000001A0AD4: DBFC0010 B600005D
	ds_load_b128 v[186:189], v93 offset:32                     // 0000001A0ADC: DBFC0020 BA00005D
	ds_load_b128 v[190:193], v93 offset:48                     // 0000001A0AE4: DBFC0030 BE00005D
	ds_load_b128 v[198:201], v93 offset:80                     // 0000001A0AEC: DBFC0050 C600005D
	ds_load_b128 v[194:197], v93 offset:64                     // 0000001A0AF4: DBFC0040 C200005D
	ds_load_b128 v[206:209], v93 offset:112                    // 0000001A0AFC: DBFC0070 CE00005D
	ds_load_b128 v[202:205], v93 offset:96                     // 0000001A0B04: DBFC0060 CA00005D
	ds_load_b128 v[214:217], v93 offset:144                    // 0000001A0B0C: DBFC0090 D600005D
	ds_load_b128 v[210:213], v93 offset:128                    // 0000001A0B14: DBFC0080 D200005D
	ds_load_b32 v73, v73 offset:1024                           // 0000001A0B1C: D8D80400 49000049
	s_waitcnt lgkmcnt(0)                                       // 0000001A0B24: BF89FC07
	v_ashrrev_i32_e32 v74, 31, v73                             // 0000001A0B28: 3494929F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0B2C: BF870091
	.long 0xd73c0049                                           // 0000001A0B30: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 0000001A0B34: 0202928C
	.long 0xd7006a49                                           // 0000001A0B38: D7006A49
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 0000001A0B3C: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0B40: BF870001
	v_add_co_ci_u32_e64 v74, null, v87, v74, vcc_lo            // 0000001A0B44: D5207C4A 01AA9557
	v_cmp_gt_i32_e32 vcc_lo, s3, v82                           // 0000001A0B4C: 7C88A403
	s_clause 0xf                                               // 0000001A0B50: BF85000F
	global_load_b128 v[118:121], v[73:74], off offset:16       // 0000001A0B54: DC5E0010 767C0049
	global_load_b128 v[114:117], v[73:74], off                 // 0000001A0B5C: DC5E0000 727C0049
	global_load_b128 v[126:129], v[73:74], off offset:144      // 0000001A0B64: DC5E0090 7E7C0049
	global_load_b128 v[122:125], v[73:74], off offset:128      // 0000001A0B6C: DC5E0080 7A7C0049
	global_load_b128 v[134:137], v[73:74], off offset:272      // 0000001A0B74: DC5E0110 867C0049
	global_load_b128 v[130:133], v[73:74], off offset:256      // 0000001A0B7C: DC5E0100 827C0049
	global_load_b128 v[142:145], v[73:74], off offset:400      // 0000001A0B84: DC5E0190 8E7C0049
	global_load_b128 v[138:141], v[73:74], off offset:384      // 0000001A0B8C: DC5E0180 8A7C0049
	global_load_b128 v[150:153], v[73:74], off offset:528      // 0000001A0B94: DC5E0210 967C0049
	global_load_b128 v[146:149], v[73:74], off offset:512      // 0000001A0B9C: DC5E0200 927C0049
	global_load_b128 v[158:161], v[73:74], off offset:656      // 0000001A0BA4: DC5E0290 9E7C0049
	global_load_b128 v[154:157], v[73:74], off offset:640      // 0000001A0BAC: DC5E0280 9A7C0049
	global_load_b128 v[166:169], v[73:74], off offset:784      // 0000001A0BB4: DC5E0310 A67C0049
	global_load_b128 v[162:165], v[73:74], off offset:768      // 0000001A0BBC: DC5E0300 A27C0049
	global_load_b128 v[174:177], v[73:74], off offset:912      // 0000001A0BC4: DC5E0390 AE7C0049
	global_load_b128 v[170:173], v[73:74], off offset:896      // 0000001A0BCC: DC5E0380 AA7C0049
	s_waitcnt vmcnt(14)                                        // 0000001A0BD4: BF893BF7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[178:185], v[114:121], v[65:72]// 0000001A0BD8: CC414049 1D06E5B2
	ds_load_b128 v[118:121], v93 offset:176                    // 0000001A0BE0: DBFC00B0 7600005D
	ds_load_b128 v[114:117], v93 offset:160                    // 0000001A0BE8: DBFC00A0 7200005D
	s_waitcnt vmcnt(12)                                        // 0000001A0BF0: BF8933F7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[186:193], v[122:129], v[73:80]// 0000001A0BF4: CC414049 1D26F5BA
	ds_load_b128 v[126:129], v93 offset:208                    // 0000001A0BFC: DBFC00D0 7E00005D
	ds_load_b128 v[122:125], v93 offset:192                    // 0000001A0C04: DBFC00C0 7A00005D
	s_waitcnt vmcnt(10)                                        // 0000001A0C0C: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[194:201], v[130:137], v[73:80]// 0000001A0C10: CC414049 1D2705C2
	ds_load_b128 v[134:137], v93 offset:240                    // 0000001A0C18: DBFC00F0 8600005D
	ds_load_b128 v[130:133], v93 offset:224                    // 0000001A0C20: DBFC00E0 8200005D
	s_waitcnt vmcnt(8)                                         // 0000001A0C28: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[202:209], v[138:145], v[73:80]// 0000001A0C2C: CC414049 1D2715CA
	s_waitcnt vmcnt(6)                                         // 0000001A0C34: BF891BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A0C38: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[73:80], v[210:217], v[146:153], v[73:80]// 0000001A0C3C: CC414049 1D2725D2
	s_waitcnt vmcnt(4) lgkmcnt(4)                              // 0000001A0C44: BF891047
	v_wmma_f32_16x16x16_bf16 v[73:80], v[114:121], v[154:161], v[73:80]// 0000001A0C48: CC414049 1D273572
	ds_load_b128 v[114:117], v86 offset:1024                   // 0000001A0C50: DBFC0400 72000056
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000001A0C58: BF890837
	v_wmma_f32_16x16x16_bf16 v[73:80], v[122:129], v[162:169], v[73:80]// 0000001A0C5C: CC414049 1D27457A
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 0000001A0C64: BF890017
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0C68: BF870091
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[170:177], v[73:80]// 0000001A0C6C: CC414049 1D275582
	v_mul_f32_e32 v81, 0x3d800000, v73                         // 0000001A0C74: 10A292FF 3D800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0C7C: BF870001
	v_cndmask_b32_e32 v73, 0xf149f2ca, v81, vcc_lo             // 0000001A0C80: 0292A2FF F149F2CA
	s_waitcnt lgkmcnt(0)                                       // 0000001A0C88: BF89FC07
	v_readfirstlane_b32 s16, v114                              // 0000001A0C8C: 7E200572
	v_readfirstlane_b32 s14, v115                              // 0000001A0C90: 7E1C0573
	v_readfirstlane_b32 s4, v116                               // 0000001A0C94: 7E080574
	v_readfirstlane_b32 s6, v117                               // 0000001A0C98: 7E0C0575
	v_mov_b32_dpp v85, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0C9C: 7EAA02FA FF096149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CA4: BF870091
	v_max_f32_e32 v85, v85, v85                                // 0000001A0CA8: 20AAAB55
	v_max_f32_e32 v73, v73, v85                                // 0000001A0CAC: 2092AB49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CB0: BF870091
	v_mov_b32_dpp v85, v73 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0CB4: 7EAA02FA FF096249
	v_max_f32_e32 v85, v85, v85                                // 0000001A0CBC: 20AAAB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CC0: BF870091
	v_max_f32_e32 v73, v73, v85                                // 0000001A0CC4: 2092AB49
	v_mov_b32_dpp v85, v73 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0CC8: 7EAA02FA FF096449
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CD0: BF870091
	v_max_f32_e32 v85, v85, v85                                // 0000001A0CD4: 20AAAB55
	v_max_f32_e32 v73, v73, v85                                // 0000001A0CD8: 2092AB49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CDC: BF870091
	v_mov_b32_dpp v85, v73 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0CE0: 7EAA02FA FF096849
	v_max3_f32 v102, v109, v73, v85                            // 0000001A0CE8: D61C0066 0556936D
	v_mov_b32_e32 v73, 0                                       // 0000001A0CF0: 7E920280
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A0CF4: BE85206A
	s_cbranch_execz 31                                         // 0000001A0CF8: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xc78>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0CFC: BF870092
	v_sub_f32_e32 v73, v81, v102                               // 0000001A0D00: 0892CD51
	v_mul_f32_e32 v81, 0x3fb8aa3b, v73                         // 0000001A0D04: 10A292FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A0D0C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 0000001A0D10: 020292FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A0D18: BF870122
	v_fma_f32 v85, 0x3fb8aa3b, v73, -v81                       // 0000001A0D1C: D6130055 854692FF 3FB8AA3B
	v_rndne_f32_e32 v86, v81                                   // 0000001A0D28: 7EAC4751
	v_fmac_f32_e32 v85, 0x32a5705f, v73                        // 0000001A0D2C: 56AA92FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0D34: BF870092
	v_sub_f32_e32 v81, v81, v86                                // 0000001A0D38: 08A2AD51
	v_add_f32_e32 v81, v81, v85                                // 0000001A0D3C: 06A2AB51
	v_cvt_i32_f32_e32 v85, v86                                 // 0000001A0D40: 7EAA1156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A0D44: BF870292
	v_exp_f32_e32 v81, v81                                     // 0000001A0D48: 7EA24B51
	.long 0xd71c0051                                           // 0000001A0D4C: D71C0051
	v_cndmask_b32_e32 v1, v81, v85, vcc_lo                     // 0000001A0D50: 0202AB51
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A0D54: BF8700A1
	v_cndmask_b32_e64 v81, 0, v81, s0                          // 0000001A0D58: D5010051 0002A280
	.long 0xd41e0000                                           // 0000001A0D60: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001A0D64: 020292FF 42B17218
	v_cndmask_b32_e64 v73, 0x7f800000, v81, s0                 // 0000001A0D6C: D5010049 0002A2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A0D78: 8C7E057E
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v106, 0            // 0000001A0D7C: CA100080 516A0080
	s_mov_b32 s5, exec_lo                                      // 0000001A0D84: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v109                         // 0000001A0D88: 7D22DAFF EFA18F08
	s_cbranch_execz 31                                         // 0000001A0D90: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd10>
	v_sub_f32_e32 v85, v109, v102                              // 0000001A0D94: 08AACD6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0D98: BF870091
	v_mul_f32_e32 v86, 0x3fb8aa3b, v85                         // 0000001A0D9C: 10ACAAFF 3FB8AA3B
	v_fma_f32 v104, 0x3fb8aa3b, v85, -v86                      // 0000001A0DA4: D6130068 855AAAFF 3FB8AA3B
	v_rndne_f32_e32 v106, v86                                  // 0000001A0DB0: 7ED44756
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A0DB4: BF870112
	v_fmac_f32_e32 v104, 0x32a5705f, v85                       // 0000001A0DB8: 56D0AAFF 32A5705F
	v_sub_f32_e32 v86, v86, v106                               // 0000001A0DC0: 08ACD556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A0DC4: BF8701B1
	v_add_f32_e32 v86, v86, v104                               // 0000001A0DC8: 06ACD156
	v_cvt_i32_f32_e32 v104, v106                               // 0000001A0DCC: 7ED0116A
	.long 0xd41b0000                                           // 0000001A0DD0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v85, vcc_lo              // 0000001A0DD4: 0202AAFF C2CE8ED0
	v_exp_f32_e32 v86, v86                                     // 0000001A0DDC: 7EAC4B56
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0DE0: BF870095
	.long 0xd71c0056                                           // 0000001A0DE4: D71C0056
	v_cndmask_b32_e32 v1, v86, v104, vcc_lo                    // 0000001A0DE8: 0202D156
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001A0DEC: D5010056 0002AC80
	.long 0xd41e0000                                           // 0000001A0DF4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v85, vcc_lo              // 0000001A0DF8: 0202AAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0E00: BF870001
	v_cndmask_b32_e64 v106, 0x7f800000, v86, s0                // 0000001A0E04: D501006A 0002ACFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A0E10: 8C7E057E
	v_mul_f32_e32 v74, 0x3d800000, v74                         // 0000001A0E14: 109494FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0E1C: BF870091
	v_cndmask_b32_e32 v85, 0xf149f2ca, v74, vcc_lo             // 0000001A0E20: 02AA94FF F149F2CA
	v_mov_b32_dpp v86, v85 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0E28: 7EAC02FA FF096155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0E30: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A0E34: 20ACAD56
	v_max_f32_e32 v85, v85, v86                                // 0000001A0E38: 20AAAD55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0E3C: BF870091
	v_mov_b32_dpp v86, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0E40: 7EAC02FA FF096255
	v_max_f32_e32 v86, v86, v86                                // 0000001A0E48: 20ACAD56
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0E4C: BF870091
	v_max_f32_e32 v85, v85, v86                                // 0000001A0E50: 20AAAD55
	v_mov_b32_dpp v86, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0E54: 7EAC02FA FF096455
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0E5C: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A0E60: 20ACAD56
	v_max_f32_e32 v85, v85, v86                                // 0000001A0E64: 20AAAD55
	v_bfe_u32 v86, v73, 16, 1                                  // 0000001A0E68: D6100056 02052149
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A0E70: BF870112
	v_mov_b32_dpp v104, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0E74: 7ED002FA FF096855
	v_add3_u32 v86, v73, v86, 0x7fff                           // 0000001A0E7C: D6550056 03FEAD49 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A0E88: BF870002
	v_max3_f32 v104, v111, v85, v104                           // 0000001A0E8C: D61C0068 05A2AB6F
	ds_store_b16_d16_hi v88, v86                               // 0000001A0E94: DA840000 00005658
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A0E9C: BE85206A
	s_cbranch_execz 31                                         // 0000001A0EA0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xe20>
	v_sub_f32_e32 v74, v74, v104                               // 0000001A0EA4: 0894D14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0EA8: BF870091
	v_mul_f32_e32 v81, 0x3fb8aa3b, v74                         // 0000001A0EAC: 10A294FF 3FB8AA3B
	v_fma_f32 v85, 0x3fb8aa3b, v74, -v81                       // 0000001A0EB4: D6130055 854694FF 3FB8AA3B
	v_rndne_f32_e32 v86, v81                                   // 0000001A0EC0: 7EAC4751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A0EC4: BF870191
	v_sub_f32_e32 v81, v81, v86                                // 0000001A0EC8: 08A2AD51
	v_fmac_f32_e32 v85, 0x32a5705f, v74                        // 0000001A0ECC: 56AA94FF 32A5705F
	.long 0xd41b0000                                           // 0000001A0ED4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001A0ED8: 020294FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A0EE0: BF870122
	v_add_f32_e32 v81, v81, v85                                // 0000001A0EE4: 06A2AB51
	v_cvt_i32_f32_e32 v85, v86                                 // 0000001A0EE8: 7EAA1156
	v_exp_f32_e32 v81, v81                                     // 0000001A0EEC: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0EF0: BF870095
	.long 0xd71c0051                                           // 0000001A0EF4: D71C0051
	v_cndmask_b32_e32 v1, v81, v85, vcc_lo                     // 0000001A0EF8: 0202AB51
	v_cndmask_b32_e64 v81, 0, v81, s0                          // 0000001A0EFC: D5010051 0002A280
	.long 0xd41e0000                                           // 0000001A0F04: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001A0F08: 020294FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0F10: BF870001
	v_cndmask_b32_e64 v81, 0x7f800000, v81, s0                 // 0000001A0F14: D5010051 0002A2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A0F20: 8C7E057E
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v109, 0            // 0000001A0F24: CA100080 4A6C0080
	s_mov_b32 s5, exec_lo                                      // 0000001A0F2C: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v111                         // 0000001A0F30: 7D22DEFF EFA18F08
	s_cbranch_execz 31                                         // 0000001A0F38: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xeb8>
	v_sub_f32_e32 v85, v111, v104                              // 0000001A0F3C: 08AAD16F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0F40: BF870091
	v_mul_f32_e32 v86, 0x3fb8aa3b, v85                         // 0000001A0F44: 10ACAAFF 3FB8AA3B
	v_fma_f32 v107, 0x3fb8aa3b, v85, -v86                      // 0000001A0F4C: D613006B 855AAAFF 3FB8AA3B
	v_rndne_f32_e32 v109, v86                                  // 0000001A0F58: 7EDA4756
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A0F5C: BF870191
	v_sub_f32_e32 v86, v86, v109                               // 0000001A0F60: 08ACDB56
	v_fmac_f32_e32 v107, 0x32a5705f, v85                       // 0000001A0F64: 56D6AAFF 32A5705F
	.long 0xd41b0000                                           // 0000001A0F6C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v85, vcc_lo              // 0000001A0F70: 0202AAFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A0F78: BF870122
	v_add_f32_e32 v86, v86, v107                               // 0000001A0F7C: 06ACD756
	v_cvt_i32_f32_e32 v107, v109                               // 0000001A0F80: 7ED6116D
	v_exp_f32_e32 v86, v86                                     // 0000001A0F84: 7EAC4B56
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0F88: BF870095
	.long 0xd71c0056                                           // 0000001A0F8C: D71C0056
	v_cndmask_b32_e32 v1, v86, v107, vcc_lo                    // 0000001A0F90: 0202D756
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001A0F94: D5010056 0002AC80
	.long 0xd41e0000                                           // 0000001A0F9C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v85, vcc_lo              // 0000001A0FA0: 0202AAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0FA8: BF870001
	v_cndmask_b32_e64 v109, 0x7f800000, v86, s0                // 0000001A0FAC: D501006D 0002ACFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A0FB8: 8C7E057E
	v_mul_f32_e32 v75, 0x3d800000, v75                         // 0000001A0FBC: 109696FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0FC4: BF870091
	v_cndmask_b32_e32 v85, 0xf149f2ca, v75, vcc_lo             // 0000001A0FC8: 02AA96FF F149F2CA
	v_mov_b32_dpp v86, v85 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0FD0: 7EAC02FA FF096155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0FD8: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A0FDC: 20ACAD56
	v_max_f32_e32 v85, v85, v86                                // 0000001A0FE0: 20AAAD55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0FE4: BF870091
	v_mov_b32_dpp v86, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0FE8: 7EAC02FA FF096255
	v_max_f32_e32 v86, v86, v86                                // 0000001A0FF0: 20ACAD56
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0FF4: BF870091
	v_max_f32_e32 v85, v85, v86                                // 0000001A0FF8: 20AAAD55
	v_mov_b32_dpp v86, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A0FFC: 7EAC02FA FF096455
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1004: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A1008: 20ACAD56
	v_max_f32_e32 v85, v85, v86                                // 0000001A100C: 20AAAD55
	v_bfe_u32 v86, v81, 16, 1                                  // 0000001A1010: D6100056 02052151
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1018: BF870112
	v_mov_b32_dpp v107, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A101C: 7ED602FA FF096855
	v_add3_u32 v86, v81, v86, 0x7fff                           // 0000001A1024: D6550056 03FEAD51 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A1030: BF870002
	v_max3_f32 v107, v113, v85, v107                           // 0000001A1034: D61C006B 05AEAB71
	ds_store_b16_d16_hi v88, v86 offset:64                     // 0000001A103C: DA840040 00005658
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A1044: BE85206A
	s_cbranch_execz 31                                         // 0000001A1048: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xfc8>
	v_sub_f32_e32 v74, v75, v107                               // 0000001A104C: 0894D74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1050: BF870121
	v_mul_f32_e32 v75, 0x3fb8aa3b, v74                         // 0000001A1054: 109694FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A105C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001A1060: 020294FF C2CE8ED0
	v_fma_f32 v85, 0x3fb8aa3b, v74, -v75                       // 0000001A1068: D6130055 852E94FF 3FB8AA3B
	v_rndne_f32_e32 v86, v75                                   // 0000001A1074: 7EAC474B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1078: BF870112
	v_fmac_f32_e32 v85, 0x32a5705f, v74                        // 0000001A107C: 56AA94FF 32A5705F
	v_sub_f32_e32 v75, v75, v86                                // 0000001A1084: 0896AD4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1088: BF870121
	v_add_f32_e32 v75, v75, v85                                // 0000001A108C: 0696AB4B
	v_cvt_i32_f32_e32 v85, v86                                 // 0000001A1090: 7EAA1156
	v_exp_f32_e32 v75, v75                                     // 0000001A1094: 7E964B4B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1098: BF870095
	.long 0xd71c004b                                           // 0000001A109C: D71C004B
	v_cndmask_b32_e32 v1, v75, v85, vcc_lo                     // 0000001A10A0: 0202AB4B
	v_cndmask_b32_e64 v75, 0, v75, s0                          // 0000001A10A4: D501004B 00029680
	.long 0xd41e0000                                           // 0000001A10AC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001A10B0: 020294FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A10B8: BF870001
	v_cndmask_b32_e64 v74, 0x7f800000, v75, s0                 // 0000001A10BC: D501004A 000296FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A10C8: 8C7E057E
	v_mov_b32_e32 v75, 0                                       // 0000001A10CC: 7E960280
	v_mov_b32_e32 v111, 0                                      // 0000001A10D0: 7EDE0280
	s_mov_b32 s5, exec_lo                                      // 0000001A10D4: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v113                         // 0000001A10D8: 7D22E2FF EFA18F08
	s_cbranch_execz 31                                         // 0000001A10E0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1060>
	v_sub_f32_e32 v85, v113, v107                              // 0000001A10E4: 08AAD771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A10E8: BF870091
	v_mul_f32_e32 v86, 0x3fb8aa3b, v85                         // 0000001A10EC: 10ACAAFF 3FB8AA3B
	v_fma_f32 v111, 0x3fb8aa3b, v85, -v86                      // 0000001A10F4: D613006F 855AAAFF 3FB8AA3B
	v_rndne_f32_e32 v113, v86                                  // 0000001A1100: 7EE24756
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A1104: BF870191
	v_sub_f32_e32 v86, v86, v113                               // 0000001A1108: 08ACE356
	v_fmac_f32_e32 v111, 0x32a5705f, v85                       // 0000001A110C: 56DEAAFF 32A5705F
	.long 0xd41b0000                                           // 0000001A1114: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v85, vcc_lo              // 0000001A1118: 0202AAFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1120: BF870122
	v_add_f32_e32 v86, v86, v111                               // 0000001A1124: 06ACDF56
	v_cvt_i32_f32_e32 v111, v113                               // 0000001A1128: 7EDE1171
	v_exp_f32_e32 v86, v86                                     // 0000001A112C: 7EAC4B56
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1130: BF870095
	.long 0xd71c0056                                           // 0000001A1134: D71C0056
	v_cndmask_b32_e32 v1, v86, v111, vcc_lo                    // 0000001A1138: 0202DF56
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001A113C: D5010056 0002AC80
	.long 0xd41e0000                                           // 0000001A1144: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v85, vcc_lo              // 0000001A1148: 0202AAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1150: BF870001
	v_cndmask_b32_e64 v111, 0x7f800000, v86, s0                // 0000001A1154: D501006F 0002ACFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A1160: 8C7E057E
	v_mul_f32_e32 v85, 0x3d800000, v76                         // 0000001A1164: 10AA98FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A116C: BF870091
	v_cndmask_b32_e32 v76, 0xf149f2ca, v85, vcc_lo             // 0000001A1170: 0298AAFF F149F2CA
	v_mov_b32_dpp v86, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1178: 7EAC02FA FF09614C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1180: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A1184: 20ACAD56
	v_max_f32_e32 v76, v76, v86                                // 0000001A1188: 2098AD4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A118C: BF870091
	v_mov_b32_dpp v86, v76 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1190: 7EAC02FA FF09624C
	v_max_f32_e32 v86, v86, v86                                // 0000001A1198: 20ACAD56
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A119C: BF870091
	v_max_f32_e32 v76, v76, v86                                // 0000001A11A0: 2098AD4C
	v_mov_b32_dpp v86, v76 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A11A4: 7EAC02FA FF09644C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A11AC: BF870091
	v_max_f32_e32 v86, v86, v86                                // 0000001A11B0: 20ACAD56
	v_max_f32_e32 v76, v76, v86                                // 0000001A11B4: 2098AD4C
	v_bfe_u32 v86, v74, 16, 1                                  // 0000001A11B8: D6100056 0205214A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A11C0: BF870112
	v_mov_b32_dpp v113, v76 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A11C4: 7EE202FA FF09684C
	v_add3_u32 v86, v74, v86, 0x7fff                           // 0000001A11CC: D6550056 03FEAD4A 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A11D8: BF870002
	v_max3_f32 v76, v112, v76, v113                            // 0000001A11DC: D61C004C 05C69970
	ds_store_b16_d16_hi v88, v86 offset:128                    // 0000001A11E4: DA840080 00005658
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A11EC: BE85206A
	s_cbranch_execz 30                                         // 0000001A11F0: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x116c>
	v_sub_f32_e32 v75, v85, v76                                // 0000001A11F4: 08969955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A11F8: BF870121
	v_mul_f32_e32 v85, 0x3fb8aa3b, v75                         // 0000001A11FC: 10AA96FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A1204: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 0000001A1208: 020296FF C2CE8ED0
	v_fma_f32 v86, 0x3fb8aa3b, v75, -v85                       // 0000001A1210: D6130056 855696FF 3FB8AA3B
	v_rndne_f32_e32 v113, v85                                  // 0000001A121C: 7EE24755
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1220: BF870091
	v_dual_fmac_f32 v86, 0x32a5705f, v75 :: v_dual_sub_f32 v85, v85, v113// 0000001A1224: C80A96FF 5654E355 32A5705F
	v_add_f32_e32 v85, v85, v86                                // 0000001A1230: 06AAAD55
	v_cvt_i32_f32_e32 v86, v113                                // 0000001A1234: 7EAC1171
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A1238: BF870292
	v_exp_f32_e32 v85, v85                                     // 0000001A123C: 7EAA4B55
	.long 0xd71c0055                                           // 0000001A1240: D71C0055
	v_cndmask_b32_e32 v1, v85, v86, vcc_lo                     // 0000001A1244: 0202AD55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1248: BF8700A1
	v_cndmask_b32_e64 v85, 0, v85, s0                          // 0000001A124C: D5010055 0002AA80
	.long 0xd41e0000                                           // 0000001A1254: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 0000001A1258: 020296FF 42B17218
	v_cndmask_b32_e64 v75, 0x7f800000, v85, s0                 // 0000001A1260: D501004B 0002AAFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A126C: 8C7E057E
	v_mov_b32_e32 v85, 0                                       // 0000001A1270: 7EAA0280
	v_mov_b32_e32 v113, 0                                      // 0000001A1274: 7EE20280
	s_mov_b32 s5, exec_lo                                      // 0000001A1278: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v112                         // 0000001A127C: 7D22E0FF EFA18F08
	s_cbranch_execz 31                                         // 0000001A1284: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1204>
	v_sub_f32_e32 v86, v112, v76                               // 0000001A1288: 08AC9970
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A128C: BF870121
	v_mul_f32_e32 v112, 0x3fb8aa3b, v86                        // 0000001A1290: 10E0ACFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A1298: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v86, vcc_lo              // 0000001A129C: 0202ACFF C2CE8ED0
	v_fma_f32 v113, 0x3fb8aa3b, v86, -v112                     // 0000001A12A4: D6130071 85C2ACFF 3FB8AA3B
	v_rndne_f32_e32 v114, v112                                 // 0000001A12B0: 7EE44770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A12B4: BF870112
	v_fmac_f32_e32 v113, 0x32a5705f, v86                       // 0000001A12B8: 56E2ACFF 32A5705F
	v_sub_f32_e32 v112, v112, v114                             // 0000001A12C0: 08E0E570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A12C4: BF870121
	v_add_f32_e32 v112, v112, v113                             // 0000001A12C8: 06E0E370
	v_cvt_i32_f32_e32 v113, v114                               // 0000001A12CC: 7EE21172
	v_exp_f32_e32 v112, v112                                   // 0000001A12D0: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A12D4: BF870095
	.long 0xd71c0070                                           // 0000001A12D8: D71C0070
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                   // 0000001A12DC: 0202E370
	v_cndmask_b32_e64 v112, 0, v112, s0                        // 0000001A12E0: D5010070 0002E080
	.long 0xd41e0000                                           // 0000001A12E8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v86, vcc_lo              // 0000001A12EC: 0202ACFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A12F4: BF870001
	v_cndmask_b32_e64 v113, 0x7f800000, v112, s0               // 0000001A12F8: D5010071 0002E0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A1304: 8C7E057E
	v_mul_f32_e32 v86, 0x3d800000, v77                         // 0000001A1308: 10AC9AFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1310: BF870091
	v_cndmask_b32_e32 v77, 0xf149f2ca, v86, vcc_lo             // 0000001A1314: 029AACFF F149F2CA
	v_mov_b32_dpp v112, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A131C: 7EE002FA FF09614D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1324: BF870091
	v_max_f32_e32 v112, v112, v112                             // 0000001A1328: 20E0E170
	v_max_f32_e32 v77, v77, v112                               // 0000001A132C: 209AE14D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1330: BF870091
	v_mov_b32_dpp v112, v77 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1334: 7EE002FA FF09624D
	v_max_f32_e32 v112, v112, v112                             // 0000001A133C: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1340: BF870091
	v_max_f32_e32 v77, v77, v112                               // 0000001A1344: 209AE14D
	v_mov_b32_dpp v112, v77 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1348: 7EE002FA FF09644D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1350: BF870091
	v_max_f32_e32 v112, v112, v112                             // 0000001A1354: 20E0E170
	v_max_f32_e32 v77, v77, v112                               // 0000001A1358: 209AE14D
	v_bfe_u32 v112, v75, 16, 1                                 // 0000001A135C: D6100070 0205214B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1364: BF870112
	v_mov_b32_dpp v114, v77 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1368: 7EE402FA FF09684D
	v_add3_u32 v112, v75, v112, 0x7fff                         // 0000001A1370: D6550070 03FEE14B 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A137C: BF870002
	v_max3_f32 v77, v110, v77, v114                            // 0000001A1380: D61C004D 05CA9B6E
	ds_store_b16_d16_hi v88, v112 offset:192                   // 0000001A1388: DA8400C0 00007058
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A1390: BE85206A
	s_cbranch_execz 31                                         // 0000001A1394: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1314>
	v_sub_f32_e32 v85, v86, v77                                // 0000001A1398: 08AA9B56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A139C: BF870121
	v_mul_f32_e32 v86, 0x3fb8aa3b, v85                         // 0000001A13A0: 10ACAAFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A13A8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v85, vcc_lo              // 0000001A13AC: 0202AAFF C2CE8ED0
	v_fma_f32 v112, 0x3fb8aa3b, v85, -v86                      // 0000001A13B4: D6130070 855AAAFF 3FB8AA3B
	v_rndne_f32_e32 v114, v86                                  // 0000001A13C0: 7EE44756
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A13C4: BF870112
	v_fmac_f32_e32 v112, 0x32a5705f, v85                       // 0000001A13C8: 56E0AAFF 32A5705F
	v_sub_f32_e32 v86, v86, v114                               // 0000001A13D0: 08ACE556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A13D4: BF870121
	v_add_f32_e32 v86, v86, v112                               // 0000001A13D8: 06ACE156
	v_cvt_i32_f32_e32 v112, v114                               // 0000001A13DC: 7EE01172
	v_exp_f32_e32 v86, v86                                     // 0000001A13E0: 7EAC4B56
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A13E4: BF870095
	.long 0xd71c0056                                           // 0000001A13E8: D71C0056
	v_cndmask_b32_e32 v1, v86, v112, vcc_lo                    // 0000001A13EC: 0202E156
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001A13F0: D5010056 0002AC80
	.long 0xd41e0000                                           // 0000001A13F8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v85, vcc_lo              // 0000001A13FC: 0202AAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1404: BF870001
	v_cndmask_b32_e64 v85, 0x7f800000, v86, s0                 // 0000001A1408: D5010055 0002ACFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A1414: 8C7E057E
	v_mov_b32_e32 v86, 0                                       // 0000001A1418: 7EAC0280
	v_mov_b32_e32 v112, 0                                      // 0000001A141C: 7EE00280
	s_mov_b32 s5, exec_lo                                      // 0000001A1420: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v110                         // 0000001A1424: 7D22DCFF EFA18F08
	s_cbranch_execz 31                                         // 0000001A142C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x13ac>
	v_sub_f32_e32 v110, v110, v77                              // 0000001A1430: 08DC9B6E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1434: BF870121
	v_mul_f32_e32 v112, 0x3fb8aa3b, v110                       // 0000001A1438: 10E0DCFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A1440: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v110, vcc_lo             // 0000001A1444: 0202DCFF C2CE8ED0
	v_fma_f32 v114, 0x3fb8aa3b, v110, -v112                    // 0000001A144C: D6130072 85C2DCFF 3FB8AA3B
	v_rndne_f32_e32 v115, v112                                 // 0000001A1458: 7EE64770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A145C: BF870112
	v_fmac_f32_e32 v114, 0x32a5705f, v110                      // 0000001A1460: 56E4DCFF 32A5705F
	v_sub_f32_e32 v112, v112, v115                             // 0000001A1468: 08E0E770
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A146C: BF870121
	v_add_f32_e32 v112, v112, v114                             // 0000001A1470: 06E0E570
	v_cvt_i32_f32_e32 v114, v115                               // 0000001A1474: 7EE41173
	v_exp_f32_e32 v112, v112                                   // 0000001A1478: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A147C: BF870095
	.long 0xd71c0070                                           // 0000001A1480: D71C0070
	v_cndmask_b32_e32 v1, v112, v114, vcc_lo                   // 0000001A1484: 0202E570
	v_cndmask_b32_e64 v112, 0, v112, s0                        // 0000001A1488: D5010070 0002E080
	.long 0xd41e0000                                           // 0000001A1490: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v110, vcc_lo             // 0000001A1494: 0202DCFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A149C: BF870001
	v_cndmask_b32_e64 v112, 0x7f800000, v112, s0               // 0000001A14A0: D5010070 0002E0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A14AC: 8C7E057E
	v_mul_f32_e32 v110, 0x3d800000, v78                        // 0000001A14B0: 10DC9CFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A14B8: BF870091
	v_cndmask_b32_e32 v78, 0xf149f2ca, v110, vcc_lo            // 0000001A14BC: 029CDCFF F149F2CA
	v_mov_b32_dpp v114, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A14C4: 7EE402FA FF09614E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A14CC: BF870091
	v_max_f32_e32 v114, v114, v114                             // 0000001A14D0: 20E4E572
	v_max_f32_e32 v78, v78, v114                               // 0000001A14D4: 209CE54E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A14D8: BF870091
	v_mov_b32_dpp v114, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A14DC: 7EE402FA FF09624E
	v_max_f32_e32 v114, v114, v114                             // 0000001A14E4: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A14E8: BF870091
	v_max_f32_e32 v78, v78, v114                               // 0000001A14EC: 209CE54E
	v_mov_b32_dpp v114, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A14F0: 7EE402FA FF09644E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A14F8: BF870091
	v_max_f32_e32 v114, v114, v114                             // 0000001A14FC: 20E4E572
	v_max_f32_e32 v78, v78, v114                               // 0000001A1500: 209CE54E
	v_bfe_u32 v114, v85, 16, 1                                 // 0000001A1504: D6100072 02052155
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A150C: BF870112
	v_mov_b32_dpp v115, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1510: 7EE602FA FF09684E
	v_add3_u32 v114, v85, v114, 0x7fff                         // 0000001A1518: D6550072 03FEE555 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A1524: BF870002
	v_max3_f32 v78, v108, v78, v115                            // 0000001A1528: D61C004E 05CE9D6C
	ds_store_b16_d16_hi v88, v114 offset:256                   // 0000001A1530: DA840100 00007258
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A1538: BE85206A
	s_cbranch_execz 31                                         // 0000001A153C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x14bc>
	v_sub_f32_e32 v86, v110, v78                               // 0000001A1540: 08AC9D6E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1544: BF870121
	v_mul_f32_e32 v110, 0x3fb8aa3b, v86                        // 0000001A1548: 10DCACFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A1550: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v86, vcc_lo              // 0000001A1554: 0202ACFF C2CE8ED0
	v_fma_f32 v114, 0x3fb8aa3b, v86, -v110                     // 0000001A155C: D6130072 85BAACFF 3FB8AA3B
	v_rndne_f32_e32 v115, v110                                 // 0000001A1568: 7EE6476E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A156C: BF870112
	v_fmac_f32_e32 v114, 0x32a5705f, v86                       // 0000001A1570: 56E4ACFF 32A5705F
	v_sub_f32_e32 v110, v110, v115                             // 0000001A1578: 08DCE76E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A157C: BF870121
	v_add_f32_e32 v110, v110, v114                             // 0000001A1580: 06DCE56E
	v_cvt_i32_f32_e32 v114, v115                               // 0000001A1584: 7EE41173
	v_exp_f32_e32 v110, v110                                   // 0000001A1588: 7EDC4B6E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A158C: BF870095
	.long 0xd71c006e                                           // 0000001A1590: D71C006E
	v_cndmask_b32_e32 v1, v110, v114, vcc_lo                   // 0000001A1594: 0202E56E
	v_cndmask_b32_e64 v110, 0, v110, s0                        // 0000001A1598: D501006E 0002DC80
	.long 0xd41e0000                                           // 0000001A15A0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v86, vcc_lo              // 0000001A15A4: 0202ACFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A15AC: BF870001
	v_cndmask_b32_e64 v86, 0x7f800000, v110, s0                // 0000001A15B0: D5010056 0002DCFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A15BC: 8C7E057E
	v_mov_b32_e32 v114, 0                                      // 0000001A15C0: 7EE40280
	v_mov_b32_e32 v110, 0                                      // 0000001A15C4: 7EDC0280
	s_mov_b32 s5, exec_lo                                      // 0000001A15C8: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v108                         // 0000001A15CC: 7D22D8FF EFA18F08
	s_cbranch_execz 31                                         // 0000001A15D4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1554>
	v_sub_f32_e32 v108, v108, v78                              // 0000001A15D8: 08D89D6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A15DC: BF870121
	v_mul_f32_e32 v110, 0x3fb8aa3b, v108                       // 0000001A15E0: 10DCD8FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A15E8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v108, vcc_lo             // 0000001A15EC: 0202D8FF C2CE8ED0
	v_fma_f32 v115, 0x3fb8aa3b, v108, -v110                    // 0000001A15F4: D6130073 85BAD8FF 3FB8AA3B
	v_rndne_f32_e32 v116, v110                                 // 0000001A1600: 7EE8476E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1604: BF870112
	v_fmac_f32_e32 v115, 0x32a5705f, v108                      // 0000001A1608: 56E6D8FF 32A5705F
	v_sub_f32_e32 v110, v110, v116                             // 0000001A1610: 08DCE96E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1614: BF870121
	v_add_f32_e32 v110, v110, v115                             // 0000001A1618: 06DCE76E
	v_cvt_i32_f32_e32 v115, v116                               // 0000001A161C: 7EE61174
	v_exp_f32_e32 v110, v110                                   // 0000001A1620: 7EDC4B6E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1624: BF870095
	.long 0xd71c006e                                           // 0000001A1628: D71C006E
	v_cndmask_b32_e32 v1, v110, v115, vcc_lo                   // 0000001A162C: 0202E76E
	v_cndmask_b32_e64 v110, 0, v110, s0                        // 0000001A1630: D501006E 0002DC80
	.long 0xd41e0000                                           // 0000001A1638: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v108, vcc_lo             // 0000001A163C: 0202D8FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1644: BF870001
	v_cndmask_b32_e64 v110, 0x7f800000, v110, s0               // 0000001A1648: D501006E 0002DCFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A1654: 8C7E057E
	v_mul_f32_e32 v108, 0x3d800000, v79                        // 0000001A1658: 10D89EFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1660: BF870091
	v_cndmask_b32_e32 v79, 0xf149f2ca, v108, vcc_lo            // 0000001A1664: 029ED8FF F149F2CA
	v_mov_b32_dpp v115, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A166C: 7EE602FA FF09614F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1674: BF870091
	v_max_f32_e32 v115, v115, v115                             // 0000001A1678: 20E6E773
	v_max_f32_e32 v79, v79, v115                               // 0000001A167C: 209EE74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1680: BF870091
	v_mov_b32_dpp v115, v79 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1684: 7EE602FA FF09624F
	v_max_f32_e32 v115, v115, v115                             // 0000001A168C: 20E6E773
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1690: BF870091
	v_max_f32_e32 v79, v79, v115                               // 0000001A1694: 209EE74F
	v_mov_b32_dpp v115, v79 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1698: 7EE602FA FF09644F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A16A0: BF870091
	v_max_f32_e32 v115, v115, v115                             // 0000001A16A4: 20E6E773
	v_max_f32_e32 v79, v79, v115                               // 0000001A16A8: 209EE74F
	v_bfe_u32 v115, v86, 16, 1                                 // 0000001A16AC: D6100073 02052156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A16B4: BF870112
	v_mov_b32_dpp v116, v79 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A16B8: 7EE802FA FF09684F
	v_add3_u32 v115, v86, v115, 0x7fff                         // 0000001A16C0: D6550073 03FEE756 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A16CC: BF870002
	v_max3_f32 v79, v105, v79, v116                            // 0000001A16D0: D61C004F 05D29F69
	ds_store_b16_d16_hi v88, v115 offset:320                   // 0000001A16D8: DA840140 00007358
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001A16E0: BE85206A
	s_cbranch_execz 31                                         // 0000001A16E4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1664>
	v_sub_f32_e32 v108, v108, v79                              // 0000001A16E8: 08D89F6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A16EC: BF870121
	v_mul_f32_e32 v114, 0x3fb8aa3b, v108                       // 0000001A16F0: 10E4D8FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001A16F8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v108, vcc_lo             // 0000001A16FC: 0202D8FF C2CE8ED0
	v_fma_f32 v115, 0x3fb8aa3b, v108, -v114                    // 0000001A1704: D6130073 85CAD8FF 3FB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000001A1710: 7EE84772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1714: BF870112
	v_fmac_f32_e32 v115, 0x32a5705f, v108                      // 0000001A1718: 56E6D8FF 32A5705F
	v_sub_f32_e32 v114, v114, v116                             // 0000001A1720: 08E4E972
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1724: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001A1728: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000001A172C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000001A1730: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1734: BF870095
	.long 0xd71c0072                                           // 0000001A1738: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001A173C: 0202E772
	v_cndmask_b32_e64 v114, 0, v114, s0                        // 0000001A1740: D5010072 0002E480
	.long 0xd41e0000                                           // 0000001A1748: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v108, vcc_lo             // 0000001A174C: 0202D8FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1754: BF870001
	v_cndmask_b32_e64 v114, 0x7f800000, v114, s0               // 0000001A1758: D5010072 0002E4FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A1764: 8C7E057E
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v108, 0           // 0000001A1768: CA100080 736C0080
	s_mov_b32 s5, exec_lo                                      // 0000001A1770: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v105                         // 0000001A1774: 7D22D2FF EFA18F08
	s_cbranch_execz 31                                         // 0000001A177C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16fc>
	v_sub_f32_e32 v105, v105, v79                              // 0000001A1780: 08D29F69
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1784: BF870091
	v_mul_f32_e32 v108, 0x3fb8aa3b, v105                       // 0000001A1788: 10D8D2FF 3FB8AA3B
	v_fma_f32 v116, 0x3fb8aa3b, v105, -v108                    // 0000001A1790: D6130074 85B2D2FF 3FB8AA3B
	v_rndne_f32_e32 v117, v108                                 // 0000001A179C: 7EEA476C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A17A0: BF870191
	v_sub_f32_e32 v108, v108, v117                             // 0000001A17A4: 08D8EB6C
	v_fmac_f32_e32 v116, 0x32a5705f, v105                      // 0000001A17A8: 56E8D2FF 32A5705F
	.long 0xd41b0000                                           // 0000001A17B0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v105, vcc_lo             // 0000001A17B4: 0202D2FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A17BC: BF870122
	v_add_f32_e32 v108, v108, v116                             // 0000001A17C0: 06D8E96C
	v_cvt_i32_f32_e32 v116, v117                               // 0000001A17C4: 7EE81175
	v_exp_f32_e32 v108, v108                                   // 0000001A17C8: 7ED84B6C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A17CC: BF870095
	.long 0xd71c006c                                           // 0000001A17D0: D71C006C
	v_cndmask_b32_e32 v1, v108, v116, vcc_lo                   // 0000001A17D4: 0202E96C
	v_cndmask_b32_e64 v108, 0, v108, s0                        // 0000001A17D8: D501006C 0002D880
	.long 0xd41e0000                                           // 0000001A17E0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v105, vcc_lo             // 0000001A17E4: 0202D2FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A17EC: BF870001
	v_cndmask_b32_e64 v108, 0x7f800000, v108, s0               // 0000001A17F0: D501006C 0002D8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001A17FC: 8C7E057E
	v_mul_f32_e32 v105, 0x3d800000, v80                        // 0000001A1800: 10D2A0FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1808: BF870091
	v_cndmask_b32_e32 v80, 0xf149f2ca, v105, vcc_lo            // 0000001A180C: 02A0D2FF F149F2CA
	v_mov_b32_dpp v116, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1814: 7EE802FA FF096150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A181C: BF870091
	v_max_f32_e32 v116, v116, v116                             // 0000001A1820: 20E8E974
	v_max_f32_e32 v80, v80, v116                               // 0000001A1824: 20A0E950
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1828: BF870091
	v_mov_b32_dpp v116, v80 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A182C: 7EE802FA FF096250
	v_max_f32_e32 v116, v116, v116                             // 0000001A1834: 20E8E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1838: BF870091
	v_max_f32_e32 v80, v80, v116                               // 0000001A183C: 20A0E950
	v_mov_b32_dpp v116, v80 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1840: 7EE802FA FF096450
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1848: BF870091
	v_max_f32_e32 v116, v116, v116                             // 0000001A184C: 20E8E974
	v_max_f32_e32 v80, v80, v116                               // 0000001A1850: 20A0E950
	v_bfe_u32 v116, v114, 16, 1                                // 0000001A1854: D6100074 02052172
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A185C: BF870112
	v_mov_b32_dpp v117, v80 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1860: 7EEA02FA FF096850
	v_add3_u32 v116, v114, v116, 0x7fff                        // 0000001A1868: D6550074 03FEE972 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A1874: BF870002
	v_max3_f32 v80, v103, v80, v117                            // 0000001A1878: D61C0050 05D6A167
	ds_store_b16_d16_hi v88, v116 offset:384                   // 0000001A1880: DA840180 00007458
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001A1888: BE80206A
	s_cbranch_execz 27                                         // 0000001A188C: BFA5001B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x17fc>
	v_sub_f32_e32 v105, v105, v80                              // 0000001A1890: 08D2A169
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1894: BF870121
	v_mul_f32_e32 v115, 0x3fb8aa3b, v105                       // 0000001A1898: 10E6D2FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v105                 // 0000001A18A0: 7C36D2FF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v105, -v115                    // 0000001A18A8: D6130074 85CED2FF 3FB8AA3B
	v_rndne_f32_e32 v117, v115                                 // 0000001A18B4: 7EEA4773
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A18B8: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v105                      // 0000001A18BC: 56E8D2FF 32A5705F
	v_sub_f32_e32 v115, v115, v117                             // 0000001A18C4: 08E6EB73
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A18C8: BF870121
	v_add_f32_e32 v115, v115, v116                             // 0000001A18CC: 06E6E973
	v_cvt_i32_f32_e32 v116, v117                               // 0000001A18D0: 7EE81175
	v_exp_f32_e32 v115, v115                                   // 0000001A18D4: 7EE64B73
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A18D8: BF870095
	.long 0xd71c0073                                           // 0000001A18DC: D71C0073
	v_cndmask_b32_e32 v1, v115, v116, vcc_lo                   // 0000001A18E0: 0202E973
	v_cndmask_b32_e32 v115, 0, v115, vcc_lo                    // 0000001A18E4: 02E6E680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v105                 // 0000001A18E8: 7C3CD2FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A18F0: BF870002
	v_cndmask_b32_e32 v115, 0x7f800000, v115, vcc_lo           // 0000001A18F4: 02E6E6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A18FC: 8C7E007E
	v_mov_b32_e32 v105, 0                                      // 0000001A1900: 7ED20280
	s_mov_b32 s0, exec_lo                                      // 0000001A1904: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v103                         // 0000001A1908: 7D22CEFF EFA18F08
	s_cbranch_execz 64370                                      // 0000001A1910: BFA5FB72 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5dc>
	v_sub_f32_e32 v103, v103, v80                              // 0000001A1914: 08CEA167
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1918: BF870121
	v_mul_f32_e32 v105, 0x3fb8aa3b, v103                       // 0000001A191C: 10D2CEFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v103                 // 0000001A1924: 7C36CEFF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v103, -v105                    // 0000001A192C: D6130074 85A6CEFF 3FB8AA3B
	v_rndne_f32_e32 v117, v105                                 // 0000001A1938: 7EEA4769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A193C: BF870091
	v_dual_fmac_f32 v116, 0x32a5705f, v103 :: v_dual_sub_f32 v105, v105, v117// 0000001A1940: C80ACEFF 7468EB69 32A5705F
	v_add_f32_e32 v105, v105, v116                             // 0000001A194C: 06D2E969
	v_cvt_i32_f32_e32 v116, v117                               // 0000001A1950: 7EE81175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A1954: BF870292
	v_exp_f32_e32 v105, v105                                   // 0000001A1958: 7ED24B69
	.long 0xd71c0069                                           // 0000001A195C: D71C0069
	v_cndmask_b32_e32 v1, v105, v116, vcc_lo                   // 0000001A1960: 0202E969
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A1964: BF870121
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001A1968: 02D2D280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v103                 // 0000001A196C: 7C3CCEFF 42B17218
	v_cndmask_b32_e32 v105, 0x7f800000, v105, vcc_lo           // 0000001A1974: 02D2D2FF 7F800000
	s_branch 64343                                             // 0000001A197C: BFA0FB57 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi8ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5dc>
	v_mov_b32_e32 v8, v84                                      // 0000001A1980: 7E100354
	s_mul_i32 s0, s20, 12                                      // 0000001A1984: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1988: BF870001
	v_or_b32_e32 v7, v8, v82                                   // 0000001A198C: 380EA508
	v_or_b32_e32 v0, s0, v83                                   // 0000001A1990: 3800A600
	v_mov_b32_dpp v78, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1994: 7E9C02FA FF09614B
	v_mov_b32_dpp v77, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A199C: 7E9A02FA FF09614A
	v_mov_b32_dpp v83, v85 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A19A4: 7EA602FA FF096155
	v_mov_b32_dpp v84, v86 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A19AC: 7EA802FA FF096156
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001A19B4: 30000088
	v_mov_b32_e32 v8, 0                                        // 0000001A19B8: 7E100280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A19BC: BF870214
	v_dual_add_f32 v78, v75, v78 :: v_dual_add_f32 v83, v85, v83// 0000001A19C0: C9089D4B 4E52A755
	v_add_f32_e32 v84, v86, v84                                // 0000001A19C8: 06A8A956
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A19CC: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001A19D0: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001A19D8: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001A19E4: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001A19E8: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001A19F0: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001A19F8: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001A19FC: 388200FF 00000200
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1A04: 06A6A6FA FF096253
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001A1A0C: 34403E9F
	.long 0xd7006a0f                                           // 0000001A1A10: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001A1A14: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1A18: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001A1A1C: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001A1A24: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001A1A28: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001A1A2C: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A1A34: BF870233
	.long 0xd73c000f                                           // 0000001A1A38: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001A1A3C: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001A1A40: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001A1A48: 34504E9F
	.long 0xd73c0017                                           // 0000001A1A4C: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001A1A50: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001A1A54: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1A58: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001A1A60: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001A1A64: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1A68: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001A1A6C: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001A1A74: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001A1A78: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001A1A7C: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001A1A84: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001A1A88: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001A1A8C: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001A1A90: BF8700B3
	.long 0xd73c001f                                           // 0000001A1A94: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001A1A98: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 0000001A1A9C: D5207C38 01AA300B
	.long 0xd7006a27                                           // 0000001A1AA4: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001A1AA8: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001A1AAC: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001A1AB4: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001A1AB8: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1ABC: BF8700A1
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001A1AC0: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001A1AC8: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000001A1ACC: 02023E0A
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001A1AD0: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001A1AD8: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001A1ADC: 02028307
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1AE0: BF870001
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001A1AE4: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001A1AEC: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001A1AF0: 02024E81
	.long 0xd73c002f                                           // 0000001A1AF4: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001A1AF8: 02025E81
	s_clause 0x2                                               // 0000001A1AFC: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001A1B00: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001A1B08: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001A1B10: DC4A0040 677C0045
	.long 0xd73c0068                                           // 0000001A1B18: D73C0068
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001A1B1C: 02020E81
	global_load_u16 v76, v[69:70], off offset:1024             // 0000001A1B20: DC4A0400 4C7C0045
	v_mov_b32_dpp v7, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1B28: 7E0E02FA FF096149
	.long 0xd7006a43                                           // 0000001A1B30: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001A1B34: 02024E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1B38: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001A1B3C: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001A1B44: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001A1B48: 02025E0A
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001A1B4C: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001A1B54: D7006A47
	v_cndmask_b32_e32 v1, s10, v104, vcc_lo                    // 0000001A1B58: 0202D00A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1B5C: BF870001
	v_add_co_ci_u32_e64 v72, null, s11, v105, vcc_lo           // 0000001A1B60: D5207C48 01AAD20B
	s_clause 0x9                                               // 0000001A1B68: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001A1B6C: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001A1B74: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001A1B7C: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001A1B84: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001A1B8C: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001A1B94: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001A1B9C: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001A1BA4: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001A1BAC: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001A1BB4: DC4A0040 617C0047
	v_mov_b32_dpp v8, v81 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BBC: 7E1002FA FF096151
	v_add_f32_e32 v7, v73, v7                                  // 0000001A1BC4: 060E0F49
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BC8: 06A8A8FA FF096254
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BD0: 06A6A6FA FF096453
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BD8: 069C9CFA FF09644E
	v_add_f32_e32 v8, v81, v8                                  // 0000001A1BE0: 06101151
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BE4: 060E0EFA FF096207
	v_add_f32_e32 v81, v74, v77                                // 0000001A1BEC: 06A29B4A
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BF0: 06A8A8FA FF096454
	v_add_f32_dpp v83, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1BF8: 06A6A6FA FF096853
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C00: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C08: 060E0EFA FF096407
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C10: 06A2A2FA FF096251
	v_add_f32_dpp v88, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C18: 06B09CFA FF09684E
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001A1C20: D6FC7C6F 03CAA753
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C28: 061010FA FF096408
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C30: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001A1C38: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001A1C3C: 02021E0C
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C40: 06A2A2FA FF096451
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A1C48: BF870214
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1C4C: 06D610FA FF096808
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001A1C54: D6FC7C75 03CAD96C
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001A1C5C: D5207C08 0016200D
	.long 0xd700050f                                           // 0000001A1C64: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001A1C68: 02022E0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A1C6C: BF870214
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001A1C70: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v122, v117                                   // 0000001A1C78: 7EF45575
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001A1C7C: D5207C10 0016300D
	.long 0xd7000517                                           // 0000001A1C84: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001A1C88: 02023E0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001A1C8C: BF8700B3
	v_rcp_f32_e32 v121, v118                                   // 0000001A1C90: 7EF25576
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001A1C94: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001A1C9C: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001A1CA0: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001A1CA4: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001A1CAC: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001A1CB0: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1CB4: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001A1CB8: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001A1CC0: D700052F
	v_cndmask_b32_e32 v1, s12, v104, vcc_lo                    // 0000001A1CC4: 0202D00C
	v_add_co_ci_u32_e64 v48, null, s13, v105, s5               // 0000001A1CC8: D5207C30 0016D20D
	s_clause 0x1f                                              // 0000001A1CD0: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001A1CD4: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001A1CDC: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001A1CE4: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001A1CEC: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001A1CF4: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001A1CFC: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001A1D04: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001A1D0C: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001A1D14: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001A1D1C: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001A1D24: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001A1D2C: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001A1D34: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001A1D3C: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001A1D44: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001A1D4C: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001A1D54: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001A1D5C: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001A1D64: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001A1D6C: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001A1D74: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001A1D7C: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001A1D84: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001A1D8C: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001A1D94: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001A1D9C: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001A1DA4: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001A1DAC: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001A1DB4: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001A1DBC: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001A1DC4: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001A1DCC: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001A1DD4: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001A1DD8: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001A1DE0: DC4A00E0 407C0041
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001A1DE8: D6130041 23CAF575
	v_add_f32_dpp v89, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1DF0: 06B2A2FA FF096851
	v_add_f32_dpp v81, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001A1DF8: 06A2A8FA FF096854
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001A1E00: D6130042 23CAF376
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001A1E08: D6FC6A77 03CAD8F2
	v_fmac_f32_e32 v122, v65, v122                             // 0000001A1E10: 56F4F541
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001A1E14: D6FC0478 03CAD6F2
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001A1E1C: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001A1E24: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001A1E2C: D6FC7C73 03CAA351
	v_rcp_f32_e32 v85, v111                                    // 0000001A1E34: 7EAA556F
	v_fmac_f32_e32 v121, v66, v121                             // 0000001A1E38: 56F2F342
	v_mul_f32_e32 v65, v119, v122                              // 0000001A1E3C: 1082F577
	v_rcp_f32_e32 v91, v109                                    // 0000001A1E40: 7EB6556D
	v_rcp_f32_e32 v90, v110                                    // 0000001A1E44: 7EB4556E
	v_rcp_f32_e32 v84, v115                                    // 0000001A1E48: 7EA85573
	v_mul_f32_e32 v66, v120, v121                              // 0000001A1E4C: 1084F378
	v_fma_f32 v144, -v117, v65, v119                           // 0000001A1E50: D6130090 25DE8375
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001A1E58: D6FC0072 03CAA6F2
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001A1E60: D6FC0270 03CAB2F2
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001A1E68: D613008E 23CAAB6F
	v_fma_f32 v145, -v118, v66, v120                           // 0000001A1E70: D6130091 25E28576
	v_fmac_f32_e32 v65, v144, v122                             // 0000001A1E78: 5682F590
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001A1E7C: D6130047 23CAB76D
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001A1E84: D6130048 23CAB56E
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001A1E8C: D613008F 23CAA973
	v_fmac_f32_e32 v85, v142, v85                              // 0000001A1E94: 56AAAB8E
	v_fmac_f32_e32 v66, v145, v121                             // 0000001A1E98: 5684F391
	v_fma_f32 v117, -v117, v65, v119                           // 0000001A1E9C: D6130075 25DE8375
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001A1EA4: D6FC0371 03CAB0F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001A1EAC: D6FC0174 03CAA2F2
	v_dual_fmac_f32 v91, v71, v91 :: v_dual_fmac_f32 v90, v72, v90// 0000001A1EB4: C800B747 5B5AB548
	v_fmac_f32_e32 v84, v143, v84                              // 0000001A1EBC: 56A8A98F
	v_mul_f32_e32 v142, v114, v85                              // 0000001A1EC0: 111CAB72
	v_fma_f32 v118, -v118, v66, v120                           // 0000001A1EC4: D6130076 25E28576
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001A1ECC: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001A1ED4: BEEA0004
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001A1ED8: C8C6B770 4748B571
	v_mul_f32_e32 v143, v116, v84                              // 0000001A1EE0: 111EA974
	v_fma_f32 v148, -v111, v142, v114                          // 0000001A1EE4: D6130094 25CB1D6F
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001A1EEC: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A1EF4: BF870004
	v_fma_f32 v146, -v109, v71, v112                           // 0000001A1EF8: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001A1F00: D6130093 25C6916E
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001A1F08: D6270042 03CAD941
	v_fmac_f32_e32 v142, v148, v85                             // 0000001A1F10: 571CAB94
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001A1F14: D6270041 03CAD775
	v_fma_f32 v144, -v115, v143, v116                          // 0000001A1F1C: D6130090 25D31F73
	v_dual_fmac_f32 v71, v146, v91 :: v_dual_fmac_f32 v72, v147, v90// 0000001A1F24: C800B792 4748B593
	v_mul_f32_e32 v57, v57, v66                                // 0000001A1F2C: 10728539
	v_fma_f32 v107, -v111, v142, v114                          // 0000001A1F30: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001A1F38: 10DE8531
	v_dual_fmac_f32 v143, v144, v84 :: v_dual_mul_f32 v58, v58, v65// 0000001A1F3C: C806A990 8F3A833A
	v_fma_f32 v108, -v110, v72, v113                           // 0000001A1F44: D613006C 25C6916E
	v_fma_f32 v109, -v109, v71, v112                           // 0000001A1F4C: D613006D 25C28F6D
	.long 0x7f003880                                           // 0000001A1F54: 7F003880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A1F58: BF870004
	v_fma_f32 v110, -v115, v143, v116                          // 0000001A1F5C: D613006E 25D31F73
	v_mul_f32_e32 v33, v33, v66                                // 0000001A1F64: 10428521
	v_mul_f32_e32 v25, v25, v66                                // 0000001A1F68: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001A1F6C: 10228511
	.long 0x7f9e3980                                           // 0000001A1F70: 7F9E3980
	.long 0x7f9a3980                                           // 0000001A1F74: 7F9A3980
	.long 0x7f963980                                           // 0000001A1F78: 7F963980
	.long 0x7f943980                                           // 0000001A1F7C: 7F943980
	.long 0x7f923980                                           // 0000001A1F80: 7F923980
	v_mul_f32_e32 v9, v9, v66                                  // 0000001A1F84: 10128509
	v_mul_f32_e32 v1, v1, v66                                  // 0000001A1F88: 10028501
	v_dual_mul_f32 v41, v41, v66 :: v_dual_mul_f32 v34, v34, v65// 0000001A1F8C: C8C68529 29228322
	v_mul_f32_e32 v26, v26, v65                                // 0000001A1F94: 1034831A
	v_mul_f32_e32 v18, v18, v65                                // 0000001A1F98: 10248312
	v_mul_f32_e32 v10, v10, v65                                // 0000001A1F9C: 1014830A
	s_waitcnt vmcnt(47)                                        // 0000001A1FA0: BF89BFF7
	v_dual_mul_f32 v2, v2, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001A1FA4: C8E28302 0230A090
	v_mul_f32_e32 v80, v50, v65                                // 0000001A1FAC: 10A08332
	s_waitcnt vmcnt(46)                                        // 0000001A1FB0: BF89BBF7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001A1FB4: 3064A490
	s_waitcnt vmcnt(45)                                        // 0000001A1FB8: BF89B7F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 0000001A1FBC: 30A4CE90
	s_waitcnt vmcnt(44)                                        // 0000001A1FC0: BF89B3F7
	v_dual_mul_f32 v103, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v76, 16, v76// 0000001A1FC4: C8E262FF 674C9890 BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001A1FD0: 7C3C62FF 42CE8ED0
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001A1FD8: 10E264FF BFB8AA3B
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001A1FE0: 10E4A4FF BFB8AA3B
	s_waitcnt vmcnt(43)                                        // 0000001A1FE8: BF89AFF7
	v_dual_mul_f32 v112, 0xbfb8aa3b, v76 :: v_dual_lshlrev_b32 v99, 16, v99// 0000001A1FEC: C8E298FF 7062C690 BFB8AA3B
	s_waitcnt vmcnt(41)                                        // 0000001A1FF8: BF89A7F7
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001A1FFC: 30CACA90
	s_waitcnt vmcnt(40)                                        // 0000001A2000: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001A2004: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001A2008: 30C4C490
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001A200C: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001A2018: 7EE84767
	s_waitcnt vmcnt(35)                                        // 0000001A201C: BF898FF7
	v_dual_mul_f32 v122, 0xbfb8aa3b, v101 :: v_dual_lshlrev_b32 v95, 16, v95// 0000001A2020: C8E2CAFF 7A5EBE90 BFB8AA3B
	v_lshlrev_b32_e32 v94, 16, v94                             // 0000001A202C: 30BCBC90
	v_dual_mul_f32 v120, 0xbfb8aa3b, v99 :: v_dual_lshlrev_b32 v93, 16, v93// 0000001A2030: C8E2C6FF 785CBA90 BFB8AA3B
	v_lshlrev_b32_e32 v102, 16, v102                           // 0000001A203C: 30CCCC90
	v_fma_f32 v117, 0xbfb8aa3b, v76, -v112                     // 0000001A2040: D6130075 85C298FF BFB8AA3B
	v_rndne_f32_e32 v118, v112                                 // 0000001A204C: 7EEC4770
	v_mul_f32_e32 v121, 0xbfb8aa3b, v100                       // 0000001A2050: 10F2C8FF BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001A2058: 10EEC4FF BFB8AA3B
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_mul_f32 v148, 0xbfb8aa3b, v94// 0000001A2060: C8C6BEFF 9594BCFF BFB8AA3B
	v_sub_f32_e32 v103, v103, v116                             // 0000001A206C: 08CEE967
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001A2070: C80A62FF 7370ED70 B2A5705F
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001A207C: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001A2088: 7F244771
	v_mul_f32_e32 v147, 0xbfb8aa3b, v93                        // 0000001A208C: 1126BAFF BFB8AA3B
	s_waitcnt vmcnt(34)                                        // 0000001A2094: BF898BF7
	v_dual_mul_f32 v144, 0xbfb8aa3b, v102 :: v_dual_lshlrev_b32 v97, 16, v97// 0000001A2098: C8E2CCFF 9060C290 BFB8AA3B
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001A20A4: 30C0C090
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001A20A8: D6130097 85CAA4FF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001A20B4: D613009A 85DEC4FF BFB8AA3B
	v_fmac_f32_e32 v117, 0xb2a5705f, v76                       // 0000001A20C0: 56EA98FF B2A5705F
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001A20C8: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001A20D4: 7F3E4779
	v_add_f32_e32 v103, v103, v115                             // 0000001A20D8: 06CEE767
	v_rndne_f32_e32 v152, v114                                 // 0000001A20DC: 7F304772
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001A20E0: C8C6C2FF 9996C0FF BFB8AA3B
	v_sub_f32_e32 v113, v113, v146                             // 0000001A20EC: 08E32571
	v_rndne_f32_e32 v161, v122                                 // 0000001A20F0: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001A20F4: D61300A2 8642CCFF BFB8AA3B
	v_dual_fmac_f32 v145, 0xb2a5705f, v50 :: v_dual_sub_f32 v114, v114, v152// 0000001A2100: C80A64FF 91733172 B2A5705F
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001A210C: D61300A8 8656BEFF BFB8AA3B
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001A2118: 5734C4FF B2A5705F
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_add_f32 v112, v112, v117// 0000001A2120: C808A4FF 9770EB70 B2A5705F
	v_dual_fmac_f32 v158, 0xb2a5705f, v100 :: v_dual_sub_f32 v121, v121, v159// 0000001A212C: C80AC8FF 9E793F79 B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001A2138: 7ECE4B67
	v_cvt_i32_f32_e32 v116, v116                               // 0000001A213C: 7EE81174
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001A2140: D61300A0 85EACAFF BFB8AA3B
	v_sub_f32_e32 v122, v122, v161                             // 0000001A214C: 08F5437A
	v_dual_fmac_f32 v162, 0xb2a5705f, v102 :: v_dual_add_f32 v113, v113, v145// 0000001A2150: C808CCFF A2712371 B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v121, v121, v158// 0000001A215C: C808BEFF A8793D79 B2A5705F
	v_exp_f32_e32 v112, v112                                   // 0000001A2168: 7EE04B70
	v_cvt_i32_f32_e32 v118, v118                               // 0000001A216C: 7EEC1176
	v_rndne_f32_e32 v155, v119                                 // 0000001A2170: 7F364777
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001A2174: D613009C 85E2C6FF BFB8AA3B
	v_rndne_f32_e32 v157, v120                                 // 0000001A2180: 7F3A4778
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001A2184: D61300AA 865AC0FF BFB8AA3B
	v_exp_f32_e32 v113, v113                                   // 0000001A2190: 7EE24B71
	v_exp_f32_e32 v121, v121                                   // 0000001A2194: 7EF24B79
	.long 0xd71c0067                                           // 0000001A2198: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001A219C: 0202E967
	v_cvt_i32_f32_e32 v146, v146                               // 0000001A21A0: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001A21A4: D61300A4 864EBAFF BFB8AA3B
	v_rndne_f32_e32 v167, v148                                 // 0000001A21B0: 7F4E4794
	v_dual_sub_f32 v115, v119, v155 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001A21B4: C9413777 73A0CAFF B2A5705F
	v_cvt_i32_f32_e32 v117, v155                               // 0000001A21C0: 7EEA119B
	v_dual_fmac_f32 v156, 0xb2a5705f, v99 :: v_dual_sub_f32 v119, v120, v157// 0000001A21C4: C80AC6FF 9C773B78 B2A5705F
	v_cvt_i32_f32_e32 v155, v159                               // 0000001A21D0: 7F36119F
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_cndmask_b32 v103, 0, v103// 0000001A21D4: C812C0FF AA66CE80 B2A5705F
	.long 0xd71c0070                                           // 0000001A21E0: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001A21E4: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001A21E8: 7C3C98FF 42CE8ED0
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001A21F0: D61300A6 8652BCFF BFB8AA3B
	v_dual_fmac_f32 v164, 0xb2a5705f, v93 :: v_dual_add_f32 v115, v115, v154// 0000001A21FC: C808BAFF A4733573 B2A5705F
	v_dual_sub_f32 v148, v148, v167 :: v_dual_add_f32 v119, v119, v156// 0000001A2208: C9494F94 94773977
	.long 0xd71c0071                                           // 0000001A2210: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001A2214: 02032571
	.long 0xd71c0076                                           // 0000001A2218: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001A221C: 02033779
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001A2220: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001A2224: 7C3C64FF 42CE8ED0
	v_add_f32_e32 v122, v122, v160                             // 0000001A222C: 06F5417A
	v_rndne_f32_e32 v169, v149                                 // 0000001A2230: 7F524795
	v_fmac_f32_e32 v166, 0xb2a5705f, v94                       // 0000001A2234: 574CBCFF B2A5705F
	v_exp_f32_e32 v115, v115                                   // 0000001A223C: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001A2240: 7EEE4B77
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001A2244: 02E2E280
	v_exp_f32_e32 v122, v122                                   // 0000001A2248: 7EF44B7A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001A224C: 7C3662FF C2B17218
	v_rndne_f32_e32 v163, v144                                 // 0000001A2254: 7F464790
	v_rndne_f32_e32 v165, v147                                 // 0000001A2258: 7F4A4793
	v_rndne_f32_e32 v171, v150                                 // 0000001A225C: 7F564796
	v_cvt_i32_f32_e32 v120, v157                               // 0000001A2260: 7EF0119D
	v_cvt_i32_f32_e32 v157, v161                               // 0000001A2264: 7F3A11A1
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001A2268: C9495395 95954D94
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001A2270: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001A2278: 7C3698FF C2B17218
	v_dual_sub_f32 v144, v144, v163 :: v_dual_sub_f32 v145, v147, v165// 0000001A2280: C94B4790 90914B93
	v_sub_f32_e32 v150, v150, v171                             // 0000001A2288: 092D5796
	v_exp_f32_e32 v148, v148                                   // 0000001A228C: 7F284B94
	.long 0xd71c0073                                           // 0000001A2290: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001A2294: 0202EB73
	.long 0xd71c0075                                           // 0000001A2298: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001A229C: 0202F177
	.long 0xd71c0077                                           // 0000001A22A0: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001A22A4: 02033B7A
	v_cndmask_b32_e32 v76, 0x7f800000, v112, vcc_lo            // 0000001A22A8: 0298E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001A22B0: 7C3CC4FF 42CE8ED0
	v_cvt_i32_f32_e32 v161, v167                               // 0000001A22B8: 7F4211A7
	v_dual_add_f32 v144, v144, v162 :: v_dual_add_f32 v149, v149, v168// 0000001A22BC: C9094590 90955195
	v_dual_add_f32 v145, v145, v164 :: v_dual_add_f32 v150, v150, v170// 0000001A22C4: C9094991 91975596
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001A22CC: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001A22D0: 7C3CC6FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A22D8: BF870004
	v_exp_f32_e32 v144, v144                                   // 0000001A22DC: 7F204B90
	.long 0xd71c007a                                           // 0000001A22E0: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001A22E4: 02034394
	v_cvt_i32_f32_e32 v159, v163                               // 0000001A22E8: 7F3E11A3
	v_exp_f32_e32 v145, v145                                   // 0000001A22EC: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001A22F0: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001A22F4: 7C3CC8FF 42CE8ED0
	v_cvt_i32_f32_e32 v147, v165                               // 0000001A22FC: 7F2611A5
	v_exp_f32_e32 v149, v149                                   // 0000001A2300: 7F2A4B95
	v_cvt_i32_f32_e32 v163, v169                               // 0000001A2304: 7F4611A9
	v_exp_f32_e32 v116, v150                                   // 0000001A2308: 7EE84B96
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001A230C: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001A2310: 7C3CCAFF 42CE8ED0
	.long 0xd71c0078                                           // 0000001A2318: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001A231C: 02033F90
	.long 0xd71c0079                                           // 0000001A2320: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001A2324: 02032791
	v_cvt_i32_f32_e32 v165, v171                               // 0000001A2328: 7F4A11AB
	.long 0xd41b0005                                           // 0000001A232C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001A2330: 0202BCFF C2B17218
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001A2338: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001A233C: 7C3CCCFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001A2344: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001A2348: 02034795
	.long 0xd71c0074                                           // 0000001A234C: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001A2350: 02034B74
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001A2354: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001A2358: 7C3664FF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001A2360: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001A2368: 7C3CBAFF 42CE8ED0
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001A2370: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001A2374: 7C3CBCFF 42CE8ED0
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001A237C: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001A2380: 7C3CBEFF 42CE8ED0
	v_add_f32_e32 v120, 1.0, v49                               // 0000001A2388: 06F062F2
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A238C: BF870003
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001A2390: D501005E 0016EEFF 7F800000
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001A239C: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001A23A0: 7C3CC0FF 42CE8ED0
	.long 0xd41b0005                                           // 0000001A23A8: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001A23AC: 0202BEFF C2B17218
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001A23B4: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001A23B8: 7C36C4FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A23C0: BF870243
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001A23C4: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001A23D0: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001A23D4: 0202C0FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001A23DC: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001A23E4: 7C36C6FF C2B17218
	v_add_f32_e32 v95, 1.0, v95                                // 0000001A23EC: 06BEBEF2
	v_cndmask_b32_e32 v99, 0x7f800000, v112, vcc_lo            // 0000001A23F0: 02C6E0FF 7F800000
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001A23F8: D6FC7C79 04E6F178
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001A2400: 7C36C8FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2408: BF870193
	v_add_f32_e32 v99, 1.0, v99                                // 0000001A240C: 06C6C6F2
	v_rcp_f32_e32 v103, v121                                   // 0000001A2410: 7ECE5579
	v_cndmask_b32_e32 v100, 0x7f800000, v115, vcc_lo           // 0000001A2414: 02C8E6FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001A241C: 7C36CAFF C2B17218
	v_dual_add_f32 v76, 1.0, v76 :: v_dual_add_f32 v115, 1.0, v50// 0000001A2424: C90898F2 4C7264F2
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001A242C: D5010060 0016E8FF 7F800000
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001A2438: 02CAEAFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001A2440: BF8702A3
	v_div_scale_f32 v122, null, v76, v76, v58                  // 0000001A2444: D6FC7C7A 04EA994C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001A244C: 7C36CCFF C2B17218
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001A2454: D6130032 23CACF79
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001A245C: D6FC0574 05BEE76F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A2464: BF870114
	v_rcp_f32_e32 v112, v122                                   // 0000001A2468: 7EE0557A
	v_dual_cndmask_b32 v102, 0x7f800000, v118 :: v_dual_fmac_f32 v103, v50, v103// 0000001A246C: CA40ECFF 6666CF32 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001A2478: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v76, v58                    // 0000001A2480: D6FC0476 04EA993A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001A2488: BF8702A3
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001A248C: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001A2498: D6FC6A75 04E6F139
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001A24A0: D6130071 23CAE17A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A24A8: BF870213
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001A24AC: D6FC7C77 0542CD66
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_add_f32 v93, 1.0, v93// 0000001A24B4: C908C4F2 625CBAF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A24BC: BF870214
	v_mul_f32_e32 v50, v117, v103                              // 0000001A24C0: 1064CF75
	v_fmac_f32_e32 v112, v113, v112                            // 0000001A24C4: 56E0E171
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A24C8: BF8701A4
	v_rcp_f32_e32 v146, v119                                   // 0000001A24CC: 7F245577
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001A24D0: D6FC7C71 05BEE773
	v_fma_f32 v49, -v121, v50, v117                            // 0000001A24D8: D6130031 25D66579
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A24E0: BF870193
	v_mul_f32_e32 v144, v118, v112                             // 0000001A24E4: 1120E176
	v_rcp_f32_e32 v145, v113                                   // 0000001A24E8: 7F225571
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A24EC: BF870112
	v_fmac_f32_e32 v50, v49, v103                              // 0000001A24F0: 5664CF31
	v_fma_f32 v147, -v122, v144, v118                          // 0000001A24F4: D6130093 25DB217A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001A24FC: BF870312
	v_fma_f32 v117, -v121, v50, v117                           // 0000001A2500: D6130075 25D66579
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001A2508: D6130079 23CB2577
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2510: BF870195
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001A2514: D6130031 23CB2371
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001A251C: D6370067 04CACF75
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001A2524: BF8701D3
	v_fmac_f32_e32 v146, v121, v146                            // 0000001A2528: 57252579
	v_fmac_f32_e32 v144, v147, v112                            // 0000001A252C: 5720E193
	s_mov_b32 vcc_lo, s4                                       // 0000001A2530: BEEA0004
	v_fmac_f32_e32 v145, v49, v145                             // 0000001A2534: 57232331
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001A2538: D6270039 04E6F167
	v_fma_f32 v118, -v122, v144, v118                          // 0000001A2540: D6130076 25DB217A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2548: BF8701A2
	.long 0x7e9e39b9                                           // 0000001A254C: 7E9E39B9
	v_add_f32_e32 v94, 1.0, v94                                // 0000001A2550: 06BCBCF2
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001A2554: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001A255C: BEEA0002
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001A2560: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001A2568: BEEA0003
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A256C: BF870002
	v_div_fixup_f32 v58, v112, v76, v58                        // 0000001A2570: D627003A 04EA9970
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001A2578: D6370047 0522B56C
	v_add_f32_e32 v90, 1.0, v100                               // 0000001A2580: 06B4C8F2
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001A2584: D6270032 03CAB332
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 0000001A258C: D6FC0248 0542CD50
	.long 0x7e0039ba                                           // 0000001A2594: 7E0039BA
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001A2598: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A25A0: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v103, v51, v50// 0000001A25A4: C8C72374 58666533
	v_mul_f32_e32 v59, v59, v50                                // 0000001A25AC: 1076653B
	v_add_f32_e32 v71, 1.0, v101                               // 0000001A25B0: 068ECAF2
	v_and_b32_e32 v79, 1, v79                                  // 0000001A25B4: 369E9E81
	v_fma_f32 v91, -v113, v88, v116                            // 0000001A25B8: D613005B 25D2B171
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001A25C0: D6FC7C75 059EBB5D
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001A25C8: D6FC7C64 04EEC562
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001A25D0: D6FC047A 059EBB67
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001A25D8: D6550039 03FE9F39 00007FFF
	v_fmac_f32_e32 v88, v91, v145                              // 0000001A25E4: 56B1235B
	v_rcp_f32_e32 v112, v117                                   // 0000001A25E8: 7EE05575
	v_rcp_f32_e32 v91, v100                                    // 0000001A25EC: 7EB65564
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v36, v36, v49// 0000001A25F0: C8C6652B 2B246324
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001A25F8: BF870252
	v_fma_f32 v109, -v113, v88, v116                           // 0000001A25FC: D613006D 25D2B171
	v_mul_f32_e32 v113, v52, v49                               // 0000001A2604: 10E26334
	v_mul_f32_e32 v89, v72, v146                               // 0000001A2608: 10B32548
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001A260C: D6FC6A74 04EEC53B
	v_dual_mul_f32 v35, v35, v50 :: v_dual_mul_f32 v28, v28, v49// 0000001A2614: C8C66523 231C631C
	v_div_scale_f32 v76, null, v94, v94, v113                  // 0000001A261C: D6FC7C4C 05C6BD5E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A2624: BF870245
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001A2628: D6130033 23CAB764
	v_mul_f32_e32 v60, v60, v49                                // 0000001A2630: 1078633C
	v_fma_f32 v101, -v119, v89, v72                            // 0000001A2634: D6130065 2522B377
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001A263C: C8C66314 141A651B
	v_fmac_f32_e32 v91, v51, v91                               // 0000001A2644: 56B6B733
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A2648: BF870214
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001A264C: D6FC7C6C 04F2C763
	v_fmac_f32_e32 v89, v101, v146                             // 0000001A2654: 56B32565
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001A2658: D6FC0333 04F2C73C
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001A2660: C8C6630C 0C126513
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2668: BF870194
	v_rcp_f32_e32 v101, v108                                   // 0000001A266C: 7ECA556C
	v_fma_f32 v72, -v119, v89, v72                             // 0000001A2670: D6130048 2522B377
	v_rcp_f32_e32 v119, v76                                    // 0000001A2678: 7EEE554C
	v_mul_f32_e32 v11, v11, v50                                // 0000001A267C: 1016650B
	v_dual_mul_f32 v3, v3, v50 :: v_dual_mul_f32 v4, v4, v49   // 0000001A2680: C8C66503 03046304
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A2688: BF870296
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001A268C: D6130034 23CACB6C
	v_fma_f32 v144, -v76, v119, 1.0                            // 0000001A2694: D6130090 23CAEF4C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A269C: BF8701A2
	v_fmac_f32_e32 v101, v52, v101                             // 0000001A26A0: 56CACB34
	v_mul_f32_e32 v52, v116, v91                               // 0000001A26A4: 1068B774
	v_fmac_f32_e32 v119, v144, v119                            // 0000001A26A8: 56EEEF90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A26AC: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 0000001A26B0: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 0000001A26B8: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001A26BC: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A26C4: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 0000001A26C8: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001A26D0: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001A26D8: BEEA0003
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A26DC: BF870091
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001A26E0: D627003B 04EEC55B
	.long 0x7e9a39bb                                           // 0000001A26E8: 7E9A39BB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A26EC: BF870121
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_and_b32 v77, 1, v77// 0000001A26F0: C824E178 704C9A81
	v_mul_f32_e32 v118, v51, v101                              // 0000001A26F8: 10ECCB33
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000001A26FC: D655003B 03FE9B3B 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2708: BF870092
	v_fma_f32 v121, -v108, v118, v51                           // 0000001A270C: D6130079 24CEED6C
	v_fmac_f32_e32 v118, v121, v101                            // 0000001A2714: 56ECCB79
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001A2718: D6FC0679 05C6BD71
	v_add_f32_e32 v96, 1.0, v96                                // 0000001A2720: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2724: BF870093
	v_fma_f32 v51, -v108, v118, v51                            // 0000001A2728: D6130033 24CEED6C
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001A2730: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001A2738: BEEA0000
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001A273C: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001A2744: BEEA0001
	v_and_b32_e32 v85, 1, v0                                   // 0000001A2748: 36AA0081
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001A274C: D6370054 063EA96E
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001A2754: D627003C 04F2C764
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001A275C: D6270034 03CAA733
	v_mul_f32_e32 v83, v122, v112                              // 0000001A2764: 10A6E17A
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001A2768: D655003A 03FEAB3A 00007FFF
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001A2774: D6270033 03CAA354
	v_mul_f32_e32 v81, v121, v119                              // 0000001A277C: 10A2EF79
	v_mul_f32_e32 v61, v61, v52                                // 0000001A2780: 107A693D
	v_fma_f32 v79, -v117, v83, v122                            // 0000001A2784: D613004F 25EAA775
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A278C: BF870004
	v_dual_mul_f32 v53, v53, v52 :: v_dual_mul_f32 v54, v54, v51// 0000001A2790: C8C66935 35366736
	v_mul_f32_e32 v62, v62, v51                                // 0000001A2798: 107C673E
	v_fma_f32 v84, -v76, v81, v121                             // 0000001A279C: D6130054 25E6A34C
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001A27A4: D6FC7C55 04F6B55A
	v_fmac_f32_e32 v83, v79, v112                              // 0000001A27AC: 56A6E14F
	s_clause 0x1                                               // 0000001A27B0: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001A27B4: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001A27BC: DC960400 007C3A07
	v_div_scale_f32 v79, null, v71, v71, v62                   // 0000001A27C4: D6FC7C4F 04FA8F47
	v_fmac_f32_e32 v81, v84, v119                              // 0000001A27CC: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001A27D0: 7EA85555
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001A27D4: D6FC7C64 04D6BF5F
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001A27DC: D6FC6A63 04F6B53D
	v_rcp_f32_e32 v91, v79                                     // 0000001A27E4: 7EB6554F
	v_fma_f32 v58, -v76, v81, v121                             // 0000001A27E8: D613003A 25E6A34C
	.long 0x7e0039bc                                           // 0000001A27F0: 7E0039BC
	v_rcp_f32_e32 v107, v100                                   // 0000001A27F4: 7ED65564
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001A27F8: DC960000 007C3B0F
	v_fma_f32 v57, -v117, v83, v122                            // 0000001A2800: D6130039 25EAA775
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001A2808: D6FC7C74 04DAC160
	v_fma_f32 v76, -v85, v84, 1.0                              // 0000001A2810: D613004C 23CAA955
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001A2818: D6FC016E 04D6BF35
	v_mul_f32_e32 v45, v45, v52                                // 0000001A2820: 105A692D
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001A2824: D6130062 23CAB74F
	v_mul_f32_e32 v37, v37, v52                                // 0000001A282C: 104A6925
	v_fmac_f32_e32 v84, v76, v84                               // 0000001A2830: 56A8A94C
	v_div_scale_f32 v76, s0, v62, v71, v62                     // 0000001A2834: D6FC004C 04FA8F3E
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001A283C: D613003B 23CAD764
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001A2844: C824B762 5B620081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A284C: BF870194
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v22, v22, v51// 0000001A2850: C8C6A963 65166716
	v_fmac_f32_e32 v107, v59, v107                             // 0000001A2858: 56D6D73B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A285C: BF870213
	v_mul_f32_e32 v108, v76, v91                               // 0000001A2860: 10D8B74C
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001A2864: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A2870: BF870224
	v_fma_f32 v77, -v85, v101, v99                             // 0000001A2874: D613004D 258ECB55
	v_dual_mul_f32 v29, v29, v52 :: v_dual_mul_f32 v14, v14, v51// 0000001A287C: C8C6691D 1D0E670E
	v_fma_f32 v117, -v79, v108, v76                            // 0000001A2884: D6130075 2532D94F
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001A288C: DC960000 007C3C17
	v_fmac_f32_e32 v101, v77, v84                              // 0000001A2894: 56CAA94D
	v_rcp_f32_e32 v77, v116                                    // 0000001A2898: 7E9A5574
	v_mul_f32_e32 v21, v21, v52                                // 0000001A289C: 102A6915
	v_fmac_f32_e32 v108, v117, v91                             // 0000001A28A0: 56D8B775
	v_mul_f32_e32 v13, v13, v52                                // 0000001A28A4: 101A690D
	v_fma_f32 v60, -v85, v101, v99                             // 0000001A28A8: D613003C 258ECB55
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 0000001A28B0: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A28B8: BF870004
	v_fma_f32 v59, -v79, v108, v76                             // 0000001A28BC: D613003B 2532D94F
	s_waitcnt vmcnt(23)                                        // 0000001A28C4: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001A28C8: 309F1290
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001A28CC: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 0000001A28D4: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001A28D8: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001A28E0: BEEA0002
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A28E4: BF870002
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001A28E8: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001A28F0: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001A28F8: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001A28FC: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001A2904: D637003D 0563236D
	.long 0x7e9639bc                                           // 0000001A290C: 7E9639BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001A2910: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001A2918: BEEA0004
	.long 0x7e0039bb                                           // 0000001A291C: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001A2920: D627003D 05BEE73D
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001A2928: D6370039 054EE139
	.long 0x7e9439be                                           // 0000001A2930: 7E9439BE
	s_mov_b32 vcc_lo, s6                                       // 0000001A2934: BEEA0006
	v_and_b32_e32 v71, 1, v0                                   // 0000001A2938: 368E0081
	.long 0x7e0039bd                                           // 0000001A293C: 7E0039BD
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001A2940: D637003A 0546EF3A
	v_and_b32_e32 v72, 1, v75                                  // 0000001A2948: 36909681
	v_and_b32_e32 v74, 1, v74                                  // 0000001A294C: 36949481
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001A2950: D655003B 03FE8F3B 00007FFF
	v_and_b32_e32 v75, 1, v0                                   // 0000001A295C: 36960081
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001A2960: D627003A 05C6BD3A
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001A2968: D655003C 03FE913C 00007FFF
	v_add3_u32 v62, v62, v74, 0x7fff                           // 0000001A2974: D655003E 03FE953E 00007FFF
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001A2980: D6270039 059EBB39
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001A2988: D655003D 03FE973D 00007FFF
	.long 0x7e0039ba                                           // 0000001A2994: 7E0039BA
	s_clause 0x3                                               // 0000001A2998: BF850003
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001A299C: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001A29A4: DC960000 007C3B27
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001A29AC: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001A29B4: DC960020 007C3E2F
	v_fma_f32 v60, -v116, v77, 1.0                             // 0000001A29BC: D613003C 23CA9B74
	v_add_f32_e32 v61, v114, v151                              // 0000001A29C4: 067B2F72
	v_mul_f32_e32 v62, v110, v107                              // 0000001A29C8: 107CD76E
	.long 0x7e9239b9                                           // 0000001A29CC: 7E9239B9
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001A29D0: D6130048 8666C2FF BFB8AA3B
	v_and_b32_e32 v59, 1, v0                                   // 0000001A29DC: 36760081
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001A29E0: 7C3CA4FF 42CE8ED0
	v_fma_f32 v75, -v100, v62, v110                            // 0000001A29E8: D613004B 25BA7D64
	v_fmac_f32_e32 v77, v60, v77                               // 0000001A29F0: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 0000001A29F4: 7E784B3D
	v_fmac_f32_e32 v72, 0xb2a5705f, v97                        // 0000001A29F8: 5690C2FF B2A5705F
	v_and_b32_e32 v71, 1, v73                                  // 0000001A2A00: 368E9281
	v_rndne_f32_e32 v73, v153                                  // 0000001A2A04: 7E924799
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001A2A08: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001A2A14: 7E761198
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001A2A18: D6FC003D 04DAC136
	v_fmac_f32_e32 v62, v75, v107                              // 0000001A2A20: 567CD74B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A2A24: BF870185
	.long 0xd71c003b                                           // 0000001A2A28: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001A2A2C: 0202773C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2A30: BF870091
	v_dual_sub_f32 v74, v153, v73 :: v_dual_cndmask_b32 v59, 0, v59// 0000001A2A34: C9529399 4A3A7680
	v_add_f32_e32 v72, v74, v72                                // 0000001A2A3C: 0690914A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001A2A40: 7C36A4FF C2B17218
	v_mul_f32_e32 v76, v61, v77                                // 0000001A2A48: 10989B3D
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001A2A4C: D6550039 03FE8F39 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2A58: BF8701A4
	v_exp_f32_e32 v71, v72                                     // 0000001A2A5C: 7E8E4B48
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001A2A60: 027676FF 7F800000
	v_fma_f32 v60, -v116, v76, v61                             // 0000001A2A68: D613003C 24F69974
	v_fma_f32 v72, -v100, v62, v110                            // 0000001A2A70: D6130048 25BA7D64
	s_mov_b32 vcc_lo, s1                                       // 0000001A2A78: BEEA0001
	s_clause 0x1                                               // 0000001A2A7C: BF850001
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001A2A80: DC960020 007C390F
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001A2A88: DC960020 007C3A17
	v_fmac_f32_e32 v76, v60, v77                               // 0000001A2A90: 56989B3C
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001A2A94: 7E781149
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001A2A98: D637003E 04FAD748
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001A2AA0: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 0000001A2AA8: 7F903980
	v_fma_f32 v61, -v116, v76, v61                             // 0000001A2AAC: D613003D 24F69974
	.long 0xd71c003c                                           // 0000001A2AB4: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001A2AB8: 02027947
	v_add_f32_e32 v59, 1.0, v59                                // 0000001A2ABC: 067676F2
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001A2AC0: D6270035 04D6BF3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2AC8: BF8701A3
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001A2ACC: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001A2AD0: BEEA0000
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001A2AD4: D6FC7C47 04A6773B
	v_div_fmas_f32 v61, v61, v77, v76                          // 0000001A2ADC: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001A2AE4: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001A2AEC: 7E9039B5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2AF0: BF870194
	v_rcp_f32_e32 v57, v71                                     // 0000001A2AF4: 7E725547
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001A2AF8: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001A2B00: CA6278FF 3C3D1490 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2B0C: BF870193
	v_and_b32_e32 v72, 1, v72                                  // 0000001A2B10: 36909081
	.long 0x7e0039b6                                           // 0000001A2B14: 7E0039B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A2B18: BF870213
	v_add_f32_e32 v60, 1.0, v60                                // 0000001A2B1C: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001A2B20: 107C7AFF BFB8AA3B
	v_mul_f32_e32 v42, v42, v65                                // 0000001A2B28: 1054832A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A2B2C: BF870005
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001A2B30: D6130049 23CA7347
	v_and_b32_e32 v77, 1, v0                                   // 0000001A2B38: 369A0081
	.long 0xd41e0001                                           // 0000001A2B3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001A2B40: 02027AFF 42CE8ED0
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001A2B48: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001A2B54: 7E98473E
	v_fmac_f32_e32 v57, v73, v57                               // 0000001A2B58: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001A2B5C: D6FC6A49 04A67729
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001A2B64: D6550036 03FE9B36 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A2B70: BF870004
	v_dual_fmac_f32 v75, 0xb2a5705f, v61 :: v_dual_sub_f32 v62, v62, v76// 0000001A2B74: C80A7AFF 4B3E993E B2A5705F
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001A2B80: 10A09EFF BFB8AA3B
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001A2B88: D6FC7C3A 04AA793C
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001A2B90: 7E98114C
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001A2B94: D6550035 03FE9135 00007FFF
	v_dual_add_f32 v62, v62, v75 :: v_dual_mul_f32 v75, v73, v57// 0000001A2BA0: C906973E 3E4A7349
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A2BA8: BF870004
	v_rcp_f32_e32 v74, v58                                     // 0000001A2BAC: 7E94553A
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001A2BB0: D6130052 85429EFF BFB8AA3B
	v_rndne_f32_e32 v83, v80                                   // 0000001A2BBC: 7EA64750
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001A2BC0: DC960020 007C351F
	v_fma_f32 v77, -v71, v75, v73                              // 0000001A2BC8: D613004D 25269747
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001A2BD0: DC960020 007C3627
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001A2BD8: 56A49EFF B2A5705F
	v_dual_sub_f32 v80, v80, v83 :: v_dual_fmac_f32 v75, v77, v57// 0000001A2BE0: C940A750 504A734D
	v_exp_f32_e32 v62, v62                                     // 0000001A2BE8: 7E7C4B3E
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001A2BEC: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2BF4: BF870192
	v_add_f32_e32 v80, v80, v82                                // 0000001A2BF8: 06A0A550
	v_fma_f32 v71, -v71, v75, v73                              // 0000001A2BFC: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A2C04: BF870291
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001A2C08: D6370039 052E7347
	.long 0xd71c003e                                           // 0000001A2C10: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 0000001A2C14: 0202993E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2C18: BF8701A4
	v_exp_f32_e32 v76, v80                                     // 0000001A2C1C: 7E984B50
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001A2C20: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001A2C28: D6270029 04A67739
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2C30: BF870233
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001A2C34: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001A2C3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001A2C40: 02027AFF C2B17218
	.long 0x7f763980                                           // 0000001A2C48: 7F763980
	.long 0x7e7639a9                                           // 0000001A2C4C: 7E7639A9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2C50: BF870233
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001A2C54: D501003D 00067CFF 7F800000
	v_fmac_f32_e32 v74, v81, v74                               // 0000001A2C60: 56949551
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001A2C64: D6FC0051 04AA792A
	v_and_b32_e32 v59, 1, v59                                  // 0000001A2C6C: 36767681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A2C70: BF870114
	v_add_f32_e32 v61, 1.0, v61                                // 0000001A2C74: 067A7AF2
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001A2C78: D6550029 03FE7729 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001A2C84: BF8700C2
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001A2C88: D6FC7C47 04AE7B3D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001A2C90: DC960040 007C2907
	v_rcp_f32_e32 v53, v71                                     // 0000001A2C98: 7E6A5547
	v_mul_f32_e32 v84, v81, v74                                // 0000001A2C9C: 10A89551
	v_fma_f32 v72, -v58, v84, v81                              // 0000001A2CA0: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A2CA8: BF8700A1
	v_fmac_f32_e32 v84, v72, v74                               // 0000001A2CAC: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001A2CB0: 7E901153
	.long 0xd71c003e                                           // 0000001A2CB4: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001A2CB8: 0202914C
	s_waitcnt vmcnt(11)                                        // 0000001A2CBC: BF892FF7
	v_lshlrev_b32_e32 v76, 16, v139                            // 0000001A2CC0: 30991690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001A2CC4: BF870131
	v_dual_cndmask_b32 v62, 0, v62 :: v_dual_mul_f32 v77, 0xbfb8aa3b, v76// 0000001A2CC8: CA467C80 3E4C98FF BFB8AA3B
	v_fma_f32 v58, -v58, v84, v81                              // 0000001A2CD4: D613003A 2546A93A
	s_mov_b32 vcc_lo, s0                                       // 0000001A2CDC: BEEA0000
	v_rndne_f32_e32 v81, v77                                   // 0000001A2CE0: 7EA2474D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2CE4: BF870232
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001A2CE8: D637003A 0552953A
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001A2CF0: D6130050 853698FF BFB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001A2CFC: 7C369EFF C2B17218
	v_sub_f32_e32 v77, v77, v81                                // 0000001A2D04: 089AA34D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A2D08: BF870124
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001A2D0C: D627002A 04AA793A
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001A2D14: 30791890
	.long 0x7e0039aa                                           // 0000001A2D18: 7E0039AA
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2D1C: BF8701A2
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 0000001A2D20: 107278FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001A2D28: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001A2D2C: 020278FF 42CE8ED0
	v_and_b32_e32 v75, 1, v0                                   // 0000001A2D34: 36960081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2D38: BF870233
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001A2D3C: D6130049 84E678FF BFB8AA3B
	v_rndne_f32_e32 v74, v57                                   // 0000001A2D48: 7E944739
	v_mul_f32_e32 v44, v44, v49                                // 0000001A2D4C: 1058632C
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001A2D50: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A2D5C: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v60                        // 0000001A2D60: 569278FF B2A5705F
	v_sub_f32_e32 v57, v57, v74                                // 0000001A2D68: 08729539
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001A2D6C: 027C7CFF 7F800000
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001A2D74: 7E94114A
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001A2D78: DC960040 007C2A2F
	v_dual_add_f32 v57, v57, v73 :: v_dual_add_f32 v58, 1.0, v62// 0000001A2D80: C9089339 393A7CF2
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001A2D88: D613003E 23CA6B47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2D90: BF870092
	v_exp_f32_e32 v57, v57                                     // 0000001A2D94: 7E724B39
	v_fmac_f32_e32 v53, v62, v53                               // 0000001A2D98: 566A6B3E
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001A2D9C: D6FC6A3E 04AE7B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001A2DA4: BF8702A1
	v_mul_f32_e32 v73, v62, v53                                // 0000001A2DA8: 10926B3E
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001A2DAC: D6FC7C36 04B2753A
	.long 0xd71c0039                                           // 0000001A2DB4: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001A2DB8: 02029539
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2DBC: BF870193
	v_fma_f32 v75, -v71, v73, v62                              // 0000001A2DC0: D613004B 24FA9347
	v_rcp_f32_e32 v72, v54                                     // 0000001A2DC8: 7E905536
	v_fmac_f32_e32 v80, 0xb2a5705f, v76                        // 0000001A2DCC: 56A098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2DD4: BF870233
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001A2DD8: D5010039 00067280
	.long 0xd41b0001                                           // 0000001A2DE0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001A2DE4: 020278FF C2B17218
	v_fmac_f32_e32 v73, v75, v53                               // 0000001A2DEC: 56926B4B
	v_add_f32_e32 v77, v77, v80                                // 0000001A2DF0: 069AA14D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2DF4: BF870193
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001A2DF8: D5010039 000672FF 7F800000
	v_fma_f32 v62, -v71, v73, v62                              // 0000001A2E04: D613003E 24FA9347
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A2E0C: BF870215
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001A2E10: D613004F 23CA9136
	v_exp_f32_e32 v74, v77                                     // 0000001A2E18: 7E944B4D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A2E1C: BF870193
	v_add_f32_e32 v57, 1.0, v57                                // 0000001A2E20: 067272F2
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001A2E24: D6370035 05266B3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A2E2C: BF870233
	v_fmac_f32_e32 v72, v79, v72                               // 0000001A2E30: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001A2E34: D6FC004F 04B2752C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001A2E3C: 7C3C98FF 42CE8ED0
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001A2E44: D627002B 04AE7B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2E4C: BF870093
	v_mul_f32_e32 v82, v79, v72                                // 0000001A2E50: 10A4914F
	v_fma_f32 v59, -v54, v82, v79                              // 0000001A2E54: D613003B 253EA536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A2E5C: BF870121
	v_fmac_f32_e32 v82, v59, v72                               // 0000001A2E60: 56A4913B
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001A2E64: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 0000001A2E68: D6130036 253EA536
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A2E70: BF870092
	.long 0xd71c003b                                           // 0000001A2E74: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001A2E78: 0202774A
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001A2E7C: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001A2E80: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A2E84: BF870123
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001A2E88: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001A2E90: 7C3698FF C2B17218
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001A2E98: D6270029 04B27536
	v_dual_cndmask_b32 v59, 0x7f800000, v59 :: v_dual_lshlrev_b32 v58, 16, v78// 0000001A2EA0: CA6276FF 3B3A9C90 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001A2EAC: 1058672E
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001A2EB0: D6FC7C3C 04B67339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A2EB8: BF870214
	.long 0x7e0039a9                                           // 0000001A2EBC: 7E0039A9
	v_dual_add_f32 v54, 1.0, v59 :: v_dual_mul_f32 v53, 0xbfb8aa3b, v58// 0000001A2EC0: C90676F2 363474FF BFB8AA3B
	.long 0x7e7639ab                                           // 0000001A2ECC: 7E7639AB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A2ED0: BF8701A4
	v_rcp_f32_e32 v46, v60                                     // 0000001A2ED4: 7E5C553C
	.long 0x7f763980                                           // 0000001A2ED8: 7F763980
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001A2EDC: D6FC7C2A 04B26D36
	v_rndne_f32_e32 v72, v53                                   // 0000001A2EE4: 7E904735
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001A2EE8: D6130047 84D674FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A2EF4: BF870123
	v_rcp_f32_e32 v62, v42                                     // 0000001A2EF8: 7E7C552A
	s_waitcnt vmcnt(5)                                         // 0000001A2EFC: BF8917F7
	v_dual_sub_f32 v53, v53, v72 :: v_dual_lshlrev_b32 v74, 16, v141// 0000001A2F00: C9629135 354B1A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001A2F08: BF870312
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001A2F0C: 568E74FF B2A5705F
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001A2F14: D613003D 23CA5D3C
	v_and_b32_e32 v73, 1, v0                                   // 0000001A2F1C: 36920081
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001A2F20: 7E901148
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001A2F24: 109694FF BFB8AA3B
	v_add_f32_e32 v53, v53, v71                                // 0000001A2F2C: 066A8F35
	v_fmac_f32_e32 v46, v61, v46                               // 0000001A2F30: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001A2F34: D6FC6A3D 04B6732D
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001A2F3C: D613004C 23CA7D2A
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001A2F44: D613004D 852E94FF BFB8AA3B
	v_rndne_f32_e32 v78, v75                                   // 0000001A2F50: 7E9C474B
	v_and_b32_e32 v59, 1, v59                                  // 0000001A2F54: 36767681
	v_mul_f32_e32 v71, v61, v46                                // 0000001A2F58: 108E5D3D
	v_fmac_f32_e32 v62, v76, v62                               // 0000001A2F5C: 567C7D4C
	v_exp_f32_e32 v53, v53                                     // 0000001A2F60: 7E6A4B35
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001A2F64: D6FC004C 04B26D2C
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001A2F6C: 569A94FF B2A5705F
	v_sub_f32_e32 v75, v75, v78                                // 0000001A2F74: 08969D4B
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001A2F78: D6550029 03FE9329 00007FFF
	v_fma_f32 v73, -v60, v71, v61                              // 0000001A2F84: D6130049 24F68F3C
	v_mul_f32_e32 v79, v76, v62                                // 0000001A2F8C: 109E7D4C
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001A2F90: D655002B 03FE772B 00007FFF
	v_add_f32_e32 v75, v75, v77                                // 0000001A2F9C: 06969B4B
	.long 0xd41e0001                                           // 0000001A2FA0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001A2FA4: 020274FF 42CE8ED0
	.long 0xd71c0035                                           // 0000001A2FAC: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001A2FB0: 02029135
	v_fmac_f32_e32 v71, v73, v46                               // 0000001A2FB4: 568E5D49
	v_fma_f32 v59, -v42, v79, v76                              // 0000001A2FB8: D613003B 25329F2A
	v_exp_f32_e32 v72, v75                                     // 0000001A2FC0: 7E904B4B
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001A2FC4: DC960040 007C2B0F
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001A2FCC: D5010035 00066A80
	v_fma_f32 v60, -v60, v71, v61                              // 0000001A2FD4: D613003C 24F68F3C
	v_fmac_f32_e32 v79, v59, v62                               // 0000001A2FDC: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001A2FE0: 7E76114E
	.long 0xd41b0001                                           // 0000001A2FE4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001A2FE8: 020274FF C2B17218
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001A2FF0: DC960040 007C2917
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001A2FF8: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001A3000: 7C3C94FF 42CE8ED0
	.long 0xd71c003a                                           // 0000001A3008: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001A300C: 02027748
	v_fma_f32 v42, -v42, v79, v76                              // 0000001A3010: D613002A 25329F2A
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001A3018: D5010035 00066AFF 7F800000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001A3024: D627002D 04B6732E
	v_lshlrev_b32_e32 v72, 16, v132                            // 0000001A302C: 30910890
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001A3030: 02747480
	s_mov_b32 vcc_lo, s0                                       // 0000001A3034: BEEA0000
	.long 0x7f723980                                           // 0000001A3038: 7F723980
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001A303C: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001A3044: 7C3694FF C2B17218
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001A304C: 109290FF BFB8AA3B
	.long 0x7e7239ad                                           // 0000001A3054: 7E7239AD
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A3058: BF870244
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001A305C: D627002A 04B26D2A
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001A3064: 306D0A90
	v_dual_cndmask_b32 v58, 0x7f800000, v58 :: v_dual_add_f32 v53, 1.0, v53// 0000001A3068: CA4874FF 3A346AF2 7F800000
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001A3074: D613004B 852690FF BFB8AA3B
	.long 0x7e0039aa                                           // 0000001A3080: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3084: BF870214
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001A3088: 105C6CFF BFB8AA3B
	v_add_f32_e32 v44, 1.0, v58                                // 0000001A3090: 065874F2
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001A3094: D6FC7C3B 04866B35
	.long 0xd41e0001                                           // 0000001A309C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001A30A0: 02026CFF 42CE8ED0
	v_and_b32_e32 v71, 1, v0                                   // 0000001A30A8: 368E0081
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001A30AC: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001A30B8: 7E7C472E
	v_rcp_f32_e32 v43, v59                                     // 0000001A30BC: 7E56553B
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001A30C0: D6FC7C29 048A592C
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001A30C8: D655002A 03FE8F2A 00007FFF
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001A30D4: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 0000001A30DC: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001A30E0: 7E7C113E
	v_rcp_f32_e32 v60, v41                                     // 0000001A30E4: 7E785529
	v_rndne_f32_e32 v76, v73                                   // 0000001A30E8: 7E984749
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001A30EC: BF870313
	v_dual_fmac_f32 v75, 0xb2a5705f, v72 :: v_dual_add_f32 v46, v46, v61// 0000001A30F0: C80890FF 4B2E7B2E B2A5705F
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001A30FC: D613003A 23CA573B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3104: BF870193
	v_sub_f32_e32 v73, v73, v76                                // 0000001A3108: 08929949
	v_exp_f32_e32 v46, v46                                     // 0000001A310C: 7E5C4B2E
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A3110: BF870096
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001A3114: D613004A 23CA7929
	v_dual_add_f32 v73, v73, v75 :: v_dual_fmac_f32 v60, v74, v60// 0000001A311C: C9009749 493C794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001A3124: D6FC004A 048A5922
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A312C: BF870195
	.long 0xd71c002e                                           // 0000001A3130: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001A3134: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001A3138: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A313C: BF870112
	v_mul_f32_e32 v77, v74, v60                                // 0000001A3140: 109A794A
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001A3144: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001A314C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001A3150: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001A3158: BF8700B1
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001A315C: D501002E 00065CFF 7F800000
	v_fmac_f32_e32 v43, v58, v43                               // 0000001A3168: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001A316C: D6FC6A3A 04866B21
	v_dual_add_f32 v46, 1.0, v46 :: v_dual_mul_f32 v61, v58, v43// 0000001A3174: C9065CF2 2E3C573A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A317C: BF870091
	v_fma_f32 v71, -v59, v61, v58                              // 0000001A3180: D6130047 24EA7B3B
	v_fmac_f32_e32 v61, v71, v43                               // 0000001A3188: 567A5747
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A318C: BF870091
	v_fma_f32 v58, -v59, v61, v58                              // 0000001A3190: D613003A 24EA7B3B
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001A3198: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001A31A0: 7C3C90FF 42CE8ED0
	v_and_b32_e32 v57, 1, v57                                  // 0000001A31A8: 36727281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A31AC: BF8701A3
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001A31B0: D6270021 04866B2B
	.long 0x7f6a3980                                           // 0000001A31B8: 7F6A3980
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001A31BC: D655002D 03FE732D 00007FFF
	v_fma_f32 v57, -v41, v77, v74                              // 0000001A31C8: D6130039 252A9B29
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A31D0: BF870004
	.long 0x7e6a39a1                                           // 0000001A31D4: 7E6A39A1
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001A31D8: DC960040 007C2D1F
	v_fmac_f32_e32 v77, v57, v60                               // 0000001A31E0: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001A31E4: 7E72114C
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001A31E8: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001A31EC: DC960040 007C2A27
	v_and_b32_e32 v53, 1, v53                                  // 0000001A31F4: 366A6A81
	v_fma_f32 v41, -v41, v77, v74                              // 0000001A31F8: D6130029 252A9B29
	.long 0xd71c0036                                           // 0000001A3200: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001A3204: 0202733E
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001A3208: D6FC7C39 048E5D2E
	v_dual_mul_f32 v43, 0xbfb8aa3b, v45 :: v_dual_lshlrev_b32 v62, 16, v134// 0000001A3210: C8E25AFF 2B3F0C90 BFB8AA3B
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001A321C: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A3228: BF8701A4
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001A322C: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001A3230: BEEA0000
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001A3234: D613003B 84AE5AFF BFB8AA3B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001A3240: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001A3248: 7C3690FF C2B17218
	v_rndne_f32_e32 v60, v43                                   // 0000001A3250: 7E78472B
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001A3254: 108E7CFF BFB8AA3B
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001A325C: 56765AFF B2A5705F
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001A3264: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001A326C: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001A3274: 7E525539
	v_sub_f32_e32 v43, v43, v60                                // 0000001A3278: 0856792B
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001A327C: D6130049 851E7CFF BFB8AA3B
	.long 0x7e0039a2                                           // 0000001A3288: 7E0039A2
	v_add_f32_e32 v44, 1.0, v54                                // 0000001A328C: 06586CF2
	v_rndne_f32_e32 v74, v71                                   // 0000001A3290: 7E944747
	v_add_f32_e32 v43, v43, v59                                // 0000001A3294: 0656772B
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001A3298: 56927CFF B2A5705F
	v_and_b32_e32 v61, 1, v0                                   // 0000001A32A0: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001A32A4: D6FC7C2A 0492592C
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001A32AC: D6130036 23CA5339
	v_exp_f32_e32 v43, v43                                     // 0000001A32B4: 7E564B2B
	v_sub_f32_e32 v71, v71, v74                                // 0000001A32B8: 088E9547
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001A32BC: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 0000001A32C8: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 0000001A32CC: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001A32D0: D6FC6A36 048E5D23
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001A32D8: 7E78113C
	v_add_f32_e32 v71, v71, v73                                // 0000001A32DC: 068E9347
	.long 0xd41e0001                                           // 0000001A32E0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001A32E4: 02025AFF 42CE8ED0
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001A32EC: DC960060 007C2107
	v_mul_f32_e32 v59, v54, v41                                // 0000001A32F4: 10765336
	.long 0xd71c002b                                           // 0000001A32F8: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001A32FC: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001A3300: 7E784B47
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001A3304: D6130048 23CA752A
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001A330C: DC960060 007C222F
	v_fma_f32 v61, -v57, v59, v54                              // 0000001A3314: D613003D 24DA7739
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001A331C: D501002B 00065680
	.long 0xd41b0001                                           // 0000001A3324: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001A3328: 02025AFF C2B17218
	v_fmac_f32_e32 v58, v72, v58                               // 0000001A3330: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001A3334: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001A333C: 5676533D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3340: BF870194
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001A3344: D501002B 000656FF 7F800000
	v_mul_f32_e32 v75, v72, v58                                // 0000001A3350: 10967548
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3354: BF870193
	v_fma_f32 v54, -v57, v59, v54                              // 0000001A3358: D6130036 24DA7739
	v_add_f32_e32 v43, 1.0, v43                                // 0000001A3360: 065656F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3364: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 0000001A3368: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001A3370: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001A3378: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A3380: BF870223
	v_fmac_f32_e32 v75, v53, v58                               // 0000001A3384: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001A3388: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001A338C: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3394: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001A3398: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001A33A0: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001A33A4: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001A33A8: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001A33B0: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A33B4: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001A33B8: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001A33C0: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001A33C4: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001A33CC: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001A33D4: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A33DC: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001A33E0: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001A33EC: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001A33F4: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001A3400: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001A3404: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3408: BF870193
	.long 0x7e0039a1                                           // 0000001A340C: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001A3410: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001A3414: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001A3418: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001A3420: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001A3424: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001A3428: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001A3430: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001A3434: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001A3440: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001A3444: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001A344C: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001A3450: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001A3458: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001A3460: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001A3464: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001A3468: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001A3470: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001A3474: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001A3478: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001A347C: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001A3488: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001A3490: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001A3494: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001A3498: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001A349C: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001A34A0: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001A34A8: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001A34B0: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001A34B8: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001A34C4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001A34C8: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 0000001A34D0: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A34D4: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 0000001A34D8: 56724D3B
	.long 0xd71c0029                                           // 0000001A34DC: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001A34E0: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001A34E4: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001A34E8: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 0000001A34F0: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001A34F8: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001A3500: D5010029 00065280
	.long 0xd41b0001                                           // 0000001A3508: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001A350C: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001A3514: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001A351C: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001A3520: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001A3524: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001A352C: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001A3534: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001A3540: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001A3548: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001A354C: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001A3550: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A3558: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001A355C: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001A3564: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001A3568: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001A356C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A3570: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001A3574: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001A357C: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001A3584: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001A358C: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001A3594: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001A3598: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001A35A4: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001A35AC: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001A35B4: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001A35B8: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001A35BC: 7E7C473B
	.long 0x7e0039a2                                           // 0000001A35C0: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001A35C4: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001A35C8: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001A35D0: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001A35D8: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001A35DC: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001A35E0: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001A35E8: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001A35F4: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001A35F8: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001A3600: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001A3604: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001A3608: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A3610: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001A3614: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001A361C: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001A3624: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001A3630: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001A3634: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001A3638: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001A363C: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A3640: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001A3644: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001A364C: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001A3658: 7E4C4B26
	.long 0xd41e0001                                           // 0000001A365C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001A3660: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001A3668: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001A3670: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001A3674: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001A367C: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001A3684: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001A3688: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001A368C: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001A3694: 108E5D3C
	.long 0xd71c0026                                           // 0000001A3698: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001A369C: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001A36A0: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001A36A4: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A36AC: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001A36B0: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001A36B8: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001A36C0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001A36C4: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A36CC: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001A36D0: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001A36D8: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001A36E0: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001A36E4: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001A36E8: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001A36F4: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001A36FC: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001A3704: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001A370C: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001A3710: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001A3714: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001A3718: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001A371C: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001A3728: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001A372C: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001A3730: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001A3734: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001A373C: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001A3744: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001A374C: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001A3750: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001A3758: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001A3760: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001A3768: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001A3770: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001A3774: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001A3778: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001A3784: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001A3788: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001A378C: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001A3790: 06465B23
	.long 0x7f523980                                           // 0000001A3794: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001A3798: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001A379C: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001A37A4: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001A37AC: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001A37B0: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001A37B8: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001A37BC: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001A37C0: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001A37C4: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001A37CC: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001A37D0: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001A37DC: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001A37E0: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001A37E4: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001A37E8: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001A37F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001A37F8: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001A3800: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001A3808: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001A380C: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001A3810: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001A3818: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001A381C: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001A3824: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001A3828: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001A3830: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001A3834: D5010023 00064680
	.long 0xd41b0001                                           // 0000001A383C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001A3840: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001A3848: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001A3850: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001A3854: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001A385C: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3868: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001A386C: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001A3874: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001A387C: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3884: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001A3888: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001A388C: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001A3890: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001A3894: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A389C: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001A38A0: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001A38A8: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001A38AC: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001A38B0: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001A38B8: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A38BC: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001A38C0: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001A38C8: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001A38CC: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001A38D4: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001A38DC: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A38E4: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001A38E8: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001A38F4: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001A38FC: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001A3908: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001A390C: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3910: BF870193
	.long 0x7e003999                                           // 0000001A3914: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001A3918: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001A391C: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001A3920: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001A3928: 7E4A399B
	.long 0x7f4a3980                                           // 0000001A392C: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001A3930: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001A3938: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001A393C: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001A3948: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001A394C: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001A3954: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001A3958: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001A3960: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A3968: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001A396C: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001A3974: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001A397C: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001A3980: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001A3984: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001A3988: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A3994: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001A3998: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001A39A0: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001A39A4: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001A39A8: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001A39AC: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001A39B4: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001A39BC: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001A39C4: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001A39D0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001A39D4: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A39DC: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001A39E0: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001A39E4: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A39E8: BF870005
	.long 0xd71c0021                                           // 0000001A39EC: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001A39F0: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001A39F4: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001A39F8: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001A3A00: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001A3A08: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001A3A10: D5010021 00064280
	.long 0xd41b0001                                           // 0000001A3A18: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001A3A1C: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001A3A24: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001A3A2C: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001A3A30: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001A3A34: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001A3A3C: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001A3A44: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001A3A50: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001A3A58: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001A3A5C: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001A3A60: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A3A68: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001A3A6C: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001A3A74: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001A3A78: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001A3A7C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A3A80: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001A3A84: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001A3A8C: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001A3A94: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001A3A9C: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001A3AA4: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001A3AA8: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001A3AB4: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001A3ABC: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001A3AC4: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001A3AC8: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001A3ACC: 7E6C472D
	.long 0x7e00399a                                           // 0000001A3AD0: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001A3AD4: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001A3AD8: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001A3AE0: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001A3AE8: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001A3AEC: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001A3AF0: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001A3AF8: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001A3B04: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001A3B08: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001A3B10: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001A3B14: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001A3B18: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A3B20: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001A3B24: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001A3B2C: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001A3B34: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001A3B40: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001A3B44: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001A3B48: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001A3B4C: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A3B50: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001A3B54: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001A3B5C: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001A3B68: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001A3B6C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001A3B70: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001A3B78: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001A3B80: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001A3B84: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001A3B8C: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001A3B90: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001A3B98: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001A3BA0: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001A3BA8: 10724D2E
	.long 0xd71c001e                                           // 0000001A3BAC: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001A3BB0: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001A3BB4: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A3BB8: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001A3BBC: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001A3BC4: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001A3BC8: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001A3BD0: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001A3BD8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001A3BDC: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001A3BE4: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001A3BEC: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001A3BF4: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001A3BF8: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001A3BFC: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001A3C08: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001A3C10: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001A3C18: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001A3C20: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001A3C24: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001A3C28: 063C3CF2
	.long 0xd41e0001                                           // 0000001A3C2C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001A3C30: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001A3C38: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001A3C44: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001A3C48: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001A3C4C: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001A3C50: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001A3C58: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001A3C60: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001A3C68: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001A3C74: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A3C78: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001A3C7C: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001A3C84: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001A3C8C: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001A3C90: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001A3C98: 06425321
	.long 0x7e003992                                           // 0000001A3C9C: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001A3CA0: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001A3CA4: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001A3CA8: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001A3CB4: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001A3CB8: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001A3CBC: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001A3CC4: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A3CCC: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001A3CD0: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001A3CDC: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001A3CE4: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A3CE8: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001A3CEC: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001A3CF0: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001A3CF8: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001A3CFC: 06565D2B
	.long 0xd71c0021                                           // 0000001A3D00: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001A3D04: 02025521
	.long 0x7e3a3991                                           // 0000001A3D08: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001A3D0C: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001A3D10: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001A3D1C: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001A3D20: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001A3D28: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A3D30: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001A3D34: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001A3D3C: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001A3D44: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001A3D50: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A3D54: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001A3D58: C8C04929 362C332C
	s_clause 0x1                                               // 0000001A3D60: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001A3D64: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001A3D6C: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001A3D74: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001A3D7C: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001A3D84: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3D88: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001A3D8C: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001A3D90: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001A3D98: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A3DA0: BF870004
	.long 0xd71c0022                                           // 0000001A3DA4: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001A3DA8: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001A3DAC: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001A3DB4: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001A3DBC: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001A3DC4: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001A3DCC: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001A3DD4: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3DD8: BF870214
	.long 0x7e3c3991                                           // 0000001A3DDC: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001A3DE0: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001A3DE4: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001A3DE8: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001A3DEC: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001A3DF4: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001A3DFC: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001A3E00: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001A3E04: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001A3E08: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001A3E0C: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001A3E14: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001A3E1C: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3E24: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001A3E28: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001A3E34: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3E38: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001A3E3C: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001A3E40: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001A3E44: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001A3E4C: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001A3E50: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A3E58: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001A3E5C: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001A3E68: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001A3E6C: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001A3E74: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001A3E80: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001A3E84: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001A3E88: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001A3E90: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001A3E94: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001A3E9C: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001A3EA4: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3EAC: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001A3EB0: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001A3EB4: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001A3EB8: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A3EC0: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001A3EC4: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001A3EC8: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001A3ED0: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001A3ED8: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001A3EDC: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001A3EE8: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3EEC: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001A3EF0: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001A3EF8: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A3F00: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001A3F04: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001A3F08: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A3F10: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001A3F14: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001A3F1C: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001A3F20: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001A3F24: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3F28: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001A3F2C: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001A3F34: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001A3F3C: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A3F44: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001A3F48: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001A3F50: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001A3F54: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001A3F58: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001A3F5C: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001A3F64: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001A3F6C: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001A3F74: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001A3F78: 30448C90
	.long 0x7e2a3991                                           // 0000001A3F7C: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001A3F80: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001A3F88: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001A3F90: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001A3F94: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001A3F98: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001A3FA0: 3032D090
	.long 0x7e003993                                           // 0000001A3FA4: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001A3FA8: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001A3FB0: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001A3FB4: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001A3FBC: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A3FC4: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001A3FC8: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001A3FD0: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001A3FDC: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001A3FE4: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A3FF0: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001A3FF4: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001A3FF8: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001A3FFC: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001A4008: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001A4014: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A4020: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001A4024: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001A4028: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001A402C: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001A4034: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A4038: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001A403C: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001A4044: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001A4048: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001A4054: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001A4058: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001A4060: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001A4064: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001A4068: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001A4070: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001A4074: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001A407C: 104C351D
	.long 0xd41e0001                                           // 0000001A4080: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001A4084: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001A408C: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001A4090: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001A4098: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001A409C: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001A40A4: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001A40A8: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001A40AC: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001A40B4: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001A40B8: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001A40C0: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001A40C4: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001A40CC: 564C3515
	.long 0xd41b0001                                           // 0000001A40D0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001A40D4: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001A40DC: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A40E4: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001A40E8: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001A40F0: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A40FC: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001A4100: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001A4108: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001A410C: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A4114: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001A4118: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001A4120: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001A4128: 563C4915
	.long 0xd71c0015                                           // 0000001A412C: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001A4130: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001A4134: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001A4138: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A4140: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001A4144: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001A414C: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001A4150: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001A4154: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A415C: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001A4160: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001A4168: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001A4170: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001A4174: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A4178: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001A417C: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001A4184: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001A418C: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001A4194: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001A419C: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001A41A4: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001A41A8: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001A41AC: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A41B8: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001A41BC: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001A41C4: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001A41C8: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001A41CC: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001A41D4: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001A41DC: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001A41E0: 08323D19
	.long 0x7e283989                                           // 0000001A41E4: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001A41E8: 7E2A5516
	.long 0x7f283980                                           // 0000001A41EC: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001A41F0: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001A41F4: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001A41F8: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001A4204: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001A4208: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001A4214: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001A4218: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001A4220: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001A4224: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001A422C: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001A4234: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001A4238: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001A4244: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001A4248: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001A424C: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001A4254: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001A425C: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001A4264: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001A4268: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001A426C: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001A4270: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001A4278: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001A427C: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001A4284: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001A428C: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001A4294: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001A429C: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001A42A0: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A42A8: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001A42AC: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001A42B0: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A42B8: BF870004
	.long 0xd71c0011                                           // 0000001A42BC: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001A42C0: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001A42C4: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001A42CC: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001A42D4: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001A42DC: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001A42E0: 30328690
	.long 0x7e2c398b                                           // 0000001A42E4: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001A42E8: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001A42EC: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001A42F0: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001A42F4: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001A42FC: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001A4304: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001A430C: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001A4310: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001A4318: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001A4324: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001A432C: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001A4334: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001A433C: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001A4340: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001A4344: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001A434C: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001A4350: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001A435C: 7E384713
	.long 0xd41e0001                                           // 0000001A4360: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001A4364: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001A436C: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001A4370: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001A4378: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001A4380: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001A4384: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001A438C: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001A4390: 7E42551A
	.long 0x7f2c3980                                           // 0000001A4394: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A4398: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001A439C: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001A43A4: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001A43AC: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001A43B4: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001A43B8: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001A43BC: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001A43C0: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001A43C4: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001A43CC: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A43D0: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001A43D4: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001A43E0: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A43E8: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001A43EC: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001A43F0: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001A43F8: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001A43FC: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001A4400: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001A4404: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001A4408: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001A440C: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001A4410: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001A441C: D5010013 00062680
	.long 0xd41b0001                                           // 0000001A4424: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001A4428: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001A4430: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001A4438: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001A4440: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001A4444: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001A4448: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001A4450: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001A445C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001A4460: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001A4468: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001A446C: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001A4474: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001A447C: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001A4480: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001A4488: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001A4490: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001A4498: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001A44A0: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001A44A8: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001A44B0: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001A44B4: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001A44B8: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001A44C0: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001A44C4: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001A44C8: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A44CC: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001A44D0: D627000C 043A2314
	.long 0x7e223989                                           // 0000001A44D8: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001A44DC: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001A44E4: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001A44E8: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001A44F0: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A44F4: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001A44F8: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001A4500: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001A4504: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001A4508: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A450C: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001A4510: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001A4514: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001A451C: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A4528: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001A452C: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001A4538: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001A4540: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A4544: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001A4548: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001A4550: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001A4554: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001A455C: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001A4564: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001A4570: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001A4578: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001A457C: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001A4584: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A4588: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001A458C: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001A4598: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A45A0: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001A45A4: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001A45AC: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001A45B8: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A45C0: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001A45C4: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001A45C8: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001A45CC: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001A45D4: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001A45DC: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001A45E0: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001A45E4: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001A45E8: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001A45EC: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001A45F0: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001A45F8: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001A45FC: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001A4600: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001A4604: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001A460C: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001A4614: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001A4618: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001A4620: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001A4624: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001A4628: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001A4634: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001A4638: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001A463C: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001A4648: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A464C: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001A4650: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001A465C: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001A4660: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001A4668: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001A466C: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001A4670: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001A4678: 0632331A
	.long 0xd71c000c                                           // 0000001A467C: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001A4680: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001A4684: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001A4688: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001A468C: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001A4694: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001A4698: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001A46A0: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001A46A8: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001A46AC: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001A46B0: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001A46B4: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001A46B8: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001A46C0: 7E443981
	.long 0x7f443980                                           // 0000001A46C4: 7F443980
	.long 0xd71c0012                                           // 0000001A46C8: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001A46CC: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001A46D0: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001A46D8: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001A46E0: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001A46E8: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001A46EC: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A46F0: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001A46F4: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001A46F8: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001A46FC: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001A4700: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001A4708: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001A470C: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001A4714: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001A471C: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001A4724: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A472C: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001A4730: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001A4734: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001A4738: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001A4740: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001A4748: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A474C: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001A4750: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001A4758: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001A475C: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001A4764: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001A4768: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001A4770: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001A4774: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001A477C: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001A4784: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001A478C: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001A4790: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001A4798: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001A479C: 5638391E
	.long 0x7e003982                                           // 0000001A47A0: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001A47A4: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001A47AC: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A47B4: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001A47B8: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001A47BC: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A47C4: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001A47C8: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001A47D0: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001A47D8: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A47E0: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001A47E4: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001A47EC: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001A47F0: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001A47F8: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001A47FC: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001A4800: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001A4808: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001A480C: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001A4810: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001A4818: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001A4820: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001A4828: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001A482C: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001A4834: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001A4838: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001A4840: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A4844: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001A4848: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001A4850: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A4858: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001A485C: D6270004 04121909
	.long 0x7f183980                                           // 0000001A4864: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001A4868: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001A4874: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001A487C: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001A4884: BEEA0002
	.long 0x7e003984                                           // 0000001A4888: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001A488C: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001A4898: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001A48A0: D6270005 0416250A
	.long 0x7e143983                                           // 0000001A48A8: 7E143983
	.long 0x7f143980                                           // 0000001A48AC: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001A48B0: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001A48B8: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001A48C0: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001A48C4: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001A48C8: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A48CC: BF870214
	.long 0x7e003986                                           // 0000001A48D0: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001A48D4: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A48D8: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001A48DC: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001A48E8: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001A48F4: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A48F8: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001A48FC: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001A4908: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001A4914: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001A4918: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001A4920: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001A4928: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001A4930: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001A4938: DC9600E0 007C0027
	s_nop 0                                                    // 0000001A4940: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001A4944: BFB60003
	s_endpgm                                                   // 0000001A4948: BFB00000
		...

