0000000000211a00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 000000211A00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 5                                       // 000000211A08: 84068503
	s_ashr_i32 s3, s2, 31                                      // 000000211A0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 000000211A10: 86079F06
	v_and_b32_e32 v1, 31, v0                                   // 000000211A14: 3602009F
	s_movk_i32 s5, 0x210                                       // 000000211A18: B0050210
	v_mov_b32_e32 v5, v0                                       // 000000211A1C: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000211A20: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000211A24: 30060282
	v_mad_u32_u24 v2, v1, s5, 0x4800                           // 000000211A28: D60B0002 03FC0B01 00004800
	s_waitcnt lgkmcnt(0)                                       // 000000211A34: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 000000211A38: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 000000211A40: 84928214
	s_add_u32 s8, s16, s18                                     // 000000211A44: 80081210
	s_addc_u32 s9, s17, s19                                    // 000000211A48: 82091311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 000000211A4C: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000211A50: BF870009
	s_add_u32 s8, s8, s34                                      // 000000211A54: 80082208
	s_addc_u32 s9, s9, s35                                     // 000000211A58: 82092309
	s_waitcnt lgkmcnt(0)                                       // 000000211A5C: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 000000211A60: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 000000211A68: 970FFF04 09000000
	s_add_u32 s4, s8, s33                                      // 000000211A70: 80042108
	s_addc_u32 s8, s9, s15                                     // 000000211A74: 82080F09
	s_lshl_b64 s[48:49], s[6:7], 2                             // 000000211A78: 84B08206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000211A7C: BF8700B9
	s_add_u32 s4, s4, s48                                      // 000000211A80: 80043004
	s_addc_u32 s5, s8, s49                                     // 000000211A84: 82053108
	.long 0xd7000403                                           // 000000211A88: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000211A8C: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 000000211A90: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 000000211A98: BE840080
	s_nop 0                                                    // 000000211A9C: BF800000
	s_nop 0                                                    // 000000211AA0: BF800000
	s_nop 0                                                    // 000000211AA4: BF800000
	s_nop 0                                                    // 000000211AA8: BF800000
	s_nop 0                                                    // 000000211AAC: BF800000
	s_nop 0                                                    // 000000211AB0: BF800000
	s_nop 0                                                    // 000000211AB4: BF800000
	s_nop 0                                                    // 000000211AB8: BF800000
	s_nop 0                                                    // 000000211ABC: BF800000
	v_lshrrev_b32_e32 v8, 5, v5                                // 000000211AC0: 32100A85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000211AC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 000000211AC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 000000211ACC: D6460008 04090508
	.long 0xd7006a06                                           // 000000211AD4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000211AD8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000211ADC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000211AE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v5                         // 000000211AE8: 7C920AFF 00000F7F
	global_load_b32 v6, v[6:7], off                            // 000000211AF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 000000211AF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000211B00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 000000211B04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 000000211B08: BF8903F7
	ds_store_b32 v8, v6                                        // 000000211B0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000211B14: 917E047E
	s_cbranch_execnz 65513                                     // 000000211B18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000211B1C: 8C7E047E
	s_load_b32 s50, s[0:1], 0x58                               // 000000211B20: F4000C80 F8000058
	v_or_b32_e32 v126, 0xffffff80, v0                          // 000000211B28: 38FC00FF FFFFFF80
	v_lshlrev_b32_e32 v125, 2, v1                              // 000000211B30: 30FA0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 000000211B34: 160602FF 00000210
	s_mov_b32 s4, 0                                            // 000000211B3C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000211B40: BF89FC07
	s_barrier                                                  // 000000211B44: BFBD0000
	buffer_gl0_inv                                             // 000000211B48: E0AC0000 00000000
	s_cmp_gt_i32 s50, 0                                        // 000000211B50: BF028032
	s_cbranch_scc1 17                                          // 000000211B54: BFA20011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x19c>
	v_dual_mov_b32 v114, 0 :: v_dual_lshlrev_b32 v1, 4, v0     // 000000211B58: CA220080 72000084
	v_lshrrev_b32_e32 v2, 3, v0                                // 000000211B60: 32040083
	v_or_b32_e32 v4, 0xffffff80, v0                            // 000000211B64: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000211B6C: BF870213
	v_and_b32_e32 v113, 0x600, v1                              // 000000211B70: 36E202FF 00000600
	v_mov_b32_e32 v141, v114                                   // 000000211B78: 7F1A0372
	s_delay_alu instid0(VALU_DEP_4)                            // 000000211B7C: BF870004
	v_and_or_b32 v136, v2, 12, v3                              // 000000211B80: D6570088 040D1902
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 000000211B88: CA100030 01020031
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000211B90: 916A047E
	s_cbranch_vccz 1                                           // 000000211B94: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x19c>
	s_branch 4850                                              // 000000211B98: BFA012F2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d64>
	s_clause 0x3                                               // 000000211B9C: BF850003
	s_load_b128 s[28:31], s[0:1], 0x10                         // 000000211BA0: F4080700 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000211BA8: F4040200 F8000020
	s_load_b64 s[10:11], s[0:1], 0x70                          // 000000211BB0: F4040280 F8000070
	s_load_b128 s[44:47], s[0:1], 0x60                         // 000000211BB8: F4080B00 F8000060
	v_lshrrev_b32_e32 v6, 4, v0                                // 000000211BC0: 320C0084
	v_mov_b32_e32 v114, 0                                      // 000000211BC4: 7EE40280
	s_add_i32 s5, s50, 63                                      // 000000211BC8: 8105BF32
	s_add_i32 s52, s50, -1                                     // 000000211BCC: 8134C132
	s_lshr_b32 s53, s5, 6                                      // 000000211BD0: 85358605
	v_and_b32_e32 v9, 4, v6                                    // 000000211BD4: 36120C84
	v_dual_mov_b32 v141, v114 :: v_dual_lshlrev_b32 v2, 2, v0  // 000000211BD8: CA220172 8D020082
	s_mul_i32 s5, s52, 48                                      // 000000211BE0: 9605B034
	s_add_i32 s51, s2, 0xbd0                                   // 000000211BE4: 8133FF02 00000BD0
	s_mul_hi_u32 s13, s52, 48                                  // 000000211BEC: 968DB034
	s_add_u32 s12, s5, s2                                      // 000000211BF0: 800C0205
	s_addc_u32 s13, s13, s3                                    // 000000211BF4: 820D030D
	v_and_b32_e32 v4, 15, v0                                   // 000000211BF8: 3608008F
	s_lshl_b64 s[12:13], s[12:13], 9                           // 000000211BFC: 848C890C
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000211C00: 32020085
	s_waitcnt lgkmcnt(0)                                       // 000000211C04: BF89FC07
	.long 0xd7000581                                           // 000000211C08: D7000581
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000211C0C: 0202041C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000211C10: BF8701A1
	v_add_co_ci_u32_e64 v130, null, s29, 0, s5                 // 000000211C14: D5207C82 0015001D
	v_or_b32_e32 v127, 0x9c00, v2                              // 000000211C1C: 38FE04FF 00009C00
	.long 0xd7000583                                           // 000000211C24: D7000583
	v_cndmask_b32_e32 v0, v129, v12, vcc_lo                    // 000000211C28: 02001981
	s_delay_alu instid0(VALU_DEP_1)                            // 000000211C2C: BF870001
	v_add_co_ci_u32_e64 v132, null, s13, v130, s5              // 000000211C30: D5207C84 0017040D
	s_movk_i32 s5, 0x210                                       // 000000211C38: B0050210
	s_mov_b32 s13, 0x8a00                                      // 000000211C3C: BE8D00FF 00008A00
	v_mad_u32_u24 v135, v4, s5, 0x4800                         // 000000211C44: D60B0087 03FC0B04 00004800
	s_add_u32 s5, s8, s48                                      // 000000211C50: 80053008
	s_addc_u32 s12, s9, s49                                    // 000000211C54: 820C3109
	s_lshl_b32 s8, s2, 7                                       // 000000211C58: 84088702
	v_add_nc_u32_e32 v128, 0x9d00, v2                          // 000000211C5C: 4B0004FF 00009D00
	v_lshlrev_b32_e32 v2, 4, v1                                // 000000211C64: 30040284
	v_bfe_u32 v5, v0, 4, 1                                     // 000000211C68: D6100005 02050900
	v_bfe_u32 v7, v0, 5, 1                                     // 000000211C70: D6100007 02050B00
	v_mad_u32_u24 v138, 0x90, v4, s13                          // 000000211C78: D60B008A 003608FF 00000090
	s_ashr_i32 s9, s8, 31                                      // 000000211C84: 86099F08
	v_or_b32_e32 v134, v2, v4                                  // 000000211C88: 390C0902
	s_lshl_b64 s[8:9], s[8:9], 1                               // 000000211C8C: 84888108
	v_or_b32_e32 v137, v5, v2                                  // 000000211C90: 39120505
	v_mul_u32_u24_e32 v2, 0x90, v4                             // 000000211C94: 160408FF 00000090
	s_add_u32 s8, s22, s8                                      // 000000211C9C: 80080816
	v_mad_u32_u24 v8, 0x2100, v7, v135                         // 000000211CA0: D60B0008 061E0EFF 00002100
	v_mad_u32_u24 v139, 0x900, v7, v138                        // 000000211CAC: D60B008B 062A0EFF 00000900
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000211CB8: 300E0882
	v_lshlrev_b32_e32 v4, 1, v4                                // 000000211CBC: 30080881
	s_addc_u32 s9, s23, s9                                     // 000000211CC0: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 000000211CC4: 84868106
	s_load_b256 s[36:43], s[0:1], 0x80                         // 000000211CC8: F40C0900 F8000080
	s_add_u32 s8, s8, s6                                       // 000000211CD0: 80080608
	s_addc_u32 s7, s9, s7                                      // 000000211CD4: 82070709
	.long 0xd7000873                                           // 000000211CD8: D7000873
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000211CDC: 02020808
	s_delay_alu instid0(VALU_DEP_1)                            // 000000211CE0: BF870001
	v_add_co_ci_u32_e64 v116, null, s7, 0, s8                  // 000000211CE4: D5207C74 00210007
	s_load_b64 s[8:9], s[0:1], 0xa0                            // 000000211CEC: F4040200 F80000A0
	v_lshl_or_b32 v140, v5, 2, v8                              // 000000211CF4: D656008C 04210505
	v_lshlrev_b32_e32 v5, 1, v137                              // 000000211CFC: 300B1281
	v_lshlrev_b32_e32 v113, 9, v1                              // 000000211D00: 30E20289
	s_add_u32 s0, s48, s34                                     // 000000211D04: 80002230
	v_lshlrev_b32_e32 v148, 6, v9                              // 000000211D08: 31281286
	s_addc_u32 s1, s49, s35                                    // 000000211D0C: 82012331
	v_add_nc_u32_e32 v144, v138, v5                            // 000000211D10: 4B200B8A
	v_add3_u32 v145, v2, v5, 0x8a00                            // 000000211D14: D6550091 03FE0B02 00008A00
	v_mul_u32_u24_e32 v5, 0x900, v9                            // 000000211D20: 160A12FF 00000900
	.long 0xd7000009                                           // 000000211D28: D7000009
	v_cndmask_b32_e32 v1, s0, v113, vcc_lo                     // 000000211D2C: 0202E200
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000211D30: BF8701A1
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 000000211D34: D5207C0A 00010001
	v_lshlrev_b32_e32 v8, 7, v134                              // 000000211D3C: 30110C87
	.long 0xd7000009                                           // 000000211D40: D7000009
	v_cndmask_b32_e32 v1, v9, v125, vcc_lo                     // 000000211D44: 0202FB09
	v_or_b32_e32 v4, 3, v6                                     // 000000211D48: 38080C83
	s_delay_alu instid0(VALU_DEP_4)                            // 000000211D4C: BF870004
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000211D50: D5207C0A 00021480
	.long 0xd700058e                                           // 000000211D58: D700058E
	v_cndmask_b32_e32 v1, s5, v7, vcc_lo                       // 000000211D5C: 02020E05
	s_waitcnt lgkmcnt(0)                                       // 000000211D60: BF89FC07
	.long 0xd7000075                                           // 000000211D64: D7000075
	v_cndmask_b32_e32 v1, s40, v9, vcc_lo                      // 000000211D68: 02021228
	v_add_co_ci_u32_e64 v143, null, s12, 0, s5                 // 000000211D6C: D5207C8F 0015000C
	.long 0xd7000592                                           // 000000211D74: D7000592
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 000000211D78: 0202100A
	v_or_b32_e32 v6, 64, v148                                  // 000000211D7C: 380D28C0
	v_or_b32_e32 v7, 0x80, v148                                // 000000211D80: 380F28FF 00000080
	v_mul_u32_u24_e32 v8, 0x900, v4                            // 000000211D88: 161008FF 00000900
	v_lshlrev_b32_e32 v4, 6, v4                                // 000000211D90: 30080886
	v_add_co_ci_u32_e64 v118, null, s41, v10, s0               // 000000211D94: D5207C76 00021429
	.long 0xd7000077                                           // 000000211D9C: D7000077
	v_cndmask_b32_e32 v1, s42, v9, vcc_lo                      // 000000211DA0: 0202122A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000211DA4: BF870001
	v_add_co_ci_u32_e64 v120, null, s43, v10, s0               // 000000211DA8: D5207C78 0002142B
	.long 0xd7000079                                           // 000000211DB0: D7000079
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000211DB4: 02021208
	.long 0xd4490004                                           // 000000211DB8: D4490004
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 000000211DBC: 020200BF
	v_mul_u32_u24_e32 v133, 0x90, v0                           // 000000211DC0: 170A00FF 00000090
	v_add_co_ci_u32_e64 v147, null, s11, 0, s5                 // 000000211DC8: D5207C93 0015000B
	.long 0xd44d0005                                           // 000000211DD0: D44D0005
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000211DD4: 02020280
	.long 0xd4490006                                           // 000000211DD8: D4490006
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 000000211DDC: 020200FF 0000005F
	v_lshl_or_b32 v149, v137, 2, 0x9d00                        // 000000211DE4: D6560095 03FD0589 00009D00
	v_lshl_or_b32 v136, v1, 2, v3                              // 000000211DF0: D6560088 040D0501
	v_add_co_ci_u32_e64 v122, null, s9, v10, s0                // 000000211DF8: D5207C7A 00021409
	v_add_nc_u32_e32 v150, v2, v5                              // 000000211E00: 4B2C0B02
	v_add_nc_u32_e32 v151, v140, v6                            // 000000211E04: 4B2E0D8C
	v_add_nc_u32_e32 v152, v140, v7                            // 000000211E08: 4B300F8C
	v_add_nc_u32_e32 v153, v2, v8                              // 000000211E0C: 4B321102
	v_add_nc_u32_e32 v154, v140, v4                            // 000000211E10: 4B34098C
	s_mov_b32 s20, 0                                           // 000000211E14: BE940080
	s_mov_b32 s39, 0x41800000                                  // 000000211E18: BEA700FF 41800000
	s_mov_b32 s21, s20                                         // 000000211E20: BE950014
	s_mov_b32 s22, s20                                         // 000000211E24: BE960014
	s_mov_b32 s23, s20                                         // 000000211E28: BE970014
	s_mov_b32 s24, s20                                         // 000000211E2C: BE980014
	s_mov_b32 s25, s20                                         // 000000211E30: BE990014
	s_mov_b32 s26, s20                                         // 000000211E34: BE9A0014
	s_mov_b32 s27, s20                                         // 000000211E38: BE9B0014
	s_mov_b32 s40, s20                                         // 000000211E3C: BEA80014
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000211E40: 7C9800C0
	s_branch 4                                                 // 000000211E44: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x458>
	s_add_i32 s40, s40, 1                                      // 000000211E48: 81288128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000211E4C: BF870009
	s_cmp_eq_u32 s40, s53                                      // 000000211E50: BF063528
	s_cbranch_scc1 4672                                        // 000000211E54: BFA21240 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d58>
	s_mul_i32 s8, s40, 0xc00                                   // 000000211E58: 9608FF28 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000211E60: BF870499
	s_add_i32 s0, s51, s8                                      // 000000211E64: 81000833
	s_ashr_i32 s1, s0, 31                                      // 000000211E68: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000211E6C: BF870009
	s_lshl_b64 s[10:11], s[0:1], 2                             // 000000211E70: 848A8200
	s_lshl_b32 s1, s40, 6                                      // 000000211E74: 84018628
	s_add_u32 s10, s30, s10                                    // 000000211E78: 800A0A1E
	s_addc_u32 s11, s31, s11                                   // 000000211E7C: 820B0B1F
	global_load_b32 v1, v114, s[10:11]                         // 000000211E80: DC520000 010A0072
	s_waitcnt vmcnt(0)                                         // 000000211E88: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 000000211E8C: 7E520501
	s_and_saveexec_b32 s7, vcc_lo                              // 000000211E90: BE87206A
	s_cbranch_execz 77                                         // 000000211E94: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5cc>
	v_or_b32_e32 v1, s1, v0                                    // 000000211E98: 38020001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000211E9C: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 000000211EA0: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000211EA8: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000211EAC: BF870091
	.long 0xd73c0001                                           // 000000211EB0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000211EB4: 02020282
	.long 0xd7000001                                           // 000000211EB8: D7000001
	v_cndmask_b32_e32 v1, s30, v1, vcc_lo                      // 000000211EBC: 0202021E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000211EC0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s31, v2, s0                  // 000000211EC4: D5207C02 0002041F
	global_load_b32 v1, v[1:2], off                            // 000000211ECC: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000211ED4: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 000000211ED8: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 000000211EDC: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000211EE8: BF8701A1
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 000000211EEC: D6130007 841202FF 3FB8AA3B
	v_rndne_f32_e32 v8, v4                                     // 000000211EF8: 7E104704
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 000000211EFC: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 000000211F08: 7E0C4703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000211F0C: BF870113
	v_dual_fmac_f32 v7, 0x32a5705f, v1 :: v_dual_sub_f32 v4, v4, v8// 000000211F10: C80A02FF 07041104 32A5705F
	v_sub_f32_e32 v3, v3, v6                                   // 000000211F1C: 08060D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000211F20: BF870124
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 000000211F24: 560A04FF 32A5705F
	.long 0xd41b0000                                           // 000000211F2C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v2, vcc_lo               // 000000211F30: 020204FF C2CE8ED0
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v3, v3, v5     // 000000211F38: C9080F04 04020B03
	v_cvt_i32_f32_e32 v5, v6                                   // 000000211F40: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 000000211F44: 7E0C1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000211F48: BF870193
	v_exp_f32_e32 v4, v4                                       // 000000211F4C: 7E084B04
	v_exp_f32_e32 v3, v3                                       // 000000211F50: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000211F54: BF870296
	.long 0xd71c0004                                           // 000000211F58: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000211F5C: 02020D04
	.long 0xd71c0003                                           // 000000211F60: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000211F64: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000211F68: BF8700A1
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 000000211F6C: D5010003 00020680
	.long 0xd41b0000                                           // 000000211F74: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v1, vcc_lo               // 000000211F78: 020202FF C2CE8ED0
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 000000211F80: D5010004 00020880
	.long 0xd41e0000                                           // 000000211F88: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v2, vcc_lo               // 000000211F8C: 020204FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000211F94: BF8700A1
	v_cndmask_b32_e64 v2, 0x7f800000, v3, s0                   // 000000211F98: D5010002 000206FF 7F800000
	.long 0xd41e0000                                           // 000000211FA4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v1, vcc_lo               // 000000211FA8: 020202FF 42B17218
	v_cndmask_b32_e64 v1, 0x7f800000, v4, s0                   // 000000211FB0: D5010001 000208FF 7F800000
	ds_store_b32 v127, v2                                      // 000000211FBC: D8340000 0000027F
	ds_store_b32 v128, v1                                      // 000000211FC4: D8340000 00000180
	s_or_b32 exec_lo, exec_lo, s7                              // 000000211FCC: 8C7E077E
	s_sub_i32 s7, s50, s1                                      // 000000211FD0: 81870132
	s_mul_hi_u32 s0, s40, 0xc00                                // 000000211FD4: 9680FF28 00000C00
	s_add_u32 s28, s8, s2                                      // 000000211FDC: 801C0208
	s_addc_u32 s29, s0, s3                                     // 000000211FE0: 821D0300
	.long 0x7ea23880                                           // 000000211FE4: 7EA23880
	s_lshl_b64 s[8:9], s[28:29], 9                             // 000000211FE8: 8488891C
	s_cmp_gt_i32 s7, 0                                         // 000000211FEC: BF028007
	.long 0xd7000001                                           // 000000211FF0: D7000001
	v_cndmask_b32_e32 v0, v129, v8, vcc_lo                     // 000000211FF4: 02001181
	s_delay_alu instid0(VALU_DEP_1)                            // 000000211FF8: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v130, s0                 // 000000211FFC: D5207C02 00030409
	s_cselect_b32 s0, -1, 0                                    // 000000212004: 980080C1
	s_cmp_gt_i32 s7, 1                                         // 000000212008: BF028107
	v_cndmask_b32_e64 v3, v131, v1, s0                         // 00000021200C: D5010003 00020383
	v_cndmask_b32_e64 v4, v132, v2, s0                         // 000000212014: D5010004 00020584
	global_load_b32 v25, v[3:4], off                           // 00000021201C: DC520000 197C0003
	.long 0xd7000003                                           // 000000212024: D7000003
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 000000212028: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212030: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 000000212034: D5207C04 00020480
	.long 0xd7000005                                           // 00000021203C: D7000005
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 000000212040: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212048: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212050: 980080C1
	s_cmp_gt_i32 s7, 2                                         // 000000212054: BF028207
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212058: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212060: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212068: 980080C1
	s_cmp_gt_i32 s7, 3                                         // 00000021206C: BF028307
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212070: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212078: D5010005 00020B83
	.long 0xd7000007                                           // 000000212080: D7000007
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 000000212084: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021208C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212090: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212098: 980080C1
	global_load_b32 v26, v[3:4], off                           // 00000021209C: DC520000 1A7C0003
	global_load_b32 v27, v[5:6], off                           // 0000002120A4: DC520000 1B7C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 0000002120AC: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 0000002120B4: D5010003 00020F83
	.long 0xd7000005                                           // 0000002120BC: D7000005
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000002120C0: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002120C8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002120CC: D5207C06 00020480
	.long 0xd7000007                                           // 0000002120D4: D7000007
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000002120D8: 020202FF 0001E000
	s_cmp_gt_i32 s7, 4                                         // 0000002120E0: BF028407
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000002120E4: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002120EC: 980080C1
	s_cmp_gt_i32 s7, 5                                         // 0000002120F0: BF028507
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002120F4: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002120FC: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212104: 980080C1
	s_cmp_gt_i32 s7, 6                                         // 000000212108: BF028607
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 00000021210C: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212114: D5010007 00020F83
	.long 0xd7000009                                           // 00000021211C: D7000009
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 000000212120: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212128: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 00000021212C: D5207C0A 00020480
	.long 0xd700000b                                           // 000000212134: D700000B
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 000000212138: 020202FF 0002A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212140: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212148: 980080C1
	s_cmp_gt_i32 s7, 7                                         // 00000021214C: BF028707
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 000000212150: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 000000212158: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212160: 980080C1
	s_cmp_gt_i32 s7, 8                                         // 000000212164: BF028807
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 000000212168: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 000000212170: D501000B 00021783
	global_load_b32 v28, v[3:4], off                           // 000000212178: DC520000 1C7C0003
	global_load_b32 v29, v[5:6], off                           // 000000212180: DC520000 1D7C0005
	global_load_b32 v30, v[7:8], off                           // 000000212188: DC520000 1E7C0007
	global_load_b32 v31, v[9:10], off                          // 000000212190: DC520000 1F7C0009
	global_load_b32 v32, v[11:12], off                         // 000000212198: DC520000 207C000B
	.long 0xd7000003                                           // 0000002121A0: D7000003
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000002121A4: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002121AC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000002121B0: D5207C04 00020480
	.long 0xd7000005                                           // 0000002121B8: D7000005
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000002121BC: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002121C4: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002121CC: 980080C1
	s_cmp_gt_i32 s7, 9                                         // 0000002121D0: BF028907
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 0000002121D4: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 0000002121DC: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 0000002121E4: 980080C1
	s_cmp_gt_i32 s7, 10                                        // 0000002121E8: BF028A07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002121EC: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002121F4: D5010005 00020B83
	.long 0xd7000007                                           // 0000002121FC: D7000007
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 000000212200: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212208: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 00000021220C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212214: 980080C1
	global_load_b32 v49, v[3:4], off                           // 000000212218: DC520000 317C0003
	global_load_b32 v50, v[5:6], off                           // 000000212220: DC520000 327C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212228: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 000000212230: D5010003 00020F83
	.long 0xd7000005                                           // 000000212238: D7000005
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 00000021223C: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212244: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212248: D5207C06 00020480
	.long 0xd7000007                                           // 000000212250: D7000007
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 000000212254: 020202FF 00048000
	s_cmp_gt_i32 s7, 11                                        // 00000021225C: BF028B07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212260: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212268: 980080C1
	s_cmp_gt_i32 s7, 12                                        // 00000021226C: BF028C07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212270: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212278: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212280: 980080C1
	s_cmp_gt_i32 s7, 13                                        // 000000212284: BF028D07
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212288: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212290: D5010007 00020F83
	.long 0xd7000009                                           // 000000212298: D7000009
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 00000021229C: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002122A4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000002122A8: D5207C0A 00020480
	.long 0xd700000b                                           // 0000002122B0: D700000B
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000002122B4: 020202FF 00054000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000002122BC: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002122C4: 980080C1
	s_cmp_gt_i32 s7, 14                                        // 0000002122C8: BF028E07
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 0000002122CC: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 0000002122D4: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 0000002122DC: 980080C1
	s_cmp_gt_i32 s7, 15                                        // 0000002122E0: BF028F07
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 0000002122E4: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 0000002122EC: D501000B 00021783
	global_load_b32 v51, v[3:4], off                           // 0000002122F4: DC520000 337C0003
	global_load_b32 v52, v[5:6], off                           // 0000002122FC: DC520000 347C0005
	global_load_b32 v53, v[7:8], off                           // 000000212304: DC520000 357C0007
	global_load_b32 v54, v[9:10], off                          // 00000021230C: DC520000 367C0009
	global_load_b32 v55, v[11:12], off                         // 000000212314: DC520000 377C000B
	.long 0xd7000003                                           // 00000021231C: D7000003
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 000000212320: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212328: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 00000021232C: D5207C04 00020480
	.long 0xd7000005                                           // 000000212334: D7000005
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 000000212338: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212340: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212348: 980080C1
	s_cmp_gt_i32 s7, 16                                        // 00000021234C: BF029007
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212350: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212358: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212360: 980080C1
	s_cmp_gt_i32 s7, 17                                        // 000000212364: BF029107
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212368: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212370: D5010005 00020B83
	.long 0xd7000007                                           // 000000212378: D7000007
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 00000021237C: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212384: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212388: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212390: 980080C1
	global_load_b32 v56, v[3:4], off                           // 000000212394: DC520000 387C0003
	global_load_b32 v84, v[5:6], off                           // 00000021239C: DC520000 547C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 0000002123A4: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 0000002123AC: D5010003 00020F83
	.long 0xd7000005                                           // 0000002123B4: D7000005
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000002123B8: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002123C0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002123C4: D5207C06 00020480
	.long 0xd7000007                                           // 0000002123CC: D7000007
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000002123D0: 020202FF 00072000
	s_cmp_gt_i32 s7, 18                                        // 0000002123D8: BF029207
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000002123DC: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002123E4: 980080C1
	s_cmp_gt_i32 s7, 19                                        // 0000002123E8: BF029307
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002123EC: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002123F4: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 0000002123FC: 980080C1
	s_cmp_gt_i32 s7, 20                                        // 000000212400: BF029407
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212404: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 00000021240C: D5010007 00020F83
	.long 0xd7000009                                           // 000000212414: D7000009
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 000000212418: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212420: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 000000212424: D5207C0A 00020480
	.long 0xd700000b                                           // 00000021242C: D700000B
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 000000212430: 020202FF 0007E000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212438: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212440: 980080C1
	s_cmp_gt_i32 s7, 21                                        // 000000212444: BF029507
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 000000212448: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 000000212450: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212458: 980080C1
	s_cmp_gt_i32 s7, 22                                        // 00000021245C: BF029607
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 000000212460: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 000000212468: D501000B 00021783
	global_load_b32 v91, v[3:4], off                           // 000000212470: DC520000 5B7C0003
	global_load_b32 v92, v[5:6], off                           // 000000212478: DC520000 5C7C0005
	global_load_b32 v93, v[7:8], off                           // 000000212480: DC520000 5D7C0007
	global_load_b32 v85, v[9:10], off                          // 000000212488: DC520000 557C0009
	global_load_b32 v86, v[11:12], off                         // 000000212490: DC520000 567C000B
	.long 0xd7000003                                           // 000000212498: D7000003
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 00000021249C: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002124A4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000002124A8: D5207C04 00020480
	.long 0xd7000005                                           // 0000002124B0: D7000005
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000002124B4: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002124BC: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002124C4: 980080C1
	s_cmp_gt_i32 s7, 23                                        // 0000002124C8: BF029707
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 0000002124CC: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 0000002124D4: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 0000002124DC: 980080C1
	s_cmp_gt_i32 s7, 24                                        // 0000002124E0: BF029807
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002124E4: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002124EC: D5010005 00020B83
	.long 0xd7000007                                           // 0000002124F4: D7000007
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000002124F8: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212500: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212504: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 00000021250C: 980080C1
	global_load_b32 v88, v[3:4], off                           // 000000212510: DC520000 587C0003
	global_load_b32 v87, v[5:6], off                           // 000000212518: DC520000 577C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212520: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 000000212528: D5010003 00020F83
	.long 0xd7000005                                           // 000000212530: D7000005
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 000000212534: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021253C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212540: D5207C06 00020480
	.long 0xd7000007                                           // 000000212548: D7000007
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 00000021254C: 020202FF 0009C000
	s_cmp_gt_i32 s7, 25                                        // 000000212554: BF029907
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212558: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212560: 980080C1
	s_cmp_gt_i32 s7, 26                                        // 000000212564: BF029A07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212568: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212570: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212578: 980080C1
	s_cmp_gt_i32 s7, 27                                        // 00000021257C: BF029B07
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212580: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212588: D5010007 00020F83
	.long 0xd7000009                                           // 000000212590: D7000009
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 000000212594: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000021259C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000002125A0: D5207C0A 00020480
	.long 0xd700000b                                           // 0000002125A8: D700000B
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000002125AC: 020202FF 000A8000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000002125B4: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002125BC: 980080C1
	s_cmp_gt_i32 s7, 28                                        // 0000002125C0: BF029C07
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 0000002125C4: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 0000002125CC: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 0000002125D4: 980080C1
	s_cmp_gt_i32 s7, 29                                        // 0000002125D8: BF029D07
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 0000002125DC: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 0000002125E4: D501000B 00021783
	global_load_b32 v98, v[3:4], off                           // 0000002125EC: DC520000 627C0003
	global_load_b32 v95, v[5:6], off                           // 0000002125F4: DC520000 5F7C0005
	global_load_b32 v94, v[7:8], off                           // 0000002125FC: DC520000 5E7C0007
	global_load_b32 v89, v[9:10], off                          // 000000212604: DC520000 597C0009
	global_load_b32 v90, v[11:12], off                         // 00000021260C: DC520000 5A7C000B
	.long 0xd7000003                                           // 000000212614: D7000003
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 000000212618: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212620: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 000000212624: D5207C04 00020480
	.long 0xd7000005                                           // 00000021262C: D7000005
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 000000212630: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212638: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212640: 980080C1
	s_cmp_gt_i32 s7, 30                                        // 000000212644: BF029E07
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212648: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212650: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212658: 980080C1
	s_cmp_gt_i32 s7, 31                                        // 00000021265C: BF029F07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212660: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212668: D5010005 00020B83
	.long 0xd7000007                                           // 000000212670: D7000007
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 000000212674: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021267C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212680: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212688: 980080C1
	global_load_b32 v96, v[3:4], off                           // 00000021268C: DC520000 607C0003
	global_load_b32 v97, v[5:6], off                           // 000000212694: DC520000 617C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 00000021269C: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 0000002126A4: D5010003 00020F83
	.long 0xd7000005                                           // 0000002126AC: D7000005
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000002126B0: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002126B8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002126BC: D5207C06 00020480
	.long 0xd7000007                                           // 0000002126C4: D7000007
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000002126C8: 020202FF 000C6000
	s_cmp_gt_i32 s7, 32                                        // 0000002126D0: BF02A007
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000002126D4: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002126DC: 980080C1
	s_cmp_gt_i32 s7, 33                                        // 0000002126E0: BF02A107
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002126E4: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002126EC: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 0000002126F4: 980080C1
	s_cmp_gt_i32 s7, 34                                        // 0000002126F8: BF02A207
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 0000002126FC: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212704: D5010007 00020F83
	.long 0xd7000009                                           // 00000021270C: D7000009
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 000000212710: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212718: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 00000021271C: D5207C0A 00020480
	.long 0xd700000b                                           // 000000212724: D700000B
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 000000212728: 020202FF 000D2000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212730: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212738: 980080C1
	s_cmp_gt_i32 s7, 35                                        // 00000021273C: BF02A307
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 000000212740: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 000000212748: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212750: 980080C1
	s_cmp_gt_i32 s7, 36                                        // 000000212754: BF02A407
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 000000212758: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 000000212760: D501000B 00021783
	global_load_b32 v105, v[3:4], off                          // 000000212768: DC520000 697C0003
	global_load_b32 v102, v[5:6], off                          // 000000212770: DC520000 667C0005
	global_load_b32 v101, v[7:8], off                          // 000000212778: DC520000 657C0007
	global_load_b32 v99, v[9:10], off                          // 000000212780: DC520000 637C0009
	global_load_b32 v100, v[11:12], off                        // 000000212788: DC520000 647C000B
	.long 0xd7000003                                           // 000000212790: D7000003
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 000000212794: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000021279C: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000002127A0: D5207C04 00020480
	.long 0xd7000005                                           // 0000002127A8: D7000005
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000002127AC: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002127B4: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002127BC: 980080C1
	s_cmp_gt_i32 s7, 37                                        // 0000002127C0: BF02A507
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 0000002127C4: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 0000002127CC: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 0000002127D4: 980080C1
	s_cmp_gt_i32 s7, 38                                        // 0000002127D8: BF02A607
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002127DC: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002127E4: D5010005 00020B83
	.long 0xd7000007                                           // 0000002127EC: D7000007
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000002127F0: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002127F8: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000002127FC: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212804: 980080C1
	global_load_b32 v104, v[3:4], off                          // 000000212808: DC520000 687C0003
	global_load_b32 v103, v[5:6], off                          // 000000212810: DC520000 677C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212818: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 000000212820: D5010003 00020F83
	.long 0xd7000005                                           // 000000212828: D7000005
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 00000021282C: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212834: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212838: D5207C06 00020480
	.long 0xd7000007                                           // 000000212840: D7000007
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 000000212844: 020202FF 000F0000
	s_cmp_gt_i32 s7, 39                                        // 00000021284C: BF02A707
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212850: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212858: 980080C1
	s_cmp_gt_i32 s7, 40                                        // 00000021285C: BF02A807
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212860: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212868: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212870: 980080C1
	s_cmp_gt_i32 s7, 41                                        // 000000212874: BF02A907
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212878: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212880: D5010007 00020F83
	.long 0xd7000009                                           // 000000212888: D7000009
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 00000021288C: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212894: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 000000212898: D5207C0A 00020480
	.long 0xd700000b                                           // 0000002128A0: D700000B
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000002128A4: 020202FF 000FC000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000002128AC: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002128B4: 980080C1
	s_cmp_gt_i32 s7, 42                                        // 0000002128B8: BF02AA07
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 0000002128BC: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 0000002128C4: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 0000002128CC: 980080C1
	s_cmp_gt_i32 s7, 43                                        // 0000002128D0: BF02AB07
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 0000002128D4: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 0000002128DC: D501000B 00021783
	global_load_b32 v111, v[3:4], off                          // 0000002128E4: DC520000 6F7C0003
	global_load_b32 v110, v[5:6], off                          // 0000002128EC: DC520000 6E7C0005
	global_load_b32 v108, v[7:8], off                          // 0000002128F4: DC520000 6C7C0007
	global_load_b32 v107, v[9:10], off                         // 0000002128FC: DC520000 6B7C0009
	global_load_b32 v106, v[11:12], off                        // 000000212904: DC520000 6A7C000B
	.long 0xd7000003                                           // 00000021290C: D7000003
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 000000212910: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212918: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 00000021291C: D5207C04 00020480
	.long 0xd7000005                                           // 000000212924: D7000005
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 000000212928: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212930: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212938: 980080C1
	s_cmp_gt_i32 s7, 44                                        // 00000021293C: BF02AC07
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212940: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212948: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212950: 980080C1
	s_cmp_gt_i32 s7, 45                                        // 000000212954: BF02AD07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212958: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212960: D5010005 00020B83
	.long 0xd7000007                                           // 000000212968: D7000007
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 00000021296C: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212974: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212978: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212980: 980080C1
	global_load_b32 v112, v[3:4], off                          // 000000212984: DC520000 707C0003
	global_load_b32 v109, v[5:6], off                          // 00000021298C: DC520000 6D7C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212994: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 00000021299C: D5010003 00020F83
	.long 0xd7000005                                           // 0000002129A4: D7000005
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000002129A8: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002129B0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000002129B4: D5207C06 00020480
	.long 0xd7000007                                           // 0000002129BC: D7000007
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000002129C0: 020202FF 0011A000
	s_cmp_gt_i32 s7, 46                                        // 0000002129C8: BF02AE07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000002129CC: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000002129D4: 980080C1
	s_cmp_gt_i32 s7, 47                                        // 0000002129D8: BF02AF07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 0000002129DC: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 0000002129E4: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 0000002129EC: 980080C1
	s_cmp_gt_i32 s7, 48                                        // 0000002129F0: BF02B007
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 0000002129F4: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 0000002129FC: D5010007 00020F83
	.long 0xd7000009                                           // 000000212A04: D7000009
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 000000212A08: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212A10: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 000000212A14: D5207C0A 00020480
	.long 0xd700000b                                           // 000000212A1C: D700000B
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 000000212A20: 020202FF 00126000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212A28: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212A30: 980080C1
	s_cmp_gt_i32 s7, 49                                        // 000000212A34: BF02B107
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 000000212A38: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 000000212A40: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212A48: 980080C1
	s_cmp_gt_i32 s7, 50                                        // 000000212A4C: BF02B207
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 000000212A50: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 000000212A58: D501000B 00021783
	global_load_b32 v158, v[3:4], off                          // 000000212A60: DC520000 9E7C0003
	global_load_b32 v156, v[5:6], off                          // 000000212A68: DC520000 9C7C0005
	global_load_b32 v155, v[7:8], off                          // 000000212A70: DC520000 9B7C0007
	global_load_b32 v124, v[9:10], off                         // 000000212A78: DC520000 7C7C0009
	global_load_b32 v123, v[11:12], off                        // 000000212A80: DC520000 7B7C000B
	.long 0xd7000003                                           // 000000212A88: D7000003
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 000000212A8C: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212A94: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 000000212A98: D5207C04 00020480
	.long 0xd7000005                                           // 000000212AA0: D7000005
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 000000212AA4: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212AAC: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212AB4: 980080C1
	s_cmp_gt_i32 s7, 51                                        // 000000212AB8: BF02B307
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212ABC: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212AC4: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212ACC: 980080C1
	s_cmp_gt_i32 s7, 52                                        // 000000212AD0: BF02B407
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212AD4: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212ADC: D5010005 00020B83
	.long 0xd7000007                                           // 000000212AE4: D7000007
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 000000212AE8: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212AF0: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212AF4: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212AFC: 980080C1
	global_load_b32 v159, v[3:4], off                          // 000000212B00: DC520000 9F7C0003
	global_load_b32 v157, v[5:6], off                          // 000000212B08: DC520000 9D7C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212B10: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 000000212B18: D5010003 00020F83
	.long 0xd7000005                                           // 000000212B20: D7000005
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 000000212B24: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212B2C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212B30: D5207C06 00020480
	.long 0xd7000007                                           // 000000212B38: D7000007
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 000000212B3C: 020202FF 00144000
	s_cmp_gt_i32 s7, 53                                        // 000000212B44: BF02B507
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212B48: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212B50: 980080C1
	s_cmp_gt_i32 s7, 54                                        // 000000212B54: BF02B607
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212B58: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212B60: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212B68: 980080C1
	s_cmp_gt_i32 s7, 55                                        // 000000212B6C: BF02B707
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212B70: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212B78: D5010007 00020F83
	.long 0xd7000009                                           // 000000212B80: D7000009
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 000000212B84: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212B8C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 000000212B90: D5207C0A 00020480
	.long 0xd700000b                                           // 000000212B98: D700000B
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 000000212B9C: 020202FF 00150000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212BA4: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212BAC: 980080C1
	s_cmp_gt_i32 s7, 56                                        // 000000212BB0: BF02B807
	v_cndmask_b32_e64 v10, v132, v10, s0                       // 000000212BB4: D501000A 00021584
	v_cndmask_b32_e64 v9, v131, v9, s0                         // 000000212BBC: D5010009 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212BC4: 980080C1
	s_cmp_gt_i32 s7, 57                                        // 000000212BC8: BF02B907
	v_cndmask_b32_e64 v12, v132, v12, s0                       // 000000212BCC: D501000C 00021984
	v_cndmask_b32_e64 v11, v131, v11, s0                       // 000000212BD4: D501000B 00021783
	global_load_b32 v164, v[3:4], off                          // 000000212BDC: DC520000 A47C0003
	global_load_b32 v163, v[5:6], off                          // 000000212BE4: DC520000 A37C0005
	global_load_b32 v162, v[7:8], off                          // 000000212BEC: DC520000 A27C0007
	global_load_b32 v161, v[9:10], off                         // 000000212BF4: DC520000 A17C0009
	global_load_b32 v160, v[11:12], off                        // 000000212BFC: DC520000 A07C000B
	.long 0xd7000003                                           // 000000212C04: D7000003
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 000000212C08: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212C10: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 000000212C14: D5207C04 00020480
	.long 0xd7000005                                           // 000000212C1C: D7000005
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 000000212C20: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212C28: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212C30: 980080C1
	s_cmp_gt_i32 s7, 58                                        // 000000212C34: BF02BA07
	v_cndmask_b32_e64 v4, v132, v4, s0                         // 000000212C38: D5010004 00020984
	v_cndmask_b32_e64 v3, v131, v3, s0                         // 000000212C40: D5010003 00020783
	s_cselect_b32 s0, -1, 0                                    // 000000212C48: 980080C1
	s_cmp_gt_i32 s7, 59                                        // 000000212C4C: BF02BB07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212C50: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212C58: D5010005 00020B83
	.long 0xd7000007                                           // 000000212C60: D7000007
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 000000212C64: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212C6C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212C70: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212C78: 980080C1
	global_load_b32 v165, v[3:4], off                          // 000000212C7C: DC520000 A57C0003
	global_load_b32 v166, v[5:6], off                          // 000000212C84: DC520000 A67C0005
	v_cndmask_b32_e64 v4, v132, v8, s0                         // 000000212C8C: D5010004 00021184
	v_cndmask_b32_e64 v3, v131, v7, s0                         // 000000212C94: D5010003 00020F83
	.long 0xd7000005                                           // 000000212C9C: D7000005
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 000000212CA0: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000212CA8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 000000212CAC: D5207C06 00020480
	.long 0xd7000007                                           // 000000212CB4: D7000007
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 000000212CB8: 020202FF 0016E000
	s_cmp_gt_i32 s7, 60                                        // 000000212CC0: BF02BC07
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 000000212CC4: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212CCC: 980080C1
	s_cmp_gt_i32 s7, 61                                        // 000000212CD0: BF02BD07
	v_cndmask_b32_e64 v6, v132, v6, s0                         // 000000212CD4: D5010006 00020D84
	v_cndmask_b32_e64 v5, v131, v5, s0                         // 000000212CDC: D5010005 00020B83
	s_cselect_b32 s0, -1, 0                                    // 000000212CE4: 980080C1
	s_cmp_gt_i32 s7, 62                                        // 000000212CE8: BF02BE07
	v_cndmask_b32_e64 v8, v132, v8, s0                         // 000000212CEC: D5010008 00021184
	v_cndmask_b32_e64 v7, v131, v7, s0                         // 000000212CF4: D5010007 00020F83
	.long 0xd7000009                                           // 000000212CFC: D7000009
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 000000212D00: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000212D08: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 000000212D0C: D5207C0A 00020480
	.long 0xd700000b                                           // 000000212D14: D700000B
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 000000212D18: 020202FF 0017A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 000000212D20: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 000000212D28: 980080C1
	s_cmp_gt_i32 s7, 63                                        // 000000212D2C: BF02BF07
	v_cndmask_b32_e64 v2, v132, v10, s0                        // 000000212D30: D5010002 00021584
	v_cndmask_b32_e64 v1, v131, v9, s0                         // 000000212D38: D5010001 00021383
	s_cselect_b32 s0, -1, 0                                    // 000000212D40: 980080C1
	s_cmp_gt_i32 s50, s1                                       // 000000212D44: BF020132
	v_cndmask_b32_e64 v10, v132, v12, s0                       // 000000212D48: D501000A 00021984
	v_cndmask_b32_e64 v9, v131, v11, s0                        // 000000212D50: D5010009 00021783
	global_load_b32 v171, v[3:4], off                          // 000000212D58: DC520000 AB7C0003
	global_load_b32 v170, v[5:6], off                          // 000000212D60: DC520000 AA7C0005
	global_load_b32 v168, v[7:8], off                          // 000000212D68: DC520000 A87C0007
	global_load_b32 v167, v[1:2], off                          // 000000212D70: DC520000 A77C0001
	global_load_b32 v169, v[9:10], off                         // 000000212D78: DC520000 A97C0009
	s_cselect_b32 s7, -1, 0                                    // 000000212D80: 980780C1
	s_or_b32 s0, s1, 1                                         // 000000212D84: 8C008101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212D88: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212D8C: BF043200
	s_cselect_b32 s8, -1, 0                                    // 000000212D90: 980880C1
	s_or_b32 s0, s1, 2                                         // 000000212D94: 8C008201
	s_cmp_lt_i32 s0, s50                                       // 000000212D98: BF043200
	s_cselect_b32 s9, -1, 0                                    // 000000212D9C: 980980C1
	s_or_b32 s0, s1, 3                                         // 000000212DA0: 8C008301
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212DA4: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212DA8: BF043200
	s_cselect_b32 s10, -1, 0                                   // 000000212DAC: 980A80C1
	s_or_b32 s0, s1, 4                                         // 000000212DB0: 8C008401
	s_cmp_lt_i32 s0, s50                                       // 000000212DB4: BF043200
	s_cselect_b32 s11, -1, 0                                   // 000000212DB8: 980B80C1
	s_or_b32 s0, s1, 5                                         // 000000212DBC: 8C008501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212DC0: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212DC4: BF043200
	s_cselect_b32 s12, -1, 0                                   // 000000212DC8: 980C80C1
	s_or_b32 s0, s1, 6                                         // 000000212DCC: 8C008601
	s_cmp_lt_i32 s0, s50                                       // 000000212DD0: BF043200
	s_cselect_b32 s13, -1, 0                                   // 000000212DD4: 980D80C1
	s_or_b32 s0, s1, 7                                         // 000000212DD8: 8C008701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212DDC: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212DE0: BF043200
	s_cselect_b32 s14, -1, 0                                   // 000000212DE4: 980E80C1
	s_or_b32 s0, s1, 8                                         // 000000212DE8: 8C008801
	s_cmp_lt_i32 s0, s50                                       // 000000212DEC: BF043200
	s_cselect_b32 s42, -1, 0                                   // 000000212DF0: 982A80C1
	s_or_b32 s0, s1, 9                                         // 000000212DF4: 8C008901
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212DF8: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212DFC: BF043200
	s_cselect_b32 s43, -1, 0                                   // 000000212E00: 982B80C1
	s_or_b32 s0, s1, 10                                        // 000000212E04: 8C008A01
	s_cmp_lt_i32 s0, s50                                       // 000000212E08: BF043200
	s_cselect_b32 s54, -1, 0                                   // 000000212E0C: 983680C1
	s_or_b32 s0, s1, 11                                        // 000000212E10: 8C008B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212E14: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212E18: BF043200
	s_cselect_b32 s55, -1, 0                                   // 000000212E1C: 983780C1
	s_or_b32 s0, s1, 12                                        // 000000212E20: 8C008C01
	s_cmp_lt_i32 s0, s50                                       // 000000212E24: BF043200
	s_cselect_b32 s56, -1, 0                                   // 000000212E28: 983880C1
	s_or_b32 s0, s1, 13                                        // 000000212E2C: 8C008D01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212E30: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212E34: BF043200
	s_cselect_b32 s57, -1, 0                                   // 000000212E38: 983980C1
	s_or_b32 s0, s1, 14                                        // 000000212E3C: 8C008E01
	s_cmp_lt_i32 s0, s50                                       // 000000212E40: BF043200
	s_cselect_b32 s58, -1, 0                                   // 000000212E44: 983A80C1
	s_or_b32 s0, s1, 15                                        // 000000212E48: 8C008F01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212E4C: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212E50: BF043200
	s_cselect_b32 s59, -1, 0                                   // 000000212E54: 983B80C1
	s_or_b32 s0, s1, 16                                        // 000000212E58: 8C009001
	s_cmp_lt_i32 s0, s50                                       // 000000212E5C: BF043200
	s_cselect_b32 s60, -1, 0                                   // 000000212E60: 983C80C1
	s_or_b32 s0, s1, 17                                        // 000000212E64: 8C009101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000212E68: BF8704B9
	s_cmp_lt_i32 s0, s50                                       // 000000212E6C: BF043200
	s_cselect_b32 s61, -1, 0                                   // 000000212E70: 983D80C1
	s_or_b32 s62, s1, 18                                       // 000000212E74: 8C3E9201
	s_cmp_lt_i32 s62, s50                                      // 000000212E78: BF04323E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000212E7C: BF890007
	s_barrier                                                  // 000000212E80: BFBD0000
	buffer_gl0_inv                                             // 000000212E84: E0AC0000 00000000
	ds_load_b128 v[172:175], v114 offset:39936                 // 000000212E8C: DBFC9C00 AC000072
	ds_load_b128 v[176:179], v114 offset:39952                 // 000000212E94: DBFC9C10 B0000072
	ds_load_b128 v[180:183], v114 offset:39968                 // 000000212E9C: DBFC9C20 B4000072
	ds_load_b128 v[184:187], v114 offset:39984                 // 000000212EA4: DBFC9C30 B8000072
	ds_load_b128 v[188:191], v114 offset:40000                 // 000000212EAC: DBFC9C40 BC000072
	ds_load_b128 v[192:195], v114 offset:40016                 // 000000212EB4: DBFC9C50 C0000072
	s_waitcnt lgkmcnt(5)                                       // 000000212EBC: BF89FC57
	v_dual_mul_f32 v25, v25, v172 :: v_dual_add_nc_u32 v196, s1, v134// 000000212EC0: C8E15919 19C50C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000212EC8: BF8701C1
	v_min_i32_e32 v1, s52, v196                                // 000000212ECC: 22038834
	v_dual_mul_f32 v26, v26, v173 :: v_dual_mul_f32 v27, v27, v174// 000000212ED0: C8C75B1A 1A1B5D1B
	s_waitcnt lgkmcnt(4)                                       // 000000212ED8: BF89FC47
	v_dual_mul_f32 v28, v28, v175 :: v_dual_mul_f32 v29, v29, v176// 000000212EDC: C8C75F1C 1C1D611D
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 000000212EE4: D6FF7C01 00096101
	v_dual_mul_f32 v30, v30, v177 :: v_dual_mul_f32 v31, v31, v178// 000000212EEC: C8C7631E 1E1F651F
	s_waitcnt lgkmcnt(3)                                       // 000000212EF4: BF89FC37
	v_dual_mul_f32 v32, v32, v179 :: v_dual_mul_f32 v49, v49, v180// 000000212EF8: C8C76720 20316931
	s_waitcnt lgkmcnt(2)                                       // 000000212F00: BF89FC27
	v_dual_mul_f32 v52, v52, v183 :: v_dual_mul_f32 v53, v53, v184// 000000212F04: C8C76F34 34357135
	v_dual_mul_f32 v54, v54, v185 :: v_dual_mul_f32 v55, v55, v186// 000000212F0C: C8C77336 36377537
	.long 0xd73c0052                                           // 000000212F14: D73C0052
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000212F18: 02020288
	s_waitcnt lgkmcnt(1)                                       // 000000212F1C: BF89FC17
	v_dual_mul_f32 v56, v56, v187 :: v_dual_mul_f32 v91, v91, v189// 000000212F20: C8C77738 385B7B5B
	v_dual_mul_f32 v50, v50, v181 :: v_dual_mul_f32 v51, v51, v182// 000000212F28: C8C76B32 32336D33
	v_mul_f32_e32 v92, v92, v190                               // 000000212F30: 10B97D5C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000212F34: BF870094
	.long 0xd7000005                                           // 000000212F38: D7000005
	v_cndmask_b32_e32 v1, s46, v82, vcc_lo                     // 000000212F3C: 0202A42E
	v_add_co_ci_u32_e64 v6, null, s47, v83, s0                 // 000000212F40: D5207C06 0002A62F
	s_clause 0xf                                               // 000000212F48: BF85000F
	global_load_b128 v[73:76], v[5:6], off                     // 000000212F4C: DC5E0000 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:16           // 000000212F54: DC5E0010 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:32           // 000000212F5C: DC5E0020 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:48           // 000000212F64: DC5E0030 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:64           // 000000212F6C: DC5E0040 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:80           // 000000212F74: DC5E0050 3D7C0005
	global_load_b128 v[41:44], v[5:6], off offset:96           // 000000212F7C: DC5E0060 297C0005
	global_load_b128 v[45:48], v[5:6], off offset:112          // 000000212F84: DC5E0070 2D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:128          // 000000212F8C: DC5E0080 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:144          // 000000212F94: DC5E0090 257C0005
	global_load_b128 v[17:20], v[5:6], off offset:160          // 000000212F9C: DC5E00A0 117C0005
	global_load_b128 v[21:24], v[5:6], off offset:176          // 000000212FA4: DC5E00B0 157C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 000000212FAC: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 000000212FB4: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 000000212FBC: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 000000212FC4: DC5E00F0 057C0005
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 000000212FCC: CC210019 02004F19
	v_dual_mul_f32 v84, v84, v188 :: v_dual_mul_f32 v93, v93, v191// 000000212FD4: C8C77954 545D7F5D
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 000000212FDC: CC220019 02004F1A
	v_fma_mixhi_f16 v26, v28, s39, 0                           // 000000212FE4: CC22001A 02004F1C
	v_fma_mixlo_f16 v28, v31, s39, 0                           // 000000212FEC: CC21001C 02004F1F
	v_fma_mixhi_f16 v28, v32, s39, 0                           // 000000212FF4: CC22001C 02004F20
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 000000212FFC: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 000000213004: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 00000021300C: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 000000213014: CC220020 02004F38
	ds_load_b128 v[53:56], v114 offset:40032                   // 00000021301C: DBFC9C60 35000072
	v_fma_mixlo_f16 v26, v27, s39, 0                           // 000000213024: CC21001A 02004F1B
	v_fma_mixlo_f16 v27, v29, s39, 0                           // 00000021302C: CC21001B 02004F1D
	v_fma_mixhi_f16 v27, v30, s39, 0                           // 000000213034: CC22001B 02004F1E
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 00000021303C: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 000000213044: CC21001E 02004F33
	s_waitcnt lgkmcnt(1)                                       // 00000021304C: BF89FC17
	v_mul_f32_e32 v51, v85, v192                               // 000000213050: 10678155
	v_fma_mixlo_f16 v50, v92, s39, 0                           // 000000213054: CC210032 02004F5C
	v_cndmask_b16 v25, 0, v25, s7                              // 00000021305C: D65D0019 001E3280
	s_cselect_b32 s0, -1, 0                                    // 000000213064: 980080C1
	s_or_b32 s7, s1, 19                                        // 000000213068: 8C079301
	v_fma_mixhi_f16 v50, v93, s39, 0                           // 00000021306C: CC220032 02004F5D
	s_cmp_lt_i32 s7, s50                                       // 000000213074: BF043207
	v_cndmask_b16 v50, 0, v50, s0                              // 000000213078: D65D0032 00026480
	s_cselect_b32 s0, -1, 0                                    // 000000213080: 980080C1
	s_or_b32 s7, s1, 20                                        // 000000213084: 8C079401
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 000000213088: CC21001D 02004F31
	s_cmp_lt_i32 s7, s50                                       // 000000213090: BF043207
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 000000213094: CC22001E 02004F34
	v_fma_mixlo_f16 v49, v84, s39, 0                           // 00000021309C: CC210031 02004F54
	v_cndmask_b16 v50, 0, v50, s0                              // 0000002130A4: D65D5032 00026480
	s_cselect_b32 s0, -1, 0                                    // 0000002130AC: 980080C1
	s_or_b32 s7, s1, 21                                        // 0000002130B0: 8C079501
	v_mul_f32_e32 v52, v86, v193                               // 0000002130B4: 10698356
	v_mul_f32_e32 v84, v88, v194                               // 0000002130B8: 10A98558
	s_cmp_lt_i32 s7, s50                                       // 0000002130BC: BF043207
	v_fma_mixlo_f16 v51, v51, s39, 0                           // 0000002130C0: CC210033 02004F33
	v_cndmask_b16 v25, 0, v25, s8                              // 0000002130C8: D65D5019 00223280
	s_cselect_b32 s7, -1, 0                                    // 0000002130D0: 980780C1
	s_or_b32 s8, s1, 22                                        // 0000002130D4: 8C089601
	v_fma_mixhi_f16 v51, v52, s39, 0                           // 0000002130D8: CC220033 02004F34
	v_fma_mixlo_f16 v52, v84, s39, 0                           // 0000002130E0: CC210034 02004F54
	v_mul_f32_e32 v88, v87, v195                               // 0000002130E8: 10B18757
	ds_load_b128 v[84:87], v114 offset:40048                   // 0000002130EC: DBFC9C70 54000072
	s_cmp_lt_i32 s8, s50                                       // 0000002130F4: BF043208
	v_cndmask_b16 v51, 0, v51, s0                              // 0000002130F8: D65D0033 00026680
	s_cselect_b32 s0, -1, 0                                    // 000000213100: 980080C1
	s_waitcnt lgkmcnt(1)                                       // 000000213104: BF89FC17
	v_mul_f32_e32 v53, v98, v53                                // 000000213108: 106A6B62
	v_cndmask_b16 v52, 0, v52, s0                              // 00000021310C: D65D0034 00026880
	s_or_b32 s0, s1, 23                                        // 000000213114: 8C009701
	v_fma_mixhi_f16 v52, v88, s39, 0                           // 000000213118: CC220034 02004F58
	s_cmp_lt_i32 s0, s50                                       // 000000213120: BF043200
	v_cndmask_b16 v51, 0, v51, s7                              // 000000213124: D65D5033 001E6680
	s_cselect_b32 s0, -1, 0                                    // 00000021312C: 980080C1
	s_or_b32 s7, s1, 24                                        // 000000213130: 8C079801
	v_fma_mixlo_f16 v53, v53, s39, 0                           // 000000213134: CC210035 02004F35
	s_cmp_lt_i32 s7, s50                                       // 00000021313C: BF043207
	v_cndmask_b16 v52, 0, v52, s0                              // 000000213140: D65D5034 00026880
	s_cselect_b32 s0, -1, 0                                    // 000000213148: 980080C1
	v_dual_mul_f32 v54, v95, v54 :: v_dual_mul_f32 v55, v94, v55// 00000021314C: C8C66D5F 36366F5E
	v_cndmask_b16 v53, 0, v53, s0                              // 000000213154: D65D0035 00026A80
	s_or_b32 s0, s1, 25                                        // 00000021315C: 8C009901
	v_fma_mixhi_f16 v49, v91, s39, 0                           // 000000213160: CC220031 02004F5B
	s_cmp_lt_i32 s0, s50                                       // 000000213168: BF043200
	v_fma_mixhi_f16 v53, v54, s39, 0                           // 00000021316C: CC220035 02004F36
	s_cselect_b32 s0, -1, 0                                    // 000000213174: 980080C1
	s_or_b32 s7, s1, 26                                        // 000000213178: 8C079A01
	v_fma_mixlo_f16 v54, v55, s39, 0                           // 00000021317C: CC210036 02004F37
	v_mul_f32_e32 v55, v89, v56                                // 000000213184: 106E7159
	s_waitcnt lgkmcnt(0)                                       // 000000213188: BF89FC07
	v_mul_f32_e32 v56, v90, v84                                // 00000021318C: 1070A95A
	ds_load_b128 v[88:91], v114 offset:40064                   // 000000213190: DBFC9C80 58000072
	s_cmp_lt_i32 s7, s50                                       // 000000213198: BF043207
	v_cndmask_b16 v53, 0, v53, s0                              // 00000021319C: D65D5035 00026A80
	s_cselect_b32 s0, -1, 0                                    // 0000002131A4: 980080C1
	v_fma_mixhi_f16 v54, v55, s39, 0                           // 0000002131A8: CC220036 02004F37
	v_cndmask_b16 v54, 0, v54, s0                              // 0000002131B0: D65D0036 00026C80
	s_or_b32 s0, s1, 27                                        // 0000002131B8: 8C009B01
	v_cndmask_b16 v26, 0, v26, s9                              // 0000002131BC: D65D001A 00263480
	s_cmp_lt_i32 s0, s50                                       // 0000002131C4: BF043200
	v_cndmask_b16 v26, 0, v26, s10                             // 0000002131C8: D65D501A 002A3480
	s_cselect_b32 s0, -1, 0                                    // 0000002131D0: 980080C1
	s_or_b32 s7, s1, 28                                        // 0000002131D4: 8C079C01
	v_cndmask_b16 v27, 0, v27, s11                             // 0000002131D8: D65D001B 002E3680
	v_cndmask_b16 v27, 0, v27, s12                             // 0000002131E0: D65D501B 00323680
	v_cndmask_b16 v28, 0, v28, s13                             // 0000002131E8: D65D001C 00363880
	v_cndmask_b16 v28, 0, v28, s14                             // 0000002131F0: D65D501C 003A3880
	v_cndmask_b16 v29, 0, v29, s42                             // 0000002131F8: D65D001D 00AA3A80
	v_cndmask_b16 v29, 0, v29, s43                             // 000000213200: D65D501D 00AE3A80
	v_cndmask_b16 v30, 0, v30, s54                             // 000000213208: D65D001E 00DA3C80
	v_cndmask_b16 v30, 0, v30, s55                             // 000000213210: D65D501E 00DE3C80
	v_cndmask_b16 v31, 0, v31, s56                             // 000000213218: D65D001F 00E23E80
	v_cndmask_b16 v31, 0, v31, s57                             // 000000213220: D65D501F 00E63E80
	v_cndmask_b16 v32, 0, v32, s58                             // 000000213228: D65D0020 00EA4080
	v_cndmask_b16 v32, 0, v32, s59                             // 000000213230: D65D5020 00EE4080
	s_cmp_lt_i32 s7, s50                                       // 000000213238: BF043207
	v_fma_mixlo_f16 v55, v56, s39, 0                           // 00000021323C: CC210037 02004F38
	v_cndmask_b16 v54, 0, v54, s0                              // 000000213244: D65D5036 00026C80
	s_cselect_b32 s0, -1, 0                                    // 00000021324C: 980080C1
	s_or_b32 s7, s1, 29                                        // 000000213250: 8C079D01
	ds_store_b128 v133, v[25:28]                               // 000000213254: DB7C0000 00001985
	ds_store_b128 v133, v[29:32] offset:16                     // 00000021325C: DB7C0010 00001D85
	s_cmp_lt_i32 s7, s50                                       // 000000213264: BF043207
	ds_load_b128 v[25:28], v114 offset:40080                   // 000000213268: DBFC9C90 19000072
	s_waitcnt lgkmcnt(3)                                       // 000000213270: BF89FC37
	v_dual_mul_f32 v56, v96, v85 :: v_dual_mul_f32 v29, v102, v88// 000000213274: C8C6AB60 381CB166
	v_cndmask_b16 v55, 0, v55, s0                              // 00000021327C: D65D0037 00026E80
	s_cselect_b32 s0, -1, 0                                    // 000000213284: 980080C1
	s_or_b32 s7, s1, 30                                        // 000000213288: 8C079E01
	v_mul_f32_e32 v85, v105, v87                               // 00000021328C: 10AAAF69
	s_cmp_lt_i32 s7, s50                                       // 000000213290: BF043207
	v_fma_mixhi_f16 v55, v56, s39, 0                           // 000000213294: CC220037 02004F38
	v_dual_mul_f32 v84, v97, v86 :: v_dual_mul_f32 v31, v100, v91// 00000021329C: C8C6AD61 541EB764
	s_cselect_b32 s7, -1, 0                                    // 0000002132A4: 980780C1
	s_or_b32 s8, s1, 31                                        // 0000002132A8: 8C089F01
	v_fma_mixhi_f16 v56, v85, s39, 0                           // 0000002132AC: CC220038 02004F55
	s_cmp_lt_i32 s8, s50                                       // 0000002132B4: BF043208
	v_cndmask_b16 v55, 0, v55, s0                              // 0000002132B8: D65D5037 00026E80
	s_cselect_b32 s0, -1, 0                                    // 0000002132C0: 980080C1
	v_fma_mixlo_f16 v56, v84, s39, 0                           // 0000002132C4: CC210038 02004F54
	v_cndmask_b16 v56, 0, v56, s0                              // 0000002132CC: D65D5038 00027080
	s_or_b32 s0, s1, 32                                        // 0000002132D4: 8C00A001
	v_mul_f32_e32 v30, v101, v89                               // 0000002132D8: 103CB365
	s_cmp_lt_i32 s0, s50                                       // 0000002132DC: BF043200
	v_fma_mixlo_f16 v29, v29, s39, 0                           // 0000002132E0: CC21001D 02004F1D
	v_cndmask_b16 v56, 0, v56, s7                              // 0000002132E8: D65D0038 001E7080
	s_cselect_b32 s0, -1, 0                                    // 0000002132F0: 980080C1
	s_or_b32 s7, s1, 33                                        // 0000002132F4: 8C07A101
	v_cndmask_b16 v49, 0, v49, s60                             // 0000002132F8: D65D0031 00F26280
	v_cndmask_b16 v49, 0, v49, s61                             // 000000213300: D65D5031 00F66280
	s_cmp_lt_i32 s7, s50                                       // 000000213308: BF043207
	v_fma_mixhi_f16 v29, v30, s39, 0                           // 00000021330C: CC22001D 02004F1E
	v_cndmask_b16 v29, 0, v29, s0                              // 000000213314: D65D001D 00023A80
	s_cselect_b32 s0, -1, 0                                    // 00000021331C: 980080C1
	s_or_b32 s7, s1, 34                                        // 000000213320: 8C07A201
	ds_store_b128 v133, v[49:52] offset:32                     // 000000213324: DB7C0020 00003185
	ds_store_b128 v133, v[53:56] offset:48                     // 00000021332C: DB7C0030 00003585
	s_cmp_lt_i32 s7, s50                                       // 000000213334: BF043207
	ds_load_b128 v[49:52], v114 offset:40096                   // 000000213338: DBFC9CA0 31000072
	v_mul_f32_e32 v30, v99, v90                                // 000000213340: 103CB563
	v_cndmask_b16 v29, 0, v29, s0                              // 000000213344: D65D501D 00023A80
	s_cselect_b32 s0, -1, 0                                    // 00000021334C: 980080C1
	s_or_b32 s7, s1, 35                                        // 000000213350: 8C07A301
	s_waitcnt lgkmcnt(3)                                       // 000000213354: BF89FC37
	v_mul_f32_e32 v32, v104, v25                               // 000000213358: 10403368
	s_cmp_lt_i32 s7, s50                                       // 00000021335C: BF043207
	v_fma_mixlo_f16 v30, v30, s39, 0                           // 000000213360: CC21001E 02004F1E
	s_cselect_b32 s7, -1, 0                                    // 000000213368: 980780C1
	s_or_b32 s8, s1, 36                                        // 00000021336C: 8C08A401
	v_fma_mixlo_f16 v25, v31, s39, 0                           // 000000213370: CC210019 02004F1F
	v_fma_mixhi_f16 v25, v32, s39, 0                           // 000000213378: CC220019 02004F20
	s_cmp_lt_i32 s8, s50                                       // 000000213380: BF043208
	v_cndmask_b16 v30, 0, v30, s0                              // 000000213384: D65D001E 00023C80
	s_cselect_b32 s0, -1, 0                                    // 00000021338C: 980080C1
	v_cndmask_b16 v30, 0, v25, s7                              // 000000213390: D65D401E 001E3280
	s_or_b32 s7, s1, 37                                        // 000000213398: 8C07A501
	v_cndmask_b16 v31, 0, v25, s0                              // 00000021339C: D65D101F 00023280
	v_mul_f32_e32 v25, v103, v26                               // 0000002133A4: 10323567
	v_mul_f32_e32 v26, v111, v27                               // 0000002133A8: 1034376F
	s_cmp_lt_i32 s7, s50                                       // 0000002133AC: BF043207
	v_mul_f32_e32 v27, v110, v28                               // 0000002133B0: 1036396E
	s_cselect_b32 s0, -1, 0                                    // 0000002133B4: 980080C1
	s_or_b32 s7, s1, 38                                        // 0000002133B8: 8C07A601
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000002133BC: CC210019 02004F19
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000002133C4: CC220019 02004F1A
	s_cmp_lt_i32 s7, s50                                       // 0000002133CC: BF043207
	v_fma_mixhi_f16 v32, v27, s39, 0                           // 0000002133D0: CC220020 02004F1B
	s_cselect_b32 s7, -1, 0                                    // 0000002133D8: 980780C1
	v_cndmask_b16 v31, 0, v25, s0                              // 0000002133DC: D65D401F 00023280
	v_cndmask_b16 v32, 0, v25, s7                              // 0000002133E4: D65D1020 001E3280
	ds_load_b128 v[25:28], v114 offset:40112                   // 0000002133EC: DBFC9CB0 19000072
	s_or_b32 s8, s1, 39                                        // 0000002133F4: 8C08A701
	s_waitcnt lgkmcnt(1)                                       // 0000002133F8: BF89FC17
	v_mul_f32_e32 v49, v108, v49                               // 0000002133FC: 1062636C
	s_cmp_lt_i32 s8, s50                                       // 000000213400: BF043208
	v_mul_f32_e32 v50, v107, v50                               // 000000213404: 1064656B
	s_cselect_b32 s0, -1, 0                                    // 000000213408: 980080C1
	.long 0xd443000d                                           // 00000021340C: D443000D
	v_cndmask_b32_e32 v1, s50, v196, vcc_lo                    // 000000213410: 02038832
	v_cndmask_b16 v32, 0, v32, s0                              // 000000213414: D65D5020 00024080
	s_or_b32 s0, s1, 40                                        // 00000021341C: 8C00A801
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 000000213420: CC210031 02004F31
	s_cmp_lt_i32 s0, s50                                       // 000000213428: BF043200
	s_cselect_b32 s0, -1, 0                                    // 00000021342C: 980080C1
	s_or_b32 s7, s1, 41                                        // 000000213430: 8C07A901
	s_delay_alu instid0(VALU_DEP_1)                            // 000000213434: BF870001
	v_cndmask_b16 v49, 0, v49, s0                              // 000000213438: D65D0031 00026280
	s_cmp_lt_i32 s7, s50                                       // 000000213440: BF043207
	s_cselect_b32 s0, -1, 0                                    // 000000213444: 980080C1
	s_waitcnt lgkmcnt(0)                                       // 000000213448: BF89FC07
	v_mul_f32_e32 v25, v109, v25                               // 00000021344C: 1032336D
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 000000213450: CC220031 02004F32
	v_dual_mul_f32 v50, v106, v51 :: v_dual_mul_f32 v51, v112, v52// 000000213458: C8C6676A 32326970
	ds_load_b128 v[52:55], v114 offset:40128                   // 000000213460: DBFC9CC0 34000072
	v_mul_f32_e32 v26, v158, v26                               // 000000213468: 1034359E
	v_cndmask_b16 v49, 0, v49, s0                              // 00000021346C: D65D5031 00026280
	s_or_b32 s0, s1, 42                                        // 000000213474: 8C00AA01
	v_fma_mixlo_f16 v50, v50, s39, 0                           // 000000213478: CC210032 02004F32
	s_cmp_lt_i32 s0, s50                                       // 000000213480: BF043200
	v_fma_mixhi_f16 v50, v51, s39, 0                           // 000000213484: CC220032 02004F33
	s_cselect_b32 s0, -1, 0                                    // 00000021348C: 980080C1
	s_or_b32 s7, s1, 43                                        // 000000213490: 8C07AB01
	v_cndmask_b16 v50, 0, v50, s0                              // 000000213494: D65D0032 00026480
	s_cmp_lt_i32 s7, s50                                       // 00000021349C: BF043207
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000002134A0: CC210019 02004F19
	s_cselect_b32 s0, -1, 0                                    // 0000002134A8: 980080C1
	s_or_b32 s7, s1, 44                                        // 0000002134AC: 8C07AC01
	v_cndmask_b16 v50, 0, v50, s0                              // 0000002134B0: D65D5032 00026480
	s_cmp_lt_i32 s7, s50                                       // 0000002134B8: BF043207
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000002134BC: CC220019 02004F1A
	s_cselect_b32 s0, -1, 0                                    // 0000002134C4: 980080C1
	s_or_b32 s7, s1, 45                                        // 0000002134C8: 8C07AD01
	v_mul_f32_e32 v26, v156, v27                               // 0000002134CC: 1034379C
	s_cmp_lt_i32 s7, s50                                       // 0000002134D0: BF043207
	v_cndmask_b16 v51, 0, v25, s0                              // 0000002134D4: D65D0033 00023280
	s_cselect_b32 s7, -1, 0                                    // 0000002134DC: 980780C1
	s_or_b32 s8, s1, 46                                        // 0000002134E0: 8C08AE01
	v_cndmask_b16 v51, 0, v25, s7                              // 0000002134E4: D65D5033 001E3280
	s_cmp_lt_i32 s8, s50                                       // 0000002134EC: BF043208
	v_mul_f32_e32 v84, v155, v28                               // 0000002134F0: 10A8399B
	s_cselect_b32 s0, -1, 0                                    // 0000002134F4: 980080C1
	s_or_b32 s8, s1, 47                                        // 0000002134F8: 8C08AF01
	v_fma_mixlo_f16 v56, v26, s39, 0                           // 0000002134FC: CC210038 02004F1A
	ds_load_b128 v[25:28], v114 offset:40144                   // 000000213504: DBFC9CD0 19000072
	s_waitcnt lgkmcnt(1)                                       // 00000021350C: BF89FC17
	v_mul_f32_e32 v85, v124, v52                               // 000000213510: 10AA697C
	s_cmp_lt_i32 s8, s50                                       // 000000213514: BF043208
	v_fma_mixhi_f16 v52, v84, s39, 0                           // 000000213518: CC220034 02004F54
	s_cselect_b32 s7, -1, 0                                    // 000000213520: 980780C1
	s_or_b32 s8, s1, 48                                        // 000000213524: 8C08B001
	v_cndmask_b16 v52, 0, v56, s0                              // 000000213528: D65D0034 00027080
	v_fma_mixlo_f16 v56, v85, s39, 0                           // 000000213530: CC210038 02004F55
	s_cmp_lt_i32 s8, s50                                       // 000000213538: BF043208
	ds_load_b128 v[84:87], v114 offset:40160                   // 00000021353C: DBFC9CE0 54000072
	ds_load_b128 v[88:91], v114 offset:40176                   // 000000213544: DBFC9CF0 58000072
	s_cselect_b32 s0, -1, 0                                    // 00000021354C: 980080C1
	v_mul_f32_e32 v53, v123, v53                               // 000000213550: 106A6B7B
	v_cndmask_b16 v92, 0, v56, s0                              // 000000213554: D65D005C 00027080
	s_or_b32 s0, s1, 49                                        // 00000021355C: 8C00B101
	v_mul_f32_e32 v54, v159, v54                               // 000000213560: 106C6D9F
	s_cmp_lt_i32 s0, s50                                       // 000000213564: BF043200
	v_cndmask_b16 v52, 0, v52, s7                              // 000000213568: D65D5034 001E6880
	s_cselect_b32 s0, -1, 0                                    // 000000213570: 980080C1
	s_or_b32 s7, s1, 50                                        // 000000213574: 8C07B201
	v_fma_mixlo_f16 v53, v53, s39, 0                           // 000000213578: CC210035 02004F35
	v_fma_mixhi_f16 v53, v54, s39, 0                           // 000000213580: CC220035 02004F36
	s_cmp_lt_i32 s7, s50                                       // 000000213588: BF043207
	s_waitcnt lgkmcnt(2)                                       // 00000021358C: BF89FC27
	v_mul_f32_e32 v54, v164, v25                               // 000000213590: 106C33A4
	s_cselect_b32 s7, -1, 0                                    // 000000213594: 980780C1
	s_or_b32 s8, s1, 51                                        // 000000213598: 8C08B301
	v_cndmask_b16 v92, 0, v53, s0                              // 00000021359C: D65D405C 00026A80
	s_cmp_lt_i32 s8, s50                                       // 0000002135A4: BF043208
	v_cndmask_b16 v93, 0, v53, s7                              // 0000002135A8: D65D105D 001E6A80
	v_mul_f32_e32 v53, v157, v55                               // 0000002135B0: 106A6F9D
	s_cselect_b32 s0, -1, 0                                    // 0000002135B4: 980080C1
	s_or_b32 s7, s1, 52                                        // 0000002135B8: 8C07B401
	v_mul_f32_e32 v26, v163, v26                               // 0000002135BC: 103435A3
	s_cmp_lt_i32 s7, s50                                       // 0000002135C0: BF043207
	v_fma_mixlo_f16 v25, v53, s39, 0                           // 0000002135C4: CC210019 02004F35
	s_cselect_b32 s7, -1, 0                                    // 0000002135CC: 980780C1
	s_or_b32 s8, s1, 53                                        // 0000002135D0: 8C08B501
	v_fma_mixhi_f16 v25, v54, s39, 0                           // 0000002135D4: CC220019 02004F36
	v_fma_mixlo_f16 v26, v26, s39, 0                           // 0000002135DC: CC21001A 02004F1A
	s_cmp_lt_i32 s8, s50                                       // 0000002135E4: BF043208
	v_cndmask_b16 v93, 0, v25, s0                              // 0000002135E8: D65D405D 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000002135F0: 980080C1
	v_cndmask_b16 v94, 0, v25, s7                              // 0000002135F4: D65D105E 001E3280
	v_cndmask_b16 v94, 0, v26, s0                              // 0000002135FC: D65D405E 00023480
	s_or_b32 s0, s1, 54                                        // 000000213604: 8C00B601
	v_dual_mul_f32 v25, v162, v27 :: v_dual_mul_f32 v26, v161, v28// 000000213608: C8C637A2 191A39A1
	s_waitcnt lgkmcnt(0)                                       // 000000213610: BF89FC07
	v_mul_f32_e32 v53, v167, v90                               // 000000213614: 106AB5A7
	s_cmp_lt_i32 s0, s50                                       // 000000213618: BF043200
	v_mul_f32_e32 v27, v166, v86                               // 00000021361C: 1036ADA6
	s_cselect_b32 s0, -1, 0                                    // 000000213620: 980080C1
	s_or_b32 s7, s1, 55                                        // 000000213624: 8C07B701
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 000000213628: CC210019 02004F19
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 000000213630: CC220019 02004F1A
	s_cmp_lt_i32 s7, s50                                       // 000000213638: BF043207
	v_mul_f32_e32 v26, v165, v85                               // 00000021363C: 1034ABA5
	s_cselect_b32 s7, -1, 0                                    // 000000213640: 980780C1
	s_or_b32 s8, s1, 56                                        // 000000213644: 8C08B801
	v_cndmask_b16 v95, 0, v25, s0                              // 000000213648: D65D005F 00023280
	s_cmp_lt_i32 s8, s50                                       // 000000213650: BF043208
	v_cndmask_b16 v95, 0, v25, s7                              // 000000213654: D65D505F 001E3280
	v_mul_f32_e32 v25, v160, v84                               // 00000021365C: 1032A9A0
	s_cselect_b32 s0, -1, 0                                    // 000000213660: 980080C1
	s_or_b32 s7, s1, 57                                        // 000000213664: 8C07B901
	v_mul_f32_e32 v28, v170, v88                               // 000000213668: 1038B1AA
	s_cmp_lt_i32 s7, s50                                       // 00000021366C: BF043207
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 000000213670: CC210019 02004F19
	s_cselect_b32 s7, -1, 0                                    // 000000213678: 980780C1
	s_or_b32 s8, s1, 58                                        // 00000021367C: 8C08BA01
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 000000213680: CC220019 02004F1A
	v_fma_mixlo_f16 v26, v27, s39, 0                           // 000000213688: CC21001A 02004F1B
	s_cmp_lt_i32 s8, s50                                       // 000000213690: BF043208
	v_cndmask_b16 v25, 0, v25, s0                              // 000000213694: D65D0019 00023280
	s_cselect_b32 s0, -1, 0                                    // 00000021369C: 980080C1
	v_mul_f32_e32 v27, v171, v87                               // 0000002136A0: 1036AFAB
	v_cndmask_b16 v26, 0, v26, s0                              // 0000002136A4: D65D001A 00023480
	s_or_b32 s0, s1, 59                                        // 0000002136AC: 8C00BB01
	v_cndmask_b16 v25, 0, v25, s7                              // 0000002136B0: D65D5019 001E3280
	s_cmp_lt_i32 s0, s50                                       // 0000002136B8: BF043200
	v_fma_mixhi_f16 v26, v27, s39, 0                           // 0000002136BC: CC22001A 02004F1B
	s_cselect_b32 s0, -1, 0                                    // 0000002136C4: 980080C1
	s_or_b32 s7, s1, 60                                        // 0000002136C8: 8C07BC01
	v_fma_mixlo_f16 v27, v28, s39, 0                           // 0000002136CC: CC21001B 02004F1C
	s_cmp_lt_i32 s7, s50                                       // 0000002136D4: BF043207
	v_mul_f32_e32 v28, v168, v89                               // 0000002136D8: 1038B3A8
	s_cselect_b32 s7, -1, 0                                    // 0000002136DC: 980780C1
	s_or_b32 s8, s1, 61                                        // 0000002136E0: 8C08BD01
	v_cndmask_b16 v26, 0, v26, s0                              // 0000002136E4: D65D501A 00023480
	s_cmp_lt_i32 s8, s50                                       // 0000002136EC: BF043208
	v_cndmask_b16 v27, 0, v27, s7                              // 0000002136F0: D65D001B 001E3680
	s_cselect_b32 s0, -1, 0                                    // 0000002136F8: 980080C1
	s_or_b32 s7, s1, 62                                        // 0000002136FC: 8C07BE01
	v_mul_f32_e32 v54, v169, v91                               // 000000213700: 106CB7A9
	s_cmp_lt_i32 s7, s50                                       // 000000213704: BF043207
	v_fma_mixhi_f16 v27, v28, s39, 0                           // 000000213708: CC22001B 02004F1C
	s_cselect_b32 s7, -1, 0                                    // 000000213710: 980780C1
	s_or_b32 s8, s1, 63                                        // 000000213714: 8C08BF01
	v_fma_mixlo_f16 v28, v53, s39, 0                           // 000000213718: CC21001C 02004F35
	v_fma_mixhi_f16 v28, v54, s39, 0                           // 000000213720: CC22001C 02004F36
	s_cmp_lt_i32 s8, s50                                       // 000000213728: BF043208
	v_cndmask_b16 v27, 0, v27, s0                              // 00000021372C: D65D501B 00023680
	s_cselect_b32 s0, -1, 0                                    // 000000213734: 980080C1
	v_cndmask_b16 v28, 0, v28, s7                              // 000000213738: D65D001C 001E3880
	v_cndmask_b16 v28, 0, v28, s0                              // 000000213740: D65D501C 00023880
	ds_store_b128 v133, v[29:32] offset:64                     // 000000213748: DB7C0040 00001D85
	ds_store_b128 v133, v[49:52] offset:80                     // 000000213750: DB7C0050 00003185
	ds_store_b128 v133, v[92:95] offset:96                     // 000000213758: DB7C0060 00005C85
	ds_store_b128 v133, v[25:28] offset:112                    // 000000213760: DB7C0070 00001985
	s_and_saveexec_b32 s0, s13                                 // 000000213768: BE80200D
	s_cbranch_execz 67                                         // 00000021376C: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1e7c>
	s_waitcnt vmcnt(1)                                         // 000000213770: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 000000213774: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000213778: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000021377C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000213780: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000213784: 7E080301
	s_waitcnt vmcnt(0)                                         // 000000213788: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 00000021378C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000213790: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000213794: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000213798: 7E100301
	v_mov_b32_e32 v9, v1                                       // 00000021379C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000002137A0: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000002137A4: 7E160301
	v_mov_b32_e32 v12, v1                                      // 0000002137A8: 7E180301
	v_mov_b32_e32 v13, v1                                      // 0000002137AC: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 0000002137B0: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 0000002137B4: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 0000002137B8: 7E200301
	v_mov_b32_e32 v17, v1                                      // 0000002137BC: 7E220301
	v_mov_b32_e32 v18, v1                                      // 0000002137C0: 7E240301
	v_mov_b32_e32 v19, v1                                      // 0000002137C4: 7E260301
	v_mov_b32_e32 v20, v1                                      // 0000002137C8: 7E280301
	v_mov_b32_e32 v21, v1                                      // 0000002137CC: 7E2A0301
	v_mov_b32_e32 v22, v1                                      // 0000002137D0: 7E2C0301
	v_mov_b32_e32 v23, v1                                      // 0000002137D4: 7E2E0301
	v_mov_b32_e32 v24, v1                                      // 0000002137D8: 7E300301
	v_mov_b32_e32 v33, v1                                      // 0000002137DC: 7E420301
	v_mov_b32_e32 v34, v1                                      // 0000002137E0: 7E440301
	v_mov_b32_e32 v35, v1                                      // 0000002137E4: 7E460301
	v_mov_b32_e32 v36, v1                                      // 0000002137E8: 7E480301
	v_mov_b32_e32 v37, v1                                      // 0000002137EC: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 0000002137F0: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 0000002137F4: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 0000002137F8: 7E500301
	v_mov_b32_e32 v41, v1                                      // 0000002137FC: 7E520301
	v_mov_b32_e32 v42, v1                                      // 000000213800: 7E540301
	v_mov_b32_e32 v43, v1                                      // 000000213804: 7E560301
	v_mov_b32_e32 v44, v1                                      // 000000213808: 7E580301
	v_mov_b32_e32 v45, v1                                      // 00000021380C: 7E5A0301
	v_mov_b32_e32 v46, v1                                      // 000000213810: 7E5C0301
	v_mov_b32_e32 v47, v1                                      // 000000213814: 7E5E0301
	v_mov_b32_e32 v48, v1                                      // 000000213818: 7E600301
	v_mov_b32_e32 v57, v1                                      // 00000021381C: 7E720301
	v_mov_b32_e32 v58, v1                                      // 000000213820: 7E740301
	v_mov_b32_e32 v59, v1                                      // 000000213824: 7E760301
	v_mov_b32_e32 v60, v1                                      // 000000213828: 7E780301
	v_mov_b32_e32 v61, v1                                      // 00000021382C: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 000000213830: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 000000213834: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 000000213838: 7E800301
	v_mov_b32_e32 v65, v1                                      // 00000021383C: 7E820301
	v_mov_b32_e32 v66, v1                                      // 000000213840: 7E840301
	v_mov_b32_e32 v67, v1                                      // 000000213844: 7E860301
	v_mov_b32_e32 v68, v1                                      // 000000213848: 7E880301
	v_mov_b32_e32 v69, v1                                      // 00000021384C: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 000000213850: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 000000213854: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 000000213858: 7E900301
	v_mov_b32_e32 v73, v1                                      // 00000021385C: 7E920301
	v_mov_b32_e32 v74, v1                                      // 000000213860: 7E940301
	v_mov_b32_e32 v75, v1                                      // 000000213864: 7E960301
	v_mov_b32_e32 v76, v1                                      // 000000213868: 7E980301
	v_mov_b32_e32 v77, v1                                      // 00000021386C: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 000000213870: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 000000213874: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 000000213878: 7EA00301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021387C: 8C7E007E
	ds_load_b128 v[25:28], v135                                // 000000213880: DBFC0000 19000087
	ds_load_b128 v[29:32], v135 offset:16                      // 000000213888: DBFC0010 1D000087
	ds_load_b128 v[49:52], v135 offset:32                      // 000000213890: DBFC0020 31000087
	ds_load_b128 v[53:56], v135 offset:48                      // 000000213898: DBFC0030 35000087
	ds_load_b128 v[92:95], v135 offset:8448                    // 0000002138A0: DBFC2100 5C000087
	ds_load_b128 v[96:99], v135 offset:8464                    // 0000002138A8: DBFC2110 60000087
	ds_load_b128 v[100:103], v135 offset:8480                  // 0000002138B0: DBFC2120 64000087
	ds_load_b128 v[104:107], v135 offset:8496                  // 0000002138B8: DBFC2130 68000087
	v_dual_mov_b32 v91, s27 :: v_dual_mov_b32 v90, s26         // 0000002138C0: CA10001B 5B5A001A
	v_dual_mov_b32 v89, s25 :: v_dual_mov_b32 v88, s24         // 0000002138C8: CA100019 59580018
	v_dual_mov_b32 v87, s23 :: v_dual_mov_b32 v86, s22         // 0000002138D0: CA100017 57560016
	v_dual_mov_b32 v85, s21 :: v_dual_mov_b32 v84, s20         // 0000002138D8: CA100015 55540014
	ds_load_b128 v[108:111], v135 offset:64                    // 0000002138E0: DBFC0040 6C000087
	ds_load_b128 v[155:158], v135 offset:80                    // 0000002138E8: DBFC0050 9B000087
	s_waitcnt lgkmcnt(9)                                       // 0000002138F0: BF89FC97
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000002138F4: CC210019 02004F19
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000002138FC: CC220019 02004F1A
	v_fma_mixlo_f16 v26, v27, s39, 0                           // 000000213904: CC21001A 02004F1B
	v_fma_mixhi_f16 v26, v28, s39, 0                           // 00000021390C: CC22001A 02004F1C
	s_waitcnt lgkmcnt(8)                                       // 000000213914: BF89FC87
	v_fma_mixlo_f16 v27, v29, s39, 0                           // 000000213918: CC21001B 02004F1D
	v_fma_mixhi_f16 v27, v30, s39, 0                           // 000000213920: CC22001B 02004F1E
	v_fma_mixlo_f16 v28, v31, s39, 0                           // 000000213928: CC21001C 02004F1F
	v_fma_mixhi_f16 v28, v32, s39, 0                           // 000000213930: CC22001C 02004F20
	s_waitcnt lgkmcnt(7)                                       // 000000213938: BF89FC77
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 00000021393C: CC21001D 02004F31
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 000000213944: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 00000021394C: CC21001E 02004F33
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 000000213954: CC22001E 02004F34
	s_waitcnt lgkmcnt(6)                                       // 00000021395C: BF89FC67
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 000000213960: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 000000213968: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 000000213970: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 000000213978: CC220020 02004F38
	s_waitcnt lgkmcnt(5)                                       // 000000213980: BF89FC57
	v_fma_mixlo_f16 v92, v92, s39, 0                           // 000000213984: CC21005C 02004F5C
	v_fma_mixhi_f16 v92, v93, s39, 0                           // 00000021398C: CC22005C 02004F5D
	v_fma_mixlo_f16 v93, v94, s39, 0                           // 000000213994: CC21005D 02004F5E
	v_fma_mixhi_f16 v93, v95, s39, 0                           // 00000021399C: CC22005D 02004F5F
	s_waitcnt lgkmcnt(4)                                       // 0000002139A4: BF89FC47
	v_fma_mixlo_f16 v94, v96, s39, 0                           // 0000002139A8: CC21005E 02004F60
	v_fma_mixhi_f16 v94, v97, s39, 0                           // 0000002139B0: CC22005E 02004F61
	v_fma_mixlo_f16 v95, v98, s39, 0                           // 0000002139B8: CC21005F 02004F62
	v_fma_mixhi_f16 v95, v99, s39, 0                           // 0000002139C0: CC22005F 02004F63
	s_waitcnt lgkmcnt(3)                                       // 0000002139C8: BF89FC37
	v_fma_mixlo_f16 v96, v100, s39, 0                          // 0000002139CC: CC210060 02004F64
	v_fma_mixhi_f16 v96, v101, s39, 0                          // 0000002139D4: CC220060 02004F65
	v_fma_mixlo_f16 v97, v102, s39, 0                          // 0000002139DC: CC210061 02004F66
	v_fma_mixhi_f16 v97, v103, s39, 0                          // 0000002139E4: CC220061 02004F67
	s_waitcnt lgkmcnt(2)                                       // 0000002139EC: BF89FC27
	v_fma_mixlo_f16 v98, v104, s39, 0                          // 0000002139F0: CC210062 02004F68
	v_fma_mixhi_f16 v98, v105, s39, 0                          // 0000002139F8: CC220062 02004F69
	v_fma_mixlo_f16 v99, v106, s39, 0                          // 000000213A00: CC210063 02004F6A
	v_fma_mixhi_f16 v99, v107, s39, 0                          // 000000213A08: CC220063 02004F6B
	ds_load_b128 v[100:103], v135 offset:96                    // 000000213A10: DBFC0060 64000087
	ds_load_b128 v[104:107], v135 offset:112                   // 000000213A18: DBFC0070 68000087
	s_waitcnt vmcnt(14)                                        // 000000213A20: BF893BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[25:32], v[84:91]// 000000213A24: CC404031 1D523349
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[92:99], v[84:91]// 000000213A2C: CC404019 1D52B949
	ds_load_b128 v[84:87], v135 offset:8512                    // 000000213A34: DBFC2140 54000087
	ds_load_b128 v[88:91], v135 offset:8528                    // 000000213A3C: DBFC2150 58000087
	ds_load_b128 v[92:95], v135 offset:8544                    // 000000213A44: DBFC2160 5C000087
	ds_load_b128 v[96:99], v135 offset:8560                    // 000000213A4C: DBFC2170 60000087
	s_waitcnt lgkmcnt(7)                                       // 000000213A54: BF89FC77
	v_fma_mixlo_f16 v73, v108, s39, 0                          // 000000213A58: CC210049 02004F6C
	v_fma_mixhi_f16 v73, v109, s39, 0                          // 000000213A60: CC220049 02004F6D
	v_fma_mixlo_f16 v74, v110, s39, 0                          // 000000213A68: CC21004A 02004F6E
	v_fma_mixhi_f16 v74, v111, s39, 0                          // 000000213A70: CC22004A 02004F6F
	s_waitcnt lgkmcnt(6)                                       // 000000213A78: BF89FC67
	v_fma_mixlo_f16 v75, v155, s39, 0                          // 000000213A7C: CC21004B 02004F9B
	v_fma_mixhi_f16 v75, v156, s39, 0                          // 000000213A84: CC22004B 02004F9C
	v_fma_mixlo_f16 v76, v157, s39, 0                          // 000000213A8C: CC21004C 02004F9D
	v_fma_mixhi_f16 v76, v158, s39, 0                          // 000000213A94: CC22004C 02004F9E
	v_add_nc_u32_e32 v155, s1, v137                            // 000000213A9C: 4B371201
	s_waitcnt lgkmcnt(5)                                       // 000000213AA0: BF89FC57
	v_fma_mixlo_f16 v77, v100, s39, 0                          // 000000213AA4: CC21004D 02004F64
	v_fma_mixhi_f16 v77, v101, s39, 0                          // 000000213AAC: CC22004D 02004F65
	v_fma_mixlo_f16 v78, v102, s39, 0                          // 000000213AB4: CC21004E 02004F66
	v_fma_mixhi_f16 v78, v103, s39, 0                          // 000000213ABC: CC22004E 02004F67
	s_waitcnt lgkmcnt(4)                                       // 000000213AC4: BF89FC47
	v_fma_mixlo_f16 v79, v104, s39, 0                          // 000000213AC8: CC21004F 02004F68
	v_fma_mixhi_f16 v79, v105, s39, 0                          // 000000213AD0: CC22004F 02004F69
	v_fma_mixlo_f16 v80, v106, s39, 0                          // 000000213AD8: CC210050 02004F6A
	v_fma_mixhi_f16 v80, v107, s39, 0                          // 000000213AE0: CC220050 02004F6B
	s_waitcnt lgkmcnt(3)                                       // 000000213AE8: BF89FC37
	v_fma_mixlo_f16 v84, v84, s39, 0                           // 000000213AEC: CC210054 02004F54
	v_fma_mixhi_f16 v84, v85, s39, 0                           // 000000213AF4: CC220054 02004F55
	v_fma_mixlo_f16 v85, v86, s39, 0                           // 000000213AFC: CC210055 02004F56
	v_fma_mixhi_f16 v85, v87, s39, 0                           // 000000213B04: CC220055 02004F57
	s_waitcnt lgkmcnt(2)                                       // 000000213B0C: BF89FC27
	v_fma_mixlo_f16 v86, v88, s39, 0                           // 000000213B10: CC210056 02004F58
	v_fma_mixhi_f16 v86, v89, s39, 0                           // 000000213B18: CC220056 02004F59
	v_fma_mixlo_f16 v87, v90, s39, 0                           // 000000213B20: CC210057 02004F5A
	v_fma_mixhi_f16 v87, v91, s39, 0                           // 000000213B28: CC220057 02004F5B
	s_waitcnt lgkmcnt(1)                                       // 000000213B30: BF89FC17
	v_fma_mixlo_f16 v88, v92, s39, 0                           // 000000213B34: CC210058 02004F5C
	v_fma_mixhi_f16 v88, v93, s39, 0                           // 000000213B3C: CC220058 02004F5D
	v_fma_mixlo_f16 v89, v94, s39, 0                           // 000000213B44: CC210059 02004F5E
	v_fma_mixhi_f16 v89, v95, s39, 0                           // 000000213B4C: CC220059 02004F5F
	s_waitcnt lgkmcnt(0)                                       // 000000213B54: BF89FC07
	v_fma_mixlo_f16 v90, v96, s39, 0                           // 000000213B58: CC21005A 02004F60
	v_fma_mixhi_f16 v90, v97, s39, 0                           // 000000213B60: CC22005A 02004F61
	v_fma_mixlo_f16 v91, v98, s39, 0                           // 000000213B68: CC21005B 02004F62
	v_fma_mixhi_f16 v91, v99, s39, 0                           // 000000213B70: CC22005B 02004F63
	ds_load_b128 v[100:103], v135 offset:128                   // 000000213B78: DBFC0080 64000087
	ds_load_b128 v[104:107], v135 offset:144                   // 000000213B80: DBFC0090 68000087
	ds_load_b128 v[92:95], v135 offset:160                     // 000000213B88: DBFC00A0 5C000087
	ds_load_b128 v[96:99], v135 offset:176                     // 000000213B90: DBFC00B0 60000087
	s_waitcnt vmcnt(12)                                        // 000000213B98: BF8933F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[73:80], v[49:56]// 000000213B9C: CC404031 1CC69341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[84:91], v[25:32]// 000000213BA4: CC404019 1C66A941
	ds_load_b128 v[73:76], v135 offset:8576                    // 000000213BAC: DBFC2180 49000087
	ds_load_b128 v[77:80], v135 offset:8592                    // 000000213BB4: DBFC2190 4D000087
	ds_load_b128 v[84:87], v135 offset:8608                    // 000000213BBC: DBFC21A0 54000087
	ds_load_b128 v[88:91], v135 offset:8624                    // 000000213BC4: DBFC21B0 58000087
	.long 0xd4440000                                           // 000000213BCC: D4440000
	v_cndmask_b32_e32 v1, s50, v155, vcc_lo                    // 000000213BD0: 02033632
	s_waitcnt lgkmcnt(7)                                       // 000000213BD4: BF89FC77
	v_fma_mixlo_f16 v65, v100, s39, 0                          // 000000213BD8: CC210041 02004F64
	v_fma_mixhi_f16 v65, v101, s39, 0                          // 000000213BE0: CC220041 02004F65
	v_fma_mixlo_f16 v66, v102, s39, 0                          // 000000213BE8: CC210042 02004F66
	v_fma_mixhi_f16 v66, v103, s39, 0                          // 000000213BF0: CC220042 02004F67
	s_waitcnt lgkmcnt(6)                                       // 000000213BF8: BF89FC67
	v_fma_mixlo_f16 v67, v104, s39, 0                          // 000000213BFC: CC210043 02004F68
	v_fma_mixhi_f16 v67, v105, s39, 0                          // 000000213C04: CC220043 02004F69
	v_fma_mixlo_f16 v68, v106, s39, 0                          // 000000213C0C: CC210044 02004F6A
	v_fma_mixhi_f16 v68, v107, s39, 0                          // 000000213C14: CC220044 02004F6B
	s_waitcnt lgkmcnt(5)                                       // 000000213C1C: BF89FC57
	v_fma_mixlo_f16 v69, v92, s39, 0                           // 000000213C20: CC210045 02004F5C
	v_fma_mixhi_f16 v69, v93, s39, 0                           // 000000213C28: CC220045 02004F5D
	v_fma_mixlo_f16 v70, v94, s39, 0                           // 000000213C30: CC210046 02004F5E
	v_fma_mixhi_f16 v70, v95, s39, 0                           // 000000213C38: CC220046 02004F5F
	s_waitcnt lgkmcnt(4)                                       // 000000213C40: BF89FC47
	v_fma_mixlo_f16 v71, v96, s39, 0                           // 000000213C44: CC210047 02004F60
	v_fma_mixhi_f16 v71, v97, s39, 0                           // 000000213C4C: CC220047 02004F61
	v_fma_mixlo_f16 v72, v98, s39, 0                           // 000000213C54: CC210048 02004F62
	v_fma_mixhi_f16 v72, v99, s39, 0                           // 000000213C5C: CC220048 02004F63
	s_waitcnt lgkmcnt(3)                                       // 000000213C64: BF89FC37
	v_fma_mixlo_f16 v73, v73, s39, 0                           // 000000213C68: CC210049 02004F49
	v_fma_mixhi_f16 v73, v74, s39, 0                           // 000000213C70: CC220049 02004F4A
	v_fma_mixlo_f16 v74, v75, s39, 0                           // 000000213C78: CC21004A 02004F4B
	v_fma_mixhi_f16 v74, v76, s39, 0                           // 000000213C80: CC22004A 02004F4C
	s_waitcnt lgkmcnt(2)                                       // 000000213C88: BF89FC27
	v_fma_mixlo_f16 v75, v77, s39, 0                           // 000000213C8C: CC21004B 02004F4D
	v_fma_mixhi_f16 v75, v78, s39, 0                           // 000000213C94: CC22004B 02004F4E
	v_fma_mixlo_f16 v76, v79, s39, 0                           // 000000213C9C: CC21004C 02004F4F
	v_fma_mixhi_f16 v76, v80, s39, 0                           // 000000213CA4: CC22004C 02004F50
	s_waitcnt lgkmcnt(1)                                       // 000000213CAC: BF89FC17
	v_fma_mixlo_f16 v77, v84, s39, 0                           // 000000213CB0: CC21004D 02004F54
	v_fma_mixhi_f16 v77, v85, s39, 0                           // 000000213CB8: CC22004D 02004F55
	v_fma_mixlo_f16 v78, v86, s39, 0                           // 000000213CC0: CC21004E 02004F56
	v_fma_mixhi_f16 v78, v87, s39, 0                           // 000000213CC8: CC22004E 02004F57
	s_waitcnt lgkmcnt(0)                                       // 000000213CD0: BF89FC07
	v_fma_mixlo_f16 v79, v88, s39, 0                           // 000000213CD4: CC21004F 02004F58
	v_fma_mixhi_f16 v79, v89, s39, 0                           // 000000213CDC: CC22004F 02004F59
	v_fma_mixlo_f16 v80, v90, s39, 0                           // 000000213CE4: CC210050 02004F5A
	v_fma_mixhi_f16 v80, v91, s39, 0                           // 000000213CEC: CC220050 02004F5B
	ds_load_b128 v[92:95], v135 offset:192                     // 000000213CF4: DBFC00C0 5C000087
	ds_load_b128 v[96:99], v135 offset:208                     // 000000213CFC: DBFC00D0 60000087
	ds_load_b128 v[84:87], v135 offset:224                     // 000000213D04: DBFC00E0 54000087
	ds_load_b128 v[88:91], v135 offset:240                     // 000000213D0C: DBFC00F0 58000087
	s_waitcnt vmcnt(10)                                        // 000000213D14: BF892BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[65:72], v[49:56]// 000000213D18: CC404031 1CC68339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 000000213D20: CC404019 1C669339
	ds_load_b128 v[65:68], v135 offset:8640                    // 000000213D28: DBFC21C0 41000087
	ds_load_b128 v[69:72], v135 offset:8656                    // 000000213D30: DBFC21D0 45000087
	ds_load_b128 v[73:76], v135 offset:8672                    // 000000213D38: DBFC21E0 49000087
	ds_load_b128 v[77:80], v135 offset:8688                    // 000000213D40: DBFC21F0 4D000087
	s_waitcnt lgkmcnt(7)                                       // 000000213D48: BF89FC77
	v_fma_mixlo_f16 v57, v92, s39, 0                           // 000000213D4C: CC210039 02004F5C
	v_fma_mixhi_f16 v57, v93, s39, 0                           // 000000213D54: CC220039 02004F5D
	v_fma_mixlo_f16 v58, v94, s39, 0                           // 000000213D5C: CC21003A 02004F5E
	v_fma_mixhi_f16 v58, v95, s39, 0                           // 000000213D64: CC22003A 02004F5F
	s_waitcnt lgkmcnt(6)                                       // 000000213D6C: BF89FC67
	v_fma_mixlo_f16 v59, v96, s39, 0                           // 000000213D70: CC21003B 02004F60
	v_fma_mixhi_f16 v59, v97, s39, 0                           // 000000213D78: CC22003B 02004F61
	v_fma_mixlo_f16 v60, v98, s39, 0                           // 000000213D80: CC21003C 02004F62
	v_fma_mixhi_f16 v60, v99, s39, 0                           // 000000213D88: CC22003C 02004F63
	s_waitcnt lgkmcnt(5)                                       // 000000213D90: BF89FC57
	v_fma_mixlo_f16 v61, v84, s39, 0                           // 000000213D94: CC21003D 02004F54
	v_fma_mixhi_f16 v61, v85, s39, 0                           // 000000213D9C: CC22003D 02004F55
	v_fma_mixlo_f16 v62, v86, s39, 0                           // 000000213DA4: CC21003E 02004F56
	v_fma_mixhi_f16 v62, v87, s39, 0                           // 000000213DAC: CC22003E 02004F57
	s_waitcnt lgkmcnt(4)                                       // 000000213DB4: BF89FC47
	v_fma_mixlo_f16 v63, v88, s39, 0                           // 000000213DB8: CC21003F 02004F58
	v_fma_mixhi_f16 v63, v89, s39, 0                           // 000000213DC0: CC22003F 02004F59
	v_fma_mixlo_f16 v64, v90, s39, 0                           // 000000213DC8: CC210040 02004F5A
	v_fma_mixhi_f16 v64, v91, s39, 0                           // 000000213DD0: CC220040 02004F5B
	s_waitcnt lgkmcnt(3)                                       // 000000213DD8: BF89FC37
	v_fma_mixlo_f16 v65, v65, s39, 0                           // 000000213DDC: CC210041 02004F41
	v_fma_mixhi_f16 v65, v66, s39, 0                           // 000000213DE4: CC220041 02004F42
	v_fma_mixlo_f16 v66, v67, s39, 0                           // 000000213DEC: CC210042 02004F43
	v_fma_mixhi_f16 v66, v68, s39, 0                           // 000000213DF4: CC220042 02004F44
	s_waitcnt lgkmcnt(2)                                       // 000000213DFC: BF89FC27
	v_fma_mixlo_f16 v67, v69, s39, 0                           // 000000213E00: CC210043 02004F45
	v_fma_mixhi_f16 v67, v70, s39, 0                           // 000000213E08: CC220043 02004F46
	v_fma_mixlo_f16 v68, v71, s39, 0                           // 000000213E10: CC210044 02004F47
	v_fma_mixhi_f16 v68, v72, s39, 0                           // 000000213E18: CC220044 02004F48
	s_waitcnt lgkmcnt(1)                                       // 000000213E20: BF89FC17
	v_fma_mixlo_f16 v69, v73, s39, 0                           // 000000213E24: CC210045 02004F49
	v_fma_mixhi_f16 v69, v74, s39, 0                           // 000000213E2C: CC220045 02004F4A
	v_fma_mixlo_f16 v70, v75, s39, 0                           // 000000213E34: CC210046 02004F4B
	v_fma_mixhi_f16 v70, v76, s39, 0                           // 000000213E3C: CC220046 02004F4C
	s_waitcnt lgkmcnt(0)                                       // 000000213E44: BF89FC07
	v_fma_mixlo_f16 v71, v77, s39, 0                           // 000000213E48: CC210047 02004F4D
	v_fma_mixhi_f16 v71, v78, s39, 0                           // 000000213E50: CC220047 02004F4E
	v_fma_mixlo_f16 v72, v79, s39, 0                           // 000000213E58: CC210048 02004F4F
	v_fma_mixhi_f16 v72, v80, s39, 0                           // 000000213E60: CC220048 02004F50
	ds_load_b128 v[84:87], v135 offset:256                     // 000000213E68: DBFC0100 54000087
	ds_load_b128 v[88:91], v135 offset:272                     // 000000213E70: DBFC0110 58000087
	ds_load_b128 v[73:76], v135 offset:288                     // 000000213E78: DBFC0120 49000087
	ds_load_b128 v[77:80], v135 offset:304                     // 000000213E80: DBFC0130 4D000087
	s_waitcnt vmcnt(8)                                         // 000000213E88: BF8923F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[41:48], v[57:64], v[49:56]// 000000213E8C: CC404031 1CC67329
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[65:72], v[25:32]// 000000213E94: CC404019 1C668329
	ds_load_b128 v[57:60], v135 offset:8704                    // 000000213E9C: DBFC2200 39000087
	ds_load_b128 v[61:64], v135 offset:8720                    // 000000213EA4: DBFC2210 3D000087
	ds_load_b128 v[65:68], v135 offset:8736                    // 000000213EAC: DBFC2220 41000087
	ds_load_b128 v[69:72], v135 offset:8752                    // 000000213EB4: DBFC2230 45000087
	s_waitcnt lgkmcnt(7)                                       // 000000213EBC: BF89FC77
	v_fma_mixlo_f16 v41, v84, s39, 0                           // 000000213EC0: CC210029 02004F54
	v_fma_mixhi_f16 v41, v85, s39, 0                           // 000000213EC8: CC220029 02004F55
	v_fma_mixlo_f16 v42, v86, s39, 0                           // 000000213ED0: CC21002A 02004F56
	v_fma_mixhi_f16 v42, v87, s39, 0                           // 000000213ED8: CC22002A 02004F57
	s_waitcnt lgkmcnt(6)                                       // 000000213EE0: BF89FC67
	v_fma_mixlo_f16 v43, v88, s39, 0                           // 000000213EE4: CC21002B 02004F58
	v_fma_mixhi_f16 v43, v89, s39, 0                           // 000000213EEC: CC22002B 02004F59
	v_fma_mixlo_f16 v44, v90, s39, 0                           // 000000213EF4: CC21002C 02004F5A
	v_fma_mixhi_f16 v44, v91, s39, 0                           // 000000213EFC: CC22002C 02004F5B
	s_waitcnt lgkmcnt(5)                                       // 000000213F04: BF89FC57
	v_fma_mixlo_f16 v45, v73, s39, 0                           // 000000213F08: CC21002D 02004F49
	v_fma_mixhi_f16 v45, v74, s39, 0                           // 000000213F10: CC22002D 02004F4A
	v_fma_mixlo_f16 v46, v75, s39, 0                           // 000000213F18: CC21002E 02004F4B
	v_fma_mixhi_f16 v46, v76, s39, 0                           // 000000213F20: CC22002E 02004F4C
	s_waitcnt lgkmcnt(4)                                       // 000000213F28: BF89FC47
	v_fma_mixlo_f16 v47, v77, s39, 0                           // 000000213F2C: CC21002F 02004F4D
	v_fma_mixhi_f16 v47, v78, s39, 0                           // 000000213F34: CC22002F 02004F4E
	v_fma_mixlo_f16 v48, v79, s39, 0                           // 000000213F3C: CC210030 02004F4F
	v_fma_mixhi_f16 v48, v80, s39, 0                           // 000000213F44: CC220030 02004F50
	s_waitcnt lgkmcnt(3)                                       // 000000213F4C: BF89FC37
	v_fma_mixlo_f16 v57, v57, s39, 0                           // 000000213F50: CC210039 02004F39
	v_fma_mixhi_f16 v57, v58, s39, 0                           // 000000213F58: CC220039 02004F3A
	v_fma_mixlo_f16 v58, v59, s39, 0                           // 000000213F60: CC21003A 02004F3B
	v_fma_mixhi_f16 v58, v60, s39, 0                           // 000000213F68: CC22003A 02004F3C
	s_waitcnt lgkmcnt(2)                                       // 000000213F70: BF89FC27
	v_fma_mixlo_f16 v59, v61, s39, 0                           // 000000213F74: CC21003B 02004F3D
	v_fma_mixhi_f16 v59, v62, s39, 0                           // 000000213F7C: CC22003B 02004F3E
	v_fma_mixlo_f16 v60, v63, s39, 0                           // 000000213F84: CC21003C 02004F3F
	v_fma_mixhi_f16 v60, v64, s39, 0                           // 000000213F8C: CC22003C 02004F40
	s_waitcnt lgkmcnt(1)                                       // 000000213F94: BF89FC17
	v_fma_mixlo_f16 v61, v65, s39, 0                           // 000000213F98: CC21003D 02004F41
	v_fma_mixhi_f16 v61, v66, s39, 0                           // 000000213FA0: CC22003D 02004F42
	v_fma_mixlo_f16 v62, v67, s39, 0                           // 000000213FA8: CC21003E 02004F43
	v_fma_mixhi_f16 v62, v68, s39, 0                           // 000000213FB0: CC22003E 02004F44
	s_waitcnt lgkmcnt(0)                                       // 000000213FB8: BF89FC07
	v_fma_mixlo_f16 v63, v69, s39, 0                           // 000000213FBC: CC21003F 02004F45
	v_fma_mixhi_f16 v63, v70, s39, 0                           // 000000213FC4: CC22003F 02004F46
	v_fma_mixlo_f16 v64, v71, s39, 0                           // 000000213FCC: CC210040 02004F47
	v_fma_mixhi_f16 v64, v72, s39, 0                           // 000000213FD4: CC220040 02004F48
	ds_load_b128 v[73:76], v135 offset:320                     // 000000213FDC: DBFC0140 49000087
	ds_load_b128 v[77:80], v135 offset:336                     // 000000213FE4: DBFC0150 4D000087
	ds_load_b128 v[65:68], v135 offset:352                     // 000000213FEC: DBFC0160 41000087
	ds_load_b128 v[69:72], v135 offset:368                     // 000000213FF4: DBFC0170 45000087
	s_waitcnt vmcnt(6)                                         // 000000213FFC: BF891BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[41:48], v[49:56]// 000000214000: CC404031 1CC65321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[57:64], v[25:32]// 000000214008: CC404019 1C667321
	ds_load_b128 v[41:44], v135 offset:8768                    // 000000214010: DBFC2240 29000087
	ds_load_b128 v[45:48], v135 offset:8784                    // 000000214018: DBFC2250 2D000087
	ds_load_b128 v[57:60], v135 offset:8800                    // 000000214020: DBFC2260 39000087
	ds_load_b128 v[61:64], v135 offset:8816                    // 000000214028: DBFC2270 3D000087
	s_waitcnt lgkmcnt(7)                                       // 000000214030: BF89FC77
	v_fma_mixlo_f16 v33, v73, s39, 0                           // 000000214034: CC210021 02004F49
	v_fma_mixhi_f16 v33, v74, s39, 0                           // 00000021403C: CC220021 02004F4A
	v_fma_mixlo_f16 v34, v75, s39, 0                           // 000000214044: CC210022 02004F4B
	v_fma_mixhi_f16 v34, v76, s39, 0                           // 00000021404C: CC220022 02004F4C
	s_waitcnt lgkmcnt(6)                                       // 000000214054: BF89FC67
	v_fma_mixlo_f16 v35, v77, s39, 0                           // 000000214058: CC210023 02004F4D
	v_fma_mixhi_f16 v35, v78, s39, 0                           // 000000214060: CC220023 02004F4E
	v_fma_mixlo_f16 v36, v79, s39, 0                           // 000000214068: CC210024 02004F4F
	v_fma_mixhi_f16 v36, v80, s39, 0                           // 000000214070: CC220024 02004F50
	s_waitcnt lgkmcnt(5)                                       // 000000214078: BF89FC57
	v_fma_mixlo_f16 v37, v65, s39, 0                           // 00000021407C: CC210025 02004F41
	v_fma_mixhi_f16 v37, v66, s39, 0                           // 000000214084: CC220025 02004F42
	v_fma_mixlo_f16 v38, v67, s39, 0                           // 00000021408C: CC210026 02004F43
	v_fma_mixhi_f16 v38, v68, s39, 0                           // 000000214094: CC220026 02004F44
	s_waitcnt lgkmcnt(4)                                       // 00000021409C: BF89FC47
	v_fma_mixlo_f16 v39, v69, s39, 0                           // 0000002140A0: CC210027 02004F45
	v_fma_mixhi_f16 v39, v70, s39, 0                           // 0000002140A8: CC220027 02004F46
	v_fma_mixlo_f16 v40, v71, s39, 0                           // 0000002140B0: CC210028 02004F47
	v_fma_mixhi_f16 v40, v72, s39, 0                           // 0000002140B8: CC220028 02004F48
	s_waitcnt lgkmcnt(3)                                       // 0000002140C0: BF89FC37
	v_fma_mixlo_f16 v41, v41, s39, 0                           // 0000002140C4: CC210029 02004F29
	v_fma_mixhi_f16 v41, v42, s39, 0                           // 0000002140CC: CC220029 02004F2A
	v_fma_mixlo_f16 v42, v43, s39, 0                           // 0000002140D4: CC21002A 02004F2B
	v_fma_mixhi_f16 v42, v44, s39, 0                           // 0000002140DC: CC22002A 02004F2C
	s_waitcnt lgkmcnt(2)                                       // 0000002140E4: BF89FC27
	v_fma_mixlo_f16 v43, v45, s39, 0                           // 0000002140E8: CC21002B 02004F2D
	v_fma_mixhi_f16 v43, v46, s39, 0                           // 0000002140F0: CC22002B 02004F2E
	v_fma_mixlo_f16 v44, v47, s39, 0                           // 0000002140F8: CC21002C 02004F2F
	v_fma_mixhi_f16 v44, v48, s39, 0                           // 000000214100: CC22002C 02004F30
	s_waitcnt lgkmcnt(1)                                       // 000000214108: BF89FC17
	v_fma_mixlo_f16 v45, v57, s39, 0                           // 00000021410C: CC21002D 02004F39
	v_fma_mixhi_f16 v45, v58, s39, 0                           // 000000214114: CC22002D 02004F3A
	v_fma_mixlo_f16 v46, v59, s39, 0                           // 00000021411C: CC21002E 02004F3B
	v_fma_mixhi_f16 v46, v60, s39, 0                           // 000000214124: CC22002E 02004F3C
	s_waitcnt lgkmcnt(0)                                       // 00000021412C: BF89FC07
	v_fma_mixlo_f16 v47, v61, s39, 0                           // 000000214130: CC21002F 02004F3D
	v_fma_mixhi_f16 v47, v62, s39, 0                           // 000000214138: CC22002F 02004F3E
	v_fma_mixlo_f16 v48, v63, s39, 0                           // 000000214140: CC210030 02004F3F
	v_fma_mixhi_f16 v48, v64, s39, 0                           // 000000214148: CC220030 02004F40
	ds_load_b128 v[65:68], v135 offset:384                     // 000000214150: DBFC0180 41000087
	ds_load_b128 v[69:72], v135 offset:400                     // 000000214158: DBFC0190 45000087
	ds_load_b128 v[57:60], v135 offset:416                     // 000000214160: DBFC01A0 39000087
	ds_load_b128 v[61:64], v135 offset:432                     // 000000214168: DBFC01B0 3D000087
	s_waitcnt vmcnt(4)                                         // 000000214170: BF8913F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[17:24], v[33:40], v[49:56]// 000000214174: CC404031 1CC64311
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[41:48], v[25:32]// 00000021417C: CC404019 1C665311
	ds_load_b128 v[33:36], v135 offset:8832                    // 000000214184: DBFC2280 21000087
	ds_load_b128 v[37:40], v135 offset:8848                    // 00000021418C: DBFC2290 25000087
	ds_load_b128 v[41:44], v135 offset:8864                    // 000000214194: DBFC22A0 29000087
	ds_load_b128 v[45:48], v135 offset:8880                    // 00000021419C: DBFC22B0 2D000087
	s_waitcnt lgkmcnt(7)                                       // 0000002141A4: BF89FC77
	v_fma_mixlo_f16 v17, v65, s39, 0                           // 0000002141A8: CC210011 02004F41
	v_fma_mixhi_f16 v17, v66, s39, 0                           // 0000002141B0: CC220011 02004F42
	v_fma_mixlo_f16 v18, v67, s39, 0                           // 0000002141B8: CC210012 02004F43
	v_fma_mixhi_f16 v18, v68, s39, 0                           // 0000002141C0: CC220012 02004F44
	s_waitcnt lgkmcnt(6)                                       // 0000002141C8: BF89FC67
	v_fma_mixlo_f16 v19, v69, s39, 0                           // 0000002141CC: CC210013 02004F45
	v_fma_mixhi_f16 v19, v70, s39, 0                           // 0000002141D4: CC220013 02004F46
	v_fma_mixlo_f16 v20, v71, s39, 0                           // 0000002141DC: CC210014 02004F47
	v_fma_mixhi_f16 v20, v72, s39, 0                           // 0000002141E4: CC220014 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000002141EC: BF89FC57
	v_fma_mixlo_f16 v21, v57, s39, 0                           // 0000002141F0: CC210015 02004F39
	v_fma_mixhi_f16 v21, v58, s39, 0                           // 0000002141F8: CC220015 02004F3A
	v_fma_mixlo_f16 v22, v59, s39, 0                           // 000000214200: CC210016 02004F3B
	v_fma_mixhi_f16 v22, v60, s39, 0                           // 000000214208: CC220016 02004F3C
	s_waitcnt lgkmcnt(4)                                       // 000000214210: BF89FC47
	v_fma_mixlo_f16 v23, v61, s39, 0                           // 000000214214: CC210017 02004F3D
	v_fma_mixhi_f16 v23, v62, s39, 0                           // 00000021421C: CC220017 02004F3E
	v_fma_mixlo_f16 v24, v63, s39, 0                           // 000000214224: CC210018 02004F3F
	v_fma_mixhi_f16 v24, v64, s39, 0                           // 00000021422C: CC220018 02004F40
	s_waitcnt lgkmcnt(3)                                       // 000000214234: BF89FC37
	v_fma_mixlo_f16 v33, v33, s39, 0                           // 000000214238: CC210021 02004F21
	v_fma_mixhi_f16 v33, v34, s39, 0                           // 000000214240: CC220021 02004F22
	v_fma_mixlo_f16 v34, v35, s39, 0                           // 000000214248: CC210022 02004F23
	v_fma_mixhi_f16 v34, v36, s39, 0                           // 000000214250: CC220022 02004F24
	s_waitcnt lgkmcnt(2)                                       // 000000214258: BF89FC27
	v_fma_mixlo_f16 v35, v37, s39, 0                           // 00000021425C: CC210023 02004F25
	v_fma_mixhi_f16 v35, v38, s39, 0                           // 000000214264: CC220023 02004F26
	v_fma_mixlo_f16 v36, v39, s39, 0                           // 00000021426C: CC210024 02004F27
	v_fma_mixhi_f16 v36, v40, s39, 0                           // 000000214274: CC220024 02004F28
	s_waitcnt lgkmcnt(1)                                       // 00000021427C: BF89FC17
	v_fma_mixlo_f16 v37, v41, s39, 0                           // 000000214280: CC210025 02004F29
	v_fma_mixhi_f16 v37, v42, s39, 0                           // 000000214288: CC220025 02004F2A
	v_fma_mixlo_f16 v38, v43, s39, 0                           // 000000214290: CC210026 02004F2B
	v_fma_mixhi_f16 v38, v44, s39, 0                           // 000000214298: CC220026 02004F2C
	s_waitcnt lgkmcnt(0)                                       // 0000002142A0: BF89FC07
	v_fma_mixlo_f16 v39, v45, s39, 0                           // 0000002142A4: CC210027 02004F2D
	v_fma_mixhi_f16 v39, v46, s39, 0                           // 0000002142AC: CC220027 02004F2E
	v_fma_mixlo_f16 v40, v47, s39, 0                           // 0000002142B4: CC210028 02004F2F
	v_fma_mixhi_f16 v40, v48, s39, 0                           // 0000002142BC: CC220028 02004F30
	ds_load_b128 v[57:60], v135 offset:448                     // 0000002142C4: DBFC01C0 39000087
	ds_load_b128 v[61:64], v135 offset:464                     // 0000002142CC: DBFC01D0 3D000087
	ds_load_b128 v[41:44], v135 offset:480                     // 0000002142D4: DBFC01E0 29000087
	ds_load_b128 v[45:48], v135 offset:496                     // 0000002142DC: DBFC01F0 2D000087
	s_waitcnt vmcnt(2)                                         // 0000002142E4: BF890BF7
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[17:24], v[49:56]// 0000002142E8: CC404031 1CC62309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[33:40], v[25:32]// 0000002142F0: CC404019 1C664309
	ds_load_b128 v[17:20], v135 offset:8896                    // 0000002142F8: DBFC22C0 11000087
	ds_load_b128 v[21:24], v135 offset:8912                    // 000000214300: DBFC22D0 15000087
	ds_load_b128 v[33:36], v135 offset:8928                    // 000000214308: DBFC22E0 21000087
	ds_load_b128 v[37:40], v135 offset:8944                    // 000000214310: DBFC22F0 25000087
	s_waitcnt lgkmcnt(7)                                       // 000000214318: BF89FC77
	v_fma_mixlo_f16 v9, v57, s39, 0                            // 00000021431C: CC210009 02004F39
	v_fma_mixhi_f16 v9, v58, s39, 0                            // 000000214324: CC220009 02004F3A
	v_fma_mixlo_f16 v10, v59, s39, 0                           // 00000021432C: CC21000A 02004F3B
	v_fma_mixhi_f16 v10, v60, s39, 0                           // 000000214334: CC22000A 02004F3C
	s_waitcnt lgkmcnt(6)                                       // 00000021433C: BF89FC67
	v_fma_mixlo_f16 v11, v61, s39, 0                           // 000000214340: CC21000B 02004F3D
	v_fma_mixhi_f16 v11, v62, s39, 0                           // 000000214348: CC22000B 02004F3E
	v_fma_mixlo_f16 v12, v63, s39, 0                           // 000000214350: CC21000C 02004F3F
	v_fma_mixhi_f16 v12, v64, s39, 0                           // 000000214358: CC22000C 02004F40
	s_waitcnt lgkmcnt(5)                                       // 000000214360: BF89FC57
	v_fma_mixlo_f16 v13, v41, s39, 0                           // 000000214364: CC21000D 02004F29
	v_fma_mixhi_f16 v13, v42, s39, 0                           // 00000021436C: CC22000D 02004F2A
	v_fma_mixlo_f16 v14, v43, s39, 0                           // 000000214374: CC21000E 02004F2B
	v_fma_mixhi_f16 v14, v44, s39, 0                           // 00000021437C: CC22000E 02004F2C
	s_waitcnt lgkmcnt(4)                                       // 000000214384: BF89FC47
	v_fma_mixlo_f16 v15, v45, s39, 0                           // 000000214388: CC21000F 02004F2D
	v_fma_mixhi_f16 v15, v46, s39, 0                           // 000000214390: CC22000F 02004F2E
	v_fma_mixlo_f16 v16, v47, s39, 0                           // 000000214398: CC210010 02004F2F
	v_fma_mixhi_f16 v16, v48, s39, 0                           // 0000002143A0: CC220010 02004F30
	s_waitcnt lgkmcnt(3)                                       // 0000002143A8: BF89FC37
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000002143AC: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000002143B4: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000002143BC: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000002143C4: CC220012 02004F14
	s_waitcnt lgkmcnt(2)                                       // 0000002143CC: BF89FC27
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000002143D0: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000002143D8: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000002143E0: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000002143E8: CC220014 02004F18
	s_waitcnt lgkmcnt(1)                                       // 0000002143F0: BF89FC17
	v_fma_mixlo_f16 v21, v33, s39, 0                           // 0000002143F4: CC210015 02004F21
	v_fma_mixhi_f16 v21, v34, s39, 0                           // 0000002143FC: CC220015 02004F22
	v_fma_mixlo_f16 v22, v35, s39, 0                           // 000000214404: CC210016 02004F23
	v_fma_mixhi_f16 v22, v36, s39, 0                           // 00000021440C: CC220016 02004F24
	s_waitcnt lgkmcnt(0)                                       // 000000214414: BF89FC07
	v_fma_mixlo_f16 v23, v37, s39, 0                           // 000000214418: CC210017 02004F25
	v_fma_mixhi_f16 v23, v38, s39, 0                           // 000000214420: CC220017 02004F26
	v_fma_mixlo_f16 v24, v39, s39, 0                           // 000000214428: CC210018 02004F27
	v_fma_mixhi_f16 v24, v40, s39, 0                           // 000000214430: CC220018 02004F28
	s_waitcnt vmcnt(0)                                         // 000000214438: BF8903F7
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[9:16], v[49:56]// 00000021443C: CC404031 1CC61301
	s_delay_alu instid0(VALU_DEP_2)                            // 000000214444: BF870002
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[17:24], v[25:32]// 000000214448: CC404019 1C662301
	s_and_saveexec_b32 s7, s0                                  // 000000214450: BE872000
	s_cbranch_execz 17                                         // 000000214454: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2a9c>
	v_mad_u64_u32 v[1:2], null, v155, 48, s[2:3]               // 000000214458: D6FE7C01 0009619B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214460: BF870091
	.long 0xd73c0001                                           // 000000214464: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000214468: 02020289
	.long 0xd7000101                                           // 00000021446C: D7000101
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 000000214470: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214474: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s1                 // 000000214478: D5207C02 0006058F
	global_load_b32 v1, v[1:2], off                            // 000000214480: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000214488: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v49                         // 00000021448C: 560262FF BB800000
	v_fma_mixlo_f16 v81, v1, s39, 0                            // 000000214494: CC210051 02004F01
	s_or_b32 exec_lo, exec_lo, s7                              // 00000021449C: 8C7E077E
	v_add_nc_u32_e32 v156, 2, v155                             // 0000002144A0: 4B393682
	.long 0x7e023880                                           // 0000002144A4: 7E023880
	ds_store_b16 v144, v81                                     // 0000002144A8: D87C0000 00005190
	.long 0xd4440001                                           // 0000002144B0: D4440001
	v_cndmask_b32_e32 v1, s50, v156, vcc_lo                    // 0000002144B4: 02033832
	.long 0x7f023901                                           // 0000002144B8: 7F023901
	s_and_saveexec_b32 s8, s1                                  // 0000002144BC: BE882001
	s_cbranch_execz 17                                         // 0000002144C0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2b08>
	v_mad_u64_u32 v[2:3], null, v156, 48, s[2:3]               // 0000002144C4: D6FE7C02 0009619C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002144CC: BF870091
	.long 0xd73c0002                                           // 0000002144D0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002144D4: 02020489
	.long 0xd7000702                                           // 0000002144D8: D7000702
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 0000002144DC: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002144E0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s7                 // 0000002144E4: D5207C03 001E078F
	global_load_b32 v2, v[2:3], off                            // 0000002144EC: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000002144F4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v50                         // 0000002144F8: 560464FF BB800000
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 000000214500: CC220001 02004F02
	s_or_b32 exec_lo, exec_lo, s8                              // 000000214508: 8C7E087E
	v_add_nc_u32_e32 v157, 4, v155                             // 00000021450C: 4B3B3684
	ds_store_b16_d16_hi v144, v1 offset:4                      // 000000214510: DA840004 00000190
	.long 0xd4440007                                           // 000000214518: D4440007
	v_cndmask_b32_e32 v1, s50, v157, vcc_lo                    // 00000021451C: 02033A32
	s_and_saveexec_b32 s9, s7                                  // 000000214520: BE892007
	s_cbranch_execz 17                                         // 000000214524: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2b6c>
	v_mad_u64_u32 v[1:2], null, v157, 48, s[2:3]               // 000000214528: D6FE7C01 0009619D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214530: BF870091
	.long 0xd73c0001                                           // 000000214534: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000214538: 02020289
	.long 0xd7000801                                           // 00000021453C: D7000801
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 000000214540: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214544: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s8                 // 000000214548: D5207C02 0022058F
	global_load_b32 v1, v[1:2], off                            // 000000214550: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000214558: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v51                         // 00000021455C: 560266FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 000000214564: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s9                              // 00000021456C: 8C7E097E
	v_add_nc_u32_e32 v158, 6, v155                             // 000000214570: 4B3D3686
	.long 0x7f023880                                           // 000000214574: 7F023880
	ds_store_b16 v144, v1 offset:8                             // 000000214578: D87C0008 00000190
	.long 0xd4440008                                           // 000000214580: D4440008
	v_cndmask_b32_e32 v1, s50, v158, vcc_lo                    // 000000214584: 02033C32
	.long 0x7e043981                                           // 000000214588: 7E043981
	s_and_saveexec_b32 s10, s8                                 // 00000021458C: BE8A2008
	s_cbranch_execz 17                                         // 000000214590: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2bd8>
	v_mad_u64_u32 v[2:3], null, v158, 48, s[2:3]               // 000000214594: D6FE7C02 0009619E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021459C: BF870091
	.long 0xd73c0002                                           // 0000002145A0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002145A4: 02020489
	.long 0xd7000902                                           // 0000002145A8: D7000902
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 0000002145AC: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002145B0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s9                 // 0000002145B4: D5207C03 0026078F
	global_load_b32 v2, v[2:3], off                            // 0000002145BC: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000002145C4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v52                         // 0000002145C8: 560468FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000002145D0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002145D8: 8C7E0A7E
	v_add_nc_u32_e32 v159, 8, v155                             // 0000002145DC: 4B3F3688
	ds_store_b16 v144, v2 offset:12                            // 0000002145E0: D87C000C 00000290
	.long 0xd4440009                                           // 0000002145E8: D4440009
	v_cndmask_b32_e32 v1, s50, v159, vcc_lo                    // 0000002145EC: 02033E32
	s_and_saveexec_b32 s11, s9                                 // 0000002145F0: BE8B2009
	s_cbranch_execz 17                                         // 0000002145F4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2c3c>
	v_mad_u64_u32 v[1:2], null, v159, 48, s[2:3]               // 0000002145F8: D6FE7C01 0009619F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214600: BF870091
	.long 0xd73c0001                                           // 000000214604: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000214608: 02020289
	.long 0xd7000a01                                           // 00000021460C: D7000A01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 000000214610: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214614: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s10                // 000000214618: D5207C02 002A058F
	global_load_b32 v1, v[1:2], off                            // 000000214620: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000214628: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v53                         // 00000021462C: 56026AFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 000000214634: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s11                             // 00000021463C: 8C7E0B7E
	v_add_nc_u32_e32 v160, 10, v155                            // 000000214640: 4B41368A
	.long 0x7e023880                                           // 000000214644: 7E023880
	ds_store_b16_d16_hi v144, v1 offset:16                     // 000000214648: DA840010 00000190
	.long 0xd444000a                                           // 000000214650: D444000A
	v_cndmask_b32_e32 v1, s50, v160, vcc_lo                    // 000000214654: 02034032
	.long 0x7e043901                                           // 000000214658: 7E043901
	s_and_saveexec_b32 s12, s10                                // 00000021465C: BE8C200A
	s_cbranch_execz 17                                         // 000000214660: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2ca8>
	v_mad_u64_u32 v[2:3], null, v160, 48, s[2:3]               // 000000214664: D6FE7C02 000961A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021466C: BF870091
	.long 0xd73c0002                                           // 000000214670: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000214674: 02020489
	.long 0xd7000b02                                           // 000000214678: D7000B02
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 00000021467C: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214680: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s11                // 000000214684: D5207C03 002E078F
	global_load_b32 v2, v[2:3], off                            // 00000021468C: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000214694: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v54                         // 000000214698: 56046CFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000002146A0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002146A8: 8C7E0C7E
	v_add_nc_u32_e32 v161, 12, v155                            // 0000002146AC: 4B43368C
	ds_store_b16 v144, v2 offset:20                            // 0000002146B0: D87C0014 00000290
	.long 0xd444000b                                           // 0000002146B8: D444000B
	v_cndmask_b32_e32 v1, s50, v161, vcc_lo                    // 0000002146BC: 02034232
	s_and_saveexec_b32 s14, s11                                // 0000002146C0: BE8E200B
	s_cbranch_execz 17                                         // 0000002146C4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2d0c>
	v_mad_u64_u32 v[1:2], null, v161, 48, s[2:3]               // 0000002146C8: D6FE7C01 000961A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002146D0: BF870091
	.long 0xd73c0001                                           // 0000002146D4: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000002146D8: 02020289
	.long 0xd7000c01                                           // 0000002146DC: D7000C01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 0000002146E0: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002146E4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s12                // 0000002146E8: D5207C02 0032058F
	global_load_b32 v1, v[1:2], off                            // 0000002146F0: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002146F8: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v55                         // 0000002146FC: 56026EFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 000000214704: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s14                             // 00000021470C: 8C7E0E7E
	v_add_nc_u32_e32 v162, 14, v155                            // 000000214710: 4B45368E
	.long 0x7f023880                                           // 000000214714: 7F023880
	ds_store_b16 v144, v1 offset:24                            // 000000214718: D87C0018 00000190
	.long 0xd444000c                                           // 000000214720: D444000C
	v_cndmask_b32_e32 v1, s50, v162, vcc_lo                    // 000000214724: 02034432
	.long 0x7e043981                                           // 000000214728: 7E043981
	s_and_saveexec_b32 s42, s12                                // 00000021472C: BEAA200C
	s_cbranch_execz 17                                         // 000000214730: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2d78>
	v_mad_u64_u32 v[2:3], null, v162, 48, s[2:3]               // 000000214734: D6FE7C02 000961A2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021473C: BF870091
	.long 0xd73c0002                                           // 000000214740: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000214744: 02020489
	.long 0xd7000e02                                           // 000000214748: D7000E02
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 00000021474C: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214750: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s14                // 000000214754: D5207C03 003A078F
	global_load_b32 v2, v[2:3], off                            // 00000021475C: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000214764: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v56                         // 000000214768: 560470FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 000000214770: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 000000214778: 8C7E2A7E
	ds_store_b16 v144, v2 offset:28                            // 00000021477C: D87C001C 00000290
	s_and_saveexec_b32 s42, s0                                 // 000000214784: BEAA2000
	s_cbranch_execz 17                                         // 000000214788: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2dd0>
	v_mad_u64_u32 v[1:2], null, v155, 48, s[2:3]               // 00000021478C: D6FE7C01 0009619B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214794: BF870091
	.long 0xd73c0001                                           // 000000214798: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000021479C: 02020289
	.long 0xd7000e01                                           // 0000002147A0: D7000E01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 0000002147A4: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002147A8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s14                // 0000002147AC: D5207C02 003A058F
	global_load_b32 v1, v[1:2], off offset:64                  // 0000002147B4: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002147BC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v25                         // 0000002147C0: 560232FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000002147C8: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000002147D0: 8C7E2A7E
	.long 0x7e023880                                           // 0000002147D4: 7E023880
	ds_store_b16_d16_hi v145, v1 offset:2304                   // 0000002147D8: DA840900 00000191
	.long 0x7e043901                                           // 0000002147E0: 7E043901
	s_and_saveexec_b32 s42, s1                                 // 0000002147E4: BEAA2001
	s_cbranch_execz 17                                         // 0000002147E8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2e30>
	v_mad_u64_u32 v[2:3], null, v156, 48, s[2:3]               // 0000002147EC: D6FE7C02 0009619C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002147F4: BF870091
	.long 0xd73c0002                                           // 0000002147F8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002147FC: 02020489
	.long 0xd7000e02                                           // 000000214800: D7000E02
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 000000214804: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214808: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s14                // 00000021480C: D5207C03 003A078F
	global_load_b32 v2, v[2:3], off offset:64                  // 000000214814: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 00000021481C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v26                         // 000000214820: 560434FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 000000214828: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 000000214830: 8C7E2A7E
	ds_store_b16 v145, v2 offset:2308                          // 000000214834: D87C0904 00000291
	s_and_saveexec_b32 s42, s7                                 // 00000021483C: BEAA2007
	s_cbranch_execz 17                                         // 000000214840: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2e88>
	v_mad_u64_u32 v[1:2], null, v157, 48, s[2:3]               // 000000214844: D6FE7C01 0009619D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021484C: BF870091
	.long 0xd73c0001                                           // 000000214850: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000214854: 02020289
	.long 0xd7000e01                                           // 000000214858: D7000E01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 00000021485C: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214860: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s14                // 000000214864: D5207C02 003A058F
	global_load_b32 v1, v[1:2], off offset:64                  // 00000021486C: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 000000214874: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v27                         // 000000214878: 560236FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 000000214880: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 000000214888: 8C7E2A7E
	.long 0x7f023880                                           // 00000021488C: 7F023880
	ds_store_b16 v145, v1 offset:2312                          // 000000214890: D87C0908 00000191
	.long 0x7e043981                                           // 000000214898: 7E043981
	s_and_saveexec_b32 s42, s8                                 // 00000021489C: BEAA2008
	s_cbranch_execz 17                                         // 0000002148A0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2ee8>
	v_mad_u64_u32 v[2:3], null, v158, 48, s[2:3]               // 0000002148A4: D6FE7C02 0009619E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002148AC: BF870091
	.long 0xd73c0002                                           // 0000002148B0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002148B4: 02020489
	.long 0xd7000e02                                           // 0000002148B8: D7000E02
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 0000002148BC: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002148C0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s14                // 0000002148C4: D5207C03 003A078F
	global_load_b32 v2, v[2:3], off offset:64                  // 0000002148CC: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000002148D4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v28                         // 0000002148D8: 560438FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000002148E0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000002148E8: 8C7E2A7E
	ds_store_b16 v145, v2 offset:2316                          // 0000002148EC: D87C090C 00000291
	s_and_saveexec_b32 s42, s9                                 // 0000002148F4: BEAA2009
	s_cbranch_execz 17                                         // 0000002148F8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2f40>
	v_mad_u64_u32 v[1:2], null, v159, 48, s[2:3]               // 0000002148FC: D6FE7C01 0009619F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214904: BF870091
	.long 0xd73c0001                                           // 000000214908: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000021490C: 02020289
	.long 0xd7000e01                                           // 000000214910: D7000E01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 000000214914: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214918: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s14                // 00000021491C: D5207C02 003A058F
	global_load_b32 v1, v[1:2], off offset:64                  // 000000214924: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 00000021492C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v29                         // 000000214930: 56023AFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 000000214938: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 000000214940: 8C7E2A7E
	.long 0x7e023880                                           // 000000214944: 7E023880
	ds_store_b16_d16_hi v145, v1 offset:2320                   // 000000214948: DA840910 00000191
	.long 0x7e043901                                           // 000000214950: 7E043901
	s_and_saveexec_b32 s42, s10                                // 000000214954: BEAA200A
	s_cbranch_execz 17                                         // 000000214958: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2fa0>
	v_mad_u64_u32 v[2:3], null, v160, 48, s[2:3]               // 00000021495C: D6FE7C02 000961A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214964: BF870091
	.long 0xd73c0002                                           // 000000214968: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000021496C: 02020489
	.long 0xd7000e02                                           // 000000214970: D7000E02
	v_cndmask_b32_e32 v1, v142, v2, vcc_lo                     // 000000214974: 0202058E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214978: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v143, v3, s14                // 00000021497C: D5207C03 003A078F
	global_load_b32 v2, v[2:3], off offset:64                  // 000000214984: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 00000021498C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v30                         // 000000214990: 56043CFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 000000214998: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000002149A0: 8C7E2A7E
	ds_store_b16 v145, v2 offset:2324                          // 0000002149A4: D87C0914 00000291
	s_and_saveexec_b32 s42, s11                                // 0000002149AC: BEAA200B
	s_cbranch_execz 17                                         // 0000002149B0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2ff8>
	v_mad_u64_u32 v[1:2], null, v161, 48, s[2:3]               // 0000002149B4: D6FE7C01 000961A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002149BC: BF870091
	.long 0xd73c0001                                           // 0000002149C0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000002149C4: 02020289
	.long 0xd7000e01                                           // 0000002149C8: D7000E01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 0000002149CC: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002149D0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s14                // 0000002149D4: D5207C02 003A058F
	global_load_b32 v1, v[1:2], off offset:64                  // 0000002149DC: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002149E4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v31                         // 0000002149E8: 56023EFF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000002149F0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000002149F8: 8C7E2A7E
	.long 0x7f023880                                           // 0000002149FC: 7F023880
	ds_store_b16 v145, v1 offset:2328                          // 000000214A00: D87C0918 00000191
	s_and_saveexec_b32 s42, s12                                // 000000214A08: BEAA200C
	s_cbranch_execz 17                                         // 000000214A0C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3054>
	v_mad_u64_u32 v[1:2], null, v162, 48, s[2:3]               // 000000214A10: D6FE7C01 000961A2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000214A18: BF870091
	.long 0xd73c0001                                           // 000000214A1C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000214A20: 02020289
	.long 0xd7000e01                                           // 000000214A24: D7000E01
	v_cndmask_b32_e32 v1, v142, v1, vcc_lo                     // 000000214A28: 0202038E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000214A2C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v143, v2, s14                // 000000214A30: D5207C02 003A058F
	global_load_b32 v1, v[1:2], off offset:64                  // 000000214A38: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 000000214A40: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v32                         // 000000214A44: 560240FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 000000214A4C: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 000000214A54: 8C7E2A7E
	.long 0xd7000e02                                           // 000000214A58: D7000E02
	v_cndmask_b32_e32 v1, s44, v82, vcc_lo                     // 000000214A5C: 0202A42C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000214A60: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, v83, s14                // 000000214A64: D5207C03 003AA62D
	ds_store_b16_d16_hi v145, v1 offset:2332                   // 000000214A6C: DA84091C 00000191
	s_waitcnt lgkmcnt(0)                                       // 000000214A74: BF89FC07
	s_barrier                                                  // 000000214A78: BFBD0000
	buffer_gl0_inv                                             // 000000214A7C: E0AC0000 00000000
	s_clause 0xf                                               // 000000214A84: BF85000F
	global_load_b128 v[65:68], v[2:3], off                     // 000000214A88: DC5E0000 417C0002
	global_load_b128 v[69:72], v[2:3], off offset:16           // 000000214A90: DC5E0010 457C0002
	global_load_b128 v[57:60], v[2:3], off offset:32           // 000000214A98: DC5E0020 397C0002
	global_load_b128 v[61:64], v[2:3], off offset:48           // 000000214AA0: DC5E0030 3D7C0002
	global_load_b128 v[49:52], v[2:3], off offset:64           // 000000214AA8: DC5E0040 317C0002
	global_load_b128 v[53:56], v[2:3], off offset:80           // 000000214AB0: DC5E0050 357C0002
	global_load_b128 v[41:44], v[2:3], off offset:96           // 000000214AB8: DC5E0060 297C0002
	global_load_b128 v[45:48], v[2:3], off offset:112          // 000000214AC0: DC5E0070 2D7C0002
	global_load_b128 v[33:36], v[2:3], off offset:128          // 000000214AC8: DC5E0080 217C0002
	global_load_b128 v[37:40], v[2:3], off offset:144          // 000000214AD0: DC5E0090 257C0002
	global_load_b128 v[25:28], v[2:3], off offset:160          // 000000214AD8: DC5E00A0 197C0002
	global_load_b128 v[29:32], v[2:3], off offset:176          // 000000214AE0: DC5E00B0 1D7C0002
	global_load_b128 v[17:20], v[2:3], off offset:192          // 000000214AE8: DC5E00C0 117C0002
	global_load_b128 v[21:24], v[2:3], off offset:208          // 000000214AF0: DC5E00D0 157C0002
	global_load_b128 v[9:12], v[2:3], off offset:224           // 000000214AF8: DC5E00E0 097C0002
	global_load_b128 v[13:16], v[2:3], off offset:240          // 000000214B00: DC5E00F0 0D7C0002
	s_and_saveexec_b32 s14, s13                                // 000000214B08: BE8E200D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000214B0C: BF870009
	s_xor_b32 s13, exec_lo, s14                                // 000000214B10: 8D0D0E7E
	s_cbranch_execz 81                                         // 000000214B14: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x325c>
	s_waitcnt vmcnt(15)                                        // 000000214B18: BF893FF7
	v_mov_b32_e32 v65, 0                                       // 000000214B1C: 7E820280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000214B20: BF870001
	v_mov_b32_e32 v66, v65                                     // 000000214B24: 7E840341
	v_mov_b32_e32 v67, v65                                     // 000000214B28: 7E860341
	v_mov_b32_e32 v68, v65                                     // 000000214B2C: 7E880341
	s_waitcnt vmcnt(14)                                        // 000000214B30: BF893BF7
	v_mov_b32_e32 v69, v65                                     // 000000214B34: 7E8A0341
	v_mov_b32_e32 v70, v65                                     // 000000214B38: 7E8C0341
	v_mov_b32_e32 v71, v65                                     // 000000214B3C: 7E8E0341
	v_mov_b32_e32 v72, v65                                     // 000000214B40: 7E900341
	s_waitcnt vmcnt(13)                                        // 000000214B44: BF8937F7
	v_mov_b32_e32 v57, v65                                     // 000000214B48: 7E720341
	v_mov_b32_e32 v58, v65                                     // 000000214B4C: 7E740341
	v_mov_b32_e32 v59, v65                                     // 000000214B50: 7E760341
	v_mov_b32_e32 v60, v65                                     // 000000214B54: 7E780341
	s_waitcnt vmcnt(12)                                        // 000000214B58: BF8933F7
	v_mov_b32_e32 v61, v65                                     // 000000214B5C: 7E7A0341
	v_mov_b32_e32 v62, v65                                     // 000000214B60: 7E7C0341
	v_mov_b32_e32 v63, v65                                     // 000000214B64: 7E7E0341
	v_mov_b32_e32 v64, v65                                     // 000000214B68: 7E800341
	s_waitcnt vmcnt(11)                                        // 000000214B6C: BF892FF7
	v_mov_b32_e32 v49, v65                                     // 000000214B70: 7E620341
	v_mov_b32_e32 v50, v65                                     // 000000214B74: 7E640341
	v_mov_b32_e32 v51, v65                                     // 000000214B78: 7E660341
	v_mov_b32_e32 v52, v65                                     // 000000214B7C: 7E680341
	s_waitcnt vmcnt(10)                                        // 000000214B80: BF892BF7
	v_mov_b32_e32 v53, v65                                     // 000000214B84: 7E6A0341
	v_mov_b32_e32 v54, v65                                     // 000000214B88: 7E6C0341
	v_mov_b32_e32 v55, v65                                     // 000000214B8C: 7E6E0341
	v_mov_b32_e32 v56, v65                                     // 000000214B90: 7E700341
	s_waitcnt vmcnt(9)                                         // 000000214B94: BF8927F7
	v_mov_b32_e32 v41, v65                                     // 000000214B98: 7E520341
	v_mov_b32_e32 v42, v65                                     // 000000214B9C: 7E540341
	v_mov_b32_e32 v43, v65                                     // 000000214BA0: 7E560341
	v_mov_b32_e32 v44, v65                                     // 000000214BA4: 7E580341
	s_waitcnt vmcnt(8)                                         // 000000214BA8: BF8923F7
	v_mov_b32_e32 v45, v65                                     // 000000214BAC: 7E5A0341
	v_mov_b32_e32 v46, v65                                     // 000000214BB0: 7E5C0341
	v_mov_b32_e32 v47, v65                                     // 000000214BB4: 7E5E0341
	v_mov_b32_e32 v48, v65                                     // 000000214BB8: 7E600341
	s_waitcnt vmcnt(7)                                         // 000000214BBC: BF891FF7
	v_mov_b32_e32 v33, v65                                     // 000000214BC0: 7E420341
	v_mov_b32_e32 v34, v65                                     // 000000214BC4: 7E440341
	v_mov_b32_e32 v35, v65                                     // 000000214BC8: 7E460341
	v_mov_b32_e32 v36, v65                                     // 000000214BCC: 7E480341
	s_waitcnt vmcnt(6)                                         // 000000214BD0: BF891BF7
	v_mov_b32_e32 v37, v65                                     // 000000214BD4: 7E4A0341
	v_mov_b32_e32 v38, v65                                     // 000000214BD8: 7E4C0341
	v_mov_b32_e32 v39, v65                                     // 000000214BDC: 7E4E0341
	v_mov_b32_e32 v40, v65                                     // 000000214BE0: 7E500341
	s_waitcnt vmcnt(5)                                         // 000000214BE4: BF8917F7
	v_mov_b32_e32 v25, v65                                     // 000000214BE8: 7E320341
	v_mov_b32_e32 v26, v65                                     // 000000214BEC: 7E340341
	v_mov_b32_e32 v27, v65                                     // 000000214BF0: 7E360341
	v_mov_b32_e32 v28, v65                                     // 000000214BF4: 7E380341
	s_waitcnt vmcnt(4)                                         // 000000214BF8: BF8913F7
	v_mov_b32_e32 v29, v65                                     // 000000214BFC: 7E3A0341
	v_mov_b32_e32 v30, v65                                     // 000000214C00: 7E3C0341
	v_mov_b32_e32 v31, v65                                     // 000000214C04: 7E3E0341
	v_mov_b32_e32 v32, v65                                     // 000000214C08: 7E400341
	s_waitcnt vmcnt(3)                                         // 000000214C0C: BF890FF7
	v_mov_b32_e32 v17, v65                                     // 000000214C10: 7E220341
	v_mov_b32_e32 v18, v65                                     // 000000214C14: 7E240341
	v_mov_b32_e32 v19, v65                                     // 000000214C18: 7E260341
	v_mov_b32_e32 v20, v65                                     // 000000214C1C: 7E280341
	s_waitcnt vmcnt(2)                                         // 000000214C20: BF890BF7
	v_mov_b32_e32 v21, v65                                     // 000000214C24: 7E2A0341
	v_mov_b32_e32 v22, v65                                     // 000000214C28: 7E2C0341
	v_mov_b32_e32 v23, v65                                     // 000000214C2C: 7E2E0341
	v_mov_b32_e32 v24, v65                                     // 000000214C30: 7E300341
	s_waitcnt vmcnt(1)                                         // 000000214C34: BF8907F7
	v_mov_b32_e32 v9, v65                                      // 000000214C38: 7E120341
	v_mov_b32_e32 v10, v65                                     // 000000214C3C: 7E140341
	v_mov_b32_e32 v11, v65                                     // 000000214C40: 7E160341
	v_mov_b32_e32 v12, v65                                     // 000000214C44: 7E180341
	s_waitcnt vmcnt(0)                                         // 000000214C48: BF8903F7
	v_mov_b32_e32 v13, v65                                     // 000000214C4C: 7E1A0341
	v_mov_b32_e32 v14, v65                                     // 000000214C50: 7E1C0341
	v_mov_b32_e32 v15, v65                                     // 000000214C54: 7E1E0341
	v_mov_b32_e32 v16, v65                                     // 000000214C58: 7E200341
	s_or_b32 exec_lo, exec_lo, s13                             // 000000214C5C: 8C7E0D7E
	ds_load_b128 v[1:4], v135                                  // 000000214C60: DBFC0000 01000087
	ds_load_b128 v[5:8], v135 offset:16                        // 000000214C68: DBFC0010 05000087
	ds_load_b128 v[73:76], v135 offset:32                      // 000000214C70: DBFC0020 49000087
	ds_load_b128 v[87:90], v135 offset:48                      // 000000214C78: DBFC0030 57000087
	ds_load_b128 v[91:94], v135 offset:8448                    // 000000214C80: DBFC2100 5B000087
	ds_load_b128 v[95:98], v135 offset:8464                    // 000000214C88: DBFC2110 5F000087
	ds_load_b128 v[99:102], v135 offset:8480                   // 000000214C90: DBFC2120 63000087
	s_mul_hi_u32 s13, s40, 0xfffff430                          // 000000214C98: 968DFF28 FFFFF430
	s_mul_i32 s14, s40, 0xfffff430                             // 000000214CA0: 960EFF28 FFFFF430
	s_sub_i32 s13, s13, s40                                    // 000000214CA8: 818D280D
	s_add_u32 s28, s28, s14                                    // 000000214CAC: 801C0E1C
	s_addc_u32 s29, s29, s13                                   // 000000214CB0: 821D0D1D
	ds_load_b128 v[171:174], v135 offset:64                    // 000000214CB4: DBFC0040 AB000087
	ds_load_b128 v[175:178], v135 offset:80                    // 000000214CBC: DBFC0050 AF000087
	s_lshl_b64 s[28:29], s[28:29], 13                          // 000000214CC4: 849C8D1C
	ds_load_b128 v[179:182], v135 offset:96                    // 000000214CC8: DBFC0060 B3000087
	ds_load_b128 v[183:186], v135 offset:112                   // 000000214CD0: DBFC0070 B7000087
	.long 0xd7000d7b                                           // 000000214CD8: D7000D7B
	v_cndmask_b32_e32 v0, v146, v28, vcc_lo                    // 000000214CDC: 02003992
	s_delay_alu instid0(VALU_DEP_1)                            // 000000214CE0: BF870001
	v_add_co_ci_u32_e64 v124, null, s29, v147, s13             // 000000214CE4: D5207C7C 0037261D
	s_clause 0x1                                               // 000000214CEC: BF850001
	global_load_b128 v[167:170], v[123:124], off offset:16     // 000000214CF0: DC5E0010 A77C007B
	global_load_b128 v[163:166], v[123:124], off               // 000000214CF8: DC5E0000 A37C007B
	s_waitcnt lgkmcnt(7)                                       // 000000214D00: BF89FC77
	v_fma_mixlo_f16 v87, v87, s39, 0                           // 000000214D04: CC210057 02004F57
	v_fma_mixhi_f16 v87, v88, s39, 0                           // 000000214D0C: CC220057 02004F58
	v_fma_mixlo_f16 v88, v89, s39, 0                           // 000000214D14: CC210058 02004F59
	v_fma_mixhi_f16 v88, v90, s39, 0                           // 000000214D1C: CC220058 02004F5A
	s_waitcnt lgkmcnt(6)                                       // 000000214D24: BF89FC67
	v_fma_mixhi_f16 v89, v92, s39, 0                           // 000000214D28: CC220059 02004F5C
	v_fma_mixlo_f16 v90, v93, s39, 0                           // 000000214D30: CC21005A 02004F5D
	v_fma_mixhi_f16 v90, v94, s39, 0                           // 000000214D38: CC22005A 02004F5E
	s_waitcnt lgkmcnt(5)                                       // 000000214D40: BF89FC57
	v_fma_mixlo_f16 v92, v97, s39, 0                           // 000000214D44: CC21005C 02004F61
	v_fma_mixhi_f16 v92, v98, s39, 0                           // 000000214D4C: CC22005C 02004F62
	s_waitcnt lgkmcnt(4)                                       // 000000214D54: BF89FC47
	v_fma_mixlo_f16 v93, v99, s39, 0                           // 000000214D58: CC21005D 02004F63
	v_fma_mixhi_f16 v93, v100, s39, 0                          // 000000214D60: CC22005D 02004F64
	v_fma_mixlo_f16 v94, v101, s39, 0                          // 000000214D68: CC21005E 02004F65
	v_fma_mixhi_f16 v94, v102, s39, 0                          // 000000214D70: CC22005E 02004F66
	s_clause 0x3                                               // 000000214D78: BF850003
	global_load_b128 v[109:112], v[123:124], off offset:80     // 000000214D7C: DC5E0050 6D7C007B
	global_load_b128 v[105:108], v[123:124], off offset:64     // 000000214D84: DC5E0040 697C007B
	global_load_b128 v[101:104], v[123:124], off offset:112    // 000000214D8C: DC5E0070 657C007B
	global_load_b128 v[97:100], v[123:124], off offset:96      // 000000214D94: DC5E0060 617C007B
	v_fma_mixlo_f16 v85, v73, s39, 0                           // 000000214D9C: CC210055 02004F49
	v_fma_mixhi_f16 v85, v74, s39, 0                           // 000000214DA4: CC220055 02004F4A
	v_fma_mixlo_f16 v86, v75, s39, 0                           // 000000214DAC: CC210056 02004F4B
	v_fma_mixhi_f16 v86, v76, s39, 0                           // 000000214DB4: CC220056 02004F4C
	v_dual_mov_b32 v80, s27 :: v_dual_mov_b32 v79, s26         // 000000214DBC: CA10001B 504E001A
	v_fma_mixlo_f16 v81, v1, s39, 0                            // 000000214DC4: CC210051 02004F01
	v_fma_mixhi_f16 v81, v2, s39, 0                            // 000000214DCC: CC220051 02004F02
	v_fma_mixlo_f16 v82, v3, s39, 0                            // 000000214DD4: CC210052 02004F03
	v_fma_mixhi_f16 v82, v4, s39, 0                            // 000000214DDC: CC220052 02004F04
	v_fma_mixlo_f16 v83, v5, s39, 0                            // 000000214DE4: CC210053 02004F05
	v_fma_mixhi_f16 v83, v6, s39, 0                            // 000000214DEC: CC220053 02004F06
	v_fma_mixlo_f16 v84, v7, s39, 0                            // 000000214DF4: CC210054 02004F07
	v_fma_mixhi_f16 v84, v8, s39, 0                            // 000000214DFC: CC220054 02004F08
	v_dual_mov_b32 v78, s25 :: v_dual_mov_b32 v77, s24         // 000000214E04: CA100019 4E4C0018
	v_dual_mov_b32 v76, s23 :: v_dual_mov_b32 v75, s22         // 000000214E0C: CA100017 4C4A0016
	v_dual_mov_b32 v74, s21 :: v_dual_mov_b32 v73, s20         // 000000214E14: CA100015 4A480014
	v_fma_mixlo_f16 v89, v91, s39, 0                           // 000000214E1C: CC210059 02004F5B
	v_fma_mixlo_f16 v91, v95, s39, 0                           // 000000214E24: CC21005B 02004F5F
	v_fma_mixhi_f16 v91, v96, s39, 0                           // 000000214E2C: CC22005B 02004F60
	s_waitcnt vmcnt(20)                                        // 000000214E34: BF8953F7
	v_wmma_f32_16x16x16_f16 v[1:8], v[65:72], v[81:88], v[73:80]// 000000214E38: CC404001 1D26A341
	ds_load_b128 v[81:84], v135 offset:8496                    // 000000214E40: DBFC2130 51000087
	s_waitcnt lgkmcnt(0)                                       // 000000214E48: BF89FC07
	v_fma_mixlo_f16 v95, v81, s39, 0                           // 000000214E4C: CC21005F 02004F51
	v_fma_mixhi_f16 v95, v82, s39, 0                           // 000000214E54: CC22005F 02004F52
	v_fma_mixlo_f16 v96, v83, s39, 0                           // 000000214E5C: CC210060 02004F53
	v_fma_mixhi_f16 v96, v84, s39, 0                           // 000000214E64: CC220060 02004F54
	s_delay_alu instid0(VALU_DEP_1)                            // 000000214E6C: BF870001
	v_wmma_f32_16x16x16_f16 v[81:88], v[65:72], v[89:96], v[73:80]// 000000214E70: CC404051 1D26B341
	ds_load_b128 v[89:92], v135 offset:8512                    // 000000214E78: DBFC2140 59000087
	ds_load_b128 v[93:96], v135 offset:8528                    // 000000214E80: DBFC2150 5D000087
	v_fma_mixlo_f16 v65, v171, s39, 0                          // 000000214E88: CC210041 02004FAB
	v_fma_mixhi_f16 v65, v172, s39, 0                          // 000000214E90: CC220041 02004FAC
	v_fma_mixlo_f16 v66, v173, s39, 0                          // 000000214E98: CC210042 02004FAD
	v_fma_mixhi_f16 v66, v174, s39, 0                          // 000000214EA0: CC220042 02004FAE
	v_fma_mixlo_f16 v67, v175, s39, 0                          // 000000214EA8: CC210043 02004FAF
	v_fma_mixhi_f16 v67, v176, s39, 0                          // 000000214EB0: CC220043 02004FB0
	v_fma_mixlo_f16 v68, v177, s39, 0                          // 000000214EB8: CC210044 02004FB1
	ds_load_b128 v[171:174], v135 offset:8544                  // 000000214EC0: DBFC2160 AB000087
	v_fma_mixhi_f16 v68, v178, s39, 0                          // 000000214EC8: CC220044 02004FB2
	ds_load_b128 v[175:178], v135 offset:8560                  // 000000214ED0: DBFC2170 AF000087
	v_fma_mixlo_f16 v69, v179, s39, 0                          // 000000214ED8: CC210045 02004FB3
	v_fma_mixhi_f16 v69, v180, s39, 0                          // 000000214EE0: CC220045 02004FB4
	v_fma_mixlo_f16 v70, v181, s39, 0                          // 000000214EE8: CC210046 02004FB5
	v_fma_mixhi_f16 v70, v182, s39, 0                          // 000000214EF0: CC220046 02004FB6
	v_fma_mixlo_f16 v71, v183, s39, 0                          // 000000214EF8: CC210047 02004FB7
	v_fma_mixhi_f16 v71, v184, s39, 0                          // 000000214F00: CC220047 02004FB8
	v_fma_mixlo_f16 v72, v185, s39, 0                          // 000000214F08: CC210048 02004FB9
	v_fma_mixhi_f16 v72, v186, s39, 0                          // 000000214F10: CC220048 02004FBA
	s_waitcnt lgkmcnt(3)                                       // 000000214F18: BF89FC37
	v_fma_mixlo_f16 v89, v89, s39, 0                           // 000000214F1C: CC210059 02004F59
	v_fma_mixhi_f16 v89, v90, s39, 0                           // 000000214F24: CC220059 02004F5A
	v_fma_mixlo_f16 v90, v91, s39, 0                           // 000000214F2C: CC21005A 02004F5B
	v_fma_mixhi_f16 v90, v92, s39, 0                           // 000000214F34: CC22005A 02004F5C
	s_waitcnt lgkmcnt(2)                                       // 000000214F3C: BF89FC27
	v_fma_mixlo_f16 v91, v93, s39, 0                           // 000000214F40: CC21005B 02004F5D
	v_fma_mixhi_f16 v91, v94, s39, 0                           // 000000214F48: CC22005B 02004F5E
	v_fma_mixlo_f16 v92, v95, s39, 0                           // 000000214F50: CC21005C 02004F5F
	v_fma_mixhi_f16 v92, v96, s39, 0                           // 000000214F58: CC22005C 02004F60
	ds_load_b128 v[179:182], v135 offset:128                   // 000000214F60: DBFC0080 B3000087
	ds_load_b128 v[183:186], v135 offset:144                   // 000000214F68: DBFC0090 B7000087
	s_waitcnt lgkmcnt(3)                                       // 000000214F70: BF89FC37
	v_fma_mixlo_f16 v93, v171, s39, 0                          // 000000214F74: CC21005D 02004FAB
	v_fma_mixhi_f16 v93, v172, s39, 0                          // 000000214F7C: CC22005D 02004FAC
	v_fma_mixlo_f16 v94, v173, s39, 0                          // 000000214F84: CC21005E 02004FAD
	v_fma_mixhi_f16 v94, v174, s39, 0                          // 000000214F8C: CC22005E 02004FAE
	s_waitcnt lgkmcnt(2)                                       // 000000214F94: BF89FC27
	v_fma_mixlo_f16 v95, v175, s39, 0                          // 000000214F98: CC21005F 02004FAF
	v_fma_mixhi_f16 v95, v176, s39, 0                          // 000000214FA0: CC22005F 02004FB0
	v_fma_mixlo_f16 v96, v177, s39, 0                          // 000000214FA8: CC210060 02004FB1
	v_fma_mixhi_f16 v96, v178, s39, 0                          // 000000214FB0: CC220060 02004FB2
	ds_load_b128 v[171:174], v135 offset:160                   // 000000214FB8: DBFC00A0 AB000087
	ds_load_b128 v[175:178], v135 offset:176                   // 000000214FC0: DBFC00B0 AF000087
	s_waitcnt vmcnt(18)                                        // 000000214FC8: BF894BF7
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[65:72], v[1:8] // 000000214FCC: CC404001 1C068339
	ds_load_b128 v[65:68], v135 offset:8576                    // 000000214FD4: DBFC2180 41000087
	ds_load_b128 v[69:72], v135 offset:8592                    // 000000214FDC: DBFC2190 45000087
	v_wmma_f32_16x16x16_f16 v[81:88], v[57:64], v[89:96], v[81:88]// 000000214FE4: CC404051 1D46B339
	ds_load_b128 v[89:92], v135 offset:8608                    // 000000214FEC: DBFC21A0 59000087
	ds_load_b128 v[93:96], v135 offset:8624                    // 000000214FF4: DBFC21B0 5D000087
	s_waitcnt lgkmcnt(7)                                       // 000000214FFC: BF89FC77
	v_fma_mixlo_f16 v57, v179, s39, 0                          // 000000215000: CC210039 02004FB3
	v_fma_mixhi_f16 v57, v180, s39, 0                          // 000000215008: CC220039 02004FB4
	v_fma_mixlo_f16 v58, v181, s39, 0                          // 000000215010: CC21003A 02004FB5
	v_fma_mixhi_f16 v58, v182, s39, 0                          // 000000215018: CC22003A 02004FB6
	s_waitcnt lgkmcnt(6)                                       // 000000215020: BF89FC67
	v_fma_mixlo_f16 v59, v183, s39, 0                          // 000000215024: CC21003B 02004FB7
	v_fma_mixhi_f16 v59, v184, s39, 0                          // 00000021502C: CC22003B 02004FB8
	v_fma_mixlo_f16 v60, v185, s39, 0                          // 000000215034: CC21003C 02004FB9
	v_fma_mixhi_f16 v60, v186, s39, 0                          // 00000021503C: CC22003C 02004FBA
	s_waitcnt lgkmcnt(5)                                       // 000000215044: BF89FC57
	v_fma_mixlo_f16 v61, v171, s39, 0                          // 000000215048: CC21003D 02004FAB
	v_fma_mixhi_f16 v61, v172, s39, 0                          // 000000215050: CC22003D 02004FAC
	v_fma_mixlo_f16 v62, v173, s39, 0                          // 000000215058: CC21003E 02004FAD
	v_fma_mixhi_f16 v62, v174, s39, 0                          // 000000215060: CC22003E 02004FAE
	s_waitcnt lgkmcnt(4)                                       // 000000215068: BF89FC47
	v_fma_mixlo_f16 v63, v175, s39, 0                          // 00000021506C: CC21003F 02004FAF
	v_fma_mixhi_f16 v63, v176, s39, 0                          // 000000215074: CC22003F 02004FB0
	v_fma_mixlo_f16 v64, v177, s39, 0                          // 00000021507C: CC210040 02004FB1
	v_fma_mixhi_f16 v64, v178, s39, 0                          // 000000215084: CC220040 02004FB2
	s_waitcnt lgkmcnt(3)                                       // 00000021508C: BF89FC37
	v_fma_mixlo_f16 v65, v65, s39, 0                           // 000000215090: CC210041 02004F41
	v_fma_mixhi_f16 v65, v66, s39, 0                           // 000000215098: CC220041 02004F42
	v_fma_mixlo_f16 v66, v67, s39, 0                           // 0000002150A0: CC210042 02004F43
	v_fma_mixhi_f16 v66, v68, s39, 0                           // 0000002150A8: CC220042 02004F44
	s_waitcnt lgkmcnt(2)                                       // 0000002150B0: BF89FC27
	v_fma_mixlo_f16 v67, v69, s39, 0                           // 0000002150B4: CC210043 02004F45
	v_fma_mixhi_f16 v67, v70, s39, 0                           // 0000002150BC: CC220043 02004F46
	v_fma_mixlo_f16 v68, v71, s39, 0                           // 0000002150C4: CC210044 02004F47
	v_fma_mixhi_f16 v68, v72, s39, 0                           // 0000002150CC: CC220044 02004F48
	s_waitcnt lgkmcnt(1)                                       // 0000002150D4: BF89FC17
	v_fma_mixlo_f16 v69, v89, s39, 0                           // 0000002150D8: CC210045 02004F59
	v_fma_mixhi_f16 v69, v90, s39, 0                           // 0000002150E0: CC220045 02004F5A
	v_fma_mixlo_f16 v70, v91, s39, 0                           // 0000002150E8: CC210046 02004F5B
	v_fma_mixhi_f16 v70, v92, s39, 0                           // 0000002150F0: CC220046 02004F5C
	s_waitcnt lgkmcnt(0)                                       // 0000002150F8: BF89FC07
	v_fma_mixlo_f16 v71, v93, s39, 0                           // 0000002150FC: CC210047 02004F5D
	v_fma_mixhi_f16 v71, v94, s39, 0                           // 000000215104: CC220047 02004F5E
	v_fma_mixlo_f16 v72, v95, s39, 0                           // 00000021510C: CC210048 02004F5F
	v_fma_mixhi_f16 v72, v96, s39, 0                           // 000000215114: CC220048 02004F60
	ds_load_b128 v[171:174], v135 offset:192                   // 00000021511C: DBFC00C0 AB000087
	ds_load_b128 v[175:178], v135 offset:208                   // 000000215124: DBFC00D0 AF000087
	ds_load_b128 v[89:92], v135 offset:224                     // 00000021512C: DBFC00E0 59000087
	ds_load_b128 v[93:96], v135 offset:240                     // 000000215134: DBFC00F0 5D000087
	s_waitcnt vmcnt(16)                                        // 00000021513C: BF8943F7
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[57:64], v[1:8] // 000000215140: CC404001 1C067331
	v_wmma_f32_16x16x16_f16 v[81:88], v[49:56], v[65:72], v[81:88]// 000000215148: CC404051 1D468331
	ds_load_b128 v[57:60], v135 offset:8640                    // 000000215150: DBFC21C0 39000087
	ds_load_b128 v[61:64], v135 offset:8656                    // 000000215158: DBFC21D0 3D000087
	ds_load_b128 v[65:68], v135 offset:8672                    // 000000215160: DBFC21E0 41000087
	ds_load_b128 v[69:72], v135 offset:8688                    // 000000215168: DBFC21F0 45000087
	s_waitcnt lgkmcnt(7)                                       // 000000215170: BF89FC77
	v_fma_mixlo_f16 v49, v171, s39, 0                          // 000000215174: CC210031 02004FAB
	v_fma_mixhi_f16 v49, v172, s39, 0                          // 00000021517C: CC220031 02004FAC
	v_fma_mixlo_f16 v50, v173, s39, 0                          // 000000215184: CC210032 02004FAD
	v_fma_mixhi_f16 v50, v174, s39, 0                          // 00000021518C: CC220032 02004FAE
	s_waitcnt lgkmcnt(6)                                       // 000000215194: BF89FC67
	v_fma_mixlo_f16 v51, v175, s39, 0                          // 000000215198: CC210033 02004FAF
	v_fma_mixhi_f16 v51, v176, s39, 0                          // 0000002151A0: CC220033 02004FB0
	v_fma_mixlo_f16 v52, v177, s39, 0                          // 0000002151A8: CC210034 02004FB1
	v_fma_mixhi_f16 v52, v178, s39, 0                          // 0000002151B0: CC220034 02004FB2
	s_waitcnt lgkmcnt(5)                                       // 0000002151B8: BF89FC57
	v_fma_mixlo_f16 v53, v89, s39, 0                           // 0000002151BC: CC210035 02004F59
	v_fma_mixhi_f16 v53, v90, s39, 0                           // 0000002151C4: CC220035 02004F5A
	v_fma_mixlo_f16 v54, v91, s39, 0                           // 0000002151CC: CC210036 02004F5B
	v_fma_mixhi_f16 v54, v92, s39, 0                           // 0000002151D4: CC220036 02004F5C
	s_waitcnt lgkmcnt(4)                                       // 0000002151DC: BF89FC47
	v_fma_mixlo_f16 v55, v93, s39, 0                           // 0000002151E0: CC210037 02004F5D
	v_fma_mixhi_f16 v55, v94, s39, 0                           // 0000002151E8: CC220037 02004F5E
	v_fma_mixlo_f16 v56, v95, s39, 0                           // 0000002151F0: CC210038 02004F5F
	v_fma_mixhi_f16 v56, v96, s39, 0                           // 0000002151F8: CC220038 02004F60
	s_waitcnt lgkmcnt(3)                                       // 000000215200: BF89FC37
	v_fma_mixlo_f16 v57, v57, s39, 0                           // 000000215204: CC210039 02004F39
	v_fma_mixhi_f16 v57, v58, s39, 0                           // 00000021520C: CC220039 02004F3A
	v_fma_mixlo_f16 v58, v59, s39, 0                           // 000000215214: CC21003A 02004F3B
	v_fma_mixhi_f16 v58, v60, s39, 0                           // 00000021521C: CC22003A 02004F3C
	s_waitcnt lgkmcnt(2)                                       // 000000215224: BF89FC27
	v_fma_mixlo_f16 v59, v61, s39, 0                           // 000000215228: CC21003B 02004F3D
	v_fma_mixhi_f16 v59, v62, s39, 0                           // 000000215230: CC22003B 02004F3E
	v_fma_mixlo_f16 v60, v63, s39, 0                           // 000000215238: CC21003C 02004F3F
	v_fma_mixhi_f16 v60, v64, s39, 0                           // 000000215240: CC22003C 02004F40
	s_waitcnt lgkmcnt(1)                                       // 000000215248: BF89FC17
	v_fma_mixlo_f16 v61, v65, s39, 0                           // 00000021524C: CC21003D 02004F41
	v_fma_mixhi_f16 v61, v66, s39, 0                           // 000000215254: CC22003D 02004F42
	v_fma_mixlo_f16 v62, v67, s39, 0                           // 00000021525C: CC21003E 02004F43
	v_fma_mixhi_f16 v62, v68, s39, 0                           // 000000215264: CC22003E 02004F44
	s_waitcnt lgkmcnt(0)                                       // 00000021526C: BF89FC07
	v_fma_mixlo_f16 v63, v69, s39, 0                           // 000000215270: CC21003F 02004F45
	v_fma_mixhi_f16 v63, v70, s39, 0                           // 000000215278: CC22003F 02004F46
	v_fma_mixlo_f16 v64, v71, s39, 0                           // 000000215280: CC210040 02004F47
	v_fma_mixhi_f16 v64, v72, s39, 0                           // 000000215288: CC220040 02004F48
	ds_load_b128 v[89:92], v135 offset:256                     // 000000215290: DBFC0100 59000087
	ds_load_b128 v[93:96], v135 offset:272                     // 000000215298: DBFC0110 5D000087
	ds_load_b128 v[65:68], v135 offset:288                     // 0000002152A0: DBFC0120 41000087
	ds_load_b128 v[69:72], v135 offset:304                     // 0000002152A8: DBFC0130 45000087
	s_waitcnt vmcnt(14)                                        // 0000002152B0: BF893BF7
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[49:56], v[1:8] // 0000002152B4: CC404001 1C066329
	v_wmma_f32_16x16x16_f16 v[81:88], v[41:48], v[57:64], v[81:88]// 0000002152BC: CC404051 1D467329
	ds_load_b128 v[49:52], v135 offset:8704                    // 0000002152C4: DBFC2200 31000087
	ds_load_b128 v[53:56], v135 offset:8720                    // 0000002152CC: DBFC2210 35000087
	ds_load_b128 v[57:60], v135 offset:8736                    // 0000002152D4: DBFC2220 39000087
	ds_load_b128 v[61:64], v135 offset:8752                    // 0000002152DC: DBFC2230 3D000087
	s_waitcnt lgkmcnt(7)                                       // 0000002152E4: BF89FC77
	v_fma_mixlo_f16 v41, v89, s39, 0                           // 0000002152E8: CC210029 02004F59
	v_fma_mixhi_f16 v41, v90, s39, 0                           // 0000002152F0: CC220029 02004F5A
	v_fma_mixlo_f16 v42, v91, s39, 0                           // 0000002152F8: CC21002A 02004F5B
	v_fma_mixhi_f16 v42, v92, s39, 0                           // 000000215300: CC22002A 02004F5C
	s_waitcnt lgkmcnt(6)                                       // 000000215308: BF89FC67
	v_fma_mixlo_f16 v43, v93, s39, 0                           // 00000021530C: CC21002B 02004F5D
	v_fma_mixhi_f16 v43, v94, s39, 0                           // 000000215314: CC22002B 02004F5E
	v_fma_mixlo_f16 v44, v95, s39, 0                           // 00000021531C: CC21002C 02004F5F
	v_fma_mixhi_f16 v44, v96, s39, 0                           // 000000215324: CC22002C 02004F60
	s_waitcnt lgkmcnt(5)                                       // 00000021532C: BF89FC57
	v_fma_mixlo_f16 v45, v65, s39, 0                           // 000000215330: CC21002D 02004F41
	v_fma_mixhi_f16 v45, v66, s39, 0                           // 000000215338: CC22002D 02004F42
	v_fma_mixlo_f16 v46, v67, s39, 0                           // 000000215340: CC21002E 02004F43
	v_fma_mixhi_f16 v46, v68, s39, 0                           // 000000215348: CC22002E 02004F44
	s_waitcnt lgkmcnt(4)                                       // 000000215350: BF89FC47
	v_fma_mixlo_f16 v47, v69, s39, 0                           // 000000215354: CC21002F 02004F45
	v_fma_mixhi_f16 v47, v70, s39, 0                           // 00000021535C: CC22002F 02004F46
	v_fma_mixlo_f16 v48, v71, s39, 0                           // 000000215364: CC210030 02004F47
	v_fma_mixhi_f16 v48, v72, s39, 0                           // 00000021536C: CC220030 02004F48
	s_waitcnt lgkmcnt(3)                                       // 000000215374: BF89FC37
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 000000215378: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 000000215380: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 000000215388: CC210032 02004F33
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 000000215390: CC220032 02004F34
	s_waitcnt lgkmcnt(2)                                       // 000000215398: BF89FC27
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 00000021539C: CC210033 02004F35
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000002153A4: CC220033 02004F36
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000002153AC: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000002153B4: CC220034 02004F38
	s_waitcnt lgkmcnt(1)                                       // 0000002153BC: BF89FC17
	v_fma_mixlo_f16 v53, v57, s39, 0                           // 0000002153C0: CC210035 02004F39
	v_fma_mixhi_f16 v53, v58, s39, 0                           // 0000002153C8: CC220035 02004F3A
	v_fma_mixlo_f16 v54, v59, s39, 0                           // 0000002153D0: CC210036 02004F3B
	v_fma_mixhi_f16 v54, v60, s39, 0                           // 0000002153D8: CC220036 02004F3C
	s_waitcnt lgkmcnt(0)                                       // 0000002153E0: BF89FC07
	v_fma_mixlo_f16 v55, v61, s39, 0                           // 0000002153E4: CC210037 02004F3D
	v_fma_mixhi_f16 v55, v62, s39, 0                           // 0000002153EC: CC220037 02004F3E
	v_fma_mixlo_f16 v56, v63, s39, 0                           // 0000002153F4: CC210038 02004F3F
	v_fma_mixhi_f16 v56, v64, s39, 0                           // 0000002153FC: CC220038 02004F40
	ds_load_b128 v[65:68], v135 offset:320                     // 000000215404: DBFC0140 41000087
	ds_load_b128 v[69:72], v135 offset:336                     // 00000021540C: DBFC0150 45000087
	ds_load_b128 v[57:60], v135 offset:352                     // 000000215414: DBFC0160 39000087
	ds_load_b128 v[61:64], v135 offset:368                     // 00000021541C: DBFC0170 3D000087
	s_waitcnt vmcnt(12)                                        // 000000215424: BF8933F7
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[41:48], v[1:8] // 000000215428: CC404001 1C065321
	v_wmma_f32_16x16x16_f16 v[81:88], v[33:40], v[49:56], v[81:88]// 000000215430: CC404051 1D466321
	ds_load_b128 v[41:44], v135 offset:8768                    // 000000215438: DBFC2240 29000087
	ds_load_b128 v[45:48], v135 offset:8784                    // 000000215440: DBFC2250 2D000087
	ds_load_b128 v[49:52], v135 offset:8800                    // 000000215448: DBFC2260 31000087
	ds_load_b128 v[53:56], v135 offset:8816                    // 000000215450: DBFC2270 35000087
	s_waitcnt lgkmcnt(7)                                       // 000000215458: BF89FC77
	v_fma_mixlo_f16 v33, v65, s39, 0                           // 00000021545C: CC210021 02004F41
	v_fma_mixhi_f16 v33, v66, s39, 0                           // 000000215464: CC220021 02004F42
	v_fma_mixlo_f16 v34, v67, s39, 0                           // 00000021546C: CC210022 02004F43
	v_fma_mixhi_f16 v34, v68, s39, 0                           // 000000215474: CC220022 02004F44
	s_waitcnt lgkmcnt(6)                                       // 00000021547C: BF89FC67
	v_fma_mixlo_f16 v35, v69, s39, 0                           // 000000215480: CC210023 02004F45
	v_fma_mixhi_f16 v35, v70, s39, 0                           // 000000215488: CC220023 02004F46
	v_fma_mixlo_f16 v36, v71, s39, 0                           // 000000215490: CC210024 02004F47
	v_fma_mixhi_f16 v36, v72, s39, 0                           // 000000215498: CC220024 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000002154A0: BF89FC57
	v_fma_mixlo_f16 v37, v57, s39, 0                           // 0000002154A4: CC210025 02004F39
	v_fma_mixhi_f16 v37, v58, s39, 0                           // 0000002154AC: CC220025 02004F3A
	v_fma_mixlo_f16 v38, v59, s39, 0                           // 0000002154B4: CC210026 02004F3B
	v_fma_mixhi_f16 v38, v60, s39, 0                           // 0000002154BC: CC220026 02004F3C
	s_waitcnt lgkmcnt(4)                                       // 0000002154C4: BF89FC47
	v_fma_mixlo_f16 v39, v61, s39, 0                           // 0000002154C8: CC210027 02004F3D
	v_fma_mixhi_f16 v39, v62, s39, 0                           // 0000002154D0: CC220027 02004F3E
	v_fma_mixlo_f16 v40, v63, s39, 0                           // 0000002154D8: CC210028 02004F3F
	v_fma_mixhi_f16 v40, v64, s39, 0                           // 0000002154E0: CC220028 02004F40
	s_waitcnt lgkmcnt(3)                                       // 0000002154E8: BF89FC37
	v_fma_mixlo_f16 v41, v41, s39, 0                           // 0000002154EC: CC210029 02004F29
	v_fma_mixhi_f16 v41, v42, s39, 0                           // 0000002154F4: CC220029 02004F2A
	v_fma_mixlo_f16 v42, v43, s39, 0                           // 0000002154FC: CC21002A 02004F2B
	v_fma_mixhi_f16 v42, v44, s39, 0                           // 000000215504: CC22002A 02004F2C
	s_waitcnt lgkmcnt(2)                                       // 00000021550C: BF89FC27
	v_fma_mixlo_f16 v43, v45, s39, 0                           // 000000215510: CC21002B 02004F2D
	v_fma_mixhi_f16 v43, v46, s39, 0                           // 000000215518: CC22002B 02004F2E
	v_fma_mixlo_f16 v44, v47, s39, 0                           // 000000215520: CC21002C 02004F2F
	v_fma_mixhi_f16 v44, v48, s39, 0                           // 000000215528: CC22002C 02004F30
	s_waitcnt lgkmcnt(1)                                       // 000000215530: BF89FC17
	v_fma_mixlo_f16 v45, v49, s39, 0                           // 000000215534: CC21002D 02004F31
	v_fma_mixhi_f16 v45, v50, s39, 0                           // 00000021553C: CC22002D 02004F32
	v_fma_mixlo_f16 v46, v51, s39, 0                           // 000000215544: CC21002E 02004F33
	v_fma_mixhi_f16 v46, v52, s39, 0                           // 00000021554C: CC22002E 02004F34
	s_waitcnt lgkmcnt(0)                                       // 000000215554: BF89FC07
	v_fma_mixlo_f16 v47, v53, s39, 0                           // 000000215558: CC21002F 02004F35
	ds_load_b128 v[49:52], v135 offset:416                     // 000000215560: DBFC01A0 31000087
	v_fma_mixhi_f16 v47, v54, s39, 0                           // 000000215568: CC22002F 02004F36
	v_fma_mixlo_f16 v48, v55, s39, 0                           // 000000215570: CC210030 02004F37
	v_fma_mixhi_f16 v48, v56, s39, 0                           // 000000215578: CC220030 02004F38
	ds_load_b128 v[53:56], v135 offset:432                     // 000000215580: DBFC01B0 35000087
	s_waitcnt vmcnt(10)                                        // 000000215588: BF892BF7
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[33:40], v[1:8] // 00000021558C: CC404001 1C064319
	ds_load_b128 v[33:36], v135 offset:8832                    // 000000215594: DBFC2280 21000087
	ds_load_b128 v[37:40], v135 offset:8848                    // 00000021559C: DBFC2290 25000087
	v_wmma_f32_16x16x16_f16 v[81:88], v[25:32], v[41:48], v[81:88]// 0000002155A4: CC404051 1D465319
	ds_load_b128 v[41:44], v135 offset:8864                    // 0000002155AC: DBFC22A0 29000087
	ds_load_b128 v[45:48], v135 offset:8880                    // 0000002155B4: DBFC22B0 2D000087
	ds_load_b128 v[57:60], v135 offset:384                     // 0000002155BC: DBFC0180 39000087
	ds_load_b128 v[61:64], v135 offset:400                     // 0000002155C4: DBFC0190 3D000087
	s_waitcnt lgkmcnt(7)                                       // 0000002155CC: BF89FC77
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 0000002155D0: CC21001D 02004F31
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 0000002155D8: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 0000002155E0: CC21001E 02004F33
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 0000002155E8: CC22001E 02004F34
	s_waitcnt lgkmcnt(6)                                       // 0000002155F0: BF89FC67
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 0000002155F4: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 0000002155FC: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 000000215604: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 00000021560C: CC220020 02004F38
	ds_load_b128 v[49:52], v135 offset:448                     // 000000215614: DBFC01C0 31000087
	ds_load_b128 v[53:56], v135 offset:464                     // 00000021561C: DBFC01D0 35000087
	s_waitcnt lgkmcnt(7)                                       // 000000215624: BF89FC77
	v_fma_mixlo_f16 v33, v33, s39, 0                           // 000000215628: CC210021 02004F21
	v_fma_mixhi_f16 v33, v34, s39, 0                           // 000000215630: CC220021 02004F22
	v_fma_mixlo_f16 v34, v35, s39, 0                           // 000000215638: CC210022 02004F23
	v_fma_mixhi_f16 v34, v36, s39, 0                           // 000000215640: CC220022 02004F24
	s_waitcnt lgkmcnt(6)                                       // 000000215648: BF89FC67
	v_fma_mixlo_f16 v35, v37, s39, 0                           // 00000021564C: CC210023 02004F25
	v_fma_mixhi_f16 v35, v38, s39, 0                           // 000000215654: CC220023 02004F26
	v_fma_mixlo_f16 v36, v39, s39, 0                           // 00000021565C: CC210024 02004F27
	v_fma_mixhi_f16 v36, v40, s39, 0                           // 000000215664: CC220024 02004F28
	s_waitcnt lgkmcnt(5)                                       // 00000021566C: BF89FC57
	v_fma_mixlo_f16 v37, v41, s39, 0                           // 000000215670: CC210025 02004F29
	v_fma_mixhi_f16 v37, v42, s39, 0                           // 000000215678: CC220025 02004F2A
	v_fma_mixlo_f16 v38, v43, s39, 0                           // 000000215680: CC210026 02004F2B
	v_fma_mixhi_f16 v38, v44, s39, 0                           // 000000215688: CC220026 02004F2C
	ds_load_b128 v[41:44], v135 offset:480                     // 000000215690: DBFC01E0 29000087
	s_waitcnt lgkmcnt(5)                                       // 000000215698: BF89FC57
	v_fma_mixlo_f16 v39, v45, s39, 0                           // 00000021569C: CC210027 02004F2D
	v_fma_mixhi_f16 v39, v46, s39, 0                           // 0000002156A4: CC220027 02004F2E
	v_fma_mixlo_f16 v40, v47, s39, 0                           // 0000002156AC: CC210028 02004F2F
	v_fma_mixhi_f16 v40, v48, s39, 0                           // 0000002156B4: CC220028 02004F30
	ds_load_b128 v[45:48], v135 offset:496                     // 0000002156BC: DBFC01F0 2D000087
	s_waitcnt lgkmcnt(5)                                       // 0000002156C4: BF89FC57
	v_fma_mixlo_f16 v25, v57, s39, 0                           // 0000002156C8: CC210019 02004F39
	v_fma_mixhi_f16 v25, v58, s39, 0                           // 0000002156D0: CC220019 02004F3A
	v_fma_mixlo_f16 v26, v59, s39, 0                           // 0000002156D8: CC21001A 02004F3B
	v_fma_mixhi_f16 v26, v60, s39, 0                           // 0000002156E0: CC22001A 02004F3C
	s_waitcnt lgkmcnt(4)                                       // 0000002156E8: BF89FC47
	v_fma_mixlo_f16 v27, v61, s39, 0                           // 0000002156EC: CC21001B 02004F3D
	v_fma_mixhi_f16 v27, v62, s39, 0                           // 0000002156F4: CC22001B 02004F3E
	v_fma_mixlo_f16 v28, v63, s39, 0                           // 0000002156FC: CC21001C 02004F3F
	v_fma_mixhi_f16 v28, v64, s39, 0                           // 000000215704: CC22001C 02004F40
	s_waitcnt vmcnt(8)                                         // 00000021570C: BF8923F7
	v_wmma_f32_16x16x16_f16 v[81:88], v[17:24], v[33:40], v[81:88]// 000000215710: CC404051 1D464311
	s_delay_alu instid0(VALU_DEP_2)                            // 000000215718: BF870002
	v_wmma_f32_16x16x16_f16 v[1:8], v[17:24], v[25:32], v[1:8] // 00000021571C: CC404001 1C063311
	ds_load_b128 v[25:28], v135 offset:8896                    // 000000215724: DBFC22C0 19000087
	ds_load_b128 v[29:32], v135 offset:8912                    // 00000021572C: DBFC22D0 1D000087
	s_waitcnt lgkmcnt(5)                                       // 000000215734: BF89FC57
	v_fma_mixlo_f16 v17, v49, s39, 0                           // 000000215738: CC210011 02004F31
	v_fma_mixhi_f16 v17, v50, s39, 0                           // 000000215740: CC220011 02004F32
	v_fma_mixlo_f16 v18, v51, s39, 0                           // 000000215748: CC210012 02004F33
	v_fma_mixhi_f16 v18, v52, s39, 0                           // 000000215750: CC220012 02004F34
	s_waitcnt lgkmcnt(4)                                       // 000000215758: BF89FC47
	v_fma_mixlo_f16 v19, v53, s39, 0                           // 00000021575C: CC210013 02004F35
	v_fma_mixhi_f16 v19, v54, s39, 0                           // 000000215764: CC220013 02004F36
	v_fma_mixlo_f16 v20, v55, s39, 0                           // 00000021576C: CC210014 02004F37
	v_fma_mixhi_f16 v20, v56, s39, 0                           // 000000215774: CC220014 02004F38
	ds_load_b128 v[49:52], v135 offset:8928                    // 00000021577C: DBFC22E0 31000087
	ds_load_b128 v[53:56], v135 offset:8944                    // 000000215784: DBFC22F0 35000087
	s_waitcnt lgkmcnt(5)                                       // 00000021578C: BF89FC57
	v_fma_mixlo_f16 v21, v41, s39, 0                           // 000000215790: CC210015 02004F29
	v_fma_mixhi_f16 v21, v42, s39, 0                           // 000000215798: CC220015 02004F2A
	v_fma_mixlo_f16 v22, v43, s39, 0                           // 0000002157A0: CC210016 02004F2B
	v_fma_mixhi_f16 v22, v44, s39, 0                           // 0000002157A8: CC220016 02004F2C
	s_waitcnt lgkmcnt(4)                                       // 0000002157B0: BF89FC47
	v_fma_mixlo_f16 v23, v45, s39, 0                           // 0000002157B4: CC210017 02004F2D
	v_fma_mixhi_f16 v23, v46, s39, 0                           // 0000002157BC: CC220017 02004F2E
	v_fma_mixlo_f16 v24, v47, s39, 0                           // 0000002157C4: CC210018 02004F2F
	v_fma_mixhi_f16 v24, v48, s39, 0                           // 0000002157CC: CC220018 02004F30
	ds_load_b128 v[33:36], v138                                // 0000002157D4: DBFC0000 2100008A
	ds_load_b128 v[37:40], v138 offset:16                      // 0000002157DC: DBFC0010 2500008A
	ds_load_b128 v[45:48], v138 offset:2320                    // 0000002157E4: DBFC0910 2D00008A
	ds_load_b128 v[41:44], v138 offset:2304                    // 0000002157EC: DBFC0900 2900008A
	s_waitcnt lgkmcnt(7)                                       // 0000002157F4: BF89FC77
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000002157F8: CC210019 02004F19
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 000000215800: CC220019 02004F1A
	v_fma_mixlo_f16 v26, v27, s39, 0                           // 000000215808: CC21001A 02004F1B
	v_fma_mixhi_f16 v26, v28, s39, 0                           // 000000215810: CC22001A 02004F1C
	s_waitcnt lgkmcnt(6)                                       // 000000215818: BF89FC67
	v_fma_mixlo_f16 v27, v29, s39, 0                           // 00000021581C: CC21001B 02004F1D
	v_fma_mixhi_f16 v27, v30, s39, 0                           // 000000215824: CC22001B 02004F1E
	v_fma_mixlo_f16 v28, v31, s39, 0                           // 00000021582C: CC21001C 02004F1F
	v_fma_mixhi_f16 v28, v32, s39, 0                           // 000000215834: CC22001C 02004F20
	s_waitcnt vmcnt(6)                                         // 00000021583C: BF891BF7
	v_wmma_f32_16x16x16_f16 v[1:8], v[9:16], v[17:24], v[1:8]  // 000000215840: CC404001 1C062309
	s_waitcnt lgkmcnt(5)                                       // 000000215848: BF89FC57
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 00000021584C: CC21001D 02004F31
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 000000215854: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 00000021585C: CC21001E 02004F33
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 000000215864: CC22001E 02004F34
	s_waitcnt lgkmcnt(4)                                       // 00000021586C: BF89FC47
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 000000215870: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 000000215878: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 000000215880: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 000000215888: CC220020 02004F38
	s_waitcnt vmcnt(4) lgkmcnt(2)                              // 000000215890: BF891027
	v_wmma_f32_16x16x16_f16 v[17:24], v[163:170], v[33:40], v[73:80]// 000000215894: CC404011 1D2643A3
	s_delay_alu instid0(VALU_DEP_2)                            // 00000021589C: BF870002
	v_wmma_f32_16x16x16_f16 v[81:88], v[9:16], v[25:32], v[81:88]// 0000002158A0: CC404051 1D463309
	s_waitcnt lgkmcnt(0)                                       // 0000002158A8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[163:170], v[41:48], v[73:80]// 0000002158AC: CC404009 1D2653A3
	s_and_saveexec_b32 s13, s5                                 // 0000002158B4: BE8D2005
	s_cbranch_execnz 445                                       // 0000002158B8: BFA601BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45b0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158BC: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 0000002158C0: BE8D2004
	s_cbranch_execnz 464                                       // 0000002158C4: BFA601D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4608>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158C8: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 0000002158CC: BE8D2006
	s_cbranch_execnz 478                                       // 0000002158D0: BFA601DE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x464c>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158D4: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 0000002158D8: BE8D2000
	s_cbranch_execnz 492                                       // 0000002158DC: BFA601EC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4690>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158E0: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000002158E4: BE8D2001
	s_cbranch_execnz 511                                       // 0000002158E8: BFA601FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x46e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158EC: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 0000002158F0: BE8D2007
	s_cbranch_execnz 530                                       // 0000002158F4: BFA60212 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4740>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002158F8: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 0000002158FC: BE8D2008
	s_cbranch_execnz 549                                       // 000000215900: BFA60225 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4798>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215904: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 000000215908: BE8D2009
	s_cbranch_execnz 568                                       // 00000021590C: BFA60238 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x47f0>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215910: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 000000215914: BE8D200A
	s_cbranch_execnz 587                                       // 000000215918: BFA6024B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4848>
	s_or_b32 exec_lo, exec_lo, s13                             // 00000021591C: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 000000215920: BE8D200B
	s_cbranch_execnz 606                                       // 000000215924: BFA6025E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x48a0>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215928: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 00000021592C: BE8D200C
	s_cbranch_execnz 625                                       // 000000215930: BFA60271 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x48f8>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215934: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 000000215938: BE8D2000
	s_cbranch_execnz 644                                       // 00000021593C: BFA60284 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4950>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215940: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 000000215944: BE802001
	s_cbranch_execnz 663                                       // 000000215948: BFA60297 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x49a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021594C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000215950: BE802007
	s_cbranch_execnz 682                                       // 000000215954: BFA602AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4a00>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000215958: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000021595C: BE802008
	s_cbranch_execnz 701                                       // 000000215960: BFA602BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4a58>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000215964: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000215968: BE802009
	s_cbranch_execnz 720                                       // 00000021596C: BFA602D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4ab0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000215970: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000215974: BE80200A
	s_cbranch_execnz 739                                       // 000000215978: BFA602E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4b08>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021597C: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 000000215980: BE80200B
	s_cbranch_execnz 758                                       // 000000215984: BFA602F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4b60>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000215988: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 00000021598C: BE80200C
	s_cbranch_execz 18                                         // 000000215990: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fdc>
	ds_load_b32 v1, v149 offset:56                             // 000000215994: D8D80038 01000095
	s_waitcnt lgkmcnt(0)                                       // 00000021599C: BF89FC07
	v_fmac_f32_e32 v16, v88, v1                                // 0000002159A0: 56200358
	v_mad_u64_u32 v[1:2], null, 0x3000, v162, v[115:116]       // 0000002159A4: D6FE7C01 05CF44FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002159B0: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v16                          // 0000002159B4: 100620FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002159BC: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002159C4: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002159C8: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 0000002159D4: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002159DC: 8C7E007E
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000002159E0: A200FF29 3FB8AA3B
	s_waitcnt vmcnt(0)                                         // 0000002159E8: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000002159EC: BC7C0000
	s_barrier                                                  // 0000002159F0: BFBD0000
	buffer_gl0_inv                                             // 0000002159F4: E0AC0000 00000000
	s_xor_b32 s1, s0, 0x80000000                               // 0000002159FC: 8D01FF00 80000000
	s_rndne_f32 s7, s0                                         // 000000215A04: BE876300
	s_fmamk_f32 s1, s41, 0x3fb8aa3b, s1                        // 000000215A08: A3010129 3FB8AA3B
	ds_load_b128 v[1:4], v139                                  // 000000215A10: DBFC0000 0100008B
	ds_load_b128 v[5:8], v139 offset:16                        // 000000215A18: DBFC0010 0500008B
	ds_load_b128 v[9:12], v139 offset:32                       // 000000215A20: DBFC0020 0900008B
	ds_load_b128 v[13:16], v139 offset:48                      // 000000215A28: DBFC0030 0D00008B
	ds_load_b128 v[17:20], v150                                // 000000215A30: DBFC0000 11000096
	ds_load_b128 v[21:24], v150 offset:16                      // 000000215A38: DBFC0010 15000096
	ds_load_b128 v[29:32], v139 offset:80                      // 000000215A40: DBFC0050 1D00008B
	ds_load_b128 v[25:28], v139 offset:64                      // 000000215A48: DBFC0040 1900008B
	s_sub_f32 s0, s0, s7                                       // 000000215A50: A0800700
	s_fmamk_f32 s1, s41, 0x32a5705f, s1                        // 000000215A54: A3010129 32A5705F
	ds_load_b128 v[33:36], v150 offset:32                      // 000000215A5C: DBFC0020 21000096
	ds_load_b128 v[37:40], v150 offset:48                      // 000000215A64: DBFC0030 25000096
	ds_load_b128 v[45:48], v139 offset:112                     // 000000215A6C: DBFC0070 2D00008B
	ds_load_b128 v[41:44], v139 offset:96                      // 000000215A74: DBFC0060 2900008B
	ds_load_b128 v[53:56], v150 offset:80                      // 000000215A7C: DBFC0050 35000096
	ds_load_b128 v[49:52], v150 offset:64                      // 000000215A84: DBFC0040 31000096
	v_add_nc_u32_e32 v85, v140, v148                           // 000000215A8C: 4AAB298C
	s_add_f32 s0, s0, s1                                       // 000000215A90: A0000100
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 000000215A94: BF4EFF29 C2CE8ED0
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000215A9C: BF87000A
	v_exp_f32_e32 v57, s0                                      // 000000215AA0: 7E724A00
	s_cvt_i32_f32 s0, s7                                       // 000000215AA4: BE806607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000215AA8: BF870585
	.long 0xd71c0056                                           // 000000215AAC: D71C0056
	v_cndmask_b32_e32 v0, v57, v0, vcc_lo                      // 000000215AB0: 02000139
	v_dual_mov_b32 v64, s27 :: v_dual_mov_b32 v63, s26         // 000000215AB4: CA10001B 403E001A
	v_dual_mov_b32 v62, s25 :: v_dual_mov_b32 v61, s24         // 000000215ABC: CA100019 3E3C0018
	v_dual_mov_b32 v60, s23 :: v_dual_mov_b32 v59, s22         // 000000215AC4: CA100017 3C3A0016
	v_mov_b32_e32 v58, s21                                     // 000000215ACC: 7E740215
	ds_load_b128 v[69:72], v150 offset:112                     // 000000215AD0: DBFC0070 45000096
	ds_load_b128 v[65:68], v150 offset:96                      // 000000215AD8: DBFC0060 41000096
	ds_load_2addr_b32 v[81:82], v85 offset1:2                  // 000000215AE0: D8DC0200 51000055
	ds_load_2addr_b32 v[83:84], v85 offset0:4 offset1:6        // 000000215AE8: D8DC0604 53000055
	v_mov_b32_e32 v57, s20                                     // 000000215AF0: 7E720214
	s_cselect_b32 s0, -1, 0                                    // 000000215AF4: 980080C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 000000215AF8: BF4BFF29 42B17218
	s_waitcnt lgkmcnt(12)                                      // 000000215B00: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1)                            // 000000215B04: BF870001
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[1:8], v[57:64]// 000000215B08: CC404049 1CE60311
	v_cndmask_b32_e64 v21, 0, v86, s0                          // 000000215B10: D5010015 0002AC80
	ds_load_2addr_b32 v[17:18], v85 offset0:8 offset1:10       // 000000215B18: D8DC0A08 11000055
	s_cselect_b32 s0, -1, 0                                    // 000000215B20: 980080C1
	s_waitcnt lgkmcnt(9)                                       // 000000215B24: BF89FC97
	v_wmma_f32_16x16x16_f16 v[73:80], v[33:40], v[9:16], v[73:80]// 000000215B28: CC404049 1D261321
	ds_load_2addr_b32 v[19:20], v85 offset0:12 offset1:14      // 000000215B30: D8DC0E0C 13000055
	v_cndmask_b32_e64 v89, 0x7f800000, v21, s0                 // 000000215B38: D5010059 00022AFF 7F800000
	s_cmp_lg_u32 s40, s36                                      // 000000215B44: BF072428
	s_waitcnt lgkmcnt(6)                                       // 000000215B48: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[49:56], v[25:32], v[73:80]// 000000215B4C: CC404049 1D263331
	s_waitcnt lgkmcnt(3)                                       // 000000215B54: BF89FC37
	v_mul_f32_e32 v22, v89, v82                                // 000000215B58: 102CA559
	s_waitcnt lgkmcnt(2)                                       // 000000215B5C: BF89FC27
	v_mul_f32_e32 v24, v89, v84                                // 000000215B60: 1030A959
	v_wmma_f32_16x16x16_f16 v[73:80], v[65:72], v[41:48], v[73:80]// 000000215B64: CC404049 1D265341
	v_mul_f32_e32 v21, v89, v81                                // 000000215B6C: 102AA359
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000215B70: BF870112
	v_dual_mul_f32 v23, v89, v83 :: v_dual_fmac_f32 v24, 0x3b800000, v76// 000000215B74: C8C0A759 171898FF 3B800000
	v_dual_fmac_f32 v22, 0x3b800000, v74 :: v_dual_fmac_f32 v21, 0x3b800000, v73// 000000215B80: C80094FF 161492FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 000000215B8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215B90: BF870092
	v_dual_fmac_f32 v23, 0x3b800000, v75 :: v_dual_mul_f32 v18, v89, v18// 000000215B94: C80696FF 17122559 3B800000
	v_dual_mul_f32 v17, v89, v17 :: v_dual_fmac_f32 v18, 0x3b800000, v78// 000000215BA0: C8C02359 11129CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000215BAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215BB0: BF870091
	v_dual_mul_f32 v20, v89, v20 :: v_dual_fmac_f32 v17, 0x3b800000, v77// 000000215BB4: C8C02959 14109AFF 3B800000
	v_dual_mul_f32 v19, v89, v19 :: v_dual_fmac_f32 v20, 0x3b800000, v80// 000000215BC0: C8C02759 1314A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000215BCC: BF870001
	v_fmac_f32_e32 v19, 0x3b800000, v79                        // 000000215BD0: 56269EFF 3B800000
	ds_store_2addr_b32 v85, v21, v22 offset1:2                 // 000000215BD8: D8380200 00161555
	ds_store_2addr_b32 v85, v23, v24 offset0:4 offset1:6       // 000000215BE0: D8380604 00181755
	ds_store_2addr_b32 v85, v17, v18 offset0:8 offset1:10      // 000000215BE8: D8380A08 00121155
	ds_store_2addr_b32 v85, v19, v20 offset0:12 offset1:14     // 000000215BF0: D8380E0C 00141355
	ds_load_b128 v[17:20], v150 offset:2304                    // 000000215BF8: DBFC0900 11000096
	ds_load_b128 v[21:24], v150 offset:2320                    // 000000215C00: DBFC0910 15000096
	ds_load_b128 v[33:36], v150 offset:2336                    // 000000215C08: DBFC0920 21000096
	ds_load_b128 v[37:40], v150 offset:2352                    // 000000215C10: DBFC0930 25000096
	ds_load_b128 v[53:56], v150 offset:2384                    // 000000215C18: DBFC0950 35000096
	ds_load_b128 v[49:52], v150 offset:2368                    // 000000215C20: DBFC0940 31000096
	ds_load_2addr_b32 v[81:82], v151 offset1:2                 // 000000215C28: D8DC0200 51000097
	ds_load_2addr_b32 v[83:84], v151 offset0:4 offset1:6       // 000000215C30: D8DC0604 53000097
	ds_load_b128 v[69:72], v150 offset:2416                    // 000000215C38: DBFC0970 45000096
	ds_load_b128 v[65:68], v150 offset:2400                    // 000000215C40: DBFC0960 41000096
	ds_load_2addr_b32 v[85:86], v151 offset0:8 offset1:10      // 000000215C48: D8DC0A08 55000097
	ds_load_2addr_b32 v[87:88], v151 offset0:12 offset1:14     // 000000215C50: D8DC0E0C 57000097
	s_waitcnt lgkmcnt(10)                                      // 000000215C58: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[1:8], v[57:64]// 000000215C5C: CC404049 1CE60311
	s_waitcnt lgkmcnt(8)                                       // 000000215C64: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000215C68: BF870131
	v_wmma_f32_16x16x16_f16 v[73:80], v[33:40], v[9:16], v[73:80]// 000000215C6C: CC404049 1D261321
	s_waitcnt lgkmcnt(5)                                       // 000000215C74: BF89FC57
	v_mul_f32_e32 v18, v89, v82                                // 000000215C78: 1024A559
	v_wmma_f32_16x16x16_f16 v[73:80], v[49:56], v[25:32], v[73:80]// 000000215C7C: CC404049 1D263331
	s_waitcnt lgkmcnt(2)                                       // 000000215C84: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215C88: BF870091
	v_wmma_f32_16x16x16_f16 v[73:80], v[65:72], v[41:48], v[73:80]// 000000215C8C: CC404049 1D265341
	v_dual_mul_f32 v17, v89, v81 :: v_dual_fmac_f32 v18, 0x3b800000, v74// 000000215C94: C8C0A359 111294FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215CA0: BF870091
	v_dual_mul_f32 v20, v89, v84 :: v_dual_fmac_f32 v17, 0x3b800000, v73// 000000215CA4: C8C0A959 141092FF 3B800000
	v_dual_mul_f32 v19, v89, v83 :: v_dual_fmac_f32 v20, 0x3b800000, v76// 000000215CB0: C8C0A759 131498FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 000000215CBC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215CC0: BF870091
	v_dual_mul_f32 v22, v89, v86 :: v_dual_fmac_f32 v19, 0x3b800000, v75// 000000215CC4: C8C0AD59 161296FF 3B800000
	v_dual_mul_f32 v21, v89, v85 :: v_dual_fmac_f32 v22, 0x3b800000, v78// 000000215CD0: C8C0AB59 15169CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000215CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215CE0: BF870091
	v_dual_mul_f32 v24, v89, v88 :: v_dual_fmac_f32 v21, 0x3b800000, v77// 000000215CE4: C8C0B159 18149AFF 3B800000
	v_dual_mul_f32 v23, v89, v87 :: v_dual_fmac_f32 v24, 0x3b800000, v80// 000000215CF0: C8C0AF59 1718A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000215CFC: BF870001
	v_fmac_f32_e32 v23, 0x3b800000, v79                        // 000000215D00: 562E9EFF 3B800000
	ds_store_2addr_b32 v151, v17, v18 offset1:2                // 000000215D08: D8380200 00121197
	ds_store_2addr_b32 v151, v19, v20 offset0:4 offset1:6      // 000000215D10: D8380604 00141397
	ds_store_2addr_b32 v151, v21, v22 offset0:8 offset1:10     // 000000215D18: D8380A08 00161597
	ds_store_2addr_b32 v151, v23, v24 offset0:12 offset1:14    // 000000215D20: D8380E0C 00181797
	ds_load_b128 v[17:20], v150 offset:4608                    // 000000215D28: DBFC1200 11000096
	ds_load_b128 v[21:24], v150 offset:4624                    // 000000215D30: DBFC1210 15000096
	ds_load_b128 v[33:36], v150 offset:4640                    // 000000215D38: DBFC1220 21000096
	ds_load_b128 v[37:40], v150 offset:4656                    // 000000215D40: DBFC1230 25000096
	ds_load_b128 v[53:56], v150 offset:4688                    // 000000215D48: DBFC1250 35000096
	ds_load_b128 v[49:52], v150 offset:4672                    // 000000215D50: DBFC1240 31000096
	ds_load_2addr_b32 v[81:82], v152 offset1:2                 // 000000215D58: D8DC0200 51000098
	ds_load_2addr_b32 v[83:84], v152 offset0:4 offset1:6       // 000000215D60: D8DC0604 53000098
	ds_load_b128 v[69:72], v150 offset:4720                    // 000000215D68: DBFC1270 45000096
	ds_load_b128 v[65:68], v150 offset:4704                    // 000000215D70: DBFC1260 41000096
	ds_load_2addr_b32 v[85:86], v152 offset0:8 offset1:10      // 000000215D78: D8DC0A08 55000098
	ds_load_2addr_b32 v[87:88], v152 offset0:12 offset1:14     // 000000215D80: D8DC0E0C 57000098
	s_waitcnt lgkmcnt(10)                                      // 000000215D88: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[1:8], v[57:64]// 000000215D8C: CC404049 1CE60311
	s_waitcnt lgkmcnt(8)                                       // 000000215D94: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000215D98: BF870131
	v_wmma_f32_16x16x16_f16 v[73:80], v[33:40], v[9:16], v[73:80]// 000000215D9C: CC404049 1D261321
	s_waitcnt lgkmcnt(5)                                       // 000000215DA4: BF89FC57
	v_mul_f32_e32 v18, v89, v82                                // 000000215DA8: 1024A559
	v_wmma_f32_16x16x16_f16 v[73:80], v[49:56], v[25:32], v[73:80]// 000000215DAC: CC404049 1D263331
	s_waitcnt lgkmcnt(2)                                       // 000000215DB4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215DB8: BF870091
	v_wmma_f32_16x16x16_f16 v[73:80], v[65:72], v[41:48], v[73:80]// 000000215DBC: CC404049 1D265341
	v_dual_mul_f32 v17, v89, v81 :: v_dual_fmac_f32 v18, 0x3b800000, v74// 000000215DC4: C8C0A359 111294FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215DD0: BF870091
	v_dual_mul_f32 v20, v89, v84 :: v_dual_fmac_f32 v17, 0x3b800000, v73// 000000215DD4: C8C0A959 141092FF 3B800000
	v_dual_mul_f32 v19, v89, v83 :: v_dual_fmac_f32 v20, 0x3b800000, v76// 000000215DE0: C8C0A759 131498FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 000000215DEC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215DF0: BF870091
	v_dual_mul_f32 v22, v89, v86 :: v_dual_fmac_f32 v19, 0x3b800000, v75// 000000215DF4: C8C0AD59 161296FF 3B800000
	v_dual_mul_f32 v21, v89, v85 :: v_dual_fmac_f32 v22, 0x3b800000, v78// 000000215E00: C8C0AB59 15169CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000215E0C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215E10: BF870091
	v_dual_mul_f32 v24, v89, v88 :: v_dual_fmac_f32 v21, 0x3b800000, v77// 000000215E14: C8C0B159 18149AFF 3B800000
	v_dual_mul_f32 v23, v89, v87 :: v_dual_fmac_f32 v24, 0x3b800000, v80// 000000215E20: C8C0AF59 1718A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000215E2C: BF870001
	v_fmac_f32_e32 v23, 0x3b800000, v79                        // 000000215E30: 562E9EFF 3B800000
	ds_store_2addr_b32 v152, v17, v18 offset1:2                // 000000215E38: D8380200 00121198
	ds_store_2addr_b32 v152, v19, v20 offset0:4 offset1:6      // 000000215E40: D8380604 00141398
	ds_store_2addr_b32 v152, v21, v22 offset0:8 offset1:10     // 000000215E48: D8380A08 00161598
	ds_store_2addr_b32 v152, v23, v24 offset0:12 offset1:14    // 000000215E50: D8380E0C 00181798
	ds_load_b128 v[17:20], v153                                // 000000215E58: DBFC0000 11000099
	ds_load_b128 v[21:24], v153 offset:16                      // 000000215E60: DBFC0010 15000099
	ds_load_b128 v[33:36], v153 offset:32                      // 000000215E68: DBFC0020 21000099
	ds_load_b128 v[37:40], v153 offset:48                      // 000000215E70: DBFC0030 25000099
	ds_load_b128 v[53:56], v153 offset:80                      // 000000215E78: DBFC0050 35000099
	ds_load_b128 v[49:52], v153 offset:64                      // 000000215E80: DBFC0040 31000099
	ds_load_b128 v[69:72], v153 offset:112                     // 000000215E88: DBFC0070 45000099
	ds_load_b128 v[65:68], v153 offset:96                      // 000000215E90: DBFC0060 41000099
	ds_load_2addr_b32 v[81:82], v154 offset1:2                 // 000000215E98: D8DC0200 5100009A
	ds_load_2addr_b32 v[83:84], v154 offset0:4 offset1:6       // 000000215EA0: D8DC0604 5300009A
	ds_load_2addr_b32 v[85:86], v154 offset0:8 offset1:10      // 000000215EA8: D8DC0A08 5500009A
	ds_load_2addr_b32 v[87:88], v154 offset0:12 offset1:14     // 000000215EB0: D8DC0E0C 5700009A
	s_waitcnt lgkmcnt(10)                                      // 000000215EB8: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[1:8], v[57:64]// 000000215EBC: CC404049 1CE60311
	s_waitcnt lgkmcnt(8)                                       // 000000215EC4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000215EC8: BF870131
	v_wmma_f32_16x16x16_f16 v[73:80], v[33:40], v[9:16], v[73:80]// 000000215ECC: CC404049 1D261321
	s_waitcnt lgkmcnt(3)                                       // 000000215ED4: BF89FC37
	v_mul_f32_e32 v2, v89, v82                                 // 000000215ED8: 1004A559
	v_wmma_f32_16x16x16_f16 v[73:80], v[49:56], v[25:32], v[73:80]// 000000215EDC: CC404049 1D263331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215EE4: BF870091
	v_wmma_f32_16x16x16_f16 v[73:80], v[65:72], v[41:48], v[73:80]// 000000215EE8: CC404049 1D265341
	v_dual_mul_f32 v1, v89, v81 :: v_dual_fmac_f32 v2, 0x3b800000, v74// 000000215EF0: C8C0A359 010294FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 000000215EFC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215F00: BF870091
	v_dual_mul_f32 v4, v89, v84 :: v_dual_fmac_f32 v1, 0x3b800000, v73// 000000215F04: C8C0A959 040092FF 3B800000
	v_dual_mul_f32 v3, v89, v83 :: v_dual_fmac_f32 v4, 0x3b800000, v76// 000000215F10: C8C0A759 030498FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 000000215F1C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215F20: BF870091
	v_dual_mul_f32 v6, v89, v86 :: v_dual_fmac_f32 v3, 0x3b800000, v75// 000000215F24: C8C0AD59 060296FF 3B800000
	v_dual_mul_f32 v5, v89, v85 :: v_dual_fmac_f32 v6, 0x3b800000, v78// 000000215F30: C8C0AB59 05069CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000215F3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000215F40: BF870091
	v_dual_mul_f32 v8, v89, v88 :: v_dual_fmac_f32 v5, 0x3b800000, v77// 000000215F44: C8C0B159 08049AFF 3B800000
	v_dual_mul_f32 v7, v89, v87 :: v_dual_fmac_f32 v8, 0x3b800000, v80// 000000215F50: C8C0AF59 0708A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000215F5C: BF870001
	v_fmac_f32_e32 v7, 0x3b800000, v79                         // 000000215F60: 560E9EFF 3B800000
	ds_store_2addr_b32 v154, v1, v2 offset1:2                  // 000000215F68: D8380200 0002019A
	ds_store_2addr_b32 v154, v3, v4 offset0:4 offset1:6        // 000000215F70: D8380604 0004039A
	ds_store_2addr_b32 v154, v5, v6 offset0:8 offset1:10       // 000000215F78: D8380A08 0006059A
	ds_store_2addr_b32 v154, v7, v8 offset0:12 offset1:14      // 000000215F80: D8380E0C 0008079A
	s_waitcnt lgkmcnt(0)                                       // 000000215F88: BF89FC07
	s_barrier                                                  // 000000215F8C: BFBD0000
	buffer_gl0_inv                                             // 000000215F90: E0AC0000 00000000
	s_cbranch_scc0 392                                         // 000000215F98: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4bbc>
	s_cmp_lg_u32 s40, s37                                      // 000000215F9C: BF072528
	s_cbranch_scc0 430                                         // 000000215FA0: BFA101AE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c5c>
	s_cmp_lg_u32 s40, s38                                      // 000000215FA4: BF072628
	s_cbranch_scc1 61351                                       // 000000215FA8: BFA2EFA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x448>
	s_branch 459                                               // 000000215FAC: BFA001CB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4cdc>
	s_clause 0x1                                               // 000000215FB0: BF850001
	global_load_b128 v[29:32], v[123:124], off offset:48       // 000000215FB4: DC5E0030 1D7C007B
	global_load_b128 v[25:28], v[123:124], off offset:32       // 000000215FBC: DC5E0020 197C007B
	ds_load_b128 v[33:36], v138 offset:32                      // 000000215FC4: DBFC0020 2100008A
	ds_load_b128 v[37:40], v138 offset:48                      // 000000215FCC: DBFC0030 2500008A
	ds_load_b128 v[45:48], v138 offset:2352                    // 000000215FD4: DBFC0930 2D00008A
	ds_load_b128 v[41:44], v138 offset:2336                    // 000000215FDC: DBFC0920 2900008A
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000215FE4: BF890027
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000215FE8: CC404011 1C464319
	s_waitcnt lgkmcnt(0)                                       // 000000215FF0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000215FF4: CC404009 1C265319
	s_or_b32 exec_lo, exec_lo, s13                             // 000000215FFC: 8C7E0D7E
	s_and_saveexec_b32 s13, s4                                 // 000000216000: BE8D2004
	s_cbranch_execz 65072                                      // 000000216004: BFA5FE30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ec8>
	ds_load_b128 v[25:28], v138 offset:64                      // 000000216008: DBFC0040 1900008A
	ds_load_b128 v[29:32], v138 offset:80                      // 000000216010: DBFC0050 1D00008A
	ds_load_b128 v[37:40], v138 offset:2384                    // 000000216018: DBFC0950 2500008A
	ds_load_b128 v[33:36], v138 offset:2368                    // 000000216020: DBFC0940 2100008A
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 000000216028: BF890827
	v_wmma_f32_16x16x16_f16 v[17:24], v[105:112], v[25:32], v[17:24]// 00000021602C: CC404011 1C463369
	s_waitcnt lgkmcnt(0)                                       // 000000216034: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[105:112], v[33:40], v[9:16]// 000000216038: CC404009 1C264369
	s_or_b32 exec_lo, exec_lo, s13                             // 000000216040: 8C7E0D7E
	s_and_saveexec_b32 s13, s6                                 // 000000216044: BE8D2006
	s_cbranch_execz 65058                                      // 000000216048: BFA5FE22 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ed4>
	ds_load_b128 v[25:28], v138 offset:96                      // 00000021604C: DBFC0060 1900008A
	ds_load_b128 v[29:32], v138 offset:112                     // 000000216054: DBFC0070 1D00008A
	ds_load_b128 v[37:40], v138 offset:2416                    // 00000021605C: DBFC0970 2500008A
	ds_load_b128 v[33:36], v138 offset:2400                    // 000000216064: DBFC0960 2100008A
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 00000021606C: BF890027
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[25:32], v[17:24]// 000000216070: CC404011 1C463361
	s_waitcnt lgkmcnt(0)                                       // 000000216078: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[33:40], v[9:16]// 00000021607C: CC404009 1C264361
	s_or_b32 exec_lo, exec_lo, s13                             // 000000216084: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 000000216088: BE8D2000
	s_cbranch_execz 65044                                      // 00000021608C: BFA5FE14 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ee0>
	ds_load_b32 v25, v149                                      // 000000216090: D8D80000 19000095
	s_waitcnt lgkmcnt(0)                                       // 000000216098: BF89FC07
	v_fma_f32 v1, v1, v25, v17                                 // 00000021609C: D6130001 04463301
	v_mad_u64_u32 v[25:26], null, 0x3000, v155, v[115:116]     // 0000002160A4: D6FE7C19 05CF36FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002160B0: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000002160B4: 100202FF 3B800000
	v_bfe_u32 v17, v1, 16, 1                                   // 0000002160BC: D6100011 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002160C4: BF870001
	v_add3_u32 v1, v1, v17, 0x7fff                             // 0000002160C8: D6550001 03FE2301 00007FFF
	global_store_d16_hi_b16 v[25:26], v1, off                  // 0000002160D4: DC960000 007C0119
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002160DC: 8C7E0D7E
	s_and_saveexec_b32 s13, s1                                 // 0000002160E0: BE8D2001
	s_cbranch_execz 65025                                      // 0000002160E4: BFA5FE01 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3eec>
	ds_load_b32 v1, v149 offset:8                              // 0000002160E8: D8D80008 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002160F0: BF89FC07
	v_fma_f32 v1, v2, v1, v18                                  // 0000002160F4: D6130001 044A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002160FC: BF870121
	v_mul_f32_e32 v17, 0x3b800000, v1                          // 000000216100: 102202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v156, v[115:116]       // 000000216108: D6FE7C01 05CF38FF 00003000
	v_bfe_u32 v18, v17, 16, 1                                  // 000000216114: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021611C: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000216120: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[1:2], v17, off                   // 00000021612C: DC960000 007C1101
	s_or_b32 exec_lo, exec_lo, s13                             // 000000216134: 8C7E0D7E
	s_and_saveexec_b32 s13, s7                                 // 000000216138: BE8D2007
	s_cbranch_execz 65006                                      // 00000021613C: BFA5FDEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ef8>
	ds_load_b32 v1, v149 offset:16                             // 000000216140: D8D80010 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216148: BF89FC07
	v_fma_f32 v1, v3, v1, v19                                  // 00000021614C: D6130001 044E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216154: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216158: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v157, v[115:116]       // 000000216160: D6FE7C01 05CF3AFF 00003000
	v_bfe_u32 v17, v3, 16, 1                                   // 00000021616C: D6100011 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216174: BF870001
	v_add3_u32 v3, v3, v17, 0x7fff                             // 000000216178: D6550003 03FE2303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000216184: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 00000021618C: 8C7E0D7E
	s_and_saveexec_b32 s13, s8                                 // 000000216190: BE8D2008
	s_cbranch_execz 64987                                      // 000000216194: BFA5FDDB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f04>
	ds_load_b32 v1, v149 offset:24                             // 000000216198: D8D80018 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002161A0: BF89FC07
	v_fma_f32 v1, v4, v1, v20                                  // 0000002161A4: D6130001 04520304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002161AC: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000002161B0: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v158, v[115:116]       // 0000002161B8: D6FE7C01 05CF3CFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002161C4: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002161CC: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002161D0: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000002161DC: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002161E4: 8C7E0D7E
	s_and_saveexec_b32 s13, s9                                 // 0000002161E8: BE8D2009
	s_cbranch_execz 64968                                      // 0000002161EC: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f10>
	ds_load_b32 v1, v149 offset:32                             // 0000002161F0: D8D80020 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002161F8: BF89FC07
	v_fma_f32 v1, v5, v1, v21                                  // 0000002161FC: D6130001 04560305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216204: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216208: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v159, v[115:116]       // 000000216210: D6FE7C01 05CF3EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000021621C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216224: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216228: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000216234: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 00000021623C: 8C7E0D7E
	s_and_saveexec_b32 s13, s10                                // 000000216240: BE8D200A
	s_cbranch_execz 64949                                      // 000000216244: BFA5FDB5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f1c>
	ds_load_b32 v1, v149 offset:40                             // 000000216248: D8D80028 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216250: BF89FC07
	v_fma_f32 v1, v6, v1, v22                                  // 000000216254: D6130001 045A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021625C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216260: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v160, v[115:116]       // 000000216268: D6FE7C01 05CF40FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 000000216274: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021627C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216280: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000021628C: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 000000216294: 8C7E0D7E
	s_and_saveexec_b32 s13, s11                                // 000000216298: BE8D200B
	s_cbranch_execz 64930                                      // 00000021629C: BFA5FDA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f28>
	ds_load_b32 v1, v149 offset:48                             // 0000002162A0: D8D80030 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002162A8: BF89FC07
	v_fma_f32 v1, v7, v1, v23                                  // 0000002162AC: D6130001 045E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002162B4: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000002162B8: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v161, v[115:116]       // 0000002162C0: D6FE7C01 05CF42FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002162CC: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002162D4: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002162D8: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000002162E4: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 0000002162EC: 8C7E0D7E
	s_and_saveexec_b32 s13, s12                                // 0000002162F0: BE8D200C
	s_cbranch_execz 64911                                      // 0000002162F4: BFA5FD8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f34>
	ds_load_b32 v1, v149 offset:56                             // 0000002162F8: D8D80038 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216300: BF89FC07
	v_fma_f32 v1, v8, v1, v24                                  // 000000216304: D6130001 04620308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021630C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216310: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v162, v[115:116]       // 000000216318: D6FE7C01 05CF44FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 000000216324: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021632C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216330: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000021633C: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 000000216344: 8C7E0D7E
	s_and_saveexec_b32 s13, s0                                 // 000000216348: BE8D2000
	s_cbranch_execz 64892                                      // 00000021634C: BFA5FD7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f40>
	ds_load_b32 v1, v149                                       // 000000216350: D8D80000 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216358: BF89FC07
	v_fma_f32 v1, v81, v1, v9                                  // 00000021635C: D6130001 04260351
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216364: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216368: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v155, v[115:116]       // 000000216370: D6FE7C01 05CF36FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000021637C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216384: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216388: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 000000216394: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s13                             // 00000021639C: 8C7E0D7E
	s_and_saveexec_b32 s0, s1                                  // 0000002163A0: BE802001
	s_cbranch_execz 64873                                      // 0000002163A4: BFA5FD69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f4c>
	ds_load_b32 v1, v149 offset:8                              // 0000002163A8: D8D80008 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002163B0: BF89FC07
	v_fma_f32 v1, v82, v1, v10                                 // 0000002163B4: D6130001 042A0352
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002163BC: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000002163C0: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v156, v[115:116]       // 0000002163C8: D6FE7C01 05CF38FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002163D4: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002163DC: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002163E0: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 0000002163EC: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002163F4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000002163F8: BE802007
	s_cbranch_execz 64854                                      // 0000002163FC: BFA5FD56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f58>
	ds_load_b32 v1, v149 offset:16                             // 000000216400: D8D80010 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216408: BF89FC07
	v_fma_f32 v1, v83, v1, v11                                 // 00000021640C: D6130001 042E0353
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216414: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216418: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v157, v[115:116]       // 000000216420: D6FE7C01 05CF3AFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000021642C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216434: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216438: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 000000216444: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021644C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000216450: BE802008
	s_cbranch_execz 64835                                      // 000000216454: BFA5FD43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f64>
	ds_load_b32 v1, v149 offset:24                             // 000000216458: D8D80018 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216460: BF89FC07
	v_fma_f32 v1, v84, v1, v12                                 // 000000216464: D6130001 04320354
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021646C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216470: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v158, v[115:116]       // 000000216478: D6FE7C01 05CF3CFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 000000216484: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021648C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216490: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 00000021649C: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002164A4: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000002164A8: BE802009
	s_cbranch_execz 64816                                      // 0000002164AC: BFA5FD30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f70>
	ds_load_b32 v1, v149 offset:32                             // 0000002164B0: D8D80020 01000095
	s_waitcnt lgkmcnt(0)                                       // 0000002164B8: BF89FC07
	v_fma_f32 v1, v85, v1, v13                                 // 0000002164BC: D6130001 04360355
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002164C4: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000002164C8: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v159, v[115:116]       // 0000002164D0: D6FE7C01 05CF3EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002164DC: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002164E4: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002164E8: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 0000002164F4: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002164FC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000216500: BE80200A
	s_cbranch_execz 64797                                      // 000000216504: BFA5FD1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f7c>
	ds_load_b32 v1, v149 offset:40                             // 000000216508: D8D80028 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216510: BF89FC07
	v_fma_f32 v1, v86, v1, v14                                 // 000000216514: D6130001 043A0356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021651C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216520: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v160, v[115:116]       // 000000216528: D6FE7C01 05CF40FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 000000216534: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021653C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216540: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 00000021654C: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 000000216554: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 000000216558: BE80200B
	s_cbranch_execz 64778                                      // 00000021655C: BFA5FD0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f88>
	ds_load_b32 v1, v149 offset:48                             // 000000216560: D8D80030 01000095
	s_waitcnt lgkmcnt(0)                                       // 000000216568: BF89FC07
	v_fma_f32 v1, v87, v1, v15                                 // 00000021656C: D6130001 043E0357
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216574: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 000000216578: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v161, v[115:116]       // 000000216580: D6FE7C01 05CF42FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000021658C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216594: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000216598: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:32          // 0000002165A4: DC960020 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002165AC: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000002165B0: BE80200C
	s_cbranch_execnz 64759                                     // 0000002165B4: BFA6FCF7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3f94>
	s_branch 64776                                             // 0000002165B8: BFA0FD08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fdc>
	v_dual_mov_b32 v1, v117 :: v_dual_mov_b32 v4, v126         // 0000002165BC: CA100175 0104017E
	v_dual_mov_b32 v3, v136 :: v_dual_mov_b32 v2, v118         // 0000002165C4: CA100188 03020176
	s_mov_b32 s7, 0                                            // 0000002165CC: BE870080
	s_nop 0                                                    // 0000002165D0: BF800000
	s_nop 0                                                    // 0000002165D4: BF800000
	s_nop 0                                                    // 0000002165D8: BF800000
	s_nop 0                                                    // 0000002165DC: BF800000
	s_nop 0                                                    // 0000002165E0: BF800000
	s_nop 0                                                    // 0000002165E4: BF800000
	s_nop 0                                                    // 0000002165E8: BF800000
	s_nop 0                                                    // 0000002165EC: BF800000
	s_nop 0                                                    // 0000002165F0: BF800000
	s_nop 0                                                    // 0000002165F4: BF800000
	s_nop 0                                                    // 0000002165F8: BF800000
	s_nop 0                                                    // 0000002165FC: BF800000
	ds_load_b32 v5, v3 offset:18432                            // 000000216600: D8D84800 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000216608: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 16, v3                                // 000000216610: 4A060690
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000216614: BF8700D2
	.long 0xd4490000                                           // 000000216618: D4490000
	v_cndmask_b32_e32 v1, 0xf7f, v4, vcc_lo                    // 00000021661C: 020208FF 00000F7F
	s_or_b32 s7, s0, s7                                        // 000000216624: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 000000216628: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000021662C: DC6A0000 007C0501
	.long 0xd7000101                                           // 000000216634: D7000101
	v_cndmask_b32_e32 v1, 0x800, v1, vcc_lo                    // 000000216638: 020202FF 00000800
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 000000216640: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000216648: 917E077E
	s_cbranch_execnz 65516                                     // 00000021664C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c00>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000216650: 8C7E077E
	s_cmp_lg_u32 s40, s37                                      // 000000216654: BF072528
	s_cbranch_scc1 65106                                       // 000000216658: BFA2FE52 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45a4>
	v_dual_mov_b32 v3, v136 :: v_dual_mov_b32 v4, v126         // 00000021665C: CA100188 0304017E
	v_dual_mov_b32 v1, v119 :: v_dual_mov_b32 v2, v120         // 000000216664: CA100177 01020178
	s_mov_b32 s7, 0                                            // 00000021666C: BE870080
	s_nop 0                                                    // 000000216670: BF800000
	s_nop 0                                                    // 000000216674: BF800000
	s_nop 0                                                    // 000000216678: BF800000
	s_nop 0                                                    // 00000021667C: BF800000
	ds_load_b32 v5, v3 offset:18432                            // 000000216680: D8D84800 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000216688: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 16, v3                                // 000000216690: 4A060690
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000216694: BF8700D2
	.long 0xd4490000                                           // 000000216698: D4490000
	v_cndmask_b32_e32 v1, 0xf7f, v4, vcc_lo                    // 00000021669C: 020208FF 00000F7F
	s_or_b32 s7, s0, s7                                        // 0000002166A4: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 0000002166A8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000002166AC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000002166B4: D7000101
	v_cndmask_b32_e32 v1, 0x800, v1, vcc_lo                    // 0000002166B8: 020202FF 00000800
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000002166C0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000002166C8: 917E077E
	s_cbranch_execnz 65516                                     // 0000002166CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c80>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000002166D0: 8C7E077E
	s_cmp_lg_u32 s40, s38                                      // 0000002166D4: BF072628
	s_cbranch_scc1 60891                                       // 0000002166D8: BFA2EDDB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x448>
	v_dual_mov_b32 v1, v121 :: v_dual_mov_b32 v4, v126         // 0000002166DC: CA100179 0104017E
	v_dual_mov_b32 v3, v136 :: v_dual_mov_b32 v2, v122         // 0000002166E4: CA100188 0302017A
	s_mov_b32 s7, 0                                            // 0000002166EC: BE870080
	s_nop 0                                                    // 0000002166F0: BF800000
	s_nop 0                                                    // 0000002166F4: BF800000
	s_nop 0                                                    // 0000002166F8: BF800000
	s_nop 0                                                    // 0000002166FC: BF800000
	ds_load_b32 v5, v3 offset:18432                            // 000000216700: D8D84800 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000216708: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 16, v3                                // 000000216710: 4A060690
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000216714: BF8700D2
	.long 0xd4490000                                           // 000000216718: D4490000
	v_cndmask_b32_e32 v1, 0xf7f, v4, vcc_lo                    // 00000021671C: 020208FF 00000F7F
	s_or_b32 s7, s0, s7                                        // 000000216724: 8C070700
	s_waitcnt lgkmcnt(0)                                       // 000000216728: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000021672C: DC6A0000 007C0501
	.long 0xd7000101                                           // 000000216734: D7000101
	v_cndmask_b32_e32 v1, 0x800, v1, vcc_lo                    // 000000216738: 020202FF 00000800
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 000000216740: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000216748: 917E077E
	s_cbranch_execnz 65516                                     // 00000021674C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d00>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000216750: 8C7E077E
	s_branch 60860                                             // 000000216754: BFA0EDBC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x448>
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 000000216758: CA100030 01020031
	v_mov_b32_e32 v4, v126                                     // 000000216760: 7E08037E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000216764: BF870091
	.long 0xd7006a00                                           // 000000216768: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 00000021676C: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 000000216770: D5207C01 01AA0413
	s_add_u32 s0, s33, s34                                     // 000000216778: 80002221
	s_addc_u32 s1, s15, s35                                    // 00000021677C: 8201230F
	.long 0xd7006a00                                           // 000000216780: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000216784: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000216788: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000021678C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000216794: BE810080
	.long 0xd7006a00                                           // 000000216798: D7006A00
	v_cndmask_b32_e32 v1, v0, v113, vcc_lo                     // 00000021679C: 0202E300
	v_add_co_ci_u32_e64 v1, null, v1, v114, vcc_lo             // 0000002167A0: D5207C01 01AAE501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002167A8: BF870092
	.long 0xd7006a00                                           // 0000002167AC: D7006A00
	v_cndmask_b32_e32 v1, v0, v125, vcc_lo                     // 0000002167B0: 0202FB00
	v_add_co_ci_u32_e64 v1, null, v1, v141, vcc_lo             // 0000002167B4: D5207C01 01AB1B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002167BC: BF870092
	.long 0xd7006a00                                           // 0000002167C0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000002167C4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000002167C8: D5207C01 01AA0211
	s_nop 0                                                    // 0000002167D0: BF800000
	s_nop 0                                                    // 0000002167D4: BF800000
	s_nop 0                                                    // 0000002167D8: BF800000
	s_nop 0                                                    // 0000002167DC: BF800000
	s_nop 0                                                    // 0000002167E0: BF800000
	s_nop 0                                                    // 0000002167E4: BF800000
	s_nop 0                                                    // 0000002167E8: BF800000
	s_nop 0                                                    // 0000002167EC: BF800000
	s_nop 0                                                    // 0000002167F0: BF800000
	s_nop 0                                                    // 0000002167F4: BF800000
	s_nop 0                                                    // 0000002167F8: BF800000
	s_nop 0                                                    // 0000002167FC: BF800000
	ds_load_b32 v2, v136 offset:18432                          // 000000216800: D8D84800 02000088
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000216808: 4A0808FF 00000080
	v_add_nc_u32_e32 v136, 16, v136                            // 000000216810: 4B111090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000216814: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v4                         // 000000216818: 7C9208FF 00000F7F
	s_or_b32 s1, vcc_lo, s1                                    // 000000216820: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000216824: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000216828: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000216830: D7000000
	v_cndmask_b32_e32 v1, 0x800, v0, vcc_lo                    // 000000216834: 020200FF 00000800
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000021683C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000216844: 917E017E
	s_cbranch_execnz 65517                                     // 000000216848: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi4ELi4ELb1ELb0ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4e00>
	s_nop 0                                                    // 00000021684C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000216850: BFB60003
	s_endpgm                                                   // 000000216854: BFB00000
		...

