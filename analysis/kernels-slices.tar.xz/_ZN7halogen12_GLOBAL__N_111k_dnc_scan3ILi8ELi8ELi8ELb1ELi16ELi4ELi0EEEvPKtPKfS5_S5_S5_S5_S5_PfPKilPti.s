00000000000ca800 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000CA800: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000CA804: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000CA80C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000CA814: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000CA818: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000CA81C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000CA820: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000CA828: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000CA82C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000CA830: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000CA834: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000CA83C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000CA840: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000CA844: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000CA848: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000CA84C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000CA850: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000CA854: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000CA858: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000CA85C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000CA864: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000CA86C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000CA870: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000CA874: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000CA878: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000CA87C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000CA880: 821E191E
	.long 0xd7001f02                                           // 0000000CA884: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000CA888: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000CA88C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000CA894: BE9E0080
	s_nop 0                                                    // 0000000CA898: BF800000
	s_nop 0                                                    // 0000000CA89C: BF800000
	s_nop 0                                                    // 0000000CA8A0: BF800000
	s_nop 0                                                    // 0000000CA8A4: BF800000
	s_nop 0                                                    // 0000000CA8A8: BF800000
	s_nop 0                                                    // 0000000CA8AC: BF800000
	s_nop 0                                                    // 0000000CA8B0: BF800000
	s_nop 0                                                    // 0000000CA8B4: BF800000
	s_nop 0                                                    // 0000000CA8B8: BF800000
	s_nop 0                                                    // 0000000CA8BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000CA8C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000CA8C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA8CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000CA8D0: 300C1089
	.long 0xd7006a06                                           // 0000000CA8D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000CA8D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CA8DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000CA8E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000CA8E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000CA8F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000CA8F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000CA8FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000CA908: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000CA90C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000CA910: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000CA918: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000CA91C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000CA920: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000CA924: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000CA92C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000CA934: 32040084
	s_mov_b32 s0, 0                                            // 0000000CA938: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000CA93C: BF89FC07
	s_barrier                                                  // 0000000CA940: BFBD0000
	buffer_gl0_inv                                             // 0000000CA944: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000CA94C: BF02801E
	s_cbranch_scc1 12                                          // 0000000CA950: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000CA954: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000CA95C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CA964: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000CA968: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000CA970: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000CA974: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000CA978: 916A007E
	s_cbranch_vccz 2                                           // 0000000CA97C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2616                                              // 0000000CA980: BFA00A38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a64>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000CA984: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000CA988: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000CA98C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000CA994: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000CA998: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000CA99C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000CA9A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000CA9A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000CA9AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000CA9B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000CA9B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000CA9B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000CA9BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000CA9C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000CA9C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000CA9C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000CA9D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000CA9D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000CA9DC: B00A0204
	.long 0xd7000b2c                                           // 0000000CA9E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000CA9E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000CA9E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000CA9EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000CA9F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000CAA00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000CAA04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000CAA10: 3816500A
	.long 0xd7000a05                                           // 0000000CAA14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000CAA18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CAA1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000CAA20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000CAA28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000CAA2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAA30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000CAA34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000CAA3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000CAA40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000CAA44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000CAA4C: 84848E02
	.long 0xd700010b                                           // 0000000CAA50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000CAA54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000CAA58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000CAA5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000CAA64: 8205050F
	.long 0xd700010d                                           // 0000000CAA68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000CAA6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAA70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000CAA74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000CAA7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000CAA80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000CAA88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000CAA90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000CAA94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAA9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000CAAA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000CAAA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000CAAAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000CAAB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000CAABC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000CAAC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAAC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000CAACC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000CAAD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000CAAD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000CAAE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000CAAE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000CAAEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CAAF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000CAAF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000CAB00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000CAB04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000CAB0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000CAB14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000CAB18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000CAB20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000CAB24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000CAB2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000CAB34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000CAB3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000CAB44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000CAB4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000CAB54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000CAB5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000CAB64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000CAB6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000CAB74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000CAB7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000CAB84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000CAB8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000CAB94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000CAB9C: BE850080
	s_mov_b32 s6, 0x43800000                                   // 0000000CABA0: BE8600FF 43800000
	s_mov_b32 s7, 0x3b800000                                   // 0000000CABA8: BE8700FF 3B800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000CABB0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000CABB4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000CABBC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000CABC0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000CABC4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000CABC8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000CABCC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000CABD0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000CABD4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000CABD8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000CABDC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000CABE4: BE84206A
	s_cbranch_execz 77                                         // 0000000CABE8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000CABEC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CABF0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000CABF4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000CABFC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC00: BF870091
	.long 0xd73c001d                                           // 0000000CAC04: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000CAC08: 02023A82
	.long 0xd700011d                                           // 0000000CAC0C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000CAC10: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CAC14: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000CAC18: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000CAC20: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CAC28: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000CAC2C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000CAC30: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000CAC3C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000CAC40: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000CAC4C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000CAC50: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000CAC5C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CAC60: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000CAC64: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000CAC70: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CAC74: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000CAC78: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000CAC80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000CAC84: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000CAC8C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000CAC94: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000CAC98: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CAC9C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000CACA0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000CACA4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CACA8: BF870296
	.long 0xd71c0020                                           // 0000000CACAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000CACB0: 02024520
	.long 0xd71c001f                                           // 0000000CACB4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000CACB8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CACBC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000CACC0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000CACC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000CACCC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000CACD4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000CACDC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000CACE0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CACE8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000CACEC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000CACF8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000CACFC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000CAD04: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000CAD10: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000CAD18: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CAD20: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000CAD24: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000CAD2C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CAD30: BF89FC07
	s_barrier                                                  // 0000000CAD34: BFBD0000
	buffer_gl0_inv                                             // 0000000CAD38: E0AC0000 00000000
	s_branch 15                                                // 0000000CAD40: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CAD44: 8C7E047E
	.long 0xd700011d                                           // 0000000CAD48: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000CAD4C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CAD54: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CAD58: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000CAD60: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000CAD64: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000CAD68: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000CAD6C: BF89FC07
	s_barrier                                                  // 0000000CAD70: BFBD0000
	buffer_gl0_inv                                             // 0000000CAD74: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000CAD7C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000CAD80: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000CAD88: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000CAD90: BE8D0080
	s_nop 0                                                    // 0000000CAD94: BF800000
	s_nop 0                                                    // 0000000CAD98: BF800000
	s_nop 0                                                    // 0000000CAD9C: BF800000
	s_nop 0                                                    // 0000000CADA0: BF800000
	s_nop 0                                                    // 0000000CADA4: BF800000
	s_nop 0                                                    // 0000000CADA8: BF800000
	s_nop 0                                                    // 0000000CADAC: BF800000
	s_nop 0                                                    // 0000000CADB0: BF800000
	s_nop 0                                                    // 0000000CADB4: BF800000
	s_nop 0                                                    // 0000000CADB8: BF800000
	s_nop 0                                                    // 0000000CADBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000CADC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000CADC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000CADD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000CADD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CADDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000CADE0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000CADE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000CADEC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000CADF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000CADF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000CADFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000CAE04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000CAE0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000CAE10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CAE14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CAE18: BF89FC07
	s_barrier                                                  // 0000000CAE1C: BFBD0000
	buffer_gl0_inv                                             // 0000000CAE20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000CAE28: BE842000
	s_cbranch_execz 65477                                      // 0000000CAE2C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000CAE30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000CAE38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000CAE40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000CAE48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000CAE50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000CAE58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000CAE60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000CAE68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000CAE70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000CAE78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000CAE80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000CAE88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000CAE90: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000CAE98: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAEA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000CAEA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000CAEAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000CAEB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAEB4: BF870091
	.long 0xd7000146                                           // 0000000CAEB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000CAEBC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000CAEC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000CAEC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000CAED0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000CAED4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAEDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000CAEE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000CAEE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000CAEEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000CAEF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000CAEFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000CAF04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000CAF0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000CAF14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000CAF1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000CAF24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000CAF2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000CAF34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000CAF3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000CAF44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000CAF4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000CAF54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000CAF5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CAF60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CAF64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000CAF6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000CAF74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000CAF7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000CAF84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000CAF8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000CAF94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000CAF9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000CAFA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CAFAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000CAFB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAFB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000CAFBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000CAFC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAFCC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000CAFD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000CAFD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000CAFE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAFE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000CAFE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000CAFF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000CAFF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CAFFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000CB000: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000CB008: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000CB010: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000CB018: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000CB020: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000CB028: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000CB030: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000CB038: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000CB040: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000CB048: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000CB050: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB054: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000CB058: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000CB060: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000CB068: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB06C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB070: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB078: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB080: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB084: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000CB088: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000CB090: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000CB098: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB09C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB0A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000CB0A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000CB0B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000CB0B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000CB0C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000CB0C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000CB0D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000CB0D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000CB0E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB0E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB0F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB0F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB0F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB100: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB108: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB10C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000CB110: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000CB118: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000CB120: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB124: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000CB128: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000CB130: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000CB138: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB13C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000CB140: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000CB148: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000CB150: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000CB158: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000CB160: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000CB168: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000CB170: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000CB178: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000CB180: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000CB188: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB190: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB194: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB198: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB1A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB1A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB1B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB1B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB1C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000CB1C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000CB1D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB1D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB1DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB1E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000CB1E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000CB1F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000CB1F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000CB200: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000CB208: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000CB210: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000CB218: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000CB220: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB228: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB230: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB234: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB238: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB240: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB248: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB24C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CB250: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CB258: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CB260: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB264: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CB268: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB270: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB278: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB27C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CB280: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000CB288: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000CB290: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000CB298: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000CB2A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000CB2A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000CB2B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000CB2B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000CB2C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CB2C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB2D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB2D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB2E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB2E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB2F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB2F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB300: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB304: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CB308: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB310: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB318: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB31C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB320: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000CB328: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000CB330: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000CB338: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000CB340: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000CB348: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000CB350: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000CB358: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000CB360: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB368: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB370: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB374: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB378: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB380: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB388: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB38C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CB390: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CB398: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CB3A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CB3A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB3B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB3B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB3BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CB3C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000CB3C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000CB3D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000CB3D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000CB3E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000CB3E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000CB3F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000CB3F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000CB400: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CB408: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB410: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB414: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB418: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB420: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB428: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB42C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB430: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB438: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB440: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB444: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CB448: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB450: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB458: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB45C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB460: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000CB468: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000CB470: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000CB478: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000CB480: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000CB488: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000CB490: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000CB498: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000CB4A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB4A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB4B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB4B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB4C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB4C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CB4D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CB4D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CB4E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CB4E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB4F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB4F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB4FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CB500: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000CB508: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000CB510: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000CB518: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000CB520: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000CB528: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000CB530: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000CB538: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000CB540: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CB548: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB550: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB554: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB558: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB560: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB568: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB56C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB570: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB578: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB580: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB584: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CB588: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB590: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB598: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB59C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB5A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000CB5A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000CB5B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000CB5B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000CB5C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000CB5C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000CB5D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000CB5D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000CB5E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB5E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB5F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB5F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB5F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB600: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB608: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB60C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CB610: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CB618: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CB620: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB624: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CB628: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB630: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB638: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB63C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CB640: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000CB648: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000CB650: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000CB658: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000CB660: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000CB668: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000CB670: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000CB678: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000CB680: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CB688: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB690: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB694: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB698: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB6A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB6A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB6AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB6B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB6B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB6C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB6C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CB6C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB6D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB6D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB6DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CB6E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000CB6E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000CB6F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000CB6F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000CB700: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000CB708: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000CB710: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000CB718: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000CB720: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CB728: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CB730: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB734: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CB738: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CB740: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CB748: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB74C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CB750: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CB758: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CB760: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB764: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CB768: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB770: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB778: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB77C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CB780: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000CB788: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000CB790: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000CB798: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000CB7A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000CB7A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000CB7B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000CB7B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000CB7C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CB7C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CB7D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB7D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000CB7D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000CB7E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000CB7E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB7EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CB7F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CB7F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CB800: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB804: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CB808: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CB810: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CB818: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB81C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000CB820: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000CB828: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000CB830: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB834: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000CB838: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000CB840: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000CB848: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB84C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000CB850: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000CB858: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000CB864: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000CB86C: D8340000 0000201F
	s_branch 64819                                             // 0000000CB874: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000CB878: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000CB87C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000CB884: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000CB888: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000CB88C: BE8C0080
	s_branch 21                                                // 0000000CB890: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CB894: 8C7E0D7E
	.long 0xd700011f                                           // 0000000CB898: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000CB89C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB8A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000CB8A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000CB8B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000CB8B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000CB8BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CB8C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000CB8C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000CB8CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000CB8D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000CB8D4: BC7C0000
	s_barrier                                                  // 0000000CB8D8: BFBD0000
	buffer_gl0_inv                                             // 0000000CB8DC: E0AC0000 00000000
	s_cbranch_scc1 609                                         // 0000000CB8E4: BFA20261 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CB8E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000CB8EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000CB8F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000CB8F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000CB8FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000CB900: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000CB908: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000CB910: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000CB914: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CB91C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000CB920: D5207C22 00064480
	.long 0xd4490004                                           // 0000000CB928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000CB92C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000CB934: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000CB938: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000CB93C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000CB944: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000CB94C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000CB950: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CB954: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CB958: BF89FC07
	s_barrier                                                  // 0000000CB95C: BFBD0000
	buffer_gl0_inv                                             // 0000000CB960: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000CB968: BE8D2000
	s_cbranch_execz 65481                                      // 0000000CB96C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000CB970: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB974: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000CB978: 3848420B
	.long 0xd4440001                                           // 0000000CB97C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000CB980: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000CB984: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000CB988: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000CB98C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000CB994: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000CB99C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000CB9A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000CB9AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000CB9B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000CB9BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000CB9C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000CB9CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000CB9D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000CB9D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CB9DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CB9E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CB9E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CB9E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CB9EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CB9F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CB9F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CB9F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CB9FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBA00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBA04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBA08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBA0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBA10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000CBA14: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000CBA1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000CBA24: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000CBA2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000CBA34: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000CBA3C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000CBA44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000CBA4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000CBA54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBA58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBA5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBA60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBA64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBA68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBA6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBA70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBA74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBA78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBA7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBA80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBA84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBA88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBA8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBA90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000CBA94: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000CBA9C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000CBAA4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000CBAAC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000CBAB4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000CBABC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000CBAC4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000CBACC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000CBAD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBAD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBAE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBAE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBAE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBAEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBAF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBAF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBAF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBAFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBB00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBB04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBB08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBB0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBB10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000CBB14: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000CBB1C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000CBB24: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000CBB2C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000CBB34: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000CBB3C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000CBB44: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000CBB4C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000CBB54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBB58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBB5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBB60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBB64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBB68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBB6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBB70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBB74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBB78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBB7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBB80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBB84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBB88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBB8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBB90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000CBB94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000CBB9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000CBBA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000CBBAC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000CBBB4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000CBBBC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000CBBC4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000CBBCC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000CBBD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBBD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBBDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBBE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBBE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBBE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBBEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBBF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBBF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBBF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBBFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBC00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBC04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBC08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBC0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBC10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000CBC14: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000CBC1C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000CBC24: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000CBC2C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000CBC34: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000CBC3C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000CBC44: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000CBC4C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000CBC54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBC58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBC5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBC60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBC64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBC68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBC6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBC70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBC74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBC78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBC7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBC80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBC84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBC88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBC8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBC90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000CBC94: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000CBC9C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000CBCA4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000CBCAC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000CBCB4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000CBCBC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000CBCC4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000CBCCC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000CBCD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBCD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBCDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBCE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBCE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBCE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBCEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBCF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBCF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBCF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBCFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBD00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBD04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBD08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBD0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBD10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000CBD14: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000CBD1C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000CBD24: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000CBD2C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000CBD34: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000CBD3C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000CBD44: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000CBD4C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000CBD54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBD58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBD5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBD60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBD64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBD68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBD6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBD70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBD74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBD78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBD7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBD80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBD84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBD88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBD8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBD90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000CBD94: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000CBD9C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000CBDA4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000CBDAC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000CBDB4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000CBDBC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000CBDC4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000CBDCC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000CBDD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBDD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBDDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBDE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBDE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBDE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBDEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBDF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBDF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBDF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBDFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBE00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBE04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBE08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBE0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBE10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000CBE14: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000CBE1C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000CBE24: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000CBE2C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000CBE34: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000CBE3C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000CBE44: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000CBE4C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000CBE54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBE58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBE5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBE60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBE64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBE68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBE6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBE70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBE74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBE78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBE7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBE80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBE84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBE88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBE8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBE90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000CBE94: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000CBE9C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000CBEA4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000CBEAC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000CBEB4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000CBEBC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000CBEC4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000CBECC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000CBED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBEDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBEE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBEE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBEE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBEEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBEF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBEF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBEF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBEFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBF00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBF04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBF08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBF0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBF10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000CBF14: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000CBF1C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000CBF24: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000CBF2C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000CBF34: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000CBF3C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000CBF44: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000CBF4C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000CBF54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBF58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBF5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBF60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBF64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBF68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBF6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBF70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBF74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBF78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBF7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CBF80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CBF84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CBF88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBF8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CBF90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000CBF94: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000CBF9C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000CBFA4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000CBFAC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000CBFB4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000CBFBC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000CBFC4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000CBFCC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000CBFD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CBFD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBFDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CBFE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CBFE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CBFE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBFEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CBFF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CBFF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CBFF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBFFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CC000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CC004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CC008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC00C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CC010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000CC014: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000CC01C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000CC024: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000CC02C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000CC034: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000CC03C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000CC044: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000CC04C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000CC054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CC058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC05C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CC060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CC064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CC068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC06C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CC070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CC074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CC078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC07C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CC080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CC084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CC088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC08C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CC090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000CC094: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000CC09C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000CC0A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000CC0AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000CC0B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000CC0BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000CC0C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000CC0CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000CC0D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CC0D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC0DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CC0E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CC0E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CC0E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC0EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CC0F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CC0F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CC0F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC0FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CC100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CC104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CC108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC10C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CC110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000CC114: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000CC11C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000CC124: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000CC12C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000CC134: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000CC13C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000CC144: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000CC14C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000CC154: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000CC158: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CC15C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000CC160: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000CC168: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000CC170: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CC174: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000CC178: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000CC17C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC180: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CC184: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CC188: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000CC18C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC190: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CC194: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CC198: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000CC19C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC1A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CC1A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CC1A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000CC1AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC1B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000CC1B4: 1078794C
	s_nop 0                                                    // 0000000CC1B8: BF800000
	s_nop 0                                                    // 0000000CC1BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000CC1C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000CC1C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000CC1D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000CC1D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000CC1D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CC1DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000CC1E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000CC1E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000CC1EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000CC1F0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000CC1F8: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000CC1FC: BF89FC07
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000CC200: CC210040 02000D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000CC208: BF8700B1
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CC20C: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000CC214: BF8903F7
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000CC218: CC21003F 02000D3F
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CC220: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC228: BF870001
	v_fmac_f32_e32 v60, v63, v64                               // 0000000CC22C: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000CC230: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000CC234: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000CC238: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC23C: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000CC240: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000CC248: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000CC254: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000CC260: DC960000 007C2421
	s_branch 64906                                             // 0000000CC268: BFA0FD8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000CC26C: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000CC274: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000CC278: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000CC27C: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000CC284: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000CC288: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000CC290: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000CC298: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000CC29C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000CC2A0: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000CC2A8: A0010401
	s_mov_b32 s4, 0                                            // 0000000CC2AC: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000CC2B0: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000CC2B4: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000CC2B8: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000CC2BC: BF870585
	.long 0xd71c001d                                           // 0000000CC2C0: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000CC2C4: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000CC2C8: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000CC2CC: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000CC2D4: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000CC2D8: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000CC2E0: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000CC2E4: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000CC2E8: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000CC2F4: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000CC2FC: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC304: BF870001
	.long 0xd4490001                                           // 0000000CC308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000CC30C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000CC314: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000CC318: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000CC31C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000CC320: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000CC328: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CC330: 917E047E
	s_cbranch_execnz 65519                                     // 0000000CC334: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1af4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CC338: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000CC33C: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000CC344: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000CC34C: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CC350: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CC354: BF89FC07
	s_barrier                                                  // 0000000CC358: BFBD0000
	buffer_gl0_inv                                             // 0000000CC35C: E0AC0000 00000000
	s_nop 0                                                    // 0000000CC364: BF800000
	s_nop 0                                                    // 0000000CC368: BF800000
	s_nop 0                                                    // 0000000CC36C: BF800000
	s_nop 0                                                    // 0000000CC370: BF800000
	s_nop 0                                                    // 0000000CC374: BF800000
	s_nop 0                                                    // 0000000CC378: BF800000
	s_nop 0                                                    // 0000000CC37C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CC380: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000CC388: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CC390: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CC398: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CC39C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000CC3A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CC3A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CC3B0: BF870004
	.long 0xd4490004                                           // 0000000CC3B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CC3B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CC3C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CC3C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CC3C8: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000CC3CC: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000CC3D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CC3DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CC3E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CC3E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CC3E8: BF89FC07
	s_barrier                                                  // 0000000CC3EC: BFBD0000
	buffer_gl0_inv                                             // 0000000CC3F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000CC3F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000CC400: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000CC408: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000CC410: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000CC418: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CC41C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CC420: BF840001
	s_nop 0                                                    // 0000000CC424: BF800000
	s_nop 0                                                    // 0000000CC428: BF800000
	s_nop 0                                                    // 0000000CC42C: BF800000
	s_nop 0                                                    // 0000000CC430: BF800000
	s_nop 0                                                    // 0000000CC434: BF800000
	s_nop 0                                                    // 0000000CC438: BF800000
	s_nop 0                                                    // 0000000CC43C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC440: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000CC444: 327A7884
	.long 0xd4490001                                           // 0000000CC448: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CC44C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000CC454: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000CC458: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CC464: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000CC468: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CC470: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CC478: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000CC480: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CC488: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CC490: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CC498: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CC4A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000CC4A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CC4B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000CC4B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000CC4B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000CC4C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CC4C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CC4C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000CC4CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CC4D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000CC4D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000CC4DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000CC4E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000CC4F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000CC4F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CC500: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CC504: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_set_inst_prefetch_distance 0x2                           // 0000000CC508: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CC50C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000CC510: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CC518: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CC520: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CC524: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CC528: BF89FC07
	s_barrier                                                  // 0000000CC52C: BFBD0000
	buffer_gl0_inv                                             // 0000000CC530: E0AC0000 00000000
	s_nop 0                                                    // 0000000CC538: BF800000
	s_nop 0                                                    // 0000000CC53C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CC540: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000CC548: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CC550: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CC558: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CC55C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CC564: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CC568: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CC570: BF870004
	.long 0xd4490004                                           // 0000000CC574: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CC578: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CC580: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CC584: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CC588: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CC58C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CC594: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CC59C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CC5A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CC5A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CC5A8: BF89FC07
	s_barrier                                                  // 0000000CC5AC: BFBD0000
	buffer_gl0_inv                                             // 0000000CC5B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000CC5B8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000CC5C0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000CC5C8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000CC5D0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000CC5D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CC5DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CC5E0: BF840001
	s_nop 0                                                    // 0000000CC5E4: BF800000
	s_nop 0                                                    // 0000000CC5E8: BF800000
	s_nop 0                                                    // 0000000CC5EC: BF800000
	s_nop 0                                                    // 0000000CC5F0: BF800000
	s_nop 0                                                    // 0000000CC5F4: BF800000
	s_nop 0                                                    // 0000000CC5F8: BF800000
	s_nop 0                                                    // 0000000CC5FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC600: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000CC604: 327A7884
	.long 0xd4490001                                           // 0000000CC608: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CC60C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000CC614: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000CC618: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CC624: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000CC628: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CC630: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CC638: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000CC640: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CC648: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CC650: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CC658: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CC660: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000CC664: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CC670: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000CC674: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000CC678: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000CC680: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CC684: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CC688: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000CC68C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC690: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CC694: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000CC698: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000CC69C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC6A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000CC6A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000CC6B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000CC6B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CC6C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CC6C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_set_inst_prefetch_distance 0x2                           // 0000000CC6C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CC6CC: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000CC6D0: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CC6D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CC6E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CC6E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CC6E8: BF89FC07
	s_barrier                                                  // 0000000CC6EC: BFBD0000
	buffer_gl0_inv                                             // 0000000CC6F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000CC6F8: BF800000
	s_nop 0                                                    // 0000000CC6FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CC700: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000CC708: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CC710: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CC718: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CC71C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CC724: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CC728: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CC730: BF870004
	.long 0xd4490004                                           // 0000000CC734: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CC738: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CC740: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CC744: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CC748: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CC74C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CC754: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CC75C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CC760: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CC764: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000CC768: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000CC770: BF89FC07
	s_barrier                                                  // 0000000CC774: BFBD0000
	buffer_gl0_inv                                             // 0000000CC778: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000CC780: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000CC784: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000CC78C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000CC794: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000CC79C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000CC7A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CC7A8: BF840001
	s_nop 0                                                    // 0000000CC7AC: BF800000
	s_nop 0                                                    // 0000000CC7B0: BF800000
	s_nop 0                                                    // 0000000CC7B4: BF800000
	s_nop 0                                                    // 0000000CC7B8: BF800000
	s_nop 0                                                    // 0000000CC7BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000CC7C0: 327C7A84
	.long 0xd4490001                                           // 0000000CC7C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CC7C8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CC7D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CC7D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CC7D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CC7E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CC7E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CC7F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CC7F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CC800: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CC808: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CC810: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CC818: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CC820: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CC824: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CC828: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CC82C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CC838: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CC840: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CC844: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CC848: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CC84C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC850: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CC854: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CC858: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CC85C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC860: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000CC864: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000CC870: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000CC878: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CC880: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CC884: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000CC888: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CC88C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000CC890: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CC898: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CC8A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CC8A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CC8A8: BF89FC07
	s_barrier                                                  // 0000000CC8AC: BFBD0000
	buffer_gl0_inv                                             // 0000000CC8B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000CC8B8: BF800000
	s_nop 0                                                    // 0000000CC8BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CC8C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000CC8C8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CC8D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CC8D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CC8DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CC8E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CC8E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CC8F0: BF870004
	.long 0xd4490004                                           // 0000000CC8F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CC8F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CC900: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CC904: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CC908: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CC90C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CC914: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CC91C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CC920: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CC924: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000CC928: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000CC930: BF89FC07
	s_barrier                                                  // 0000000CC934: BFBD0000
	buffer_gl0_inv                                             // 0000000CC938: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000CC940: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000CC948: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000CC950: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000CC958: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000CC960: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CC964: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CC968: BF840001
	s_nop 0                                                    // 0000000CC96C: BF800000
	s_nop 0                                                    // 0000000CC970: BF800000
	s_nop 0                                                    // 0000000CC974: BF800000
	s_nop 0                                                    // 0000000CC978: BF800000
	s_nop 0                                                    // 0000000CC97C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC980: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000CC984: 327A7884
	.long 0xd4490001                                           // 0000000CC988: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CC98C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000CC994: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000CC998: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CC9A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000CC9A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CC9B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CC9B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000CC9C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CC9C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CC9D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CC9D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CC9E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000CC9E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CC9F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000CC9F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000CC9F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000CCA00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CCA04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CCA08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000CCA0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CCA14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000CCA18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000CCA1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000CCA24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000CCA30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000CCA38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CCA40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CCA44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_set_inst_prefetch_distance 0x2                           // 0000000CCA48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CCA4C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000CCA50: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CCA58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CCA60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CCA64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CCA68: BF89FC07
	s_barrier                                                  // 0000000CCA6C: BFBD0000
	buffer_gl0_inv                                             // 0000000CCA70: E0AC0000 00000000
	s_nop 0                                                    // 0000000CCA78: BF800000
	s_nop 0                                                    // 0000000CCA7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CCA80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000CCA88: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CCA90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CCA98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CCA9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CCAA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CCAA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CCAB0: BF870004
	.long 0xd4490004                                           // 0000000CCAB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CCAB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CCAC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CCAC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CCAC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CCACC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CCAD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CCADC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CCAE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CCAE4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000CCAE8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000CCAF0: BF89FC07
	s_barrier                                                  // 0000000CCAF4: BFBD0000
	buffer_gl0_inv                                             // 0000000CCAF8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000CCB00: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000CCB04: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000CCB0C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000CCB14: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000CCB1C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000CCB24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CCB28: BF840001
	s_nop 0                                                    // 0000000CCB2C: BF800000
	s_nop 0                                                    // 0000000CCB30: BF800000
	s_nop 0                                                    // 0000000CCB34: BF800000
	s_nop 0                                                    // 0000000CCB38: BF800000
	s_nop 0                                                    // 0000000CCB3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000CCB40: 327C7884
	.long 0xd4490001                                           // 0000000CCB44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CCB48: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CCB50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CCB54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CCB58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CCB64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CCB68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CCB70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CCB78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CCB80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CCB88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CCB90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CCB98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CCBA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CCBA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CCBA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CCBAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CCBB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CCBC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CCBC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CCBC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CCBCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCBD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CCBD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CCBD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CCBDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCBE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000CCBE4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000CCBF0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CCBF4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000CCBF8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000CCBFC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CCC04: 917E047E
	s_cbranch_execnz 65485                                     // 0000000CCC08: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 0000000CCC0C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CCC10: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000CCC14: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CCC1C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CCC24: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CCC28: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CCC2C: BF89FC07
	s_barrier                                                  // 0000000CCC30: BFBD0000
	buffer_gl0_inv                                             // 0000000CCC34: E0AC0000 00000000
	s_nop 0                                                    // 0000000CCC3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CCC40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000CCC48: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CCC50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CCC58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CCC5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CCC64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CCC68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CCC70: BF870004
	.long 0xd4490004                                           // 0000000CCC74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CCC78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CCC80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CCC84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CCC88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CCC8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CCC94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CCC9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CCCA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CCCA4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000CCCA8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000CCCB0: BF89FC07
	s_barrier                                                  // 0000000CCCB4: BFBD0000
	buffer_gl0_inv                                             // 0000000CCCB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000CCCC0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000CCCC8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000CCCD0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000CCCD8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000CCCE0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000CCCE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CCCE8: BF840001
	s_nop 0                                                    // 0000000CCCEC: BF800000
	s_nop 0                                                    // 0000000CCCF0: BF800000
	s_nop 0                                                    // 0000000CCCF4: BF800000
	s_nop 0                                                    // 0000000CCCF8: BF800000
	s_nop 0                                                    // 0000000CCCFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCD00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000CCD04: 327C7A84
	.long 0xd4490001                                           // 0000000CCD08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CCD0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CCD14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CCD18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CCD24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CCD28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CCD30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CCD38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CCD40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CCD48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CCD50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CCD58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CCD60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CCD64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CCD68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CCD6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CCD78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CCD80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CCD84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CCD88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CCD8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCD90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CCD94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CCD98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CCD9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000CCDA4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000CCDB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000CCDB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CCDC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CCDC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_set_inst_prefetch_distance 0x2                           // 0000000CCDC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CCDCC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000CCDD0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CCDD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CCDE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CCDE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CCDE8: BF89FC07
	s_barrier                                                  // 0000000CCDEC: BFBD0000
	buffer_gl0_inv                                             // 0000000CCDF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000CCDF8: BF800000
	s_nop 0                                                    // 0000000CCDFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CCE00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000CCE08: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CCE10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CCE18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CCE1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CCE24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CCE28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CCE30: BF870004
	.long 0xd4490004                                           // 0000000CCE34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CCE38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CCE40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CCE44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CCE48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CCE4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CCE54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CCE5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CCE60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CCE64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CCE68: BF89FC07
	s_barrier                                                  // 0000000CCE6C: BFBD0000
	buffer_gl0_inv                                             // 0000000CCE70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000CCE78: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000CCE80: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000CCE88: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000CCE90: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000CCE98: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000CCE9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CCEA0: BF840001
	s_nop 0                                                    // 0000000CCEA4: BF800000
	s_nop 0                                                    // 0000000CCEA8: BF800000
	s_nop 0                                                    // 0000000CCEAC: BF800000
	s_nop 0                                                    // 0000000CCEB0: BF800000
	s_nop 0                                                    // 0000000CCEB4: BF800000
	s_nop 0                                                    // 0000000CCEB8: BF800000
	s_nop 0                                                    // 0000000CCEBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCEC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000CCEC4: 327C7A84
	.long 0xd4490001                                           // 0000000CCEC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CCECC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CCED4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CCED8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CCEE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CCEE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CCEF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CCEF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CCF00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CCF08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CCF10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CCF18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CCF20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CCF24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CCF28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CCF2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CCF38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CCF40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CCF44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CCF48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CCF4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCF50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CCF54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CCF58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CCF5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCF60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000CCF64: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000CCF70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000CCF78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CCF80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CCF84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000CCF88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CCF8C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000CCF90: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CCF98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CCFA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CCFA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CCFA8: BF89FC07
	s_barrier                                                  // 0000000CCFAC: BFBD0000
	buffer_gl0_inv                                             // 0000000CCFB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000CCFB8: BF800000
	s_nop 0                                                    // 0000000CCFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CCFC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000CCFC8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CCFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CCFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CCFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CCFE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CCFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CCFF0: BF870004
	.long 0xd4490004                                           // 0000000CCFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CCFF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CD000: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CD004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CD008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CD00C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CD014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CD01C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CD020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CD024: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000CD028: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000CD030: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000CD038: BF89FC07
	s_barrier                                                  // 0000000CD03C: BFBD0000
	buffer_gl0_inv                                             // 0000000CD040: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000CD048: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000CD050: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000CD058: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000CD060: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000CD068: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CD06C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CD070: BF840001
	s_nop 0                                                    // 0000000CD074: BF800000
	s_nop 0                                                    // 0000000CD078: BF800000
	s_nop 0                                                    // 0000000CD07C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD080: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000CD084: 327A7884
	.long 0xd4490001                                           // 0000000CD088: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CD08C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000CD094: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000CD098: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CD0A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000CD0A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CD0B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CD0B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000CD0C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CD0C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CD0D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CD0D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CD0E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000CD0E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CD0F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000CD0F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000CD0F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000CD100: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CD104: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CD108: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000CD10C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD110: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CD114: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000CD118: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000CD11C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD120: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000CD124: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000CD130: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000CD138: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CD140: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CD144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2880>
	s_set_inst_prefetch_distance 0x2                           // 0000000CD148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CD14C: 8C7E047E
	.long 0xd7000107                                           // 0000000CD150: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000CD154: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD15C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000CD160: D5207C08 00061080
	.long 0xd7000109                                           // 0000000CD168: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000CD16C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000CD174: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000CD17C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000CD180: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD188: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000CD18C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000CD194: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000CD198: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000CD1A0: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000CD1A8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000CD1AC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD1B4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000CD1B8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000CD1C0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000CD1C4: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000CD1CC: D5207C12 00062480
	.long 0xd7000113                                           // 0000000CD1D4: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000CD1D8: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD1E0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000CD1E4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000CD1EC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000CD1F0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000CD1F8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000CD200: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000CD204: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD20C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000CD210: D5207C18 00063080
	.long 0xd7000119                                           // 0000000CD218: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000CD21C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000CD224: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000CD22C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000CD230: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD238: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000CD23C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000CD244: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000CD248: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000CD24C: BF062105
	s_barrier                                                  // 0000000CD250: BFBD0000
	buffer_gl0_inv                                             // 0000000CD254: E0AC0000 00000000
	s_cbranch_scc0 63061                                       // 0000000CD25C: BFA1F655 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000CD260: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000CD264: 8000141C
	.long 0xd73c0000                                           // 0000000CD268: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000CD26C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000CD270: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000CD274: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000CD278: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000CD27C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000CD280: 82010103
	.long 0xd7006a00                                           // 0000000CD284: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000CD288: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000CD28C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000CD290: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000CD298: BE810080
	.long 0xd7006a00                                           // 0000000CD29C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000CD2A0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000CD2A4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD2AC: BF870092
	.long 0xd7006a00                                           // 0000000CD2B0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000CD2B4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000CD2B8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000CD2C0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000CD2C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000CD2D0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000CD2D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000CD2DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000CD2E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000CD2E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000CD2EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000CD2F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000CD2F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000CD300: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000CD308: 917E017E
	s_cbranch_execnz 65516                                     // 0000000CD30C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_endpgm                                                   // 0000000CD310: BFB00000
		...

