000000000016b700 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000016B700: BF850001
	s_load_b256 s[12:19], s[0:1], 0x30                         // 00000016B704: F40C0300 F8000030
	s_load_b64 s[6:7], s[0:1], 0x50                            // 00000016B70C: F4040180 F8000050
	s_lshl_b32 s4, s3, 6                                       // 00000016B714: 84048603
	s_ashr_i32 s3, s2, 31                                      // 00000016B718: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 00000016B71C: 86059F04
	v_and_b32_e32 v96, 63, v0                                  // 00000016B720: 36C000BF
	s_movk_i32 s9, 0x210                                       // 00000016B724: B0090210
	v_mov_b32_e32 v4, v0                                       // 00000016B728: 7E080300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000016B72C: BF8704D2
	v_lshlrev_b32_e32 v2, 2, v96                               // 00000016B730: 3004C082
	v_mad_u32_u24 v1, v96, s9, 0x3200                          // 00000016B734: D60B0001 03FC1360 00003200
	s_waitcnt lgkmcnt(0)                                       // 00000016B740: BF89FC07
	s_load_b32 s8, s[16:17], null                              // 00000016B744: F4000208 F8000000
	s_lshl_b64 s[34:35], s[18:19], 2                           // 00000016B74C: 84A28212
	s_add_u32 s10, s14, s34                                    // 00000016B750: 800A220E
	s_addc_u32 s11, s15, s35                                   // 00000016B754: 820B230F
	s_lshl_b64 s[36:37], s[2:3], 16                            // 00000016B758: 84A49002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016B75C: BF870009
	s_add_u32 s10, s10, s36                                    // 00000016B760: 800A240A
	s_addc_u32 s11, s11, s37                                   // 00000016B764: 820B250B
	s_waitcnt lgkmcnt(0)                                       // 00000016B768: BF89FC07
	s_mul_i32 s33, s8, 0x9000000                               // 00000016B76C: 9621FF08 09000000
	s_mul_hi_i32 s40, s8, 0x9000000                            // 00000016B774: 9728FF08 09000000
	s_add_u32 s8, s10, s33                                     // 00000016B77C: 8008210A
	s_addc_u32 s10, s11, s40                                   // 00000016B780: 820A280B
	s_lshl_b64 s[38:39], s[4:5], 2                             // 00000016B784: 84A68204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000016B788: BF8700B9
	s_add_u32 s8, s8, s38                                      // 00000016B78C: 80082608
	s_addc_u32 s9, s10, s39                                    // 00000016B790: 8209270A
	.long 0xd7000802                                           // 00000016B794: D7000802
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000016B798: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, 0, s8                    // 00000016B79C: D5207C03 00210009
	s_mov_b32 s8, 0                                            // 00000016B7A4: BE880080
	s_nop 0                                                    // 00000016B7A8: BF800000
	s_nop 0                                                    // 00000016B7AC: BF800000
	s_nop 0                                                    // 00000016B7B0: BF800000
	s_nop 0                                                    // 00000016B7B4: BF800000
	s_nop 0                                                    // 00000016B7B8: BF800000
	s_nop 0                                                    // 00000016B7BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 00000016B7C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B7C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 00000016B7C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 00000016B7CC: D6460007 04050507
	.long 0xd7006a05                                           // 00000016B7D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 00000016B7D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000016B7DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 00000016B7E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 00000016B7E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 00000016B7F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 00000016B7F8: 4A0C08FF 00000080
	s_or_b32 s8, vcc_lo, s8                                    // 00000016B800: 8C08086A
	v_mov_b32_e32 v4, v6                                       // 00000016B804: 7E080306
	s_waitcnt vmcnt(0)                                         // 00000016B808: BF8903F7
	ds_store_b32 v7, v5                                        // 00000016B80C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000016B814: 917E087E
	s_cbranch_execnz 65513                                     // 00000016B818: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016B81C: 8C7E087E
	s_load_b32 s41, s[0:1], 0x58                               // 00000016B820: F4000A40 F8000058
	v_or_b32_e32 v97, 0xffffff80, v0                           // 00000016B828: 38C200FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 00000016B830: 32020086
	s_mov_b32 s8, 0                                            // 00000016B834: BE880080
	s_waitcnt lgkmcnt(0)                                       // 00000016B838: BF89FC07
	s_barrier                                                  // 00000016B83C: BFBD0000
	buffer_gl0_inv                                             // 00000016B840: E0AC0000 00000000
	s_cmp_gt_i32 s41, 0                                        // 00000016B848: BF028029
	s_cbranch_scc1 9                                           // 00000016B84C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v90, 6, v0                               // 00000016B850: 32B40086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 00000016B854: 380400FF FFFFFF80
	v_mov_b32_e32 v91, 0                                       // 00000016B85C: 7EB60280
	s_delay_alu instid0(VALU_DEP_3)                            // 00000016B860: BF870003
	v_mov_b32_e32 v3, v90                                      // 00000016B864: 7E06035A
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 00000016B868: 916A087E
	s_cbranch_vccz 1                                           // 00000016B86C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 5244                                              // 00000016B870: BFA0147C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5364>
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000016B874: 30060082
	s_mov_b32 s17, 0                                           // 00000016B878: BE910080
	v_add_nc_u32_e32 v5, 3, v0                                 // 00000016B87C: 4A0A0083
	s_mov_b32 s16, s17                                         // 00000016B880: BE900011
	s_mov_b32 s18, s17                                         // 00000016B884: BE920011
	v_or_b32_e32 v99, 0xb600, v3                               // 00000016B888: 38C606FF 0000B600
	s_mov_b32 s19, s17                                         // 00000016B890: BE930011
	s_mov_b32 s20, s17                                         // 00000016B894: BE940011
	s_mov_b32 s21, s17                                         // 00000016B898: BE950011
	s_mov_b32 s22, s17                                         // 00000016B89C: BE960011
	s_mov_b32 s23, s17                                         // 00000016B8A0: BE970011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000016B8A4: BF870259
	v_dual_mov_b32 v25, s23 :: v_dual_add_nc_u32 v100, 0xb700, v3// 00000016B8A8: CA200017 196406FF 0000B700
	v_add_nc_u32_e32 v3, 2, v0                                 // 00000016B8B4: 4A060082
	v_and_b32_e32 v4, 7, v0                                    // 00000016B8B8: 36080087
	v_and_b32_e32 v5, 7, v5                                    // 00000016B8BC: 360A0A87
	v_dual_mov_b32 v22, s20 :: v_dual_add_nc_u32 v7, -1, v0    // 00000016B8C0: CA200014 160600C1
	v_dual_mov_b32 v24, s22 :: v_dual_and_b32 v3, 7, v3        // 00000016B8C8: CA240016 18020687
	v_dual_mov_b32 v21, s19 :: v_dual_add_nc_u32 v8, 6, v0     // 00000016B8D0: CA200013 15080086
	v_cvt_f32_ubyte0_e32 v6, v4                                // 00000016B8D8: 7E0C2304
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000016B8DC: 7E0A2305
	v_xor_b32_e32 v4, 4, v4                                    // 00000016B8E0: 3A080884
	v_dual_mov_b32 v20, s18 :: v_dual_and_b32 v7, 7, v7        // 00000016B8E4: CA240012 14060E87
	v_and_b32_e32 v8, 7, v8                                    // 00000016B8EC: 36101087
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000016B8F0: 7E062303
	.long 0x7f0a1505                                           // 00000016B8F4: 7F0A1505
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000016B8F8: 7E082304
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000016B8FC: 7E0E2307
	v_cvt_f32_ubyte0_e32 v8, v8                                // 00000016B900: 7E102308
	v_cvt_f16_f32_e32 v5, v3                                   // 00000016B904: 7E0A1503
	s_clause 0x1                                               // 00000016B908: BF850001
	s_load_b128 s[28:31], s[0:1], 0x10                         // 00000016B90C: F4080700 F8000010
	s_load_b64 s[0:1], s[0:1], 0x20                            // 00000016B914: F4040000 F8000020
	v_cvt_f16_f32_e32 v3, v4                                   // 00000016B91C: 7E061504
	.long 0x7f081507                                           // 00000016B920: 7F081507
	v_cvt_f16_f32_e32 v4, v8                                   // 00000016B924: 7E081508
	.long 0xcc10400b                                           // 00000016B928: CC10400B
	v_mul_i32_i24_e32 v1, 0x3000, v5                           // 00000016B92C: 12020AFF 00003000
	v_dual_mov_b32 v23, s21 :: v_dual_add_nc_u32 v2, 1, v0     // 00000016B934: CA200015 17020081
	s_add_i32 s8, s41, 63                                      // 00000016B93C: 8108BF29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016B940: BF870113
	.long 0xcc10400d                                           // 00000016B944: CC10400D
	v_mul_i32_i24_e32 v1, 0x3000, v4                           // 00000016B948: 120208FF 00003000
	v_dual_mov_b32 v15, v11 :: v_dual_and_b32 v2, 7, v2        // 00000016B950: CA24010B 0F020487
	v_mov_b32_e32 v19, s17                                     // 00000016B958: 7E260211
	s_lshr_b32 s42, s8, 6                                      // 00000016B95C: 852A8608
	s_delay_alu instid0(VALU_DEP_3)                            // 00000016B960: BF870003
	v_mov_b32_e32 v17, v13                                     // 00000016B964: 7E22030D
	s_movk_i32 s8, 0x210                                       // 00000016B968: B0080210
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000016B96C: 7E042302
	s_add_i32 s43, s2, 0xbd0                                   // 00000016B970: 812BFF02 00000BD0
	v_lshrrev_b32_e32 v98, 5, v0                               // 00000016B978: 32C40085
	v_bfe_u32 v4, v0, 4, 1                                     // 00000016B97C: D6100004 02050900
	v_lshl_or_b32 v112, v96, 2, 0xb600                         // 00000016B984: D6560070 03FD0560 0000B600
	.long 0x7f041502                                           // 00000016B990: 7F041502
	v_cvt_f16_f32_e32 v2, v6                                   // 00000016B994: 7E041506
	v_add_nc_u32_e32 v6, 5, v0                                 // 00000016B998: 4A0C0085
	v_lshl_or_b32 v102, v98, 4, v4                             // 00000016B99C: D6560066 04110962
	v_mul_u32_u24_e32 v7, 0xa00, v98                           // 00000016B9A4: 160EC4FF 00000A00
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000016B9AC: 7C9800C0
	.long 0xcc10400a                                           // 00000016B9B0: CC10400A
	v_mul_i32_i24_e32 v1, 0x3000, v2                           // 00000016B9B4: 120204FF 00003000
	v_and_b32_e32 v6, 7, v6                                    // 00000016B9BC: 360C0C87
	v_lshlrev_b32_e32 v2, 8, v0                                // 00000016B9C0: 30040088
	v_mov_b32_e32 v18, s16                                     // 00000016B9C4: 7E240210
	v_lshl_or_b32 v111, v102, 2, 0xb700                        // 00000016B9C8: D656006F 03FD0566 0000B700
	v_mov_b32_e32 v14, v10                                     // 00000016B9D4: 7E1C030A
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000016B9D8: 7E0C2306
	v_and_b32_e32 v2, 0xf00, v2                                // 00000016B9DC: 360404FF 00000F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016B9E4: BF870112
	.long 0x7f061506                                           // 00000016B9E8: 7F061506
	v_lshl_or_b32 v5, v98, 12, v2                              // 00000016B9EC: D6560005 04091962
	v_mov_b32_e32 v2, 0                                        // 00000016B9F4: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000016B9F8: BF870223
	.long 0xcc10400c                                           // 00000016B9FC: CC10400C
	v_mul_i32_i24_e32 v1, 0x3000, v3                           // 00000016BA00: 120206FF 00003000
	v_and_b32_e32 v3, 15, v0                                   // 00000016BA08: 3606008F
	.long 0xd7000a67                                           // 00000016BA0C: D7000A67
	v_cndmask_b32_e32 v1, s12, v5, vcc_lo                      // 00000016BA10: 02020A0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016BA14: BF870193
	v_dual_mov_b32 v91, v2 :: v_dual_mov_b32 v16, v12          // 00000016BA18: CA100102 5B10010C
	v_mad_u32_u24 v101, v3, s8, 0x3200                         // 00000016BA20: D60B0065 03FC1103 00003200
	s_waitcnt lgkmcnt(0)                                       // 00000016BA2C: BF89FC07
	s_add_u32 s8, s0, s38                                      // 00000016BA30: 80082600
	s_addc_u32 s9, s1, s39                                     // 00000016BA34: 82092701
	s_lshl_b32 s0, s2, 7                                       // 00000016BA38: 84008702
	v_lshlrev_b32_e32 v6, 2, v3                                // 00000016BA3C: 300C0682
	s_ashr_i32 s1, s0, 31                                      // 00000016BA40: 86019F00
	v_mad_u32_u24 v5, 0x2100, v98, v101                        // 00000016BA44: D60B0005 0596C4FF 00002100
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000016BA50: 84808100
	v_mul_u32_u24_e32 v105, 0xa0, v3                           // 00000016BA54: 16D206FF 000000A0
	s_add_u32 s6, s6, s0                                       // 00000016BA5C: 80060006
	s_addc_u32 s7, s7, s1                                      // 00000016BA60: 82070107
	s_lshl_b64 s[0:1], s[4:5], 1                               // 00000016BA64: 84808104
	v_lshl_or_b32 v107, v4, 2, v5                              // 00000016BA68: D656006B 04150504
	s_add_u32 s4, s6, s0                                       // 00000016BA70: 80040006
	s_movk_i32 s0, 0x2800                                      // 00000016BA74: B0002800
	s_addc_u32 s5, s7, s1                                      // 00000016BA78: 82050107
	v_mad_u32_u24 v106, 0xa0, v3, s0                           // 00000016BA7C: D60B006A 000206FF 000000A0
	.long 0xd700006c                                           // 00000016BA88: D700006C
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 00000016BA8C: 02020C08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016BA90: BF870001
	v_add_co_ci_u32_e64 v109, null, s9, 0, s0                  // 00000016BA94: D5207C6D 00010009
	s_lshl_b64 s[0:1], s[2:3], 9                               // 00000016BA9C: 84808902
	v_lshlrev_b32_e32 v5, 1, v3                                // 00000016BAA0: 300A0681
	v_mad_u64_u32 v[3:4], null, 0x6000, v96, s[0:1]            // 00000016BAA4: D6FE7C03 0002C0FF 00006000
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 00000016BAB0: 160C02FF 000000A0
	v_add_co_ci_u32_e64 v104, null, s13, 0, s10                // 00000016BAB8: D5207C68 0029000D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BAC0: BF870094
	.long 0xd700005c                                           // 00000016BAC4: D700005C
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000016BAC8: 02020A04
	v_add_co_ci_u32_e64 v93, null, s5, 0, s0                   // 00000016BACC: D5207C5D 00010005
	v_lshl_or_b32 v3, v1, 2, v3                                // 00000016BAD4: D6560003 040D0501
	v_lshl_add_u32 v110, v102, 1, v105                         // 00000016BADC: D646006E 05A50366
	v_lshl_add_u32 v113, v96, 1, v6                            // 00000016BAE4: D6460071 04190360
	v_mov_b32_e32 v90, v1                                      // 00000016BAEC: 7EB40301
	v_add_nc_u32_e32 v114, v105, v7                            // 00000016BAF0: 4AE40F69
	.long 0xd700005e                                           // 00000016BAF4: D700005E
	v_cndmask_b32_e32 v1, s28, v3, vcc_lo                      // 00000016BAF8: 0202061C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016BAFC: BF870001
	v_add_co_ci_u32_e64 v95, null, s29, v4, s0                 // 00000016BB00: D5207C5F 0002081D
	s_mov_b32 s12, 0x41800000                                  // 00000016BB08: BE8C00FF 41800000
	s_mov_b32 s13, 0                                           // 00000016BB10: BE8D0080
	s_branch 13                                                // 00000016BB14: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x44c>
	.long 0xd700005e                                           // 00000016BB18: D700005E
	v_cndmask_b32_e32 v1, 0x180000, v94, vcc_lo                // 00000016BB1C: 0202BCFF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016BB24: BF870001
	v_add_co_ci_u32_e64 v95, null, 0, v95, s0                  // 00000016BB28: D5207C5F 0002BE80
	s_add_i32 s13, s13, 1                                      // 00000016BB30: 810D810D
	s_waitcnt lgkmcnt(0)                                       // 00000016BB34: BF89FC07
	s_cmp_eq_u32 s13, s42                                      // 00000016BB38: BF062A0D
	s_barrier                                                  // 00000016BB3C: BFBD0000
	buffer_gl0_inv                                             // 00000016BB40: E0AC0000 00000000
	s_cbranch_scc1 5060                                        // 00000016BB48: BFA213C4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x535c>
	s_mul_i32 s0, s13, 0xc00                                   // 00000016BB4C: 9600FF0D 00000C00
	s_lshl_b32 s18, s13, 6                                     // 00000016BB54: 8412860D
	s_add_i32 s0, s43, s0                                      // 00000016BB58: 8100002B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000016BB5C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 00000016BB60: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000016BB64: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016BB68: BF870009
	s_add_u32 s0, s30, s0                                      // 00000016BB6C: 8000001E
	s_addc_u32 s1, s31, s1                                     // 00000016BB70: 8201011F
	global_load_b32 v3, v2, s[0:1]                             // 00000016BB74: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 00000016BB7C: BF8903F7
	v_readfirstlane_b32 s19, v3                                // 00000016BB80: 7E260503
	s_and_saveexec_b32 s1, vcc_lo                              // 00000016BB84: BE81206A
	s_cbranch_execz 77                                         // 00000016BB88: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	v_or_b32_e32 v3, s18, v0                                   // 00000016BB8C: 38060012
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BB90: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 00000016BB94: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000016BB9C: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016BBA0: BF870091
	.long 0xd73c0003                                           // 00000016BBA4: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000016BBA8: 02020682
	.long 0xd7000003                                           // 00000016BBAC: D7000003
	v_cndmask_b32_e32 v1, s30, v3, vcc_lo                      // 00000016BBB0: 0202061E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016BBB4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s31, v4, s0                  // 00000016BBB8: D5207C04 0002081F
	global_load_b32 v3, v[3:4], off                            // 00000016BBC0: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016BBC8: BF8903F7
	v_sub_f32_e32 v4, s19, v3                                  // 00000016BBCC: 08080613
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 00000016BBD0: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000016BBDC: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 00000016BBE0: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v26, v6                                    // 00000016BBEC: 7E344706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 00000016BBF0: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 00000016BBFC: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016BC00: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v26// 00000016BC04: C80A06FF 09063506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 00000016BC10: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016BC14: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 00000016BC18: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 00000016BC20: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 00000016BC24: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 00000016BC2C: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 00000016BC34: 7E0E1108
	v_cvt_i32_f32_e32 v8, v26                                  // 00000016BC38: 7E10111A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016BC3C: BF870193
	v_exp_f32_e32 v6, v6                                       // 00000016BC40: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 00000016BC44: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000016BC48: BF870296
	.long 0xd71c0006                                           // 00000016BC4C: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000016BC50: 02021106
	.long 0xd71c0005                                           // 00000016BC54: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000016BC58: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016BC5C: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 00000016BC60: D5010005 00020A80
	.long 0xd41b0000                                           // 00000016BC68: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 00000016BC6C: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 00000016BC74: D5010006 00020C80
	.long 0xd41e0000                                           // 00000016BC7C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 00000016BC80: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000016BC88: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 00000016BC8C: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 00000016BC98: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 00000016BC9C: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 00000016BCA4: D5010003 00020CFF 7F800000
	ds_store_b32 v99, v4                                       // 00000016BCB0: D8340000 00000463
	ds_store_b32 v100, v3                                      // 00000016BCB8: D8340000 00000364
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016BCC0: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000016BCC4: BF89FC07
	s_barrier                                                  // 00000016BCC8: BFBD0000
	buffer_gl0_inv                                             // 00000016BCCC: E0AC0000 00000000
	ds_load_b128 v[3:6], v101                                  // 00000016BCD4: DBFC0000 03000065
	ds_load_b128 v[28:31], v101 offset:16                      // 00000016BCDC: DBFC0010 1C000065
	ds_load_b128 v[32:35], v101 offset:32                      // 00000016BCE4: DBFC0020 20000065
	ds_load_b128 v[36:39], v101 offset:48                      // 00000016BCEC: DBFC0030 24000065
	ds_load_b128 v[42:45], v101 offset:8448                    // 00000016BCF4: DBFC2100 2A000065
	ds_load_b128 v[46:49], v101 offset:8464                    // 00000016BCFC: DBFC2110 2E000065
	ds_load_b128 v[50:53], v101 offset:8480                    // 00000016BD04: DBFC2120 32000065
	ds_load_b128 v[58:61], v101 offset:16896                   // 00000016BD0C: DBFC4200 3A000065
	ds_load_b128 v[62:65], v101 offset:16912                   // 00000016BD14: DBFC4210 3E000065
	ds_load_b128 v[66:69], v101 offset:16928                   // 00000016BD1C: DBFC4220 42000065
	ds_load_b128 v[82:85], v101 offset:8560                    // 00000016BD24: DBFC2170 52000065
	ds_load_b128 v[115:118], v101 offset:128                   // 00000016BD2C: DBFC0080 73000065
	ds_load_b128 v[119:122], v101 offset:144                   // 00000016BD34: DBFC0090 77000065
	ds_load_b128 v[123:126], v101 offset:160                   // 00000016BD3C: DBFC00A0 7B000065
	ds_load_b128 v[127:130], v101 offset:176                   // 00000016BD44: DBFC00B0 7F000065
	ds_load_b128 v[74:77], v101 offset:8528                    // 00000016BD4C: DBFC2150 4A000065
	ds_load_b128 v[70:73], v101 offset:80                      // 00000016BD54: DBFC0050 46000065
	ds_load_b128 v[78:81], v101 offset:8544                    // 00000016BD5C: DBFC2160 4E000065
	ds_load_b128 v[86:89], v101 offset:25456                   // 00000016BD64: DBFC6370 56000065
	s_waitcnt lgkmcnt(18)                                      // 00000016BD6C: BF89FD27
	v_fma_mixlo_f16 v26, v3, s12, 0                            // 00000016BD70: CC21001A 02001903
	v_fma_mixhi_f16 v26, v4, s12, 0                            // 00000016BD78: CC22001A 02001904
	v_fma_mixlo_f16 v27, v5, s12, 0                            // 00000016BD80: CC21001B 02001905
	v_fma_mixhi_f16 v27, v6, s12, 0                            // 00000016BD88: CC22001B 02001906
	ds_load_b128 v[3:6], v101 offset:8496                      // 00000016BD90: DBFC2130 03000065
	s_waitcnt lgkmcnt(15)                                      // 00000016BD98: BF89FCF7
	v_fma_mixlo_f16 v42, v42, s12, 0                           // 00000016BD9C: CC21002A 0200192A
	v_fma_mixhi_f16 v42, v43, s12, 0                           // 00000016BDA4: CC22002A 0200192B
	v_fma_mixhi_f16 v43, v45, s12, 0                           // 00000016BDAC: CC22002B 0200192D
	s_waitcnt lgkmcnt(14)                                      // 00000016BDB4: BF89FCE7
	v_fma_mixlo_f16 v45, v48, s12, 0                           // 00000016BDB8: CC21002D 02001930
	v_fma_mixhi_f16 v45, v49, s12, 0                           // 00000016BDC0: CC22002D 02001931
	v_fma_mixlo_f16 v43, v44, s12, 0                           // 00000016BDC8: CC21002B 0200192C
	v_fma_mixlo_f16 v44, v46, s12, 0                           // 00000016BDD0: CC21002C 0200192E
	v_fma_mixhi_f16 v44, v47, s12, 0                           // 00000016BDD8: CC22002C 0200192F
	s_waitcnt lgkmcnt(13)                                      // 00000016BDE0: BF89FCD7
	v_fma_mixlo_f16 v46, v50, s12, 0                           // 00000016BDE4: CC21002E 02001932
	v_fma_mixhi_f16 v46, v51, s12, 0                           // 00000016BDEC: CC22002E 02001933
	v_fma_mixlo_f16 v47, v52, s12, 0                           // 00000016BDF4: CC21002F 02001934
	v_fma_mixhi_f16 v47, v53, s12, 0                           // 00000016BDFC: CC22002F 02001935
	v_fma_mixlo_f16 v28, v28, s12, 0                           // 00000016BE04: CC21001C 0200191C
	v_fma_mixhi_f16 v28, v29, s12, 0                           // 00000016BE0C: CC22001C 0200191D
	v_fma_mixlo_f16 v29, v30, s12, 0                           // 00000016BE14: CC21001D 0200191E
	v_fma_mixhi_f16 v29, v31, s12, 0                           // 00000016BE1C: CC22001D 0200191F
	v_fma_mixlo_f16 v30, v32, s12, 0                           // 00000016BE24: CC21001E 02001920
	v_fma_mixhi_f16 v30, v33, s12, 0                           // 00000016BE2C: CC22001E 02001921
	v_fma_mixlo_f16 v31, v34, s12, 0                           // 00000016BE34: CC21001F 02001922
	s_waitcnt lgkmcnt(0)                                       // 00000016BE3C: BF89FC07
	v_fma_mixlo_f16 v48, v3, s12, 0                            // 00000016BE40: CC210030 02001903
	v_fma_mixhi_f16 v48, v4, s12, 0                            // 00000016BE48: CC220030 02001904
	v_fma_mixlo_f16 v49, v5, s12, 0                            // 00000016BE50: CC210031 02001905
	v_fma_mixhi_f16 v49, v6, s12, 0                            // 00000016BE58: CC220031 02001906
	ds_load_b128 v[3:6], v101 offset:16944                     // 00000016BE60: DBFC4230 03000065
	v_fma_mixhi_f16 v31, v35, s12, 0                           // 00000016BE68: CC22001F 02001923
	v_fma_mixlo_f16 v32, v36, s12, 0                           // 00000016BE70: CC210020 02001924
	v_fma_mixhi_f16 v32, v37, s12, 0                           // 00000016BE78: CC220020 02001925
	v_fma_mixlo_f16 v33, v38, s12, 0                           // 00000016BE80: CC210021 02001926
	v_fma_mixhi_f16 v33, v39, s12, 0                           // 00000016BE88: CC220021 02001927
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[42:49], v[18:25]// 00000016BE90: CC404022 1C4A550A
	ds_load_b128 v[42:45], v101 offset:25344                   // 00000016BE98: DBFC6300 2A000065
	ds_load_b128 v[46:49], v101 offset:25360                   // 00000016BEA0: DBFC6310 2E000065
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[26:33], v[18:25]// 00000016BEA8: CC404032 1C4A350A
	v_fma_mixlo_f16 v28, v62, s12, 0                           // 00000016BEB0: CC21001C 0200193E
	v_fma_mixhi_f16 v28, v63, s12, 0                           // 00000016BEB8: CC22001C 0200193F
	v_fma_mixlo_f16 v29, v64, s12, 0                           // 00000016BEC0: CC21001D 02001940
	v_fma_mixhi_f16 v29, v65, s12, 0                           // 00000016BEC8: CC22001D 02001941
	v_fma_mixlo_f16 v30, v66, s12, 0                           // 00000016BED0: CC21001E 02001942
	ds_load_b128 v[62:65], v101 offset:25376                   // 00000016BED8: DBFC6320 3E000065
	v_fma_mixhi_f16 v30, v67, s12, 0                           // 00000016BEE0: CC22001E 02001943
	v_fma_mixlo_f16 v31, v68, s12, 0                           // 00000016BEE8: CC21001F 02001944
	v_fma_mixhi_f16 v31, v69, s12, 0                           // 00000016BEF0: CC22001F 02001945
	s_waitcnt lgkmcnt(3)                                       // 00000016BEF8: BF89FC37
	v_fma_mixlo_f16 v32, v3, s12, 0                            // 00000016BEFC: CC210020 02001903
	ds_load_b128 v[66:69], v101 offset:25392                   // 00000016BF04: DBFC6330 42000065
	v_fma_mixhi_f16 v32, v4, s12, 0                            // 00000016BF0C: CC220020 02001904
	v_fma_mixlo_f16 v33, v5, s12, 0                            // 00000016BF14: CC210021 02001905
	v_fma_mixhi_f16 v33, v6, s12, 0                            // 00000016BF1C: CC220021 02001906
	ds_load_b128 v[3:6], v101 offset:64                        // 00000016BF24: DBFC0040 03000065
	v_fma_mixlo_f16 v26, v58, s12, 0                           // 00000016BF2C: CC21001A 0200193A
	v_fma_mixhi_f16 v26, v59, s12, 0                           // 00000016BF34: CC22001A 0200193B
	v_fma_mixlo_f16 v27, v60, s12, 0                           // 00000016BF3C: CC21001B 0200193C
	v_fma_mixhi_f16 v27, v61, s12, 0                           // 00000016BF44: CC22001B 0200193D
	s_waitcnt lgkmcnt(4)                                       // 00000016BF4C: BF89FC47
	v_fma_mixlo_f16 v58, v42, s12, 0                           // 00000016BF50: CC21003A 0200192A
	v_fma_mixhi_f16 v58, v43, s12, 0                           // 00000016BF58: CC22003A 0200192B
	v_fma_mixlo_f16 v59, v44, s12, 0                           // 00000016BF60: CC21003B 0200192C
	v_fma_mixhi_f16 v59, v45, s12, 0                           // 00000016BF68: CC22003B 0200192D
	s_waitcnt lgkmcnt(3)                                       // 00000016BF70: BF89FC37
	v_fma_mixlo_f16 v60, v46, s12, 0                           // 00000016BF74: CC21003C 0200192E
	v_fma_mixhi_f16 v60, v47, s12, 0                           // 00000016BF7C: CC22003C 0200192F
	v_fma_mixlo_f16 v61, v48, s12, 0                           // 00000016BF84: CC21003D 02001930
	ds_load_b128 v[42:45], v101 offset:96                      // 00000016BF8C: DBFC0060 2A000065
	v_fma_mixhi_f16 v61, v49, s12, 0                           // 00000016BF94: CC22003D 02001931
	ds_load_b128 v[46:49], v101 offset:112                     // 00000016BF9C: DBFC0070 2E000065
	s_waitcnt lgkmcnt(4)                                       // 00000016BFA4: BF89FC47
	v_fma_mixlo_f16 v62, v62, s12, 0                           // 00000016BFA8: CC21003E 0200193E
	v_fma_mixhi_f16 v62, v63, s12, 0                           // 00000016BFB0: CC22003E 0200193F
	v_fma_mixlo_f16 v63, v64, s12, 0                           // 00000016BFB8: CC21003F 02001940
	s_waitcnt lgkmcnt(3)                                       // 00000016BFC0: BF89FC37
	v_fma_mixlo_f16 v64, v66, s12, 0                           // 00000016BFC4: CC210040 02001942
	v_fma_mixhi_f16 v64, v67, s12, 0                           // 00000016BFCC: CC220040 02001943
	s_waitcnt lgkmcnt(2)                                       // 00000016BFD4: BF89FC27
	v_fma_mixlo_f16 v66, v3, s12, 0                            // 00000016BFD8: CC210042 02001903
	v_fma_mixhi_f16 v66, v4, s12, 0                            // 00000016BFE0: CC220042 02001904
	v_fma_mixlo_f16 v67, v5, s12, 0                            // 00000016BFE8: CC210043 02001905
	v_fma_mixhi_f16 v67, v6, s12, 0                            // 00000016BFF0: CC220043 02001906
	ds_load_b128 v[3:6], v101 offset:8512                      // 00000016BFF8: DBFC2140 03000065
	v_fma_mixhi_f16 v63, v65, s12, 0                           // 00000016C000: CC22003F 02001941
	v_fma_mixlo_f16 v65, v68, s12, 0                           // 00000016C008: CC210041 02001944
	v_fma_mixhi_f16 v65, v69, s12, 0                           // 00000016C010: CC220041 02001945
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016C018: CC210044 02001946
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016C020: CC220044 02001947
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016C028: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016C030: CC220045 02001949
	s_waitcnt lgkmcnt(2)                                       // 00000016C038: BF89FC27
	v_fma_mixlo_f16 v70, v42, s12, 0                           // 00000016C03C: CC210046 0200192A
	v_fma_mixhi_f16 v70, v43, s12, 0                           // 00000016C044: CC220046 0200192B
	v_fma_mixlo_f16 v71, v44, s12, 0                           // 00000016C04C: CC210047 0200192C
	v_fma_mixhi_f16 v71, v45, s12, 0                           // 00000016C054: CC220047 0200192D
	s_waitcnt lgkmcnt(1)                                       // 00000016C05C: BF89FC17
	v_fma_mixlo_f16 v72, v46, s12, 0                           // 00000016C060: CC210048 0200192E
	v_fma_mixhi_f16 v72, v47, s12, 0                           // 00000016C068: CC220048 0200192F
	v_fma_mixlo_f16 v73, v48, s12, 0                           // 00000016C070: CC210049 02001930
	v_fma_mixhi_f16 v73, v49, s12, 0                           // 00000016C078: CC220049 02001931
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[26:33], v[18:25]// 00000016C080: CC40402A 1C4A350A
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[58:65], v[18:25]// 00000016C088: CC40401A 1C4A750A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000016C090: BF870003
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016C094: CC404032 1CCA850A
	ds_load_b128 v[66:69], v101 offset:16960                   // 00000016C09C: DBFC4240 42000065
	s_waitcnt lgkmcnt(1)                                       // 00000016C0A4: BF89FC17
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016C0A8: CC21003A 02001903
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016C0B0: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016C0B8: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016C0C0: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:16976                     // 00000016C0C8: DBFC4250 03000065
	v_fma_mixlo_f16 v60, v74, s12, 0                           // 00000016C0D0: CC21003C 0200194A
	v_fma_mixhi_f16 v60, v75, s12, 0                           // 00000016C0D8: CC22003C 0200194B
	v_fma_mixlo_f16 v61, v76, s12, 0                           // 00000016C0E0: CC21003D 0200194C
	v_fma_mixhi_f16 v61, v77, s12, 0                           // 00000016C0E8: CC22003D 0200194D
	ds_load_b128 v[70:73], v101 offset:16992                   // 00000016C0F0: DBFC4260 46000065
	ds_load_b128 v[74:77], v101 offset:17008                   // 00000016C0F8: DBFC4270 4A000065
	v_fma_mixlo_f16 v62, v78, s12, 0                           // 00000016C100: CC21003E 0200194E
	v_fma_mixhi_f16 v62, v79, s12, 0                           // 00000016C108: CC22003E 0200194F
	v_fma_mixlo_f16 v63, v80, s12, 0                           // 00000016C110: CC21003F 02001950
	v_fma_mixhi_f16 v63, v81, s12, 0                           // 00000016C118: CC22003F 02001951
	ds_load_b128 v[78:81], v101 offset:25408                   // 00000016C120: DBFC6340 4E000065
	s_waitcnt lgkmcnt(4)                                       // 00000016C128: BF89FC47
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016C12C: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016C134: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016C13C: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016C144: CC220043 02001945
	s_waitcnt lgkmcnt(3)                                       // 00000016C14C: BF89FC37
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016C150: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016C158: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016C160: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016C168: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25440                     // 00000016C170: DBFC6360 03000065
	s_waitcnt lgkmcnt(3)                                       // 00000016C178: BF89FC37
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016C17C: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016C184: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016C18C: CC210047 02001948
	s_waitcnt lgkmcnt(2)                                       // 00000016C194: BF89FC27
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016C198: CC210048 0200194A
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016C1A0: CC220047 02001949
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016C1A8: CC220048 0200194B
	s_waitcnt lgkmcnt(1)                                       // 00000016C1B0: BF89FC17
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016C1B4: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016C1BC: CC22004A 0200194F
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016C1C4: CC210049 0200194C
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016C1CC: CC220049 0200194D
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016C1D4: CC21004B 02001950
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016C1DC: CC22004B 02001951
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016C1E4: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016C1EC: CC220050 02001957
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016C1F4: CC40402A 1CAA850A
	ds_load_b128 v[66:69], v101 offset:17024                   // 00000016C1FC: DBFC4280 42000065
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016C204: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016C20C: CC220051 02001959
	ds_load_b128 v[70:73], v101 offset:17056                   // 00000016C214: DBFC42A0 46000065
	s_waitcnt lgkmcnt(2)                                       // 00000016C21C: BF89FC27
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016C220: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016C228: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016C230: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016C238: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:8576                      // 00000016C240: DBFC2180 03000065
	v_fma_mixlo_f16 v64, v82, s12, 0                           // 00000016C248: CC210040 02001952
	v_fma_mixhi_f16 v64, v83, s12, 0                           // 00000016C250: CC220040 02001953
	v_fma_mixlo_f16 v65, v84, s12, 0                           // 00000016C258: CC210041 02001954
	v_fma_mixhi_f16 v65, v85, s12, 0                           // 00000016C260: CC220041 02001955
	ds_load_b128 v[82:85], v101 offset:25424                   // 00000016C268: DBFC6350 52000065
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016C270: CC210056 0200197B
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016C278: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016C280: CC210057 0200197D
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016C288: CC404022 1C8A750A
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016C290: CC220057 0200197E
	v_fma_mixlo_f16 v88, v127, s12, 0                          // 00000016C298: CC210058 0200197F
	v_fma_mixhi_f16 v88, v128, s12, 0                          // 00000016C2A0: CC220058 02001980
	v_fma_mixlo_f16 v89, v129, s12, 0                          // 00000016C2A8: CC210059 02001981
	v_fma_mixhi_f16 v89, v130, s12, 0                          // 00000016C2B0: CC220059 02001982
	ds_load_b128 v[123:126], v101 offset:8624                  // 00000016C2B8: DBFC21B0 7B000065
	ds_load_b128 v[127:130], v101 offset:240                   // 00000016C2C0: DBFC00F0 7F000065
	s_waitcnt lgkmcnt(3)                                       // 00000016C2C8: BF89FC37
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016C2CC: CC21003A 02001903
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016C2D4: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016C2DC: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016C2E4: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:17040                     // 00000016C2EC: DBFC4290 03000065
	s_waitcnt lgkmcnt(3)                                       // 00000016C2F4: BF89FC37
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016C2F8: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016C300: CC22004C 02001953
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016C308: CC21004D 02001954
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016C310: CC22004D 02001955
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016C318: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016C320: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016C328: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016C330: CC220043 02001945
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016C338: CC40401A 1C6A950A
	ds_load_b128 v[74:77], v101 offset:17072                   // 00000016C340: DBFC42B0 4A000065
	ds_load_b128 v[78:81], v101 offset:25472                   // 00000016C348: DBFC6380 4E000065
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016C350: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016C358: CC220052 02001974
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016C360: CC210053 02001975
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016C368: CC220053 02001976
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016C370: CC210054 02001977
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016C378: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016C380: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016C388: CC220055 0200197A
	s_waitcnt lgkmcnt(2)                                       // 00000016C390: BF89FC27
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016C394: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016C39C: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016C3A4: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016C3AC: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25504                     // 00000016C3B4: DBFC63A0 03000065
	ds_load_b128 v[115:118], v101 offset:8592                  // 00000016C3BC: DBFC2190 73000065
	ds_load_b128 v[119:122], v101 offset:8608                  // 00000016C3C4: DBFC21A0 77000065
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016C3CC: CC404032 1CCAA50A
	ds_load_b128 v[82:85], v101 offset:25488                   // 00000016C3D4: DBFC6390 52000065
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016C3DC: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016C3E4: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016C3EC: CC210047 02001948
	s_waitcnt lgkmcnt(5)                                       // 00000016C3F4: BF89FC57
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016C3F8: CC210048 0200194A
	ds_load_b128 v[86:89], v101 offset:25520                   // 00000016C400: DBFC63B0 56000065
	s_waitcnt lgkmcnt(5)                                       // 00000016C408: BF89FC57
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016C40C: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016C414: CC22004A 0200194F
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016C41C: CC220047 02001949
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016C424: CC220048 0200194B
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016C42C: CC210049 0200194C
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016C434: CC220049 0200194D
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016C43C: CC21004B 02001950
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016C444: CC22004B 02001951
	s_waitcnt lgkmcnt(4)                                       // 00000016C44C: BF89FC47
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016C450: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016C458: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016C460: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016C468: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:8640                      // 00000016C470: DBFC21C0 03000065
	s_waitcnt lgkmcnt(4)                                       // 00000016C478: BF89FC47
	v_fma_mixlo_f16 v60, v115, s12, 0                          // 00000016C47C: CC21003C 02001973
	v_fma_mixhi_f16 v60, v116, s12, 0                          // 00000016C484: CC22003C 02001974
	v_fma_mixlo_f16 v61, v117, s12, 0                          // 00000016C48C: CC21003D 02001975
	v_fma_mixhi_f16 v61, v118, s12, 0                          // 00000016C494: CC22003D 02001976
	s_waitcnt lgkmcnt(3)                                       // 00000016C49C: BF89FC37
	v_fma_mixlo_f16 v62, v119, s12, 0                          // 00000016C4A0: CC21003E 02001977
	v_fma_mixhi_f16 v62, v120, s12, 0                          // 00000016C4A8: CC22003E 02001978
	v_fma_mixlo_f16 v63, v121, s12, 0                          // 00000016C4B0: CC21003F 02001979
	v_fma_mixhi_f16 v63, v122, s12, 0                          // 00000016C4B8: CC22003F 0200197A
	v_fma_mixlo_f16 v64, v123, s12, 0                          // 00000016C4C0: CC210040 0200197B
	v_fma_mixhi_f16 v64, v124, s12, 0                          // 00000016C4C8: CC220040 0200197C
	v_fma_mixlo_f16 v65, v125, s12, 0                          // 00000016C4D0: CC210041 0200197D
	v_fma_mixhi_f16 v65, v126, s12, 0                          // 00000016C4D8: CC220041 0200197E
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016C4E0: CC40402A 1CAA850A
	ds_load_b128 v[66:69], v101 offset:17088                   // 00000016C4E8: DBFC42C0 42000065
	ds_load_b128 v[115:118], v101 offset:192                   // 00000016C4F0: DBFC00C0 73000065
	ds_load_b128 v[119:122], v101 offset:208                   // 00000016C4F8: DBFC00D0 77000065
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016C500: CC404022 1C8A750A
	s_waitcnt lgkmcnt(5)                                       // 00000016C508: BF89FC57
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016C50C: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016C514: CC22004C 02001953
	s_waitcnt lgkmcnt(3)                                       // 00000016C51C: BF89FC37
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016C520: CC21003A 02001903
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016C528: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016C530: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016C538: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:17104                     // 00000016C540: DBFC42D0 03000065
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016C548: CC21004D 02001954
	ds_load_b128 v[123:126], v101 offset:224                   // 00000016C550: DBFC00E0 7B000065
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016C558: CC22004D 02001955
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016C560: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016C568: CC220050 02001957
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016C570: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016C578: CC220051 02001959
	ds_load_b128 v[70:73], v101 offset:17120                   // 00000016C580: DBFC42E0 46000065
	v_fma_mixlo_f16 v88, v127, s12, 0                          // 00000016C588: CC210058 0200197F
	s_waitcnt lgkmcnt(5)                                       // 00000016C590: BF89FC57
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016C594: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016C59C: CC220042 02001943
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016C5A4: CC40401A 1C6A950A
	ds_load_b128 v[74:77], v101 offset:17136                   // 00000016C5AC: DBFC42F0 4A000065
	ds_load_b128 v[78:81], v101 offset:25536                   // 00000016C5B4: DBFC63C0 4E000065
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016C5BC: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016C5C4: CC220043 02001945
	s_waitcnt lgkmcnt(6)                                       // 00000016C5CC: BF89FC67
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016C5D0: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016C5D8: CC220052 02001974
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016C5E0: CC210053 02001975
	s_waitcnt lgkmcnt(4)                                       // 00000016C5E8: BF89FC47
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016C5EC: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016C5F4: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016C5FC: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016C604: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25568                     // 00000016C60C: DBFC63E0 03000065
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016C614: CC220053 02001976
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016C61C: CC210054 02001977
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016C624: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016C62C: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016C634: CC220055 0200197A
	s_waitcnt lgkmcnt(4)                                       // 00000016C63C: BF89FC47
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016C640: CC210056 0200197B
	ds_load_b128 v[115:118], v101 offset:8656                  // 00000016C648: DBFC21D0 73000065
	ds_load_b128 v[119:122], v101 offset:8672                  // 00000016C650: DBFC21E0 77000065
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016C658: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016C660: CC210057 0200197D
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016C668: CC220057 0200197E
	v_fma_mixhi_f16 v88, v128, s12, 0                          // 00000016C670: CC220058 02001980
	v_fma_mixlo_f16 v89, v129, s12, 0                          // 00000016C678: CC210059 02001981
	v_fma_mixhi_f16 v89, v130, s12, 0                          // 00000016C680: CC220059 02001982
	ds_load_b128 v[123:126], v101 offset:8688                  // 00000016C688: DBFC21F0 7B000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C690: BF89FC67
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016C694: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016C69C: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016C6A4: CC210047 02001948
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016C6AC: CC404032 1CCAA50A
	ds_load_b128 v[82:85], v101 offset:25552                   // 00000016C6B4: DBFC63D0 52000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C6BC: BF89FC67
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016C6C0: CC210048 0200194A
	ds_load_b128 v[86:89], v101 offset:25584                   // 00000016C6C8: DBFC63F0 56000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C6D0: BF89FC67
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016C6D4: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016C6DC: CC22004A 0200194F
	s_waitcnt lgkmcnt(5)                                       // 00000016C6E4: BF89FC57
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016C6E8: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016C6F0: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016C6F8: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016C700: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:8704                      // 00000016C708: DBFC2200 03000065
	s_waitcnt lgkmcnt(5)                                       // 00000016C710: BF89FC57
	v_fma_mixlo_f16 v60, v115, s12, 0                          // 00000016C714: CC21003C 02001973
	v_fma_mixhi_f16 v60, v116, s12, 0                          // 00000016C71C: CC22003C 02001974
	v_fma_mixlo_f16 v61, v117, s12, 0                          // 00000016C724: CC21003D 02001975
	v_fma_mixhi_f16 v61, v118, s12, 0                          // 00000016C72C: CC22003D 02001976
	s_waitcnt lgkmcnt(4)                                       // 00000016C734: BF89FC47
	v_fma_mixlo_f16 v62, v119, s12, 0                          // 00000016C738: CC21003E 02001977
	v_fma_mixhi_f16 v62, v120, s12, 0                          // 00000016C740: CC22003E 02001978
	v_fma_mixlo_f16 v63, v121, s12, 0                          // 00000016C748: CC21003F 02001979
	v_fma_mixhi_f16 v63, v122, s12, 0                          // 00000016C750: CC22003F 0200197A
	s_waitcnt lgkmcnt(3)                                       // 00000016C758: BF89FC37
	v_fma_mixlo_f16 v64, v123, s12, 0                          // 00000016C75C: CC210040 0200197B
	v_fma_mixhi_f16 v64, v124, s12, 0                          // 00000016C764: CC220040 0200197C
	v_fma_mixlo_f16 v65, v125, s12, 0                          // 00000016C76C: CC210041 0200197D
	v_fma_mixhi_f16 v65, v126, s12, 0                          // 00000016C774: CC220041 0200197E
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016C77C: CC220047 02001949
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016C784: CC220048 0200194B
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016C78C: CC210049 0200194C
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016C794: CC220049 0200194D
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016C79C: CC404022 1C8A750A
	ds_load_b128 v[115:118], v101 offset:256                   // 00000016C7A4: DBFC0100 73000065
	ds_load_b128 v[119:122], v101 offset:272                   // 00000016C7AC: DBFC0110 77000065
	s_waitcnt lgkmcnt(2)                                       // 00000016C7B4: BF89FC27
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016C7B8: CC21003A 02001903
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016C7C0: CC40402A 1CAA850A
	ds_load_b128 v[66:69], v101 offset:17152                   // 00000016C7C8: DBFC4300 42000065
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016C7D0: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016C7D8: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016C7E0: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:17168                     // 00000016C7E8: DBFC4310 03000065
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016C7F0: CC21004B 02001950
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016C7F8: CC22004B 02001951
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016C800: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016C808: CC22004C 02001953
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016C810: CC21004D 02001954
	ds_load_b128 v[123:126], v101 offset:288                   // 00000016C818: DBFC0120 7B000065
	ds_load_b128 v[127:130], v101 offset:304                   // 00000016C820: DBFC0130 7F000065
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016C828: CC22004D 02001955
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016C830: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016C838: CC220050 02001957
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016C840: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016C848: CC220051 02001959
	ds_load_b128 v[70:73], v101 offset:17184                   // 00000016C850: DBFC4320 46000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C858: BF89FC67
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016C85C: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016C864: CC220052 02001974
	s_waitcnt lgkmcnt(4)                                       // 00000016C86C: BF89FC47
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016C870: CC210042 02001942
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016C878: CC40401A 1C6A950A
	ds_load_b128 v[74:77], v101 offset:17200                   // 00000016C880: DBFC4330 4A000065
	ds_load_b128 v[78:81], v101 offset:25600                   // 00000016C888: DBFC6400 4E000065
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016C890: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016C898: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016C8A0: CC220043 02001945
	s_waitcnt lgkmcnt(5)                                       // 00000016C8A8: BF89FC57
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016C8AC: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016C8B4: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016C8BC: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016C8C4: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25632                     // 00000016C8CC: DBFC6420 03000065
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016C8D4: CC210053 02001975
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016C8DC: CC220053 02001976
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016C8E4: CC210054 02001977
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016C8EC: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016C8F4: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016C8FC: CC220055 0200197A
	s_waitcnt lgkmcnt(5)                                       // 00000016C904: BF89FC57
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016C908: CC210056 0200197B
	ds_load_b128 v[115:118], v101 offset:8720                  // 00000016C910: DBFC2210 73000065
	ds_load_b128 v[119:122], v101 offset:8736                  // 00000016C918: DBFC2220 77000065
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016C920: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016C928: CC210057 0200197D
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016C930: CC220057 0200197E
	s_waitcnt lgkmcnt(6)                                       // 00000016C938: BF89FC67
	v_fma_mixlo_f16 v88, v127, s12, 0                          // 00000016C93C: CC210058 0200197F
	v_fma_mixhi_f16 v88, v128, s12, 0                          // 00000016C944: CC220058 02001980
	v_fma_mixlo_f16 v89, v129, s12, 0                          // 00000016C94C: CC210059 02001981
	v_fma_mixhi_f16 v89, v130, s12, 0                          // 00000016C954: CC220059 02001982
	ds_load_b128 v[123:126], v101 offset:8752                  // 00000016C95C: DBFC2230 7B000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C964: BF89FC67
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016C968: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016C970: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016C978: CC210047 02001948
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016C980: CC404032 1CCAA50A
	ds_load_b128 v[82:85], v101 offset:25616                   // 00000016C988: DBFC6410 52000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C990: BF89FC67
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016C994: CC210048 0200194A
	ds_load_b128 v[86:89], v101 offset:25648                   // 00000016C99C: DBFC6430 56000065
	s_waitcnt lgkmcnt(6)                                       // 00000016C9A4: BF89FC67
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016C9A8: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016C9B0: CC22004A 0200194F
	s_waitcnt lgkmcnt(5)                                       // 00000016C9B8: BF89FC57
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016C9BC: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016C9C4: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016C9CC: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016C9D4: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:8768                      // 00000016C9DC: DBFC2240 03000065
	s_waitcnt lgkmcnt(5)                                       // 00000016C9E4: BF89FC57
	v_fma_mixlo_f16 v60, v115, s12, 0                          // 00000016C9E8: CC21003C 02001973
	v_fma_mixhi_f16 v60, v116, s12, 0                          // 00000016C9F0: CC22003C 02001974
	v_fma_mixlo_f16 v61, v117, s12, 0                          // 00000016C9F8: CC21003D 02001975
	v_fma_mixhi_f16 v61, v118, s12, 0                          // 00000016CA00: CC22003D 02001976
	s_waitcnt lgkmcnt(4)                                       // 00000016CA08: BF89FC47
	v_fma_mixlo_f16 v62, v119, s12, 0                          // 00000016CA0C: CC21003E 02001977
	v_fma_mixhi_f16 v62, v120, s12, 0                          // 00000016CA14: CC22003E 02001978
	v_fma_mixlo_f16 v63, v121, s12, 0                          // 00000016CA1C: CC21003F 02001979
	v_fma_mixhi_f16 v63, v122, s12, 0                          // 00000016CA24: CC22003F 0200197A
	s_waitcnt lgkmcnt(3)                                       // 00000016CA2C: BF89FC37
	v_fma_mixlo_f16 v64, v123, s12, 0                          // 00000016CA30: CC210040 0200197B
	v_fma_mixhi_f16 v64, v124, s12, 0                          // 00000016CA38: CC220040 0200197C
	v_fma_mixlo_f16 v65, v125, s12, 0                          // 00000016CA40: CC210041 0200197D
	v_fma_mixhi_f16 v65, v126, s12, 0                          // 00000016CA48: CC220041 0200197E
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016CA50: CC220047 02001949
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016CA58: CC220048 0200194B
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016CA60: CC210049 0200194C
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016CA68: CC220049 0200194D
	ds_load_b128 v[115:118], v101 offset:320                   // 00000016CA70: DBFC0140 73000065
	ds_load_b128 v[119:122], v101 offset:336                   // 00000016CA78: DBFC0150 77000065
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016CA80: CC404022 1C8A750A
	s_waitcnt lgkmcnt(2)                                       // 00000016CA88: BF89FC27
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016CA8C: CC21003A 02001903
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016CA94: CC40402A 1CAA850A
	ds_load_b128 v[66:69], v101 offset:17216                   // 00000016CA9C: DBFC4340 42000065
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016CAA4: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016CAAC: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016CAB4: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:17232                     // 00000016CABC: DBFC4350 03000065
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016CAC4: CC21004B 02001950
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016CACC: CC22004B 02001951
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016CAD4: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016CADC: CC22004C 02001953
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016CAE4: CC21004D 02001954
	ds_load_b128 v[123:126], v101 offset:352                   // 00000016CAEC: DBFC0160 7B000065
	ds_load_b128 v[127:130], v101 offset:368                   // 00000016CAF4: DBFC0170 7F000065
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016CAFC: CC22004D 02001955
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016CB04: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016CB0C: CC220050 02001957
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016CB14: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016CB1C: CC220051 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016CB24: BF89FC57
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016CB28: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016CB30: CC220052 02001974
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016CB38: CC210053 02001975
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016CB40: CC220053 02001976
	ds_load_b128 v[115:118], v101 offset:8784                  // 00000016CB48: DBFC2250 73000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016CB50: CC40401A 1C6A950A
	ds_load_b128 v[70:73], v101 offset:17248                   // 00000016CB58: DBFC4360 46000065
	ds_load_b128 v[74:77], v101 offset:17264                   // 00000016CB60: DBFC4370 4A000065
	s_waitcnt lgkmcnt(6)                                       // 00000016CB68: BF89FC67
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016CB6C: CC210042 02001942
	ds_load_b128 v[78:81], v101 offset:25664                   // 00000016CB74: DBFC6440 4E000065
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016CB7C: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016CB84: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016CB8C: CC220043 02001945
	s_waitcnt lgkmcnt(6)                                       // 00000016CB94: BF89FC67
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016CB98: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016CBA0: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016CBA8: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016CBB0: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25696                     // 00000016CBB8: DBFC6460 03000065
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016CBC0: CC210054 02001977
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016CBC8: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016CBD0: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016CBD8: CC220055 0200197A
	s_waitcnt lgkmcnt(6)                                       // 00000016CBE0: BF89FC67
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016CBE4: CC210056 0200197B
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016CBEC: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016CBF4: CC210057 0200197D
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016CBFC: CC220057 0200197E
	s_waitcnt lgkmcnt(5)                                       // 00000016CC04: BF89FC57
	v_fma_mixlo_f16 v88, v127, s12, 0                          // 00000016CC08: CC210058 0200197F
	ds_load_b128 v[119:122], v101 offset:8800                  // 00000016CC10: DBFC2260 77000065
	v_fma_mixhi_f16 v88, v128, s12, 0                          // 00000016CC18: CC220058 02001980
	v_fma_mixlo_f16 v89, v129, s12, 0                          // 00000016CC20: CC210059 02001981
	v_fma_mixhi_f16 v89, v130, s12, 0                          // 00000016CC28: CC220059 02001982
	ds_load_b128 v[123:126], v101 offset:8816                  // 00000016CC30: DBFC2270 7B000065
	s_waitcnt lgkmcnt(6)                                       // 00000016CC38: BF89FC67
	v_fma_mixlo_f16 v60, v115, s12, 0                          // 00000016CC3C: CC21003C 02001973
	v_fma_mixhi_f16 v60, v116, s12, 0                          // 00000016CC44: CC22003C 02001974
	v_fma_mixlo_f16 v61, v117, s12, 0                          // 00000016CC4C: CC21003D 02001975
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016CC54: CC404032 1CCAA50A
	v_fma_mixhi_f16 v61, v118, s12, 0                          // 00000016CC5C: CC22003D 02001976
	ds_load_b128 v[82:85], v101 offset:25680                   // 00000016CC64: DBFC6450 52000065
	s_waitcnt lgkmcnt(6)                                       // 00000016CC6C: BF89FC67
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016CC70: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016CC78: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016CC80: CC210047 02001948
	s_waitcnt lgkmcnt(5)                                       // 00000016CC88: BF89FC57
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016CC8C: CC210048 0200194A
	ds_load_b128 v[86:89], v101 offset:25712                   // 00000016CC94: DBFC6470 56000065
	ds_load_b128 v[115:118], v101 offset:384                   // 00000016CC9C: DBFC0180 73000065
	s_waitcnt lgkmcnt(6)                                       // 00000016CCA4: BF89FC67
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016CCA8: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016CCB0: CC22004A 0200194F
	s_waitcnt lgkmcnt(5)                                       // 00000016CCB8: BF89FC57
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016CCBC: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016CCC4: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016CCCC: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016CCD4: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:8832                      // 00000016CCDC: DBFC2280 03000065
	s_waitcnt lgkmcnt(5)                                       // 00000016CCE4: BF89FC57
	v_fma_mixlo_f16 v62, v119, s12, 0                          // 00000016CCE8: CC21003E 02001977
	v_fma_mixhi_f16 v62, v120, s12, 0                          // 00000016CCF0: CC22003E 02001978
	v_fma_mixlo_f16 v63, v121, s12, 0                          // 00000016CCF8: CC21003F 02001979
	v_fma_mixhi_f16 v63, v122, s12, 0                          // 00000016CD00: CC22003F 0200197A
	s_waitcnt lgkmcnt(4)                                       // 00000016CD08: BF89FC47
	v_fma_mixlo_f16 v64, v123, s12, 0                          // 00000016CD0C: CC210040 0200197B
	v_fma_mixhi_f16 v64, v124, s12, 0                          // 00000016CD14: CC220040 0200197C
	v_fma_mixlo_f16 v65, v125, s12, 0                          // 00000016CD1C: CC210041 0200197D
	v_fma_mixhi_f16 v65, v126, s12, 0                          // 00000016CD24: CC220041 0200197E
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016CD2C: CC220047 02001949
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016CD34: CC220048 0200194B
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016CD3C: CC210049 0200194C
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016CD44: CC220049 0200194D
	ds_load_b128 v[119:122], v101 offset:400                   // 00000016CD4C: DBFC0190 77000065
	ds_load_b128 v[123:126], v101 offset:416                   // 00000016CD54: DBFC01A0 7B000065
	ds_load_b128 v[127:130], v101 offset:432                   // 00000016CD5C: DBFC01B0 7F000065
	s_waitcnt lgkmcnt(6)                                       // 00000016CD64: BF89FC67
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016CD68: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016CD70: CC22004C 02001953
	s_waitcnt lgkmcnt(4)                                       // 00000016CD78: BF89FC47
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016CD7C: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016CD84: CC220052 02001974
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016CD8C: CC210053 02001975
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016CD94: CC220053 02001976
	ds_load_b128 v[115:118], v101 offset:8848                  // 00000016CD9C: DBFC2290 73000065
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016CDA4: CC404022 1C8A750A
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016CDAC: CC40402A 1CAA850A
	ds_load_b128 v[66:69], v101 offset:17280                   // 00000016CDB4: DBFC4380 42000065
	s_waitcnt lgkmcnt(5)                                       // 00000016CDBC: BF89FC57
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000016CDC0: CC21003A 02001903
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000016CDC8: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000016CDD0: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000016CDD8: CC22003B 02001906
	ds_load_b128 v[3:6], v101 offset:17296                     // 00000016CDE0: DBFC4390 03000065
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016CDE8: CC21004B 02001950
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016CDF0: CC22004B 02001951
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016CDF8: CC21004D 02001954
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016CE00: CC22004D 02001955
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016CE08: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016CE10: CC220050 02001957
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016CE18: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016CE20: CC220051 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016CE28: BF89FC57
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016CE2C: CC210054 02001977
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016CE34: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016CE3C: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016CE44: CC220055 0200197A
	s_waitcnt lgkmcnt(4)                                       // 00000016CE4C: BF89FC47
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016CE50: CC210056 0200197B
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016CE58: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016CE60: CC210057 0200197D
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016CE68: CC220057 0200197E
	s_waitcnt lgkmcnt(3)                                       // 00000016CE70: BF89FC37
	v_fma_mixlo_f16 v88, v127, s12, 0                          // 00000016CE74: CC210058 0200197F
	v_fma_mixhi_f16 v88, v128, s12, 0                          // 00000016CE7C: CC220058 02001980
	v_fma_mixlo_f16 v89, v129, s12, 0                          // 00000016CE84: CC210059 02001981
	v_fma_mixhi_f16 v89, v130, s12, 0                          // 00000016CE8C: CC220059 02001982
	ds_load_b128 v[119:122], v101 offset:8864                  // 00000016CE94: DBFC22A0 77000065
	ds_load_b128 v[123:126], v101 offset:8880                  // 00000016CE9C: DBFC22B0 7B000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016CEA4: CC40401A 1C6A950A
	s_waitcnt lgkmcnt(4)                                       // 00000016CEAC: BF89FC47
	v_fma_mixlo_f16 v60, v115, s12, 0                          // 00000016CEB0: CC21003C 02001973
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016CEB8: CC404032 1CCAA50A
	v_fma_mixhi_f16 v60, v116, s12, 0                          // 00000016CEC0: CC22003C 02001974
	v_fma_mixlo_f16 v61, v117, s12, 0                          // 00000016CEC8: CC21003D 02001975
	v_fma_mixhi_f16 v61, v118, s12, 0                          // 00000016CED0: CC22003D 02001976
	ds_load_b128 v[70:73], v101 offset:17312                   // 00000016CED8: DBFC43A0 46000065
	ds_load_b128 v[74:77], v101 offset:17328                   // 00000016CEE0: DBFC43B0 4A000065
	s_waitcnt lgkmcnt(5)                                       // 00000016CEE8: BF89FC57
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016CEEC: CC210042 02001942
	ds_load_b128 v[78:81], v101 offset:25728                   // 00000016CEF4: DBFC6480 4E000065
	ds_load_b128 v[82:85], v101 offset:25744                   // 00000016CEFC: DBFC6490 52000065
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016CF04: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016CF0C: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016CF14: CC220043 02001945
	s_waitcnt lgkmcnt(6)                                       // 00000016CF1C: BF89FC67
	v_fma_mixlo_f16 v68, v3, s12, 0                            // 00000016CF20: CC210044 02001903
	v_fma_mixhi_f16 v68, v4, s12, 0                            // 00000016CF28: CC220044 02001904
	v_fma_mixlo_f16 v69, v5, s12, 0                            // 00000016CF30: CC210045 02001905
	v_fma_mixhi_f16 v69, v6, s12, 0                            // 00000016CF38: CC220045 02001906
	ds_load_b128 v[3:6], v101 offset:25760                     // 00000016CF40: DBFC64A0 03000065
	ds_load_b128 v[86:89], v101 offset:25776                   // 00000016CF48: DBFC64B0 56000065
	ds_load_b128 v[115:118], v101 offset:448                   // 00000016CF50: DBFC01C0 73000065
	s_waitcnt lgkmcnt(8)                                       // 00000016CF58: BF89FC87
	v_fma_mixlo_f16 v62, v119, s12, 0                          // 00000016CF5C: CC21003E 02001977
	v_fma_mixhi_f16 v62, v120, s12, 0                          // 00000016CF64: CC22003E 02001978
	v_fma_mixlo_f16 v63, v121, s12, 0                          // 00000016CF6C: CC21003F 02001979
	v_fma_mixhi_f16 v63, v122, s12, 0                          // 00000016CF74: CC22003F 0200197A
	ds_load_b128 v[119:122], v101 offset:464                   // 00000016CF7C: DBFC01D0 77000065
	s_waitcnt lgkmcnt(7)                                       // 00000016CF84: BF89FC77
	v_fma_mixlo_f16 v70, v70, s12, 0                           // 00000016CF88: CC210046 02001946
	v_fma_mixhi_f16 v70, v71, s12, 0                           // 00000016CF90: CC220046 02001947
	v_fma_mixlo_f16 v71, v72, s12, 0                           // 00000016CF98: CC210047 02001948
	v_fma_mixhi_f16 v71, v73, s12, 0                           // 00000016CFA0: CC220047 02001949
	s_waitcnt lgkmcnt(6)                                       // 00000016CFA8: BF89FC67
	v_fma_mixlo_f16 v72, v74, s12, 0                           // 00000016CFAC: CC210048 0200194A
	v_fma_mixlo_f16 v73, v76, s12, 0                           // 00000016CFB4: CC210049 0200194C
	s_waitcnt lgkmcnt(5)                                       // 00000016CFBC: BF89FC57
	v_fma_mixlo_f16 v74, v78, s12, 0                           // 00000016CFC0: CC21004A 0200194E
	v_fma_mixhi_f16 v74, v79, s12, 0                           // 00000016CFC8: CC22004A 0200194F
	s_waitcnt lgkmcnt(4)                                       // 00000016CFD0: BF89FC47
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016CFD4: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016CFDC: CC22004C 02001953
	v_fma_mixhi_f16 v72, v75, s12, 0                           // 00000016CFE4: CC220048 0200194B
	v_fma_mixhi_f16 v75, v81, s12, 0                           // 00000016CFEC: CC22004B 02001951
	s_waitcnt lgkmcnt(3)                                       // 00000016CFF4: BF89FC37
	v_fma_mixlo_f16 v78, v3, s12, 0                            // 00000016CFF8: CC21004E 02001903
	v_fma_mixhi_f16 v78, v4, s12, 0                            // 00000016D000: CC22004E 02001904
	v_fma_mixlo_f16 v79, v5, s12, 0                            // 00000016D008: CC21004F 02001905
	v_fma_mixhi_f16 v79, v6, s12, 0                            // 00000016D010: CC22004F 02001906
	ds_load_b128 v[3:6], v101 offset:496                       // 00000016D018: DBFC01F0 03000065
	s_waitcnt lgkmcnt(2)                                       // 00000016D020: BF89FC27
	v_fma_mixlo_f16 v82, v115, s12, 0                          // 00000016D024: CC210052 02001973
	v_fma_mixhi_f16 v82, v116, s12, 0                          // 00000016D02C: CC220052 02001974
	v_fma_mixlo_f16 v83, v117, s12, 0                          // 00000016D034: CC210053 02001975
	v_fma_mixhi_f16 v83, v118, s12, 0                          // 00000016D03C: CC220053 02001976
	ds_load_b128 v[115:118], v101 offset:8896                  // 00000016D044: DBFC22C0 73000065
	v_fma_mixlo_f16 v64, v123, s12, 0                          // 00000016D04C: CC210040 0200197B
	v_fma_mixhi_f16 v64, v124, s12, 0                          // 00000016D054: CC220040 0200197C
	v_fma_mixlo_f16 v65, v125, s12, 0                          // 00000016D05C: CC210041 0200197D
	v_fma_mixhi_f16 v65, v126, s12, 0                          // 00000016D064: CC220041 0200197E
	ds_load_b128 v[123:126], v101 offset:480                   // 00000016D06C: DBFC01E0 7B000065
	v_fma_mixlo_f16 v81, v88, s12, 0                           // 00000016D074: CC210051 02001958
	v_fma_mixhi_f16 v81, v89, s12, 0                           // 00000016D07C: CC220051 02001959
	v_fma_mixhi_f16 v73, v77, s12, 0                           // 00000016D084: CC220049 0200194D
	v_fma_mixlo_f16 v75, v80, s12, 0                           // 00000016D08C: CC21004B 02001950
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016D094: CC21004D 02001954
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016D09C: CC22004D 02001955
	v_fma_mixlo_f16 v80, v86, s12, 0                           // 00000016D0A4: CC210050 02001956
	v_fma_mixhi_f16 v80, v87, s12, 0                           // 00000016D0AC: CC220050 02001957
	s_waitcnt lgkmcnt(3)                                       // 00000016D0B4: BF89FC37
	v_fma_mixlo_f16 v84, v119, s12, 0                          // 00000016D0B8: CC210054 02001977
	s_waitcnt lgkmcnt(2)                                       // 00000016D0C0: BF89FC27
	v_fma_mixlo_f16 v88, v3, s12, 0                            // 00000016D0C4: CC210058 02001903
	v_fma_mixhi_f16 v88, v4, s12, 0                            // 00000016D0CC: CC220058 02001904
	v_fma_mixlo_f16 v89, v5, s12, 0                            // 00000016D0D4: CC210059 02001905
	v_fma_mixhi_f16 v89, v6, s12, 0                            // 00000016D0DC: CC220059 02001906
	ds_load_b128 v[3:6], v101 offset:8944                      // 00000016D0E4: DBFC22F0 03000065
	v_fma_mixhi_f16 v84, v120, s12, 0                          // 00000016D0EC: CC220054 02001978
	v_fma_mixlo_f16 v85, v121, s12, 0                          // 00000016D0F4: CC210055 02001979
	v_fma_mixhi_f16 v85, v122, s12, 0                          // 00000016D0FC: CC220055 0200197A
	ds_load_b128 v[119:122], v101 offset:8912                  // 00000016D104: DBFC22D0 77000065
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016D10C: CC404022 1C8A750A
	s_waitcnt lgkmcnt(2)                                       // 00000016D114: BF89FC27
	v_fma_mixlo_f16 v86, v123, s12, 0                          // 00000016D118: CC210056 0200197B
	v_fma_mixhi_f16 v86, v124, s12, 0                          // 00000016D120: CC220056 0200197C
	v_fma_mixlo_f16 v87, v125, s12, 0                          // 00000016D128: CC210057 0200197D
	v_fma_mixhi_f16 v87, v126, s12, 0                          // 00000016D130: CC220057 0200197E
	ds_load_b128 v[123:126], v101 offset:8928                  // 00000016D138: DBFC22E0 7B000065
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016D140: CC40402A 1CAA850A
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016D148: CC40401A 1C6A950A
	v_fma_mixlo_f16 v58, v115, s12, 0                          // 00000016D150: CC21003A 02001973
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[82:89], v[50:57]// 00000016D158: CC404032 1CCAA50A
	ds_load_b128 v[66:69], v101 offset:17344                   // 00000016D160: DBFC43C0 42000065
	v_fma_mixhi_f16 v58, v116, s12, 0                          // 00000016D168: CC22003A 02001974
	v_fma_mixlo_f16 v59, v117, s12, 0                          // 00000016D170: CC21003B 02001975
	v_fma_mixhi_f16 v59, v118, s12, 0                          // 00000016D178: CC22003B 02001976
	ds_load_b128 v[70:73], v101 offset:17360                   // 00000016D180: DBFC43D0 46000065
	ds_load_b128 v[74:77], v101 offset:17376                   // 00000016D188: DBFC43E0 4A000065
	s_waitcnt lgkmcnt(5)                                       // 00000016D190: BF89FC57
	v_fma_mixlo_f16 v64, v3, s12, 0                            // 00000016D194: CC210040 02001903
	ds_load_b128 v[78:81], v101 offset:17392                   // 00000016D19C: DBFC43F0 4E000065
	v_fma_mixhi_f16 v64, v4, s12, 0                            // 00000016D1A4: CC220040 02001904
	v_fma_mixlo_f16 v65, v5, s12, 0                            // 00000016D1AC: CC210041 02001905
	v_fma_mixhi_f16 v65, v6, s12, 0                            // 00000016D1B4: CC220041 02001906
	ds_load_b128 v[3:6], v101 offset:25792                     // 00000016D1BC: DBFC64C0 03000065
	ds_load_b128 v[82:85], v101 offset:25808                   // 00000016D1C4: DBFC64D0 52000065
	ds_load_b128 v[86:89], v101 offset:25824                   // 00000016D1CC: DBFC64E0 56000065
	ds_load_b128 v[115:118], v101 offset:25840                 // 00000016D1D4: DBFC64F0 73000065
	s_waitcnt lgkmcnt(9)                                       // 00000016D1DC: BF89FC97
	v_fma_mixlo_f16 v60, v119, s12, 0                          // 00000016D1E0: CC21003C 02001977
	v_fma_mixhi_f16 v60, v120, s12, 0                          // 00000016D1E8: CC22003C 02001978
	v_fma_mixlo_f16 v61, v121, s12, 0                          // 00000016D1F0: CC21003D 02001979
	v_fma_mixhi_f16 v61, v122, s12, 0                          // 00000016D1F8: CC22003D 0200197A
	s_waitcnt lgkmcnt(8)                                       // 00000016D200: BF89FC87
	v_fma_mixlo_f16 v62, v123, s12, 0                          // 00000016D204: CC21003E 0200197B
	v_fma_mixhi_f16 v62, v124, s12, 0                          // 00000016D20C: CC22003E 0200197C
	v_fma_mixlo_f16 v63, v125, s12, 0                          // 00000016D214: CC21003F 0200197D
	v_fma_mixhi_f16 v63, v126, s12, 0                          // 00000016D21C: CC22003F 0200197E
	s_waitcnt lgkmcnt(7)                                       // 00000016D224: BF89FC77
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016D228: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016D230: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016D238: CC210043 02001944
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016D240: CC220043 02001945
	s_waitcnt lgkmcnt(6)                                       // 00000016D248: BF89FC67
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016D24C: CC210044 02001946
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016D254: CC220044 02001947
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016D25C: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016D264: CC220045 02001949
	s_waitcnt lgkmcnt(5)                                       // 00000016D26C: BF89FC57
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016D270: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016D278: CC220046 0200194B
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016D280: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016D288: CC220047 0200194D
	s_waitcnt lgkmcnt(4)                                       // 00000016D290: BF89FC47
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016D294: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016D29C: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016D2A4: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016D2AC: CC220049 02001951
	s_waitcnt lgkmcnt(3)                                       // 00000016D2B4: BF89FC37
	v_fma_mixlo_f16 v74, v3, s12, 0                            // 00000016D2B8: CC21004A 02001903
	v_fma_mixhi_f16 v74, v4, s12, 0                            // 00000016D2C0: CC22004A 02001904
	v_fma_mixlo_f16 v75, v5, s12, 0                            // 00000016D2C8: CC21004B 02001905
	v_fma_mixhi_f16 v75, v6, s12, 0                            // 00000016D2D0: CC22004B 02001906
	s_waitcnt lgkmcnt(2)                                       // 00000016D2D8: BF89FC27
	v_fma_mixlo_f16 v76, v82, s12, 0                           // 00000016D2DC: CC21004C 02001952
	v_fma_mixhi_f16 v76, v83, s12, 0                           // 00000016D2E4: CC22004C 02001953
	v_fma_mixlo_f16 v77, v84, s12, 0                           // 00000016D2EC: CC21004D 02001954
	v_fma_mixhi_f16 v77, v85, s12, 0                           // 00000016D2F4: CC22004D 02001955
	s_waitcnt lgkmcnt(1)                                       // 00000016D2FC: BF89FC17
	v_fma_mixlo_f16 v78, v86, s12, 0                           // 00000016D300: CC21004E 02001956
	v_fma_mixhi_f16 v78, v87, s12, 0                           // 00000016D308: CC22004E 02001957
	v_fma_mixlo_f16 v79, v88, s12, 0                           // 00000016D310: CC21004F 02001958
	v_fma_mixhi_f16 v79, v89, s12, 0                           // 00000016D318: CC22004F 02001959
	s_waitcnt lgkmcnt(0)                                       // 00000016D320: BF89FC07
	v_fma_mixlo_f16 v80, v115, s12, 0                          // 00000016D324: CC210050 02001973
	v_fma_mixhi_f16 v80, v116, s12, 0                          // 00000016D32C: CC220050 02001974
	v_fma_mixlo_f16 v81, v117, s12, 0                          // 00000016D334: CC210051 02001975
	v_fma_mixhi_f16 v81, v118, s12, 0                          // 00000016D33C: CC220051 02001976
	v_add_nc_u32_e32 v5, s18, v102                             // 00000016D344: 4A0ACC12
	.long 0x7e063880                                           // 00000016D348: 7E063880
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[34:41]// 00000016D34C: CC404022 1C8A750A
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[66:73], v[42:49]// 00000016D354: CC40402A 1CAA850A
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[74:81], v[26:33]// 00000016D35C: CC40401A 1C6A950A
	.long 0xd4440000                                           // 00000016D364: D4440000
	v_cndmask_b32_e32 v1, s41, v5, vcc_lo                      // 00000016D368: 02020A29
	.long 0x7f063903                                           // 00000016D36C: 7F063903
	s_and_saveexec_b32 s4, s0                                  // 00000016D370: BE842000
	s_cbranch_execz 17                                         // 00000016D374: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cbc>
	v_mad_u64_u32 v[6:7], null, v5, 48, s[2:3]                 // 00000016D378: D6FE7C06 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D380: BF870091
	.long 0xd73c0006                                           // 00000016D384: D73C0006
	v_cndmask_b32_e32 v1, 9, v6, vcc_lo                        // 00000016D388: 02020C89
	.long 0xd7000106                                           // 00000016D38C: D7000106
	v_cndmask_b32_e32 v1, v108, v6, vcc_lo                     // 00000016D390: 02020D6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D394: BF8700C1
	v_add_co_ci_u32_e64 v7, null, v109, v7, s1                 // 00000016D398: D5207C07 00060F6D
	global_load_b32 v4, v[6:7], off                            // 00000016D3A0: DC520000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000016D3A8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v50                         // 00000016D3AC: 560864FF BB800000
	v_fma_mixhi_f16 v3, v4, s12, 0                             // 00000016D3B4: CC220003 02001904
	s_or_b32 exec_lo, exec_lo, s4                              // 00000016D3BC: 8C7E047E
	v_add_nc_u32_e32 v6, 2, v5                                 // 00000016D3C0: 4A0C0A82
	ds_store_b16_d16_hi v110, v3                               // 00000016D3C4: DA840000 0000036E
	.long 0xd4440001                                           // 00000016D3CC: D4440001
	v_cndmask_b32_e32 v1, s41, v6, vcc_lo                      // 00000016D3D0: 02020C29
	s_and_saveexec_b32 s5, s1                                  // 00000016D3D4: BE852001
	s_cbranch_execz 17                                         // 00000016D3D8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d20>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000016D3DC: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D3E4: BF870091
	.long 0xd73c0003                                           // 00000016D3E8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D3EC: 02020689
	.long 0xd7000403                                           // 00000016D3F0: D7000403
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D3F4: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D3F8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s4                 // 00000016D3FC: D5207C04 0012096D
	global_load_b32 v3, v[3:4], off                            // 00000016D404: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D40C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v51                         // 00000016D410: 560666FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016D418: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s5                              // 00000016D420: 8C7E057E
	v_add_nc_u32_e32 v7, 4, v5                                 // 00000016D424: 4A0E0A84
	.long 0x7f063880                                           // 00000016D428: 7F063880
	ds_store_b16 v110, v3 offset:4                             // 00000016D42C: D87C0004 0000036E
	.long 0xd4440004                                           // 00000016D434: D4440004
	v_cndmask_b32_e32 v1, s41, v7, vcc_lo                      // 00000016D438: 02020E29
	.long 0x7e083983                                           // 00000016D43C: 7E083983
	s_and_saveexec_b32 s6, s4                                  // 00000016D440: BE862004
	s_cbranch_execz 17                                         // 00000016D444: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d8c>
	v_mad_u64_u32 v[8:9], null, v7, 48, s[2:3]                 // 00000016D448: D6FE7C08 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D450: BF870091
	.long 0xd73c0008                                           // 00000016D454: D73C0008
	v_cndmask_b32_e32 v1, 9, v8, vcc_lo                        // 00000016D458: 02021089
	.long 0xd7000508                                           // 00000016D45C: D7000508
	v_cndmask_b32_e32 v1, v108, v8, vcc_lo                     // 00000016D460: 0202116C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D464: BF8700C1
	v_add_co_ci_u32_e64 v9, null, v109, v9, s5                 // 00000016D468: D5207C09 0016136D
	global_load_b32 v4, v[8:9], off                            // 00000016D470: DC520000 047C0008
	s_waitcnt vmcnt(0)                                         // 00000016D478: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v52                         // 00000016D47C: 560868FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D484: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016D48C: 8C7E067E
	v_add_nc_u32_e32 v8, 6, v5                                 // 00000016D490: 4A100A86
	ds_store_b16 v110, v4 offset:8                             // 00000016D494: D87C0008 0000046E
	.long 0xd4440005                                           // 00000016D49C: D4440005
	v_cndmask_b32_e32 v1, s41, v8, vcc_lo                      // 00000016D4A0: 02021029
	s_and_saveexec_b32 s7, s5                                  // 00000016D4A4: BE872005
	s_cbranch_execz 17                                         // 00000016D4A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1df0>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000016D4AC: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D4B4: BF870091
	.long 0xd73c0003                                           // 00000016D4B8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D4BC: 02020689
	.long 0xd7000603                                           // 00000016D4C0: D7000603
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D4C4: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D4C8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s6                 // 00000016D4CC: D5207C04 001A096D
	global_load_b32 v3, v[3:4], off                            // 00000016D4D4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D4DC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v53                         // 00000016D4E0: 56066AFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016D4E8: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s7                              // 00000016D4F0: 8C7E077E
	v_add_nc_u32_e32 v9, 8, v5                                 // 00000016D4F4: 4A120A88
	.long 0x7e083880                                           // 00000016D4F8: 7E083880
	ds_store_b16_d16_hi v110, v3 offset:12                     // 00000016D4FC: DA84000C 0000036E
	.long 0xd4440006                                           // 00000016D504: D4440006
	v_cndmask_b32_e32 v1, s41, v9, vcc_lo                      // 00000016D508: 02021229
	.long 0x7e063904                                           // 00000016D50C: 7E063904
	s_and_saveexec_b32 s8, s6                                  // 00000016D510: BE882006
	s_cbranch_execz 17                                         // 00000016D514: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e5c>
	v_mad_u64_u32 v[50:51], null, v9, 48, s[2:3]               // 00000016D518: D6FE7C32 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D520: BF870091
	.long 0xd73c0032                                           // 00000016D524: D73C0032
	v_cndmask_b32_e32 v1, 9, v50, vcc_lo                       // 00000016D528: 02026489
	.long 0xd7000732                                           // 00000016D52C: D7000732
	v_cndmask_b32_e32 v1, v108, v50, vcc_lo                    // 00000016D530: 0202656C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D534: BF8700C1
	v_add_co_ci_u32_e64 v51, null, v109, v51, s7               // 00000016D538: D5207C33 001E676D
	global_load_b32 v3, v[50:51], off                          // 00000016D540: DC520000 037C0032
	s_waitcnt vmcnt(0)                                         // 00000016D548: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v54                         // 00000016D54C: 56066CFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016D554: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s8                              // 00000016D55C: 8C7E087E
	v_add_nc_u32_e32 v115, 10, v5                              // 00000016D560: 4AE60A8A
	ds_store_b16 v110, v3 offset:16                            // 00000016D564: D87C0010 0000036E
	.long 0xd4440007                                           // 00000016D56C: D4440007
	v_cndmask_b32_e32 v1, s41, v115, vcc_lo                    // 00000016D570: 0202E629
	s_and_saveexec_b32 s9, s7                                  // 00000016D574: BE892007
	s_cbranch_execz 17                                         // 00000016D578: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	v_mad_u64_u32 v[3:4], null, v115, 48, s[2:3]               // 00000016D57C: D6FE7C03 00096173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D584: BF870091
	.long 0xd73c0003                                           // 00000016D588: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D58C: 02020689
	.long 0xd7000803                                           // 00000016D590: D7000803
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D594: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D598: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s8                 // 00000016D59C: D5207C04 0022096D
	global_load_b32 v3, v[3:4], off                            // 00000016D5A4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D5AC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v55                         // 00000016D5B0: 56066EFF BB800000
	v_fma_mixlo_f16 v4, v3, s12, 0                             // 00000016D5B8: CC210004 02001903
	s_or_b32 exec_lo, exec_lo, s9                              // 00000016D5C0: 8C7E097E
	v_add_nc_u32_e32 v116, 12, v5                              // 00000016D5C4: 4AE80A8C
	.long 0x7e063880                                           // 00000016D5C8: 7E063880
	ds_store_b16 v110, v4 offset:20                            // 00000016D5CC: D87C0014 0000046E
	.long 0xd4440008                                           // 00000016D5D4: D4440008
	v_cndmask_b32_e32 v1, s41, v116, vcc_lo                    // 00000016D5D8: 0202E829
	.long 0x7f063903                                           // 00000016D5DC: 7F063903
	s_and_saveexec_b32 s10, s8                                 // 00000016D5E0: BE8A2008
	s_cbranch_execz 17                                         // 00000016D5E4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f2c>
	v_mad_u64_u32 v[50:51], null, v116, 48, s[2:3]             // 00000016D5E8: D6FE7C32 00096174
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D5F0: BF870091
	.long 0xd73c0032                                           // 00000016D5F4: D73C0032
	v_cndmask_b32_e32 v1, 9, v50, vcc_lo                       // 00000016D5F8: 02026489
	.long 0xd7000932                                           // 00000016D5FC: D7000932
	v_cndmask_b32_e32 v1, v108, v50, vcc_lo                    // 00000016D600: 0202656C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D604: BF8700C1
	v_add_co_ci_u32_e64 v51, null, v109, v51, s9               // 00000016D608: D5207C33 0026676D
	global_load_b32 v4, v[50:51], off                          // 00000016D610: DC520000 047C0032
	s_waitcnt vmcnt(0)                                         // 00000016D618: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v56                         // 00000016D61C: 560870FF BB800000
	v_fma_mixhi_f16 v3, v4, s12, 0                             // 00000016D624: CC220003 02001904
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016D62C: 8C7E0A7E
	v_add_nc_u32_e32 v117, 14, v5                              // 00000016D630: 4AEA0A8E
	ds_store_b16_d16_hi v110, v3 offset:24                     // 00000016D634: DA840018 0000036E
	.long 0xd4440009                                           // 00000016D63C: D4440009
	v_cndmask_b32_e32 v1, s41, v117, vcc_lo                    // 00000016D640: 0202EA29
	s_and_saveexec_b32 s11, s9                                 // 00000016D644: BE8B2009
	s_cbranch_execz 17                                         // 00000016D648: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f90>
	v_mad_u64_u32 v[3:4], null, v117, 48, s[2:3]               // 00000016D64C: D6FE7C03 00096175
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D654: BF870091
	.long 0xd73c0003                                           // 00000016D658: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D65C: 02020689
	.long 0xd7000a03                                           // 00000016D660: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D664: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D668: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016D66C: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off                            // 00000016D674: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D67C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v57                         // 00000016D680: 560672FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016D688: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D690: 8C7E0B7E
	.long 0x7f063880                                           // 00000016D694: 7F063880
	ds_store_b16 v110, v3 offset:28                            // 00000016D698: D87C001C 0000036E
	.long 0x7e083983                                           // 00000016D6A0: 7E083983
	s_and_saveexec_b32 s11, s0                                 // 00000016D6A4: BE8B2000
	s_cbranch_execz 17                                         // 00000016D6A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ff0>
	v_mad_u64_u32 v[50:51], null, v5, 48, s[2:3]               // 00000016D6AC: D6FE7C32 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D6B4: BF870091
	.long 0xd73c0032                                           // 00000016D6B8: D73C0032
	v_cndmask_b32_e32 v1, 9, v50, vcc_lo                       // 00000016D6BC: 02026489
	.long 0xd7000a32                                           // 00000016D6C0: D7000A32
	v_cndmask_b32_e32 v1, v108, v50, vcc_lo                    // 00000016D6C4: 0202656C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D6C8: BF8700C1
	v_add_co_ci_u32_e64 v51, null, v109, v51, s10              // 00000016D6CC: D5207C33 002A676D
	global_load_b32 v4, v[50:51], off offset:64                // 00000016D6D4: DC520040 047C0032
	s_waitcnt vmcnt(0)                                         // 00000016D6DC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v34                         // 00000016D6E0: 560844FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D6E8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D6F0: 8C7E0B7E
	ds_store_b16 v110, v4 offset:2560                          // 00000016D6F4: D87C0A00 0000046E
	s_and_saveexec_b32 s11, s1                                 // 00000016D6FC: BE8B2001
	s_cbranch_execz 17                                         // 00000016D700: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2048>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000016D704: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D70C: BF870091
	.long 0xd73c0003                                           // 00000016D710: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D714: 02020689
	.long 0xd7000a03                                           // 00000016D718: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D71C: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D720: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016D724: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:64                  // 00000016D72C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D734: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v35                         // 00000016D738: 560646FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016D740: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D748: 8C7E0B7E
	.long 0x7e063880                                           // 00000016D74C: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:2564                   // 00000016D750: DA840A04 0000036E
	.long 0x7e083903                                           // 00000016D758: 7E083903
	s_and_saveexec_b32 s11, s4                                 // 00000016D75C: BE8B2004
	s_cbranch_execz 17                                         // 00000016D760: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20a8>
	v_mad_u64_u32 v[34:35], null, v7, 48, s[2:3]               // 00000016D764: D6FE7C22 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D76C: BF870091
	.long 0xd73c0022                                           // 00000016D770: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016D774: 02024489
	.long 0xd7000a22                                           // 00000016D778: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016D77C: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D780: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016D784: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:64                // 00000016D78C: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016D794: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v36                         // 00000016D798: 560848FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D7A0: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D7A8: 8C7E0B7E
	ds_store_b16 v110, v4 offset:2568                          // 00000016D7AC: D87C0A08 0000046E
	s_and_saveexec_b32 s11, s5                                 // 00000016D7B4: BE8B2005
	s_cbranch_execz 17                                         // 00000016D7B8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000016D7BC: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D7C4: BF870091
	.long 0xd73c0003                                           // 00000016D7C8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D7CC: 02020689
	.long 0xd7000a03                                           // 00000016D7D0: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D7D4: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D7D8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016D7DC: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:64                  // 00000016D7E4: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D7EC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v37                         // 00000016D7F0: 56064AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016D7F8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D800: 8C7E0B7E
	.long 0x7f063880                                           // 00000016D804: 7F063880
	ds_store_b16 v110, v3 offset:2572                          // 00000016D808: D87C0A0C 0000036E
	.long 0x7e083983                                           // 00000016D810: 7E083983
	s_and_saveexec_b32 s11, s6                                 // 00000016D814: BE8B2006
	s_cbranch_execz 17                                         // 00000016D818: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2160>
	v_mad_u64_u32 v[34:35], null, v9, 48, s[2:3]               // 00000016D81C: D6FE7C22 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D824: BF870091
	.long 0xd73c0022                                           // 00000016D828: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016D82C: 02024489
	.long 0xd7000a22                                           // 00000016D830: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016D834: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D838: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016D83C: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:64                // 00000016D844: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016D84C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v38                         // 00000016D850: 56084CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D858: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D860: 8C7E0B7E
	ds_store_b16 v110, v4 offset:2576                          // 00000016D864: D87C0A10 0000046E
	s_and_saveexec_b32 s11, s7                                 // 00000016D86C: BE8B2007
	s_cbranch_execz 17                                         // 00000016D870: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21b8>
	v_mad_u64_u32 v[3:4], null, v115, 48, s[2:3]               // 00000016D874: D6FE7C03 00096173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D87C: BF870091
	.long 0xd73c0003                                           // 00000016D880: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D884: 02020689
	.long 0xd7000a03                                           // 00000016D888: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D88C: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D890: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016D894: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:64                  // 00000016D89C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D8A4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v39                         // 00000016D8A8: 56064EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016D8B0: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D8B8: 8C7E0B7E
	.long 0x7e063880                                           // 00000016D8BC: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:2580                   // 00000016D8C0: DA840A14 0000036E
	.long 0x7e083903                                           // 00000016D8C8: 7E083903
	s_and_saveexec_b32 s11, s8                                 // 00000016D8CC: BE8B2008
	s_cbranch_execz 17                                         // 00000016D8D0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2218>
	v_mad_u64_u32 v[34:35], null, v116, 48, s[2:3]             // 00000016D8D4: D6FE7C22 00096174
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D8DC: BF870091
	.long 0xd73c0022                                           // 00000016D8E0: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016D8E4: 02024489
	.long 0xd7000a22                                           // 00000016D8E8: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016D8EC: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D8F0: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016D8F4: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:64                // 00000016D8FC: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016D904: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v40                         // 00000016D908: 560850FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D910: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D918: 8C7E0B7E
	ds_store_b16 v110, v4 offset:2584                          // 00000016D91C: D87C0A18 0000046E
	s_and_saveexec_b32 s11, s9                                 // 00000016D924: BE8B2009
	s_cbranch_execz 17                                         // 00000016D928: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2270>
	v_mad_u64_u32 v[3:4], null, v117, 48, s[2:3]               // 00000016D92C: D6FE7C03 00096175
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D934: BF870091
	.long 0xd73c0003                                           // 00000016D938: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D93C: 02020689
	.long 0xd7000a03                                           // 00000016D940: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D944: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D948: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016D94C: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:64                  // 00000016D954: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016D95C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v41                         // 00000016D960: 560652FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016D968: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D970: 8C7E0B7E
	.long 0x7f063880                                           // 00000016D974: 7F063880
	ds_store_b16 v110, v3 offset:2588                          // 00000016D978: D87C0A1C 0000036E
	.long 0x7e083983                                           // 00000016D980: 7E083983
	s_and_saveexec_b32 s11, s0                                 // 00000016D984: BE8B2000
	s_cbranch_execz 17                                         // 00000016D988: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22d0>
	v_mad_u64_u32 v[34:35], null, v5, 48, s[2:3]               // 00000016D98C: D6FE7C22 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D994: BF870091
	.long 0xd73c0022                                           // 00000016D998: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016D99C: 02024489
	.long 0xd7000a22                                           // 00000016D9A0: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016D9A4: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016D9A8: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016D9AC: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:128               // 00000016D9B4: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016D9BC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v42                         // 00000016D9C0: 560854FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016D9C8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016D9D0: 8C7E0B7E
	ds_store_b16 v110, v4 offset:5120                          // 00000016D9D4: D87C1400 0000046E
	s_and_saveexec_b32 s11, s1                                 // 00000016D9DC: BE8B2001
	s_cbranch_execz 17                                         // 00000016D9E0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2328>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000016D9E4: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016D9EC: BF870091
	.long 0xd73c0003                                           // 00000016D9F0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016D9F4: 02020689
	.long 0xd7000a03                                           // 00000016D9F8: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016D9FC: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DA00: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DA04: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016DA0C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DA14: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v43                         // 00000016DA18: 560656FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016DA20: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DA28: 8C7E0B7E
	.long 0x7e063880                                           // 00000016DA2C: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:5124                   // 00000016DA30: DA841404 0000036E
	.long 0x7e083903                                           // 00000016DA38: 7E083903
	s_and_saveexec_b32 s11, s4                                 // 00000016DA3C: BE8B2004
	s_cbranch_execz 17                                         // 00000016DA40: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2388>
	v_mad_u64_u32 v[34:35], null, v7, 48, s[2:3]               // 00000016DA44: D6FE7C22 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DA4C: BF870091
	.long 0xd73c0022                                           // 00000016DA50: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016DA54: 02024489
	.long 0xd7000a22                                           // 00000016DA58: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016DA5C: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DA60: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016DA64: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:128               // 00000016DA6C: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016DA74: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v44                         // 00000016DA78: 560858FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DA80: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DA88: 8C7E0B7E
	ds_store_b16 v110, v4 offset:5128                          // 00000016DA8C: D87C1408 0000046E
	s_and_saveexec_b32 s11, s5                                 // 00000016DA94: BE8B2005
	s_cbranch_execz 17                                         // 00000016DA98: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e0>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000016DA9C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DAA4: BF870091
	.long 0xd73c0003                                           // 00000016DAA8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DAAC: 02020689
	.long 0xd7000a03                                           // 00000016DAB0: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DAB4: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DAB8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DABC: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016DAC4: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DACC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v45                         // 00000016DAD0: 56065AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016DAD8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DAE0: 8C7E0B7E
	.long 0x7f063880                                           // 00000016DAE4: 7F063880
	ds_store_b16 v110, v3 offset:5132                          // 00000016DAE8: D87C140C 0000036E
	.long 0x7e083983                                           // 00000016DAF0: 7E083983
	s_and_saveexec_b32 s11, s6                                 // 00000016DAF4: BE8B2006
	s_cbranch_execz 17                                         // 00000016DAF8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	v_mad_u64_u32 v[34:35], null, v9, 48, s[2:3]               // 00000016DAFC: D6FE7C22 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DB04: BF870091
	.long 0xd73c0022                                           // 00000016DB08: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016DB0C: 02024489
	.long 0xd7000a22                                           // 00000016DB10: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016DB14: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DB18: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016DB1C: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:128               // 00000016DB24: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016DB2C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v46                         // 00000016DB30: 56085CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DB38: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DB40: 8C7E0B7E
	ds_store_b16 v110, v4 offset:5136                          // 00000016DB44: D87C1410 0000046E
	s_and_saveexec_b32 s11, s7                                 // 00000016DB4C: BE8B2007
	s_cbranch_execz 17                                         // 00000016DB50: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2498>
	v_mad_u64_u32 v[3:4], null, v115, 48, s[2:3]               // 00000016DB54: D6FE7C03 00096173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DB5C: BF870091
	.long 0xd73c0003                                           // 00000016DB60: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DB64: 02020689
	.long 0xd7000a03                                           // 00000016DB68: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DB6C: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DB70: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DB74: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016DB7C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DB84: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v47                         // 00000016DB88: 56065EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016DB90: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DB98: 8C7E0B7E
	.long 0x7e063880                                           // 00000016DB9C: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:5140                   // 00000016DBA0: DA841414 0000036E
	.long 0x7e083903                                           // 00000016DBA8: 7E083903
	s_and_saveexec_b32 s11, s8                                 // 00000016DBAC: BE8B2008
	s_cbranch_execz 17                                         // 00000016DBB0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24f8>
	v_mad_u64_u32 v[34:35], null, v116, 48, s[2:3]             // 00000016DBB4: D6FE7C22 00096174
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DBBC: BF870091
	.long 0xd73c0022                                           // 00000016DBC0: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016DBC4: 02024489
	.long 0xd7000a22                                           // 00000016DBC8: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016DBCC: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DBD0: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016DBD4: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:128               // 00000016DBDC: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016DBE4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v48                         // 00000016DBE8: 560860FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DBF0: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DBF8: 8C7E0B7E
	ds_store_b16 v110, v4 offset:5144                          // 00000016DBFC: D87C1418 0000046E
	s_and_saveexec_b32 s11, s9                                 // 00000016DC04: BE8B2009
	s_cbranch_execz 17                                         // 00000016DC08: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2550>
	v_mad_u64_u32 v[3:4], null, v117, 48, s[2:3]               // 00000016DC0C: D6FE7C03 00096175
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DC14: BF870091
	.long 0xd73c0003                                           // 00000016DC18: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DC1C: 02020689
	.long 0xd7000a03                                           // 00000016DC20: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DC24: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DC28: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DC2C: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016DC34: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DC3C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v49                         // 00000016DC40: 560662FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016DC48: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DC50: 8C7E0B7E
	.long 0x7f063880                                           // 00000016DC54: 7F063880
	ds_store_b16 v110, v3 offset:5148                          // 00000016DC58: D87C141C 0000036E
	.long 0x7e083983                                           // 00000016DC60: 7E083983
	s_and_saveexec_b32 s11, s0                                 // 00000016DC64: BE8B2000
	s_cbranch_execz 17                                         // 00000016DC68: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25b0>
	v_mad_u64_u32 v[34:35], null, v5, 48, s[2:3]               // 00000016DC6C: D6FE7C22 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DC74: BF870091
	.long 0xd73c0022                                           // 00000016DC78: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016DC7C: 02024489
	.long 0xd7000a22                                           // 00000016DC80: D7000A22
	v_cndmask_b32_e32 v1, v108, v34, vcc_lo                    // 00000016DC84: 0202456C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DC88: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v109, v35, s10              // 00000016DC8C: D5207C23 002A476D
	global_load_b32 v4, v[34:35], off offset:192               // 00000016DC94: DC5200C0 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016DC9C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v26                         // 00000016DCA0: 560834FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DCA8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DCB0: 8C7E0B7E
	ds_store_b16 v110, v4 offset:7680                          // 00000016DCB4: D87C1E00 0000046E
	s_and_saveexec_b32 s11, s1                                 // 00000016DCBC: BE8B2001
	s_cbranch_execz 17                                         // 00000016DCC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2608>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000016DCC4: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DCCC: BF870091
	.long 0xd73c0003                                           // 00000016DCD0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DCD4: 02020689
	.long 0xd7000a03                                           // 00000016DCD8: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DCDC: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DCE0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DCE4: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:192                 // 00000016DCEC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DCF4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v27                         // 00000016DCF8: 560636FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016DD00: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DD08: 8C7E0B7E
	.long 0x7e063880                                           // 00000016DD0C: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:7684                   // 00000016DD10: DA841E04 0000036E
	.long 0x7e083903                                           // 00000016DD18: 7E083903
	s_and_saveexec_b32 s11, s4                                 // 00000016DD1C: BE8B2004
	s_cbranch_execz 17                                         // 00000016DD20: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2668>
	v_mad_u64_u32 v[26:27], null, v7, 48, s[2:3]               // 00000016DD24: D6FE7C1A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD2C: BF870091
	.long 0xd73c001a                                           // 00000016DD30: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000016DD34: 02023489
	.long 0xd7000a1a                                           // 00000016DD38: D7000A1A
	v_cndmask_b32_e32 v1, v108, v26, vcc_lo                    // 00000016DD3C: 0202356C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DD40: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v109, v27, s10              // 00000016DD44: D5207C1B 002A376D
	global_load_b32 v4, v[26:27], off offset:192               // 00000016DD4C: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 00000016DD54: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 00000016DD58: 560838FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DD60: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DD68: 8C7E0B7E
	ds_store_b16 v110, v4 offset:7688                          // 00000016DD6C: D87C1E08 0000046E
	s_and_saveexec_b32 s11, s5                                 // 00000016DD74: BE8B2005
	s_cbranch_execz 17                                         // 00000016DD78: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000016DD7C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DD84: BF870091
	.long 0xd73c0003                                           // 00000016DD88: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DD8C: 02020689
	.long 0xd7000a03                                           // 00000016DD90: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DD94: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DD98: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DD9C: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:192                 // 00000016DDA4: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DDAC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v29                         // 00000016DDB0: 56063AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016DDB8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DDC0: 8C7E0B7E
	.long 0x7f063880                                           // 00000016DDC4: 7F063880
	ds_store_b16 v110, v3 offset:7692                          // 00000016DDC8: D87C1E0C 0000036E
	.long 0x7e083983                                           // 00000016DDD0: 7E083983
	s_and_saveexec_b32 s11, s6                                 // 00000016DDD4: BE8B2006
	s_cbranch_execz 17                                         // 00000016DDD8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2720>
	v_mad_u64_u32 v[26:27], null, v9, 48, s[2:3]               // 00000016DDDC: D6FE7C1A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DDE4: BF870091
	.long 0xd73c001a                                           // 00000016DDE8: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000016DDEC: 02023489
	.long 0xd7000a1a                                           // 00000016DDF0: D7000A1A
	v_cndmask_b32_e32 v1, v108, v26, vcc_lo                    // 00000016DDF4: 0202356C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DDF8: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v109, v27, s10              // 00000016DDFC: D5207C1B 002A376D
	global_load_b32 v4, v[26:27], off offset:192               // 00000016DE04: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 00000016DE0C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v30                         // 00000016DE10: 56083CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DE18: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DE20: 8C7E0B7E
	ds_store_b16 v110, v4 offset:7696                          // 00000016DE24: D87C1E10 0000046E
	s_and_saveexec_b32 s11, s7                                 // 00000016DE2C: BE8B2007
	s_cbranch_execz 17                                         // 00000016DE30: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2778>
	v_mad_u64_u32 v[3:4], null, v115, 48, s[2:3]               // 00000016DE34: D6FE7C03 00096173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DE3C: BF870091
	.long 0xd73c0003                                           // 00000016DE40: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DE44: 02020689
	.long 0xd7000a03                                           // 00000016DE48: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DE4C: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DE50: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DE54: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:192                 // 00000016DE5C: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DE64: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v31                         // 00000016DE68: 56063EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000016DE70: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DE78: 8C7E0B7E
	.long 0x7e063880                                           // 00000016DE7C: 7E063880
	ds_store_b16_d16_hi v110, v3 offset:7700                   // 00000016DE80: DA841E14 0000036E
	.long 0x7e083903                                           // 00000016DE88: 7E083903
	s_and_saveexec_b32 s11, s8                                 // 00000016DE8C: BE8B2008
	s_cbranch_execz 17                                         // 00000016DE90: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27d8>
	v_mad_u64_u32 v[26:27], null, v116, 48, s[2:3]             // 00000016DE94: D6FE7C1A 00096174
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DE9C: BF870091
	.long 0xd73c001a                                           // 00000016DEA0: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000016DEA4: 02023489
	.long 0xd7000a1a                                           // 00000016DEA8: D7000A1A
	v_cndmask_b32_e32 v1, v108, v26, vcc_lo                    // 00000016DEAC: 0202356C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DEB0: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v109, v27, s10              // 00000016DEB4: D5207C1B 002A376D
	global_load_b32 v4, v[26:27], off offset:192               // 00000016DEBC: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 00000016DEC4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v32                         // 00000016DEC8: 560840FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000016DED0: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DED8: 8C7E0B7E
	ds_store_b16 v110, v4 offset:7704                          // 00000016DEDC: D87C1E18 0000046E
	s_and_saveexec_b32 s11, s9                                 // 00000016DEE4: BE8B2009
	s_cbranch_execz 17                                         // 00000016DEE8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2830>
	v_mad_u64_u32 v[3:4], null, v117, 48, s[2:3]               // 00000016DEEC: D6FE7C03 00096175
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016DEF4: BF870091
	.long 0xd73c0003                                           // 00000016DEF8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016DEFC: 02020689
	.long 0xd7000a03                                           // 00000016DF00: D7000A03
	v_cndmask_b32_e32 v1, v108, v3, vcc_lo                     // 00000016DF04: 0202076C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016DF08: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v109, v4, s10                // 00000016DF0C: D5207C04 002A096D
	global_load_b32 v3, v[3:4], off offset:192                 // 00000016DF14: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016DF1C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v33                         // 00000016DF20: 560642FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016DF28: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016DF30: 8C7E0B7E
	ds_store_b16 v110, v3 offset:7708                          // 00000016DF34: D87C1E1C 0000036E
	s_waitcnt lgkmcnt(0)                                       // 00000016DF3C: BF89FC07
	s_barrier                                                  // 00000016DF40: BFBD0000
	buffer_gl0_inv                                             // 00000016DF44: E0AC0000 00000000
	ds_load_b128 v[26:29], v101                                // 00000016DF4C: DBFC0000 1A000065
	ds_load_b128 v[30:33], v101 offset:16                      // 00000016DF54: DBFC0010 1E000065
	ds_load_b128 v[38:41], v101 offset:32                      // 00000016DF5C: DBFC0020 26000065
	ds_load_b128 v[42:45], v101 offset:48                      // 00000016DF64: DBFC0030 2A000065
	ds_load_b128 v[50:53], v101 offset:8448                    // 00000016DF6C: DBFC2100 32000065
	ds_load_b128 v[54:57], v101 offset:8464                    // 00000016DF74: DBFC2110 36000065
	s_mov_b32 s20, 0                                           // 00000016DF7C: BE940080
	ds_load_b128 v[58:61], v101 offset:8480                    // 00000016DF80: DBFC2120 3A000065
	ds_load_b128 v[62:65], v101 offset:8496                    // 00000016DF88: DBFC2130 3E000065
	s_mov_b32 s27, s20                                         // 00000016DF90: BE9B0014
	s_mov_b32 s21, s20                                         // 00000016DF94: BE950014
	s_mov_b32 s22, s20                                         // 00000016DF98: BE960014
	s_mov_b32 s23, s20                                         // 00000016DF9C: BE970014
	s_mov_b32 s24, s20                                         // 00000016DFA0: BE980014
	s_mov_b32 s25, s20                                         // 00000016DFA4: BE990014
	s_mov_b32 s26, s20                                         // 00000016DFA8: BE9A0014
	ds_load_b128 v[66:69], v101 offset:16896                   // 00000016DFAC: DBFC4200 42000065
	ds_load_b128 v[74:77], v101 offset:25344                   // 00000016DFB4: DBFC6300 4A000065
	ds_load_b128 v[78:81], v101 offset:25360                   // 00000016DFBC: DBFC6310 4E000065
	ds_load_b128 v[82:85], v101 offset:25376                   // 00000016DFC4: DBFC6320 52000065
	s_waitcnt lgkmcnt(11)                                      // 00000016DFCC: BF89FCB7
	v_fma_mixlo_f16 v34, v26, s12, 0                           // 00000016DFD0: CC210022 0200191A
	v_fma_mixhi_f16 v34, v27, s12, 0                           // 00000016DFD8: CC220022 0200191B
	v_fma_mixlo_f16 v35, v28, s12, 0                           // 00000016DFE0: CC210023 0200191C
	v_fma_mixhi_f16 v35, v29, s12, 0                           // 00000016DFE8: CC220023 0200191D
	s_waitcnt lgkmcnt(10)                                      // 00000016DFF0: BF89FCA7
	v_fma_mixlo_f16 v36, v30, s12, 0                           // 00000016DFF4: CC210024 0200191E
	v_fma_mixhi_f16 v36, v31, s12, 0                           // 00000016DFFC: CC220024 0200191F
	v_fma_mixlo_f16 v37, v32, s12, 0                           // 00000016E004: CC210025 02001920
	v_fma_mixhi_f16 v37, v33, s12, 0                           // 00000016E00C: CC220025 02001921
	v_dual_mov_b32 v33, s27 :: v_dual_mov_b32 v32, s26         // 00000016E014: CA10001B 2120001A
	s_waitcnt lgkmcnt(9)                                       // 00000016E01C: BF89FC97
	v_fma_mixlo_f16 v38, v38, s12, 0                           // 00000016E020: CC210026 02001926
	v_fma_mixhi_f16 v38, v39, s12, 0                           // 00000016E028: CC220026 02001927
	v_fma_mixlo_f16 v39, v40, s12, 0                           // 00000016E030: CC210027 02001928
	v_fma_mixhi_f16 v39, v41, s12, 0                           // 00000016E038: CC220027 02001929
	s_waitcnt lgkmcnt(8)                                       // 00000016E040: BF89FC87
	v_fma_mixlo_f16 v40, v42, s12, 0                           // 00000016E044: CC210028 0200192A
	v_fma_mixhi_f16 v40, v43, s12, 0                           // 00000016E04C: CC220028 0200192B
	v_fma_mixlo_f16 v41, v44, s12, 0                           // 00000016E054: CC210029 0200192C
	v_fma_mixhi_f16 v41, v45, s12, 0                           // 00000016E05C: CC220029 0200192D
	v_dual_mov_b32 v31, s25 :: v_dual_mov_b32 v30, s24         // 00000016E064: CA100019 1F1E0018
	v_dual_mov_b32 v29, s23 :: v_dual_mov_b32 v28, s22         // 00000016E06C: CA100017 1D1C0016
	v_dual_mov_b32 v27, s21 :: v_dual_mov_b32 v26, s20         // 00000016E074: CA100015 1B1A0014
	ds_load_b128 v[70:73], v101 offset:16944                   // 00000016E07C: DBFC4230 46000065
	ds_load_b128 v[86:89], v101 offset:112                     // 00000016E084: DBFC0070 56000065
	ds_load_b128 v[126:129], v101 offset:25408                 // 00000016E08C: DBFC6340 7E000065
	ds_load_b128 v[130:133], v101 offset:25424                 // 00000016E094: DBFC6350 82000065
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[34:41], v[26:33]// 00000016E09C: CC40402A 1C6A450A
	s_waitcnt lgkmcnt(11)                                      // 00000016E0A4: BF89FCB7
	v_fma_mixlo_f16 v34, v50, s12, 0                           // 00000016E0A8: CC210022 02001932
	v_fma_mixhi_f16 v34, v51, s12, 0                           // 00000016E0B0: CC220022 02001933
	v_fma_mixlo_f16 v35, v52, s12, 0                           // 00000016E0B8: CC210023 02001934
	v_fma_mixhi_f16 v35, v53, s12, 0                           // 00000016E0C0: CC220023 02001935
	ds_load_b128 v[50:53], v101 offset:16912                   // 00000016E0C8: DBFC4210 32000065
	s_waitcnt lgkmcnt(11)                                      // 00000016E0D0: BF89FCB7
	v_fma_mixlo_f16 v36, v54, s12, 0                           // 00000016E0D4: CC210024 02001936
	v_fma_mixhi_f16 v36, v55, s12, 0                           // 00000016E0DC: CC220024 02001937
	v_fma_mixlo_f16 v37, v56, s12, 0                           // 00000016E0E4: CC210025 02001938
	v_fma_mixhi_f16 v37, v57, s12, 0                           // 00000016E0EC: CC220025 02001939
	ds_load_b128 v[54:57], v101 offset:16928                   // 00000016E0F4: DBFC4220 36000065
	s_waitcnt lgkmcnt(11)                                      // 00000016E0FC: BF89FCB7
	v_fma_mixlo_f16 v39, v60, s12, 0                           // 00000016E100: CC210027 0200193C
	v_fma_mixhi_f16 v39, v61, s12, 0                           // 00000016E108: CC220027 0200193D
	v_fma_mixlo_f16 v38, v58, s12, 0                           // 00000016E110: CC210026 0200193A
	s_waitcnt lgkmcnt(10)                                      // 00000016E118: BF89FCA7
	v_fma_mixlo_f16 v41, v64, s12, 0                           // 00000016E11C: CC210029 02001940
	s_waitcnt lgkmcnt(9)                                       // 00000016E124: BF89FC97
	v_fma_mixlo_f16 v58, v66, s12, 0                           // 00000016E128: CC21003A 02001942
	v_fma_mixhi_f16 v58, v67, s12, 0                           // 00000016E130: CC22003A 02001943
	s_waitcnt lgkmcnt(5)                                       // 00000016E138: BF89FC57
	v_fma_mixlo_f16 v64, v70, s12, 0                           // 00000016E13C: CC210040 02001946
	v_fma_mixhi_f16 v64, v71, s12, 0                           // 00000016E144: CC220040 02001947
	v_fma_mixlo_f16 v66, v74, s12, 0                           // 00000016E14C: CC210042 0200194A
	v_fma_mixhi_f16 v66, v75, s12, 0                           // 00000016E154: CC220042 0200194B
	v_fma_mixlo_f16 v67, v76, s12, 0                           // 00000016E15C: CC210043 0200194C
	v_fma_mixhi_f16 v67, v77, s12, 0                           // 00000016E164: CC220043 0200194D
	ds_load_b128 v[74:77], v101 offset:64                      // 00000016E16C: DBFC0040 4A000065
	v_fma_mixhi_f16 v38, v59, s12, 0                           // 00000016E174: CC220026 0200193B
	s_waitcnt lgkmcnt(2)                                       // 00000016E17C: BF89FC27
	v_fma_mixlo_f16 v60, v50, s12, 0                           // 00000016E180: CC21003C 02001932
	v_fma_mixhi_f16 v60, v51, s12, 0                           // 00000016E188: CC22003C 02001933
	v_fma_mixlo_f16 v61, v52, s12, 0                           // 00000016E190: CC21003D 02001934
	v_fma_mixhi_f16 v61, v53, s12, 0                           // 00000016E198: CC22003D 02001935
	ds_load_b128 v[50:53], v101 offset:25392                   // 00000016E1A0: DBFC6330 32000065
	v_fma_mixlo_f16 v70, v82, s12, 0                           // 00000016E1A8: CC210046 02001952
	v_fma_mixhi_f16 v70, v83, s12, 0                           // 00000016E1B0: CC220046 02001953
	v_fma_mixlo_f16 v71, v84, s12, 0                           // 00000016E1B8: CC210047 02001954
	v_fma_mixhi_f16 v71, v85, s12, 0                           // 00000016E1C0: CC220047 02001955
	ds_load_b128 v[82:85], v101 offset:96                      // 00000016E1C8: DBFC0060 52000065
	v_fma_mixlo_f16 v59, v68, s12, 0                           // 00000016E1D0: CC21003B 02001944
	v_fma_mixhi_f16 v59, v69, s12, 0                           // 00000016E1D8: CC22003B 02001945
	v_fma_mixlo_f16 v68, v78, s12, 0                           // 00000016E1E0: CC210044 0200194E
	v_fma_mixhi_f16 v68, v79, s12, 0                           // 00000016E1E8: CC220044 0200194F
	v_fma_mixlo_f16 v69, v80, s12, 0                           // 00000016E1F0: CC210045 02001950
	v_fma_mixhi_f16 v69, v81, s12, 0                           // 00000016E1F8: CC220045 02001951
	ds_load_b128 v[78:81], v101 offset:80                      // 00000016E200: DBFC0050 4E000065
	v_fma_mixlo_f16 v40, v62, s12, 0                           // 00000016E208: CC210028 0200193E
	v_fma_mixhi_f16 v40, v63, s12, 0                           // 00000016E210: CC220028 0200193F
	v_fma_mixhi_f16 v41, v65, s12, 0                           // 00000016E218: CC220029 02001941
	s_waitcnt lgkmcnt(4)                                       // 00000016E220: BF89FC47
	v_fma_mixlo_f16 v62, v54, s12, 0                           // 00000016E224: CC21003E 02001936
	v_fma_mixhi_f16 v62, v55, s12, 0                           // 00000016E22C: CC22003E 02001937
	v_fma_mixlo_f16 v63, v56, s12, 0                           // 00000016E234: CC21003F 02001938
	v_fma_mixhi_f16 v63, v57, s12, 0                           // 00000016E23C: CC22003F 02001939
	v_fma_mixlo_f16 v65, v72, s12, 0                           // 00000016E244: CC210041 02001948
	v_fma_mixhi_f16 v65, v73, s12, 0                           // 00000016E24C: CC220041 02001949
	s_waitcnt lgkmcnt(2)                                       // 00000016E254: BF89FC27
	v_fma_mixlo_f16 v72, v50, s12, 0                           // 00000016E258: CC210048 02001932
	v_fma_mixhi_f16 v72, v51, s12, 0                           // 00000016E260: CC220048 02001933
	v_fma_mixlo_f16 v73, v52, s12, 0                           // 00000016E268: CC210049 02001934
	v_fma_mixhi_f16 v73, v53, s12, 0                           // 00000016E270: CC220049 02001935
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[34:41], v[26:33]// 00000016E278: CC404032 1C6A450A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[58:65], v[26:33]// 00000016E280: CC404022 1C6A750A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000016E288: BF870003
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[26:33]// 00000016E28C: CC40401A 1C6A850A
	ds_load_b128 v[66:69], v101 offset:8512                    // 00000016E294: DBFC2140 42000065
	ds_load_b128 v[70:73], v101 offset:8528                    // 00000016E29C: DBFC2150 46000065
	v_fma_mixlo_f16 v58, v74, s12, 0                           // 00000016E2A4: CC21003A 0200194A
	v_fma_mixhi_f16 v58, v75, s12, 0                           // 00000016E2AC: CC22003A 0200194B
	v_fma_mixlo_f16 v59, v76, s12, 0                           // 00000016E2B4: CC21003B 0200194C
	v_fma_mixhi_f16 v59, v77, s12, 0                           // 00000016E2BC: CC22003B 0200194D
	ds_load_b128 v[74:77], v101 offset:8544                    // 00000016E2C4: DBFC2160 4A000065
	s_waitcnt lgkmcnt(4)                                       // 00000016E2CC: BF89FC47
	v_fma_mixlo_f16 v62, v82, s12, 0                           // 00000016E2D0: CC21003E 02001952
	v_fma_mixhi_f16 v62, v83, s12, 0                           // 00000016E2D8: CC22003E 02001953
	v_fma_mixlo_f16 v63, v84, s12, 0                           // 00000016E2E0: CC21003F 02001954
	v_fma_mixhi_f16 v63, v85, s12, 0                           // 00000016E2E8: CC22003F 02001955
	ds_load_b128 v[82:85], v101 offset:16960                   // 00000016E2F0: DBFC4240 52000065
	s_waitcnt lgkmcnt(4)                                       // 00000016E2F8: BF89FC47
	v_fma_mixlo_f16 v60, v78, s12, 0                           // 00000016E2FC: CC21003C 0200194E
	v_fma_mixhi_f16 v60, v79, s12, 0                           // 00000016E304: CC22003C 0200194F
	v_fma_mixlo_f16 v61, v80, s12, 0                           // 00000016E30C: CC21003D 02001950
	v_fma_mixhi_f16 v61, v81, s12, 0                           // 00000016E314: CC22003D 02001951
	ds_load_b128 v[78:81], v101 offset:8560                    // 00000016E31C: DBFC2170 4E000065
	ds_load_b128 v[118:121], v101 offset:16992                 // 00000016E324: DBFC4260 76000065
	ds_load_b128 v[122:125], v101 offset:17008                 // 00000016E32C: DBFC4270 7A000065
	v_fma_mixlo_f16 v64, v86, s12, 0                           // 00000016E334: CC210040 02001956
	v_fma_mixhi_f16 v64, v87, s12, 0                           // 00000016E33C: CC220040 02001957
	v_fma_mixlo_f16 v65, v88, s12, 0                           // 00000016E344: CC210041 02001958
	v_fma_mixhi_f16 v65, v89, s12, 0                           // 00000016E34C: CC220041 02001959
	ds_load_b128 v[86:89], v101 offset:16976                   // 00000016E354: DBFC4250 56000065
	ds_load_b128 v[134:137], v101 offset:25440                 // 00000016E35C: DBFC6360 86000065
	ds_load_b128 v[138:141], v101 offset:25456                 // 00000016E364: DBFC6370 8A000065
	s_waitcnt lgkmcnt(9)                                       // 00000016E36C: BF89FC97
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016E370: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016E378: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016E380: CC210043 02001944
	s_waitcnt lgkmcnt(8)                                       // 00000016E388: BF89FC87
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016E38C: CC210044 02001946
	s_waitcnt lgkmcnt(7)                                       // 00000016E394: BF89FC77
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016E398: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016E3A0: CC220046 0200194B
	s_waitcnt lgkmcnt(6)                                       // 00000016E3A8: BF89FC67
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016E3AC: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016E3B4: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016E3BC: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016E3C4: CC22004B 02001955
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016E3CC: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016E3D4: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016E3DC: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016E3E4: CC220053 02001981
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016E3EC: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016E3F4: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016E3FC: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016E404: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:160                   // 00000016E40C: DBFC00A0 7E000065
	ds_load_b128 v[130:133], v101 offset:176                   // 00000016E414: DBFC00B0 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016E41C: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016E424: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016E42C: CC220045 02001949
	s_waitcnt lgkmcnt(7)                                       // 00000016E434: BF89FC77
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016E438: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016E440: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016E448: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016E450: CC220049 02001951
	s_waitcnt lgkmcnt(6)                                       // 00000016E458: BF89FC67
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016E45C: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016E464: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016E46C: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016E474: CC22004F 02001979
	s_waitcnt lgkmcnt(5)                                       // 00000016E47C: BF89FC57
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016E480: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016E488: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016E490: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016E498: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:128                   // 00000016E4A0: DBFC0080 76000065
	ds_load_b128 v[122:125], v101 offset:144                   // 00000016E4A8: DBFC0090 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016E4B0: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016E4B8: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016E4C0: CC220047 0200194D
	s_waitcnt lgkmcnt(6)                                       // 00000016E4C8: BF89FC67
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016E4CC: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016E4D4: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016E4DC: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016E4E4: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016E4EC: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016E4F0: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016E4F8: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016E500: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016E508: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016E510: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016E514: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016E51C: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016E524: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016E52C: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016E534: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016E53C: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016E544: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8576                    // 00000016E54C: DBFC2180 42000065
	ds_load_b128 v[70:73], v101 offset:8592                    // 00000016E554: DBFC2190 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016E55C: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8608                    // 00000016E564: DBFC21A0 4A000065
	ds_load_b128 v[78:81], v101 offset:8624                    // 00000016E56C: DBFC21B0 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016E574: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016E578: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016E580: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016E588: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016E590: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016E598: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016E59C: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016E5A4: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016E5AC: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016E5B4: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17024                   // 00000016E5BC: DBFC4280 52000065
	ds_load_b128 v[86:89], v101 offset:17040                   // 00000016E5C4: DBFC4290 56000065
	ds_load_b128 v[126:129], v101 offset:25472                 // 00000016E5CC: DBFC6380 7E000065
	ds_load_b128 v[130:133], v101 offset:25488                 // 00000016E5D4: DBFC6390 82000065
	s_waitcnt lgkmcnt(9)                                       // 00000016E5DC: BF89FC97
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016E5E0: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016E5E8: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016E5F0: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016E5F8: CC22003B 02001979
	s_waitcnt lgkmcnt(8)                                       // 00000016E600: BF89FC87
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016E604: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016E60C: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016E614: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016E61C: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17056                 // 00000016E624: DBFC42A0 76000065
	ds_load_b128 v[122:125], v101 offset:17072                 // 00000016E62C: DBFC42B0 7A000065
	ds_load_b128 v[134:137], v101 offset:25504                 // 00000016E634: DBFC63A0 86000065
	ds_load_b128 v[138:141], v101 offset:25520                 // 00000016E63C: DBFC63B0 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016E644: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016E648: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016E650: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016E658: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016E660: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016E664: CC210044 02001946
	s_waitcnt lgkmcnt(9)                                       // 00000016E66C: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016E670: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016E678: CC220046 0200194B
	s_waitcnt lgkmcnt(7)                                       // 00000016E680: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016E684: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016E68C: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016E694: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016E69C: CC22004B 02001955
	s_waitcnt lgkmcnt(5)                                       // 00000016E6A4: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016E6A8: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016E6B0: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016E6B8: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016E6C0: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016E6C8: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016E6CC: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016E6D4: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016E6DC: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016E6E4: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:224                   // 00000016E6EC: DBFC00E0 7E000065
	ds_load_b128 v[130:133], v101 offset:240                   // 00000016E6F4: DBFC00F0 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016E6FC: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016E704: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016E70C: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016E714: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016E71C: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016E724: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016E72C: CC220049 02001951
	s_waitcnt lgkmcnt(5)                                       // 00000016E734: BF89FC57
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016E738: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016E740: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016E748: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016E750: CC22004F 02001979
	s_waitcnt lgkmcnt(4)                                       // 00000016E758: BF89FC47
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016E75C: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016E764: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016E76C: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016E774: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:192                   // 00000016E77C: DBFC00C0 76000065
	ds_load_b128 v[122:125], v101 offset:208                   // 00000016E784: DBFC00D0 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016E78C: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016E794: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016E79C: CC220047 0200194D
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016E7A4: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016E7AC: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016E7B4: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016E7BC: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016E7C4: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016E7C8: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016E7D0: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016E7D8: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016E7E0: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016E7E8: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016E7EC: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016E7F4: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016E7FC: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016E804: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016E80C: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016E814: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016E81C: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8640                    // 00000016E824: DBFC21C0 42000065
	ds_load_b128 v[70:73], v101 offset:8656                    // 00000016E82C: DBFC21D0 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016E834: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8672                    // 00000016E83C: DBFC21E0 4A000065
	ds_load_b128 v[78:81], v101 offset:8688                    // 00000016E844: DBFC21F0 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016E84C: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016E850: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016E858: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016E860: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016E868: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016E870: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016E874: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016E87C: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016E884: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016E88C: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17088                   // 00000016E894: DBFC42C0 52000065
	ds_load_b128 v[86:89], v101 offset:17104                   // 00000016E89C: DBFC42D0 56000065
	ds_load_b128 v[126:129], v101 offset:25536                 // 00000016E8A4: DBFC63C0 7E000065
	ds_load_b128 v[130:133], v101 offset:25552                 // 00000016E8AC: DBFC63D0 82000065
	s_waitcnt lgkmcnt(9)                                       // 00000016E8B4: BF89FC97
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016E8B8: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016E8C0: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016E8C8: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016E8D0: CC22003B 02001979
	s_waitcnt lgkmcnt(8)                                       // 00000016E8D8: BF89FC87
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016E8DC: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016E8E4: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016E8EC: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016E8F4: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17120                 // 00000016E8FC: DBFC42E0 76000065
	ds_load_b128 v[122:125], v101 offset:17136                 // 00000016E904: DBFC42F0 7A000065
	ds_load_b128 v[134:137], v101 offset:25568                 // 00000016E90C: DBFC63E0 86000065
	ds_load_b128 v[138:141], v101 offset:25584                 // 00000016E914: DBFC63F0 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016E91C: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016E920: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016E928: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016E930: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016E938: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016E93C: CC210044 02001946
	s_waitcnt lgkmcnt(9)                                       // 00000016E944: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016E948: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016E950: CC220046 0200194B
	s_waitcnt lgkmcnt(7)                                       // 00000016E958: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016E95C: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016E964: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016E96C: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016E974: CC22004B 02001955
	s_waitcnt lgkmcnt(5)                                       // 00000016E97C: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016E980: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016E988: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016E990: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016E998: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016E9A0: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016E9A4: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016E9AC: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016E9B4: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016E9BC: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:288                   // 00000016E9C4: DBFC0120 7E000065
	ds_load_b128 v[130:133], v101 offset:304                   // 00000016E9CC: DBFC0130 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016E9D4: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016E9DC: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016E9E4: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016E9EC: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016E9F4: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016E9FC: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016EA04: CC220049 02001951
	s_waitcnt lgkmcnt(5)                                       // 00000016EA0C: BF89FC57
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016EA10: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016EA18: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016EA20: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016EA28: CC22004F 02001979
	s_waitcnt lgkmcnt(4)                                       // 00000016EA30: BF89FC47
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016EA34: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016EA3C: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016EA44: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016EA4C: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:256                   // 00000016EA54: DBFC0100 76000065
	ds_load_b128 v[122:125], v101 offset:272                   // 00000016EA5C: DBFC0110 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016EA64: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016EA6C: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016EA74: CC220047 0200194D
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016EA7C: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016EA84: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016EA8C: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016EA94: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016EA9C: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016EAA0: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016EAA8: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016EAB0: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016EAB8: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016EAC0: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016EAC4: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016EACC: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016EAD4: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016EADC: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016EAE4: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016EAEC: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016EAF4: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8704                    // 00000016EAFC: DBFC2200 42000065
	ds_load_b128 v[70:73], v101 offset:8720                    // 00000016EB04: DBFC2210 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016EB0C: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8736                    // 00000016EB14: DBFC2220 4A000065
	ds_load_b128 v[78:81], v101 offset:8752                    // 00000016EB1C: DBFC2230 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016EB24: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016EB28: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016EB30: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016EB38: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016EB40: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016EB48: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016EB4C: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016EB54: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016EB5C: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016EB64: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17152                   // 00000016EB6C: DBFC4300 52000065
	ds_load_b128 v[86:89], v101 offset:17168                   // 00000016EB74: DBFC4310 56000065
	ds_load_b128 v[126:129], v101 offset:25600                 // 00000016EB7C: DBFC6400 7E000065
	ds_load_b128 v[130:133], v101 offset:25616                 // 00000016EB84: DBFC6410 82000065
	s_waitcnt lgkmcnt(9)                                       // 00000016EB8C: BF89FC97
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016EB90: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016EB98: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016EBA0: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016EBA8: CC22003B 02001979
	s_waitcnt lgkmcnt(8)                                       // 00000016EBB0: BF89FC87
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016EBB4: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016EBBC: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016EBC4: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016EBCC: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17184                 // 00000016EBD4: DBFC4320 76000065
	ds_load_b128 v[122:125], v101 offset:17200                 // 00000016EBDC: DBFC4330 7A000065
	ds_load_b128 v[134:137], v101 offset:25632                 // 00000016EBE4: DBFC6420 86000065
	ds_load_b128 v[138:141], v101 offset:25648                 // 00000016EBEC: DBFC6430 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016EBF4: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016EBF8: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016EC00: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016EC08: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016EC10: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016EC14: CC210044 02001946
	s_waitcnt lgkmcnt(9)                                       // 00000016EC1C: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016EC20: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016EC28: CC220046 0200194B
	s_waitcnt lgkmcnt(7)                                       // 00000016EC30: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016EC34: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016EC3C: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016EC44: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016EC4C: CC22004B 02001955
	s_waitcnt lgkmcnt(5)                                       // 00000016EC54: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016EC58: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016EC60: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016EC68: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016EC70: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016EC78: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016EC7C: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016EC84: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016EC8C: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016EC94: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:352                   // 00000016EC9C: DBFC0160 7E000065
	ds_load_b128 v[130:133], v101 offset:368                   // 00000016ECA4: DBFC0170 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016ECAC: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016ECB4: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016ECBC: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016ECC4: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016ECCC: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016ECD4: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016ECDC: CC220049 02001951
	s_waitcnt lgkmcnt(5)                                       // 00000016ECE4: BF89FC57
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016ECE8: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016ECF0: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016ECF8: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016ED00: CC22004F 02001979
	s_waitcnt lgkmcnt(4)                                       // 00000016ED08: BF89FC47
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016ED0C: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016ED14: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016ED1C: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016ED24: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:320                   // 00000016ED2C: DBFC0140 76000065
	ds_load_b128 v[122:125], v101 offset:336                   // 00000016ED34: DBFC0150 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016ED3C: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016ED44: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016ED4C: CC220047 0200194D
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016ED54: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016ED5C: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016ED64: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016ED6C: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016ED74: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016ED78: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016ED80: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016ED88: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016ED90: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016ED98: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016ED9C: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016EDA4: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016EDAC: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016EDB4: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016EDBC: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016EDC4: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016EDCC: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8768                    // 00000016EDD4: DBFC2240 42000065
	ds_load_b128 v[70:73], v101 offset:8784                    // 00000016EDDC: DBFC2250 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016EDE4: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8800                    // 00000016EDEC: DBFC2260 4A000065
	ds_load_b128 v[78:81], v101 offset:8816                    // 00000016EDF4: DBFC2270 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016EDFC: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016EE00: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016EE08: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016EE10: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016EE18: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016EE20: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016EE24: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016EE2C: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016EE34: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016EE3C: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17216                   // 00000016EE44: DBFC4340 52000065
	ds_load_b128 v[86:89], v101 offset:17232                   // 00000016EE4C: DBFC4350 56000065
	ds_load_b128 v[126:129], v101 offset:25664                 // 00000016EE54: DBFC6440 7E000065
	ds_load_b128 v[130:133], v101 offset:25680                 // 00000016EE5C: DBFC6450 82000065
	s_waitcnt lgkmcnt(9)                                       // 00000016EE64: BF89FC97
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016EE68: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016EE70: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016EE78: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016EE80: CC22003B 02001979
	s_waitcnt lgkmcnt(8)                                       // 00000016EE88: BF89FC87
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016EE8C: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016EE94: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016EE9C: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016EEA4: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17248                 // 00000016EEAC: DBFC4360 76000065
	ds_load_b128 v[122:125], v101 offset:17264                 // 00000016EEB4: DBFC4370 7A000065
	ds_load_b128 v[134:137], v101 offset:25696                 // 00000016EEBC: DBFC6460 86000065
	ds_load_b128 v[138:141], v101 offset:25712                 // 00000016EEC4: DBFC6470 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016EECC: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016EED0: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016EED8: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016EEE0: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016EEE8: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016EEEC: CC210044 02001946
	s_waitcnt lgkmcnt(9)                                       // 00000016EEF4: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016EEF8: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016EF00: CC220046 0200194B
	s_waitcnt lgkmcnt(7)                                       // 00000016EF08: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016EF0C: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016EF14: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016EF1C: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016EF24: CC22004B 02001955
	s_waitcnt lgkmcnt(5)                                       // 00000016EF2C: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016EF30: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016EF38: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016EF40: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016EF48: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016EF50: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016EF54: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016EF5C: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016EF64: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016EF6C: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:416                   // 00000016EF74: DBFC01A0 7E000065
	ds_load_b128 v[130:133], v101 offset:432                   // 00000016EF7C: DBFC01B0 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016EF84: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016EF8C: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016EF94: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016EF9C: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016EFA4: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016EFAC: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016EFB4: CC220049 02001951
	s_waitcnt lgkmcnt(5)                                       // 00000016EFBC: BF89FC57
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016EFC0: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016EFC8: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016EFD0: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016EFD8: CC22004F 02001979
	s_waitcnt lgkmcnt(4)                                       // 00000016EFE0: BF89FC47
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016EFE4: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016EFEC: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016EFF4: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016EFFC: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:384                   // 00000016F004: DBFC0180 76000065
	ds_load_b128 v[122:125], v101 offset:400                   // 00000016F00C: DBFC0190 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016F014: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016F01C: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016F024: CC220047 0200194D
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016F02C: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016F034: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016F03C: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016F044: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016F04C: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016F050: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016F058: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016F060: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016F068: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016F070: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016F074: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016F07C: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016F084: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016F08C: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016F094: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016F09C: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016F0A4: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8832                    // 00000016F0AC: DBFC2280 42000065
	ds_load_b128 v[70:73], v101 offset:8848                    // 00000016F0B4: DBFC2290 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016F0BC: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8864                    // 00000016F0C4: DBFC22A0 4A000065
	ds_load_b128 v[78:81], v101 offset:8880                    // 00000016F0CC: DBFC22B0 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016F0D4: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016F0D8: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016F0E0: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016F0E8: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016F0F0: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016F0F8: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016F0FC: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016F104: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016F10C: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016F114: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17280                   // 00000016F11C: DBFC4380 52000065
	ds_load_b128 v[86:89], v101 offset:17296                   // 00000016F124: DBFC4390 56000065
	ds_load_b128 v[126:129], v101 offset:25728                 // 00000016F12C: DBFC6480 7E000065
	ds_load_b128 v[130:133], v101 offset:25744                 // 00000016F134: DBFC6490 82000065
	s_waitcnt lgkmcnt(9)                                       // 00000016F13C: BF89FC97
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016F140: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016F148: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016F150: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016F158: CC22003B 02001979
	s_waitcnt lgkmcnt(8)                                       // 00000016F160: BF89FC87
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016F164: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016F16C: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016F174: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016F17C: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17312                 // 00000016F184: DBFC43A0 76000065
	ds_load_b128 v[122:125], v101 offset:17328                 // 00000016F18C: DBFC43B0 7A000065
	ds_load_b128 v[134:137], v101 offset:25760                 // 00000016F194: DBFC64A0 86000065
	ds_load_b128 v[138:141], v101 offset:25776                 // 00000016F19C: DBFC64B0 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016F1A4: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016F1A8: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016F1B0: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016F1B8: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016F1C0: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016F1C4: CC210044 02001946
	s_waitcnt lgkmcnt(9)                                       // 00000016F1CC: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016F1D0: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016F1D8: CC220046 0200194B
	s_waitcnt lgkmcnt(7)                                       // 00000016F1E0: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016F1E4: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016F1EC: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016F1F4: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016F1FC: CC22004B 02001955
	s_waitcnt lgkmcnt(5)                                       // 00000016F204: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016F208: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016F210: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016F218: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016F220: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016F228: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016F22C: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016F234: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016F23C: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016F244: CC220055 02001985
	ds_load_b128 v[126:129], v101 offset:480                   // 00000016F24C: DBFC01E0 7E000065
	ds_load_b128 v[130:133], v101 offset:496                   // 00000016F254: DBFC01F0 82000065
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016F25C: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016F264: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016F26C: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016F274: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016F27C: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016F284: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016F28C: CC220049 02001951
	s_waitcnt lgkmcnt(5)                                       // 00000016F294: BF89FC57
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016F298: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016F2A0: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016F2A8: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016F2B0: CC22004F 02001979
	s_waitcnt lgkmcnt(4)                                       // 00000016F2B8: BF89FC47
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016F2BC: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016F2C4: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016F2CC: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016F2D4: CC220051 0200197D
	ds_load_b128 v[118:121], v101 offset:448                   // 00000016F2DC: DBFC01C0 76000065
	ds_load_b128 v[122:125], v101 offset:464                   // 00000016F2E4: DBFC01D0 7A000065
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016F2EC: CC220044 02001947
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016F2F4: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016F2FC: CC220047 0200194D
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016F304: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016F30C: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016F314: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016F31C: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016F324: BF89FC57
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016F328: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016F330: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016F338: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016F340: CC220057 02001989
	s_waitcnt lgkmcnt(4)                                       // 00000016F348: BF89FC47
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016F34C: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016F354: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016F35C: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016F364: CC220059 0200198D
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016F36C: CC40402A 1CAA750A
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016F374: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016F37C: CC404022 1C8A950A
	ds_load_b128 v[66:69], v101 offset:8896                    // 00000016F384: DBFC22C0 42000065
	ds_load_b128 v[70:73], v101 offset:8912                    // 00000016F38C: DBFC22D0 46000065
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016F394: CC40401A 1C6AA50A
	ds_load_b128 v[74:77], v101 offset:8928                    // 00000016F39C: DBFC22E0 4A000065
	ds_load_b128 v[78:81], v101 offset:8944                    // 00000016F3A4: DBFC22F0 4E000065
	s_waitcnt lgkmcnt(7)                                       // 00000016F3AC: BF89FC77
	v_fma_mixlo_f16 v62, v126, s12, 0                          // 00000016F3B0: CC21003E 0200197E
	v_fma_mixhi_f16 v62, v127, s12, 0                          // 00000016F3B8: CC22003E 0200197F
	v_fma_mixlo_f16 v63, v128, s12, 0                          // 00000016F3C0: CC21003F 02001980
	v_fma_mixhi_f16 v63, v129, s12, 0                          // 00000016F3C8: CC22003F 02001981
	s_waitcnt lgkmcnt(6)                                       // 00000016F3D0: BF89FC67
	v_fma_mixlo_f16 v64, v130, s12, 0                          // 00000016F3D4: CC210040 02001982
	v_fma_mixhi_f16 v64, v131, s12, 0                          // 00000016F3DC: CC220040 02001983
	v_fma_mixlo_f16 v65, v132, s12, 0                          // 00000016F3E4: CC210041 02001984
	v_fma_mixhi_f16 v65, v133, s12, 0                          // 00000016F3EC: CC220041 02001985
	ds_load_b128 v[82:85], v101 offset:17344                   // 00000016F3F4: DBFC43C0 52000065
	ds_load_b128 v[86:89], v101 offset:17360                   // 00000016F3FC: DBFC43D0 56000065
	ds_load_b128 v[126:129], v101 offset:25792                 // 00000016F404: DBFC64C0 7E000065
	ds_load_b128 v[130:133], v101 offset:25808                 // 00000016F40C: DBFC64D0 82000065
	ds_load_b128 v[134:137], v101 offset:25824                 // 00000016F414: DBFC64E0 86000065
	ds_load_b128 v[138:141], v101 offset:25840                 // 00000016F41C: DBFC64F0 8A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016F424: BF89FCB7
	v_fma_mixlo_f16 v58, v118, s12, 0                          // 00000016F428: CC21003A 02001976
	v_fma_mixhi_f16 v58, v119, s12, 0                          // 00000016F430: CC22003A 02001977
	v_fma_mixlo_f16 v59, v120, s12, 0                          // 00000016F438: CC21003B 02001978
	v_fma_mixhi_f16 v59, v121, s12, 0                          // 00000016F440: CC22003B 02001979
	s_waitcnt lgkmcnt(10)                                      // 00000016F448: BF89FCA7
	v_fma_mixlo_f16 v60, v122, s12, 0                          // 00000016F44C: CC21003C 0200197A
	v_fma_mixhi_f16 v60, v123, s12, 0                          // 00000016F454: CC22003C 0200197B
	v_fma_mixlo_f16 v61, v124, s12, 0                          // 00000016F45C: CC21003D 0200197C
	v_fma_mixhi_f16 v61, v125, s12, 0                          // 00000016F464: CC22003D 0200197D
	ds_load_b128 v[118:121], v101 offset:17376                 // 00000016F46C: DBFC43E0 76000065
	ds_load_b128 v[122:125], v101 offset:17392                 // 00000016F474: DBFC43F0 7A000065
	s_waitcnt lgkmcnt(11)                                      // 00000016F47C: BF89FCB7
	v_fma_mixlo_f16 v66, v66, s12, 0                           // 00000016F480: CC210042 02001942
	v_fma_mixhi_f16 v66, v67, s12, 0                           // 00000016F488: CC220042 02001943
	v_fma_mixlo_f16 v67, v68, s12, 0                           // 00000016F490: CC210043 02001944
	s_waitcnt lgkmcnt(10)                                      // 00000016F498: BF89FCA7
	v_fma_mixlo_f16 v68, v70, s12, 0                           // 00000016F49C: CC210044 02001946
	v_fma_mixhi_f16 v68, v71, s12, 0                           // 00000016F4A4: CC220044 02001947
	s_waitcnt lgkmcnt(9)                                       // 00000016F4AC: BF89FC97
	v_fma_mixlo_f16 v70, v74, s12, 0                           // 00000016F4B0: CC210046 0200194A
	v_fma_mixhi_f16 v70, v75, s12, 0                           // 00000016F4B8: CC220046 0200194B
	v_fma_mixlo_f16 v71, v76, s12, 0                           // 00000016F4C0: CC210047 0200194C
	v_fma_mixhi_f16 v71, v77, s12, 0                           // 00000016F4C8: CC220047 0200194D
	s_waitcnt lgkmcnt(7)                                       // 00000016F4D0: BF89FC77
	v_fma_mixlo_f16 v74, v82, s12, 0                           // 00000016F4D4: CC21004A 02001952
	v_fma_mixhi_f16 v74, v83, s12, 0                           // 00000016F4DC: CC22004A 02001953
	v_fma_mixlo_f16 v75, v84, s12, 0                           // 00000016F4E4: CC21004B 02001954
	v_fma_mixhi_f16 v75, v85, s12, 0                           // 00000016F4EC: CC22004B 02001955
	s_waitcnt lgkmcnt(6)                                       // 00000016F4F4: BF89FC67
	v_fma_mixlo_f16 v76, v86, s12, 0                           // 00000016F4F8: CC21004C 02001956
	v_fma_mixhi_f16 v76, v87, s12, 0                           // 00000016F500: CC22004C 02001957
	v_fma_mixlo_f16 v77, v88, s12, 0                           // 00000016F508: CC21004D 02001958
	v_fma_mixhi_f16 v77, v89, s12, 0                           // 00000016F510: CC22004D 02001959
	s_waitcnt lgkmcnt(5)                                       // 00000016F518: BF89FC57
	v_fma_mixlo_f16 v82, v126, s12, 0                          // 00000016F51C: CC210052 0200197E
	v_fma_mixhi_f16 v82, v127, s12, 0                          // 00000016F524: CC220052 0200197F
	v_fma_mixlo_f16 v83, v128, s12, 0                          // 00000016F52C: CC210053 02001980
	v_fma_mixhi_f16 v83, v129, s12, 0                          // 00000016F534: CC220053 02001981
	s_waitcnt lgkmcnt(4)                                       // 00000016F53C: BF89FC47
	v_fma_mixlo_f16 v84, v130, s12, 0                          // 00000016F540: CC210054 02001982
	v_fma_mixhi_f16 v84, v131, s12, 0                          // 00000016F548: CC220054 02001983
	v_fma_mixlo_f16 v85, v132, s12, 0                          // 00000016F550: CC210055 02001984
	v_fma_mixhi_f16 v85, v133, s12, 0                          // 00000016F558: CC220055 02001985
	s_waitcnt lgkmcnt(3)                                       // 00000016F560: BF89FC37
	v_fma_mixlo_f16 v86, v134, s12, 0                          // 00000016F564: CC210056 02001986
	v_fma_mixhi_f16 v86, v135, s12, 0                          // 00000016F56C: CC220056 02001987
	v_fma_mixlo_f16 v87, v136, s12, 0                          // 00000016F574: CC210057 02001988
	v_fma_mixhi_f16 v87, v137, s12, 0                          // 00000016F57C: CC220057 02001989
	s_waitcnt lgkmcnt(2)                                       // 00000016F584: BF89FC27
	v_fma_mixlo_f16 v88, v138, s12, 0                          // 00000016F588: CC210058 0200198A
	v_fma_mixhi_f16 v88, v139, s12, 0                          // 00000016F590: CC220058 0200198B
	v_fma_mixlo_f16 v89, v140, s12, 0                          // 00000016F598: CC210059 0200198C
	v_fma_mixhi_f16 v89, v141, s12, 0                          // 00000016F5A0: CC220059 0200198D
	s_mul_i32 s10, s13, 48                                     // 00000016F5A8: 960AB00D
	s_mul_hi_u32 s11, s13, 48                                  // 00000016F5AC: 968BB00D
	s_add_u32 s10, s10, s2                                     // 00000016F5B0: 800A020A
	s_addc_u32 s11, s11, s3                                    // 00000016F5B4: 820B030B
	v_fma_mixhi_f16 v67, v69, s12, 0                           // 00000016F5B8: CC220043 02001945
	v_fma_mixlo_f16 v69, v72, s12, 0                           // 00000016F5C0: CC210045 02001948
	v_fma_mixhi_f16 v69, v73, s12, 0                           // 00000016F5C8: CC220045 02001949
	v_fma_mixlo_f16 v72, v78, s12, 0                           // 00000016F5D0: CC210048 0200194E
	v_fma_mixhi_f16 v72, v79, s12, 0                           // 00000016F5D8: CC220048 0200194F
	v_fma_mixlo_f16 v73, v80, s12, 0                           // 00000016F5E0: CC210049 02001950
	v_fma_mixhi_f16 v73, v81, s12, 0                           // 00000016F5E8: CC220049 02001951
	s_waitcnt lgkmcnt(1)                                       // 00000016F5F0: BF89FC17
	v_fma_mixlo_f16 v78, v118, s12, 0                          // 00000016F5F4: CC21004E 02001976
	v_fma_mixhi_f16 v78, v119, s12, 0                          // 00000016F5FC: CC22004E 02001977
	v_fma_mixlo_f16 v79, v120, s12, 0                          // 00000016F604: CC21004F 02001978
	v_fma_mixhi_f16 v79, v121, s12, 0                          // 00000016F60C: CC22004F 02001979
	s_waitcnt lgkmcnt(0)                                       // 00000016F614: BF89FC07
	v_fma_mixlo_f16 v80, v122, s12, 0                          // 00000016F618: CC210050 0200197A
	v_fma_mixhi_f16 v80, v123, s12, 0                          // 00000016F620: CC220050 0200197B
	v_fma_mixlo_f16 v81, v124, s12, 0                          // 00000016F628: CC210051 0200197C
	v_fma_mixhi_f16 v81, v125, s12, 0                          // 00000016F630: CC220051 0200197D
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[82:89], v[26:33]// 00000016F638: CC40401A 1C6AA50A
	v_mov_b32_e32 v82, 0                                       // 00000016F640: 7EA40280
	s_lshl_b64 s[10:11], s[10:11], 14                          // 00000016F644: 848A8E0A
	v_wmma_f32_16x16x16_f16 v[42:49], v[10:17], v[58:65], v[42:49]// 00000016F648: CC40402A 1CAA750A
	.long 0xd7000a03                                           // 00000016F650: D7000A03
	v_cndmask_b32_e32 v0, v103, v10, vcc_lo                    // 00000016F654: 02001567
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[50:57]// 00000016F658: CC404032 1CCA850A
	v_wmma_f32_16x16x16_f16 v[34:41], v[10:17], v[74:81], v[34:41]// 00000016F660: CC404022 1C8A950A
	v_add_co_ci_u32_e64 v4, null, s11, v104, s10               // 00000016F668: D5207C04 002AD00B
	v_mov_b32_e32 v83, v82                                     // 00000016F670: 7EA60352
	v_mov_b32_e32 v84, v82                                     // 00000016F674: 7EA80352
	v_mov_b32_e32 v85, v82                                     // 00000016F678: 7EAA0352
	v_mov_b32_e32 v86, v82                                     // 00000016F67C: 7EAC0352
	v_mov_b32_e32 v87, v82                                     // 00000016F680: 7EAE0352
	v_mov_b32_e32 v88, v82                                     // 00000016F684: 7EB00352
	v_mov_b32_e32 v89, v82                                     // 00000016F688: 7EB20352
	v_mov_b32_e32 v74, v82                                     // 00000016F68C: 7E940352
	v_mov_b32_e32 v75, v82                                     // 00000016F690: 7E960352
	v_mov_b32_e32 v76, v82                                     // 00000016F694: 7E980352
	v_mov_b32_e32 v77, v82                                     // 00000016F698: 7E9A0352
	v_mov_b32_e32 v78, v82                                     // 00000016F69C: 7E9C0352
	v_mov_b32_e32 v79, v82                                     // 00000016F6A0: 7E9E0352
	v_mov_b32_e32 v80, v82                                     // 00000016F6A4: 7EA00352
	v_mov_b32_e32 v81, v82                                     // 00000016F6A8: 7EA20352
	v_mov_b32_e32 v66, v82                                     // 00000016F6AC: 7E840352
	v_mov_b32_e32 v67, v82                                     // 00000016F6B0: 7E860352
	v_mov_b32_e32 v68, v82                                     // 00000016F6B4: 7E880352
	v_mov_b32_e32 v69, v82                                     // 00000016F6B8: 7E8A0352
	v_mov_b32_e32 v70, v82                                     // 00000016F6BC: 7E8C0352
	v_mov_b32_e32 v71, v82                                     // 00000016F6C0: 7E8E0352
	v_mov_b32_e32 v72, v82                                     // 00000016F6C4: 7E900352
	v_mov_b32_e32 v73, v82                                     // 00000016F6C8: 7E920352
	v_mov_b32_e32 v58, v82                                     // 00000016F6CC: 7E740352
	v_mov_b32_e32 v59, v82                                     // 00000016F6D0: 7E760352
	v_mov_b32_e32 v60, v82                                     // 00000016F6D4: 7E780352
	v_mov_b32_e32 v61, v82                                     // 00000016F6D8: 7E7A0352
	v_mov_b32_e32 v62, v82                                     // 00000016F6DC: 7E7C0352
	v_mov_b32_e32 v63, v82                                     // 00000016F6E0: 7E7E0352
	v_mov_b32_e32 v64, v82                                     // 00000016F6E4: 7E800352
	v_mov_b32_e32 v65, v82                                     // 00000016F6E8: 7E820352
	s_mov_b32 s11, s20                                         // 00000016F6EC: BE8B0014
	s_lshl_b32 s16, s20, 4                                     // 00000016F6F0: 84108414
	v_lshl_add_u32 v142, s20, 5, v105                          // 00000016F6F4: D646008E 05A50A14
	s_lshl_b64 s[22:23], s[16:17], 2                           // 00000016F6FC: 84968210
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F700: BF870099
	.long 0xd7000a76                                           // 00000016F704: D7000A76
	v_cndmask_b32_e32 v0, v3, v22, vcc_lo                      // 00000016F708: 02002D03
	v_add_co_ci_u32_e64 v119, null, s23, v4, s10               // 00000016F70C: D5207C77 002A0817
	.long 0xd44a000a                                           // 00000016F714: D44A000A
	v_cndmask_b32_e32 v1, s20, v98, vcc_lo                     // 00000016F718: 0202C414
	s_add_i32 s20, s20, 1                                      // 00000016F71C: 81148114
	s_clause 0x3                                               // 00000016F720: BF850003
	global_load_b128 v[150:153], v[118:119], off               // 00000016F724: DC5E0000 967C0076
	global_load_b128 v[154:157], v[118:119], off offset:16     // 00000016F72C: DC5E0010 9A7C0076
	global_load_b128 v[158:161], v[118:119], off offset:32     // 00000016F734: DC5E0020 9E7C0076
	global_load_b128 v[162:165], v[118:119], off offset:48     // 00000016F73C: DC5E0030 A27C0076
	ds_load_b128 v[118:121], v142                              // 00000016F744: DBFC0000 7600008E
	ds_load_b128 v[122:125], v142 offset:16                    // 00000016F74C: DBFC0010 7A00008E
	ds_load_b128 v[130:133], v142 offset:2576                  // 00000016F754: DBFC0A10 8200008E
	ds_load_b128 v[126:129], v142 offset:2560                  // 00000016F75C: DBFC0A00 7E00008E
	ds_load_b128 v[138:141], v142 offset:5136                  // 00000016F764: DBFC1410 8A00008E
	ds_load_b128 v[134:137], v142 offset:5120                  // 00000016F76C: DBFC1400 8600008E
	ds_load_b128 v[146:149], v142 offset:7696                  // 00000016F774: DBFC1E10 9200008E
	ds_load_b128 v[142:145], v142 offset:7680                  // 00000016F77C: DBFC1E00 8E00008E
	s_or_b32 s11, s10, s11                                     // 00000016F784: 8C0B0B0A
	s_waitcnt vmcnt(3)                                         // 00000016F788: BF890FF7
	v_fma_mixlo_f16 v150, v150, s12, 0                         // 00000016F78C: CC210096 02001996
	v_fma_mixhi_f16 v150, v151, s12, 0                         // 00000016F794: CC220096 02001997
	v_fma_mixlo_f16 v151, v152, s12, 0                         // 00000016F79C: CC210097 02001998
	v_fma_mixhi_f16 v151, v153, s12, 0                         // 00000016F7A4: CC220097 02001999
	s_waitcnt vmcnt(2)                                         // 00000016F7AC: BF890BF7
	v_fma_mixlo_f16 v152, v154, s12, 0                         // 00000016F7B0: CC210098 0200199A
	v_fma_mixhi_f16 v152, v155, s12, 0                         // 00000016F7B8: CC220098 0200199B
	v_fma_mixlo_f16 v153, v156, s12, 0                         // 00000016F7C0: CC210099 0200199C
	v_fma_mixhi_f16 v153, v157, s12, 0                         // 00000016F7C8: CC220099 0200199D
	s_waitcnt vmcnt(1)                                         // 00000016F7D0: BF8907F7
	v_fma_mixlo_f16 v154, v158, s12, 0                         // 00000016F7D4: CC21009A 0200199E
	v_fma_mixhi_f16 v154, v159, s12, 0                         // 00000016F7DC: CC22009A 0200199F
	v_fma_mixlo_f16 v155, v160, s12, 0                         // 00000016F7E4: CC21009B 020019A0
	v_fma_mixhi_f16 v155, v161, s12, 0                         // 00000016F7EC: CC22009B 020019A1
	s_waitcnt vmcnt(0)                                         // 00000016F7F4: BF8903F7
	v_fma_mixlo_f16 v156, v162, s12, 0                         // 00000016F7F8: CC21009C 020019A2
	v_fma_mixhi_f16 v156, v163, s12, 0                         // 00000016F800: CC22009C 020019A3
	v_fma_mixlo_f16 v157, v164, s12, 0                         // 00000016F808: CC21009D 020019A4
	v_fma_mixhi_f16 v157, v165, s12, 0                         // 00000016F810: CC22009D 020019A5
	s_waitcnt lgkmcnt(6)                                       // 00000016F818: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016F81C: BF870001
	v_wmma_f32_16x16x16_f16 v[82:89], v[150:157], v[118:125], v[82:89]// 00000016F820: CC404052 1D4AED96
	s_waitcnt lgkmcnt(4)                                       // 00000016F828: BF89FC47
	v_wmma_f32_16x16x16_f16 v[74:81], v[150:157], v[126:133], v[74:81]// 00000016F82C: CC40404A 1D2AFD96
	s_waitcnt lgkmcnt(2)                                       // 00000016F834: BF89FC27
	v_wmma_f32_16x16x16_f16 v[66:73], v[150:157], v[134:141], v[66:73]// 00000016F838: CC404042 1D0B0D96
	s_waitcnt lgkmcnt(0)                                       // 00000016F840: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[150:157], v[142:149], v[58:65]// 00000016F844: CC40403A 1CEB1D96
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000016F84C: 917E0B7E
	s_cbranch_execnz 65447                                     // 00000016F850: BFA6FFA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ff0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016F854: 8C7E0B7E
	s_and_saveexec_b32 s10, s0                                 // 00000016F858: BE8A2000
	s_cbranch_execnz 471                                       // 00000016F85C: BFA601D7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48bc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F860: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000016F864: BE8A2001
	s_cbranch_execnz 490                                       // 00000016F868: BFA601EA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4914>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F86C: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000016F870: BE8A2004
	s_cbranch_execnz 509                                       // 00000016F874: BFA601FD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x496c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F878: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000016F87C: BE8A2005
	s_cbranch_execnz 528                                       // 00000016F880: BFA60210 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x49c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F884: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000016F888: BE8A2006
	s_cbranch_execnz 547                                       // 00000016F88C: BFA60223 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a1c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F890: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000016F894: BE8A2007
	s_cbranch_execnz 566                                       // 00000016F898: BFA60236 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a74>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F89C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000016F8A0: BE8A2008
	s_cbranch_execnz 585                                       // 00000016F8A4: BFA60249 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4acc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8A8: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000016F8AC: BE8A2009
	s_cbranch_execnz 604                                       // 00000016F8B0: BFA6025C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b24>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8B4: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000016F8B8: BE8A2000
	s_cbranch_execnz 622                                       // 00000016F8BC: BFA6026E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b78>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8C0: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000016F8C4: BE8A2001
	s_cbranch_execnz 641                                       // 00000016F8C8: BFA60281 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4bd0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8CC: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000016F8D0: BE8A2004
	s_cbranch_execnz 660                                       // 00000016F8D4: BFA60294 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c28>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8D8: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000016F8DC: BE8A2005
	s_cbranch_execnz 679                                       // 00000016F8E0: BFA602A7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c80>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8E4: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000016F8E8: BE8A2006
	s_cbranch_execnz 698                                       // 00000016F8EC: BFA602BA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4cd8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8F0: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000016F8F4: BE8A2007
	s_cbranch_execnz 717                                       // 00000016F8F8: BFA602CD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d30>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F8FC: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000016F900: BE8A2008
	s_cbranch_execnz 736                                       // 00000016F904: BFA602E0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d88>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F908: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000016F90C: BE8A2009
	s_cbranch_execnz 755                                       // 00000016F910: BFA602F3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4de0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F914: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000016F918: BE8A2000
	s_cbranch_execnz 773                                       // 00000016F91C: BFA60305 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e34>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F920: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000016F924: BE8A2001
	s_cbranch_execnz 792                                       // 00000016F928: BFA60318 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e8c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F92C: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000016F930: BE8A2004
	s_cbranch_execnz 811                                       // 00000016F934: BFA6032B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ee4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F938: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000016F93C: BE8A2005
	s_cbranch_execnz 830                                       // 00000016F940: BFA6033E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f3c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F944: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000016F948: BE8A2006
	s_cbranch_execnz 849                                       // 00000016F94C: BFA60351 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f94>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F950: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000016F954: BE8A2007
	s_cbranch_execnz 868                                       // 00000016F958: BFA60364 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4fec>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F95C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000016F960: BE8A2008
	s_cbranch_execnz 887                                       // 00000016F964: BFA60377 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5044>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F968: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000016F96C: BE8A2009
	s_cbranch_execnz 906                                       // 00000016F970: BFA6038A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x509c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F974: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000016F978: BE8A2000
	s_cbranch_execnz 924                                       // 00000016F97C: BFA6039C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50f0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000016F980: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 00000016F984: BE802001
	s_cbranch_execnz 943                                       // 00000016F988: BFA603AF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5148>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F98C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016F990: BE802004
	s_cbranch_execnz 962                                       // 00000016F994: BFA603C2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51a0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F998: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016F99C: BE802005
	s_cbranch_execnz 981                                       // 00000016F9A0: BFA603D5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51f8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F9A4: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016F9A8: BE802006
	s_cbranch_execnz 1000                                      // 00000016F9AC: BFA603E8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5250>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F9B0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016F9B4: BE802007
	s_cbranch_execnz 1019                                      // 00000016F9B8: BFA603FB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F9BC: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016F9C0: BE802008
	s_cbranch_execnz 1038                                      // 00000016F9C4: BFA6040E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5300>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016F9C8: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016F9CC: BE802009
	s_cbranch_execz 18                                         // 00000016F9D0: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x431c>
	ds_load_b32 v3, v111 offset:56                             // 00000016F9D4: D8D80038 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000016F9DC: BF89FC07
	v_fmac_f32_e32 v65, v33, v3                                // 00000016F9E0: 56820721
	v_mad_u64_u32 v[3:4], null, 0x3000, v117, v[92:93]         // 00000016F9E4: D6FE7C03 0572EAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016F9F0: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v65                          // 00000016F9F4: 100A82FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016F9FC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FA04: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016FA08: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016FA14: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016FA1C: 8C7E007E
	s_mul_f32 s0, s19, 0x3fb8aa3b                              // 00000016FA20: A200FF13 3FB8AA3B
	v_or_b32_e32 v4, s18, v96                                  // 00000016FA28: 3808C012
	v_dual_mov_b32 v26, v94 :: v_dual_mov_b32 v27, v95         // 00000016FA2C: CA10015E 1A1A015F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016FA34: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 00000016FA38: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 00000016FA40: BE846300
	s_fmamk_f32 s1, s19, 0x3fb8aa3b, s1                        // 00000016FA44: A3010113 3FB8AA3B
	s_cmp_nlt_f32 s19, 0xc2ce8ed0                              // 00000016FA4C: BF4EFF13 C2CE8ED0
	s_mov_b32 s5, 0                                            // 00000016FA54: BE850080
	s_sub_f32 s0, s0, s4                                       // 00000016FA58: A0800400
	s_fmamk_f32 s1, s19, 0x32a5705f, s1                        // 00000016FA5C: A3010113 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000016FA64: BF87059B
	s_add_f32 s0, s0, s1                                       // 00000016FA68: A0000100
	v_exp_f32_e32 v3, s0                                       // 00000016FA6C: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 00000016FA70: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000016FA74: BF870585
	.long 0xd71c0003                                           // 00000016FA78: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000016FA7C: 02000103
	s_cselect_b32 s0, -1, 0                                    // 00000016FA80: 980080C1
	s_cmp_ngt_f32 s19, 0x42b17218                              // 00000016FA84: BF4BFF13 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000016FA8C: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 00000016FA90: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 00000016FA98: 980180C1
	.long 0xd4440000                                           // 00000016FA9C: D4440000
	v_cndmask_b32_e32 v1, s41, v4, vcc_lo                      // 00000016FAA0: 02020829
	v_cndmask_b32_e64 v28, 0x7f800000, v3, s1                  // 00000016FAA4: D501001C 000606FF 7F800000
	s_branch 120                                               // 00000016FAB0: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4594>
	s_set_inst_prefetch_distance 0x2                           // 00000016FAB4: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016FAB8: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000016FABC: BF89FC07
	s_barrier                                                  // 00000016FAC0: BFBD0000
	buffer_gl0_inv                                             // 00000016FAC4: E0AC0000 00000000
	ds_load_b128 v[30:33], v106                                // 00000016FACC: DBFC0000 1E00006A
	ds_load_b128 v[34:37], v106 offset:16                      // 00000016FAD4: DBFC0010 2200006A
	ds_load_b128 v[38:41], v114                                // 00000016FADC: DBFC0000 26000072
	ds_load_b128 v[42:45], v114 offset:16                      // 00000016FAE4: DBFC0010 2A000072
	ds_load_b128 v[46:49], v106 offset:32                      // 00000016FAEC: DBFC0020 2E00006A
	ds_load_b128 v[50:53], v106 offset:48                      // 00000016FAF4: DBFC0030 3200006A
	ds_load_b128 v[54:57], v114 offset:32                      // 00000016FAFC: DBFC0020 36000072
	ds_load_b128 v[58:61], v114 offset:48                      // 00000016FB04: DBFC0030 3A000072
	v_mov_b32_e32 v9, v2                                       // 00000016FB0C: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000016FB10: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000016FB14: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000016FB18: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000016FB1C: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000016FB20: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000016FB24: 7E100302
	v_mov_b32_e32 v69, v9                                      // 00000016FB28: 7E8A0309
	v_dual_mov_b32 v65, v5 :: v_dual_mov_b32 v64, v4           // 00000016FB2C: CA100105 41400104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016FB34: BF870214
	v_dual_mov_b32 v67, v7 :: v_dual_mov_b32 v66, v6           // 00000016FB38: CA100107 43420106
	v_dual_mov_b32 v68, v8 :: v_dual_mov_b32 v63, v3           // 00000016FB40: CA100108 443E0103
	v_mov_b32_e32 v62, v2                                      // 00000016FB48: 7E7C0302
	ds_load_b128 v[74:77], v106 offset:80                      // 00000016FB4C: DBFC0050 4A00006A
	ds_load_b128 v[70:73], v106 offset:64                      // 00000016FB54: DBFC0040 4600006A
	ds_load_b128 v[82:85], v114 offset:80                      // 00000016FB5C: DBFC0050 52000072
	ds_load_b128 v[78:81], v114 offset:64                      // 00000016FB64: DBFC0040 4E000072
	ds_load_b128 v[119:122], v106 offset:112                   // 00000016FB6C: DBFC0070 7700006A
	ds_load_b128 v[115:118], v106 offset:96                    // 00000016FB74: DBFC0060 7300006A
	ds_load_2addr_b32 v[3:4], v29 offset0:16 offset1:18        // 00000016FB7C: D8DC1210 0300001D
	ds_load_b128 v[127:130], v114 offset:112                   // 00000016FB84: DBFC0070 7F000072
	ds_load_b128 v[123:126], v114 offset:96                    // 00000016FB8C: DBFC0060 7B000072
	ds_load_2addr_b32 v[5:6], v29 offset0:20 offset1:22        // 00000016FB94: D8DC1614 0500001D
	ds_load_2addr_b32 v[7:8], v29 offset0:24 offset1:26        // 00000016FB9C: D8DC1A18 0700001D
	.long 0xd700011a                                           // 00000016FBA4: D700011A
	v_cndmask_b32_e32 v1, 0x80, v26, vcc_lo                    // 00000016FBA8: 020234FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FBB0: BF870001
	v_add_co_ci_u32_e64 v27, null, 0, v27, s1                  // 00000016FBB4: D5207C1B 00063680
	s_waitcnt lgkmcnt(15)                                      // 00000016FBBC: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[62:69], v[30:37], v[38:45], v[62:69]// 00000016FBC0: CC40403E 1CFA4D1E
	ds_load_2addr_b32 v[30:31], v29 offset0:28 offset1:30      // 00000016FBC8: D8DC1E1C 1E00001D
	s_add_i32 s1, s5, 32                                       // 00000016FBD0: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 00000016FBD4: B585005F
	s_mov_b32 s5, s1                                           // 00000016FBD8: BE850001
	s_waitcnt lgkmcnt(12)                                      // 00000016FBDC: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[62:69], v[46:53], v[54:61], v[62:69]// 00000016FBE0: CC40403E 1CFA6D2E
	s_waitcnt lgkmcnt(8)                                       // 00000016FBE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FBEC: BF870001
	v_wmma_f32_16x16x16_f16 v[62:69], v[70:77], v[78:85], v[62:69]// 00000016FBF0: CC40403E 1CFA9D46
	s_waitcnt lgkmcnt(5)                                       // 00000016FBF8: BF89FC57
	v_mul_f32_e32 v3, v28, v3                                  // 00000016FBFC: 1006071C
	v_mul_f32_e32 v4, v28, v4                                  // 00000016FC00: 1008091C
	s_waitcnt lgkmcnt(2)                                       // 00000016FC04: BF89FC27
	v_mul_f32_e32 v5, v28, v5                                  // 00000016FC08: 100A0B1C
	v_wmma_f32_16x16x16_f16 v[62:69], v[115:122], v[123:130], v[62:69]// 00000016FC0C: CC40403E 1CFAF773
	s_waitcnt lgkmcnt(1)                                       // 00000016FC14: BF89FC17
	v_mul_f32_e32 v7, v28, v7                                  // 00000016FC18: 100E0F1C
	v_mul_f32_e32 v6, v28, v6                                  // 00000016FC1C: 100C0D1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016FC20: BF870193
	v_dual_mul_f32 v8, v28, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v62// 00000016FC24: C8C0111C 08027CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v66                         // 00000016FC30: 560E84FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000016FC38: BF89FC07
	v_mul_f32_e32 v9, v28, v30                                 // 00000016FC3C: 10123D1C
	v_mul_f32_e32 v30, v28, v31                                // 00000016FC40: 103C3F1C
	v_dual_fmac_f32 v4, 0x3b800000, v63 :: v_dual_fmac_f32 v5, 0x3b800000, v64// 00000016FC44: C8007EFF 040480FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v67                         // 00000016FC50: 561086FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v65                         // 00000016FC58: 560C82FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000016FC60: BF870004
	v_dual_fmac_f32 v30, 0x3b800000, v69 :: v_dual_fmac_f32 v9, 0x3b800000, v68// 00000016FC64: C8008AFF 1E0888FF 3B800000
	ds_store_2addr_b32 v29, v3, v4 offset0:16 offset1:18       // 00000016FC70: D8381210 0004031D
	ds_store_2addr_b32 v29, v5, v6 offset0:20 offset1:22       // 00000016FC78: D8381614 0006051D
	ds_store_2addr_b32 v29, v7, v8 offset0:24 offset1:26       // 00000016FC80: D8381A18 0008071D
	ds_store_2addr_b32 v29, v9, v30 offset0:28 offset1:30      // 00000016FC88: D8381E1C 001E091D
	s_cbranch_scc1 61345                                       // 00000016FC90: BFA2EFA1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x418>
	v_dual_mov_b32 v4, v26 :: v_dual_mov_b32 v5, v27           // 00000016FC94: CA10011A 0404011B
	v_mov_b32_e32 v6, v113                                     // 00000016FC9C: 7E0C0371
	v_mov_b32_e32 v7, v97                                      // 00000016FCA0: 7E0E0361
	s_mov_b32 s6, 0                                            // 00000016FCA4: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 00000016FCA8: BC7C0000
	s_barrier                                                  // 00000016FCAC: BFBD0000
	buffer_gl0_inv                                             // 00000016FCB0: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000016FCB8: BF840001
	s_branch 18                                                // 00000016FCBC: BFA00012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4608>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016FCC0: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000016FCC4: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000016FCCC: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000016FCD0: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000016FCD4: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000016FCDC: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000016FCE4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000016FCE8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000016FCF0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000016FCF8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016FCFC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000016FD00: 917E067E
	s_cbranch_execz 13                                         // 00000016FD04: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x463c>
	.long 0x7e063880                                           // 00000016FD08: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000016FD0C: BE812000
	s_cbranch_execz 65515                                      // 00000016FD10: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45c0>
	global_load_b32 v3, v[4:5], off                            // 00000016FD14: DC520000 037C0004
	ds_load_b32 v8, v112                                       // 00000016FD1C: D8D80000 08000070
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000016FD24: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000016FD28: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FD2C: BF870001
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016FD30: CC210003 02001903
	s_branch 65505                                             // 00000016FD38: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45c0>
	s_set_inst_prefetch_distance 0x2                           // 00000016FD3C: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016FD40: 8C7E067E
	v_lshl_add_u32 v29, s5, 2, v107                            // 00000016FD44: D646001D 05AD0405
	s_waitcnt lgkmcnt(0)                                       // 00000016FD4C: BF89FC07
	s_barrier                                                  // 00000016FD50: BFBD0000
	buffer_gl0_inv                                             // 00000016FD54: E0AC0000 00000000
	ds_load_b128 v[30:33], v106                                // 00000016FD5C: DBFC0000 1E00006A
	ds_load_b128 v[34:37], v106 offset:16                      // 00000016FD64: DBFC0010 2200006A
	ds_load_b128 v[38:41], v106 offset:32                      // 00000016FD6C: DBFC0020 2600006A
	ds_load_b128 v[42:45], v106 offset:48                      // 00000016FD74: DBFC0030 2A00006A
	ds_load_b128 v[46:49], v114                                // 00000016FD7C: DBFC0000 2E000072
	ds_load_b128 v[50:53], v114 offset:16                      // 00000016FD84: DBFC0010 32000072
	ds_load_b128 v[54:57], v114 offset:32                      // 00000016FD8C: DBFC0020 36000072
	ds_load_b128 v[58:61], v114 offset:48                      // 00000016FD94: DBFC0030 3A000072
	ds_load_b128 v[66:69], v106 offset:80                      // 00000016FD9C: DBFC0050 4200006A
	ds_load_b128 v[62:65], v106 offset:64                      // 00000016FDA4: DBFC0040 3E00006A
	ds_load_b128 v[74:77], v114 offset:80                      // 00000016FDAC: DBFC0050 4A000072
	ds_load_b128 v[70:73], v114 offset:64                      // 00000016FDB4: DBFC0040 46000072
	ds_load_b128 v[82:85], v106 offset:112                     // 00000016FDBC: DBFC0070 5200006A
	ds_load_b128 v[78:81], v106 offset:96                      // 00000016FDC4: DBFC0060 4E00006A
	ds_load_b128 v[119:122], v114 offset:112                   // 00000016FDCC: DBFC0070 77000072
	ds_load_b128 v[115:118], v114 offset:96                    // 00000016FDD4: DBFC0060 73000072
	ds_load_2addr_b32 v[86:87], v29 offset1:2                  // 00000016FDDC: D8DC0200 5600001D
	ds_load_2addr_b32 v[88:89], v29 offset0:4 offset1:6        // 00000016FDE4: D8DC0604 5800001D
	ds_load_2addr_b32 v[131:132], v29 offset0:8 offset1:10     // 00000016FDEC: D8DC0A08 8300001D
	ds_load_2addr_b32 v[133:134], v29 offset0:12 offset1:14    // 00000016FDF4: D8DC0E0C 8500001D
	v_mov_b32_e32 v9, v2                                       // 00000016FDFC: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000016FE00: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000016FE04: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000016FE08: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000016FE0C: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000016FE10: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000016FE14: 7E100302
	v_mov_b32_e32 v130, v9                                     // 00000016FE18: 7F040309
	v_dual_mov_b32 v126, v5 :: v_dual_mov_b32 v125, v4         // 00000016FE1C: CA100105 7E7C0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016FE24: BF870214
	v_dual_mov_b32 v128, v7 :: v_dual_mov_b32 v127, v6         // 00000016FE28: CA100107 807E0106
	v_dual_mov_b32 v129, v8 :: v_dual_mov_b32 v124, v3         // 00000016FE30: CA100108 817C0103
	v_mov_b32_e32 v123, v2                                     // 00000016FE38: 7EF60302
	s_waitcnt lgkmcnt(3)                                       // 00000016FE3C: BF89FC37
	v_dual_mov_b32 v4, v26 :: v_dual_mul_f32 v3, v28, v86      // 00000016FE40: CA06011A 0402AD1C
	v_mul_f32_e32 v8, v28, v87                                 // 00000016FE48: 1010AF1C
	s_waitcnt lgkmcnt(2)                                       // 00000016FE4C: BF89FC27
	v_mul_f32_e32 v9, v28, v88                                 // 00000016FE50: 1012B11C
	v_wmma_f32_16x16x16_f16 v[123:130], v[30:37], v[46:53], v[123:130]// 00000016FE54: CC40407B 1DEE5D1E
	v_mul_f32_e32 v30, v28, v89                                // 00000016FE5C: 103CB31C
	s_waitcnt lgkmcnt(1)                                       // 00000016FE60: BF89FC17
	v_mul_f32_e32 v31, v28, v131                               // 00000016FE64: 103F071C
	v_dual_mul_f32 v32, v28, v132 :: v_dual_mov_b32 v5, v27    // 00000016FE68: C8D1091C 2004011B
	v_wmma_f32_16x16x16_f16 v[123:130], v[38:45], v[54:61], v[123:130]// 00000016FE70: CC40407B 1DEE6D26
	v_mov_b32_e32 v6, v113                                     // 00000016FE78: 7E0C0371
	v_mov_b32_e32 v7, v97                                      // 00000016FE7C: 7E0E0361
	s_mov_b32 s6, 0                                            // 00000016FE80: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016FE84: BF870093
	v_wmma_f32_16x16x16_f16 v[123:130], v[62:69], v[70:77], v[123:130]// 00000016FE88: CC40407B 1DEE8D3E
	v_wmma_f32_16x16x16_f16 v[123:130], v[78:85], v[115:122], v[123:130]// 00000016FE90: CC40407B 1DEEE74E
	s_waitcnt lgkmcnt(0)                                       // 00000016FE98: BF89FC07
	v_mul_f32_e32 v33, v28, v133                               // 00000016FE9C: 10430B1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016FEA0: BF870192
	v_dual_mul_f32 v34, v28, v134 :: v_dual_fmac_f32 v3, 0x3b800000, v123// 00000016FEA4: C8C10D1C 2202F6FF 3B800000
	v_dual_fmac_f32 v8, 0x3b800000, v124 :: v_dual_fmac_f32 v9, 0x3b800000, v125// 00000016FEB0: C800F8FF 0808FAFF 3B800000
	v_dual_fmac_f32 v30, 0x3b800000, v126 :: v_dual_fmac_f32 v31, 0x3b800000, v127// 00000016FEBC: C800FCFF 1E1EFEFF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016FEC8: BF870214
	v_dual_fmac_f32 v32, 0x3b800000, v128 :: v_dual_fmac_f32 v33, 0x3b800000, v129// 00000016FECC: C80100FF 202102FF 3B800000
	v_fmac_f32_e32 v34, 0x3b800000, v130                       // 00000016FED8: 564504FF 3B800000
	ds_store_2addr_b32 v29, v3, v8 offset1:2                   // 00000016FEE0: D8380200 0008031D
	ds_store_2addr_b32 v29, v9, v30 offset0:4 offset1:6        // 00000016FEE8: D8380604 001E091D
	ds_store_2addr_b32 v29, v31, v32 offset0:8 offset1:10      // 00000016FEF0: D8380A08 00201F1D
	ds_store_2addr_b32 v29, v33, v34 offset0:12 offset1:14     // 00000016FEF8: D8380E0C 0022211D
	s_waitcnt lgkmcnt(0)                                       // 00000016FF00: BF89FC07
	s_barrier                                                  // 00000016FF04: BFBD0000
	buffer_gl0_inv                                             // 00000016FF08: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000016FF10: BF840001
	s_branch 28                                                // 00000016FF14: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4888>
	s_nop 0                                                    // 00000016FF18: BF800000
	s_nop 0                                                    // 00000016FF1C: BF800000
	s_nop 0                                                    // 00000016FF20: BF800000
	s_nop 0                                                    // 00000016FF24: BF800000
	s_nop 0                                                    // 00000016FF28: BF800000
	s_nop 0                                                    // 00000016FF2C: BF800000
	s_nop 0                                                    // 00000016FF30: BF800000
	s_nop 0                                                    // 00000016FF34: BF800000
	s_nop 0                                                    // 00000016FF38: BF800000
	s_nop 0                                                    // 00000016FF3C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016FF40: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000016FF44: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000016FF4C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000016FF50: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000016FF54: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000016FF5C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000016FF64: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000016FF68: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000016FF70: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000016FF78: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016FF7C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000016FF80: 917E067E
	s_cbranch_execz 65227                                      // 00000016FF84: BFA5FECB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x43b4>
	.long 0x7e063880                                           // 00000016FF88: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000016FF8C: BE812000
	s_cbranch_execz 65515                                      // 00000016FF90: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4840>
	global_load_b32 v3, v[4:5], off offset:64                  // 00000016FF94: DC520040 037C0004
	ds_load_b32 v8, v112                                       // 00000016FF9C: D8D80000 08000070
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000016FFA4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000016FFA8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FFAC: BF870001
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000016FFB0: CC210003 02001903
	s_branch 65505                                             // 00000016FFB8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4840>
	ds_load_b32 v3, v111                                       // 00000016FFBC: D8D80000 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000016FFC4: BF89FC07
	v_fma_f32 v3, v42, v3, v82                                 // 00000016FFC8: D6130003 054A072A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016FFD0: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000016FFD4: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[92:93]           // 00000016FFDC: D6FE7C03 05720AFF 00003000
	v_bfe_u32 v82, v42, 16, 1                                  // 00000016FFE8: D6100052 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016FFF0: BF870001
	v_add3_u32 v42, v42, v82, 0x7fff                           // 00000016FFF4: D655002A 03FEA52A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170000: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170008: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000017000C: BE8A2001
	s_cbranch_execz 65046                                      // 000000170010: BFA5FE16 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x416c>
	ds_load_b32 v3, v111 offset:8                              // 000000170014: D8D80008 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017001C: BF89FC07
	v_fma_f32 v3, v43, v3, v83                                 // 000000170020: D6130003 054E072B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170028: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000017002C: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[92:93]           // 000000170034: D6FE7C03 05720CFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170040: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170048: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000017004C: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170058: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170060: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000170064: BE8A2004
	s_cbranch_execz 65027                                      // 000000170068: BFA5FE03 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4178>
	ds_load_b32 v3, v111 offset:16                             // 00000017006C: D8D80010 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170074: BF89FC07
	v_fma_f32 v3, v44, v3, v84                                 // 000000170078: D6130003 0552072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170080: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170084: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[92:93]           // 00000017008C: D6FE7C03 05720EFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170098: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001700A0: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001700A4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 0000001700B0: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001700B8: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 0000001700BC: BE8A2005
	s_cbranch_execz 65008                                      // 0000001700C0: BFA5FDF0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4184>
	ds_load_b32 v3, v111 offset:24                             // 0000001700C4: D8D80018 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001700CC: BF89FC07
	v_fma_f32 v3, v45, v3, v85                                 // 0000001700D0: D6130003 0556072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001700D8: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 0000001700DC: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[92:93]           // 0000001700E4: D6FE7C03 057210FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001700F0: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001700F8: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001700FC: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170108: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170110: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000170114: BE8A2006
	s_cbranch_execz 64989                                      // 000000170118: BFA5FDDD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4190>
	ds_load_b32 v3, v111 offset:32                             // 00000017011C: D8D80020 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170124: BF89FC07
	v_fma_f32 v3, v46, v3, v86                                 // 000000170128: D6130003 055A072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170130: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170134: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[92:93]           // 00000017013C: D6FE7C03 057212FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170148: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170150: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170154: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170160: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170168: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000017016C: BE8A2007
	s_cbranch_execz 64970                                      // 000000170170: BFA5FDCA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x419c>
	ds_load_b32 v3, v111 offset:40                             // 000000170174: D8D80028 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017017C: BF89FC07
	v_fma_f32 v3, v47, v3, v87                                 // 000000170180: D6130003 055E072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170188: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000017018C: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v115, v[92:93]         // 000000170194: D6FE7C03 0572E6FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001701A0: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001701A8: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001701AC: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 0000001701B8: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001701C0: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 0000001701C4: BE8A2008
	s_cbranch_execz 64951                                      // 0000001701C8: BFA5FDB7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41a8>
	ds_load_b32 v3, v111 offset:48                             // 0000001701CC: D8D80030 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001701D4: BF89FC07
	v_fma_f32 v3, v48, v3, v88                                 // 0000001701D8: D6130003 05620730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001701E0: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 0000001701E4: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v116, v[92:93]         // 0000001701EC: D6FE7C03 0572E8FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001701F8: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170200: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170204: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170210: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170218: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000017021C: BE8A2009
	s_cbranch_execz 64932                                      // 000000170220: BFA5FDA4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41b4>
	ds_load_b32 v3, v111 offset:56                             // 000000170224: D8D80038 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017022C: BF89FC07
	v_fmac_f32_e32 v89, v49, v3                                // 000000170230: 56B20731
	v_mad_u64_u32 v[3:4], null, 0x3000, v117, v[92:93]         // 000000170234: D6FE7C03 0572EAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170240: BF870092
	v_mul_f32_e32 v42, 0x3b800000, v89                         // 000000170244: 1054B2FF 3B800000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000017024C: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170254: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170258: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 000000170264: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000017026C: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000170270: BE8A2000
	s_cbranch_execz 64914                                      // 000000170274: BFA5FD92 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41c0>
	ds_load_b32 v3, v111                                       // 000000170278: D8D80000 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170280: BF89FC07
	v_fma_f32 v3, v50, v3, v74                                 // 000000170284: D6130003 052A0732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017028C: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170290: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[92:93]           // 000000170298: D6FE7C03 05720AFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001702A4: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001702AC: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001702B0: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 0000001702BC: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001702C4: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 0000001702C8: BE8A2001
	s_cbranch_execz 64895                                      // 0000001702CC: BFA5FD7F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41cc>
	ds_load_b32 v3, v111 offset:8                              // 0000001702D0: D8D80008 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001702D8: BF89FC07
	v_fma_f32 v3, v51, v3, v75                                 // 0000001702DC: D6130003 052E0733
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001702E4: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 0000001702E8: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[92:93]           // 0000001702F0: D6FE7C03 05720CFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001702FC: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170304: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170308: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 000000170314: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000017031C: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000170320: BE8A2004
	s_cbranch_execz 64876                                      // 000000170324: BFA5FD6C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41d8>
	ds_load_b32 v3, v111 offset:16                             // 000000170328: D8D80010 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170330: BF89FC07
	v_fma_f32 v3, v52, v3, v76                                 // 000000170334: D6130003 05320734
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017033C: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170340: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[92:93]           // 000000170348: D6FE7C03 05720EFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170354: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017035C: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170360: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 00000017036C: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170374: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000170378: BE8A2005
	s_cbranch_execz 64857                                      // 00000017037C: BFA5FD59 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41e4>
	ds_load_b32 v3, v111 offset:24                             // 000000170380: D8D80018 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170388: BF89FC07
	v_fma_f32 v3, v53, v3, v77                                 // 00000017038C: D6130003 05360735
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170394: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170398: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[92:93]           // 0000001703A0: D6FE7C03 057210FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001703AC: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001703B4: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001703B8: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 0000001703C4: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001703CC: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 0000001703D0: BE8A2006
	s_cbranch_execz 64838                                      // 0000001703D4: BFA5FD46 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41f0>
	ds_load_b32 v3, v111 offset:32                             // 0000001703D8: D8D80020 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001703E0: BF89FC07
	v_fma_f32 v3, v54, v3, v78                                 // 0000001703E4: D6130003 053A0736
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001703EC: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 0000001703F0: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[92:93]           // 0000001703F8: D6FE7C03 057212FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170404: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017040C: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170410: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 00000017041C: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170424: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 000000170428: BE8A2007
	s_cbranch_execz 64819                                      // 00000017042C: BFA5FD33 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41fc>
	ds_load_b32 v3, v111 offset:40                             // 000000170430: D8D80028 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170438: BF89FC07
	v_fma_f32 v3, v55, v3, v79                                 // 00000017043C: D6130003 053E0737
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170444: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 000000170448: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v115, v[92:93]         // 000000170450: D6FE7C03 0572E6FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000017045C: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170464: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170468: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 000000170474: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000017047C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000170480: BE8A2008
	s_cbranch_execz 64800                                      // 000000170484: BFA5FD20 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4208>
	ds_load_b32 v3, v111 offset:48                             // 000000170488: D8D80030 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170490: BF89FC07
	v_fma_f32 v3, v56, v3, v80                                 // 000000170494: D6130003 05420738
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017049C: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 0000001704A0: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v116, v[92:93]         // 0000001704A8: D6FE7C03 0572E8FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001704B4: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001704BC: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001704C0: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 0000001704CC: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001704D4: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001704D8: BE8A2009
	s_cbranch_execz 64781                                      // 0000001704DC: BFA5FD0D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4214>
	ds_load_b32 v3, v111 offset:56                             // 0000001704E0: D8D80038 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001704E8: BF89FC07
	v_fmac_f32_e32 v81, v57, v3                                // 0000001704EC: 56A20739
	v_mad_u64_u32 v[3:4], null, 0x3000, v117, v[92:93]         // 0000001704F0: D6FE7C03 0572EAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001704FC: BF870092
	v_mul_f32_e32 v42, 0x3b800000, v81                         // 000000170500: 1054A2FF 3B800000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000170508: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170510: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000170514: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off offset:32         // 000000170520: DC960020 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170528: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000017052C: BE8A2000
	s_cbranch_execz 64763                                      // 000000170530: BFA5FCFB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4220>
	ds_load_b32 v3, v111                                       // 000000170534: D8D80000 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017053C: BF89FC07
	v_fma_f32 v3, v34, v3, v66                                 // 000000170540: D6130003 050A0722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170548: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000017054C: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[92:93]           // 000000170554: D6FE7C03 05720AFF 00003000
	v_bfe_u32 v42, v34, 16, 1                                  // 000000170560: D610002A 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170568: BF870001
	v_add3_u32 v34, v34, v42, 0x7fff                           // 00000017056C: D6550022 03FE5522 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 000000170578: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170580: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000170584: BE8A2001
	s_cbranch_execz 64744                                      // 000000170588: BFA5FCE8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x422c>
	ds_load_b32 v3, v111 offset:8                              // 00000017058C: D8D80008 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170594: BF89FC07
	v_fma_f32 v3, v35, v3, v67                                 // 000000170598: D6130003 050E0723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001705A0: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 0000001705A4: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[92:93]           // 0000001705AC: D6FE7C03 05720CFF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001705B8: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001705C0: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000001705C4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 0000001705D0: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001705D8: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 0000001705DC: BE8A2004
	s_cbranch_execz 64725                                      // 0000001705E0: BFA5FCD5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4238>
	ds_load_b32 v3, v111 offset:16                             // 0000001705E4: D8D80010 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001705EC: BF89FC07
	v_fma_f32 v3, v36, v3, v68                                 // 0000001705F0: D6130003 05120724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001705F8: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 0000001705FC: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[92:93]           // 000000170604: D6FE7C03 05720EFF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 000000170610: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170618: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000017061C: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 000000170628: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170630: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000170634: BE8A2005
	s_cbranch_execz 64706                                      // 000000170638: BFA5FCC2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4244>
	ds_load_b32 v3, v111 offset:24                             // 00000017063C: D8D80018 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170644: BF89FC07
	v_fma_f32 v3, v37, v3, v69                                 // 000000170648: D6130003 05160725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170650: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 000000170654: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[92:93]           // 00000017065C: D6FE7C03 057210FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 000000170668: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170670: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000170674: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 000000170680: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170688: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000017068C: BE8A2006
	s_cbranch_execz 64687                                      // 000000170690: BFA5FCAF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4250>
	ds_load_b32 v3, v111 offset:32                             // 000000170694: D8D80020 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017069C: BF89FC07
	v_fma_f32 v3, v38, v3, v70                                 // 0000001706A0: D6130003 051A0726
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001706A8: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 0000001706AC: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[92:93]           // 0000001706B4: D6FE7C03 057212FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001706C0: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001706C8: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000001706CC: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 0000001706D8: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001706E0: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 0000001706E4: BE8A2007
	s_cbranch_execz 64668                                      // 0000001706E8: BFA5FC9C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x425c>
	ds_load_b32 v3, v111 offset:40                             // 0000001706EC: D8D80028 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001706F4: BF89FC07
	v_fma_f32 v3, v39, v3, v71                                 // 0000001706F8: D6130003 051E0727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170700: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 000000170704: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v115, v[92:93]         // 00000017070C: D6FE7C03 0572E6FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 000000170718: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170720: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000170724: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 000000170730: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170738: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000017073C: BE8A2008
	s_cbranch_execz 64649                                      // 000000170740: BFA5FC89 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4268>
	ds_load_b32 v3, v111 offset:48                             // 000000170744: D8D80030 0300006F
	s_waitcnt lgkmcnt(0)                                       // 00000017074C: BF89FC07
	v_fma_f32 v3, v40, v3, v72                                 // 000000170750: D6130003 05220728
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170758: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000017075C: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v116, v[92:93]         // 000000170764: D6FE7C03 0572E8FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 000000170770: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170778: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000017077C: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 000000170788: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 000000170790: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000170794: BE8A2009
	s_cbranch_execz 64630                                      // 000000170798: BFA5FC76 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4274>
	ds_load_b32 v3, v111 offset:56                             // 00000017079C: D8D80038 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001707A4: BF89FC07
	v_fmac_f32_e32 v73, v41, v3                                // 0000001707A8: 56920729
	v_mad_u64_u32 v[3:4], null, 0x3000, v117, v[92:93]         // 0000001707AC: D6FE7C03 0572EAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001707B8: BF870092
	v_mul_f32_e32 v34, 0x3b800000, v73                         // 0000001707BC: 104492FF 3B800000
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001707C4: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001707CC: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000001707D0: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:64         // 0000001707DC: DC960040 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001707E4: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 0000001707E8: BE8A2000
	s_cbranch_execz 64612                                      // 0000001707EC: BFA5FC64 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4280>
	ds_load_b32 v3, v111                                       // 0000001707F0: D8D80000 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001707F8: BF89FC07
	v_fma_f32 v3, v26, v3, v58                                 // 0000001707FC: D6130003 04EA071A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170804: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 000000170808: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[92:93]           // 000000170810: D6FE7C03 05720AFF 00003000
	v_bfe_u32 v34, v26, 16, 1                                  // 00000017081C: D6100022 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170824: BF870001
	v_add3_u32 v5, v26, v34, 0x7fff                            // 000000170828: D6550005 03FE451A 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000170834: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s10                             // 00000017083C: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 000000170840: BE802001
	s_cbranch_execz 64593                                      // 000000170844: BFA5FC51 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x428c>
	ds_load_b32 v3, v111 offset:8                              // 000000170848: D8D80008 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170850: BF89FC07
	v_fma_f32 v3, v27, v3, v59                                 // 000000170854: D6130003 04EE071B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017085C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000170860: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[92:93]           // 000000170868: D6FE7C03 05720CFF 00003000
	v_bfe_u32 v26, v5, 16, 1                                   // 000000170874: D610001A 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017087C: BF870001
	v_add3_u32 v5, v5, v26, 0x7fff                             // 000000170880: D6550005 03FE3505 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017088C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170894: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000170898: BE802004
	s_cbranch_execz 64574                                      // 00000017089C: BFA5FC3E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4298>
	ds_load_b32 v3, v111 offset:16                             // 0000001708A0: D8D80010 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001708A8: BF89FC07
	v_fma_f32 v3, v28, v3, v60                                 // 0000001708AC: D6130003 04F2071C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001708B4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001708B8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[92:93]           // 0000001708C0: D6FE7C03 05720EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001708CC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001708D4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001708D8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 0000001708E4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001708EC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001708F0: BE802005
	s_cbranch_execz 64555                                      // 0000001708F4: BFA5FC2B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42a4>
	ds_load_b32 v3, v111 offset:24                             // 0000001708F8: D8D80018 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170900: BF89FC07
	v_fma_f32 v3, v29, v3, v61                                 // 000000170904: D6130003 04F6071D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017090C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000170910: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[92:93]           // 000000170918: D6FE7C03 057210FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000170924: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017092C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000170930: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000017093C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170944: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000170948: BE802006
	s_cbranch_execz 64536                                      // 00000017094C: BFA5FC18 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42b0>
	ds_load_b32 v3, v111 offset:32                             // 000000170950: D8D80020 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170958: BF89FC07
	v_fma_f32 v3, v30, v3, v62                                 // 00000017095C: D6130003 04FA071E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170964: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000170968: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[92:93]           // 000000170970: D6FE7C03 057212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000017097C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170984: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000170988: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000170994: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017099C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001709A0: BE802007
	s_cbranch_execz 64517                                      // 0000001709A4: BFA5FC05 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42bc>
	ds_load_b32 v3, v111 offset:40                             // 0000001709A8: D8D80028 0300006F
	s_waitcnt lgkmcnt(0)                                       // 0000001709B0: BF89FC07
	v_fma_f32 v3, v31, v3, v63                                 // 0000001709B4: D6130003 04FE071F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001709BC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001709C0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v115, v[92:93]         // 0000001709C8: D6FE7C03 0572E6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001709D4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001709DC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001709E0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 0000001709EC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001709F4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001709F8: BE802008
	s_cbranch_execz 64498                                      // 0000001709FC: BFA5FBF2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42c8>
	ds_load_b32 v3, v111 offset:48                             // 000000170A00: D8D80030 0300006F
	s_waitcnt lgkmcnt(0)                                       // 000000170A08: BF89FC07
	v_fma_f32 v3, v32, v3, v64                                 // 000000170A0C: D6130003 05020720
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000170A14: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000170A18: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v116, v[92:93]         // 000000170A20: D6FE7C03 0572E8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000170A2C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000170A34: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000170A38: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000170A44: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000170A4C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000170A50: BE802009
	s_cbranch_execnz 64479                                     // 000000170A54: BFA6FBDF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42d4>
	s_branch 64496                                             // 000000170A58: BFA0FBF0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x431c>
	v_mov_b32_e32 v2, v97                                      // 000000170A5C: 7E040361
	v_mov_b32_e32 v3, v1                                       // 000000170A60: 7E060301
	s_add_u32 s0, s33, s36                                     // 000000170A64: 80002421
	.long 0xd73c0000                                           // 000000170A68: D73C0000
	v_cndmask_b32_e32 v1, 9, v90, vcc_lo                       // 000000170A6C: 0202B489
	s_addc_u32 s1, s40, s37                                    // 000000170A70: 82012528
	s_add_u32 s2, s38, s34                                     // 000000170A74: 80022226
	s_addc_u32 s3, s39, s35                                    // 000000170A78: 82032327
	s_add_u32 s0, s2, s0                                       // 000000170A7C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000170A80: 82010103
	v_lshlrev_b32_e32 v4, 2, v96                               // 000000170A84: 3008C082
	.long 0xd7006a00                                           // 000000170A88: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000170A8C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000170A90: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000170A94: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000170A9C: BE810080
	.long 0xd7006a00                                           // 000000170AA0: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 000000170AA4: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000170AA8: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v96                           // 000000170AB0: 1608C0FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000170AB8: BF870093
	.long 0xd7006a00                                           // 000000170ABC: D7006A00
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000170AC0: 0202000E
	v_add_co_ci_u32_e64 v1, null, s15, v1, vcc_lo              // 000000170AC4: D5207C01 01AA020F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000170ACC: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 000000170AD0: D6460003 04110503
	s_nop 0                                                    // 000000170AD8: BF800000
	s_nop 0                                                    // 000000170ADC: BF800000
	s_nop 0                                                    // 000000170AE0: BF800000
	s_nop 0                                                    // 000000170AE4: BF800000
	s_nop 0                                                    // 000000170AE8: BF800000
	s_nop 0                                                    // 000000170AEC: BF800000
	s_nop 0                                                    // 000000170AF0: BF800000
	s_nop 0                                                    // 000000170AF4: BF800000
	s_nop 0                                                    // 000000170AF8: BF800000
	s_nop 0                                                    // 000000170AFC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 000000170B00: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 000000170B08: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 000000170B10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000170B14: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 000000170B18: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 000000170B20: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000170B24: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 000000170B28: DC6A0000 007C0400
	.long 0xd7000000                                           // 000000170B30: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 000000170B34: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000170B3C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000170B44: 917E017E
	s_cbranch_execnz 65517                                     // 000000170B48: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi8EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5400>
	s_nop 0                                                    // 000000170B4C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000170B50: BFB60003
	s_endpgm                                                   // 000000170B54: BFB00000
		...

