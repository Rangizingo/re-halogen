0000000000126c00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000126C00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000126C04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 000000126C0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000126C14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000126C18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 000000126C1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000126C20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000126C28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 000000126C2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000126C30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000126C34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 000000126C3C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000126C40: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000126C44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000126C48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126C4C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000126C50: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000126C54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000126C58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 000000126C5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000126C64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 000000126C6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000126C70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000126C74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000126C78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 000000126C7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000126C80: 821E191E
	.long 0xd7001f02                                           // 000000126C84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000126C88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 000000126C8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000126C94: BE9E0080
	s_nop 0                                                    // 000000126C98: BF800000
	s_nop 0                                                    // 000000126C9C: BF800000
	s_nop 0                                                    // 000000126CA0: BF800000
	s_nop 0                                                    // 000000126CA4: BF800000
	s_nop 0                                                    // 000000126CA8: BF800000
	s_nop 0                                                    // 000000126CAC: BF800000
	s_nop 0                                                    // 000000126CB0: BF800000
	s_nop 0                                                    // 000000126CB4: BF800000
	s_nop 0                                                    // 000000126CB8: BF800000
	s_nop 0                                                    // 000000126CBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 000000126CC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 000000126CC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126CCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 000000126CD0: 300C1089
	.long 0xd7006a06                                           // 000000126CD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 000000126CD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126CDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 000000126CE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000126CE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 000000126CF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 000000126CF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 000000126CFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000126D08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 000000126D0C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000126D10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000126D18: 917E1E7E
	s_cbranch_execnz 65512                                     // 000000126D1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000126D20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000126D24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 000000126D2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000126D34: 32040084
	s_mov_b32 s0, 0                                            // 000000126D38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000126D3C: BF89FC07
	s_barrier                                                  // 000000126D40: BFBD0000
	buffer_gl0_inv                                             // 000000126D44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 000000126D4C: BF02801E
	s_cbranch_scc1 12                                          // 000000126D50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000126D54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 000000126D5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000126D64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000126D68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000126D70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000126D74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000126D78: 916A007E
	s_cbranch_vccz 2                                           // 000000126D7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2215                                              // 000000126D80: BFA008A7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2420>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000126D84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 000000126D88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 000000126D8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000126D94: 85218600
	s_add_u32 s34, s10, s24                                    // 000000126D98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 000000126D9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 000000126DA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 000000126DA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 000000126DAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 000000126DB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000126DB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 000000126DB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 000000126DBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 000000126DC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 000000126DC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 000000126DC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 000000126DD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 000000126DD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 000000126DDC: B00A0204
	.long 0xd7000b2c                                           // 000000126DE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 000000126DE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000126DE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 000000126DEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 000000126DF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000126E00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000126E04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 000000126E10: 3816500A
	.long 0xd7000a05                                           // 000000126E14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000126E18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000126E1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000126E20: D5207C06 00290001
	.long 0xd7000107                                           // 000000126E28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 000000126E2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126E30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000126E34: D5207C08 0006180D
	.long 0xd7000109                                           // 000000126E3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000126E40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000126E44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 000000126E4C: 84848E02
	.long 0xd700010b                                           // 000000126E50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000126E54: 02021606
	s_add_u32 s4, s14, s4                                      // 000000126E58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 000000126E5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000126E64: 8205050F
	.long 0xd700010d                                           // 000000126E68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 000000126E6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126E70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000126E74: D5207C0E 00050005
	.long 0xd700010f                                           // 000000126E7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000126E80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000126E88: D5207C10 00061880
	.long 0xd7000111                                           // 000000126E90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000126E94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126E9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 000000126EA0: D5207C12 00061880
	.long 0xd7000113                                           // 000000126EA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 000000126EAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 000000126EB4: D5207C14 00061880
	.long 0xd7000115                                           // 000000126EBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 000000126EC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126EC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 000000126ECC: D5207C16 00061880
	.long 0xd7000117                                           // 000000126ED4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 000000126ED8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 000000126EE0: D5207C18 00061880
	.long 0xd7000119                                           // 000000126EE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 000000126EEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126EF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 000000126EF8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000126F00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000126F04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 000000126F0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000126F14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000126F18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000126F20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000126F24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 000000126F2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000126F34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 000000126F3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000126F44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 000000126F4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000126F54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 000000126F5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000126F64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 000000126F6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000126F74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 000000126F7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000126F84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 000000126F8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000126F94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 000000126F9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000126FA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 000000126FA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000126FAC: BF870499
	s_add_i32 s6, s31, s1                                      // 000000126FB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 000000126FB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126FB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000126FBC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000126FC0: 84078605
	s_add_u32 s10, s8, s10                                     // 000000126FC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 000000126FC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 000000126FCC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000126FD4: BE84206A
	s_cbranch_execz 77                                         // 000000126FD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 000000126FDC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126FE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 000000126FE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 000000126FEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126FF0: BF870091
	.long 0xd73c001d                                           // 000000126FF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 000000126FF8: 02023A82
	.long 0xd700011d                                           // 000000126FFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000127000: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127004: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000127008: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000127010: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000127018: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000012701C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000127020: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000012702C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000127030: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000012703C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000127040: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000012704C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000127050: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000127054: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000127060: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127064: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000127068: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000127070: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000127074: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000012707C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000127084: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000127088: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012708C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000127090: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000127094: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000127098: BF870296
	.long 0xd71c0020                                           // 00000012709C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000001270A0: 02024520
	.long 0xd71c001f                                           // 0000001270A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000001270A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001270AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000001270B0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000001270B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000001270BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001270C4: D5010020 00064080
	.long 0xd41e0001                                           // 0000001270CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000001270D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001270D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000001270DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000001270E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000001270EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000001270F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000127100: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000127108: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000127110: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000127114: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000012711C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000127120: BF89FC07
	s_barrier                                                  // 000000127124: BFBD0000
	buffer_gl0_inv                                             // 000000127128: E0AC0000 00000000
	s_branch 15                                                // 000000127130: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000127134: 8C7E047E
	.long 0xd700011d                                           // 000000127138: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000012713C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000127144: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000127148: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000127150: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000127154: BF08B70A
	s_mov_b32 s10, s1                                          // 000000127158: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000012715C: BF89FC07
	s_barrier                                                  // 000000127160: BFBD0000
	buffer_gl0_inv                                             // 000000127164: E0AC0000 00000000
	s_cbranch_scc1 676                                         // 00000012716C: BFA202A4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000127170: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000127178: CA100128 21220126
	s_mov_b32 s11, 0                                           // 000000127180: BE8B0080
	s_nop 0                                                    // 000000127184: BF800000
	s_nop 0                                                    // 000000127188: BF800000
	s_nop 0                                                    // 00000012718C: BF800000
	s_nop 0                                                    // 000000127190: BF800000
	s_nop 0                                                    // 000000127194: BF800000
	s_nop 0                                                    // 000000127198: BF800000
	s_nop 0                                                    // 00000012719C: BF800000
	s_nop 0                                                    // 0000001271A0: BF800000
	s_nop 0                                                    // 0000001271A4: BF800000
	s_nop 0                                                    // 0000001271A8: BF800000
	s_nop 0                                                    // 0000001271AC: BF800000
	s_nop 0                                                    // 0000001271B0: BF800000
	s_nop 0                                                    // 0000001271B4: BF800000
	s_nop 0                                                    // 0000001271B8: BF800000
	s_nop 0                                                    // 0000001271BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000001271C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000001271C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000001271D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000001271D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001271DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000001271E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000001271E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000001271EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000001271F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000001271F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000001271FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000127204: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012720C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000127210: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000127214: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000127218: BF89FC07
	s_barrier                                                  // 00000012721C: BFBD0000
	buffer_gl0_inv                                             // 000000127220: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000127228: BE842000
	s_cbranch_execz 65473                                      // 00000012722C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s10, s7, v2                                 // 000000127230: D658001F 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127238: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 00000012723C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 000000127244: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 000000127248: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012724C: BF870091
	.long 0xd700011f                                           // 000000127250: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 000000127254: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 000000127258: D5207C20 0006412D
	global_load_b32 v68, v[31:32], off                         // 000000127260: DC520000 447C001F
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000127268: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v1 offset1:17                  // 000000127270: D8DC1100 21000001
	ds_load_2addr_b32 v[35:36], v1 offset0:34 offset1:51       // 000000127278: D8DC3322 23000001
	ds_load_2addr_b32 v[60:61], v46 offset0:2 offset1:3        // 000000127280: D8DC0302 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:4 offset1:5        // 000000127288: D8DC0504 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:6 offset1:7        // 000000127290: D8DC0706 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000127298: D8DC5544 42000001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000001272A0: BF890057
	v_fma_f32 v31, -v31, v33, v68                              // 0000001272A4: D613001F 2512431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001272AC: BF8700C1
	v_fma_f32 v33, -v32, v34, v31                              // 0000001272B0: D6130021 247E4520
	ds_load_2addr_b32 v[31:32], v1 offset0:102 offset1:119     // 0000001272B8: D8DC7766 1F000001
	s_waitcnt lgkmcnt(4)                                       // 0000001272C0: BF89FC47
	v_fma_f32 v33, -v60, v35, v33                              // 0000001272C4: D6130021 2486473C
	v_fma_f32 v60, -v61, v36, v33                              // 0000001272CC: D613003C 2486493D
	ds_load_2addr_b32 v[33:34], v46 offset0:8 offset1:9        // 0000001272D4: D8DC0908 2100002E
	ds_load_2addr_b32 v[35:36], v1 offset0:136 offset1:153     // 0000001272DC: D8DC9988 23000001
	s_waitcnt lgkmcnt(3)                                       // 0000001272E4: BF89FC37
	v_fma_f32 v60, -v62, v66, v60                              // 0000001272E8: D613003C 24F2853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001272F0: BF8700D1
	v_fma_f32 v66, -v63, v67, v60                              // 0000001272F4: D6130042 24F2873F
	ds_load_2addr_b32 v[60:61], v46 offset0:10 offset1:11      // 0000001272FC: D8DC0B0A 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 000000127304: D8DCBBAA 3E000001
	s_waitcnt lgkmcnt(4)                                       // 00000012730C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000127310: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000127318: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:12 offset1:13      // 000000127320: D8DC0D0C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 000000127328: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:204 offset1:221     // 000000127330: D8DCDDCC 42000001
	s_waitcnt lgkmcnt(5)                                       // 000000127338: BF89FC57
	v_fma_f32 v33, -v33, v35, v68                              // 00000012733C: D6130021 25124721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127344: BF8700C1
	v_fma_f32 v35, -v34, v36, v33                              // 000000127348: D6130023 24864922
	ds_load_2addr_b32 v[33:34], v1 offset0:238 offset1:255     // 000000127350: D8DCFFEE 21000001
	s_waitcnt lgkmcnt(4)                                       // 000000127358: BF89FC47
	v_fma_f32 v35, -v60, v62, v35                              // 00000012735C: D6130023 248E7D3C
	v_fma_f32 v62, -v61, v63, v35                              // 000000127364: D613003E 248E7F3D
	ds_load_2addr_b32 v[35:36], v46 offset0:16 offset1:17      // 00000012736C: D8DC1110 2300002E
	ds_load_2addr_b32 v[60:61], v48 offset0:16 offset1:33      // 000000127374: D8DC2110 3C000030
	s_waitcnt lgkmcnt(3)                                       // 00000012737C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000127380: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127388: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000012738C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:18 offset1:19      // 000000127394: D8DC1312 1F00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:50 offset1:67      // 00000012739C: D8DC4332 3E000030
	s_waitcnt lgkmcnt(4)                                       // 0000001273A4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 0000001273A8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 0000001273B0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:20 offset1:21      // 0000001273B8: D8DC1514 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:22 offset1:23      // 0000001273C0: D8DC1716 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:84 offset1:101     // 0000001273C8: D8DC6554 42000030
	s_waitcnt lgkmcnt(5)                                       // 0000001273D0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 0000001273D4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001273DC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 0000001273E0: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v48 offset0:118 offset1:135    // 0000001273E8: D8DC8776 23000030
	s_waitcnt lgkmcnt(4)                                       // 0000001273F0: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 0000001273F4: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 0000001273FC: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000127404: D8DC1918 1F00002E
	ds_load_2addr_b32 v[60:61], v48 offset0:152 offset1:169    // 00000012740C: D8DCA998 3C000030
	s_waitcnt lgkmcnt(3)                                       // 000000127414: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000127418: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127420: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000127424: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:26 offset1:27      // 00000012742C: D8DC1B1A 2100002E
	ds_load_2addr_b32 v[62:63], v48 offset0:186 offset1:203    // 000000127434: D8DCCBBA 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000012743C: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000127440: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000127448: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:28 offset1:29      // 000000127450: D8DC1D1C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:30 offset1:31      // 000000127458: D8DC1F1E 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:220 offset1:237    // 000000127460: D8DCEDDC 42000030
	s_waitcnt lgkmcnt(5)                                       // 000000127468: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000012746C: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127474: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000127478: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v49 offset0:126 offset1:143    // 000000127480: D8DC8F7E 1F000031
	s_waitcnt lgkmcnt(4)                                       // 000000127488: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000012748C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000127494: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:32 offset1:33      // 00000012749C: D8DC2120 2100002E
	ds_load_2addr_b32 v[60:61], v50 offset0:32 offset1:49      // 0000001274A4: D8DC3120 3C000032
	s_waitcnt lgkmcnt(3)                                       // 0000001274AC: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 0000001274B0: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001274B8: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 0000001274BC: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:34 offset1:35      // 0000001274C4: D8DC2322 2300002E
	ds_load_2addr_b32 v[62:63], v50 offset0:66 offset1:83      // 0000001274CC: D8DC5342 3E000032
	s_waitcnt lgkmcnt(4)                                       // 0000001274D4: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 0000001274D8: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 0000001274E0: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:36 offset1:37      // 0000001274E8: D8DC2524 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 0000001274F0: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:100 offset1:117    // 0000001274F8: D8DC7564 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000127500: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000127504: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012750C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000127510: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v50 offset0:134 offset1:151    // 000000127518: D8DC9786 21000032
	s_waitcnt lgkmcnt(4)                                       // 000000127520: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000127524: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 00000012752C: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:40 offset1:41      // 000000127534: D8DC2928 2300002E
	ds_load_2addr_b32 v[60:61], v50 offset0:168 offset1:185    // 00000012753C: D8DCB9A8 3C000032
	s_waitcnt lgkmcnt(3)                                       // 000000127544: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000127548: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127550: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000127554: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:42 offset1:43      // 00000012755C: D8DC2B2A 1F00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:202 offset1:219    // 000000127564: D8DCDBCA 3E000032
	s_waitcnt lgkmcnt(4)                                       // 00000012756C: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000127570: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000127578: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:44 offset1:45      // 000000127580: D8DC2D2C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:46 offset1:47      // 000000127588: D8DC2F2E 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:236 offset1:253    // 000000127590: D8DCFDEC 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000127598: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000012759C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001275A4: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 0000001275A8: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v51 offset0:14 offset1:31      // 0000001275B0: D8DC1F0E 23000033
	s_waitcnt lgkmcnt(4)                                       // 0000001275B8: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 0000001275BC: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 0000001275C4: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000001275CC: D8DC3130 1F00002E
	ds_load_2addr_b32 v[60:61], v51 offset0:48 offset1:65      // 0000001275D4: D8DC4130 3C000033
	s_waitcnt lgkmcnt(3)                                       // 0000001275DC: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 0000001275E0: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001275E8: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 0000001275EC: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000001275F4: D8DC3332 2100002E
	ds_load_2addr_b32 v[62:63], v51 offset0:82 offset1:99      // 0000001275FC: D8DC6352 3E000033
	s_waitcnt lgkmcnt(4)                                       // 000000127604: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000127608: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000127610: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 000000127618: D8DC3534 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:54 offset1:55      // 000000127620: D8DC3736 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:116 offset1:133    // 000000127628: D8DC8574 42000033
	s_waitcnt lgkmcnt(5)                                       // 000000127630: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000127634: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012763C: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000127640: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v51 offset0:150 offset1:167    // 000000127648: D8DCA796 1F000033
	s_waitcnt lgkmcnt(4)                                       // 000000127650: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000127654: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000012765C: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:56 offset1:57      // 000000127664: D8DC3938 2100002E
	ds_load_2addr_b32 v[60:61], v51 offset0:184 offset1:201    // 00000012766C: D8DCC9B8 3C000033
	s_waitcnt lgkmcnt(3)                                       // 000000127674: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000127678: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127680: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000127684: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:58 offset1:59      // 00000012768C: D8DC3B3A 2300002E
	ds_load_2addr_b32 v[62:63], v51 offset0:218 offset1:235    // 000000127694: D8DCEBDA 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000012769C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 0000001276A0: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 0000001276A8: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:60 offset1:61      // 0000001276B0: D8DC3D3C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 0000001276B8: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v52 offset0:124 offset1:141    // 0000001276C0: D8DC8D7C 42000034
	s_waitcnt lgkmcnt(5)                                       // 0000001276C8: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 0000001276CC: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001276D4: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 0000001276D8: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v53 offset0:30 offset1:47      // 0000001276E0: D8DC2F1E 21000035
	s_waitcnt lgkmcnt(4)                                       // 0000001276E8: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 0000001276EC: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 0000001276F4: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:64 offset1:65      // 0000001276FC: D8DC4140 2300002E
	ds_load_2addr_b32 v[60:61], v53 offset0:64 offset1:81      // 000000127704: D8DC5140 3C000035
	s_waitcnt lgkmcnt(3)                                       // 00000012770C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000127710: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127718: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000012771C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:66 offset1:67      // 000000127724: D8DC4342 1F00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:98 offset1:115     // 00000012772C: D8DC7362 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000127734: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000127738: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000127740: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:68 offset1:69      // 000000127748: D8DC4544 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:70 offset1:71      // 000000127750: D8DC4746 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:132 offset1:149    // 000000127758: D8DC9584 42000035
	s_waitcnt lgkmcnt(5)                                       // 000000127760: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000127764: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012776C: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000127770: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v53 offset0:166 offset1:183    // 000000127778: D8DCB7A6 23000035
	s_waitcnt lgkmcnt(4)                                       // 000000127780: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000127784: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000012778C: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 000000127794: D8DC4948 1F00002E
	ds_load_2addr_b32 v[60:61], v53 offset0:200 offset1:217    // 00000012779C: D8DCD9C8 3C000035
	s_waitcnt lgkmcnt(3)                                       // 0000001277A4: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 0000001277A8: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001277B0: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 0000001277B4: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:74 offset1:75      // 0000001277BC: D8DC4B4A 2100002E
	ds_load_2addr_b32 v[62:63], v53 offset0:234 offset1:251    // 0000001277C4: D8DCFBEA 3E000035
	s_waitcnt lgkmcnt(4)                                       // 0000001277CC: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 0000001277D0: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 0000001277D8: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:76 offset1:77      // 0000001277E0: D8DC4D4C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:78 offset1:79      // 0000001277E8: D8DC4F4E 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:12 offset1:29      // 0000001277F0: D8DC1D0C 42000036
	s_waitcnt lgkmcnt(5)                                       // 0000001277F8: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 0000001277FC: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127804: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000127808: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v54 offset0:46 offset1:63      // 000000127810: D8DC3F2E 1F000036
	s_waitcnt lgkmcnt(4)                                       // 000000127818: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000012781C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000127824: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:80 offset1:81      // 00000012782C: D8DC5150 2100002E
	ds_load_2addr_b32 v[60:61], v54 offset0:80 offset1:97      // 000000127834: D8DC6150 3C000036
	s_waitcnt lgkmcnt(3)                                       // 00000012783C: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000127840: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127848: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000012784C: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:82 offset1:83      // 000000127854: D8DC5352 2300002E
	ds_load_2addr_b32 v[62:63], v54 offset0:114 offset1:131    // 00000012785C: D8DC8372 3E000036
	s_waitcnt lgkmcnt(4)                                       // 000000127864: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000127868: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000127870: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:84 offset1:85      // 000000127878: D8DC5554 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 000000127880: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:148 offset1:165    // 000000127888: D8DCA594 42000036
	s_waitcnt lgkmcnt(5)                                       // 000000127890: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000127894: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012789C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 0000001278A0: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v54 offset0:182 offset1:199    // 0000001278A8: D8DCC7B6 21000036
	s_waitcnt lgkmcnt(4)                                       // 0000001278B0: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 0000001278B4: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 0000001278BC: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:88 offset1:89      // 0000001278C4: D8DC5958 2300002E
	ds_load_2addr_b32 v[60:61], v54 offset0:216 offset1:233    // 0000001278CC: D8DCE9D8 3C000036
	s_waitcnt lgkmcnt(3)                                       // 0000001278D4: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 0000001278D8: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001278E0: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 0000001278E4: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:90 offset1:91      // 0000001278EC: D8DC5B5A 1F00002E
	ds_load_2addr_b32 v[62:63], v55 offset0:122 offset1:139    // 0000001278F4: D8DC8B7A 3E000037
	s_waitcnt lgkmcnt(4)                                       // 0000001278FC: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000127900: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000127908: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:92 offset1:93      // 000000127910: D8DC5D5C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:94 offset1:95      // 000000127918: D8DC5F5E 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:28 offset1:45      // 000000127920: D8DC2D1C 42000038
	s_waitcnt lgkmcnt(5)                                       // 000000127928: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000012792C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127934: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000127938: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v56 offset0:62 offset1:79      // 000000127940: D8DC4F3E 23000038
	s_waitcnt lgkmcnt(4)                                       // 000000127948: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000012794C: D613001F 24F27D1F
	v_fma_f32 v60, -v32, v63, v31                              // 000000127954: D613003C 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000012795C: D8DC6160 1F00002E
	s_waitcnt lgkmcnt(2)                                       // 000000127964: BF89FC27
	v_fma_f32 v33, -v33, v66, v60                              // 000000127968: D6130021 24F28521
	ds_load_2addr_b32 v[60:61], v56 offset0:96 offset1:113     // 000000127970: D8DC7160 3C000038
	v_fma_f32 v62, -v34, v67, v33                              // 000000127978: D613003E 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 000000127980: D8DC6362 2100002E
	s_waitcnt lgkmcnt(3)                                       // 000000127988: BF89FC37
	v_fma_f32 v35, -v64, v35, v62                              // 00000012798C: D6130023 24FA4740
	ds_load_2addr_b32 v[62:63], v56 offset0:130 offset1:147    // 000000127994: D8DC9382 3E000038
	v_fma_f32 v68, -v65, v36, v35                              // 00000012799C: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000001279A4: D8DC6564 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:102 offset1:103    // 0000001279AC: D8DC6766 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:164 offset1:181    // 0000001279B4: D8DCB5A4 42000038
	s_waitcnt lgkmcnt(5)                                       // 0000001279BC: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 0000001279C0: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001279C8: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 0000001279CC: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v56 offset0:198 offset1:215    // 0000001279D4: D8DCD7C6 1F000038
	s_waitcnt lgkmcnt(4)                                       // 0000001279DC: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 0000001279E0: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 0000001279E8: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:104 offset1:105    // 0000001279F0: D8DC6968 2100002E
	ds_load_2addr_b32 v[60:61], v56 offset0:232 offset1:249    // 0000001279F8: D8DCF9E8 3C000038
	s_waitcnt lgkmcnt(3)                                       // 000000127A00: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000127A04: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127A0C: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000127A10: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:106 offset1:107    // 000000127A18: D8DC6B6A 2300002E
	ds_load_2addr_b32 v[62:63], v57 offset0:10 offset1:27      // 000000127A20: D8DC1B0A 3E000039
	s_waitcnt lgkmcnt(4)                                       // 000000127A28: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000127A2C: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000127A34: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:108 offset1:109    // 000000127A3C: D8DC6D6C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 000000127A44: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:44 offset1:61      // 000000127A4C: D8DC3D2C 42000039
	s_waitcnt lgkmcnt(5)                                       // 000000127A54: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000127A58: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127A60: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000127A64: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v57 offset0:78 offset1:95      // 000000127A6C: D8DC5F4E 21000039
	s_waitcnt lgkmcnt(4)                                       // 000000127A74: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000127A78: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000127A80: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:112 offset1:113    // 000000127A88: D8DC7170 2300002E
	ds_load_2addr_b32 v[60:61], v57 offset0:112 offset1:129    // 000000127A90: D8DC8170 3C000039
	s_waitcnt lgkmcnt(3)                                       // 000000127A98: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000127A9C: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127AA4: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000127AA8: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:114 offset1:115    // 000000127AB0: D8DC7372 1F00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:146 offset1:163    // 000000127AB8: D8DCA392 3E000039
	s_waitcnt lgkmcnt(4)                                       // 000000127AC0: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000127AC4: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000127ACC: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:116 offset1:117    // 000000127AD4: D8DC7574 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:118 offset1:119    // 000000127ADC: D8DC7776 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:180 offset1:197    // 000000127AE4: D8DCC5B4 42000039
	s_waitcnt lgkmcnt(5)                                       // 000000127AEC: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000127AF0: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127AF8: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000127AFC: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v57 offset0:214 offset1:231    // 000000127B04: D8DCE7D6 23000039
	s_waitcnt lgkmcnt(4)                                       // 000000127B0C: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000127B10: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000127B18: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000127B20: D8DC7978 1F00002E
	ds_load_2addr_b32 v[60:61], v58 offset0:120 offset1:137    // 000000127B28: D8DC8978 3C00003A
	s_waitcnt lgkmcnt(3)                                       // 000000127B30: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000127B34: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127B3C: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000127B40: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:122 offset1:123    // 000000127B48: D8DC7B7A 2100002E
	ds_load_2addr_b32 v[62:63], v59 offset0:26 offset1:43      // 000000127B50: D8DC2B1A 3E00003B
	s_waitcnt lgkmcnt(4)                                       // 000000127B58: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000127B5C: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000127B64: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:124 offset1:125    // 000000127B6C: D8DC7D7C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:126 offset1:127    // 000000127B74: D8DC7F7E 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:60 offset1:77      // 000000127B7C: D8DC4D3C 4200003B
	s_waitcnt lgkmcnt(5)                                       // 000000127B84: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000127B88: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127B90: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000127B94: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v59 offset0:94 offset1:111     // 000000127B9C: D8DC6F5E 1F00003B
	s_waitcnt lgkmcnt(4)                                       // 000000127BA4: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000127BA8: D6130021 24F27D21
	v_fma_f32 v33, -v34, v63, v33                              // 000000127BB0: D6130021 24867F22
	s_waitcnt lgkmcnt(1)                                       // 000000127BB8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127BBC: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 000000127BC0: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 000000127BC8: D6130021 24868724
	s_waitcnt lgkmcnt(0)                                       // 000000127BD0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127BD4: BF870121
	v_fma_f32 v31, -v64, v31, v33                              // 000000127BD8: D613001F 24863F40
	v_mad_u64_u32 v[33:34], null, 0x44, s10, v[4:5]            // 000000127BE0: D6FE7C21 041014FF 00000044
	v_fma_f32 v31, -v65, v32, v31                              // 000000127BEC: D613001F 247E4141
	ds_store_b32 v33, v31                                      // 000000127BF4: D8340000 00001F21
	s_branch 64845                                             // 000000127BFC: BFA0FD4D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_dual_mov_b32 v30, v14 :: v_dual_mov_b32 v29, v13         // 000000127C00: CA10010E 1E1C010D
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v31, v9          // 000000127C08: CA10010A 201E0109
	v_mov_b32_e32 v35, v43                                     // 000000127C10: 7E46032B
	s_mov_b32 s10, 0                                           // 000000127C14: BE8A0080
	s_branch 21                                                // 000000127C18: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1070>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000127C1C: 8C7E0B7E
	.long 0xd700011f                                           // 000000127C20: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 000000127C24: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000127C2C: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000127C30: D5207C20 00064080
	.long 0xd700011d                                           // 000000127C38: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 000000127C3C: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 000000127C44: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000127C48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000127C50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000127C54: BF08B70A
	s_mov_b32 s10, s1                                          // 000000127C58: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 000000127C5C: BC7C0000
	s_barrier                                                  // 000000127C60: BFBD0000
	buffer_gl0_inv                                             // 000000127C64: E0AC0000 00000000
	s_cbranch_scc1 244                                         // 000000127C6C: BFA200F4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1440>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000127C70: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 000000127C74: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 000000127C7C: 7E480328
	v_mov_b32_e32 v60, v38                                     // 000000127C80: 7E780326
	s_mov_b32 s11, 0                                           // 000000127C84: BE8B0080
	s_nop 0                                                    // 000000127C88: BF800000
	s_nop 0                                                    // 000000127C8C: BF800000
	s_nop 0                                                    // 000000127C90: BF800000
	s_nop 0                                                    // 000000127C94: BF800000
	s_nop 0                                                    // 000000127C98: BF800000
	s_nop 0                                                    // 000000127C9C: BF800000
	s_nop 0                                                    // 000000127CA0: BF800000
	s_nop 0                                                    // 000000127CA4: BF800000
	s_nop 0                                                    // 000000127CA8: BF800000
	s_nop 0                                                    // 000000127CAC: BF800000
	s_nop 0                                                    // 000000127CB0: BF800000
	s_nop 0                                                    // 000000127CB4: BF800000
	s_nop 0                                                    // 000000127CB8: BF800000
	s_nop 0                                                    // 000000127CBC: BF800000
	global_load_b32 v61, v[33:34], off                         // 000000127CC0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000127CC8: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000127CD0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000127CD4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000127CDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000127CE0: D5207C22 00064480
	.long 0xd4490004                                           // 000000127CE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 000000127CEC: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000127CF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000127CF8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 000000127CFC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000127D04: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000127D0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000127D10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000127D14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000127D18: BF89FC07
	s_barrier                                                  // 000000127D1C: BFBD0000
	buffer_gl0_inv                                             // 000000127D20: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000127D28: BE8B2000
	s_cbranch_execz 65467                                      // 000000127D2C: BFA5FFBB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	v_or_b32_e32 v33, s10, v2                                  // 000000127D30: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127D34: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000127D38: 38484207
	.long 0xd4440001                                           // 000000127D3C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000127D40: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000127D44: 8B7E017E
	s_cbranch_execz 65460                                      // 000000127D48: BFA5FFB4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	v_mov_b32_e32 v60, 0                                       // 000000127D4C: 7E780280
	s_mov_b32 s1, 0                                            // 000000127D50: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000127D54: BF870009
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 000000127D58: D6FE7C3D 040402FF 00000044
	v_lshl_add_u32 v34, s1, 2, v46                             // 000000127D64: D6460022 04B90401
	s_add_i32 s4, s1, 32                                       // 000000127D6C: 8104A001
	s_cmpk_gt_u32 s1, 0x5f                                     // 000000127D70: B581005F
	s_mov_b32 s1, s4                                           // 000000127D74: BE810004
	ds_load_2addr_b32 v[62:63], v34 offset1:1                  // 000000127D78: D8DC0100 3E000022
	ds_load_2addr_b32 v[64:65], v61 offset1:17                 // 000000127D80: D8DC1100 4000003D
	ds_load_2addr_b32 v[66:67], v34 offset0:2 offset1:3        // 000000127D88: D8DC0302 42000022
	ds_load_2addr_b32 v[68:69], v61 offset0:34 offset1:51      // 000000127D90: D8DC3322 4400003D
	ds_load_2addr_b32 v[70:71], v34 offset0:4 offset1:5        // 000000127D98: D8DC0504 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:6 offset1:7        // 000000127DA0: D8DC0706 48000022
	ds_load_2addr_b32 v[74:75], v61 offset0:68 offset1:85      // 000000127DA8: D8DC5544 4A00003D
	v_add_nc_u32_e32 v76, 0x400, v61                           // 000000127DB0: 4A987AFF 00000400
	s_waitcnt lgkmcnt(5)                                       // 000000127DB8: BF89FC57
	v_fmac_f32_e32 v60, v62, v64                               // 000000127DBC: 5678813E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127DC0: BF8700C1
	v_fmac_f32_e32 v60, v63, v65                               // 000000127DC4: 5678833F
	ds_load_2addr_b32 v[62:63], v61 offset0:102 offset1:119    // 000000127DC8: D8DC7766 3E00003D
	s_waitcnt lgkmcnt(4)                                       // 000000127DD0: BF89FC47
	v_fmac_f32_e32 v60, v66, v68                               // 000000127DD4: 56788942
	v_fmac_f32_e32 v60, v67, v69                               // 000000127DD8: 56788B43
	ds_load_2addr_b32 v[64:65], v34 offset0:8 offset1:9        // 000000127DDC: D8DC0908 40000022
	ds_load_2addr_b32 v[66:67], v61 offset0:136 offset1:153    // 000000127DE4: D8DC9988 4200003D
	s_waitcnt lgkmcnt(3)                                       // 000000127DEC: BF89FC37
	v_fmac_f32_e32 v60, v70, v74                               // 000000127DF0: 56789546
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127DF4: BF8700D1
	v_fmac_f32_e32 v60, v71, v75                               // 000000127DF8: 56789747
	ds_load_2addr_b32 v[68:69], v34 offset0:10 offset1:11      // 000000127DFC: D8DC0B0A 44000022
	ds_load_2addr_b32 v[70:71], v61 offset0:170 offset1:187    // 000000127E04: D8DCBBAA 4600003D
	s_waitcnt lgkmcnt(4)                                       // 000000127E0C: BF89FC47
	v_fmac_f32_e32 v60, v72, v62                               // 000000127E10: 56787D48
	v_fmac_f32_e32 v60, v73, v63                               // 000000127E14: 56787F49
	ds_load_2addr_b32 v[62:63], v34 offset0:12 offset1:13      // 000000127E18: D8DC0D0C 3E000022
	ds_load_2addr_b32 v[72:73], v34 offset0:14 offset1:15      // 000000127E20: D8DC0F0E 48000022
	ds_load_2addr_b32 v[74:75], v61 offset0:204 offset1:221    // 000000127E28: D8DCDDCC 4A00003D
	s_waitcnt lgkmcnt(5)                                       // 000000127E30: BF89FC57
	v_fmac_f32_e32 v60, v64, v66                               // 000000127E34: 56788540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127E38: BF8700C1
	v_fmac_f32_e32 v60, v65, v67                               // 000000127E3C: 56788741
	ds_load_2addr_b32 v[64:65], v61 offset0:238 offset1:255    // 000000127E40: D8DCFFEE 4000003D
	s_waitcnt lgkmcnt(4)                                       // 000000127E48: BF89FC47
	v_fmac_f32_e32 v60, v68, v70                               // 000000127E4C: 56788D44
	v_fmac_f32_e32 v60, v69, v71                               // 000000127E50: 56788F45
	ds_load_2addr_b32 v[66:67], v34 offset0:16 offset1:17      // 000000127E54: D8DC1110 42000022
	ds_load_2addr_b32 v[68:69], v76 offset0:16 offset1:33      // 000000127E5C: D8DC2110 4400004C
	s_waitcnt lgkmcnt(3)                                       // 000000127E64: BF89FC37
	v_fmac_f32_e32 v60, v62, v74                               // 000000127E68: 5678953E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127E6C: BF8700D1
	v_fmac_f32_e32 v60, v63, v75                               // 000000127E70: 5678973F
	ds_load_2addr_b32 v[62:63], v34 offset0:18 offset1:19      // 000000127E74: D8DC1312 3E000022
	ds_load_2addr_b32 v[70:71], v76 offset0:50 offset1:67      // 000000127E7C: D8DC4332 4600004C
	s_waitcnt lgkmcnt(4)                                       // 000000127E84: BF89FC47
	v_fmac_f32_e32 v60, v72, v64                               // 000000127E88: 56788148
	v_fmac_f32_e32 v60, v73, v65                               // 000000127E8C: 56788349
	ds_load_2addr_b32 v[64:65], v34 offset0:20 offset1:21      // 000000127E90: D8DC1514 40000022
	ds_load_2addr_b32 v[72:73], v34 offset0:22 offset1:23      // 000000127E98: D8DC1716 48000022
	ds_load_2addr_b32 v[74:75], v76 offset0:84 offset1:101     // 000000127EA0: D8DC6554 4A00004C
	s_waitcnt lgkmcnt(5)                                       // 000000127EA8: BF89FC57
	v_fmac_f32_e32 v60, v66, v68                               // 000000127EAC: 56788942
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000127EB0: BF8700C1
	v_fmac_f32_e32 v60, v67, v69                               // 000000127EB4: 56788B43
	ds_load_2addr_b32 v[66:67], v76 offset0:118 offset1:135    // 000000127EB8: D8DC8776 4200004C
	s_waitcnt lgkmcnt(4)                                       // 000000127EC0: BF89FC47
	v_fmac_f32_e32 v60, v62, v70                               // 000000127EC4: 56788D3E
	v_fmac_f32_e32 v60, v63, v71                               // 000000127EC8: 56788F3F
	ds_load_2addr_b32 v[62:63], v34 offset0:24 offset1:25      // 000000127ECC: D8DC1918 3E000022
	ds_load_2addr_b32 v[68:69], v76 offset0:152 offset1:169    // 000000127ED4: D8DCA998 4400004C
	s_waitcnt lgkmcnt(3)                                       // 000000127EDC: BF89FC37
	v_fmac_f32_e32 v60, v64, v74                               // 000000127EE0: 56789540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000127EE4: BF8700D1
	v_fmac_f32_e32 v60, v65, v75                               // 000000127EE8: 56789741
	ds_load_2addr_b32 v[64:65], v34 offset0:26 offset1:27      // 000000127EEC: D8DC1B1A 40000022
	ds_load_2addr_b32 v[70:71], v76 offset0:186 offset1:203    // 000000127EF4: D8DCCBBA 4600004C
	s_waitcnt lgkmcnt(4)                                       // 000000127EFC: BF89FC47
	v_fmac_f32_e32 v60, v72, v66                               // 000000127F00: 56788548
	v_fmac_f32_e32 v60, v73, v67                               // 000000127F04: 56788749
	ds_load_2addr_b32 v[66:67], v34 offset0:28 offset1:29      // 000000127F08: D8DC1D1C 42000022
	ds_load_2addr_b32 v[72:73], v34 offset0:30 offset1:31      // 000000127F10: D8DC1F1E 48000022
	ds_load_2addr_b32 v[74:75], v76 offset0:220 offset1:237    // 000000127F18: D8DCEDDC 4A00004C
	v_add_nc_u32_e32 v34, 0x600, v61                           // 000000127F20: 4A447AFF 00000600
	s_waitcnt lgkmcnt(5)                                       // 000000127F28: BF89FC57
	v_fmac_f32_e32 v60, v62, v68                               // 000000127F2C: 5678893E
	ds_load_2addr_b32 v[61:62], v34 offset0:126 offset1:143    // 000000127F30: D8DC8F7E 3D000022
	v_fmac_f32_e32 v60, v63, v69                               // 000000127F38: 56788B3F
	s_waitcnt lgkmcnt(4)                                       // 000000127F3C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127F40: BF870091
	v_fmac_f32_e32 v60, v64, v70                               // 000000127F44: 56788D40
	v_fmac_f32_e32 v60, v65, v71                               // 000000127F48: 56788F41
	s_waitcnt lgkmcnt(1)                                       // 000000127F4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127F50: BF870091
	v_fmac_f32_e32 v60, v66, v74                               // 000000127F54: 56789542
	v_fmac_f32_e32 v60, v67, v75                               // 000000127F58: 56789743
	s_waitcnt lgkmcnt(0)                                       // 000000127F5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127F60: BF870091
	v_fmac_f32_e32 v60, v72, v61                               // 000000127F64: 56787B48
	v_fmac_f32_e32 v60, v73, v62                               // 000000127F68: 56787D49
	s_cbranch_scc0 65401                                       // 000000127F6C: BFA1FF79 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1154>
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000127F70: 30424282
	s_mov_b32 s12, 0                                           // 000000127F74: BE8C0080
	ds_load_b32 v62, v33 offset:17440                          // 000000127F78: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v61, v1          // 000000127F80: CA10011E 223C0101
	s_waitcnt lgkmcnt(0)                                       // 000000127F88: BF89FC07
	v_dual_mov_b32 v33, v29 :: v_dual_mul_f32 v60, v60, v62    // 000000127F8C: CA06011D 213C7D3C
	v_mov_b32_e32 v62, v35                                     // 000000127F94: 7E7C0323
	s_nop 0                                                    // 000000127F98: BF800000
	s_nop 0                                                    // 000000127F9C: BF800000
	s_nop 0                                                    // 000000127FA0: BF800000
	s_nop 0                                                    // 000000127FA4: BF800000
	s_nop 0                                                    // 000000127FA8: BF800000
	s_nop 0                                                    // 000000127FAC: BF800000
	s_nop 0                                                    // 000000127FB0: BF800000
	s_nop 0                                                    // 000000127FB4: BF800000
	s_nop 0                                                    // 000000127FB8: BF800000
	s_nop 0                                                    // 000000127FBC: BF800000
	global_load_b32 v63, v[33:34], off                         // 000000127FC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000127FC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000127FD0: 4A7C7CC1
	.long 0xd7000121                                           // 000000127FD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000127FD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000127FDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000127FE0: D5207C22 00064480
	.long 0xd44a0004                                           // 000000127FE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 000000127FEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000127FF0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000127FF8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000127FFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000128000: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000128004: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000128008: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000012800C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128010: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000128014: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000012801C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000128028: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000128034: DC960000 007C2421
	s_branch 65271                                             // 00000012803C: BFA0FEF7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000128040: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000128048: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012804C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000128050: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000128058: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000012805C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000128064: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000012806C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000128070: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000128074: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000012807C: A0010401
	s_mov_b32 s4, 0                                            // 000000128080: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000128084: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000128088: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000012808C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000128090: BF870585
	.long 0xd71c001d                                           // 000000128094: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000128098: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000012809C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000001280A0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001280A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000001280AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000001280B4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000001280B8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001280BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000001280C8: D8D80000 2000001D
	s_waitcnt lgkmcnt(0)                                       // 0000001280D0: BF89FC07
	v_dual_mul_f32 v32, v30, v32 :: v_dual_add_nc_u32 v31, 0x80, v31// 0000001280D4: C8E0411E 201E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000001280E0: BF8704C1
	.long 0xd4490001                                           // 0000001280E4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000001280E8: 02023EFF 0000077F
	ds_store_b32 v29, v32                                      // 0000001280F0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000001280F8: 4A3A3AFF 00000220
	s_or_b32 s4, s1, s4                                        // 000000128100: 8C040401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000128104: 917E047E
	s_cbranch_execnz 65519                                     // 000000128108: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012810C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000128110: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000128118: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000128120: 7E420326
	s_mov_b32 s6, 0                                            // 000000128124: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000128128: BF89FC07
	s_barrier                                                  // 00000012812C: BFBD0000
	buffer_gl0_inv                                             // 000000128130: E0AC0000 00000000
	s_nop 0                                                    // 000000128138: BF800000
	s_nop 0                                                    // 00000012813C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128140: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000128148: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128150: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128158: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012815C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000128164: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128168: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128170: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128174: 10444722
	.long 0xd4490004                                           // 000000128178: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012817C: 020242FF 0000037F
	ds_store_b32 v32, v34 offset:13056                         // 000000128184: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000012818C: 4A4040FF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128194: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128198: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012819C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001281A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001281A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001281A8: BF89FC07
	s_barrier                                                  // 0000001281AC: BFBD0000
	buffer_gl0_inv                                             // 0000001281B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000001281B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000001281C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000001281C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000001281D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000001281D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000001281DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001281E0: BF840001
	s_nop 0                                                    // 0000001281E4: BF800000
	s_nop 0                                                    // 0000001281E8: BF800000
	s_nop 0                                                    // 0000001281EC: BF800000
	s_nop 0                                                    // 0000001281F0: BF800000
	s_nop 0                                                    // 0000001281F4: BF800000
	s_nop 0                                                    // 0000001281F8: BF800000
	s_nop 0                                                    // 0000001281FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128200: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000128204: 327A7884
	.long 0xd4490001                                           // 000000128208: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012820C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000128214: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000128218: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128224: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000128228: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000128230: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000128238: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000128240: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000128244: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128248: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012824C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000128258: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000128260: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000128268: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000128270: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000128278: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000128280: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000128284: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128288: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012828C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000128290: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128294: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000128298: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012829C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001282A8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001282AC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001282B4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001282BC: 917E047E
	s_cbranch_execnz 65487                                     // 0000001282C0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1600>
	s_set_inst_prefetch_distance 0x2                           // 0000001282C4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001282C8: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000001282CC: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001282D4: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001282DC: 7E420326
	s_mov_b32 s6, 0                                            // 0000001282E0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001282E4: BF89FC07
	s_barrier                                                  // 0000001282E8: BFBD0000
	buffer_gl0_inv                                             // 0000001282EC: E0AC0000 00000000
	s_nop 0                                                    // 0000001282F4: BF800000
	s_nop 0                                                    // 0000001282F8: BF800000
	s_nop 0                                                    // 0000001282FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128300: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000128308: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128310: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128318: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012831C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000128324: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128328: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128330: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128334: 10444722
	.long 0xd4490004                                           // 000000128338: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012833C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128344: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012834C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128354: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128358: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012835C: 917E067E
	s_cbranch_execnz 65511                                     // 000000128360: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1700>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000128364: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000128368: BF89FC07
	s_barrier                                                  // 00000012836C: BFBD0000
	buffer_gl0_inv                                             // 000000128370: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000128378: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000128380: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000128388: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000128390: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000128398: 7E780300
	s_mov_b32 s4, 0                                            // 00000012839C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001283A0: BF840001
	s_nop 0                                                    // 0000001283A4: BF800000
	s_nop 0                                                    // 0000001283A8: BF800000
	s_nop 0                                                    // 0000001283AC: BF800000
	s_nop 0                                                    // 0000001283B0: BF800000
	s_nop 0                                                    // 0000001283B4: BF800000
	s_nop 0                                                    // 0000001283B8: BF800000
	s_nop 0                                                    // 0000001283BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001283C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000001283C4: 327A7884
	.long 0xd4490001                                           // 0000001283C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000001283CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000001283D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000001283D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001283E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001283E8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 0000001283F0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000001283F8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000128400: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000128404: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128408: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012840C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000128418: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000128420: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000128428: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000128430: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000128438: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000128440: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000128444: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128448: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012844C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000128450: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128454: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000128458: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012845C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128468: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012846C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000128474: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012847C: 917E047E
	s_cbranch_execnz 65487                                     // 000000128480: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17c0>
	s_set_inst_prefetch_distance 0x2                           // 000000128484: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128488: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000012848C: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000128494: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012849C: 7E420326
	s_mov_b32 s6, 0                                            // 0000001284A0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001284A4: BF89FC07
	s_barrier                                                  // 0000001284A8: BFBD0000
	buffer_gl0_inv                                             // 0000001284AC: E0AC0000 00000000
	s_nop 0                                                    // 0000001284B4: BF800000
	s_nop 0                                                    // 0000001284B8: BF800000
	s_nop 0                                                    // 0000001284BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001284C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000001284C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001284D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001284D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001284DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001284E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001284E8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001284F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001284F4: 10444722
	.long 0xd4490004                                           // 0000001284F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001284FC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128504: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012850C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128514: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128518: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012851C: 917E067E
	s_cbranch_execnz 65511                                     // 000000128520: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000128524: 8C7E067E
	v_dual_mov_b32 v61, v0 :: v_dual_add_nc_u32 v60, 0x400, v47// 000000128528: CA200100 3D3C5EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000128534: BF89FC07
	s_barrier                                                  // 000000128538: BFBD0000
	buffer_gl0_inv                                             // 00000012853C: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000128544: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000012854C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000128554: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000012855C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000128564: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000128568: BF840001
	s_nop 0                                                    // 00000012856C: BF800000
	s_nop 0                                                    // 000000128570: BF800000
	s_nop 0                                                    // 000000128574: BF800000
	s_nop 0                                                    // 000000128578: BF800000
	s_nop 0                                                    // 00000012857C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000128580: 327C7A84
	.long 0xd4490001                                           // 000000128584: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000128588: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000128590: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000128594: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000128598: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001285A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001285A8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 0000001285B0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001285B8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000001285C0: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 0000001285C4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001285C8: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 0000001285CC: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000001285D8: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 0000001285E0: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 0000001285E4: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000001285F0: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 0000001285F8: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 0000001285FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128600: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000128604: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000128608: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000128614: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012861C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000128620: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012862C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000128630: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000128638: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000128640: 917E047E
	s_cbranch_execnz 65486                                     // 000000128644: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_set_inst_prefetch_distance 0x2                           // 000000128648: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012864C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000128650: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000128658: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000128660: 7E420326
	s_mov_b32 s6, 0                                            // 000000128664: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000128668: BF89FC07
	s_barrier                                                  // 00000012866C: BFBD0000
	buffer_gl0_inv                                             // 000000128670: E0AC0000 00000000
	s_nop 0                                                    // 000000128678: BF800000
	s_nop 0                                                    // 00000012867C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128680: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000128688: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128690: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128698: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012869C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001286A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001286A8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001286B0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001286B4: 10444722
	.long 0xd4490004                                           // 0000001286B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001286BC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 0000001286C4: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000001286CC: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000001286D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001286D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001286DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001286E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001286E4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000001286E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000001286F0: BF89FC07
	s_barrier                                                  // 0000001286F4: BFBD0000
	buffer_gl0_inv                                             // 0000001286F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000128700: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000128708: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000128710: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000128718: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000128720: 7E780300
	s_mov_b32 s4, 0                                            // 000000128724: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000128728: BF840001
	s_nop 0                                                    // 00000012872C: BF800000
	s_nop 0                                                    // 000000128730: BF800000
	s_nop 0                                                    // 000000128734: BF800000
	s_nop 0                                                    // 000000128738: BF800000
	s_nop 0                                                    // 00000012873C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128740: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000128744: 327A7884
	.long 0xd4490001                                           // 000000128748: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012874C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000128754: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000128758: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128764: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000128768: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000128770: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000128778: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000128780: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000128784: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128788: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012878C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000128798: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001287A0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001287A8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001287B0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001287B8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 0000001287C0: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 0000001287C4: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001287C8: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 0000001287CC: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 0000001287D0: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001287D4: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 0000001287D8: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000001287DC: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001287E8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001287EC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001287F4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001287FC: 917E047E
	s_cbranch_execnz 65487                                     // 000000128800: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000128804: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128808: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000012880C: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000128814: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012881C: 7E420326
	s_mov_b32 s6, 0                                            // 000000128820: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000128824: BF89FC07
	s_barrier                                                  // 000000128828: BFBD0000
	buffer_gl0_inv                                             // 00000012882C: E0AC0000 00000000
	s_nop 0                                                    // 000000128834: BF800000
	s_nop 0                                                    // 000000128838: BF800000
	s_nop 0                                                    // 00000012883C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128840: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000128848: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128850: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128858: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012885C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000128864: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128868: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128870: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128874: 10444722
	.long 0xd4490004                                           // 000000128878: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012887C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128884: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012888C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128894: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128898: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012889C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001288A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001288A4: 8C7E067E
	v_dual_mov_b32 v60, v0 :: v_dual_add_nc_u32 v61, 0x800, v47// 0000001288A8: CA200100 3C3C5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000001288B4: BF89FC07
	s_barrier                                                  // 0000001288B8: BFBD0000
	buffer_gl0_inv                                             // 0000001288BC: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000001288C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000001288CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000001288D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000001288DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000001288E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001288E8: BF840001
	s_nop 0                                                    // 0000001288EC: BF800000
	s_nop 0                                                    // 0000001288F0: BF800000
	s_nop 0                                                    // 0000001288F4: BF800000
	s_nop 0                                                    // 0000001288F8: BF800000
	s_nop 0                                                    // 0000001288FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000128900: 327C7884
	.long 0xd4490001                                           // 000000128904: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000128908: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000128910: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000128914: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000128918: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128924: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000128928: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000128930: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000128938: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000128940: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000128944: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128948: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012894C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000128958: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000128960: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000128964: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000128970: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000128978: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012897C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128980: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000128984: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000128988: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000128994: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012899C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000001289A0: C820473F 463E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001289AC: BF870111
	v_fmac_f32_e32 v70, v64, v36                               // 0000001289B0: 568C4940
	v_mov_b32_e32 v60, v63                                     // 0000001289B4: 7E78033F
	ds_store_b32 v62, v70                                      // 0000001289B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001289C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000001289C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 0000001289C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001289CC: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000001289D0: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001289D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001289E0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001289E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001289E8: BF89FC07
	s_barrier                                                  // 0000001289EC: BFBD0000
	buffer_gl0_inv                                             // 0000001289F0: E0AC0000 00000000
	s_nop 0                                                    // 0000001289F8: BF800000
	s_nop 0                                                    // 0000001289FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128A00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000128A08: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128A10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128A18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000128A1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000128A24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128A28: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128A30: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128A34: 10444722
	.long 0xd4490004                                           // 000000128A38: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000128A3C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128A44: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000128A4C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128A54: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128A58: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000128A5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000128A60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000128A64: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000128A68: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000128A70: BF89FC07
	s_barrier                                                  // 000000128A74: BFBD0000
	buffer_gl0_inv                                             // 000000128A78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000128A80: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000128A88: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000128A90: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000128A98: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000128AA0: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000128AA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000128AA8: BF840001
	s_nop 0                                                    // 000000128AAC: BF800000
	s_nop 0                                                    // 000000128AB0: BF800000
	s_nop 0                                                    // 000000128AB4: BF800000
	s_nop 0                                                    // 000000128AB8: BF800000
	s_nop 0                                                    // 000000128ABC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128AC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000128AC4: 327C7A84
	.long 0xd4490001                                           // 000000128AC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000128ACC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000128AD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000128AD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128AE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000128AE8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000128AF0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000128AF8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000128B00: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000128B04: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128B08: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000128B0C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000128B18: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000128B20: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000128B24: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000128B30: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000128B38: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000128B3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128B40: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000128B44: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000128B48: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000128B54: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000128B5C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000128B60: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128B6C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000128B70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000128B78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000128B80: 917E047E
	s_cbranch_execnz 65486                                     // 000000128B84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000128B88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128B8C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000128B90: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000128B98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000128BA0: 7E420326
	s_mov_b32 s6, 0                                            // 000000128BA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000128BA8: BF89FC07
	s_barrier                                                  // 000000128BAC: BFBD0000
	buffer_gl0_inv                                             // 000000128BB0: E0AC0000 00000000
	s_nop 0                                                    // 000000128BB8: BF800000
	s_nop 0                                                    // 000000128BBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128BC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000128BC8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128BD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128BD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000128BDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000128BE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128BE8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128BF0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128BF4: 10444722
	.long 0xd4490004                                           // 000000128BF8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000128BFC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128C04: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000128C0C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128C14: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128C18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000128C1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000128C20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000128C24: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000128C28: BF89FC07
	s_barrier                                                  // 000000128C2C: BFBD0000
	buffer_gl0_inv                                             // 000000128C30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000128C38: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000128C40: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000128C48: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000128C50: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000128C58: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000128C5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000128C60: BF840001
	s_nop 0                                                    // 000000128C64: BF800000
	s_nop 0                                                    // 000000128C68: BF800000
	s_nop 0                                                    // 000000128C6C: BF800000
	s_nop 0                                                    // 000000128C70: BF800000
	s_nop 0                                                    // 000000128C74: BF800000
	s_nop 0                                                    // 000000128C78: BF800000
	s_nop 0                                                    // 000000128C7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128C80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000128C84: 327C7A84
	.long 0xd4490001                                           // 000000128C88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000128C8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000128C94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000128C98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128CA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000128CA8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000128CB0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000128CB8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000128CC0: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000128CC4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128CC8: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000128CCC: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000128CD8: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000128CE0: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000128CE4: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000128CF0: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000128CF8: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000128CFC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128D00: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000128D04: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000128D08: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000128D14: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000128D1C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000128D20: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128D2C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000128D30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000128D38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000128D40: 917E047E
	s_cbranch_execnz 65486                                     // 000000128D44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000128D48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128D4C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000128D50: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000128D58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000128D60: 7E420326
	s_mov_b32 s6, 0                                            // 000000128D64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000128D68: BF89FC07
	s_barrier                                                  // 000000128D6C: BFBD0000
	buffer_gl0_inv                                             // 000000128D70: E0AC0000 00000000
	s_nop 0                                                    // 000000128D78: BF800000
	s_nop 0                                                    // 000000128D7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000128D80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000128D88: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000128D90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000128D98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000128D9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000128DA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000128DA8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128DB0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000128DB4: 10444722
	.long 0xd4490004                                           // 000000128DB8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000128DBC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000128DC4: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000128DCC: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000128DD4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128DD8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000128DDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000128DE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000128DE4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000128DE8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000128DF0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000128DF8: BF89FC07
	s_barrier                                                  // 000000128DFC: BFBD0000
	buffer_gl0_inv                                             // 000000128E00: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000128E08: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000128E10: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000128E18: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000128E20: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000128E28: 7E780300
	s_mov_b32 s4, 0                                            // 000000128E2C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000128E30: BF840001
	s_nop 0                                                    // 000000128E34: BF800000
	s_nop 0                                                    // 000000128E38: BF800000
	s_nop 0                                                    // 000000128E3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128E40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000128E44: 327A7884
	.long 0xd4490001                                           // 000000128E48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000128E4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000128E54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000128E58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000128E64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000128E68: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000128E70: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000128E78: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000128E80: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000128E84: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128E88: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 000000128E8C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000128E98: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000128EA0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000128EA8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000128EB0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000128EB8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000128EC0: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000128EC4: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128EC8: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 000000128ECC: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000128ED0: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128ED4: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000128ED8: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000128EDC: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128EE8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000128EEC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000128EF4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000128EFC: 917E047E
	s_cbranch_execnz 65487                                     // 000000128F00: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000128F04: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128F08: 8C7E047E
	.long 0xd7000107                                           // 000000128F0C: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000128F10: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000128F18: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000128F1C: D5207C08 00061080
	.long 0xd7000109                                           // 000000128F24: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000128F28: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000128F30: D5207C0A 00061480
	.long 0xd700010d                                           // 000000128F38: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000128F3C: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000128F44: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000128F48: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000128F50: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000128F54: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000128F5C: D5207C0C 00061880
	.long 0xd700010f                                           // 000000128F64: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 000000128F68: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000128F70: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000128F74: D5207C10 00062080
	.long 0xd7000111                                           // 000000128F7C: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000128F80: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 000000128F88: D5207C12 00062480
	.long 0xd7000113                                           // 000000128F90: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000128F94: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000128F9C: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 000000128FA0: D5207C14 00062880
	.long 0xd7000115                                           // 000000128FA8: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 000000128FAC: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 000000128FB4: D5207C16 00062C80
	.long 0xd7000117                                           // 000000128FBC: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000128FC0: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000128FC8: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000128FCC: D5207C18 00063080
	.long 0xd7000119                                           // 000000128FD4: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000128FD8: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000128FE0: D5207C1A 00063480
	.long 0xd700011b                                           // 000000128FE8: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000128FEC: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128FF4: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000128FF8: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000129000: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000129004: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000129008: BF062105
	s_barrier                                                  // 00000012900C: BFBD0000
	buffer_gl0_inv                                             // 000000129010: E0AC0000 00000000
	s_cbranch_scc0 63458                                       // 000000129018: BFA1F7E2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000012901C: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000129020: 8000141C
	.long 0xd73c0000                                           // 000000129024: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000129028: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000012902C: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000129030: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000129034: 82031319
	s_add_u32 s0, s2, s0                                       // 000000129038: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000012903C: 82010103
	.long 0xd7006a00                                           // 000000129040: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000129044: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000129048: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000012904C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000129054: BE810080
	.long 0xd7006a00                                           // 000000129058: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000012905C: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000129060: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129068: BF870092
	.long 0xd7006a00                                           // 00000012906C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000129070: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000129074: D5207C01 01AA0211
	s_nop 0                                                    // 00000012907C: BF800000
	ds_load_b32 v2, v37                                        // 000000129080: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000129088: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000129090: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000129098: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000012909C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001290A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001290A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001290AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001290B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000001290B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001290C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001290C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000001290CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi32ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000001290D0: BFB00000
		...

