00000000000bdb00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000BDB00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000BDB04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000BDB0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000BDB14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000BDB18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000BDB1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000BDB20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000BDB28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000BDB2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000BDB30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000BDB34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000BDB3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000BDB40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000BDB44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000BDB48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BDB4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000BDB50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000BDB54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000BDB58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000BDB5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000BDB64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000BDB6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000BDB70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000BDB74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000BDB78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000BDB7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000BDB80: 821E191E
	.long 0xd7001f02                                           // 0000000BDB84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000BDB88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000BDB8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000BDB94: BE9E0080
	s_nop 0                                                    // 0000000BDB98: BF800000
	s_nop 0                                                    // 0000000BDB9C: BF800000
	s_nop 0                                                    // 0000000BDBA0: BF800000
	s_nop 0                                                    // 0000000BDBA4: BF800000
	s_nop 0                                                    // 0000000BDBA8: BF800000
	s_nop 0                                                    // 0000000BDBAC: BF800000
	s_nop 0                                                    // 0000000BDBB0: BF800000
	s_nop 0                                                    // 0000000BDBB4: BF800000
	s_nop 0                                                    // 0000000BDBB8: BF800000
	s_nop 0                                                    // 0000000BDBBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000BDBC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000BDBC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000BDBD0: 300C1089
	.long 0xd7006a06                                           // 0000000BDBD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000BDBD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BDBDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000BDBE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000BDBE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000BDBF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000BDBF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000BDBFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000BDC08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000BDC0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000BDC10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000BDC18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000BDC1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000BDC20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000BDC24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000BDC2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000BDC34: 32040084
	s_mov_b32 s0, 0                                            // 0000000BDC38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000BDC3C: BF89FC07
	s_barrier                                                  // 0000000BDC40: BFBD0000
	buffer_gl0_inv                                             // 0000000BDC44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000BDC4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000BDC50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000BDC54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000BDC5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BDC64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000BDC68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000BDC70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000BDC74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000BDC78: 916A007E
	s_cbranch_vccz 2                                           // 0000000BDC7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2616                                              // 0000000BDC80: BFA00A38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a64>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000BDC84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000BDC88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000BDC8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000BDC94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000BDC98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000BDC9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000BDCA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000BDCA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000BDCAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000BDCB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000BDCB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000BDCB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000BDCBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000BDCC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000BDCC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000BDCC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000BDCD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000BDCD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000BDCDC: B00A0204
	.long 0xd7000b2c                                           // 0000000BDCE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000BDCE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000BDCE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000BDCEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000BDCF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000BDD00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000BDD04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000BDD10: 3816500A
	.long 0xd7000a05                                           // 0000000BDD14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000BDD18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BDD1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000BDD20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000BDD28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000BDD2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDD30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000BDD34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000BDD3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000BDD40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000BDD44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000BDD4C: 84848E02
	.long 0xd700010b                                           // 0000000BDD50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000BDD54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000BDD58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000BDD5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000BDD64: 8205050F
	.long 0xd700010d                                           // 0000000BDD68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000BDD6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDD70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000BDD74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000BDD7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000BDD80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000BDD88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000BDD90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000BDD94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDD9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000BDDA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000BDDA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000BDDAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000BDDB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000BDDBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000BDDC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDDC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000BDDCC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000BDDD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000BDDD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000BDDE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000BDDE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000BDDEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BDDF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000BDDF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000BDE00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000BDE04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000BDE0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000BDE14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000BDE18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000BDE20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000BDE24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000BDE2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000BDE34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000BDE3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000BDE44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000BDE4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000BDE54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000BDE5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000BDE64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000BDE6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000BDE74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000BDE7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000BDE84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000BDE8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000BDE94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000BDE9C: BE850080
	s_mov_b32 s6, 0x42800000                                   // 0000000BDEA0: BE8600FF 42800000
	s_mov_b32 s7, 0x3c800000                                   // 0000000BDEA8: BE8700FF 3C800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000BDEB0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000BDEB4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000BDEBC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000BDEC0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000BDEC4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BDEC8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000BDECC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000BDED0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000BDED4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000BDED8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000BDEDC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000BDEE4: BE84206A
	s_cbranch_execz 77                                         // 0000000BDEE8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000BDEEC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDEF0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000BDEF4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000BDEFC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF00: BF870091
	.long 0xd73c001d                                           // 0000000BDF04: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000BDF08: 02023A82
	.long 0xd700011d                                           // 0000000BDF0C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000BDF10: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BDF14: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000BDF18: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000BDF20: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BDF28: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000BDF2C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000BDF30: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000BDF3C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000BDF40: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000BDF4C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000BDF50: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000BDF5C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BDF60: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000BDF64: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000BDF70: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDF74: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000BDF78: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000BDF80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000BDF84: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000BDF8C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000BDF94: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000BDF98: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BDF9C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000BDFA0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000BDFA4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BDFA8: BF870296
	.long 0xd71c0020                                           // 0000000BDFAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000BDFB0: 02024520
	.long 0xd71c001f                                           // 0000000BDFB4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000BDFB8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDFBC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000BDFC0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000BDFC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000BDFCC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000BDFD4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000BDFDC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000BDFE0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDFE8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000BDFEC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000BDFF8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000BDFFC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000BE004: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000BE010: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000BE018: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BE020: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000BE024: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000BE02C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BE030: BF89FC07
	s_barrier                                                  // 0000000BE034: BFBD0000
	buffer_gl0_inv                                             // 0000000BE038: E0AC0000 00000000
	s_branch 15                                                // 0000000BE040: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BE044: 8C7E047E
	.long 0xd700011d                                           // 0000000BE048: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000BE04C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE054: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BE058: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000BE060: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000BE064: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000BE068: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000BE06C: BF89FC07
	s_barrier                                                  // 0000000BE070: BFBD0000
	buffer_gl0_inv                                             // 0000000BE074: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000BE07C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000BE080: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000BE088: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000BE090: BE8D0080
	s_nop 0                                                    // 0000000BE094: BF800000
	s_nop 0                                                    // 0000000BE098: BF800000
	s_nop 0                                                    // 0000000BE09C: BF800000
	s_nop 0                                                    // 0000000BE0A0: BF800000
	s_nop 0                                                    // 0000000BE0A4: BF800000
	s_nop 0                                                    // 0000000BE0A8: BF800000
	s_nop 0                                                    // 0000000BE0AC: BF800000
	s_nop 0                                                    // 0000000BE0B0: BF800000
	s_nop 0                                                    // 0000000BE0B4: BF800000
	s_nop 0                                                    // 0000000BE0B8: BF800000
	s_nop 0                                                    // 0000000BE0BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000BE0C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000BE0C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000BE0D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000BE0D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BE0DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000BE0E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000BE0E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000BE0EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000BE0F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000BE0F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000BE0FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000BE104: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000BE10C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000BE110: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BE114: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BE118: BF89FC07
	s_barrier                                                  // 0000000BE11C: BFBD0000
	buffer_gl0_inv                                             // 0000000BE120: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000BE128: BE842000
	s_cbranch_execz 65477                                      // 0000000BE12C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000BE130: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000BE138: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000BE140: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000BE148: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000BE150: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000BE158: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000BE160: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000BE168: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000BE170: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000BE178: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000BE180: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000BE188: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000BE190: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000BE198: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE1A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000BE1A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000BE1AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000BE1B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE1B4: BF870091
	.long 0xd7000146                                           // 0000000BE1B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000BE1BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000BE1C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000BE1C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000BE1D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000BE1D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BE1DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000BE1E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000BE1E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000BE1EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000BE1F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000BE1FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000BE204: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000BE20C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000BE214: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE218: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000BE21C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000BE224: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000BE22C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE230: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000BE234: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000BE23C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000BE244: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE248: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000BE24C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000BE254: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000BE25C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE260: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE264: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000BE26C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000BE274: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000BE27C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000BE284: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000BE28C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000BE294: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000BE29C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000BE2A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE2AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000BE2B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000BE2BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000BE2C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000BE2D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000BE2D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000BE2E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000BE2E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000BE2F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000BE2F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE2FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000BE300: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000BE308: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000BE310: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000BE318: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000BE320: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000BE328: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000BE330: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000BE338: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000BE340: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000BE348: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000BE350: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE354: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000BE358: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000BE360: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000BE368: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE36C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE370: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE378: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE380: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE384: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000BE388: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000BE390: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000BE398: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE39C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE3A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000BE3A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000BE3B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000BE3B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000BE3C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000BE3C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000BE3D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000BE3D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000BE3E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE3E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BE3F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE3F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BE3F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BE400: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BE408: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE40C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000BE410: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000BE418: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000BE420: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE424: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000BE428: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000BE430: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000BE438: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE43C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000BE440: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000BE448: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000BE450: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000BE458: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000BE460: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000BE468: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000BE470: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000BE478: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000BE480: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000BE488: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000BE490: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE494: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BE498: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BE4A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BE4A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE4B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE4B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE4C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000BE4C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000BE4D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE4D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE4DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE4E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000BE4E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000BE4F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000BE4F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000BE500: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000BE508: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000BE510: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000BE518: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000BE520: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE528: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BE530: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE534: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BE538: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BE540: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BE548: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE54C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BE550: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BE558: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BE560: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE564: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BE568: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE570: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE578: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE57C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BE580: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000BE588: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000BE590: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000BE598: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000BE5A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000BE5A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000BE5B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000BE5B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000BE5C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BE5C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BE5D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BE5D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BE5E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BE5E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE5F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE5F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE600: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE604: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BE608: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE610: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE618: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE61C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE620: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000BE628: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000BE630: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000BE638: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000BE640: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000BE648: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000BE650: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000BE658: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000BE660: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE668: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BE670: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE674: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BE678: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BE680: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BE688: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE68C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BE690: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BE698: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BE6A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE6A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BE6A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE6B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE6B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE6BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BE6C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000BE6C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000BE6D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000BE6D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000BE6E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000BE6E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000BE6F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000BE6F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000BE700: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BE708: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BE710: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE714: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BE718: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BE720: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BE728: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE72C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE730: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE738: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE740: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE744: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BE748: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE750: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE758: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE75C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE760: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000BE768: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000BE770: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000BE778: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000BE780: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000BE788: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000BE790: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000BE798: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000BE7A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE7A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BE7B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE7B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BE7B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BE7C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BE7C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE7CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BE7D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BE7D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BE7E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE7E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BE7E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE7F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE7F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE7FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BE800: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000BE808: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000BE810: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000BE818: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000BE820: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000BE828: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000BE830: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000BE838: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000BE840: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BE848: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BE850: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE854: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BE858: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BE860: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BE868: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE86C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE870: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE878: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE880: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE884: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BE888: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE890: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE898: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE89C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE8A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000BE8A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000BE8B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000BE8B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000BE8C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000BE8C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000BE8D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000BE8D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000BE8E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BE8E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BE8F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE8F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BE8F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BE900: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BE908: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE90C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BE910: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BE918: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BE920: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE924: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BE928: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE930: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE938: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE93C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BE940: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000BE948: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000BE950: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000BE958: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000BE960: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000BE968: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000BE970: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000BE978: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000BE980: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BE988: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BE990: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE994: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BE998: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BE9A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BE9A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE9AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BE9B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BE9B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BE9C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE9C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BE9C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BE9D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BE9D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE9DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BE9E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000BE9E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000BE9F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000BE9F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000BEA00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000BEA08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000BEA10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000BEA18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000BEA20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BEA28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BEA30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BEA38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BEA40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BEA48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BEA50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BEA58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BEA60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BEA68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BEA70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BEA78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEA7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BEA80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000BEA88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000BEA90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000BEA98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000BEAA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000BEAA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000BEAB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000BEAB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000BEAC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BEAC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BEAD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEAD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BEAD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BEAE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BEAE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEAEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BEAF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BEAF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BEB00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BEB08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BEB10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BEB18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB1C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000BEB20: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000BEB28: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000BEB30: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB34: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000BEB38: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000BEB40: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000BEB48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEB4C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000BEB50: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000BEB58: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000BEB64: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000BEB6C: D8340000 0000201F
	s_branch 64819                                             // 0000000BEB74: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000BEB78: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000BEB7C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000BEB84: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000BEB88: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000BEB8C: BE8C0080
	s_branch 21                                                // 0000000BEB90: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BEB94: 8C7E0D7E
	.long 0xd700011f                                           // 0000000BEB98: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000BEB9C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEBA4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000BEBA8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000BEBB0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000BEBB4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000BEBBC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BEBC0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000BEBC8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000BEBCC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000BEBD0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000BEBD4: BC7C0000
	s_barrier                                                  // 0000000BEBD8: BFBD0000
	buffer_gl0_inv                                             // 0000000BEBDC: E0AC0000 00000000
	s_cbranch_scc1 609                                         // 0000000BEBE4: BFA20261 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BEBE8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000BEBEC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000BEBF4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000BEBF8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000BEBFC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000BEC00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000BEC08: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000BEC10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000BEC14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BEC1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000BEC20: D5207C22 00064480
	.long 0xd4490004                                           // 0000000BEC28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000BEC2C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000BEC34: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000BEC38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000BEC3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000BEC44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000BEC4C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000BEC50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BEC54: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BEC58: BF89FC07
	s_barrier                                                  // 0000000BEC5C: BFBD0000
	buffer_gl0_inv                                             // 0000000BEC60: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000BEC68: BE8D2000
	s_cbranch_execz 65481                                      // 0000000BEC6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000BEC70: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEC74: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000BEC78: 3848420B
	.long 0xd4440001                                           // 0000000BEC7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000BEC80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000BEC84: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000BEC88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000BEC8C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000BEC94: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000BEC9C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000BECA4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000BECAC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000BECB4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000BECBC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000BECC4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000BECCC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000BECD0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000BECD4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BECDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BECE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BECE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BECE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BECEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BECF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BECF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BECF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BECFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BED00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BED04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BED08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BED0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BED10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000BED14: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000BED1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000BED24: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000BED2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000BED34: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000BED3C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000BED44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000BED4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000BED54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BED58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BED5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BED60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BED64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BED68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BED6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BED70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BED74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BED78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BED7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BED80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BED84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BED88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BED8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BED90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000BED94: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000BED9C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000BEDA4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000BEDAC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000BEDB4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000BEDBC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000BEDC4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000BEDCC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000BEDD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BEDD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEDDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BEDE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BEDE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BEDE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEDEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BEDF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BEDF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BEDF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEDFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BEE00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BEE04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BEE08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEE0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BEE10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000BEE14: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000BEE1C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000BEE24: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000BEE2C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000BEE34: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000BEE3C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000BEE44: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000BEE4C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000BEE54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BEE58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEE5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BEE60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BEE64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BEE68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEE6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BEE70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BEE74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BEE78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEE7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BEE80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BEE84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BEE88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEE8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BEE90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000BEE94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000BEE9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000BEEA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000BEEAC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000BEEB4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000BEEBC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000BEEC4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000BEECC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000BEED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BEED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEEDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BEEE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BEEE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BEEE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEEEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BEEF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BEEF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BEEF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEEFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BEF00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BEF04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BEF08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEF0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BEF10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000BEF14: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000BEF1C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000BEF24: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000BEF2C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000BEF34: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000BEF3C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000BEF44: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000BEF4C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000BEF54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BEF58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEF5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BEF60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BEF64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BEF68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEF6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BEF70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BEF74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BEF78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEF7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BEF80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BEF84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BEF88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BEF8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BEF90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000BEF94: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000BEF9C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000BEFA4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000BEFAC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000BEFB4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000BEFBC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000BEFC4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000BEFCC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000BEFD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BEFD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEFDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BEFE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BEFE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BEFE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEFEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BEFF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BEFF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BEFF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BEFFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF00C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000BF014: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000BF01C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000BF024: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000BF02C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000BF034: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000BF03C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000BF044: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000BF04C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000BF054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF05C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF06C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF07C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF08C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000BF094: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000BF09C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000BF0A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000BF0AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000BF0B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000BF0BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000BF0C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000BF0CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000BF0D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF0D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF0DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF0E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF0E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF0E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF0EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF0F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF0F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF0F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF0FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF10C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000BF114: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000BF11C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000BF124: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000BF12C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000BF134: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000BF13C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000BF144: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000BF14C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000BF154: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF158: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF15C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF160: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF164: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF168: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF16C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF170: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF174: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF178: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF17C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF180: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF184: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF188: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF18C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF190: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000BF194: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000BF19C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000BF1A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000BF1AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000BF1B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000BF1BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000BF1C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000BF1CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000BF1D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF1D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF1DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF1E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF1E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF1E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF1EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF1F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF1F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF1F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF1FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF200: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF204: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF208: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF20C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF210: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000BF214: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000BF21C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000BF224: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000BF22C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000BF234: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000BF23C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000BF244: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000BF24C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000BF254: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF258: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF25C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF260: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF264: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF268: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF26C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF270: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF274: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF278: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF27C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF280: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF284: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF288: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF28C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF290: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000BF294: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000BF29C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000BF2A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000BF2AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000BF2B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000BF2BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000BF2C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000BF2CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000BF2D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF2D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF2DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF2E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF2E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF2E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF2EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF2F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF2F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF2F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF2FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF30C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000BF314: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000BF31C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000BF324: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000BF32C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000BF334: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000BF33C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000BF344: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000BF34C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000BF354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF35C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF36C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF37C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF38C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000BF394: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000BF39C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000BF3A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000BF3AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000BF3B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000BF3BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000BF3C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000BF3CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000BF3D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF3D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF3DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF3E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BF3E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF3E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF3EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF3F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BF3F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF3F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF3FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BF404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF40C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000BF414: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000BF41C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000BF424: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000BF42C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000BF434: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000BF43C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000BF444: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000BF44C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000BF454: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000BF458: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BF45C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000BF460: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000BF468: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000BF470: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BF474: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000BF478: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000BF47C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF480: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BF484: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BF488: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000BF48C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF490: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BF494: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BF498: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000BF49C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF4A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BF4A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BF4A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000BF4AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF4B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000BF4B4: 1078794C
	s_nop 0                                                    // 0000000BF4B8: BF800000
	s_nop 0                                                    // 0000000BF4BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000BF4C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000BF4C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000BF4D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000BF4D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000BF4D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BF4DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000BF4E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000BF4E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000BF4EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000BF4F0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000BF4F8: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000BF4FC: BF89FC07
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000BF500: CC210040 02000D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000BF508: BF8700B1
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BF50C: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000BF514: BF8903F7
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000BF518: CC21003F 02000D3F
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BF520: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF528: BF870001
	v_fmac_f32_e32 v60, v63, v64                               // 0000000BF52C: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000BF530: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000BF534: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000BF538: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF53C: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000BF540: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000BF548: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000BF554: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000BF560: DC960000 007C2421
	s_branch 64906                                             // 0000000BF568: BFA0FD8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000BF56C: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000BF574: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000BF578: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000BF57C: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000BF584: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000BF588: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000BF590: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000BF598: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000BF59C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000BF5A0: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000BF5A8: A0010401
	s_mov_b32 s4, 0                                            // 0000000BF5AC: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000BF5B0: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000BF5B4: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000BF5B8: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000BF5BC: BF870585
	.long 0xd71c001d                                           // 0000000BF5C0: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000BF5C4: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000BF5C8: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000BF5CC: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000BF5D4: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000BF5D8: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000BF5E0: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000BF5E4: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000BF5E8: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000BF5F4: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000BF5FC: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF604: BF870001
	.long 0xd4490001                                           // 0000000BF608: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000BF60C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000BF614: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000BF618: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000BF61C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000BF620: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000BF628: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BF630: 917E047E
	s_cbranch_execnz 65519                                     // 0000000BF634: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1af4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BF638: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000BF63C: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000BF644: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000BF64C: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BF650: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BF654: BF89FC07
	s_barrier                                                  // 0000000BF658: BFBD0000
	buffer_gl0_inv                                             // 0000000BF65C: E0AC0000 00000000
	s_nop 0                                                    // 0000000BF664: BF800000
	s_nop 0                                                    // 0000000BF668: BF800000
	s_nop 0                                                    // 0000000BF66C: BF800000
	s_nop 0                                                    // 0000000BF670: BF800000
	s_nop 0                                                    // 0000000BF674: BF800000
	s_nop 0                                                    // 0000000BF678: BF800000
	s_nop 0                                                    // 0000000BF67C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BF680: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000BF688: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BF690: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BF698: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BF69C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000BF6A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BF6A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BF6B0: BF870004
	.long 0xd4490004                                           // 0000000BF6B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BF6B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BF6C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BF6C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BF6C8: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000BF6CC: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000BF6D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BF6DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BF6E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BF6E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BF6E8: BF89FC07
	s_barrier                                                  // 0000000BF6EC: BFBD0000
	buffer_gl0_inv                                             // 0000000BF6F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000BF6F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000BF700: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000BF708: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000BF710: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BF718: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BF71C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BF720: BF840001
	s_nop 0                                                    // 0000000BF724: BF800000
	s_nop 0                                                    // 0000000BF728: BF800000
	s_nop 0                                                    // 0000000BF72C: BF800000
	s_nop 0                                                    // 0000000BF730: BF800000
	s_nop 0                                                    // 0000000BF734: BF800000
	s_nop 0                                                    // 0000000BF738: BF800000
	s_nop 0                                                    // 0000000BF73C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF740: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BF744: 327A7884
	.long 0xd4490001                                           // 0000000BF748: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BF74C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BF754: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BF758: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BF764: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BF768: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BF770: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BF778: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BF780: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BF788: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BF790: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BF798: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BF7A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BF7A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BF7B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BF7B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BF7B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BF7C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BF7C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BF7C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BF7CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BF7D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BF7D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BF7DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BF7E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BF7F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BF7F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BF800: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BF804: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_set_inst_prefetch_distance 0x2                           // 0000000BF808: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BF80C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000BF810: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BF818: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BF820: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BF824: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BF828: BF89FC07
	s_barrier                                                  // 0000000BF82C: BFBD0000
	buffer_gl0_inv                                             // 0000000BF830: E0AC0000 00000000
	s_nop 0                                                    // 0000000BF838: BF800000
	s_nop 0                                                    // 0000000BF83C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BF840: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000BF848: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BF850: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BF858: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BF85C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BF864: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BF868: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BF870: BF870004
	.long 0xd4490004                                           // 0000000BF874: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BF878: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BF880: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BF884: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BF888: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BF88C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BF894: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BF89C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BF8A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BF8A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BF8A8: BF89FC07
	s_barrier                                                  // 0000000BF8AC: BFBD0000
	buffer_gl0_inv                                             // 0000000BF8B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000BF8B8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000BF8C0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000BF8C8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000BF8D0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BF8D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BF8DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BF8E0: BF840001
	s_nop 0                                                    // 0000000BF8E4: BF800000
	s_nop 0                                                    // 0000000BF8E8: BF800000
	s_nop 0                                                    // 0000000BF8EC: BF800000
	s_nop 0                                                    // 0000000BF8F0: BF800000
	s_nop 0                                                    // 0000000BF8F4: BF800000
	s_nop 0                                                    // 0000000BF8F8: BF800000
	s_nop 0                                                    // 0000000BF8FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF900: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BF904: 327A7884
	.long 0xd4490001                                           // 0000000BF908: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BF90C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BF914: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BF918: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BF924: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BF928: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BF930: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BF938: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BF940: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BF948: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BF950: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BF958: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BF960: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BF964: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BF970: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BF974: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BF978: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BF980: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BF984: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BF988: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BF98C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF990: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BF994: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BF998: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BF99C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF9A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BF9A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BF9B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BF9B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BF9C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BF9C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_set_inst_prefetch_distance 0x2                           // 0000000BF9C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BF9CC: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000BF9D0: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BF9D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BF9E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BF9E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BF9E8: BF89FC07
	s_barrier                                                  // 0000000BF9EC: BFBD0000
	buffer_gl0_inv                                             // 0000000BF9F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BF9F8: BF800000
	s_nop 0                                                    // 0000000BF9FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BFA00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000BFA08: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BFA10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BFA18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BFA1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BFA24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BFA28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BFA30: BF870004
	.long 0xd4490004                                           // 0000000BFA34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BFA38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BFA40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BFA44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BFA48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BFA4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BFA54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BFA5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BFA60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BFA64: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000BFA68: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000BFA70: BF89FC07
	s_barrier                                                  // 0000000BFA74: BFBD0000
	buffer_gl0_inv                                             // 0000000BFA78: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000BFA80: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000BFA84: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000BFA8C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000BFA94: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000BFA9C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000BFAA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BFAA8: BF840001
	s_nop 0                                                    // 0000000BFAAC: BF800000
	s_nop 0                                                    // 0000000BFAB0: BF800000
	s_nop 0                                                    // 0000000BFAB4: BF800000
	s_nop 0                                                    // 0000000BFAB8: BF800000
	s_nop 0                                                    // 0000000BFABC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BFAC0: 327C7A84
	.long 0xd4490001                                           // 0000000BFAC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BFAC8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BFAD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BFAD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BFAD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BFAE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BFAE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BFAF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BFAF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BFB00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BFB08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BFB10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BFB18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BFB20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BFB24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BFB28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BFB2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BFB38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BFB40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BFB44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BFB48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BFB4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BFB54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BFB58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BFB5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BFB64: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BFB70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BFB78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BFB80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BFB84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000BFB88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BFB8C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000BFB90: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BFB98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BFBA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BFBA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BFBA8: BF89FC07
	s_barrier                                                  // 0000000BFBAC: BFBD0000
	buffer_gl0_inv                                             // 0000000BFBB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BFBB8: BF800000
	s_nop 0                                                    // 0000000BFBBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BFBC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000BFBC8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BFBD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BFBD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BFBDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BFBE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BFBE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BFBF0: BF870004
	.long 0xd4490004                                           // 0000000BFBF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BFBF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BFC00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BFC04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BFC08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BFC0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BFC14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BFC1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BFC20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BFC24: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000BFC28: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000BFC30: BF89FC07
	s_barrier                                                  // 0000000BFC34: BFBD0000
	buffer_gl0_inv                                             // 0000000BFC38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000BFC40: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000BFC48: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000BFC50: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000BFC58: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000BFC60: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BFC64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BFC68: BF840001
	s_nop 0                                                    // 0000000BFC6C: BF800000
	s_nop 0                                                    // 0000000BFC70: BF800000
	s_nop 0                                                    // 0000000BFC74: BF800000
	s_nop 0                                                    // 0000000BFC78: BF800000
	s_nop 0                                                    // 0000000BFC7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFC80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BFC84: 327A7884
	.long 0xd4490001                                           // 0000000BFC88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BFC8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BFC94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BFC98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BFCA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BFCA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BFCB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BFCB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BFCC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BFCC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BFCD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BFCD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BFCE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BFCE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BFCF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BFCF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BFCF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BFD00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BFD04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BFD08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BFD0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BFD14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BFD18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BFD1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BFD24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BFD30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BFD38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BFD40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BFD44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_set_inst_prefetch_distance 0x2                           // 0000000BFD48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BFD4C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000BFD50: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BFD58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BFD60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BFD64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BFD68: BF89FC07
	s_barrier                                                  // 0000000BFD6C: BFBD0000
	buffer_gl0_inv                                             // 0000000BFD70: E0AC0000 00000000
	s_nop 0                                                    // 0000000BFD78: BF800000
	s_nop 0                                                    // 0000000BFD7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BFD80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000BFD88: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BFD90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BFD98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BFD9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BFDA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BFDA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BFDB0: BF870004
	.long 0xd4490004                                           // 0000000BFDB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BFDB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BFDC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BFDC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BFDC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BFDCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BFDD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BFDDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BFDE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BFDE4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000BFDE8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000BFDF0: BF89FC07
	s_barrier                                                  // 0000000BFDF4: BFBD0000
	buffer_gl0_inv                                             // 0000000BFDF8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000BFE00: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000BFE04: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000BFE0C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000BFE14: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000BFE1C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000BFE24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BFE28: BF840001
	s_nop 0                                                    // 0000000BFE2C: BF800000
	s_nop 0                                                    // 0000000BFE30: BF800000
	s_nop 0                                                    // 0000000BFE34: BF800000
	s_nop 0                                                    // 0000000BFE38: BF800000
	s_nop 0                                                    // 0000000BFE3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000BFE40: 327C7884
	.long 0xd4490001                                           // 0000000BFE44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BFE48: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BFE50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BFE54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BFE58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BFE64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BFE68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BFE70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BFE78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BFE80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BFE88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BFE90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BFE98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BFEA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BFEA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BFEA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BFEAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BFEB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BFEC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BFEC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BFEC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BFECC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFED0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BFED4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BFED8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BFEDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFEE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000BFEE4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000BFEF0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BFEF4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000BFEF8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000BFEFC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BFF04: 917E047E
	s_cbranch_execnz 65485                                     // 0000000BFF08: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 0000000BFF0C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BFF10: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000BFF14: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BFF1C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BFF24: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BFF28: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BFF2C: BF89FC07
	s_barrier                                                  // 0000000BFF30: BFBD0000
	buffer_gl0_inv                                             // 0000000BFF34: E0AC0000 00000000
	s_nop 0                                                    // 0000000BFF3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BFF40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000BFF48: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BFF50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BFF58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BFF5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BFF64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BFF68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BFF70: BF870004
	.long 0xd4490004                                           // 0000000BFF74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BFF78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BFF80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BFF84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BFF88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BFF8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BFF94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BFF9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BFFA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BFFA4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000BFFA8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000BFFB0: BF89FC07
	s_barrier                                                  // 0000000BFFB4: BFBD0000
	buffer_gl0_inv                                             // 0000000BFFB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000BFFC0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000BFFC8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000BFFD0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000BFFD8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000BFFE0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000BFFE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BFFE8: BF840001
	s_nop 0                                                    // 0000000BFFEC: BF800000
	s_nop 0                                                    // 0000000BFFF0: BF800000
	s_nop 0                                                    // 0000000BFFF4: BF800000
	s_nop 0                                                    // 0000000BFFF8: BF800000
	s_nop 0                                                    // 0000000BFFFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0000: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000C0004: 327C7A84
	.long 0xd4490001                                           // 0000000C0008: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000C000C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000C0014: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000C0018: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C0024: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000C0028: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000C0030: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000C0038: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000C0040: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000C0048: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000C0050: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000C0058: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000C0060: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000C0064: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C0068: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000C006C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000C0078: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000C0080: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000C0084: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000C0088: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000C008C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0090: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000C0094: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000C0098: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000C009C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C00A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000C00A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000C00B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000C00B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C00C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C00C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_set_inst_prefetch_distance 0x2                           // 0000000C00C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C00CC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000C00D0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C00D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C00E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C00E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C00E8: BF89FC07
	s_barrier                                                  // 0000000C00EC: BFBD0000
	buffer_gl0_inv                                             // 0000000C00F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000C00F8: BF800000
	s_nop 0                                                    // 0000000C00FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C0100: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000C0108: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C0110: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C0118: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C011C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C0124: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C0128: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C0130: BF870004
	.long 0xd4490004                                           // 0000000C0134: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C0138: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C0140: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C0144: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C0148: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C014C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C0154: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C015C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C0160: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C0164: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C0168: BF89FC07
	s_barrier                                                  // 0000000C016C: BFBD0000
	buffer_gl0_inv                                             // 0000000C0170: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000C0178: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000C0180: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000C0188: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000C0190: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000C0198: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000C019C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C01A0: BF840001
	s_nop 0                                                    // 0000000C01A4: BF800000
	s_nop 0                                                    // 0000000C01A8: BF800000
	s_nop 0                                                    // 0000000C01AC: BF800000
	s_nop 0                                                    // 0000000C01B0: BF800000
	s_nop 0                                                    // 0000000C01B4: BF800000
	s_nop 0                                                    // 0000000C01B8: BF800000
	s_nop 0                                                    // 0000000C01BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C01C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000C01C4: 327C7A84
	.long 0xd4490001                                           // 0000000C01C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000C01CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000C01D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000C01D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C01E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000C01E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000C01F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000C01F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000C0200: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000C0208: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000C0210: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000C0218: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000C0220: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000C0224: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C0228: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000C022C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000C0238: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000C0240: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000C0244: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000C0248: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000C024C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0250: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000C0254: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000C0258: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000C025C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0260: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000C0264: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000C0270: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000C0278: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C0280: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C0284: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000C0288: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C028C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000C0290: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C0298: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C02A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C02A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C02A8: BF89FC07
	s_barrier                                                  // 0000000C02AC: BFBD0000
	buffer_gl0_inv                                             // 0000000C02B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000C02B8: BF800000
	s_nop 0                                                    // 0000000C02BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C02C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000C02C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C02D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C02D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C02DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C02E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C02E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C02F0: BF870004
	.long 0xd4490004                                           // 0000000C02F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C02F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C0300: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C0304: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C0308: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C030C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C0314: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C031C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C0320: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C0324: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000C0328: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000C0330: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000C0338: BF89FC07
	s_barrier                                                  // 0000000C033C: BFBD0000
	buffer_gl0_inv                                             // 0000000C0340: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000C0348: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000C0350: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000C0358: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000C0360: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000C0368: 7E780300
	s_mov_b32 s4, 0                                            // 0000000C036C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C0370: BF840001
	s_nop 0                                                    // 0000000C0374: BF800000
	s_nop 0                                                    // 0000000C0378: BF800000
	s_nop 0                                                    // 0000000C037C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0380: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000C0384: 327A7884
	.long 0xd4490001                                           // 0000000C0388: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000C038C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000C0394: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000C0398: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C03A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000C03A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000C03B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000C03B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000C03C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000C03C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000C03D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000C03D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000C03E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000C03E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C03F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000C03F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000C03F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000C0400: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000C0404: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000C0408: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000C040C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0410: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000C0414: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000C0418: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000C041C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0420: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000C0424: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000C0430: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000C0438: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C0440: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C0444: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2880>
	s_set_inst_prefetch_distance 0x2                           // 0000000C0448: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C044C: 8C7E047E
	.long 0xd7000107                                           // 0000000C0450: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000C0454: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C045C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000C0460: D5207C08 00061080
	.long 0xd7000109                                           // 0000000C0468: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000C046C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000C0474: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000C047C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000C0480: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C0488: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000C048C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000C0494: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000C0498: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000C04A0: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000C04A8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000C04AC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C04B4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000C04B8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000C04C0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000C04C4: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000C04CC: D5207C12 00062480
	.long 0xd7000113                                           // 0000000C04D4: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000C04D8: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C04E0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000C04E4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000C04EC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000C04F0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000C04F8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000C0500: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000C0504: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C050C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000C0510: D5207C18 00063080
	.long 0xd7000119                                           // 0000000C0518: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000C051C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000C0524: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000C052C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000C0530: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C0538: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000C053C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000C0544: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000C0548: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000C054C: BF062105
	s_barrier                                                  // 0000000C0550: BFBD0000
	buffer_gl0_inv                                             // 0000000C0554: E0AC0000 00000000
	s_cbranch_scc0 63061                                       // 0000000C055C: BFA1F655 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000C0560: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000C0564: 8000141C
	.long 0xd73c0000                                           // 0000000C0568: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000C056C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000C0570: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000C0574: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000C0578: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000C057C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000C0580: 82010103
	.long 0xd7006a00                                           // 0000000C0584: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000C0588: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000C058C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000C0590: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000C0598: BE810080
	.long 0xd7006a00                                           // 0000000C059C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000C05A0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000C05A4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C05AC: BF870092
	.long 0xd7006a00                                           // 0000000C05B0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000C05B4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000C05B8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000C05C0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000C05C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000C05D0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000C05D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000C05DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000C05E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000C05E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000C05EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000C05F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000C05F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000C0600: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000C0608: 917E017E
	s_cbranch_execnz 65516                                     // 0000000C060C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_endpgm                                                   // 0000000C0610: BFB00000
		...

