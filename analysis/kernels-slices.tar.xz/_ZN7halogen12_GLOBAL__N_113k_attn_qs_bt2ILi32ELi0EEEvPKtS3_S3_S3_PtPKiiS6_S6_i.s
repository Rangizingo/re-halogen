00000000001a9400 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_load_b256 s[4:11], s[0:1], 0x10                          // 0000001A9400: F40C0100 F8000010
	s_mov_b32 s16, s3                                          // 0000001A9408: BE900003
	s_ashr_i32 s3, s2, 31                                      // 0000001A940C: 86039F02
	s_load_b32 s19, s[0:1], 0x48                               // 0000001A9410: F40004C0 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001A9418: BF89FC07
	s_load_b32 s17, s[10:11], null                             // 0000001A941C: F4000445 F8000000
	s_load_b128 s[12:15], s[0:1], 0x38                         // 0000001A9424: F4080300 F8000038
	s_lshl_b64 s[10:11], s[2:3], 2                             // 0000001A942C: 848A8202
	s_waitcnt lgkmcnt(0)                                       // 0000001A9430: BF89FC07
	s_add_i32 s3, s17, s2                                      // 0000001A9434: 81030211
	s_add_u32 s10, s14, s10                                    // 0000001A9438: 800A0A0E
	s_addc_u32 s11, s15, s11                                   // 0000001A943C: 820B0B0F
	s_add_i32 s15, s3, 1                                       // 0000001A9440: 810F8103
	s_load_b32 s14, s[10:11], null                             // 0000001A9444: F4000385 F8000000
	s_ashr_i32 s10, s15, 31                                    // 0000001A944C: 860A9F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001A9450: BF870499
	s_lshr_b32 s10, s10, 30                                    // 0000001A9454: 850A9E0A
	s_add_i32 s10, s15, s10                                    // 0000001A9458: 810A0A0F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A945C: BF870009
	s_and_b32 s11, s10, -4                                     // 0000001A9460: 8B0BC40A
	s_ashr_i32 s18, s10, 2                                     // 0000001A9464: 8612820A
	s_sub_i32 s15, s3, s11                                     // 0000001A9468: 818F0B03
	s_mul_hi_i32 s11, s19, s2                                  // 0000001A946C: 970B0213
	s_cmp_gt_i32 s15, -1                                       // 0000001A9470: BF02C10F
	s_mul_i32 s10, s19, s2                                     // 0000001A9474: 960A0213
	s_cselect_b32 s3, -1, 0                                    // 0000001A9478: 980380C1
	s_mov_b32 s19, s18                                         // 0000001A947C: BE930012
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000001A9480: 8B6A037E
	s_cbranch_vccnz 15                                         // 0000001A9484: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xc4>
	s_lshl_b64 s[20:21], s[10:11], 2                           // 0000001A9488: 8494820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001A948C: BF8704D9
	s_add_u32 s17, s12, s20                                    // 0000001A9490: 8011140C
	s_addc_u32 s19, s13, s21                                   // 0000001A9494: 8213150D
	s_waitcnt lgkmcnt(0)                                       // 0000001A9498: BF89FC07
	s_max_i32 s20, s14, 1                                      // 0000001A949C: 8A14810E
	s_mov_b32 s21, 0                                           // 0000001A94A0: BE950080
	s_lshl_b64 s[20:21], s[20:21], 2                           // 0000001A94A4: 84948214
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A94A8: BF870009
	s_add_u32 s17, s17, s20                                    // 0000001A94AC: 80111411
	s_addc_u32 s19, s19, s21                                   // 0000001A94B0: 82131513
	s_add_u32 s20, s17, -4                                     // 0000001A94B4: 8014C411
	s_addc_u32 s21, s19, -1                                    // 0000001A94B8: 8215C113
	s_load_b32 s19, s[20:21], null                             // 0000001A94BC: F40004CA F8000000
	v_cndmask_b32_e64 v1, 0, 1, s3                             // 0000001A94C4: D5010001 000D0280
	s_mov_b32 s22, exec_lo                                     // 0000001A94CC: BE96007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001A94D0: BF8704B1
	v_readfirstlane_b32 s3, v1                                 // 0000001A94D4: 7E060501
	s_waitcnt lgkmcnt(0)                                       // 0000001A94D8: BF89FC07
	s_add_i32 s20, s14, s3                                     // 0000001A94DC: 8114030E
	s_add_i32 s17, s20, 3                                      // 0000001A94E0: 81118314
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001A94E4: BF870499
	s_and_b32 s21, s17, -4                                     // 0000001A94E8: 8B15C411
	.long 0xd4c4007e                                           // 0000001A94EC: D4C4007E
	v_cndmask_b32_e32 v1, s21, v0, vcc_lo                      // 0000001A94F0: 02020015
	s_cbranch_execz 48                                         // 0000001A94F4: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001A94F8: CA220100 04020082
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000001A9500: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9504: BF8700A9
	s_add_u32 s3, s12, s10                                     // 0000001A9508: 80030A0C
	s_addc_u32 s10, s13, s11                                   // 0000001A950C: 820A0B0D
	.long 0xd7000301                                           // 0000001A9510: D7000301
	v_cndmask_b32_e32 v1, s3, v3, vcc_lo                       // 0000001A9514: 02020603
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9518: BF870001
	v_add_co_ci_u32_e64 v2, null, s10, 0, s3                   // 0000001A951C: D5207C02 000D000A
	s_mov_b32 s10, 0                                           // 0000001A9524: BE8A0080
	s_set_inst_prefetch_distance 0x1                           // 0000001A9528: BF840001
	s_branch 21                                                // 0000001A952C: BFA00015 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 0000001A9530: BF800000
	s_nop 0                                                    // 0000001A9534: BF800000
	s_nop 0                                                    // 0000001A9538: BF800000
	s_nop 0                                                    // 0000001A953C: BF800000
	s_or_b32 exec_lo, exec_lo, s3                              // 0000001A9540: 8C7E037E
	v_add_nc_u32_e32 v4, 64, v4                                // 0000001A9544: 4A0808C0
	.long 0xd7000301                                           // 0000001A9548: D7000301
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 0000001A954C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000001A9554: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 0000001A9558: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 0000001A9560: D5207C02 000E0480
	v_cmp_le_i32_e32 vcc_lo, s21, v4                           // 0000001A9568: 7C860815
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000001A956C: 4A0606FF 00000100
	s_or_b32 s10, vcc_lo, s10                                  // 0000001A9574: 8C0A0A6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A9578: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000001A957C: 917E0A7E
	s_cbranch_execz 13                                         // 0000001A9580: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s3, exec_lo                                      // 0000001A9584: BE83007E
	.long 0xd4c3007e                                           // 0000001A9588: D4C3007E
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000001A958C: 0202080E
	s_xor_b32 s3, exec_lo, s3                                  // 0000001A9590: 8D03037E
	v_mov_b32_e32 v5, s18                                      // 0000001A9594: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s20, v4                           // 0000001A9598: 7C880814
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A959C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001A95A0: 020A0A13
	s_and_not1_saveexec_b32 s3, s3                             // 0000001A95A4: BE833003
	s_cbranch_execz 65509                                      // 0000001A95A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001A95AC: DC520000 057C0001
	s_branch 65506                                             // 0000001A95B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001A95B8: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000001A95BC: 8C7E167E
	v_lshrrev_b32_e32 v6, 5, v0                                // 0000001A95C0: 320C0085
	s_mov_b32 s3, exec_lo                                      // 0000001A95C4: BE83007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001A95C8: 7D9800FF 00000180
	s_cbranch_execz 64                                         // 0000001A95D0: BFA50040 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2d4>
	s_load_b64 s[0:1], s[0:1], null                            // 0000001A95D4: F4040000 F8000000
	s_mul_i32 s10, s16, 0xc00                                  // 0000001A95DC: 960AFF10 00000C00
	v_mul_u32_u24_e32 v1, 0x210, v6                            // 0000001A95E4: 16020CFF 00000210
	s_ashr_i32 s11, s10, 31                                    // 0000001A95EC: 860B9F0A
	v_and_b32_e32 v2, 31, v0                                   // 0000001A95F0: 3604009F
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000001A95F4: 848A810A
	v_lshlrev_b32_e32 v5, 4, v0                                // 0000001A95F8: 300A0084
	s_mul_i32 s13, s2, 0x3000                                  // 0000001A95FC: 960DFF02 00003000
	s_mul_hi_i32 s12, s2, 0x3000                               // 0000001A9604: 970CFF02 00003000
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001A960C: D6460004 04050902
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001A9614: D6560003 03FD0700 FFFFFE00
	s_waitcnt lgkmcnt(0)                                       // 0000001A9620: BF89FC07
	s_add_u32 s0, s0, s10                                      // 0000001A9624: 80000A00
	s_addc_u32 s1, s1, s11                                     // 0000001A9628: 82010B01
	s_add_u32 s0, s0, s13                                      // 0000001A962C: 80000D00
	s_addc_u32 s1, s1, s12                                     // 0000001A9630: 82010C01
	.long 0xd7000001                                           // 0000001A9634: D7000001
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 0000001A9638: 02020A00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A963C: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001A9640: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001A9648: BE810080
	s_nop 0                                                    // 0000001A964C: BF800000
	s_nop 0                                                    // 0000001A9650: BF800000
	s_nop 0                                                    // 0000001A9654: BF800000
	s_nop 0                                                    // 0000001A9658: BF800000
	s_nop 0                                                    // 0000001A965C: BF800000
	s_nop 0                                                    // 0000001A9660: BF800000
	s_nop 0                                                    // 0000001A9664: BF800000
	s_nop 0                                                    // 0000001A9668: BF800000
	s_nop 0                                                    // 0000001A966C: BF800000
	s_nop 0                                                    // 0000001A9670: BF800000
	s_nop 0                                                    // 0000001A9674: BF800000
	s_nop 0                                                    // 0000001A9678: BF800000
	s_nop 0                                                    // 0000001A967C: BF800000
	global_load_b128 v[7:10], v[1:2], off                      // 0000001A9680: DC5E0000 077C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001A9688: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001A9690: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001A9694: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A969C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001A96A0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001A96A8: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001A96AC: 020206FF 000009FF
	s_or_b32 s1, s0, s1                                        // 0000001A96B4: 8C010100
	s_waitcnt vmcnt(0)                                         // 0000001A96B8: BF8903F7
	ds_store_b128 v4, v[7:10] offset:9232                      // 0000001A96BC: DB7C2410 00000704
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001A96C4: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001A96CC: 917E017E
	s_cbranch_execnz 65515                                     // 0000001A96D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x280>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000001A96D4: 8C7E037E
	v_lshlrev_b32_e32 v91, 7, v6                               // 0000001A96D8: 30B60C87
	s_ashr_i32 s1, s17, 2                                      // 0000001A96DC: 86018211
	s_mov_b32 s0, 0                                            // 0000001A96E0: BE800080
	s_cmp_gt_i32 s1, 0                                         // 0000001A96E4: BF028001
	s_waitcnt lgkmcnt(0)                                       // 0000001A96E8: BF89FC07
	s_barrier                                                  // 0000001A96EC: BFBD0000
	buffer_gl0_inv                                             // 0000001A96F0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 0000001A96F8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x304>
	v_lshlrev_b32_e32 v7, 7, v6                                // 0000001A96FC: 300E0C87
	s_branch 1                                                 // 0000001A9700: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x308>
	s_mov_b32 s0, -1                                           // 0000001A9704: BE8000C1
	v_mov_b32_e32 v37, 0                                       // 0000001A9708: 7E4A0280
	v_and_b32_e32 v89, 15, v0                                  // 0000001A970C: 36B2008F
	v_bfe_u32 v90, v0, 4, 1                                    // 0000001A9710: D610005A 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001A9718: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A971C: BF870003
	v_mov_b32_e32 v36, v37                                     // 0000001A9720: 7E480325
	v_mov_b32_e32 v35, v37                                     // 0000001A9724: 7E460325
	v_mov_b32_e32 v34, v37                                     // 0000001A9728: 7E440325
	v_mov_b32_e32 v33, v37                                     // 0000001A972C: 7E420325
	v_mov_b32_e32 v32, v37                                     // 0000001A9730: 7E400325
	v_mov_b32_e32 v45, v37                                     // 0000001A9734: 7E5A0325
	v_mov_b32_e32 v44, v37                                     // 0000001A9738: 7E580325
	v_mov_b32_e32 v43, v37                                     // 0000001A973C: 7E560325
	v_mov_b32_e32 v42, v37                                     // 0000001A9740: 7E540325
	v_mov_b32_e32 v41, v37                                     // 0000001A9744: 7E520325
	v_mov_b32_e32 v40, v37                                     // 0000001A9748: 7E500325
	v_mov_b32_e32 v53, v37                                     // 0000001A974C: 7E6A0325
	v_mov_b32_e32 v52, v37                                     // 0000001A9750: 7E680325
	v_mov_b32_e32 v51, v37                                     // 0000001A9754: 7E660325
	v_mov_b32_e32 v50, v37                                     // 0000001A9758: 7E640325
	v_mov_b32_e32 v49, v37                                     // 0000001A975C: 7E620325
	v_mov_b32_e32 v48, v37                                     // 0000001A9760: 7E600325
	v_mov_b32_e32 v61, v37                                     // 0000001A9764: 7E7A0325
	v_mov_b32_e32 v60, v37                                     // 0000001A9768: 7E780325
	v_mov_b32_e32 v59, v37                                     // 0000001A976C: 7E760325
	v_mov_b32_e32 v58, v37                                     // 0000001A9770: 7E740325
	v_mov_b32_e32 v57, v37                                     // 0000001A9774: 7E720325
	v_mov_b32_e32 v56, v37                                     // 0000001A9778: 7E700325
	v_mov_b32_e32 v29, v37                                     // 0000001A977C: 7E3A0325
	v_mov_b32_e32 v28, v37                                     // 0000001A9780: 7E380325
	v_mov_b32_e32 v27, v37                                     // 0000001A9784: 7E360325
	v_mov_b32_e32 v26, v37                                     // 0000001A9788: 7E340325
	v_mov_b32_e32 v25, v37                                     // 0000001A978C: 7E320325
	v_mov_b32_e32 v24, v37                                     // 0000001A9790: 7E300325
	v_mov_b32_e32 v21, v37                                     // 0000001A9794: 7E2A0325
	v_mov_b32_e32 v20, v37                                     // 0000001A9798: 7E280325
	v_mov_b32_e32 v19, v37                                     // 0000001A979C: 7E260325
	v_mov_b32_e32 v18, v37                                     // 0000001A97A0: 7E240325
	v_mov_b32_e32 v17, v37                                     // 0000001A97A4: 7E220325
	v_mov_b32_e32 v16, v37                                     // 0000001A97A8: 7E200325
	v_mov_b32_e32 v13, v37                                     // 0000001A97AC: 7E1A0325
	v_mov_b32_e32 v12, v37                                     // 0000001A97B0: 7E180325
	v_mov_b32_e32 v11, v37                                     // 0000001A97B4: 7E160325
	v_mov_b32_e32 v10, v37                                     // 0000001A97B8: 7E140325
	v_mov_b32_e32 v9, v37                                      // 0000001A97BC: 7E120325
	v_mov_b32_e32 v8, v37                                      // 0000001A97C0: 7E100325
	v_mov_b32_e32 v5, v37                                      // 0000001A97C4: 7E0A0325
	v_mov_b32_e32 v4, v37                                      // 0000001A97C8: 7E080325
	v_mov_b32_e32 v3, v37                                      // 0000001A97CC: 7E060325
	v_mov_b32_e32 v2, v37                                      // 0000001A97D0: 7E040325
	v_mov_b32_e32 v1, v37                                      // 0000001A97D4: 7E020325
	v_mov_b32_e32 v0, v37                                      // 0000001A97D8: 7E000325
	v_mov_b32_e32 v76, v37                                     // 0000001A97DC: 7E980325
	v_mov_b32_e32 v84, v37                                     // 0000001A97E0: 7EA80325
	v_mov_b32_e32 v74, v37                                     // 0000001A97E4: 7E940325
	v_mov_b32_e32 v73, v37                                     // 0000001A97E8: 7E920325
	v_mov_b32_e32 v88, v37                                     // 0000001A97EC: 7EB00325
	v_mov_b32_e32 v87, v37                                     // 0000001A97F0: 7EAE0325
	s_cbranch_vccnz 1375                                       // 0000001A97F4: BFA4055F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1974>
	s_ashr_i32 s17, s16, 31                                    // 0000001A97F8: 86119F10
	v_cmp_gt_u32_e32 vcc_lo, 12, v89                           // 0000001A97FC: 7C98B28C
	s_lshl_b64 s[10:11], s[16:17], 8                           // 0000001A9800: 848A8810
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001A9804: BF870139
	v_dual_mov_b32 v97, s11 :: v_dual_lshlrev_b32 v0, 2, v89   // 0000001A9808: CA22000B 6100B282
	s_movk_i32 s3, 0x210                                       // 0000001A9810: B0030210
	v_dual_cndmask_b32 v1, 0, v89 :: v_dual_lshlrev_b32 v2, 9, v6// 0000001A9814: CA62B280 01020C89
	v_lshl_or_b32 v0, v90, 6, v0                               // 0000001A981C: D6560000 04010D5A
	v_dual_mov_b32 v64, 0 :: v_dual_lshlrev_b32 v3, 5, v90     // 0000001A9824: CA220080 4002B485
	v_dual_mov_b32 v113, 0xf149f2ca :: v_dual_lshlrev_b32 v4, 1, v89// 0000001A982C: CA2200FF 7104B281 F149F2CA
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A9838: BF870223
	v_add_nc_u32_e32 v0, 0x3cd0, v0                            // 0000001A983C: 4A0000FF 00003CD0
	v_xor_b32_e32 v5, 1, v6                                    // 0000001A9844: 3A0A0C81
	v_dual_mov_b32 v66, v64 :: v_dual_lshlrev_b32 v7, 8, v6    // 0000001A9848: CA220140 42060C88
	v_mad_u32_u24 v1, v1, s3, 0x2410                           // 0000001A9850: D60B0001 03FC0701 00002410
	v_or3_b32 v92, v2, v3, v4                                  // 0000001A985C: D658005C 04120702
	v_lshl_or_b32 v95, v89, 5, v2                              // 0000001A9864: D656005F 04090B59
	v_or3_b32 v96, s10, v89, v91                               // 0000001A986C: D6580060 056EB20A
	v_mov_b32_e32 v65, v64                                     // 0000001A9874: 7E820340
	v_lshl_add_u32 v93, v6, 10, v0                             // 0000001A9878: D646005D 04011506
	v_lshl_add_u32 v94, v5, 10, v0                             // 0000001A9880: D646005E 04011505
	v_dual_mov_b32 v67, v64 :: v_dual_add_nc_u32 v98, v1, v7   // 0000001A9888: CA200140 43620F01
	v_dual_mov_b32 v68, v64 :: v_dual_mov_b32 v115, 0xf149f2ca // 0000001A9890: CA100140 447200FF F149F2CA
	v_dual_mov_b32 v69, v64 :: v_dual_mov_b32 v116, 0xf149f2ca // 0000001A989C: CA100140 457400FF F149F2CA
	v_dual_mov_b32 v70, v64 :: v_dual_mov_b32 v109, 0xf149f2ca // 0000001A98A8: CA100140 466C00FF F149F2CA
	v_dual_mov_b32 v71, v64 :: v_dual_mov_b32 v114, 0xf149f2ca // 0000001A98B4: CA100140 477200FF F149F2CA
	v_dual_mov_b32 v112, 0xf149f2ca :: v_dual_mov_b32 v107, 0xf149f2ca// 0000001A98C0: CA1000FF 706A00FF F149F2CA
	v_dual_mov_b32 v108, 0xf149f2ca :: v_dual_mov_b32 v101, v64// 0000001A98CC: CA1000FF 6C640140 F149F2CA
	v_mov_b32_e32 v100, v64                                    // 0000001A98D8: 7EC80340
	v_mov_b32_e32 v102, v64                                    // 0000001A98DC: 7ECC0340
	v_mov_b32_e32 v103, v64                                    // 0000001A98E0: 7ECE0340
	v_mov_b32_e32 v104, v64                                    // 0000001A98E4: 7ED00340
	v_mov_b32_e32 v105, v64                                    // 0000001A98E8: 7ED20340
	v_mov_b32_e32 v106, v64                                    // 0000001A98EC: 7ED40340
	v_mov_b32_e32 v99, v64                                     // 0000001A98F0: 7EC60340
	v_mov_b32_e32 v0, v64                                      // 0000001A98F4: 7E000340
	v_mov_b32_e32 v1, v64                                      // 0000001A98F8: 7E020340
	v_mov_b32_e32 v2, v64                                      // 0000001A98FC: 7E040340
	v_mov_b32_e32 v3, v64                                      // 0000001A9900: 7E060340
	v_mov_b32_e32 v4, v64                                      // 0000001A9904: 7E080340
	v_mov_b32_e32 v5, v64                                      // 0000001A9908: 7E0A0340
	v_mov_b32_e32 v6, v64                                      // 0000001A990C: 7E0C0340
	v_mov_b32_e32 v7, v64                                      // 0000001A9910: 7E0E0340
	v_mov_b32_e32 v8, v64                                      // 0000001A9914: 7E100340
	v_mov_b32_e32 v9, v64                                      // 0000001A9918: 7E120340
	v_mov_b32_e32 v10, v64                                     // 0000001A991C: 7E140340
	v_mov_b32_e32 v11, v64                                     // 0000001A9920: 7E160340
	v_mov_b32_e32 v12, v64                                     // 0000001A9924: 7E180340
	v_mov_b32_e32 v13, v64                                     // 0000001A9928: 7E1A0340
	v_mov_b32_e32 v14, v64                                     // 0000001A992C: 7E1C0340
	v_mov_b32_e32 v15, v64                                     // 0000001A9930: 7E1E0340
	v_mov_b32_e32 v16, v64                                     // 0000001A9934: 7E200340
	v_mov_b32_e32 v17, v64                                     // 0000001A9938: 7E220340
	v_mov_b32_e32 v18, v64                                     // 0000001A993C: 7E240340
	v_mov_b32_e32 v19, v64                                     // 0000001A9940: 7E260340
	v_mov_b32_e32 v20, v64                                     // 0000001A9944: 7E280340
	v_mov_b32_e32 v21, v64                                     // 0000001A9948: 7E2A0340
	v_mov_b32_e32 v22, v64                                     // 0000001A994C: 7E2C0340
	v_mov_b32_e32 v23, v64                                     // 0000001A9950: 7E2E0340
	v_mov_b32_e32 v24, v64                                     // 0000001A9954: 7E300340
	v_mov_b32_e32 v25, v64                                     // 0000001A9958: 7E320340
	v_mov_b32_e32 v26, v64                                     // 0000001A995C: 7E340340
	v_mov_b32_e32 v27, v64                                     // 0000001A9960: 7E360340
	v_mov_b32_e32 v28, v64                                     // 0000001A9964: 7E380340
	v_mov_b32_e32 v29, v64                                     // 0000001A9968: 7E3A0340
	v_mov_b32_e32 v30, v64                                     // 0000001A996C: 7E3C0340
	v_mov_b32_e32 v31, v64                                     // 0000001A9970: 7E3E0340
	v_mov_b32_e32 v56, v64                                     // 0000001A9974: 7E700340
	v_mov_b32_e32 v57, v64                                     // 0000001A9978: 7E720340
	v_mov_b32_e32 v58, v64                                     // 0000001A997C: 7E740340
	v_mov_b32_e32 v59, v64                                     // 0000001A9980: 7E760340
	v_mov_b32_e32 v60, v64                                     // 0000001A9984: 7E780340
	v_mov_b32_e32 v61, v64                                     // 0000001A9988: 7E7A0340
	v_mov_b32_e32 v62, v64                                     // 0000001A998C: 7E7C0340
	v_mov_b32_e32 v63, v64                                     // 0000001A9990: 7E7E0340
	v_mov_b32_e32 v48, v64                                     // 0000001A9994: 7E600340
	v_mov_b32_e32 v49, v64                                     // 0000001A9998: 7E620340
	v_mov_b32_e32 v50, v64                                     // 0000001A999C: 7E640340
	v_mov_b32_e32 v51, v64                                     // 0000001A99A0: 7E660340
	v_mov_b32_e32 v52, v64                                     // 0000001A99A4: 7E680340
	v_mov_b32_e32 v53, v64                                     // 0000001A99A8: 7E6A0340
	v_mov_b32_e32 v54, v64                                     // 0000001A99AC: 7E6C0340
	v_mov_b32_e32 v55, v64                                     // 0000001A99B0: 7E6E0340
	v_mov_b32_e32 v40, v64                                     // 0000001A99B4: 7E500340
	v_mov_b32_e32 v41, v64                                     // 0000001A99B8: 7E520340
	v_mov_b32_e32 v42, v64                                     // 0000001A99BC: 7E540340
	v_mov_b32_e32 v43, v64                                     // 0000001A99C0: 7E560340
	v_mov_b32_e32 v44, v64                                     // 0000001A99C4: 7E580340
	v_mov_b32_e32 v45, v64                                     // 0000001A99C8: 7E5A0340
	v_mov_b32_e32 v46, v64                                     // 0000001A99CC: 7E5C0340
	v_mov_b32_e32 v47, v64                                     // 0000001A99D0: 7E5E0340
	v_mov_b32_e32 v32, v64                                     // 0000001A99D4: 7E400340
	v_mov_b32_e32 v33, v64                                     // 0000001A99D8: 7E420340
	v_mov_b32_e32 v34, v64                                     // 0000001A99DC: 7E440340
	v_mov_b32_e32 v35, v64                                     // 0000001A99E0: 7E460340
	v_mov_b32_e32 v36, v64                                     // 0000001A99E4: 7E480340
	v_mov_b32_e32 v37, v64                                     // 0000001A99E8: 7E4A0340
	v_mov_b32_e32 v38, v64                                     // 0000001A99EC: 7E4C0340
	v_mov_b32_e32 v39, v64                                     // 0000001A99F0: 7E4E0340
	s_lshl2_add_u32 s0, s14, s15                               // 0000001A99F4: 87800F0E
	s_mov_b32 s17, 0                                           // 0000001A99F8: BE910080
	s_add_i32 s3, s0, 1                                        // 0000001A99FC: 81038100
	s_mov_b32 s20, 0                                           // 0000001A9A00: BE940080
	s_branch 251                                               // 0000001A9A04: BFA000FB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x9f4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A9A08: 8C7E007E
	v_bfe_u32 v107, v109, 16, 1                                // 0000001A9A0C: D610006B 0205216D
	s_ashr_i32 s19, s18, 31                                    // 0000001A9A14: 86139F12
	s_ashr_i32 s15, s14, 31                                    // 0000001A9A18: 860F9F0E
	s_lshl_b64 s[18:19], s[18:19], 9                           // 0000001A9A1C: 84928912
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000001A9A20: 848E890E
	v_add3_u32 v107, v109, v107, 0x7fff                        // 0000001A9A24: D655006B 03FED76D 00007FFF
	s_ashr_i32 s11, s10, 31                                    // 0000001A9A30: 860B9F0A
	s_ashr_i32 s13, s12, 31                                    // 0000001A9A34: 860D9F0C
	s_lshl_b64 s[10:11], s[10:11], 9                           // 0000001A9A38: 848A890A
	s_lshl_b64 s[12:13], s[12:13], 9                           // 0000001A9A3C: 848C890C
	ds_store_b16_d16_hi v92, v107 offset:448                   // 0000001A9A40: DA8401C0 00006B5C
	.long 0xd7006a6b                                           // 0000001A9A48: D7006A6B
	v_cndmask_b32_e32 v1, s18, v96, vcc_lo                     // 0000001A9A4C: 0202C012
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9A50: BF8700A1
	v_add_co_ci_u32_e64 v108, null, s19, v97, vcc_lo           // 0000001A9A54: D5207C6C 01AAC213
	.long 0xd7006a7d                                           // 0000001A9A5C: D7006A7D
	v_cndmask_b32_e32 v1, s14, v96, vcc_lo                     // 0000001A9A60: 0202C00E
	v_add_co_ci_u32_e64 v126, null, s15, v97, vcc_lo           // 0000001A9A64: D5207C7E 01AAC20F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9A6C: BF8700A3
	.long 0xd73c006b                                           // 0000001A9A70: D73C006B
	v_cndmask_b32_e32 v1, 3, v107, vcc_lo                      // 0000001A9A74: 0202D683
	.long 0xd7006a7f                                           // 0000001A9A78: D7006A7F
	v_cndmask_b32_e32 v1, s10, v96, vcc_lo                     // 0000001A9A7C: 0202C00A
	v_add_co_ci_u32_e64 v128, null, s11, v97, vcc_lo           // 0000001A9A80: D5207C80 01AAC20B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9A88: BF870214
	.long 0xd73c007d                                           // 0000001A9A8C: D73C007D
	v_cndmask_b32_e32 v1, 3, v125, vcc_lo                      // 0000001A9A90: 0202FA83
	.long 0xd7006a6b                                           // 0000001A9A94: D7006A6B
	v_cndmask_b32_e32 v1, s4, v107, vcc_lo                     // 0000001A9A98: 0202D604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9A9C: BF8700A1
	v_add_co_ci_u32_e64 v108, null, s5, v108, vcc_lo           // 0000001A9AA0: D5207C6C 01AAD805
	.long 0xd7006a81                                           // 0000001A9AA8: D7006A81
	v_cndmask_b32_e32 v1, s12, v96, vcc_lo                     // 0000001A9AAC: 0202C00C
	v_add_co_ci_u32_e64 v130, null, s13, v97, vcc_lo           // 0000001A9AB0: D5207C82 01AAC20D
	.long 0xd73c007f                                           // 0000001A9AB8: D73C007F
	v_cndmask_b32_e32 v1, 3, v127, vcc_lo                      // 0000001A9ABC: 0202FE83
	.long 0xd7006aa1                                           // 0000001A9AC0: D7006AA1
	v_cndmask_b32_e32 v1, s4, v125, vcc_lo                     // 0000001A9AC4: 0202FA04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9AC8: BF870211
	v_add_co_ci_u32_e64 v162, null, s5, v126, vcc_lo           // 0000001A9ACC: D5207CA2 01AAFC05
	.long 0xd73c007d                                           // 0000001A9AD4: D73C007D
	v_cndmask_b32_e32 v1, 3, v129, vcc_lo                      // 0000001A9AD8: 02030283
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9ADC: BF870094
	.long 0xd7006aa3                                           // 0000001A9AE0: D7006AA3
	v_cndmask_b32_e32 v1, s4, v127, vcc_lo                     // 0000001A9AE4: 0202FE04
	v_add_co_ci_u32_e64 v164, null, s5, v128, vcc_lo           // 0000001A9AE8: D5207CA4 01AB0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9AF0: BF870093
	.long 0xd7006abb                                           // 0000001A9AF4: D7006ABB
	v_cndmask_b32_e32 v1, s4, v125, vcc_lo                     // 0000001A9AF8: 0202FA04
	v_add_co_ci_u32_e64 v188, null, s5, v126, vcc_lo           // 0000001A9AFC: D5207CBC 01AAFC05
	ds_load_b128 v[117:120], v95                               // 0000001A9B04: DBFC0000 7500005F
	ds_load_b128 v[121:124], v95 offset:16                     // 0000001A9B0C: DBFC0010 7900005F
	s_clause 0x1f                                              // 0000001A9B14: BF85001F
	global_load_b64 v[125:126], v[107:108], off                // 0000001A9B18: DC560000 7D7C006B
	global_load_b64 v[133:134], v[107:108], off offset:128     // 0000001A9B20: DC560080 857C006B
	global_load_b64 v[141:142], v[107:108], off offset:256     // 0000001A9B28: DC560100 8D7C006B
	global_load_b64 v[149:150], v[107:108], off offset:384     // 0000001A9B30: DC560180 957C006B
	global_load_b64 v[127:128], v[161:162], off                // 0000001A9B38: DC560000 7F7C00A1
	global_load_b64 v[135:136], v[161:162], off offset:128     // 0000001A9B40: DC560080 877C00A1
	global_load_b64 v[143:144], v[161:162], off offset:256     // 0000001A9B48: DC560100 8F7C00A1
	global_load_b64 v[151:152], v[161:162], off offset:384     // 0000001A9B50: DC560180 977C00A1
	global_load_b64 v[129:130], v[163:164], off                // 0000001A9B58: DC560000 817C00A3
	global_load_b64 v[137:138], v[163:164], off offset:128     // 0000001A9B60: DC560080 897C00A3
	global_load_b64 v[145:146], v[163:164], off offset:256     // 0000001A9B68: DC560100 917C00A3
	global_load_b64 v[153:154], v[163:164], off offset:384     // 0000001A9B70: DC560180 997C00A3
	global_load_b64 v[131:132], v[187:188], off                // 0000001A9B78: DC560000 837C00BB
	global_load_b64 v[139:140], v[187:188], off offset:128     // 0000001A9B80: DC560080 8B7C00BB
	global_load_b64 v[147:148], v[187:188], off offset:256     // 0000001A9B88: DC560100 937C00BB
	global_load_b64 v[155:156], v[187:188], off offset:384     // 0000001A9B90: DC560180 9B7C00BB
	global_load_b64 v[157:158], v[107:108], off offset:512     // 0000001A9B98: DC560200 9D7C006B
	global_load_b64 v[165:166], v[107:108], off offset:640     // 0000001A9BA0: DC560280 A57C006B
	global_load_b64 v[173:174], v[107:108], off offset:768     // 0000001A9BA8: DC560300 AD7C006B
	global_load_b64 v[181:182], v[107:108], off offset:896     // 0000001A9BB0: DC560380 B57C006B
	global_load_b64 v[159:160], v[161:162], off offset:512     // 0000001A9BB8: DC560200 9F7C00A1
	global_load_b64 v[167:168], v[161:162], off offset:640     // 0000001A9BC0: DC560280 A77C00A1
	global_load_b64 v[175:176], v[161:162], off offset:768     // 0000001A9BC8: DC560300 AF7C00A1
	global_load_b64 v[183:184], v[161:162], off offset:896     // 0000001A9BD0: DC560380 B77C00A1
	global_load_b64 v[161:162], v[163:164], off offset:512     // 0000001A9BD8: DC560200 A17C00A3
	global_load_b64 v[169:170], v[163:164], off offset:640     // 0000001A9BE0: DC560280 A97C00A3
	global_load_b64 v[177:178], v[163:164], off offset:768     // 0000001A9BE8: DC560300 B17C00A3
	global_load_b64 v[185:186], v[163:164], off offset:896     // 0000001A9BF0: DC560380 B97C00A3
	global_load_b64 v[163:164], v[187:188], off offset:512     // 0000001A9BF8: DC560200 A37C00BB
	global_load_b64 v[171:172], v[187:188], off offset:640     // 0000001A9C00: DC560280 AB7C00BB
	global_load_b64 v[179:180], v[187:188], off offset:768     // 0000001A9C08: DC560300 B37C00BB
	global_load_b64 v[187:188], v[187:188], off offset:896     // 0000001A9C10: DC560380 BB7C00BB
	v_dual_fmac_f32 v87, v100, v110 :: v_dual_fmac_f32 v88, v101, v113// 0000001A9C18: C800DD64 5758E365
	v_dual_fmac_f32 v73, v102, v115 :: v_dual_fmac_f32 v74, v103, v85// 0000001A9C20: C800E766 494AAB67
	v_dual_fmac_f32 v84, v104, v114 :: v_dual_fmac_f32 v83, v106, v80// 0000001A9C28: C800E568 5452A16A
	v_dual_fmac_f32 v76, v105, v112 :: v_dual_mul_f32 v59, v59, v85// 0000001A9C30: C806E169 4C3AAB3B
	v_dual_mul_f32 v56, v56, v110 :: v_dual_mul_f32 v57, v57, v113// 0000001A9C38: C8C6DD38 3838E339
	v_dual_mul_f32 v58, v58, v115 :: v_dual_mul_f32 v61, v61, v112// 0000001A9C40: C8C6E73A 3A3CE13D
	v_dual_mul_f32 v60, v60, v114 :: v_dual_mul_f32 v63, v63, v81// 0000001A9C48: C8C6E53C 3C3EA33F
	v_dual_mul_f32 v62, v62, v80 :: v_dual_mul_f32 v49, v49, v113// 0000001A9C50: C8C6A13E 3E30E331
	v_dual_mul_f32 v48, v48, v110 :: v_dual_mul_f32 v51, v51, v85// 0000001A9C58: C8C6DD30 3032AB33
	v_dual_mul_f32 v50, v50, v115 :: v_dual_mul_f32 v53, v53, v112// 0000001A9C60: C8C6E732 3234E135
	v_dual_mul_f32 v52, v52, v114 :: v_dual_mul_f32 v55, v55, v81// 0000001A9C68: C8C6E534 3436A337
	v_dual_mul_f32 v54, v54, v80 :: v_dual_mul_f32 v41, v41, v113// 0000001A9C70: C8C6A136 3628E329
	v_dual_mul_f32 v40, v40, v110 :: v_dual_mul_f32 v43, v43, v85// 0000001A9C78: C8C6DD28 282AAB2B
	v_dual_mul_f32 v42, v42, v115 :: v_dual_mul_f32 v45, v45, v112// 0000001A9C80: C8C6E72A 2A2CE12D
	v_dual_mul_f32 v44, v44, v114 :: v_dual_mul_f32 v47, v47, v81// 0000001A9C88: C8C6E52C 2C2EA32F
	v_dual_mul_f32 v46, v46, v80 :: v_dual_mul_f32 v33, v33, v113// 0000001A9C90: C8C6A12E 2E20E321
	v_dual_mul_f32 v32, v32, v110 :: v_dual_mul_f32 v35, v35, v85// 0000001A9C98: C8C6DD20 2022AB23
	v_dual_mul_f32 v34, v34, v115 :: v_dual_mul_f32 v37, v37, v112// 0000001A9CA0: C8C6E722 2224E125
	v_dual_mul_f32 v36, v36, v114 :: v_dual_mul_f32 v39, v39, v81// 0000001A9CA8: C8C6E524 2426A327
	v_dual_mul_f32 v38, v38, v80 :: v_dual_mul_f32 v25, v25, v113// 0000001A9CB0: C8C6A126 2618E319
	v_dual_mul_f32 v24, v24, v110 :: v_dual_mul_f32 v27, v27, v85// 0000001A9CB8: C8C6DD18 181AAB1B
	v_dual_mul_f32 v26, v26, v115 :: v_dual_mul_f32 v29, v29, v112// 0000001A9CC0: C8C6E71A 1A1CE11D
	v_dual_mul_f32 v28, v28, v114 :: v_dual_mul_f32 v31, v31, v81// 0000001A9CC8: C8C6E51C 1C1EA31F
	v_dual_mul_f32 v30, v30, v80 :: v_dual_mul_f32 v17, v17, v113// 0000001A9CD0: C8C6A11E 1E10E311
	v_dual_mul_f32 v16, v16, v110 :: v_dual_mul_f32 v19, v19, v85// 0000001A9CD8: C8C6DD10 1012AB13
	v_dual_mul_f32 v18, v18, v115 :: v_dual_mul_f32 v21, v21, v112// 0000001A9CE0: C8C6E712 1214E115
	v_dual_mul_f32 v20, v20, v114 :: v_dual_mul_f32 v23, v23, v81// 0000001A9CE8: C8C6E514 1416A317
	v_dual_mul_f32 v22, v22, v80 :: v_dual_mul_f32 v9, v9, v113// 0000001A9CF0: C8C6A116 1608E309
	v_dual_mul_f32 v8, v8, v110 :: v_dual_mul_f32 v11, v11, v85// 0000001A9CF8: C8C6DD08 080AAB0B
	v_dual_mul_f32 v10, v10, v115 :: v_dual_mul_f32 v13, v13, v112// 0000001A9D00: C8C6E70A 0A0CE10D
	v_dual_mul_f32 v12, v12, v114 :: v_dual_mul_f32 v15, v15, v81// 0000001A9D08: C8C6E50C 0C0EA30F
	v_dual_mul_f32 v14, v14, v80 :: v_dual_mul_f32 v1, v1, v113// 0000001A9D10: C8C6A10E 0E00E301
	v_dual_mul_f32 v0, v0, v110 :: v_dual_mul_f32 v3, v3, v85  // 0000001A9D18: C8C6DD00 0002AB03
	v_dual_mul_f32 v2, v2, v115 :: v_dual_mul_f32 v5, v5, v112 // 0000001A9D20: C8C6E702 0204E105
	v_dual_mul_f32 v4, v4, v114 :: v_dual_mul_f32 v7, v7, v81  // 0000001A9D28: C8C6E504 0406A307
	v_dual_mul_f32 v6, v6, v80 :: v_dual_mov_b32 v113, v72     // 0000001A9D30: C8D0A106 06700148
	v_fma_f32 v99, v99, v81, v109                              // 0000001A9D38: D6130063 05B6A363
	v_dual_mov_b32 v115, v86 :: v_dual_mov_b32 v116, v111      // 0000001A9D40: CA100156 7374016F
	v_dual_mov_b32 v114, v75 :: v_dual_mov_b32 v109, v77       // 0000001A9D48: CA10014B 726C014D
	v_dual_mov_b32 v112, v82 :: v_dual_mov_b32 v107, v79       // 0000001A9D50: CA100152 706A014F
	v_dual_mov_b32 v108, v78 :: v_dual_mov_b32 v101, v88       // 0000001A9D58: CA10014E 6C640158
	v_dual_mov_b32 v100, v87 :: v_dual_mov_b32 v103, v74       // 0000001A9D60: CA100157 6466014A
	v_dual_mov_b32 v102, v73 :: v_dual_mov_b32 v105, v76       // 0000001A9D68: CA100149 6668014C
	v_mov_b32_e32 v104, v84                                    // 0000001A9D70: 7ED00354
	v_mov_b32_e32 v106, v83                                    // 0000001A9D74: 7ED40353
	s_add_i32 s3, s3, -16                                      // 0000001A9D78: 8103D003
	s_add_i32 s17, s17, 16                                     // 0000001A9D7C: 81119011
	s_cmp_lg_u32 s1, s20                                       // 0000001A9D80: BF071401
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001A9D84: BF894C07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[117:124], v[125:132], v[56:63]// 0000001A9D88: CC414038 1CE2FB75
	s_waitcnt vmcnt(18)                                        // 0000001A9D90: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[48:55], v[117:124], v[133:140], v[48:55]// 0000001A9D94: CC414030 1CC30B75
	s_waitcnt vmcnt(17)                                        // 0000001A9D9C: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[40:47], v[117:124], v[141:148], v[40:47]// 0000001A9DA0: CC414028 1CA31B75
	s_waitcnt vmcnt(16)                                        // 0000001A9DA8: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[32:39], v[117:124], v[149:156], v[32:39]// 0000001A9DAC: CC414020 1C832B75
	s_waitcnt vmcnt(3)                                         // 0000001A9DB4: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[24:31], v[117:124], v[157:164], v[24:31]// 0000001A9DB8: CC414018 1C633B75
	s_waitcnt vmcnt(2)                                         // 0000001A9DC0: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[16:23], v[117:124], v[165:172], v[16:23]// 0000001A9DC4: CC414010 1C434B75
	s_waitcnt vmcnt(1)                                         // 0000001A9DCC: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[8:15], v[117:124], v[173:180], v[8:15]// 0000001A9DD0: CC414008 1C235B75
	s_waitcnt vmcnt(0)                                         // 0000001A9DD8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[0:7], v[117:124], v[181:188], v[0:7]// 0000001A9DDC: CC414000 1C036B75
	s_barrier                                                  // 0000001A9DE4: BFBD0000
	buffer_gl0_inv                                             // 0000001A9DE8: E0AC0000 00000000
	s_cbranch_scc0 991                                         // 0000001A9DF0: BFA103DF <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1970>
	s_mov_b32 s0, s20                                          // 0000001A9DF4: BE800014
	s_add_i32 s20, s20, 1                                      // 0000001A9DF8: 81148114
	s_and_b32 s11, s0, 7                                       // 0000001A9DFC: 8B0B8700
	s_add_i32 s10, s0, 3                                       // 0000001A9E00: 810A8300
	s_xor_b32 s11, s11, 0x3f84                                 // 0000001A9E04: 8D0BFF0B 00003F84
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A9E0C: BF870009
	v_dual_mov_b32 v72, s17 :: v_dual_mov_b32 v119, s11        // 0000001A9E10: CA100011 4876000B
	ds_load_b128 v[80:83], v98                                 // 0000001A9E18: DBFC0000 50000062
	ds_load_b128 v[84:87], v98 offset:16                       // 0000001A9E20: DBFC0010 54000062
	ds_load_b128 v[138:141], v98 offset:32                     // 0000001A9E28: DBFC0020 8A000062
	ds_load_b128 v[142:145], v98 offset:48                     // 0000001A9E30: DBFC0030 8E000062
	ds_load_b128 v[150:153], v98 offset:80                     // 0000001A9E38: DBFC0050 96000062
	ds_load_b128 v[146:149], v98 offset:64                     // 0000001A9E40: DBFC0040 92000062
	ds_load_b128 v[158:161], v98 offset:112                    // 0000001A9E48: DBFC0070 9E000062
	ds_load_b128 v[154:157], v98 offset:96                     // 0000001A9E50: DBFC0060 9A000062
	ds_load_b128 v[166:169], v98 offset:144                    // 0000001A9E58: DBFC0090 A6000062
	ds_load_b128 v[162:165], v98 offset:128                    // 0000001A9E60: DBFC0080 A2000062
	ds_load_b128 v[174:177], v98 offset:176                    // 0000001A9E68: DBFC00B0 AE000062
	ds_load_b128 v[170:173], v98 offset:160                    // 0000001A9E70: DBFC00A0 AA000062
	ds_load_b128 v[182:185], v98 offset:208                    // 0000001A9E78: DBFC00D0 B6000062
	ds_load_b128 v[178:181], v98 offset:192                    // 0000001A9E80: DBFC00C0 B2000062
	ds_load_b128 v[190:193], v98 offset:240                    // 0000001A9E88: DBFC00F0 BE000062
	ds_load_b128 v[186:189], v98 offset:224                    // 0000001A9E90: DBFC00E0 BA000062
	ds_load_b128 v[194:197], v72 offset:1024                   // 0000001A9E98: DBFC0400 C2000048
	.long 0xcc0a4048                                           // 0000001A9EA0: CC0A4048
	v_mul_i32_i24_e32 v0, s0, v135                             // 0000001A9EA4: 12010E00
	.long 0xcc0a4049                                           // 0000001A9EA8: CC0A4049
	v_subrev_f32_e32 v0, 0x60005, v0                           // 0000001A9EAC: 0A0000FF 00060005
	.long 0xcc0b504a                                           // 0000001A9EB4: CC0B504A
	v_cndmask_b32_e32 v0, s0, v194, vcc_lo                     // 0000001A9EB8: 02018400
	s_and_b32 s0, s20, 7                                       // 0000001A9EBC: 8B008714
	s_and_b32 s10, s10, 7                                      // 0000001A9EC0: 8B0A870A
	s_or_b32 s0, s0, 0x3f80                                    // 0000001A9EC4: 8C00FF00 00003F80
	s_or_b32 s10, s10, 0x3f80                                  // 0000001A9ECC: 8C0AFF0A 00003F80
	v_dual_mov_b32 v127, s0 :: v_dual_and_b32 v72, 0x70007, v72// 0000001A9ED4: CA240000 7F4890FF 00070007
	s_pack_ll_b32_b16 s0, s10, s11                             // 0000001A9EE0: 99000B0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9EE4: BF870119
	v_dual_mov_b32 v128, s0 :: v_dual_and_b32 v73, 0x70007, v73// 0000001A9EE8: CA240000 804892FF 00070007
	v_or_b32_e32 v130, 0x3f803f80, v72                         // 0000001A9EF4: 390490FF 3F803F80
	.long 0x7fec380a                                           // 0000001A9EFC: 7FEC380A
	.long 0x7fea397f                                           // 0000001A9F00: 7FEA397F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A9F04: BF870004
	v_or_b32_e32 v129, 0x3f803f80, v73                         // 0000001A9F08: 390292FF 3F803F80
	v_and_b32_e32 v74, 0x70007, v74                            // 0000001A9F10: 369494FF 00070007
	.long 0xd59c4078                                           // 0000001A9F18: D59C4078
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 0000001A9F1C: 02010182
	.long 0xd59c0875                                           // 0000001A9F20: D59C0875
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 0000001A9F24: 02010182
	.long 0xd59c0879                                           // 0000001A9F28: D59C0879
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 0000001A9F2C: 02010182
	v_mov_b32_e32 v133, v129                                   // 0000001A9F30: 7F0A0381
	v_or_b32_e32 v131, 0x3f803f80, v74                         // 0000001A9F34: 390694FF 3F803F80
	.long 0xd59c0878                                           // 0000001A9F3C: D59C0878
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                   // 0000001A9F40: 02010181
	.long 0xd59c4077                                           // 0000001A9F44: D59C4077
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                   // 0000001A9F48: 02010181
	v_mov_b32_e32 v132, s0                                     // 0000001A9F4C: 7F080200
	v_dual_mov_b32 v134, v130 :: v_dual_mov_b32 v137, v129     // 0000001A9F50: CA100182 86880181
	.long 0xd59c0876                                           // 0000001A9F58: D59C0876
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                   // 0000001A9F5C: 02010183
	.long 0xd59c4079                                           // 0000001A9F60: D59C4079
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                   // 0000001A9F64: 02010183
	v_dual_mov_b32 v123, v119 :: v_dual_mov_b32 v124, v120     // 0000001A9F68: CA100177 7B7C0178
	.long 0xd59c487f                                           // 0000001A9F70: D59C487F
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                   // 0000001A9F74: 02010183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A9F78: BF8701C3
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v125, v121     // 0000001A9F7C: CA100176 7A7C0179
	v_dual_mov_b32 v136, s0 :: v_dual_mov_b32 v135, v131       // 0000001A9F84: CA100000 88860183
	v_mov_b32_e32 v126, v118                                   // 0000001A9F8C: 7EFC0376
	s_waitcnt lgkmcnt(15)                                      // 0000001A9F90: BF89FCF7
	v_wmma_f32_16x16x16_bf16 v[72:79], v[80:87], v[117:124], v[64:71]// 0000001A9F94: CC414048 1D02EB50
	v_cmp_gt_i32_e32 vcc_lo, s3, v89                           // 0000001A9F9C: 7C88B203
	s_waitcnt lgkmcnt(0)                                       // 0000001A9FA0: BF89FC07
	v_readfirstlane_b32 s18, v194                              // 0000001A9FA4: 7E2405C2
	v_readfirstlane_b32 s14, v195                              // 0000001A9FA8: 7E1C05C3
	v_wmma_f32_16x16x16_bf16 v[72:79], v[138:145], v[127:134], v[72:79]// 0000001A9FAC: CC414048 1D22FF8A
	v_mov_b32_e32 v127, v119                                   // 0000001A9FB4: 7EFE0377
	v_readfirstlane_b32 s10, v196                              // 0000001A9FB8: 7E1405C4
	v_readfirstlane_b32 s12, v197                              // 0000001A9FBC: 7E1805C5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9FC0: BF870094
	v_wmma_f32_16x16x16_bf16 v[72:79], v[146:153], v[118:125], v[72:79]// 0000001A9FC4: CC414048 1D22ED92
	v_wmma_f32_16x16x16_bf16 v[72:79], v[154:161], v[128:135], v[72:79]// 0000001A9FCC: CC414048 1D23019A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9FD4: BF870091
	v_wmma_f32_16x16x16_bf16 v[72:79], v[162:169], v[119:126], v[72:79]// 0000001A9FD8: CC414048 1D22EFA2
	v_wmma_f32_16x16x16_bf16 v[72:79], v[170:177], v[129:136], v[72:79]// 0000001A9FE0: CC414048 1D2303AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9FE8: BF870091
	v_wmma_f32_16x16x16_bf16 v[72:79], v[178:185], v[120:127], v[72:79]// 0000001A9FEC: CC414048 1D22F1B2
	v_wmma_f32_16x16x16_bf16 v[72:79], v[186:193], v[130:137], v[72:79]// 0000001A9FF4: CC414048 1D2305BA
	ds_store_2addr_b32 v93, v72, v73 offset1:32                // 0000001A9FFC: D8382000 0049485D
	ds_store_2addr_b32 v93, v74, v75 offset0:64 offset1:96     // 0000001AA004: D8386040 004B4A5D
	ds_store_2addr_b32 v93, v76, v77 offset0:128 offset1:160   // 0000001AA00C: D838A080 004D4C5D
	ds_store_2addr_b32 v93, v78, v79 offset0:192 offset1:224   // 0000001AA014: D838E0C0 004F4E5D
	s_waitcnt lgkmcnt(0)                                       // 0000001AA01C: BF89FC07
	s_barrier                                                  // 0000001AA020: BFBD0000
	buffer_gl0_inv                                             // 0000001AA024: E0AC0000 00000000
	ds_load_2addr_b32 v[85:86], v94 offset1:32                 // 0000001AA02C: D8DC2000 5500005E
	s_waitcnt lgkmcnt(0)                                       // 0000001AA034: BF89FC07
	v_add_f32_e32 v72, v72, v85                                // 0000001AA038: 0690AB48
	ds_load_2addr_b32 v[84:85], v94 offset0:64 offset1:96      // 0000001AA03C: D8DC6040 5400005E
	ds_load_2addr_b32 v[82:83], v94 offset0:128 offset1:160    // 0000001AA044: D8DCA080 5200005E
	v_mul_f32_e32 v88, 0x3d800000, v72                         // 0000001AA04C: 10B090FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA054: BF870091
	v_cndmask_b32_e32 v72, 0xf149f2ca, v88, vcc_lo             // 0000001AA058: 0290B0FF F149F2CA
	v_mov_b32_dpp v80, v72 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA060: 7EA002FA FF096148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA068: BF870091
	v_max_f32_e32 v80, v80, v80                                // 0000001AA06C: 20A0A150
	v_max_f32_e32 v72, v72, v80                                // 0000001AA070: 2090A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA074: BF870091
	v_mov_b32_dpp v80, v72 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA078: 7EA002FA FF096248
	v_max_f32_e32 v80, v80, v80                                // 0000001AA080: 20A0A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA084: BF870091
	v_max_f32_e32 v72, v72, v80                                // 0000001AA088: 2090A148
	v_mov_b32_dpp v80, v72 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA08C: 7EA002FA FF096448
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AA094: BF8700B1
	v_max_f32_e32 v87, v80, v80                                // 0000001AA098: 20AEA150
	ds_load_2addr_b32 v[80:81], v94 offset0:192 offset1:224    // 0000001AA09C: D8DCE0C0 5000005E
	v_max_f32_e32 v72, v72, v87                                // 0000001AA0A4: 2090AF48
	v_mov_b32_dpp v87, v72 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA0A8: 7EAE02FA FF096848
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA0B0: BF870001
	v_max3_f32 v72, v113, v72, v87                             // 0000001AA0B4: D61C0048 055E9171
	v_mov_b32_e32 v87, 0                                       // 0000001AA0BC: 7EAE0280
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA0C0: BE8B206A
	s_cbranch_execz 31                                         // 0000001AA0C4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd44>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA0C8: BF870092
	v_sub_f32_e32 v87, v88, v72                                // 0000001AA0CC: 08AE9158
	v_mul_f32_e32 v88, 0x3fb8aa3b, v87                         // 0000001AA0D0: 10B0AEFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA0D8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v87, vcc_lo              // 0000001AA0DC: 0202AEFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA0E4: BF870122
	v_fma_f32 v110, 0x3fb8aa3b, v87, -v88                      // 0000001AA0E8: D613006E 8562AEFF 3FB8AA3B
	v_rndne_f32_e32 v111, v88                                  // 0000001AA0F4: 7EDE4758
	v_fmac_f32_e32 v110, 0x32a5705f, v87                       // 0000001AA0F8: 56DCAEFF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA100: BF870092
	v_sub_f32_e32 v88, v88, v111                               // 0000001AA104: 08B0DF58
	v_add_f32_e32 v88, v88, v110                               // 0000001AA108: 06B0DD58
	v_cvt_i32_f32_e32 v110, v111                               // 0000001AA10C: 7EDC116F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA110: BF870292
	v_exp_f32_e32 v88, v88                                     // 0000001AA114: 7EB04B58
	.long 0xd71c0058                                           // 0000001AA118: D71C0058
	v_cndmask_b32_e32 v1, v88, v110, vcc_lo                    // 0000001AA11C: 0202DD58
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AA120: BF8700A1
	v_cndmask_b32_e64 v88, 0, v88, s0                          // 0000001AA124: D5010058 0002B080
	.long 0xd41e0000                                           // 0000001AA12C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v87, vcc_lo              // 0000001AA130: 0202AEFF 42B17218
	v_cndmask_b32_e64 v87, 0x7f800000, v88, s0                 // 0000001AA138: D5010057 0002B0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA144: 8C7E0B7E
	v_mov_b32_e32 v88, 0                                       // 0000001AA148: 7EB00280
	v_mov_b32_e32 v110, 0                                      // 0000001AA14C: 7EDC0280
	s_mov_b32 s11, exec_lo                                     // 0000001AA150: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v113                         // 0000001AA154: 7D22E2FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AA15C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xddc>
	v_sub_f32_e32 v110, v113, v72                              // 0000001AA160: 08DC9171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA164: BF870091
	v_mul_f32_e32 v111, 0x3fb8aa3b, v110                       // 0000001AA168: 10DEDCFF 3FB8AA3B
	v_fma_f32 v113, 0x3fb8aa3b, v110, -v111                    // 0000001AA170: D6130071 85BEDCFF 3FB8AA3B
	v_rndne_f32_e32 v117, v111                                 // 0000001AA17C: 7EEA476F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA180: BF870191
	v_sub_f32_e32 v111, v111, v117                             // 0000001AA184: 08DEEB6F
	v_fmac_f32_e32 v113, 0x32a5705f, v110                      // 0000001AA188: 56E2DCFF 32A5705F
	.long 0xd41b0000                                           // 0000001AA190: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v110, vcc_lo             // 0000001AA194: 0202DCFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA19C: BF870122
	v_add_f32_e32 v111, v111, v113                             // 0000001AA1A0: 06DEE36F
	v_cvt_i32_f32_e32 v113, v117                               // 0000001AA1A4: 7EE21175
	v_exp_f32_e32 v111, v111                                   // 0000001AA1A8: 7EDE4B6F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA1AC: BF870095
	.long 0xd71c006f                                           // 0000001AA1B0: D71C006F
	v_cndmask_b32_e32 v1, v111, v113, vcc_lo                   // 0000001AA1B4: 0202E36F
	v_cndmask_b32_e64 v111, 0, v111, s0                        // 0000001AA1B8: D501006F 0002DE80
	.long 0xd41e0000                                           // 0000001AA1C0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v110, vcc_lo             // 0000001AA1C4: 0202DCFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA1CC: BF870001
	v_cndmask_b32_e64 v110, 0x7f800000, v111, s0               // 0000001AA1D0: D501006E 0002DEFF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA1DC: 8C7E0B7E
	v_add_f32_e32 v73, v73, v86                                // 0000001AA1E0: 0692AD49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA1E4: BF870091
	v_mul_f32_e32 v73, 0x3d800000, v73                         // 0000001AA1E8: 109292FF 3D800000
	v_cndmask_b32_e32 v86, 0xf149f2ca, v73, vcc_lo             // 0000001AA1F0: 02AC92FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA1F8: BF870091
	v_mov_b32_dpp v111, v86 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA1FC: 7EDE02FA FF096156
	v_max_f32_e32 v111, v111, v111                             // 0000001AA204: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA208: BF870091
	v_max_f32_e32 v86, v86, v111                               // 0000001AA20C: 20ACDF56
	v_mov_b32_dpp v111, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA210: 7EDE02FA FF096256
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA218: BF870091
	v_max_f32_e32 v111, v111, v111                             // 0000001AA21C: 20DEDF6F
	v_max_f32_e32 v86, v86, v111                               // 0000001AA220: 20ACDF56
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA224: BF870091
	v_mov_b32_dpp v111, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA228: 7EDE02FA FF096456
	v_max_f32_e32 v111, v111, v111                             // 0000001AA230: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA234: BF870121
	v_max_f32_e32 v86, v86, v111                               // 0000001AA238: 20ACDF56
	v_bfe_u32 v111, v87, 16, 1                                 // 0000001AA23C: D610006F 02052157
	v_mov_b32_dpp v113, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA244: 7EE202FA FF096856
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA24C: BF870112
	v_add3_u32 v111, v87, v111, 0x7fff                         // 0000001AA250: D655006F 03FEDF57 00007FFF
	v_max3_f32 v86, v115, v86, v113                            // 0000001AA25C: D61C0056 05C6AD73
	ds_store_b16_d16_hi v92, v111                              // 0000001AA264: DA840000 00006F5C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA26C: BE8B206A
	s_cbranch_execz 31                                         // 0000001AA270: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xef0>
	v_sub_f32_e32 v73, v73, v86                                // 0000001AA274: 0892AD49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA278: BF870091
	v_mul_f32_e32 v88, 0x3fb8aa3b, v73                         // 0000001AA27C: 10B092FF 3FB8AA3B
	v_fma_f32 v111, 0x3fb8aa3b, v73, -v88                      // 0000001AA284: D613006F 856292FF 3FB8AA3B
	v_rndne_f32_e32 v113, v88                                  // 0000001AA290: 7EE24758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA294: BF870191
	v_sub_f32_e32 v88, v88, v113                               // 0000001AA298: 08B0E358
	v_fmac_f32_e32 v111, 0x32a5705f, v73                       // 0000001AA29C: 56DE92FF 32A5705F
	.long 0xd41b0000                                           // 0000001AA2A4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 0000001AA2A8: 020292FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA2B0: BF870122
	v_add_f32_e32 v88, v88, v111                               // 0000001AA2B4: 06B0DF58
	v_cvt_i32_f32_e32 v111, v113                               // 0000001AA2B8: 7EDE1171
	v_exp_f32_e32 v88, v88                                     // 0000001AA2BC: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA2C0: BF870095
	.long 0xd71c0058                                           // 0000001AA2C4: D71C0058
	v_cndmask_b32_e32 v1, v88, v111, vcc_lo                    // 0000001AA2C8: 0202DF58
	v_cndmask_b32_e64 v88, 0, v88, s0                          // 0000001AA2CC: D5010058 0002B080
	.long 0xd41e0000                                           // 0000001AA2D4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001AA2D8: 020292FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA2E0: BF870001
	v_cndmask_b32_e64 v88, 0x7f800000, v88, s0                 // 0000001AA2E4: D5010058 0002B0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA2F0: 8C7E0B7E
	v_mov_b32_e32 v73, 0                                       // 0000001AA2F4: 7E920280
	v_mov_b32_e32 v113, 0                                      // 0000001AA2F8: 7EE20280
	s_mov_b32 s11, exec_lo                                     // 0000001AA2FC: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v115                         // 0000001AA300: 7D22E6FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AA308: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xf88>
	v_sub_f32_e32 v111, v115, v86                              // 0000001AA30C: 08DEAD73
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA310: BF870121
	v_mul_f32_e32 v113, 0x3fb8aa3b, v111                       // 0000001AA314: 10E2DEFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA31C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v111, vcc_lo             // 0000001AA320: 0202DEFF C2CE8ED0
	v_fma_f32 v115, 0x3fb8aa3b, v111, -v113                    // 0000001AA328: D6130073 85C6DEFF 3FB8AA3B
	v_rndne_f32_e32 v117, v113                                 // 0000001AA334: 7EEA4771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA338: BF870112
	v_fmac_f32_e32 v115, 0x32a5705f, v111                      // 0000001AA33C: 56E6DEFF 32A5705F
	v_sub_f32_e32 v113, v113, v117                             // 0000001AA344: 08E2EB71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA348: BF870121
	v_add_f32_e32 v113, v113, v115                             // 0000001AA34C: 06E2E771
	v_cvt_i32_f32_e32 v115, v117                               // 0000001AA350: 7EE61175
	v_exp_f32_e32 v113, v113                                   // 0000001AA354: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA358: BF870095
	.long 0xd71c0071                                           // 0000001AA35C: D71C0071
	v_cndmask_b32_e32 v1, v113, v115, vcc_lo                   // 0000001AA360: 0202E771
	v_cndmask_b32_e64 v113, 0, v113, s0                        // 0000001AA364: D5010071 0002E280
	.long 0xd41e0000                                           // 0000001AA36C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v111, vcc_lo             // 0000001AA370: 0202DEFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA378: BF870001
	v_cndmask_b32_e64 v113, 0x7f800000, v113, s0               // 0000001AA37C: D5010071 0002E2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA388: 8C7E0B7E
	s_waitcnt lgkmcnt(3)                                       // 0000001AA38C: BF89FC37
	v_add_f32_e32 v74, v74, v84                                // 0000001AA390: 0694A94A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA394: BF870091
	v_mul_f32_e32 v74, 0x3d800000, v74                         // 0000001AA398: 109494FF 3D800000
	v_cndmask_b32_e32 v84, 0xf149f2ca, v74, vcc_lo             // 0000001AA3A0: 02A894FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA3A8: BF870091
	v_mov_b32_dpp v111, v84 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA3AC: 7EDE02FA FF096154
	v_max_f32_e32 v111, v111, v111                             // 0000001AA3B4: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA3B8: BF870091
	v_max_f32_e32 v84, v84, v111                               // 0000001AA3BC: 20A8DF54
	v_mov_b32_dpp v111, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA3C0: 7EDE02FA FF096254
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA3C8: BF870091
	v_max_f32_e32 v111, v111, v111                             // 0000001AA3CC: 20DEDF6F
	v_max_f32_e32 v84, v84, v111                               // 0000001AA3D0: 20A8DF54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA3D4: BF870091
	v_mov_b32_dpp v111, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA3D8: 7EDE02FA FF096454
	v_max_f32_e32 v111, v111, v111                             // 0000001AA3E0: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA3E4: BF870121
	v_max_f32_e32 v84, v84, v111                               // 0000001AA3E8: 20A8DF54
	v_bfe_u32 v111, v88, 16, 1                                 // 0000001AA3EC: D610006F 02052158
	v_mov_b32_dpp v115, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA3F4: 7EE602FA FF096854
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA3FC: BF870112
	v_add3_u32 v117, v88, v111, 0x7fff                         // 0000001AA400: D6550075 03FEDF58 00007FFF
	v_max3_f32 v111, v116, v84, v115                           // 0000001AA40C: D61C006F 05CEA974
	ds_store_b16_d16_hi v92, v117 offset:64                    // 0000001AA414: DA840040 0000755C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA41C: BE8B206A
	s_cbranch_execz 31                                         // 0000001AA420: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x10a0>
	v_sub_f32_e32 v73, v74, v111                               // 0000001AA424: 0892DF4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA428: BF870121
	v_mul_f32_e32 v74, 0x3fb8aa3b, v73                         // 0000001AA42C: 109492FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA434: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 0000001AA438: 020292FF C2CE8ED0
	v_fma_f32 v84, 0x3fb8aa3b, v73, -v74                       // 0000001AA440: D6130054 852A92FF 3FB8AA3B
	v_rndne_f32_e32 v115, v74                                  // 0000001AA44C: 7EE6474A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA450: BF870112
	v_fmac_f32_e32 v84, 0x32a5705f, v73                        // 0000001AA454: 56A892FF 32A5705F
	v_sub_f32_e32 v74, v74, v115                               // 0000001AA45C: 0894E74A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA460: BF870121
	v_add_f32_e32 v74, v74, v84                                // 0000001AA464: 0694A94A
	v_cvt_i32_f32_e32 v84, v115                                // 0000001AA468: 7EA81173
	v_exp_f32_e32 v74, v74                                     // 0000001AA46C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA470: BF870095
	.long 0xd71c004a                                           // 0000001AA474: D71C004A
	v_cndmask_b32_e32 v1, v74, v84, vcc_lo                     // 0000001AA478: 0202A94A
	v_cndmask_b32_e64 v74, 0, v74, s0                          // 0000001AA47C: D501004A 00029480
	.long 0xd41e0000                                           // 0000001AA484: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001AA488: 020292FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA490: BF870001
	v_cndmask_b32_e64 v73, 0x7f800000, v74, s0                 // 0000001AA494: D5010049 000294FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA4A0: 8C7E0B7E
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v115, 0            // 0000001AA4A4: CA100080 4A720080
	s_mov_b32 s11, exec_lo                                     // 0000001AA4AC: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v116                         // 0000001AA4B0: 7D22E8FF EFA18F08
	s_cbranch_execz 30                                         // 0000001AA4B8: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1134>
	v_sub_f32_e32 v84, v116, v111                              // 0000001AA4BC: 08A8DF74
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA4C0: BF870091
	v_mul_f32_e32 v115, 0x3fb8aa3b, v84                        // 0000001AA4C4: 10E6A8FF 3FB8AA3B
	v_fma_f32 v116, 0x3fb8aa3b, v84, -v115                     // 0000001AA4CC: D6130074 85CEA8FF 3FB8AA3B
	v_rndne_f32_e32 v117, v115                                 // 0000001AA4D8: 7EEA4773
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA4DC: BF870121
	v_dual_sub_f32 v115, v115, v117 :: v_dual_fmac_f32 v116, 0x32a5705f, v84// 0000001AA4E0: C940EB73 7374A8FF 32A5705F
	.long 0xd41b0000                                           // 0000001AA4EC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v84, vcc_lo              // 0000001AA4F0: 0202A8FF C2CE8ED0
	v_add_f32_e32 v115, v115, v116                             // 0000001AA4F8: 06E6E973
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AA4FC: 7EE81175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA500: BF870292
	v_exp_f32_e32 v115, v115                                   // 0000001AA504: 7EE64B73
	.long 0xd71c0073                                           // 0000001AA508: D71C0073
	v_cndmask_b32_e32 v1, v115, v116, vcc_lo                   // 0000001AA50C: 0202E973
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AA510: BF8700A1
	v_cndmask_b32_e64 v115, 0, v115, s0                        // 0000001AA514: D5010073 0002E680
	.long 0xd41e0000                                           // 0000001AA51C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v84, vcc_lo              // 0000001AA520: 0202A8FF 42B17218
	v_cndmask_b32_e64 v115, 0x7f800000, v115, s0               // 0000001AA528: D5010073 0002E6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA534: 8C7E0B7E
	v_add_f32_e32 v75, v75, v85                                // 0000001AA538: 0696AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA53C: BF870091
	v_mul_f32_e32 v84, 0x3d800000, v75                         // 0000001AA540: 10A896FF 3D800000
	v_cndmask_b32_e32 v75, 0xf149f2ca, v84, vcc_lo             // 0000001AA548: 0296A8FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA550: BF870091
	v_mov_b32_dpp v85, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA554: 7EAA02FA FF09614B
	v_max_f32_e32 v85, v85, v85                                // 0000001AA55C: 20AAAB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA560: BF870091
	v_max_f32_e32 v75, v75, v85                                // 0000001AA564: 2096AB4B
	v_mov_b32_dpp v85, v75 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA568: 7EAA02FA FF09624B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA570: BF870091
	v_max_f32_e32 v85, v85, v85                                // 0000001AA574: 20AAAB55
	v_max_f32_e32 v75, v75, v85                                // 0000001AA578: 2096AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA57C: BF870091
	v_mov_b32_dpp v85, v75 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA580: 7EAA02FA FF09644B
	v_max_f32_e32 v85, v85, v85                                // 0000001AA588: 20AAAB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA58C: BF870121
	v_max_f32_e32 v75, v75, v85                                // 0000001AA590: 2096AB4B
	v_bfe_u32 v85, v73, 16, 1                                  // 0000001AA594: D6100055 02052149
	v_mov_b32_dpp v116, v75 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA59C: 7EE802FA FF09684B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA5A4: BF870112
	v_add3_u32 v85, v73, v85, 0x7fff                           // 0000001AA5A8: D6550055 03FEAB49 00007FFF
	v_max3_f32 v75, v114, v75, v116                            // 0000001AA5B4: D61C004B 05D29772
	ds_store_b16_d16_hi v92, v85 offset:128                    // 0000001AA5BC: DA840080 0000555C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA5C4: BE8B206A
	s_cbranch_execz 30                                         // 0000001AA5C8: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1244>
	v_sub_f32_e32 v74, v84, v75                                // 0000001AA5CC: 08949754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA5D0: BF870121
	v_mul_f32_e32 v84, 0x3fb8aa3b, v74                         // 0000001AA5D4: 10A894FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA5DC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001AA5E0: 020294FF C2CE8ED0
	v_fma_f32 v85, 0x3fb8aa3b, v74, -v84                       // 0000001AA5E8: D6130055 855294FF 3FB8AA3B
	v_rndne_f32_e32 v116, v84                                  // 0000001AA5F4: 7EE84754
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA5F8: BF870091
	v_dual_fmac_f32 v85, 0x32a5705f, v74 :: v_dual_sub_f32 v84, v84, v116// 0000001AA5FC: C80A94FF 5554E954 32A5705F
	v_add_f32_e32 v84, v84, v85                                // 0000001AA608: 06A8AB54
	v_cvt_i32_f32_e32 v85, v116                                // 0000001AA60C: 7EAA1174
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA610: BF870292
	v_exp_f32_e32 v84, v84                                     // 0000001AA614: 7EA84B54
	.long 0xd71c0054                                           // 0000001AA618: D71C0054
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                     // 0000001AA61C: 0202AB54
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AA620: BF8700A1
	v_cndmask_b32_e64 v84, 0, v84, s0                          // 0000001AA624: D5010054 0002A880
	.long 0xd41e0000                                           // 0000001AA62C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001AA630: 020294FF 42B17218
	v_cndmask_b32_e64 v74, 0x7f800000, v84, s0                 // 0000001AA638: D501004A 0002A8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA644: 8C7E0B7E
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v85, 0             // 0000001AA648: CA100080 54540080
	s_mov_b32 s11, exec_lo                                     // 0000001AA650: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v114                         // 0000001AA654: 7D22E4FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AA65C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x12dc>
	v_sub_f32_e32 v85, v114, v75                               // 0000001AA660: 08AA9772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA664: BF870121
	v_mul_f32_e32 v114, 0x3fb8aa3b, v85                        // 0000001AA668: 10E4AAFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA670: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v85, vcc_lo              // 0000001AA674: 0202AAFF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v85, -v114                     // 0000001AA67C: D6130074 85CAAAFF 3FB8AA3B
	v_rndne_f32_e32 v117, v114                                 // 0000001AA688: 7EEA4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA68C: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v85                       // 0000001AA690: 56E8AAFF 32A5705F
	v_sub_f32_e32 v114, v114, v117                             // 0000001AA698: 08E4EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA69C: BF870121
	v_add_f32_e32 v114, v114, v116                             // 0000001AA6A0: 06E4E972
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AA6A4: 7EE81175
	v_exp_f32_e32 v114, v114                                   // 0000001AA6A8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA6AC: BF870095
	.long 0xd71c0072                                           // 0000001AA6B0: D71C0072
	v_cndmask_b32_e32 v1, v114, v116, vcc_lo                   // 0000001AA6B4: 0202E972
	v_cndmask_b32_e64 v114, 0, v114, s0                        // 0000001AA6B8: D5010072 0002E480
	.long 0xd41e0000                                           // 0000001AA6C0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v85, vcc_lo              // 0000001AA6C4: 0202AAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA6CC: BF870001
	v_cndmask_b32_e64 v85, 0x7f800000, v114, s0                // 0000001AA6D0: D5010055 0002E4FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA6DC: 8C7E0B7E
	s_waitcnt lgkmcnt(4)                                       // 0000001AA6E0: BF89FC47
	v_add_f32_e32 v76, v76, v82                                // 0000001AA6E4: 0698A54C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA6E8: BF870091
	v_mul_f32_e32 v76, 0x3d800000, v76                         // 0000001AA6EC: 109898FF 3D800000
	v_cndmask_b32_e32 v82, 0xf149f2ca, v76, vcc_lo             // 0000001AA6F4: 02A498FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA6FC: BF870091
	v_mov_b32_dpp v114, v82 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA700: 7EE402FA FF096152
	v_max_f32_e32 v114, v114, v114                             // 0000001AA708: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA70C: BF870091
	v_max_f32_e32 v82, v82, v114                               // 0000001AA710: 20A4E552
	v_mov_b32_dpp v114, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA714: 7EE402FA FF096252
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA71C: BF870091
	v_max_f32_e32 v114, v114, v114                             // 0000001AA720: 20E4E572
	v_max_f32_e32 v82, v82, v114                               // 0000001AA724: 20A4E552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA728: BF870091
	v_mov_b32_dpp v114, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA72C: 7EE402FA FF096452
	v_max_f32_e32 v114, v114, v114                             // 0000001AA734: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA738: BF870121
	v_max_f32_e32 v82, v82, v114                               // 0000001AA73C: 20A4E552
	v_bfe_u32 v114, v74, 16, 1                                 // 0000001AA740: D6100072 0205214A
	v_mov_b32_dpp v116, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA748: 7EE802FA FF096852
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA750: BF870112
	v_add3_u32 v114, v74, v114, 0x7fff                         // 0000001AA754: D6550072 03FEE54A 00007FFF
	v_max3_f32 v82, v112, v82, v116                            // 0000001AA760: D61C0052 05D2A570
	ds_store_b16_d16_hi v92, v114 offset:192                   // 0000001AA768: DA8400C0 0000725C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA770: BE8B206A
	s_cbranch_execz 31                                         // 0000001AA774: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x13f4>
	v_sub_f32_e32 v76, v76, v82                                // 0000001AA778: 0898A54C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA77C: BF870121
	v_mul_f32_e32 v84, 0x3fb8aa3b, v76                         // 0000001AA780: 10A898FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA788: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001AA78C: 020298FF C2CE8ED0
	v_fma_f32 v114, 0x3fb8aa3b, v76, -v84                      // 0000001AA794: D6130072 855298FF 3FB8AA3B
	v_rndne_f32_e32 v116, v84                                  // 0000001AA7A0: 7EE84754
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA7A4: BF870112
	v_fmac_f32_e32 v114, 0x32a5705f, v76                       // 0000001AA7A8: 56E498FF 32A5705F
	v_sub_f32_e32 v84, v84, v116                               // 0000001AA7B0: 08A8E954
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA7B4: BF870121
	v_add_f32_e32 v84, v84, v114                               // 0000001AA7B8: 06A8E554
	v_cvt_i32_f32_e32 v114, v116                               // 0000001AA7BC: 7EE41174
	v_exp_f32_e32 v84, v84                                     // 0000001AA7C0: 7EA84B54
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA7C4: BF870095
	.long 0xd71c0054                                           // 0000001AA7C8: D71C0054
	v_cndmask_b32_e32 v1, v84, v114, vcc_lo                    // 0000001AA7CC: 0202E554
	v_cndmask_b32_e64 v84, 0, v84, s0                          // 0000001AA7D0: D5010054 0002A880
	.long 0xd41e0000                                           // 0000001AA7D8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001AA7DC: 020298FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA7E4: BF870001
	v_cndmask_b32_e64 v84, 0x7f800000, v84, s0                 // 0000001AA7E8: D5010054 0002A8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA7F4: 8C7E0B7E
	v_mov_b32_e32 v76, 0                                       // 0000001AA7F8: 7E980280
	v_mov_b32_e32 v114, 0                                      // 0000001AA7FC: 7EE40280
	s_mov_b32 s11, exec_lo                                     // 0000001AA800: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v112                         // 0000001AA804: 7D22E0FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AA80C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x148c>
	v_sub_f32_e32 v112, v112, v82                              // 0000001AA810: 08E0A570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA814: BF870121
	v_mul_f32_e32 v114, 0x3fb8aa3b, v112                       // 0000001AA818: 10E4E0FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA820: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v112, vcc_lo             // 0000001AA824: 0202E0FF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v112, -v114                    // 0000001AA82C: D6130074 85CAE0FF 3FB8AA3B
	v_rndne_f32_e32 v117, v114                                 // 0000001AA838: 7EEA4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA83C: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v112                      // 0000001AA840: 56E8E0FF 32A5705F
	v_sub_f32_e32 v114, v114, v117                             // 0000001AA848: 08E4EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA84C: BF870121
	v_add_f32_e32 v114, v114, v116                             // 0000001AA850: 06E4E972
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AA854: 7EE81175
	v_exp_f32_e32 v114, v114                                   // 0000001AA858: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA85C: BF870095
	.long 0xd71c0072                                           // 0000001AA860: D71C0072
	v_cndmask_b32_e32 v1, v114, v116, vcc_lo                   // 0000001AA864: 0202E972
	v_cndmask_b32_e64 v114, 0, v114, s0                        // 0000001AA868: D5010072 0002E480
	.long 0xd41e0000                                           // 0000001AA870: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v112, vcc_lo             // 0000001AA874: 0202E0FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA87C: BF870001
	v_cndmask_b32_e64 v114, 0x7f800000, v114, s0               // 0000001AA880: D5010072 0002E4FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA88C: 8C7E0B7E
	v_add_f32_e32 v77, v77, v83                                // 0000001AA890: 069AA74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA894: BF870091
	v_mul_f32_e32 v83, 0x3d800000, v77                         // 0000001AA898: 10A69AFF 3D800000
	v_cndmask_b32_e32 v77, 0xf149f2ca, v83, vcc_lo             // 0000001AA8A0: 029AA6FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA8A8: BF870091
	v_mov_b32_dpp v112, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA8AC: 7EE002FA FF09614D
	v_max_f32_e32 v112, v112, v112                             // 0000001AA8B4: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA8B8: BF870091
	v_max_f32_e32 v77, v77, v112                               // 0000001AA8BC: 209AE14D
	v_mov_b32_dpp v112, v77 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA8C0: 7EE002FA FF09624D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA8C8: BF870091
	v_max_f32_e32 v112, v112, v112                             // 0000001AA8CC: 20E0E170
	v_max_f32_e32 v77, v77, v112                               // 0000001AA8D0: 209AE14D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA8D4: BF870091
	v_mov_b32_dpp v112, v77 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA8D8: 7EE002FA FF09644D
	v_max_f32_e32 v112, v112, v112                             // 0000001AA8E0: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA8E4: BF870121
	v_max_f32_e32 v77, v77, v112                               // 0000001AA8E8: 209AE14D
	v_bfe_u32 v112, v84, 16, 1                                 // 0000001AA8EC: D6100070 02052154
	v_mov_b32_dpp v116, v77 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AA8F4: 7EE802FA FF09684D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA8FC: BF870112
	v_add3_u32 v112, v84, v112, 0x7fff                         // 0000001AA900: D6550070 03FEE154 00007FFF
	v_max3_f32 v77, v109, v77, v116                            // 0000001AA90C: D61C004D 05D29B6D
	ds_store_b16_d16_hi v92, v112 offset:256                   // 0000001AA914: DA840100 0000705C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AA91C: BE8B206A
	s_cbranch_execz 31                                         // 0000001AA920: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x15a0>
	v_sub_f32_e32 v76, v83, v77                                // 0000001AA924: 08989B53
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA928: BF870121
	v_mul_f32_e32 v83, 0x3fb8aa3b, v76                         // 0000001AA92C: 10A698FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AA934: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001AA938: 020298FF C2CE8ED0
	v_fma_f32 v112, 0x3fb8aa3b, v76, -v83                      // 0000001AA940: D6130070 854E98FF 3FB8AA3B
	v_rndne_f32_e32 v116, v83                                  // 0000001AA94C: 7EE84753
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA950: BF870112
	v_fmac_f32_e32 v112, 0x32a5705f, v76                       // 0000001AA954: 56E098FF 32A5705F
	v_sub_f32_e32 v83, v83, v116                               // 0000001AA95C: 08A6E953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA960: BF870121
	v_add_f32_e32 v83, v83, v112                               // 0000001AA964: 06A6E153
	v_cvt_i32_f32_e32 v112, v116                               // 0000001AA968: 7EE01174
	v_exp_f32_e32 v83, v83                                     // 0000001AA96C: 7EA64B53
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA970: BF870095
	.long 0xd71c0053                                           // 0000001AA974: D71C0053
	v_cndmask_b32_e32 v1, v83, v112, vcc_lo                    // 0000001AA978: 0202E153
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 0000001AA97C: D5010053 0002A680
	.long 0xd41e0000                                           // 0000001AA984: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001AA988: 020298FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA990: BF870001
	v_cndmask_b32_e64 v76, 0x7f800000, v83, s0                 // 0000001AA994: D501004C 0002A6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AA9A0: 8C7E0B7E
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v112, 0            // 0000001AA9A4: CA100080 53700080
	s_mov_b32 s11, exec_lo                                     // 0000001AA9AC: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v109                         // 0000001AA9B0: 7D22DAFF EFA18F08
	s_cbranch_execz 31                                         // 0000001AA9B8: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1638>
	v_sub_f32_e32 v109, v109, v77                              // 0000001AA9BC: 08DA9B6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA9C0: BF870091
	v_mul_f32_e32 v112, 0x3fb8aa3b, v109                       // 0000001AA9C4: 10E0DAFF 3FB8AA3B
	v_fma_f32 v116, 0x3fb8aa3b, v109, -v112                    // 0000001AA9CC: D6130074 85C2DAFF 3FB8AA3B
	v_rndne_f32_e32 v117, v112                                 // 0000001AA9D8: 7EEA4770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA9DC: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v109                      // 0000001AA9E0: 56E8DAFF 32A5705F
	v_sub_f32_e32 v112, v112, v117                             // 0000001AA9E8: 08E0EB70
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AA9EC: BF8701B1
	v_add_f32_e32 v112, v112, v116                             // 0000001AA9F0: 06E0E970
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AA9F4: 7EE81175
	.long 0xd41b0000                                           // 0000001AA9F8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v109, vcc_lo             // 0000001AA9FC: 0202DAFF C2CE8ED0
	v_exp_f32_e32 v112, v112                                   // 0000001AAA04: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA08: BF870095
	.long 0xd71c0070                                           // 0000001AAA0C: D71C0070
	v_cndmask_b32_e32 v1, v112, v116, vcc_lo                   // 0000001AAA10: 0202E970
	v_cndmask_b32_e64 v112, 0, v112, s0                        // 0000001AAA14: D5010070 0002E080
	.long 0xd41e0000                                           // 0000001AAA1C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v109, vcc_lo             // 0000001AAA20: 0202DAFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AAA28: BF870001
	v_cndmask_b32_e64 v112, 0x7f800000, v112, s0               // 0000001AAA2C: D5010070 0002E0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AAA38: 8C7E0B7E
	s_waitcnt lgkmcnt(5)                                       // 0000001AAA3C: BF89FC57
	v_add_f32_e32 v78, v78, v80                                // 0000001AAA40: 069CA14E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA44: BF870091
	v_mul_f32_e32 v80, 0x3d800000, v78                         // 0000001AAA48: 10A09CFF 3D800000
	v_cndmask_b32_e32 v78, 0xf149f2ca, v80, vcc_lo             // 0000001AAA50: 029CA0FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA58: BF870091
	v_mov_b32_dpp v109, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAA5C: 7EDA02FA FF09614E
	v_max_f32_e32 v109, v109, v109                             // 0000001AAA64: 20DADB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA68: BF870091
	v_max_f32_e32 v78, v78, v109                               // 0000001AAA6C: 209CDB4E
	v_mov_b32_dpp v109, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAA70: 7EDA02FA FF09624E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA78: BF870091
	v_max_f32_e32 v109, v109, v109                             // 0000001AAA7C: 20DADB6D
	v_max_f32_e32 v78, v78, v109                               // 0000001AAA80: 209CDB4E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAA84: BF870091
	v_mov_b32_dpp v109, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAA88: 7EDA02FA FF09644E
	v_max_f32_e32 v109, v109, v109                             // 0000001AAA90: 20DADB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAA94: BF870121
	v_max_f32_e32 v78, v78, v109                               // 0000001AAA98: 209CDB4E
	v_bfe_u32 v109, v76, 16, 1                                 // 0000001AAA9C: D610006D 0205214C
	v_mov_b32_dpp v116, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAAA4: 7EE802FA FF09684E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AAAAC: BF870112
	v_add3_u32 v109, v76, v109, 0x7fff                         // 0000001AAAB0: D655006D 03FEDB4C 00007FFF
	v_max3_f32 v78, v108, v78, v116                            // 0000001AAABC: D61C004E 05D29D6C
	ds_store_b16_d16_hi v92, v109 offset:320                   // 0000001AAAC4: DA840140 00006D5C
	s_and_saveexec_b32 s11, vcc_lo                             // 0000001AAACC: BE8B206A
	s_cbranch_execz 31                                         // 0000001AAAD0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1750>
	v_sub_f32_e32 v80, v80, v78                                // 0000001AAAD4: 08A09D50
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAAD8: BF870091
	v_mul_f32_e32 v83, 0x3fb8aa3b, v80                         // 0000001AAADC: 10A6A0FF 3FB8AA3B
	v_fma_f32 v109, 0x3fb8aa3b, v80, -v83                      // 0000001AAAE4: D613006D 854EA0FF 3FB8AA3B
	v_rndne_f32_e32 v116, v83                                  // 0000001AAAF0: 7EE84753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AAAF4: BF870191
	v_sub_f32_e32 v83, v83, v116                               // 0000001AAAF8: 08A6E953
	v_fmac_f32_e32 v109, 0x32a5705f, v80                       // 0000001AAAFC: 56DAA0FF 32A5705F
	.long 0xd41b0000                                           // 0000001AAB04: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001AAB08: 0202A0FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAB10: BF870122
	v_add_f32_e32 v83, v83, v109                               // 0000001AAB14: 06A6DB53
	v_cvt_i32_f32_e32 v109, v116                               // 0000001AAB18: 7EDA1174
	v_exp_f32_e32 v83, v83                                     // 0000001AAB1C: 7EA64B53
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAB20: BF870095
	.long 0xd71c0053                                           // 0000001AAB24: D71C0053
	v_cndmask_b32_e32 v1, v83, v109, vcc_lo                    // 0000001AAB28: 0202DB53
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 0000001AAB2C: D5010053 0002A680
	.long 0xd41e0000                                           // 0000001AAB34: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001AAB38: 0202A0FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AAB40: BF870001
	v_cndmask_b32_e64 v83, 0x7f800000, v83, s0                 // 0000001AAB44: D5010053 0002A6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AAB50: 8C7E0B7E
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v80, 0            // 0000001AAB54: CA100080 6D500080
	s_mov_b32 s11, exec_lo                                     // 0000001AAB5C: BE8B007E
	v_cmpx_lt_f32_e32 0xefa18f08, v108                         // 0000001AAB60: 7D22D8FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AAB68: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x17e8>
	v_sub_f32_e32 v80, v108, v78                               // 0000001AAB6C: 08A09D6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAB70: BF870121
	v_mul_f32_e32 v108, 0x3fb8aa3b, v80                        // 0000001AAB74: 10D8A0FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AAB7C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001AAB80: 0202A0FF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v80, -v108                     // 0000001AAB88: D6130074 85B2A0FF 3FB8AA3B
	v_rndne_f32_e32 v117, v108                                 // 0000001AAB94: 7EEA476C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AAB98: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v80                       // 0000001AAB9C: 56E8A0FF 32A5705F
	v_sub_f32_e32 v108, v108, v117                             // 0000001AABA4: 08D8EB6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AABA8: BF870121
	v_add_f32_e32 v108, v108, v116                             // 0000001AABAC: 06D8E96C
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AABB0: 7EE81175
	v_exp_f32_e32 v108, v108                                   // 0000001AABB4: 7ED84B6C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AABB8: BF870095
	.long 0xd71c006c                                           // 0000001AABBC: D71C006C
	v_cndmask_b32_e32 v1, v108, v116, vcc_lo                   // 0000001AABC0: 0202E96C
	v_cndmask_b32_e64 v108, 0, v108, s0                        // 0000001AABC4: D501006C 0002D880
	.long 0xd41e0000                                           // 0000001AABCC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001AABD0: 0202A0FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AABD8: BF870001
	v_cndmask_b32_e64 v80, 0x7f800000, v108, s0                // 0000001AABDC: D5010050 0002D8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001AABE8: 8C7E0B7E
	v_add_f32_e32 v79, v79, v81                                // 0000001AABEC: 069EA34F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AABF0: BF870091
	v_mul_f32_e32 v81, 0x3d800000, v79                         // 0000001AABF4: 10A29EFF 3D800000
	v_cndmask_b32_e32 v79, 0xf149f2ca, v81, vcc_lo             // 0000001AABFC: 029EA2FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC04: BF870091
	v_mov_b32_dpp v108, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAC08: 7ED802FA FF09614F
	v_max_f32_e32 v108, v108, v108                             // 0000001AAC10: 20D8D96C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC14: BF870091
	v_max_f32_e32 v79, v79, v108                               // 0000001AAC18: 209ED94F
	v_mov_b32_dpp v108, v79 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAC1C: 7ED802FA FF09624F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC24: BF870091
	v_max_f32_e32 v108, v108, v108                             // 0000001AAC28: 20D8D96C
	v_max_f32_e32 v79, v79, v108                               // 0000001AAC2C: 209ED94F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC30: BF870091
	v_mov_b32_dpp v108, v79 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAC34: 7ED802FA FF09644F
	v_max_f32_e32 v108, v108, v108                             // 0000001AAC3C: 20D8D96C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAC40: BF870121
	v_max_f32_e32 v79, v79, v108                               // 0000001AAC44: 209ED94F
	v_bfe_u32 v108, v83, 16, 1                                 // 0000001AAC48: D610006C 02052153
	v_mov_b32_dpp v116, v79 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAC50: 7EE802FA FF09684F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AAC58: BF870112
	v_add3_u32 v108, v83, v108, 0x7fff                         // 0000001AAC5C: D655006C 03FED953 00007FFF
	v_max3_f32 v79, v107, v79, v116                            // 0000001AAC68: D61C004F 05D29F6B
	ds_store_b16_d16_hi v92, v108 offset:384                   // 0000001AAC70: DA840180 00006C5C
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001AAC78: BE80206A
	s_cbranch_execz 27                                         // 0000001AAC7C: BFA5001B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18ec>
	v_sub_f32_e32 v81, v81, v79                                // 0000001AAC80: 08A29F51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC84: BF870091
	v_mul_f32_e32 v108, 0x3fb8aa3b, v81                        // 0000001AAC88: 10D8A2FF 3FB8AA3B
	v_fma_f32 v109, 0x3fb8aa3b, v81, -v108                     // 0000001AAC90: D613006D 85B2A2FF 3FB8AA3B
	v_rndne_f32_e32 v116, v108                                 // 0000001AAC9C: 7EE8476C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AACA0: BF870221
	v_sub_f32_e32 v108, v108, v116                             // 0000001AACA4: 08D8E96C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v81                  // 0000001AACA8: 7C36A2FF C2CE8ED0
	v_fmac_f32_e32 v109, 0x32a5705f, v81                       // 0000001AACB0: 56DAA2FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AACB8: BF870121
	v_add_f32_e32 v108, v108, v109                             // 0000001AACBC: 06D8DB6C
	v_cvt_i32_f32_e32 v109, v116                               // 0000001AACC0: 7EDA1174
	v_exp_f32_e32 v108, v108                                   // 0000001AACC4: 7ED84B6C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AACC8: BF870095
	.long 0xd71c006c                                           // 0000001AACCC: D71C006C
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                   // 0000001AACD0: 0202DB6C
	v_cndmask_b32_e32 v108, 0, v108, vcc_lo                    // 0000001AACD4: 02D8D880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v81                  // 0000001AACD8: 7C3CA2FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AACE0: BF870002
	v_cndmask_b32_e32 v109, 0x7f800000, v108, vcc_lo           // 0000001AACE4: 02DAD8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001AACEC: 8C7E007E
	v_mov_b32_e32 v81, 0                                       // 0000001AACF0: 7EA20280
	s_mov_b32 s0, exec_lo                                      // 0000001AACF4: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v107                         // 0000001AACF8: 7D22D6FF EFA18F08
	s_cbranch_execz 64321                                      // 0000001AAD00: BFA5FB41 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x608>
	v_sub_f32_e32 v81, v107, v79                               // 0000001AAD04: 08A29F6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAD08: BF870121
	v_mul_f32_e32 v107, 0x3fb8aa3b, v81                        // 0000001AAD0C: 10D6A2FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v81                  // 0000001AAD14: 7C36A2FF C2CE8ED0
	v_fma_f32 v108, 0x3fb8aa3b, v81, -v107                     // 0000001AAD1C: D613006C 85AEA2FF 3FB8AA3B
	v_rndne_f32_e32 v116, v107                                 // 0000001AAD28: 7EE8476B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAD2C: BF870091
	v_dual_fmac_f32 v108, 0x32a5705f, v81 :: v_dual_sub_f32 v107, v107, v116// 0000001AAD30: C80AA2FF 6C6AE96B 32A5705F
	v_add_f32_e32 v107, v107, v108                             // 0000001AAD3C: 06D6D96B
	v_cvt_i32_f32_e32 v108, v116                               // 0000001AAD40: 7ED81174
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AAD44: BF870292
	v_exp_f32_e32 v107, v107                                   // 0000001AAD48: 7ED64B6B
	.long 0xd71c006b                                           // 0000001AAD4C: D71C006B
	v_cndmask_b32_e32 v1, v107, v108, vcc_lo                   // 0000001AAD50: 0202D96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AAD54: BF870121
	v_cndmask_b32_e32 v107, 0, v107, vcc_lo                    // 0000001AAD58: 02D6D680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v81                  // 0000001AAD5C: 7C3CA2FF 42B17218
	v_cndmask_b32_e32 v81, 0x7f800000, v107, vcc_lo            // 0000001AAD64: 02A2D6FF 7F800000
	s_branch 64294                                             // 0000001AAD6C: BFA0FB26 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi32ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x608>
	v_mov_b32_e32 v7, v91                                      // 0000001AAD70: 7E0E035B
	s_mul_i32 s0, s16, 12                                      // 0000001AAD74: 96008C10
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AAD78: BF870001
	v_or_b32_e32 v6, v7, v89                                   // 0000001AAD7C: 380CB307
	v_or_b32_e32 v14, s0, v90                                  // 0000001AAD80: 381CB400
	v_mov_b32_e32 v7, 0                                        // 0000001AAD84: 7E0E0280
	v_mov_b32_dpp v83, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAD88: 7EA602FA FF09614C
	v_mov_b32_dpp v78, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAD90: 7E9C02FA FF09614A
	v_mov_b32_dpp v81, v84 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAD98: 7EA202FA FF096154
	v_lshlrev_b32_e32 v30, 8, v14                              // 0000001AADA0: 303C1C88
	v_mov_b32_dpp v77, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AADA4: 7E9A02FA FF096149
	v_mad_i64_i32 v[6:7], null, 0x1800, s2, v[6:7]             // 0000001AADAC: D6FF7C06 041804FF 00001800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AADB8: BF870214
	v_dual_add_f32 v78, v74, v78 :: v_dual_add_f32 v81, v84, v81// 0000001AADBC: C9089D4A 4E50A354
	v_dual_add_f32 v83, v76, v83 :: v_dual_add_nc_u32 v46, 0xa00, v30// 0000001AADC4: C920A74C 532E3CFF 00000A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AADD0: BF870194
	v_dual_add_f32 v85, v73, v77 :: v_dual_add_nc_u32 v38, 0x800, v30// 0000001AADD4: C9209B49 55263CFF 00000800
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AADE0: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v15, 31, v30                             // 0000001AADE8: 341E3C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001AADEC: BF870244
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AADF0: 06A6A6FA FF096253
	.long 0xd7006a0e                                           // 0000001AADF8: D7006A0E
	v_cndmask_b32_e32 v1, v6, v30, vcc_lo                      // 0000001AADFC: 02023D06
	v_add_f32_dpp v84, v85, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE00: 06A8AAFA FF096255
	v_add_f32_dpp v85, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE08: 06AAA2FA FF096451
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE10: 06A6A6FA FF096453
	v_add_nc_u32_e32 v22, 0x400, v30                           // 0000001AAE18: 4A2C3CFF 00000400
	v_add_co_ci_u32_e64 v15, null, v7, v15, vcc_lo             // 0000001AAE20: D5207C0F 01AA1F07
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE28: 06A8A8FA FF096454
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AAE30: BF870214
	v_add_f32_dpp v81, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE34: 06A2A6FA FF096853
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001AAE3C: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AAE40: BF870224
	.long 0xd73c000e                                           // 0000001AAE44: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001AAE48: 02021C81
	.long 0xd7006a16                                           // 0000001AAE4C: D7006A16
	v_cndmask_b32_e32 v1, v6, v22, vcc_lo                      // 0000001AAE50: 02022D06
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001AAE54: D6FC7C73 03CAA351
	v_add_f32_dpp v89, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAE5C: 06B2A8FA FF096854
	v_add_co_ci_u32_e64 v23, null, v7, v23, vcc_lo             // 0000001AAE64: D5207C17 01AA2F07
	.long 0xd7006a44                                           // 0000001AAE6C: D7006A44
	v_cndmask_b32_e32 v1, s6, v14, vcc_lo                      // 0000001AAE70: 02021C06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001AAE74: BF870254
	v_rcp_f32_e32 v84, v115                                    // 0000001AAE78: 7EA85573
	v_or_b32_e32 v64, 0x200, v30                               // 0000001AAE7C: 38803CFF 00000200
	v_add_co_ci_u32_e64 v69, null, s7, v15, vcc_lo             // 0000001AAE84: D5207C45 01AA1E07
	.long 0xd73c0016                                           // 0000001AAE8C: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001AAE90: 02022C81
	v_ashrrev_i32_e32 v47, 31, v46                             // 0000001AAE94: 345E5C9F
	v_ashrrev_i32_e32 v65, 31, v64                             // 0000001AAE98: 3482809F
	s_clause 0x3                                               // 0000001AAE9C: BF850003
	global_load_u16 v75, v[68:69], off offset:1024             // 0000001AAEA0: DC4A0400 4B7C0044
	global_load_u16 v80, v[68:69], off                         // 0000001AAEA8: DC4A0000 507C0044
	global_load_u16 v82, v[68:69], off offset:32               // 0000001AAEB0: DC4A0020 527C0044
	global_load_u16 v103, v[68:69], off offset:64              // 0000001AAEB8: DC4A0040 677C0044
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAEC0: 069C9CFA FF09624E
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001AAEC8: D613008F 23CAA973
	v_add_nc_u32_e32 v31, 0x600, v30                           // 0000001AAED0: 4A3E3CFF 00000600
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001AAED8: D6FC7C6D 03CAB359
	v_add_f32_dpp v83, v85, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAEE0: 06A6AAFA FF096855
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAEE8: 069C9CFA FF09644E
	v_fmac_f32_e32 v84, v143, v84                              // 0000001AAEF0: 56A8A98F
	v_ashrrev_i32_e32 v39, 31, v31                             // 0000001AAEF4: 344E3E9F
	.long 0xd7006a1e                                           // 0000001AAEF8: D7006A1E
	v_cndmask_b32_e32 v1, v6, v31, vcc_lo                      // 0000001AAEFC: 02023F06
	v_rcp_f32_e32 v91, v109                                    // 0000001AAF00: 7EB6556D
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001AAF04: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AAF0C: BF8701B3
	v_add_co_ci_u32_e64 v31, null, v7, v39, vcc_lo             // 0000001AAF10: D5207C1F 01AA4F07
	v_ashrrev_i32_e32 v39, 31, v38                             // 0000001AAF18: 344E4C9F
	.long 0xd7006a36                                           // 0000001AAF1C: D7006A36
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 0000001AAF20: 02022C06
	.long 0xd73c001e                                           // 0000001AAF24: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001AAF28: 02023C81
	v_add_co_ci_u32_e64 v55, null, s7, v23, vcc_lo             // 0000001AAF2C: D5207C37 01AA2E07
	.long 0xd7006a26                                           // 0000001AAF34: D7006A26
	v_cndmask_b32_e32 v1, v6, v38, vcc_lo                      // 0000001AAF38: 02024D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AAF3C: BF8700A1
	v_add_co_ci_u32_e64 v39, null, v7, v39, vcc_lo             // 0000001AAF40: D5207C27 01AA4F07
	.long 0xd7006a2e                                           // 0000001AAF48: D7006A2E
	v_cndmask_b32_e32 v1, v6, v46, vcc_lo                      // 0000001AAF4C: 02025D06
	v_add_co_ci_u32_e64 v47, null, v7, v47, vcc_lo             // 0000001AAF50: D5207C2F 01AA5F07
	.long 0xd7006a3e                                           // 0000001AAF58: D7006A3E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000001AAF5C: 02023C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AAF60: BF8700A1
	v_add_co_ci_u32_e64 v63, null, s7, v31, vcc_lo             // 0000001AAF64: D5207C3F 01AA3E07
	.long 0xd7006a06                                           // 0000001AAF6C: D7006A06
	v_cndmask_b32_e32 v1, v6, v64, vcc_lo                      // 0000001AAF70: 02028106
	v_add_co_ci_u32_e64 v7, null, v7, v65, vcc_lo              // 0000001AAF74: D5207C07 01AA8307
	.long 0xd73c0026                                           // 0000001AAF7C: D73C0026
	v_cndmask_b32_e32 v1, 1, v38, vcc_lo                       // 0000001AAF80: 02024C81
	.long 0xd73c002e                                           // 0000001AAF84: D73C002E
	v_cndmask_b32_e32 v1, 1, v46, vcc_lo                       // 0000001AAF88: 02025C81
	v_rcp_f32_e32 v85, v111                                    // 0000001AAF8C: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001AAF90: BF8700C3
	.long 0xd73c0068                                           // 0000001AAF94: D73C0068
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001AAF98: 02020C81
	v_mov_b32_dpp v7, v88 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAF9C: 7E0E02FA FF096158
	v_mov_b32_dpp v6, v87 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AAFA4: 7E0C02FA FF096157
	.long 0xd7006a42                                           // 0000001AAFAC: D7006A42
	v_cndmask_b32_e32 v1, s6, v38, vcc_lo                      // 0000001AAFB0: 02024C06
	v_add_co_ci_u32_e64 v67, null, s7, v39, vcc_lo             // 0000001AAFB4: D5207C43 01AA4E07
	.long 0xd7006a40                                           // 0000001AAFBC: D7006A40
	v_cndmask_b32_e32 v1, s6, v46, vcc_lo                      // 0000001AAFC0: 02025C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AAFC4: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s7, v47, vcc_lo             // 0000001AAFC8: D5207C41 01AA5E07
	.long 0xd7006a46                                           // 0000001AAFD0: D7006A46
	v_cndmask_b32_e32 v1, s6, v104, vcc_lo                     // 0000001AAFD4: 0202D006
	v_add_co_ci_u32_e64 v71, null, s7, v105, vcc_lo            // 0000001AAFD8: D5207C47 01AAD207
	s_clause 0x9                                               // 0000001AAFE0: BF850009
	global_load_u16 v99, v[62:63], off                         // 0000001AAFE4: DC4A0000 637C003E
	global_load_u16 v98, v[54:55], off                         // 0000001AAFEC: DC4A0000 627C0036
	global_load_u16 v101, v[64:65], off                        // 0000001AAFF4: DC4A0000 657C0040
	global_load_u16 v100, v[66:67], off                        // 0000001AAFFC: DC4A0000 647C0042
	global_load_u16 v102, v[70:71], off offset:32              // 0000001AB004: DC4A0020 667C0046
	global_load_u16 v94, v[62:63], off offset:32               // 0000001AB00C: DC4A0020 5E7C003E
	global_load_u16 v93, v[54:55], off offset:32               // 0000001AB014: DC4A0020 5D7C0036
	global_load_u16 v96, v[64:65], off offset:32               // 0000001AB01C: DC4A0020 607C0040
	global_load_u16 v95, v[66:67], off offset:32               // 0000001AB024: DC4A0020 5F7C0042
	global_load_u16 v97, v[70:71], off offset:64               // 0000001AB02C: DC4A0040 617C0046
	v_add_f32_e32 v7, v88, v7                                  // 0000001AB034: 060E0F58
	v_add_f32_dpp v88, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB038: 06B09CFA FF09684E
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001AB040: D613008E 23CAAB6F
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001AB048: D6FC0072 03CAA6F2
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001AB050: D6FC0270 03CAB2F2
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB058: 060E0EFA FF096207
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001AB060: D6FC7C6E 03CAB158
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001AB068: D6FC0174 03CAA2F2
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001AB070: D6FC0371 03CAB0F2
	.long 0x7f903880                                           // 0000001AB078: 7F903880
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB07C: 060E0EFA FF096407
	v_rcp_f32_e32 v90, v110                                    // 0000001AB084: 7EB4556E
	v_fmac_f32_e32 v85, v142, v85                              // 0000001AB088: 56AAAB8E
	v_mul_f32_e32 v143, v116, v84                              // 0000001AB08C: 111EA974
	.long 0x7f9e39c8                                           // 0000001AB090: 7F9E39C8
	v_add_f32_dpp v107, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB094: 06D60EFA FF096807
	.long 0x7f9439c8                                           // 0000001AB09C: 7F9439C8
	v_mul_f32_e32 v142, v114, v85                              // 0000001AB0A0: 111CAB72
	.long 0x7f9239c8                                           // 0000001AB0A4: 7F9239C8
	.long 0x7f9a39c8                                           // 0000001AB0A8: 7F9A39C8
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001AB0AC: D6FC7C76 03CAD76B
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001AB0B4: D6FC0478 03CAD6F2
	.long 0x7f9839c8                                           // 0000001AB0BC: 7F9839C8
	v_fma_f32 v148, -v111, v142, v114                          // 0000001AB0C0: D6130094 25CB1D6F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB0C8: BF8700A4
	v_rcp_f32_e32 v121, v118                                   // 0000001AB0CC: 7EF25576
	v_add_f32_e32 v6, v87, v6                                  // 0000001AB0D0: 060C0D57
	v_add_f32_dpp v6, v6, v6 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB0D4: 060C0CFA FF096206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB0DC: BF870091
	v_add_f32_dpp v6, v6, v6 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB0E0: 060C0CFA FF096406
	v_add_f32_dpp v108, v6, v6 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AB0E8: 06D80CFA FF096806
	.long 0xd7000506                                           // 0000001AB0F0: D7000506
	v_cndmask_b32_e32 v1, s8, v14, vcc_lo                      // 0000001AB0F4: 02021C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB0F8: BF870191
	v_add_co_ci_u32_e64 v7, null, s9, v15, s5                  // 0000001AB0FC: D5207C07 00161E09
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001AB104: D6FC7C75 03CAD96C
	.long 0xd700050e                                           // 0000001AB10C: D700050E
	v_cndmask_b32_e32 v1, s8, v22, vcc_lo                      // 0000001AB110: 02022C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB114: BF870191
	v_add_co_ci_u32_e64 v15, null, s9, v23, s5                 // 0000001AB118: D5207C0F 00162E09
	v_rcp_f32_e32 v122, v117                                   // 0000001AB120: 7EF45575
	.long 0xd7000516                                           // 0000001AB124: D7000516
	v_cndmask_b32_e32 v1, s8, v30, vcc_lo                      // 0000001AB128: 02023C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB12C: BF8700A1
	v_add_co_ci_u32_e64 v23, null, s9, v31, s5                 // 0000001AB130: D5207C17 00163E09
	.long 0xd700051e                                           // 0000001AB138: D700051E
	v_cndmask_b32_e32 v1, s8, v38, vcc_lo                      // 0000001AB13C: 02024C08
	v_add_co_ci_u32_e64 v31, null, s9, v39, s5                 // 0000001AB140: D5207C1F 00164E09
	.long 0xd7000526                                           // 0000001AB148: D7000526
	v_cndmask_b32_e32 v1, s8, v46, vcc_lo                      // 0000001AB14C: 02025C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB150: BF8700A1
	v_add_co_ci_u32_e64 v39, null, s9, v47, s5                 // 0000001AB154: D5207C27 00165E09
	.long 0xd700052e                                           // 0000001AB15C: D700052E
	v_cndmask_b32_e32 v1, s8, v104, vcc_lo                     // 0000001AB160: 0202D008
	v_add_co_ci_u32_e64 v47, null, s9, v105, s5                // 0000001AB164: D5207C2F 0016D209
	s_clause 0x1f                                              // 0000001AB16C: BF85001F
	global_load_u16 v78, v[68:69], off offset:96               // 0000001AB170: DC4A0060 4E7C0044
	global_load_u16 v86, v[68:69], off offset:128              // 0000001AB178: DC4A0080 567C0044
	global_load_u16 v87, v[68:69], off offset:160              // 0000001AB180: DC4A00A0 577C0044
	global_load_u16 v92, v[68:69], off offset:192              // 0000001AB188: DC4A00C0 5C7C0044
	global_load_u16 v68, v[68:69], off offset:224              // 0000001AB190: DC4A00E0 447C0044
	global_load_u16 v138, v[54:55], off offset:64              // 0000001AB198: DC4A0040 8A7C0036
	global_load_u16 v133, v[54:55], off offset:96              // 0000001AB1A0: DC4A0060 857C0036
	global_load_u16 v128, v[54:55], off offset:128             // 0000001AB1A8: DC4A0080 807C0036
	global_load_u16 v124, v[54:55], off offset:160             // 0000001AB1B0: DC4A00A0 7C7C0036
	global_load_u16 v104, v[54:55], off offset:192             // 0000001AB1B8: DC4A00C0 687C0036
	global_load_u16 v137, v[62:63], off offset:64              // 0000001AB1C0: DC4A0040 897C003E
	global_load_u16 v132, v[62:63], off offset:96              // 0000001AB1C8: DC4A0060 847C003E
	global_load_u16 v127, v[62:63], off offset:128             // 0000001AB1D0: DC4A0080 7F7C003E
	global_load_u16 v123, v[62:63], off offset:160             // 0000001AB1D8: DC4A00A0 7B7C003E
	global_load_u16 v69, v[62:63], off offset:192              // 0000001AB1E0: DC4A00C0 457C003E
	global_load_u16 v55, v[54:55], off offset:224              // 0000001AB1E8: DC4A00E0 377C0036
	global_load_u16 v140, v[66:67], off offset:64              // 0000001AB1F0: DC4A0040 8C7C0042
	global_load_u16 v135, v[66:67], off offset:96              // 0000001AB1F8: DC4A0060 877C0042
	global_load_u16 v130, v[66:67], off offset:128             // 0000001AB200: DC4A0080 827C0042
	global_load_u16 v126, v[66:67], off offset:160             // 0000001AB208: DC4A00A0 7E7C0042
	global_load_u16 v106, v[66:67], off offset:192             // 0000001AB210: DC4A00C0 6A7C0042
	global_load_u16 v54, v[62:63], off offset:224              // 0000001AB218: DC4A00E0 367C003E
	global_load_u16 v139, v[64:65], off offset:64              // 0000001AB220: DC4A0040 8B7C0040
	global_load_u16 v134, v[64:65], off offset:96              // 0000001AB228: DC4A0060 867C0040
	global_load_u16 v129, v[64:65], off offset:128             // 0000001AB230: DC4A0080 817C0040
	global_load_u16 v125, v[64:65], off offset:160             // 0000001AB238: DC4A00A0 7D7C0040
	global_load_u16 v105, v[64:65], off offset:192             // 0000001AB240: DC4A00C0 697C0040
	global_load_u16 v62, v[66:67], off offset:224              // 0000001AB248: DC4A00E0 3E7C0042
	global_load_u16 v141, v[70:71], off offset:96              // 0000001AB250: DC4A0060 8D7C0046
	global_load_u16 v136, v[70:71], off offset:128             // 0000001AB258: DC4A0080 887C0046
	global_load_u16 v131, v[70:71], off offset:160             // 0000001AB260: DC4A00A0 837C0046
	global_load_u16 v67, v[70:71], off offset:192              // 0000001AB268: DC4A00C0 437C0046
	s_clause 0x1                                               // 0000001AB270: BF850001
	global_load_u16 v66, v[70:71], off offset:224              // 0000001AB274: DC4A00E0 427C0046
	global_load_u16 v63, v[64:65], off offset:224              // 0000001AB27C: DC4A00E0 3F7C0040
	v_fma_f32 v64, -v117, v122, 1.0                            // 0000001AB284: D6130040 23CAF575
	v_fma_f32 v65, -v118, v121, 1.0                            // 0000001AB28C: D6130041 23CAF376
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001AB294: D6FC6A77 03CAD8F2
	v_fma_f32 v70, -v109, v91, 1.0                             // 0000001AB29C: D6130046 23CAB76D
	v_fma_f32 v71, -v110, v90, 1.0                             // 0000001AB2A4: D6130047 23CAB56E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB2AC: BF870114
	v_dual_fmac_f32 v122, v64, v122 :: v_dual_fmac_f32 v121, v65, v121// 0000001AB2B0: C800F540 7A78F341
	v_dual_fmac_f32 v91, v70, v91 :: v_dual_fmac_f32 v90, v71, v90// 0000001AB2B8: C800B746 5B5AB547
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB2C0: BF870112
	v_dual_mul_f32 v64, v119, v122 :: v_dual_mul_f32 v65, v120, v121// 0000001AB2C4: C8C6F577 4040F378
	v_dual_mul_f32 v70, v112, v91 :: v_dual_mul_f32 v71, v113, v90// 0000001AB2CC: C8C6B770 4646B571
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB2D4: BF870192
	v_fma_f32 v144, -v117, v64, v119                           // 0000001AB2D8: D6130090 25DE8175
	v_fma_f32 v145, -v118, v65, v120                           // 0000001AB2E0: D6130091 25E28376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB2E8: BF870213
	v_fma_f32 v146, -v109, v70, v112                           // 0000001AB2EC: D6130092 25C28D6D
	v_fma_f32 v147, -v110, v71, v113                           // 0000001AB2F4: D6130093 25C68F6E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AB2FC: BF8701A3
	v_dual_fmac_f32 v64, v144, v122 :: v_dual_fmac_f32 v65, v145, v121// 0000001AB300: C800F590 4040F391
	v_fma_f32 v144, -v115, v143, v116                          // 0000001AB308: D6130090 25D31F73
	v_dual_fmac_f32 v70, v146, v91 :: v_dual_fmac_f32 v71, v147, v90// 0000001AB310: C800B792 4646B593
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB318: BF870213
	v_fma_f32 v117, -v117, v64, v119                           // 0000001AB31C: D6130075 25DE8175
	v_fma_f32 v118, -v118, v65, v120                           // 0000001AB324: D6130076 25E28376
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB32C: BF870214
	v_fmac_f32_e32 v143, v144, v84                             // 0000001AB330: 571EA990
	v_fma_f32 v109, -v109, v70, v112                           // 0000001AB334: D613006D 25C28D6D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AB33C: BF870134
	v_div_fmas_f32 v64, v117, v122, v64                        // 0000001AB340: D6370040 0502F575
	s_mov_b32 vcc_lo, s4                                       // 0000001AB348: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v65                       // 0000001AB34C: D6370075 0506F376
	v_div_fixup_f32 v65, v64, v108, 1.0                        // 0000001AB354: D6270041 03CAD940
	v_fma_f32 v108, -v110, v71, v113                           // 0000001AB35C: D613006C 25C68F6E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AB364: BF870223
	v_div_fixup_f32 v64, v117, v107, 1.0                       // 0000001AB368: D6270040 03CAD775
	v_fmac_f32_e32 v142, v148, v85                             // 0000001AB370: 571CAB94
	v_mul_f32_e32 v56, v56, v65                                // 0000001AB374: 10708338
	v_mul_f32_e32 v8, v8, v65                                  // 0000001AB378: 10108308
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB37C: BF870214
	v_dual_mul_f32 v0, v0, v65 :: v_dual_mul_f32 v57, v57, v64 // 0000001AB380: C8C68300 00388139
	v_fma_f32 v107, -v111, v142, v114                          // 0000001AB388: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v48, v65                               // 0000001AB390: 10DE8330
	v_mul_f32_e32 v9, v9, v64                                  // 0000001AB394: 10128109
	v_dual_mul_f32 v17, v17, v64 :: v_dual_mul_f32 v40, v40, v65// 0000001AB398: C8C68111 11288328
	v_mul_f32_e32 v32, v32, v65                                // 0000001AB3A0: 10408320
	v_dual_mul_f32 v24, v24, v65 :: v_dual_mul_f32 v1, v1, v64 // 0000001AB3A4: C8C68318 18008101
	s_waitcnt vmcnt(46)                                        // 0000001AB3AC: BF89BBF7
	v_lshlrev_b32_e32 v48, 16, v80                             // 0000001AB3B0: 3060A090
	v_dual_mul_f32 v80, v49, v64 :: v_dual_lshlrev_b32 v75, 16, v75// 0000001AB3B4: C8E28131 504A9690
	s_waitcnt vmcnt(45)                                        // 0000001AB3BC: BF89B7F7
	v_lshlrev_b32_e32 v49, 16, v82                             // 0000001AB3C0: 3062A490
	s_waitcnt vmcnt(44)                                        // 0000001AB3C4: BF89B3F7
	v_dual_mul_f32 v103, 0xbfb8aa3b, v48 :: v_dual_lshlrev_b32 v82, 16, v103// 0000001AB3C8: C8E260FF 6752CE90 BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v75                        // 0000001AB3D4: 10E096FF BFB8AA3B
	v_fma_f32 v110, -v115, v143, v116                          // 0000001AB3DC: D613006E 25D31F73
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB3E4: BF870213
	v_dual_mul_f32 v113, 0xbfb8aa3b, v49 :: v_dual_mul_f32 v114, 0xbfb8aa3b, v82// 0000001AB3E8: C8C662FF 7172A4FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v48, -v103                     // 0000001AB3F4: D6130073 859E60FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001AB400: 7EE84767
	v_fma_f32 v117, 0xbfb8aa3b, v75, -v112                     // 0000001AB404: D6130075 85C296FF BFB8AA3B
	v_rndne_f32_e32 v118, v112                                 // 0000001AB410: 7EEC4770
	v_rndne_f32_e32 v152, v114                                 // 0000001AB414: 7F304772
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001AB418: D6130097 85CAA4FF BFB8AA3B
	v_fmac_f32_e32 v115, 0xb2a5705f, v48                       // 0000001AB424: 56E660FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB42C: BF870214
	v_dual_fmac_f32 v117, 0xb2a5705f, v75 :: v_dual_sub_f32 v112, v112, v118// 0000001AB430: C80A96FF 7570ED70 B2A5705F
	v_sub_f32_e32 v114, v114, v152                             // 0000001AB43C: 08E53172
	v_sub_f32_e32 v103, v103, v116                             // 0000001AB440: 08CEE967
	v_fma_f32 v145, 0xbfb8aa3b, v49, -v113                     // 0000001AB444: D6130091 85C662FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001AB450: 7F244771
	v_add_f32_e32 v112, v112, v117                             // 0000001AB454: 06E0EB70
	v_cvt_i32_f32_e32 v116, v116                               // 0000001AB458: 7EE81174
	v_cvt_i32_f32_e32 v118, v118                               // 0000001AB45C: 7EEC1176
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001AB460: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB468: BF870294
	v_exp_f32_e32 v112, v112                                   // 0000001AB46C: 7EE04B70
	.long 0xd71c0070                                           // 0000001AB470: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001AB474: 0202ED70
	s_waitcnt vmcnt(43)                                        // 0000001AB478: BF89AFF7
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001AB47C: 30C6C690
	s_waitcnt vmcnt(42)                                        // 0000001AB480: BF89ABF7
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001AB484: 30C4C490
	s_waitcnt vmcnt(41)                                        // 0000001AB488: BF89A7F7
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001AB48C: 30CACA90
	s_waitcnt vmcnt(40)                                        // 0000001AB490: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001AB494: 30C8C890
	v_dual_mul_f32 v120, 0xbfb8aa3b, v99 :: v_dual_mul_f32 v119, 0xbfb8aa3b, v98// 0000001AB498: C8C6C6FF 7876C4FF BFB8AA3B
	s_waitcnt vmcnt(39)                                        // 0000001AB4A4: BF899FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AB4A8: BF870132
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001AB4AC: C8E2C8FF 7966CC90 BFB8AA3B
	s_waitcnt vmcnt(35)                                        // 0000001AB4B8: BF898FF7
	v_dual_mul_f32 v122, 0xbfb8aa3b, v101 :: v_dual_lshlrev_b32 v95, 16, v95// 0000001AB4BC: C8E2CAFF 7A5EBE90 BFB8AA3B
	v_dual_mul_f32 v144, 0xbfb8aa3b, v102 :: v_dual_lshlrev_b32 v93, 16, v93// 0000001AB4C8: C8E2CCFF 905CBA90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AB4D4: BF870002
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v96, 16, v96// 0000001AB4D8: C8E2BEFF 9560C090 BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001AB4E4: D613009A 85DEC4FF BFB8AA3B
	v_rndne_f32_e32 v155, v119                                 // 0000001AB4F0: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001AB4F4: D61300A0 85EACAFF BFB8AA3B
	v_add_f32_e32 v103, v103, v115                             // 0000001AB500: 06CEE767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001AB504: D613009C 85E2C6FF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001AB510: 7F42477A
	v_rndne_f32_e32 v163, v144                                 // 0000001AB514: 7F464790
	v_dual_fmac_f32 v145, 0xb2a5705f, v49 :: v_dual_fmac_f32 v154, 0xb2a5705f, v98// 0000001AB518: C80062FF 919AC4FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AB524: BF870004
	v_dual_sub_f32 v113, v113, v146 :: v_dual_fmac_f32 v156, 0xb2a5705f, v99// 0000001AB528: C9412571 719CC6FF B2A5705F
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001AB534: D61300A8 8656BEFF BFB8AA3B
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001AB540: C94B3777 737B437A
	v_fmac_f32_e32 v160, 0xb2a5705f, v101                      // 0000001AB548: 5740CAFF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001AB550: 7ECE4B67
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001AB554: C8E2BAFF 935EBC90 BFB8AA3B
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001AB560: D61300A2 8642CCFF BFB8AA3B
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001AB56C: C9494790 90712371
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001AB574: C808BEFF A8733573 B2A5705F
	s_waitcnt vmcnt(34)                                        // 0000001AB580: BF898BF7
	v_dual_mul_f32 v148, 0xbfb8aa3b, v94 :: v_dual_lshlrev_b32 v97, 16, v97// 0000001AB584: C8E2BCFF 9460C290 BFB8AA3B
	v_mul_f32_e32 v150, 0xbfb8aa3b, v96                        // 0000001AB590: 112CC0FF BFB8AA3B
	v_exp_f32_e32 v113, v113                                   // 0000001AB598: 7EE24B71
	v_exp_f32_e32 v115, v115                                   // 0000001AB59C: 7EE64B73
	.long 0xd71c0067                                           // 0000001AB5A0: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001AB5A4: 0202E967
	v_mul_f32_e32 v153, 0xbfb8aa3b, v97                        // 0000001AB5A8: 1132C2FF BFB8AA3B
	v_rndne_f32_e32 v157, v120                                 // 0000001AB5B0: 7F3A4778
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001AB5B4: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001AB5C0: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001AB5C4: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001AB5C8: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001AB5D4: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001AB5E0: 7F564796
	v_cvt_i32_f32_e32 v117, v155                               // 0000001AB5E4: 7EEA119B
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001AB5E8: C913417A 7A66CE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v75                  // 0000001AB5F0: 7C3C96FF 42CE8ED0
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v158, 0xb2a5705f, v100// 0000001AB5F8: C800A4FF 979EC8FF B2A5705F
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001AB604: C9413B78 77A2CCFF B2A5705F
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001AB610: C9413F79 79A4BAFF B2A5705F
	v_fmac_f32_e32 v170, 0xb2a5705f, v96                       // 0000001AB61C: 5754C0FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AB624: BF870003
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001AB628: C9495796 96773977
	.long 0xd71c0071                                           // 0000001AB630: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001AB634: 02032571
	.long 0xd71c0073                                           // 0000001AB638: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001AB63C: 0202EB73
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001AB640: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001AB644: 7C3C62FF 42CE8ED0
	v_add_f32_e32 v121, v121, v158                             // 0000001AB64C: 06F33D79
	v_add_f32_e32 v150, v150, v170                             // 0000001AB650: 072D5596
	v_exp_f32_e32 v119, v119                                   // 0000001AB654: 7EEE4B77
	v_rndne_f32_e32 v165, v147                                 // 0000001AB658: 7F4A4793
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001AB65C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001AB660: 7C3660FF C2B17218
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001AB668: D61300A6 8652BCFF BFB8AA3B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001AB674: 7EF0119D
	v_exp_f32_e32 v121, v121                                   // 0000001AB678: 7EF24B79
	v_cvt_i32_f32_e32 v155, v159                               // 0000001AB67C: 7F36119F
	v_cndmask_b32_e32 v48, 0x7f800000, v103, vcc_lo            // 0000001AB680: 0260CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v75                  // 0000001AB688: 7C3696FF C2B17218
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001AB690: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001AB69C: 07214590
	v_exp_f32_e32 v122, v122                                   // 0000001AB6A0: 7EF44B7A
	v_cndmask_b32_e32 v75, 0x7f800000, v112, vcc_lo            // 0000001AB6A4: 0296E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001AB6AC: 7C3CC4FF 42CE8ED0
	.long 0xd71c0075                                           // 0000001AB6B4: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001AB6B8: 0202F177
	v_rndne_f32_e32 v167, v148                                 // 0000001AB6BC: 7F4E4794
	v_rndne_f32_e32 v169, v149                                 // 0000001AB6C0: 7F524795
	v_cvt_i32_f32_e32 v157, v161                               // 0000001AB6C4: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001AB6C8: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001AB6CC: 7C3CC6FF 42CE8ED0
	v_add_f32_e32 v145, v145, v164                             // 0000001AB6D4: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001AB6D8: 7F204B90
	.long 0xd71c0076                                           // 0000001AB6DC: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001AB6E0: 02033779
	v_cvt_i32_f32_e32 v159, v163                               // 0000001AB6E4: 7F3E11A3
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001AB6E8: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001AB6EC: 7C3CC8FF 42CE8ED0
	v_dual_sub_f32 v148, v148, v167 :: v_dual_sub_f32 v149, v149, v169// 0000001AB6F4: C94B4F94 94955395
	.long 0xd71c0077                                           // 0000001AB6FC: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001AB700: 02033B7A
	v_exp_f32_e32 v145, v145                                   // 0000001AB704: 7F224B91
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001AB708: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001AB70C: 7C3CCAFF 42CE8ED0
	v_dual_add_f32 v148, v148, v166 :: v_dual_add_f32 v149, v149, v168// 0000001AB714: C9094D94 94955195
	.long 0xd71c0078                                           // 0000001AB71C: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001AB720: 02033F90
	v_cvt_i32_f32_e32 v147, v165                               // 0000001AB724: 7F2611A5
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001AB728: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001AB72C: 7C3CCCFF 42CE8ED0
	v_exp_f32_e32 v148, v148                                   // 0000001AB734: 7F284B94
	v_exp_f32_e32 v149, v149                                   // 0000001AB738: 7F2A4B95
	v_cvt_i32_f32_e32 v161, v167                               // 0000001AB73C: 7F4211A7
	v_cvt_i32_f32_e32 v163, v169                               // 0000001AB740: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001AB744: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001AB748: 7C3662FF C2B17218
	v_exp_f32_e32 v116, v150                                   // 0000001AB750: 7EE84B96
	.long 0xd71c0079                                           // 0000001AB754: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001AB758: 02032791
	v_cvt_i32_f32_e32 v165, v171                               // 0000001AB75C: 7F4A11AB
	v_dual_add_f32 v120, 1.0, v48 :: v_dual_cndmask_b32 v49, 0x7f800000, v113// 0000001AB760: C91260F2 7830E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001AB76C: 7C3CBAFF 42CE8ED0
	.long 0xd71c007a                                           // 0000001AB774: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001AB778: 02034394
	.long 0xd71c0090                                           // 0000001AB77C: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001AB780: 02034795
	.long 0xd41b0005                                           // 0000001AB784: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001AB788: 0202BCFF C2B17218
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001AB790: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001AB794: 7C3CBCFF 42CE8ED0
	.long 0xd71c0074                                           // 0000001AB79C: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001AB7A0: 02034B74
	v_div_scale_f32 v121, null, v120, v120, v56                // 0000001AB7A4: D6FC7C79 04E2F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001AB7AC: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001AB7B0: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v48, 0, v144, vcc_lo                     // 0000001AB7B8: 02612080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001AB7BC: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001AB7C4: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001AB7C8: 7C36C4FF C2B17218
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001AB7D0: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 0000001AB7DC: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001AB7E0: 0202BEFF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001AB7E8: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001AB7F0: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001AB7F8: 7ECE5579
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001AB7FC: BF870253
	v_cndmask_b32_e64 v95, 0x7f800000, v48, s5                 // 0000001AB800: D501005F 001660FF 7F800000
	.long 0xd41b0005                                           // 0000001AB80C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001AB810: 0202C0FF C2B17218
	v_cndmask_b32_e32 v99, 0x7f800000, v112, vcc_lo            // 0000001AB818: 02C6E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001AB820: 7C36C8FF C2B17218
	v_add_f32_e32 v98, 1.0, v98                                // 0000001AB828: 06C4C4F2
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001AB82C: D5010060 0016E8FF 7F800000
	v_add_f32_e32 v95, 1.0, v95                                // 0000001AB838: 06BEBEF2
	v_cndmask_b32_e32 v100, 0x7f800000, v115, vcc_lo           // 0000001AB83C: 02C8E6FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001AB844: 7C36CAFF C2B17218
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001AB84C: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001AB854: 7C36CCFF C2B17218
	v_dual_add_f32 v75, 1.0, v75 :: v_dual_cndmask_b32 v102, 0x7f800000, v118// 0000001AB85C: C91296F2 4B66ECFF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AB868: BF870001
	v_div_scale_f32 v122, null, v75, v75, v57                  // 0000001AB86C: D6FC7C7A 04E6974B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001AB874: 7C36BAFF C2B17218
	v_add_f32_e32 v115, 1.0, v49                               // 0000001AB87C: 06E662F2
	v_fma_f32 v49, -v121, v103, 1.0                            // 0000001AB880: D6130031 23CACF79
	v_div_scale_f32 v118, s4, v57, v75, v57                    // 0000001AB888: D6FC0476 04E69739
	v_rcp_f32_e32 v112, v122                                   // 0000001AB890: 7EE0557A
	v_cndmask_b32_e32 v93, 0x7f800000, v113, vcc_lo            // 0000001AB894: 02BAE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v56, v120, v56               // 0000001AB89C: D6FC6A75 04E2F138
	v_add_f32_e32 v102, 1.0, v102                              // 0000001AB8A4: 06CCCCF2
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001AB8A8: D6FC0574 05BEE76F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB8B0: BF870292
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001AB8B4: D6FC7C77 0542CD66
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001AB8BC: D6130071 23CAE17A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB8C4: BF870092
	v_rcp_f32_e32 v146, v119                                   // 0000001AB8C8: 7F245577
	v_fmac_f32_e32 v112, v113, v112                            // 0000001AB8CC: 56E0E171
	v_fmac_f32_e32 v103, v49, v103                             // 0000001AB8D0: 56CECF31
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001AB8D4: D6FC7C71 05BEE773
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v93, 1.0, v93// 0000001AB8DC: C908BCF2 5E5CBAF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB8E4: BF870193
	v_dual_mul_f32 v144, v118, v112 :: v_dual_mul_f32 v49, v117, v103// 0000001AB8E8: C8C6E176 9030CF75
	v_rcp_f32_e32 v145, v113                                   // 0000001AB8F0: 7F225571
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB8F4: BF870111
	v_fma_f32 v147, -v122, v144, v118                          // 0000001AB8F8: D6130093 25DB217A
	v_fma_f32 v48, -v121, v49, v117                            // 0000001AB900: D6130030 25D66379
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB908: BF870112
	v_dual_add_f32 v99, 1.0, v99 :: v_dual_fmac_f32 v144, v147, v112// 0000001AB90C: C900C6F2 6390E193
	v_fmac_f32_e32 v49, v48, v103                              // 0000001AB914: 5662CF30
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB918: BF870195
	v_fma_f32 v48, -v113, v145, 1.0                            // 0000001AB91C: D6130030 23CB2371
	v_fma_f32 v118, -v122, v144, v118                          // 0000001AB924: D6130076 25DB217A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB92C: BF8700A3
	v_fma_f32 v117, -v121, v49, v117                           // 0000001AB930: D6130075 25D66379
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001AB938: D6130079 23CB2577
	v_dual_fmac_f32 v145, v48, v145 :: v_dual_fmac_f32 v146, v121, v146// 0000001AB940: C8012330 91932579
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001AB948: BF870143
	v_div_fmas_f32 v103, v117, v103, v49                       // 0000001AB94C: D6370067 04C6CF75
	s_mov_b32 vcc_lo, s4                                       // 0000001AB954: BEEA0004
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001AB958: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001AB960: BEEA0002
	v_div_fixup_f32 v56, v103, v120, v56                       // 0000001AB964: D6270038 04E2F167
	v_div_fmas_f32 v49, v109, v91, v70                         // 0000001AB96C: D6370031 051AB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001AB974: BEEA0003
	v_div_fixup_f32 v57, v112, v75, v57                        // 0000001AB978: D6270039 04E69770
	v_div_fmas_f32 v70, v108, v90, v71                         // 0000001AB980: D6370046 051EB56C
	v_div_scale_f32 v71, s2, v80, v102, v80                    // 0000001AB988: D6FC0247 0542CD50
	v_div_fixup_f32 v49, v49, v89, 1.0                         // 0000001AB990: D6270031 03CAB331
	v_add_f32_e32 v90, 1.0, v100                               // 0000001AB998: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 0000001AB99C: 06C0C0F2
	v_div_fixup_f32 v48, v70, v88, 1.0                         // 0000001AB9A0: D6270030 03CAB146
	v_dual_add_f32 v70, 1.0, v101 :: v_dual_mul_f32 v89, v71, v146// 0000001AB9A8: C906CAF2 46592547
	v_mul_f32_e32 v88, v116, v145                              // 0000001AB9B0: 10B12374
	v_mul_f32_e32 v103, v50, v49                               // 0000001AB9B4: 10CE6332
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AB9B8: BF870004
	v_mul_f32_e32 v59, v59, v48                                // 0000001AB9BC: 1076613B
	.long 0x7e9e39b8                                           // 0000001AB9C0: 7E9E39B8
	v_fma_f32 v101, -v119, v89, v71                            // 0000001AB9C4: D6130065 251EB377
	v_mul_f32_e32 v58, v58, v49                                // 0000001AB9CC: 1074633A
	v_fma_f32 v91, -v113, v88, v116                            // 0000001AB9D0: D613005B 25D2B171
	v_div_scale_f32 v108, null, v99, v99, v59                  // 0000001AB9D8: D6FC7C6C 04EEC763
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001AB9E0: D6FC7C75 059EBB5D
	v_fmac_f32_e32 v89, v101, v146                             // 0000001AB9E8: 56B32565
	v_div_scale_f32 v100, null, v98, v98, v58                  // 0000001AB9EC: D6FC7C64 04EAC562
	v_fmac_f32_e32 v88, v91, v145                              // 0000001AB9F4: 56B1235B
	v_rcp_f32_e32 v101, v108                                   // 0000001AB9F8: 7ECA556C
	v_rcp_f32_e32 v112, v117                                   // 0000001AB9FC: 7EE05575
	v_fma_f32 v71, -v119, v89, v71                             // 0000001ABA00: D6130047 251EB377
	v_rcp_f32_e32 v91, v100                                    // 0000001ABA08: 7EB65564
	v_fma_f32 v109, -v113, v88, v116                           // 0000001ABA0C: D613006D 25D2B171
	v_div_scale_f32 v116, vcc_lo, v58, v98, v58                // 0000001ABA14: D6FC6A74 04EAC53A
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001ABA1C: D6FC047A 059EBB67
	.long 0x7e9039b9                                           // 0000001ABA24: 7E9039B9
	v_dual_mul_f32 v42, v42, v49 :: v_dual_and_b32 v79, 1, v79 // 0000001ABA28: C8E4632A 2A4E9E81
	v_dual_mul_f32 v34, v34, v49 :: v_dual_mul_f32 v35, v35, v48// 0000001ABA30: C8C66322 22226123
	v_mul_f32_e32 v27, v27, v48                                // 0000001ABA38: 1036611B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABA3C: BF870215
	v_fma_f32 v50, -v100, v91, 1.0                             // 0000001ABA40: D6130032 23CAB764
	v_add3_u32 v56, v56, v79, 0x7fff                           // 0000001ABA48: D6550038 03FE9F38 00007FFF
	v_dual_mul_f32 v26, v26, v49 :: v_dual_mul_f32 v19, v19, v48// 0000001ABA54: C8C6631A 1A126113
	v_mul_f32_e32 v18, v18, v49                                // 0000001ABA5C: 10246312
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ABA60: BF870004
	v_fmac_f32_e32 v91, v50, v91                               // 0000001ABA64: 56B6B732
	v_div_scale_f32 v50, s3, v59, v99, v59                     // 0000001ABA68: D6FC0332 04EEC73B
	v_mul_f32_e32 v113, v51, v48                               // 0000001ABA70: 10E26133
	v_fma_f32 v51, -v108, v101, 1.0                            // 0000001ABA74: D6130033 23CACB6C
	v_dual_mul_f32 v11, v11, v48 :: v_dual_mul_f32 v10, v10, v49// 0000001ABA7C: C8C6610B 0B0A630A
	v_dual_mul_f32 v2, v2, v49 :: v_dual_mul_f32 v3, v3, v48   // 0000001ABA84: C8C66302 02026103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABA8C: BF870093
	v_fmac_f32_e32 v101, v51, v101                             // 0000001ABA90: 56CACB33
	v_mul_f32_e32 v118, v50, v101                              // 0000001ABA94: 10ECCB32
	v_div_scale_f32 v75, null, v94, v94, v113                  // 0000001ABA98: D6FC7C4B 05C6BD5E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ABAA0: BF870112
	v_fma_f32 v121, -v108, v118, v50                           // 0000001ABAA4: D6130079 24CAED6C
	v_rcp_f32_e32 v119, v75                                    // 0000001ABAAC: 7EEE554B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ABAB0: BF870121
	v_dual_fmac_f32 v118, v121, v101 :: v_dual_mul_f32 v51, v116, v91// 0000001ABAB4: C806CB79 7632B774
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001ABABC: D6FC0679 05C6BD71
	v_fma_f32 v50, -v108, v118, v50                            // 0000001ABAC4: D6130032 24CAED6C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ABACC: BF870293
	v_fma_f32 v120, -v100, v51, v116                           // 0000001ABAD0: D6130078 25D26764
	v_fma_f32 v144, -v75, v119, 1.0                            // 0000001ABAD8: D6130090 23CAEF4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABAE0: BF8701A2
	v_fmac_f32_e32 v51, v120, v91                              // 0000001ABAE4: 5666B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001ABAE8: D6130078 23CAE175
	v_fmac_f32_e32 v119, v144, v119                            // 0000001ABAF0: 56EEEF90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABAF4: BF870193
	v_fma_f32 v100, -v100, v51, v116                           // 0000001ABAF8: D6130064 25D26764
	v_fmac_f32_e32 v112, v120, v112                            // 0000001ABB00: 56E0E178
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001ABB04: BF870142
	v_div_fmas_f32 v91, v100, v91, v51                         // 0000001ABB08: D637005B 04CEB764
	s_mov_b32 vcc_lo, s3                                       // 0000001ABB10: BEEA0003
	v_div_fmas_f32 v100, v50, v101, v118                       // 0000001ABB14: D6370064 05DACB32
	s_mov_b32 vcc_lo, s0                                       // 0000001ABB1C: BEEA0000
	v_div_fixup_f32 v58, v91, v98, v58                         // 0000001ABB20: D627003A 04EAC55B
	v_div_fmas_f32 v50, v107, v85, v142                        // 0000001ABB28: D6370032 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001ABB30: BEEA0001
	v_div_fixup_f32 v59, v100, v99, v59                        // 0000001ABB34: D627003B 04EEC764
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001ABB3C: D6370054 063EA96E
	.long 0x7e9a39ba                                           // 0000001ABB44: 7E9A39BA
	v_div_fixup_f32 v51, v50, v83, 1.0                         // 0000001ABB48: D6270033 03CAA732
	v_mul_f32_e32 v83, v122, v112                              // 0000001ABB50: 10A6E17A
	v_and_b32_e32 v85, 1, v72                                  // 0000001ABB54: 36AA9081
	v_div_fixup_f32 v50, v84, v81, 1.0                         // 0000001ABB58: D6270032 03CAA354
	v_mul_f32_e32 v81, v121, v119                              // 0000001ABB60: 10A2EF79
	v_mul_f32_e32 v60, v60, v51                                // 0000001ABB64: 1078673C
	v_mul_f32_e32 v52, v52, v51                                // 0000001ABB68: 10686734
	v_fma_f32 v79, -v117, v83, v122                            // 0000001ABB6C: D613004F 25EAA775
	v_mul_f32_e32 v61, v61, v50                                // 0000001ABB74: 107A653D
	v_fma_f32 v84, -v75, v81, v121                             // 0000001ABB78: D6130054 25E6A34B
	v_add3_u32 v57, v57, v85, 0x7fff                           // 0000001ABB80: D6550039 03FEAB39 00007FFF
	v_div_scale_f32 v85, null, v90, v90, v60                   // 0000001ABB8C: D6FC7C55 04F2B55A
	v_fmac_f32_e32 v83, v79, v112                              // 0000001ABB94: 56A6E14F
	v_div_scale_f32 v79, null, v70, v70, v61                   // 0000001ABB98: D6FC7C4F 04F68D46
	v_fmac_f32_e32 v81, v84, v119                              // 0000001ABBA0: 56A2EF54
	s_clause 0x1                                               // 0000001ABBA4: BF850001
	global_store_d16_hi_b16 v[6:7], v56, off                   // 0000001ABBA8: DC960000 007C3806
	global_store_d16_hi_b16 v[6:7], v57, off offset:1024       // 0000001ABBB0: DC960400 007C3906
	v_rcp_f32_e32 v84, v85                                     // 0000001ABBB8: 7EA85555
	v_div_scale_f32 v99, vcc_lo, v60, v90, v60                 // 0000001ABBBC: D6FC6A63 04F2B53C
	v_rcp_f32_e32 v91, v79                                     // 0000001ABBC4: 7EB6554F
	v_fma_f32 v57, -v75, v81, v121                             // 0000001ABBC8: D6130039 25E6A34B
	v_div_scale_f32 v100, null, v95, v95, v52                  // 0000001ABBD0: D6FC7C64 04D2BF5F
	.long 0x7e9039bb                                           // 0000001ABBD8: 7E9039BB
	v_and_b32_e32 v77, 1, v77                                  // 0000001ABBDC: 369A9A81
	v_fma_f32 v56, -v117, v83, v122                            // 0000001ABBE0: D6130038 25EAA775
	v_mul_f32_e32 v53, v53, v50                                // 0000001ABBE8: 106A6535
	v_rcp_f32_e32 v107, v100                                   // 0000001ABBEC: 7ED65564
	v_fma_f32 v75, -v85, v84, 1.0                              // 0000001ABBF0: D613004B 23CAA955
	v_add3_u32 v58, v58, v77, 0x7fff                           // 0000001ABBF8: D655003A 03FE9B3A 00007FFF
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001ABC04: D6130062 23CAB74F
	v_div_scale_f32 v116, null, v96, v96, v53                  // 0000001ABC0C: D6FC7C74 04D6C160
	v_div_scale_f32 v110, s1, v52, v95, v52                    // 0000001ABC14: D6FC016E 04D2BF34
	v_fmac_f32_e32 v84, v75, v84                               // 0000001ABC1C: 56A8A94B
	v_div_scale_f32 v75, s0, v61, v70, v61                     // 0000001ABC20: D6FC004B 04F68D3D
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v72// 0000001ABC28: C824B762 5B629081
	global_store_d16_hi_b16 v[14:15], v58, off                 // 0000001ABC30: DC960000 007C3A0E
	v_mul_f32_e32 v101, v99, v84                               // 0000001ABC38: 10CAA963
	v_fma_f32 v58, -v100, v107, 1.0                            // 0000001ABC3C: D613003A 23CAD764
	v_mul_f32_e32 v108, v75, v91                               // 0000001ABC44: 10D8B74B
	v_add3_u32 v59, v59, v98, 0x7fff                           // 0000001ABC48: D655003B 03FEC53B 00007FFF
	v_dual_mul_f32 v43, v43, v48 :: v_dual_mul_f32 v44, v44, v51// 0000001ABC54: C8C6612B 2B2C672C
	v_fma_f32 v77, -v85, v101, v99                             // 0000001ABC5C: D613004D 258ECB55
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ABC64: BF870004
	v_fma_f32 v117, -v79, v108, v75                            // 0000001ABC68: D6130075 252ED94F
	global_store_d16_hi_b16 v[22:23], v59, off                 // 0000001ABC70: DC960000 007C3B16
	v_fmac_f32_e32 v107, v58, v107                             // 0000001ABC78: 56D6D73A
	v_dual_mul_f32 v36, v36, v51 :: v_dual_fmac_f32 v101, v77, v84// 0000001ABC7C: C8C06724 2464A94D
	v_fmac_f32_e32 v108, v117, v91                             // 0000001ABC84: 56D8B775
	v_rcp_f32_e32 v77, v116                                    // 0000001ABC88: 7E9A5574
	v_mul_f32_e32 v28, v28, v51                                // 0000001ABC8C: 1038671C
	v_dual_mul_f32 v16, v16, v65 :: v_dual_mul_f32 v21, v21, v50// 0000001ABC90: C8C68310 10146515
	v_fma_f32 v59, -v85, v101, v99                             // 0000001ABC98: D613003B 258ECB55
	v_fma_f32 v58, -v79, v108, v75                             // 0000001ABCA0: D613003A 252ED94F
	s_waitcnt vmcnt(23)                                        // 0000001ABCA8: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001ABCAC: 309F1290
	v_dual_mul_f32 v41, v41, v64 :: v_dual_mul_f32 v20, v20, v51// 0000001ABCB0: C8C68129 29146714
	v_div_fmas_f32 v59, v59, v84, v101                         // 0000001ABCB8: D637003B 0596A93B
	s_mov_b32 vcc_lo, s0                                       // 0000001ABCC0: BEEA0000
	v_mul_f32_e32 v13, v13, v50                                // 0000001ABCC4: 101A650D
	v_div_fmas_f32 v58, v58, v91, v108                         // 0000001ABCC8: D637003A 05B2B73A
	s_mov_b32 vcc_lo, s2                                       // 0000001ABCD0: BEEA0002
	v_div_fixup_f32 v59, v59, v90, v60                         // 0000001ABCD4: D627003B 04F2B53B
	v_div_fmas_f32 v71, v71, v146, v89                         // 0000001ABCDC: D6370047 05672547
	s_mov_b32 vcc_lo, s5                                       // 0000001ABCE4: BEEA0005
	v_div_fixup_f32 v58, v58, v70, v61                         // 0000001ABCE8: D627003A 04F68D3A
	v_div_fmas_f32 v60, v109, v145, v88                        // 0000001ABCF0: D637003C 0563236D
	s_mov_b32 vcc_lo, s4                                       // 0000001ABCF8: BEEA0004
	v_div_fixup_f32 v61, v71, v102, v80                        // 0000001ABCFC: D627003D 0542CD47
	v_div_fmas_f32 v56, v56, v112, v83                         // 0000001ABD04: D6370038 054EE138
	.long 0x7e9039ba                                           // 0000001ABD0C: 7E9039BA
	v_div_fixup_f32 v60, v60, v115, v111                       // 0000001ABD10: D627003C 05BEE73C
	.long 0x7e9839bb                                           // 0000001ABD18: 7E9839BB
	.long 0x7e9439bd                                           // 0000001ABD1C: 7E9439BD
	v_div_fixup_f32 v56, v56, v93, v103                        // 0000001ABD20: D6270038 059EBB38
	v_and_b32_e32 v70, 1, v72                                  // 0000001ABD28: 368C9081
	.long 0x7e9039bc                                           // 0000001ABD2C: 7E9039BC
	s_mov_b32 vcc_lo, s6                                       // 0000001ABD30: BEEA0006
	v_and_b32_e32 v71, 1, v76                                  // 0000001ABD34: 368E9881
	.long 0x7e9239b8                                           // 0000001ABD38: 7E9239B8
	v_add3_u32 v58, v58, v70, 0x7fff                           // 0000001ABD3C: D655003A 03FE8D3A 00007FFF
	v_and_b32_e32 v75, 1, v72                                  // 0000001ABD48: 36969081
	v_and_b32_e32 v74, 1, v74                                  // 0000001ABD4C: 36949481
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001ABD50: D655003B 03FE8F3B 00007FFF
	v_and_b32_e32 v70, 1, v73                                  // 0000001ABD5C: 368C9281
	v_div_fmas_f32 v57, v57, v119, v81                         // 0000001ABD60: D6370039 0546EF39
	v_add3_u32 v60, v60, v75, 0x7fff                           // 0000001ABD68: D655003C 03FE973C 00007FFF
	v_add3_u32 v61, v61, v74, 0x7fff                           // 0000001ABD74: D655003D 03FE953D 00007FFF
	s_clause 0x3                                               // 0000001ABD80: BF850003
	global_store_d16_hi_b16 v[30:31], v59, off                 // 0000001ABD84: DC960000 007C3B1E
	global_store_d16_hi_b16 v[38:39], v58, off                 // 0000001ABD8C: DC960000 007C3A26
	global_store_d16_hi_b16 v[6:7], v60, off offset:32         // 0000001ABD94: DC960020 007C3C06
	global_store_d16_hi_b16 v[46:47], v61, off offset:32       // 0000001ABD9C: DC960020 007C3D2E
	v_div_fixup_f32 v57, v57, v94, v113                        // 0000001ABDA4: D6270039 05C6BD39
	v_fma_f32 v59, -v116, v77, 1.0                             // 0000001ABDAC: D613003B 23CA9B74
	v_add_f32_e32 v60, v114, v151                              // 0000001ABDB4: 06792F72
	v_fma_f32 v71, 0xbfb8aa3b, v97, -v153                      // 0000001ABDB8: D6130047 8666C2FF BFB8AA3B
	v_rndne_f32_e32 v73, v153                                  // 0000001ABDC4: 7E924799
	.long 0x7e9039b9                                           // 0000001ABDC8: 7E9039B9
	v_fmac_f32_e32 v77, v59, v77                               // 0000001ABDCC: 569A9B3B
	v_exp_f32_e32 v59, v60                                     // 0000001ABDD0: 7E764B3C
	v_div_scale_f32 v60, s0, v53, v96, v53                     // 0000001ABDD4: D6FC003C 04D6C135
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001ABDDC: BF870233
	v_dual_fmac_f32 v71, 0xb2a5705f, v97 :: v_dual_and_b32 v58, 1, v72// 0000001ABDE0: C824C2FF 473A9081 B2A5705F
	v_sub_f32_e32 v74, v153, v73                               // 0000001ABDEC: 08949399
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001ABDF0: 7C3CA4FF 42CE8ED0
	v_mul_f32_e32 v76, v60, v77                                // 0000001ABDF8: 10989B3C
	v_add3_u32 v56, v56, v70, 0x7fff                           // 0000001ABDFC: D6550038 03FE8D38 00007FFF
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001ABE08: D6550039 03FE7539 00007FFF
	v_cvt_i32_f32_e32 v58, v152                                // 0000001ABE14: 7E741198
	v_add_f32_e32 v71, v74, v71                                // 0000001ABE18: 068E8F4A
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001ABE1C: 10A09EFF BFB8AA3B
	s_clause 0x1                                               // 0000001ABE24: BF850001
	global_store_d16_hi_b16 v[14:15], v56, off offset:32       // 0000001ABE28: DC960020 007C380E
	global_store_d16_hi_b16 v[22:23], v57, off offset:32       // 0000001ABE30: DC960020 007C3916
	.long 0xd71c003a                                           // 0000001ABE38: D71C003A
	v_cndmask_b32_e32 v1, v59, v58, vcc_lo                     // 0000001ABE3C: 0202753B
	v_fma_f32 v59, -v116, v76, v60                             // 0000001ABE40: D613003B 24F29974
	v_exp_f32_e32 v70, v71                                     // 0000001ABE48: 7E8C4B47
	v_rndne_f32_e32 v83, v80                                   // 0000001ABE4C: 7EA64750
	v_mul_f32_e32 v12, v12, v51                                // 0000001ABE50: 1018670C
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001ABE54: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001ABE58: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v59, v77                               // 0000001ABE60: 56989B3B
	v_cvt_i32_f32_e32 v59, v73                                 // 0000001ABE64: 7E761149
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001ABE68: D6130052 85429EFF BFB8AA3B
	v_sub_f32_e32 v80, v80, v83                                // 0000001ABE74: 08A0A750
	v_dual_cndmask_b32 v58, 0x7f800000, v58 :: v_dual_mul_f32 v61, v110, v107// 0000001ABE78: CA4674FF 3A3CD76E 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ABE84: BF8701B4
	.long 0xd71c003b                                           // 0000001ABE88: D71C003B
	v_cndmask_b32_e32 v1, v70, v59, vcc_lo                     // 0000001ABE8C: 02027746
	s_mov_b32 vcc_lo, s1                                       // 0000001ABE90: BEEA0001
	v_fma_f32 v60, -v116, v76, v60                             // 0000001ABE94: D613003C 24F29974
	v_add_f32_e32 v58, 1.0, v58                                // 0000001ABE9C: 067474F2
	v_fma_f32 v75, -v100, v61, v110                            // 0000001ABEA0: D613004B 25BA7B64
	v_dual_mul_f32 v4, v4, v51 :: v_dual_mul_f32 v5, v5, v50   // 0000001ABEA8: C8C66704 04046505
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABEB0: BF870093
	v_div_scale_f32 v70, null, v58, v58, v40                   // 0000001ABEB4: D6FC7C46 04A2753A
	v_rcp_f32_e32 v56, v70                                     // 0000001ABEBC: 7E705546
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABEC0: BF870095
	v_fma_f32 v73, -v70, v56, 1.0                              // 0000001ABEC4: D6130049 23CA7146
	v_fmac_f32_e32 v56, v73, v56                               // 0000001ABECC: 56707149
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001ABED0: 56A49EFF B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABED8: BF870091
	v_dual_fmac_f32 v61, v75, v107 :: v_dual_add_f32 v80, v80, v82// 0000001ABEDC: C808D74B 3D50A550
	v_fma_f32 v71, -v100, v61, v110                            // 0000001ABEE4: D6130047 25BA7B64
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ABEEC: BF8701B1
	v_div_fmas_f32 v61, v71, v107, v61                         // 0000001ABEF0: D637003D 04F6D747
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001ABEF8: 7C3CC2FF 42CE8ED0
	.long 0x7f8e39c8                                           // 0000001ABF00: 7F8E39C8
	v_div_fixup_f32 v52, v61, v95, v52                         // 0000001ABF04: D6270034 04D2BF3D
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001ABF0C: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001ABF10: BEEA0000
	v_div_fmas_f32 v60, v60, v77, v76                          // 0000001ABF14: D637003C 05329B3C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001ABF1C: 7C36C2FF C2B17218
	.long 0x7e8e39b4                                           // 0000001ABF24: 7E8E39B4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001ABF28: BF870233
	v_div_fixup_f32 v53, v60, v96, v53                         // 0000001ABF2C: D6270035 04D6C13C
	v_dual_cndmask_b32 v59, 0x7f800000, v59 :: v_dual_lshlrev_b32 v60, 16, v138// 0000001ABF34: CA6276FF 3B3D1490 7F800000
	v_div_scale_f32 v73, vcc_lo, v40, v58, v40                 // 0000001ABF40: D6FC6A49 04A27528
	v_and_b32_e32 v71, 1, v71                                  // 0000001ABF48: 368E8E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABF4C: BF870214
	.long 0x7e9039b5                                           // 0000001ABF50: 7E9039B5
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001ABF54: 107A78FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001ABF5C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001ABF60: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABF68: BF870214
	v_add3_u32 v52, v52, v71, 0x7fff                           // 0000001ABF6C: D6550034 03FE8F34 00007FFF
	v_and_b32_e32 v77, 1, v72                                  // 0000001ABF78: 369A9081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ABF7C: BF870004
	v_fma_f32 v75, 0xbfb8aa3b, v60, -v61                       // 0000001ABF80: D613004B 84F678FF BFB8AA3B
	v_rndne_f32_e32 v76, v61                                   // 0000001ABF8C: 7E98473D
	global_store_d16_hi_b16 v[30:31], v52, off offset:32       // 0000001ABF90: DC960020 007C341E
	v_add3_u32 v53, v53, v77, 0x7fff                           // 0000001ABF98: D6550035 03FE9B35 00007FFF
	v_fmac_f32_e32 v75, 0xb2a5705f, v60                        // 0000001ABFA4: 569678FF B2A5705F
	v_sub_f32_e32 v61, v61, v76                                // 0000001ABFAC: 087A993D
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001ABFB0: 7E98114C
	global_store_d16_hi_b16 v[38:39], v53, off offset:32       // 0000001ABFB4: DC960020 007C3526
	v_add_f32_e32 v61, v61, v75                                // 0000001ABFBC: 067A973D
	v_mul_f32_e32 v75, v73, v56                                // 0000001ABFC0: 10967149
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABFC4: BF870092
	v_exp_f32_e32 v61, v61                                     // 0000001ABFC8: 7E7A4B3D
	v_fma_f32 v77, -v70, v75, v73                              // 0000001ABFCC: D613004D 25269746
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ABFD4: BF870291
	v_fmac_f32_e32 v75, v77, v56                               // 0000001ABFD8: 5696714D
	.long 0xd71c003d                                           // 0000001ABFDC: D71C003D
	v_cndmask_b32_e32 v1, v61, v76, vcc_lo                     // 0000001ABFE0: 0202993D
	v_exp_f32_e32 v76, v80                                     // 0000001ABFE4: 7E984B50
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ABFE8: BF870112
	v_fma_f32 v70, -v70, v75, v73                              // 0000001ABFEC: D6130046 25269746
	v_cndmask_b32_e64 v61, 0, v61, s1                          // 0000001ABFF4: D501003D 00067A80
	.long 0xd41b0001                                           // 0000001ABFFC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001AC000: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC008: BF8701A3
	v_div_fmas_f32 v56, v70, v56, v75                          // 0000001AC00C: D6370038 052E7146
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001AC014: 7C3C9EFF 42CE8ED0
	v_cndmask_b32_e64 v60, 0x7f800000, v61, s1                 // 0000001AC01C: D501003C 00067AFF 7F800000
	v_add_f32_e32 v59, 1.0, v59                                // 0000001AC028: 067676F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AC02C: BF870224
	v_div_fixup_f32 v40, v56, v58, v40                         // 0000001AC030: D6270028 04A27538
	.long 0x7f7439c8                                           // 0000001AC038: 7F7439C8
	v_add_f32_e32 v60, 1.0, v60                                // 0000001AC03C: 067878F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC040: BF870214
	v_div_scale_f32 v57, null, v59, v59, v41                   // 0000001AC044: D6FC7C39 04A6773B
	.long 0x7e7439a8                                           // 0000001AC04C: 7E7439A8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC050: BF870193
	v_div_scale_f32 v70, null, v60, v60, v42                   // 0000001AC054: D6FC7C46 04AA793C
	v_rcp_f32_e32 v74, v57                                     // 0000001AC05C: 7E945539
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC060: BF870112
	v_and_b32_e32 v58, 1, v58                                  // 0000001AC064: 36747481
	v_rcp_f32_e32 v52, v70                                     // 0000001AC068: 7E685546
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001AC06C: BF870311
	v_add3_u32 v40, v40, v58, 0x7fff                           // 0000001AC070: D6550028 03FE7528 00007FFF
	v_fma_f32 v81, -v57, v74, 1.0                              // 0000001AC07C: D6130051 23CA9539
	global_store_d16_hi_b16 v[6:7], v40, off offset:64         // 0000001AC084: DC960040 007C2806
	v_fmac_f32_e32 v74, v81, v74                               // 0000001AC08C: 56949551
	v_div_scale_f32 v81, s0, v41, v59, v41                     // 0000001AC090: D6FC0051 04A67729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC098: BF870091
	v_mul_f32_e32 v84, v81, v74                                // 0000001AC09C: 10A89551
	v_fma_f32 v71, -v57, v84, v81                              // 0000001AC0A0: D6130047 2546A939
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC0A8: BF870121
	v_fmac_f32_e32 v84, v71, v74                               // 0000001AC0AC: 56A89547
	v_cvt_i32_f32_e32 v71, v83                                 // 0000001AC0B0: 7E8E1153
	v_fma_f32 v57, -v57, v84, v81                              // 0000001AC0B4: D6130039 2546A939
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AC0BC: BF8700B2
	.long 0xd71c003d                                           // 0000001AC0C0: D71C003D
	v_cndmask_b32_e32 v1, v76, v71, vcc_lo                     // 0000001AC0C4: 02028F4C
	s_waitcnt vmcnt(11)                                        // 0000001AC0C8: BF892FF7
	v_lshlrev_b32_e32 v76, 16, v139                            // 0000001AC0CC: 30991690
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001AC0D0: 109A98FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AC0D8: BF870001
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001AC0DC: D6130050 853698FF BFB8AA3B
	v_cndmask_b32_e32 v61, 0, v61, vcc_lo                      // 0000001AC0E8: 027A7A80
	s_mov_b32 vcc_lo, s0                                       // 0000001AC0EC: BEEA0000
	v_rndne_f32_e32 v81, v77                                   // 0000001AC0F0: 7EA2474D
	v_div_fmas_f32 v57, v57, v74, v84                          // 0000001AC0F4: D6370039 05529539
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001AC0FC: 7C369EFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC104: BF870193
	v_dual_fmac_f32 v80, 0xb2a5705f, v76 :: v_dual_sub_f32 v77, v77, v81// 0000001AC108: C80A98FF 504CA34D B2A5705F
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001AC114: D6270029 04A67739
	v_lshlrev_b32_e32 v59, 16, v140                            // 0000001AC11C: 30771890
	v_cndmask_b32_e32 v61, 0x7f800000, v61, vcc_lo             // 0000001AC120: 027A7AFF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC128: BF870214
	v_add_f32_e32 v77, v77, v80                                // 0000001AC12C: 069AA14D
	.long 0x7e9039a9                                           // 0000001AC130: 7E9039A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC134: BF8701A4
	v_mul_f32_e32 v56, 0xbfb8aa3b, v59                         // 0000001AC138: 107076FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001AC140: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v59, vcc_lo              // 0000001AC144: 020276FF 42CE8ED0
	v_and_b32_e32 v75, 1, v72                                  // 0000001AC14C: 36969081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC150: BF8701A3
	v_fma_f32 v73, 0xbfb8aa3b, v59, -v56                       // 0000001AC154: D6130049 84E276FF BFB8AA3B
	v_rndne_f32_e32 v74, v56                                   // 0000001AC160: 7E944738
	v_add3_u32 v41, v41, v75, 0x7fff                           // 0000001AC164: D6550029 03FE9729 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001AC170: BF8700C2
	v_dual_fmac_f32 v73, 0xb2a5705f, v59 :: v_dual_sub_f32 v56, v56, v74// 0000001AC174: C80A76FF 49389538 B2A5705F
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001AC180: 7E94114A
	global_store_d16_hi_b16 v[46:47], v41, off offset:64       // 0000001AC184: DC960040 007C292E
	v_add_f32_e32 v56, v56, v73                                // 0000001AC18C: 06709338
	v_exp_f32_e32 v56, v56                                     // 0000001AC190: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AC194: BF8700A5
	.long 0xd71c0038                                           // 0000001AC198: D71C0038
	v_cndmask_b32_e32 v1, v56, v74, vcc_lo                     // 0000001AC19C: 02029538
	v_exp_f32_e32 v74, v77                                     // 0000001AC1A0: 7E944B4D
	v_cndmask_b32_e64 v56, 0, v56, s1                          // 0000001AC1A4: D5010038 00067080
	.long 0xd41b0001                                           // 0000001AC1AC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v59, vcc_lo              // 0000001AC1B0: 020276FF C2B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AC1B8: BF8701B1
	v_cndmask_b32_e64 v56, 0x7f800000, v56, s1                 // 0000001AC1BC: D5010038 000670FF 7F800000
	v_add_f32_e32 v57, 1.0, v61                                // 0000001AC1C8: 06727AF2
	v_fma_f32 v61, -v70, v52, 1.0                              // 0000001AC1CC: D613003D 23CA6946
	v_add_f32_e32 v56, 1.0, v56                                // 0000001AC1D4: 067070F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC1D8: BF870193
	v_div_scale_f32 v53, null, v57, v57, v43                   // 0000001AC1DC: D6FC7C35 04AE7339
	v_fmac_f32_e32 v52, v61, v52                               // 0000001AC1E4: 5668693D
	v_div_scale_f32 v61, vcc_lo, v42, v60, v42                 // 0000001AC1E8: D6FC6A3D 04AA792A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC1F0: BF870214
	v_div_scale_f32 v59, null, v56, v56, v44                   // 0000001AC1F4: D6FC7C3B 04B27138
	v_rcp_f32_e32 v71, v53                                     // 0000001AC1FC: 7E8E5535
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC200: BF870092
	v_mul_f32_e32 v73, v61, v52                                // 0000001AC204: 1092693D
	v_fma_f32 v75, -v70, v73, v61                              // 0000001AC208: D613004B 24F69346
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC210: BF870115
	v_fma_f32 v79, -v53, v71, 1.0                              // 0000001AC214: D613004F 23CA8F35
	v_fmac_f32_e32 v73, v75, v52                               // 0000001AC21C: 5692694B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC220: BF8701A2
	v_fmac_f32_e32 v71, v79, v71                               // 0000001AC224: 568E8F4F
	v_div_scale_f32 v79, s0, v43, v57, v43                     // 0000001AC228: D6FC004F 04AE732B
	v_fma_f32 v61, -v70, v73, v61                              // 0000001AC230: D613003D 24F69346
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC238: BF870112
	v_mul_f32_e32 v82, v79, v71                                // 0000001AC23C: 10A48F4F
	v_div_fmas_f32 v52, v61, v52, v73                          // 0000001AC240: D6370034 0526693D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001AC248: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC250: BF870193
	v_fma_f32 v58, -v53, v82, v79                              // 0000001AC254: D613003A 253EA535
	v_div_fixup_f32 v42, v52, v60, v42                         // 0000001AC25C: D627002A 04AA7934
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC264: BF870122
	v_fmac_f32_e32 v82, v58, v71                               // 0000001AC268: 56A48F3A
	v_cvt_i32_f32_e32 v58, v81                                 // 0000001AC26C: 7E741151
	v_fma_f32 v53, -v53, v82, v79                              // 0000001AC270: D6130035 253EA535
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AC278: BF870132
	.long 0xd71c003a                                           // 0000001AC27C: D71C003A
	v_cndmask_b32_e32 v1, v74, v58, vcc_lo                     // 0000001AC280: 0202754A
	s_waitcnt vmcnt(5)                                         // 0000001AC284: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001AC288: 30951A90
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001AC28C: 02747480
	s_mov_b32 vcc_lo, s0                                       // 0000001AC290: BEEA0000
	v_div_fmas_f32 v53, v53, v71, v82                          // 0000001AC294: D6370035 054A8F35
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001AC29C: 7C3698FF C2B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC2A4: BF870002
	v_div_fixup_f32 v40, v53, v57, v43                         // 0000001AC2A8: D6270028 04AE7335
	v_mul_f32_e32 v43, v45, v50                                // 0000001AC2B0: 1056652D
	v_rcp_f32_e32 v45, v59                                     // 0000001AC2B4: 7E5A553B
	v_lshlrev_b32_e32 v57, 16, v78                             // 0000001AC2B8: 30729C90
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001AC2BC: 027474FF 7F800000
	.long 0x7e9039a8                                           // 0000001AC2C4: 7E9039A8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC2C8: BF8701A3
	v_mul_f32_e32 v52, 0xbfb8aa3b, v57                         // 0000001AC2CC: 106872FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001AC2D4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v57, vcc_lo              // 0000001AC2D8: 020272FF 42CE8ED0
	v_and_b32_e32 v73, 1, v72                                  // 0000001AC2E0: 36929081
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC2E4: BF870215
	v_fma_f32 v60, -v59, v45, 1.0                              // 0000001AC2E8: D613003C 23CA5B3B
	v_fma_f32 v70, 0xbfb8aa3b, v57, -v52                       // 0000001AC2F0: D6130046 84D272FF BFB8AA3B
	v_rndne_f32_e32 v71, v52                                   // 0000001AC2FC: 7E8E4734
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC300: BF870214
	v_add3_u32 v40, v40, v73, 0x7fff                           // 0000001AC304: D6550028 03FE9328 00007FFF
	v_fmac_f32_e32 v45, v60, v45                               // 0000001AC310: 565A5B3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC314: BF870214
	v_fmac_f32_e32 v70, 0xb2a5705f, v57                        // 0000001AC318: 568C72FF B2A5705F
	v_sub_f32_e32 v52, v52, v71                                // 0000001AC320: 08688F34
	v_div_scale_f32 v60, vcc_lo, v44, v56, v44                 // 0000001AC324: D6FC6A3C 04B2712C
	v_cvt_i32_f32_e32 v71, v71                                 // 0000001AC32C: 7E8E1147
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC330: BF870193
	v_add_f32_e32 v52, v52, v70                                // 0000001AC334: 06688D34
	v_mul_f32_e32 v70, v60, v45                                // 0000001AC338: 108C5B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC33C: BF870092
	v_exp_f32_e32 v52, v52                                     // 0000001AC340: 7E684B34
	v_fma_f32 v73, -v59, v70, v60                              // 0000001AC344: D6130049 24F28D3B
	v_add_f32_e32 v53, 1.0, v58                                // 0000001AC34C: 066A74F2
	.long 0x7e7439aa                                           // 0000001AC350: 7E7439AA
	.long 0x7f7439c8                                           // 0000001AC354: 7F7439C8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC358: BF870214
	v_fmac_f32_e32 v70, v73, v45                               // 0000001AC35C: 568C5B49
	v_div_scale_f32 v41, null, v53, v53, v43                   // 0000001AC360: D6FC7C29 04AE6B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC368: BF870293
	v_and_b32_e32 v58, 1, v58                                  // 0000001AC36C: 36747481
	.long 0xd71c0034                                           // 0000001AC370: D71C0034
	v_cndmask_b32_e32 v1, v52, v71, vcc_lo                     // 0000001AC374: 02028F34
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC378: BF870214
	v_fma_f32 v59, -v59, v70, v60                              // 0000001AC37C: D613003B 24F28D3B
	v_rcp_f32_e32 v61, v41                                     // 0000001AC384: 7E7A5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC388: BF870193
	v_add3_u32 v42, v42, v58, 0x7fff                           // 0000001AC38C: D655002A 03FE752A 00007FFF
	v_cndmask_b32_e64 v52, 0, v52, s1                          // 0000001AC398: D5010034 00066880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AC3A0: BF870003
	v_div_fmas_f32 v45, v59, v45, v70                          // 0000001AC3A4: D637002D 051A5B3B
	.long 0xd41b0001                                           // 0000001AC3AC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v57, vcc_lo              // 0000001AC3B0: 020272FF C2B17218
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001AC3B8: 7C3C94FF 42CE8ED0
	s_clause 0x1                                               // 0000001AC3C0: BF850001
	global_store_d16_hi_b16 v[14:15], v42, off offset:64       // 0000001AC3C4: DC960040 007C2A0E
	global_store_d16_hi_b16 v[22:23], v40, off offset:64       // 0000001AC3CC: DC960040 007C2816
	v_div_fixup_f32 v44, v45, v56, v44                         // 0000001AC3D4: D627002C 04B2712D
	.long 0x7f7039c8                                           // 0000001AC3DC: 7F7039C8
	v_fma_f32 v76, -v41, v61, 1.0                              // 0000001AC3E0: D613004C 23CA7B29
	v_cndmask_b32_e64 v52, 0x7f800000, v52, s1                 // 0000001AC3E8: D5010034 000668FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AC3F4: BF870224
	.long 0x7e7039ac                                           // 0000001AC3F8: 7E7039AC
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001AC3FC: 109694FF BFB8AA3B
	v_fmac_f32_e32 v61, v76, v61                               // 0000001AC404: 567A7B4C
	v_div_scale_f32 v76, s0, v43, v53, v43                     // 0000001AC408: D6FC004C 04AE6B2B
	v_add_f32_e32 v52, 1.0, v52                                // 0000001AC410: 066868F2
	v_and_b32_e32 v56, 1, v56                                  // 0000001AC414: 36707081
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001AC418: D613004D 852E94FF BFB8AA3B
	v_rndne_f32_e32 v78, v75                                   // 0000001AC424: 7E9C474B
	v_mul_f32_e32 v79, v76, v61                                // 0000001AC428: 109E7B4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC42C: BF870214
	v_add3_u32 v44, v44, v56, 0x7fff                           // 0000001AC430: D655002C 03FE712C 00007FFF
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001AC43C: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC444: BF870214
	v_sub_f32_e32 v75, v75, v78                                // 0000001AC448: 08969D4B
	v_fma_f32 v58, -v41, v79, v76                              // 0000001AC44C: D613003A 25329F29
	global_store_d16_hi_b16 v[30:31], v44, off offset:64       // 0000001AC454: DC960040 007C2C1E
	v_dual_add_f32 v75, v75, v77 :: v_dual_lshlrev_b32 v44, 16, v135// 0000001AC45C: C9229B4B 4B2D0E90
	v_fmac_f32_e32 v79, v58, v61                               // 0000001AC464: 569E7B3A
	v_cvt_i32_f32_e32 v58, v78                                 // 0000001AC468: 7E74114E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC46C: BF870113
	v_exp_f32_e32 v71, v75                                     // 0000001AC470: 7E8E4B4B
	v_fma_f32 v41, -v41, v79, v76                              // 0000001AC474: D6130029 25329F29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AC47C: BF8701B5
	.long 0xd71c0039                                           // 0000001AC480: D71C0039
	v_cndmask_b32_e32 v1, v71, v58, vcc_lo                     // 0000001AC484: 02027547
	v_div_scale_f32 v58, null, v52, v52, v32                   // 0000001AC488: D6FC7C3A 04826934
	v_lshlrev_b32_e32 v71, 16, v132                            // 0000001AC490: 308F0890
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000001AC494: 02727280
	s_mov_b32 vcc_lo, s0                                       // 0000001AC498: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001AC49C: BF8701C3
	v_rcp_f32_e32 v42, v58                                     // 0000001AC4A0: 7E54553A
	v_div_fmas_f32 v41, v41, v61, v79                          // 0000001AC4A4: D6370029 053E7B29
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001AC4AC: 7C3694FF C2B17218
	v_mul_f32_e32 v73, 0xbfb8aa3b, v71                         // 0000001AC4B4: 10928EFF BFB8AA3B
	v_div_fixup_f32 v41, v41, v53, v43                         // 0000001AC4BC: D6270029 04AE6B29
	v_lshlrev_b32_e32 v53, 16, v133                            // 0000001AC4C4: 306B0A90
	v_cndmask_b32_e32 v57, 0x7f800000, v57, vcc_lo             // 0000001AC4C8: 027272FF 7F800000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AC4D0: BF870004
	v_fma_f32 v75, 0xbfb8aa3b, v71, -v73                       // 0000001AC4D4: D613004B 85268EFF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 0000001AC4E0: 7E984749
	.long 0x7e9039a9                                           // 0000001AC4E4: 7E9039A9
	v_mul_f32_e32 v45, 0xbfb8aa3b, v53                         // 0000001AC4E8: 105A6AFF BFB8AA3B
	v_add_f32_e32 v43, 1.0, v57                                // 0000001AC4F0: 065672F2
	v_fma_f32 v57, -v58, v42, 1.0                              // 0000001AC4F4: D6130039 23CA553A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC4FC: BF870214
	v_dual_fmac_f32 v75, 0xb2a5705f, v71 :: v_dual_and_b32 v70, 1, v72// 0000001AC500: C8248EFF 4B469081 B2A5705F
	v_fma_f32 v60, 0xbfb8aa3b, v53, -v45                       // 0000001AC50C: D613003C 84B66AFF BFB8AA3B
	v_rndne_f32_e32 v61, v45                                   // 0000001AC518: 7E7A472D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AC51C: BF870004
	v_fmac_f32_e32 v42, v57, v42                               // 0000001AC520: 56545539
	v_div_scale_f32 v57, vcc_lo, v32, v52, v32                 // 0000001AC524: D6FC6A39 04826920
	v_add3_u32 v41, v41, v70, 0x7fff                           // 0000001AC52C: D6550029 03FE8D29 00007FFF
	v_fmac_f32_e32 v60, 0xb2a5705f, v53                        // 0000001AC538: 56786AFF B2A5705F
	v_sub_f32_e32 v45, v45, v61                                // 0000001AC540: 085A7B2D
	v_sub_f32_e32 v73, v73, v76                                // 0000001AC544: 08929949
	v_cvt_i32_f32_e32 v61, v61                                 // 0000001AC548: 7E7A113D
	.long 0xd41e0001                                           // 0000001AC54C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v53, vcc_lo              // 0000001AC550: 02026AFF 42CE8ED0
	global_store_d16_hi_b16 v[38:39], v41, off offset:64       // 0000001AC558: DC960040 007C2926
	v_add_f32_e32 v45, v45, v60                                // 0000001AC560: 065A792D
	v_mul_f32_e32 v60, v57, v42                                // 0000001AC564: 10785539
	v_add_f32_e32 v73, v73, v75                                // 0000001AC568: 06929749
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC56C: BF870113
	v_exp_f32_e32 v45, v45                                     // 0000001AC570: 7E5A4B2D
	v_fma_f32 v70, -v58, v60, v57                              // 0000001AC574: D6130046 24E6793A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC57C: BF870291
	v_fmac_f32_e32 v60, v70, v42                               // 0000001AC580: 56785546
	.long 0xd71c002d                                           // 0000001AC584: D71C002D
	v_cndmask_b32_e32 v1, v45, v61, vcc_lo                     // 0000001AC588: 02027B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC58C: BF870122
	v_fma_f32 v57, -v58, v60, v57                              // 0000001AC590: D6130039 24E6793A
	v_exp_f32_e32 v61, v73                                     // 0000001AC598: 7E7A4B49
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 0000001AC59C: D501002D 00065A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC5A4: BF870122
	v_div_fmas_f32 v42, v57, v42, v60                          // 0000001AC5A8: D637002A 04F25539
	.long 0xd41b0001                                           // 0000001AC5B0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v53, vcc_lo              // 0000001AC5B4: 02026AFF C2B17218
	v_div_fixup_f32 v32, v42, v52, v32                         // 0000001AC5BC: D6270020 0482692A
	v_mul_f32_e32 v42, 0xbfb8aa3b, v44                         // 0000001AC5C4: 105458FF BFB8AA3B
	v_mul_f32_e32 v33, v33, v64                                // 0000001AC5CC: 10428121
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001AC5D0: BF8701D4
	v_cndmask_b32_e64 v45, 0x7f800000, v45, s1                 // 0000001AC5D4: D501002D 00065AFF 7F800000
	.long 0x7f6839c8                                           // 0000001AC5E0: 7F6839C8
	.long 0x7e6839a0                                           // 0000001AC5E4: 7E6839A0
	v_fma_f32 v58, 0xbfb8aa3b, v44, -v42                       // 0000001AC5E8: D613003A 84AA58FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001AC5F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001AC5F8: 020258FF 42CE8ED0
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_and_b32 v52, 1, v52 // 0000001AC600: C9245AF2 2D346881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC608: BF8701A3
	v_fmac_f32_e32 v58, 0xb2a5705f, v44                        // 0000001AC60C: 567458FF B2A5705F
	v_div_scale_f32 v40, null, v43, v43, v33                   // 0000001AC614: D6FC7C28 0486572B
	v_add3_u32 v32, v32, v52, 0x7fff                           // 0000001AC61C: D6550020 03FE6920 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AC628: BF8700B2
	v_rcp_f32_e32 v59, v40                                     // 0000001AC62C: 7E765528
	global_store_d16_hi_b16 v[6:7], v32, off offset:96         // 0000001AC630: DC960060 007C2006
	v_fma_f32 v74, -v40, v59, 1.0                              // 0000001AC638: D613004A 23CA7728
	v_fmac_f32_e32 v59, v74, v59                               // 0000001AC640: 5676774A
	v_div_scale_f32 v74, s0, v33, v43, v33                     // 0000001AC644: D6FC004A 04865721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC64C: BF870091
	v_mul_f32_e32 v77, v74, v59                                // 0000001AC650: 109A774A
	v_fma_f32 v56, -v40, v77, v74                              // 0000001AC654: D6130038 252A9B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC65C: BF870121
	v_fmac_f32_e32 v77, v56, v59                               // 0000001AC660: 569A7738
	v_cvt_i32_f32_e32 v56, v76                                 // 0000001AC664: 7E70114C
	v_fma_f32 v40, -v40, v77, v74                              // 0000001AC668: D6130028 252A9B28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AC670: BF870132
	.long 0xd71c0035                                           // 0000001AC674: D71C0035
	v_cndmask_b32_e32 v1, v61, v56, vcc_lo                     // 0000001AC678: 0202713D
	v_lshlrev_b32_e32 v61, 16, v134                            // 0000001AC67C: 307B0C90
	v_div_scale_f32 v56, null, v45, v45, v34                   // 0000001AC680: D6FC7C38 048A5B2D
	v_mul_f32_e32 v70, 0xbfb8aa3b, v61                         // 0000001AC688: 108C7AFF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v71                  // 0000001AC690: 7C3C8EFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC698: BF870002
	v_fma_f32 v73, 0xbfb8aa3b, v61, -v70                       // 0000001AC69C: D6130049 851A7AFF BFB8AA3B
	v_cndmask_b32_e32 v53, 0, v53, vcc_lo                      // 0000001AC6A8: 026A6A80
	s_mov_b32 vcc_lo, s0                                       // 0000001AC6AC: BEEA0000
	v_rndne_f32_e32 v74, v70                                   // 0000001AC6B0: 7E944746
	v_div_fmas_f32 v40, v40, v59, v77                          // 0000001AC6B4: D6370028 05367728
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v71                  // 0000001AC6BC: 7C368EFF C2B17218
	v_rndne_f32_e32 v59, v42                                   // 0000001AC6C4: 7E76472A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC6C8: BF870114
	v_dual_fmac_f32 v73, 0xb2a5705f, v61 :: v_dual_sub_f32 v70, v70, v74// 0000001AC6CC: C80A7AFF 49469546 B2A5705F
	v_dual_cndmask_b32 v53, 0x7f800000, v53 :: v_dual_sub_f32 v42, v42, v59// 0000001AC6D8: CA4A6AFF 352A772A 7F800000
	v_div_fixup_f32 v33, v40, v43, v33                         // 0000001AC6E4: D6270021 04865728
	v_rcp_f32_e32 v40, v56                                     // 0000001AC6EC: 7E505538
	v_cvt_i32_f32_e32 v59, v59                                 // 0000001AC6F0: 7E76113B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC6F4: BF870193
	v_dual_add_f32 v43, 1.0, v53 :: v_dual_add_f32 v42, v42, v58// 0000001AC6F8: C9086AF2 2B2A752A
	.long 0x7e9039a1                                           // 0000001AC700: 7E9039A1
	v_add_f32_e32 v70, v70, v73                                // 0000001AC704: 068C9346
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC708: BF870213
	v_div_scale_f32 v41, null, v43, v43, v35                   // 0000001AC70C: D6FC7C29 048E572B
	v_exp_f32_e32 v42, v42                                     // 0000001AC714: 7E544B2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001AC718: BF870313
	v_and_b32_e32 v60, 1, v72                                  // 0000001AC71C: 36789081
	v_fma_f32 v53, -v56, v40, 1.0                              // 0000001AC720: D6130035 23CA5138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC728: BF870113
	v_rcp_f32_e32 v57, v41                                     // 0000001AC72C: 7E725529
	v_add3_u32 v33, v33, v60, 0x7fff                           // 0000001AC730: D6550021 03FE7921 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001AC73C: BF870322
	v_fmac_f32_e32 v40, v53, v40                               // 0000001AC740: 56505135
	v_div_scale_f32 v53, vcc_lo, v34, v45, v34                 // 0000001AC744: D6FC6A35 048A5B22
	.long 0xd71c002a                                           // 0000001AC74C: D71C002A
	v_cndmask_b32_e32 v1, v42, v59, vcc_lo                     // 0000001AC750: 0202772A
	v_exp_f32_e32 v59, v70                                     // 0000001AC754: 7E764B46
	global_store_d16_hi_b16 v[46:47], v33, off offset:96       // 0000001AC758: DC960060 007C212E
	v_mul_f32_e32 v58, v53, v40                                // 0000001AC760: 10745135
	v_fma_f32 v71, -v41, v57, 1.0                              // 0000001AC764: D6130047 23CA7329
	v_cndmask_b32_e64 v42, 0, v42, s1                          // 0000001AC76C: D501002A 00065480
	.long 0xd41b0001                                           // 0000001AC774: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001AC778: 020258FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC780: BF870214
	v_fma_f32 v60, -v56, v58, v53                              // 0000001AC784: D613003C 24D67538
	v_fmac_f32_e32 v57, v71, v57                               // 0000001AC78C: 56727347
	v_div_scale_f32 v71, s0, v35, v43, v35                     // 0000001AC790: D6FC0047 048E5723
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC798: BF870114
	v_cndmask_b32_e64 v42, 0x7f800000, v42, s1                 // 0000001AC79C: D501002A 000654FF 7F800000
	v_dual_fmac_f32 v58, v60, v40 :: v_dual_mul_f32 v75, v71, v57// 0000001AC7A8: C806513C 3A4A7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC7B0: BF870112
	v_add_f32_e32 v42, 1.0, v42                                // 0000001AC7B4: 065454F2
	v_fma_f32 v53, -v56, v58, v53                              // 0000001AC7B8: D6130035 24D67538
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC7C0: BF870113
	v_fma_f32 v52, -v41, v75, v71                              // 0000001AC7C4: D6130034 251E9729
	v_div_fmas_f32 v40, v53, v40, v58                          // 0000001AC7CC: D6370028 04EA5135
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v61                  // 0000001AC7D4: 7C3C7AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AC7DC: BF870223
	v_fmac_f32_e32 v75, v52, v57                               // 0000001AC7E0: 56967334
	v_cvt_i32_f32_e32 v52, v74                                 // 0000001AC7E4: 7E68114A
	v_div_fixup_f32 v34, v40, v45, v34                         // 0000001AC7E8: D6270022 048A5B28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC7F0: BF870193
	v_fma_f32 v41, -v41, v75, v71                              // 0000001AC7F4: D6130029 251E9729
	.long 0xd71c002c                                           // 0000001AC7FC: D71C002C
	v_cndmask_b32_e32 v1, v59, v52, vcc_lo                     // 0000001AC800: 0202693B
	s_waitcnt vmcnt(4)                                         // 0000001AC804: BF8913F7
	v_lshlrev_b32_e32 v59, 16, v136                            // 0000001AC808: 30771090
	v_div_scale_f32 v52, null, v42, v42, v36                   // 0000001AC80C: D6FC7C34 0492552A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC814: BF870193
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001AC818: 02585880
	v_mul_f32_e32 v60, 0xbfb8aa3b, v59                         // 0000001AC81C: 107876FF BFB8AA3B
	s_mov_b32 vcc_lo, s0                                       // 0000001AC824: BEEA0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC828: BF870121
	v_fma_f32 v70, 0xbfb8aa3b, v59, -v60                       // 0000001AC82C: D6130046 84F276FF BFB8AA3B
	v_rndne_f32_e32 v71, v60                                   // 0000001AC838: 7E8E473C
	v_fmac_f32_e32 v70, 0xb2a5705f, v59                        // 0000001AC83C: 568C76FF B2A5705F
	v_div_fmas_f32 v41, v41, v57, v75                          // 0000001AC844: D6370029 052E7329
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC84C: BF870113
	v_sub_f32_e32 v60, v60, v71                                // 0000001AC850: 08788F3C
	v_div_fixup_f32 v32, v41, v43, v35                         // 0000001AC854: D6270020 048E5729
	v_lshlrev_b32_e32 v43, 16, v86                             // 0000001AC85C: 3056AC90
	v_mul_f32_e32 v35, v37, v50                                // 0000001AC860: 10466525
	v_rcp_f32_e32 v37, v52                                     // 0000001AC864: 7E4A5534
	v_add_f32_e32 v60, v60, v70                                // 0000001AC868: 06788D3C
	.long 0x7e9039a0                                           // 0000001AC86C: 7E9039A0
	v_mul_f32_e32 v40, 0xbfb8aa3b, v43                         // 0000001AC870: 105056FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001AC878: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v43, vcc_lo              // 0000001AC87C: 020256FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC884: BF870193
	v_and_b32_e32 v58, 1, v72                                  // 0000001AC888: 36749081
	v_fma_f32 v56, 0xbfb8aa3b, v43, -v40                       // 0000001AC88C: D6130038 84A256FF BFB8AA3B
	v_rndne_f32_e32 v57, v40                                   // 0000001AC898: 7E724728
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC89C: BF870215
	v_fma_f32 v45, -v52, v37, 1.0                              // 0000001AC8A0: D613002D 23CA4B34
	v_add3_u32 v32, v32, v58, 0x7fff                           // 0000001AC8A8: D6550020 03FE7520 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC8B4: BF870214
	v_fmac_f32_e32 v56, 0xb2a5705f, v43                        // 0000001AC8B8: 567056FF B2A5705F
	v_sub_f32_e32 v40, v40, v57                                // 0000001AC8C0: 08507328
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC8C4: BF8701A4
	v_fmac_f32_e32 v37, v45, v37                               // 0000001AC8C8: 564A4B2D
	v_cvt_i32_f32_e32 v57, v57                                 // 0000001AC8CC: 7E721139
	v_add_f32_e32 v40, v40, v56                                // 0000001AC8D0: 06507128
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v61                  // 0000001AC8D4: 7C367AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AC8DC: BF8700B2
	v_exp_f32_e32 v40, v40                                     // 0000001AC8E0: 7E504B28
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001AC8E4: 025858FF 7F800000
	v_div_scale_f32 v45, vcc_lo, v36, v42, v36                 // 0000001AC8EC: D6FC6A2D 04925524
	v_dual_add_f32 v41, 1.0, v44 :: v_dual_mul_f32 v56, v45, v37// 0000001AC8F4: C90658F2 29384B2D
	.long 0x7e5839a2                                           // 0000001AC8FC: 7E5839A2
	.long 0x7f5839c8                                           // 0000001AC900: 7F5839C8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AC904: BF8701B5
	.long 0xd71c0028                                           // 0000001AC908: D71C0028
	v_cndmask_b32_e32 v1, v40, v57, vcc_lo                     // 0000001AC90C: 02027328
	v_exp_f32_e32 v57, v60                                     // 0000001AC910: 7E724B3C
	v_fma_f32 v58, -v52, v56, v45                              // 0000001AC914: D613003A 24B67134
	v_and_b32_e32 v44, 1, v44                                  // 0000001AC91C: 36585881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AC920: BF870223
	v_cndmask_b32_e64 v40, 0, v40, s1                          // 0000001AC924: D5010028 00065080
	.long 0xd41b0001                                           // 0000001AC92C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v43, vcc_lo              // 0000001AC930: 020256FF C2B17218
	v_fmac_f32_e32 v56, v58, v37                               // 0000001AC938: 56704B3A
	v_div_scale_f32 v33, null, v41, v41, v35                   // 0000001AC93C: D6FC7C21 048E5329
	v_add3_u32 v34, v34, v44, 0x7fff                           // 0000001AC944: D6550022 03FE5922 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC950: BF870214
	v_cndmask_b32_e64 v40, 0x7f800000, v40, s1                 // 0000001AC954: D5010028 000650FF 7F800000
	v_fma_f32 v45, -v52, v56, v45                              // 0000001AC960: D613002D 24B67134
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AC968: BF870004
	v_rcp_f32_e32 v53, v33                                     // 0000001AC96C: 7E6A5521
	s_clause 0x1                                               // 0000001AC970: BF850001
	global_store_d16_hi_b16 v[14:15], v34, off offset:96       // 0000001AC974: DC960060 007C220E
	global_store_d16_hi_b16 v[22:23], v32, off offset:96       // 0000001AC97C: DC960060 007C2016
	v_add_f32_e32 v40, 1.0, v40                                // 0000001AC984: 065050F2
	v_div_fmas_f32 v37, v45, v37, v56                          // 0000001AC988: D6370025 04E24B2D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v59                  // 0000001AC990: 7C3C76FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AC998: BF8701B2
	v_div_fixup_f32 v36, v37, v42, v36                         // 0000001AC99C: D6270024 04925525
	v_fma_f32 v61, -v33, v53, 1.0                              // 0000001AC9A4: D613003D 23CA6B21
	.long 0x7f5439c8                                           // 0000001AC9AC: 7F5439C8
	.long 0x7e5439a4                                           // 0000001AC9B0: 7E5439A4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AC9B4: BF8700A3
	v_fmac_f32_e32 v53, v61, v53                               // 0000001AC9B8: 566A6B3D
	v_div_scale_f32 v61, s0, v35, v41, v35                     // 0000001AC9BC: D6FC003D 048E5323
	v_dual_mul_f32 v73, v61, v53 :: v_dual_and_b32 v42, 1, v42 // 0000001AC9C4: C8E46B3D 492A5481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC9CC: BF870111
	v_add3_u32 v36, v36, v42, 0x7fff                           // 0000001AC9D0: D6550024 03FE5524 00007FFF
	v_fma_f32 v44, -v33, v73, v61                              // 0000001AC9DC: D613002C 24F69321
	global_store_d16_hi_b16 v[30:31], v36, off offset:96       // 0000001AC9E4: DC960060 007C241E
	v_dual_fmac_f32 v73, v44, v53 :: v_dual_lshlrev_b32 v36, 16, v130// 0000001AC9EC: C8226B2C 49250490
	v_cvt_i32_f32_e32 v44, v71                                 // 0000001AC9F4: 7E581147
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC9F8: BF870112
	v_fma_f32 v33, -v33, v73, v61                              // 0000001AC9FC: D6130021 24F69321
	.long 0xd71c002b                                           // 0000001ACA04: D71C002B
	v_cndmask_b32_e32 v1, v57, v44, vcc_lo                     // 0000001ACA08: 02025939
	v_lshlrev_b32_e32 v57, 16, v127                            // 0000001ACA0C: 3072FE90
	v_mul_f32_e32 v25, v25, v64                                // 0000001ACA10: 10328119
	v_div_scale_f32 v44, null, v40, v40, v24                   // 0000001ACA14: D6FC7C2C 04625128
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ACA1C: BF870123
	v_dual_cndmask_b32 v43, 0, v43 :: v_dual_mul_f32 v58, 0xbfb8aa3b, v57// 0000001ACA20: CA465680 2B3A72FF BFB8AA3B
	s_mov_b32 vcc_lo, s0                                       // 0000001ACA2C: BEEA0000
	v_rcp_f32_e32 v34, v44                                     // 0000001ACA30: 7E44552C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001ACA34: BF8700A1
	v_fma_f32 v60, 0xbfb8aa3b, v57, -v58                       // 0000001ACA38: D613003C 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v61, v58                                   // 0000001ACA44: 7E7A473A
	v_sub_f32_e32 v58, v58, v61                                // 0000001ACA48: 08747B3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACA4C: BF870093
	v_fmac_f32_e32 v60, 0xb2a5705f, v57                        // 0000001ACA50: 567872FF B2A5705F
	v_add_f32_e32 v58, v58, v60                                // 0000001ACA58: 0674793A
	v_div_fmas_f32 v33, v33, v53, v73                          // 0000001ACA5C: D6370021 05266B21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v59                  // 0000001ACA64: 7C3676FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ACA6C: BF870122
	v_div_fixup_f32 v33, v33, v41, v35                         // 0000001ACA70: D6270021 048E5321
	v_lshlrev_b32_e32 v41, 16, v128                            // 0000001ACA78: 30530090
	.long 0x7e9039a1                                           // 0000001ACA7C: 7E9039A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACA80: BF870091
	v_dual_mul_f32 v37, 0xbfb8aa3b, v41 :: v_dual_and_b32 v56, 1, v72// 0000001ACA84: C8E452FF 25389081 BFB8AA3B
	v_fma_f32 v52, 0xbfb8aa3b, v41, -v37                       // 0000001ACA90: D6130034 849652FF BFB8AA3B
	v_rndne_f32_e32 v53, v37                                   // 0000001ACA9C: 7E6A4725
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACAA0: BF870193
	v_add3_u32 v33, v33, v56, 0x7fff                           // 0000001ACAA4: D6550021 03FE7121 00007FFF
	v_fmac_f32_e32 v52, 0xb2a5705f, v41                        // 0000001ACAB0: 566852FF B2A5705F
	v_cndmask_b32_e32 v43, 0x7f800000, v43, vcc_lo             // 0000001ACAB8: 025656FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001ACAC0: BF8700D4
	v_sub_f32_e32 v37, v37, v53                                // 0000001ACAC4: 084A6B25
	v_cvt_i32_f32_e32 v53, v53                                 // 0000001ACAC8: 7E6A1135
	global_store_d16_hi_b16 v[38:39], v33, off offset:96       // 0000001ACACC: DC960060 007C2126
	v_add_f32_e32 v35, 1.0, v43                                // 0000001ACAD4: 064656F2
	v_fma_f32 v43, -v44, v34, 1.0                              // 0000001ACAD8: D613002B 23CA452C
	v_dual_add_f32 v37, v37, v52 :: v_dual_fmac_f32 v34, v43, v34// 0000001ACAE0: C9006925 2522452B
	v_div_scale_f32 v43, vcc_lo, v24, v40, v24                 // 0000001ACAE8: D6FC6A2B 04625118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACAF0: BF870092
	v_exp_f32_e32 v37, v37                                     // 0000001ACAF4: 7E4A4B25
	v_mul_f32_e32 v52, v43, v34                                // 0000001ACAF8: 1068452B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ACAFC: BF870291
	v_fma_f32 v56, -v44, v52, v43                              // 0000001ACB00: D6130038 24AE692C
	.long 0xd71c0025                                           // 0000001ACB08: D71C0025
	v_cndmask_b32_e32 v1, v37, v53, vcc_lo                     // 0000001ACB0C: 02026B25
	v_exp_f32_e32 v53, v58                                     // 0000001ACB10: 7E6A4B3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ACB14: BF870122
	v_fmac_f32_e32 v52, v56, v34                               // 0000001ACB18: 56684538
	v_div_scale_f32 v32, null, v35, v35, v25                   // 0000001ACB1C: D6FC7C20 04664723
	v_fma_f32 v43, -v44, v52, v43                              // 0000001ACB24: D613002B 24AE692C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACB2C: BF870092
	v_rcp_f32_e32 v45, v32                                     // 0000001ACB30: 7E5A5520
	v_div_fmas_f32 v34, v43, v34, v52                          // 0000001ACB34: D6370022 04D2452B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000001ACB3C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ACB44: BF870292
	v_div_fixup_f32 v24, v34, v40, v24                         // 0000001ACB48: D6270018 04625122
	v_fma_f32 v59, -v32, v45, 1.0                              // 0000001ACB50: D613003B 23CA5B20
	v_mul_f32_e32 v34, 0xbfb8aa3b, v36                         // 0000001ACB58: 104448FF BFB8AA3B
	.long 0x7f5039c8                                           // 0000001ACB60: 7F5039C8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ACB64: BF870214
	.long 0x7e503998                                           // 0000001ACB68: 7E503998
	v_fmac_f32_e32 v45, v59, v45                               // 0000001ACB6C: 565A5B3B
	v_div_scale_f32 v59, s0, v25, v35, v25                     // 0000001ACB70: D6FC003B 04664719
	v_fma_f32 v44, 0xbfb8aa3b, v36, -v34                       // 0000001ACB78: D613002C 848A48FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACB84: BF870194
	v_and_b32_e32 v40, 1, v40                                  // 0000001ACB88: 36505081
	v_mul_f32_e32 v70, v59, v45                                // 0000001ACB8C: 108C5B3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACB90: BF870193
	v_fmac_f32_e32 v44, 0xb2a5705f, v36                        // 0000001ACB94: 565848FF B2A5705F
	v_add3_u32 v24, v24, v40, 0x7fff                           // 0000001ACB9C: D6550018 03FE5118 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001ACBA8: BF8701D3
	v_fma_f32 v42, -v32, v70, v59                              // 0000001ACBAC: D613002A 24EE8D20
	global_store_d16_hi_b16 v[6:7], v24, off offset:128        // 0000001ACBB4: DC960080 007C1806
	v_fmac_f32_e32 v70, v42, v45                               // 0000001ACBBC: 568C5B2A
	.long 0xd41e0001                                           // 0000001ACBC0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v41, vcc_lo              // 0000001ACBC4: 020252FF 42CE8ED0
	v_cvt_i32_f32_e32 v42, v61                                 // 0000001ACBCC: 7E54113D
	v_fma_f32 v32, -v32, v70, v59                              // 0000001ACBD0: D6130020 24EE8D20
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ACBD8: BF870223
	v_cndmask_b32_e64 v37, 0, v37, s1                          // 0000001ACBDC: D5010025 00064A80
	.long 0xd41b0001                                           // 0000001ACBE4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v41, vcc_lo              // 0000001ACBE8: 020252FF C2B17218
	.long 0xd71c0029                                           // 0000001ACBF0: D71C0029
	v_cndmask_b32_e32 v1, v53, v42, vcc_lo                     // 0000001ACBF4: 02025535
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACBF8: BF870112
	v_cndmask_b32_e64 v37, 0x7f800000, v37, s1                 // 0000001ACBFC: D5010025 00064AFF 7F800000
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001ACC08: 02525280
	s_mov_b32 vcc_lo, s0                                       // 0000001ACC0C: BEEA0000
	.long 0xd41e0001                                           // 0000001ACC10: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001ACC14: 020248FF 42CE8ED0
	v_div_fmas_f32 v32, v32, v45, v70                          // 0000001ACC1C: D6370020 051A5B20
	v_add_f32_e32 v37, 1.0, v37                                // 0000001ACC24: 064A4AF2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001ACC28: 7C3672FF C2B17218
	v_rndne_f32_e32 v45, v34                                   // 0000001ACC30: 7E5A4722
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ACC34: BF870214
	v_div_fixup_f32 v25, v32, v35, v25                         // 0000001ACC38: D6270019 04664720
	v_div_scale_f32 v42, null, v37, v37, v26                   // 0000001ACC40: D6FC7C2A 046A4B25
	v_cndmask_b32_e32 v41, 0x7f800000, v41, vcc_lo             // 0000001ACC48: 025252FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001ACC50: BF8701C4
	v_sub_f32_e32 v34, v34, v45                                // 0000001ACC54: 08445B22
	v_cvt_i32_f32_e32 v45, v45                                 // 0000001ACC58: 7E5A112D
	.long 0x7e903999                                           // 0000001ACC5C: 7E903999
	v_rcp_f32_e32 v32, v42                                     // 0000001ACC60: 7E40552A
	v_dual_add_f32 v35, 1.0, v41 :: v_dual_add_f32 v34, v34, v44// 0000001ACC64: C90852F2 23225922
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACC6C: BF870112
	v_and_b32_e32 v52, 1, v72                                  // 0000001ACC70: 36689081
	v_div_scale_f32 v33, null, v35, v35, v27                   // 0000001ACC74: D6FC7C21 046E4723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACC7C: BF870113
	v_exp_f32_e32 v34, v34                                     // 0000001ACC80: 7E444B22
	v_add3_u32 v25, v25, v52, 0x7fff                           // 0000001ACC84: D6550019 03FE6919 00007FFF
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACC90: BF870196
	v_fma_f32 v41, -v42, v32, 1.0                              // 0000001ACC94: D6130029 23CA412A
	v_rcp_f32_e32 v43, v33                                     // 0000001ACC9C: 7E565521
	global_store_d16_hi_b16 v[46:47], v25, off offset:128      // 0000001ACCA0: DC960080 007C192E
	v_fmac_f32_e32 v32, v41, v32                               // 0000001ACCA8: 56404129
	v_div_scale_f32 v41, vcc_lo, v26, v37, v26                 // 0000001ACCAC: D6FC6A29 046A4B1A
	v_lshlrev_b32_e32 v53, 16, v129                            // 0000001ACCB4: 306B0290
	.long 0xd71c0022                                           // 0000001ACCB8: D71C0022
	v_cndmask_b32_e32 v1, v34, v45, vcc_lo                     // 0000001ACCBC: 02025B22
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACCC0: BF870193
	v_mul_f32_e32 v44, v41, v32                                // 0000001ACCC4: 10584129
	v_mul_f32_e32 v56, 0xbfb8aa3b, v53                         // 0000001ACCC8: 10706AFF BFB8AA3B
	v_fma_f32 v57, -v33, v43, 1.0                              // 0000001ACCD0: D6130039 23CA5721
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ACCD8: BF870004
	v_cndmask_b32_e64 v34, 0, v34, s1                          // 0000001ACCDC: D5010022 00064480
	.long 0xd41b0001                                           // 0000001ACCE4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001ACCE8: 020248FF C2B17218
	v_fma_f32 v52, -v42, v44, v41                              // 0000001ACCF0: D6130034 24A6592A
	v_fma_f32 v58, 0xbfb8aa3b, v53, -v56                       // 0000001ACCF8: D613003A 84E26AFF BFB8AA3B
	v_rndne_f32_e32 v59, v56                                   // 0000001ACD04: 7E764738
	v_fmac_f32_e32 v43, v57, v43                               // 0000001ACD08: 56565739
	v_div_scale_f32 v57, s0, v27, v35, v27                     // 0000001ACD0C: D6FC0039 046E471B
	v_fmac_f32_e32 v44, v52, v32                               // 0000001ACD14: 56584134
	v_fmac_f32_e32 v58, 0xb2a5705f, v53                        // 0000001ACD18: 56746AFF B2A5705F
	v_sub_f32_e32 v56, v56, v59                                // 0000001ACD20: 08707738
	v_cndmask_b32_e64 v34, 0x7f800000, v34, s1                 // 0000001ACD24: D5010022 000644FF 7F800000
	v_mul_f32_e32 v60, v57, v43                                // 0000001ACD30: 10785739
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACD34: BF870113
	v_add_f32_e32 v56, v56, v58                                // 0000001ACD38: 06707538
	v_fma_f32 v40, -v33, v60, v57                              // 0000001ACD3C: D6130028 24E67921
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACD44: BF870092
	v_exp_f32_e32 v45, v56                                     // 0000001ACD48: 7E5A4B38
	v_fmac_f32_e32 v60, v40, v43                               // 0000001ACD4C: 56785728
	v_cvt_i32_f32_e32 v40, v59                                 // 0000001ACD50: 7E50113B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001ACD54: BF870002
	v_fma_f32 v33, -v33, v60, v57                              // 0000001ACD58: D6130021 24E67921
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 0000001ACD60: BF870105
	.long 0xd71c0024                                           // 0000001ACD64: D71C0024
	v_cndmask_b32_e32 v1, v45, v40, vcc_lo                     // 0000001ACD68: 0202512D
	s_waitcnt vmcnt(3)                                         // 0000001ACD6C: BF890FF7
	v_lshlrev_b32_e32 v45, 16, v131                            // 0000001ACD70: 305B0690
	v_fma_f32 v41, -v42, v44, v41                              // 0000001ACD74: D6130029 24A6592A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACD7C: BF870112
	v_mul_f32_e32 v52, 0xbfb8aa3b, v45                         // 0000001ACD80: 10685AFF BFB8AA3B
	v_div_fmas_f32 v32, v41, v32, v44                          // 0000001ACD88: D6370020 04B24129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001ACD90: 7C3C6AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACD98: BF870193
	v_fma_f32 v56, 0xbfb8aa3b, v45, -v52                       // 0000001ACD9C: D6130038 84D25AFF BFB8AA3B
	v_div_fixup_f32 v26, v32, v37, v26                         // 0000001ACDA8: D627001A 046A4B20
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001ACDB0: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001ACDB4: BEEA0000
	v_rndne_f32_e32 v57, v52                                   // 0000001ACDB8: 7E724734
	v_div_fmas_f32 v33, v33, v43, v60                          // 0000001ACDBC: D6370021 04F25721
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001ACDC4: 7C366AFF C2B17218
	v_fmac_f32_e32 v56, 0xb2a5705f, v45                        // 0000001ACDCC: 56705AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ACDD4: BF870214
	v_sub_f32_e32 v52, v52, v57                                // 0000001ACDD8: 08687334
	v_div_fixup_f32 v24, v33, v35, v27                         // 0000001ACDDC: D6270018 046E4721
	v_dual_cndmask_b32 v36, 0x7f800000, v36 :: v_dual_mul_f32 v27, v29, v50// 0000001ACDE4: CA4648FF 241A651D 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ACDF0: BF870193
	v_dual_add_f32 v52, v52, v56 :: v_dual_lshlrev_b32 v35, 16, v87// 0000001ACDF4: C9227134 3422AE90
	.long 0x7e903998                                           // 0000001ACDFC: 7E903998
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ACE00: BF870223
	v_add_f32_e32 v33, 1.0, v36                                // 0000001ACE04: 064248F2
	.long 0x7e48399a                                           // 0000001ACE08: 7E48399A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v35                         // 0000001ACE0C: 104046FF BFB8AA3B
	.long 0x7f4839c8                                           // 0000001ACE14: 7F4839C8
	.long 0xd41e0001                                           // 0000001ACE18: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v35, vcc_lo              // 0000001ACE1C: 020246FF 42CE8ED0
	v_div_scale_f32 v25, null, v33, v33, v27                   // 0000001ACE24: D6FC7C19 046E4321
	v_and_b32_e32 v44, 1, v72                                  // 0000001ACE2C: 36589081
	v_fma_f32 v42, 0xbfb8aa3b, v35, -v32                       // 0000001ACE30: D613002A 848246FF BFB8AA3B
	v_rndne_f32_e32 v43, v32                                   // 0000001ACE3C: 7E564720
	v_and_b32_e32 v36, 1, v36                                  // 0000001ACE40: 36484881
	v_rcp_f32_e32 v41, v25                                     // 0000001ACE44: 7E525519
	v_add3_u32 v24, v24, v44, 0x7fff                           // 0000001ACE48: D6550018 03FE5918 00007FFF
	v_fmac_f32_e32 v42, 0xb2a5705f, v35                        // 0000001ACE54: 565446FF B2A5705F
	v_sub_f32_e32 v32, v32, v43                                // 0000001ACE5C: 08405720
	v_cvt_i32_f32_e32 v43, v43                                 // 0000001ACE60: 7E56112B
	v_add3_u32 v26, v26, v36, 0x7fff                           // 0000001ACE64: D655001A 03FE491A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ACE70: BF870293
	v_add_f32_e32 v32, v32, v42                                // 0000001ACE74: 06405520
	v_fma_f32 v53, -v25, v41, 1.0                              // 0000001ACE78: D6130035 23CA5319
	s_clause 0x1                                               // 0000001ACE80: BF850001
	global_store_d16_hi_b16 v[14:15], v26, off offset:128      // 0000001ACE84: DC960080 007C1A0E
	global_store_d16_hi_b16 v[22:23], v24, off offset:128      // 0000001ACE8C: DC960080 007C1816
	v_exp_f32_e32 v32, v32                                     // 0000001ACE94: 7E404B20
	v_fmac_f32_e32 v41, v53, v41                               // 0000001ACE98: 56525335
	v_div_scale_f32 v53, s0, v27, v33, v27                     // 0000001ACE9C: D6FC0035 046E431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ACEA4: BF870291
	v_mul_f32_e32 v58, v53, v41                                // 0000001ACEA8: 10745335
	.long 0xd71c0020                                           // 0000001ACEAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v43, vcc_lo                     // 0000001ACEB0: 02025720
	v_exp_f32_e32 v43, v52                                     // 0000001ACEB4: 7E564B34
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACEB8: BF870112
	v_fma_f32 v36, -v25, v58, v53                              // 0000001ACEBC: D6130024 24D67519
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001ACEC4: D5010020 00064080
	.long 0xd41b0001                                           // 0000001ACECC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v35, vcc_lo              // 0000001ACED0: 020246FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ACED8: BF8701A3
	v_fmac_f32_e32 v58, v36, v41                               // 0000001ACEDC: 56745324
	v_cvt_i32_f32_e32 v36, v57                                 // 0000001ACEE0: 7E481139
	v_cndmask_b32_e64 v32, 0x7f800000, v32, s1                 // 0000001ACEE4: D5010020 000640FF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001ACEF0: BF870003
	v_fma_f32 v25, -v25, v58, v53                              // 0000001ACEF4: D6130019 24D67519
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001ACEFC: BF870185
	.long 0xd71c0023                                           // 0000001ACF00: D71C0023
	v_cndmask_b32_e32 v1, v43, v36, vcc_lo                     // 0000001ACF04: 0202492B
	v_add_f32_e32 v34, 1.0, v34                                // 0000001ACF08: 064444F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACF0C: BF870114
	v_dual_add_f32 v32, 1.0, v32 :: v_dual_lshlrev_b32 v43, 16, v123// 0000001ACF10: C92240F2 202AF690
	v_div_scale_f32 v40, null, v34, v34, v28                   // 0000001ACF18: D6FC7C28 04724522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACF20: BF870112
	v_div_scale_f32 v36, null, v32, v32, v16                   // 0000001ACF24: D6FC7C24 04424120
	v_rcp_f32_e32 v29, v40                                     // 0000001ACF2C: 7E3A5528
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001ACF30: BF870311
	v_rcp_f32_e32 v26, v36                                     // 0000001ACF34: 7E345524
	v_fma_f32 v37, -v40, v29, 1.0                              // 0000001ACF38: D6130025 23CA3B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001ACF40: BF8700A1
	v_fmac_f32_e32 v29, v37, v29                               // 0000001ACF44: 563A3B25
	v_div_scale_f32 v37, vcc_lo, v28, v34, v28                 // 0000001ACF48: D6FC6A25 0472451C
	v_mul_f32_e32 v42, v37, v29                                // 0000001ACF50: 10543B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACF54: BF870091
	v_fma_f32 v44, -v40, v42, v37                              // 0000001ACF58: D613002C 24965528
	v_fmac_f32_e32 v42, v44, v29                               // 0000001ACF60: 56543B2C
	v_mul_f32_e32 v44, 0xbfb8aa3b, v43                         // 0000001ACF64: 105856FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ACF6C: BF870112
	v_fma_f32 v37, -v40, v42, v37                              // 0000001ACF70: D6130025 24965528
	v_fma_f32 v52, 0xbfb8aa3b, v43, -v44                       // 0000001ACF78: D6130034 84B256FF BFB8AA3B
	v_rndne_f32_e32 v53, v44                                   // 0000001ACF84: 7E6A472C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ACF88: BF870223
	v_div_fmas_f32 v29, v37, v29, v42                          // 0000001ACF8C: D637001D 04AA3B25
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v45                  // 0000001ACF94: 7C3C5AFF 42CE8ED0
	v_fmac_f32_e32 v52, 0xb2a5705f, v43                        // 0000001ACF9C: 566856FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ACFA4: BF870004
	v_dual_sub_f32 v44, v44, v53 :: v_dual_cndmask_b32 v35, 0, v35// 0000001ACFA8: C9526B2C 2C224680
	s_mov_b32 vcc_lo, s0                                       // 0000001ACFB0: BEEA0000
	v_div_fixup_f32 v28, v29, v34, v28                         // 0000001ACFB4: D627001C 0472451D
	v_div_fmas_f32 v25, v25, v41, v58                          // 0000001ACFBC: D6370019 04EA5319
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v45                  // 0000001ACFC4: 7C365AFF C2B17218
	.long 0x7f4439c8                                           // 0000001ACFCC: 7F4439C8
	v_add_f32_e32 v44, v44, v52                                // 0000001ACFD0: 0658692C
	.long 0x7e44399c                                           // 0000001ACFD4: 7E44399C
	v_div_fixup_f32 v25, v25, v33, v27                         // 0000001ACFD8: D6270019 046E4319
	v_cndmask_b32_e32 v35, 0x7f800000, v35, vcc_lo             // 0000001ACFE0: 024646FF 7F800000
	v_lshlrev_b32_e32 v33, 16, v124                            // 0000001ACFE8: 3042F890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ACFEC: BF870214
	v_and_b32_e32 v34, 1, v34                                  // 0000001ACFF0: 36444481
	.long 0x7e903999                                           // 0000001ACFF4: 7E903999
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ACFF8: BF870214
	v_add_f32_e32 v27, 1.0, v35                                // 0000001ACFFC: 063646F2
	v_mul_f32_e32 v29, 0xbfb8aa3b, v33                         // 0000001AD000: 103A42FF BFB8AA3B
	v_fma_f32 v35, -v36, v26, 1.0                              // 0000001AD008: D6130023 23CA3524
	v_add3_u32 v28, v28, v34, 0x7fff                           // 0000001AD010: D655001C 03FE451C 00007FFF
	v_and_b32_e32 v42, 1, v72                                  // 0000001AD01C: 36549081
	v_div_scale_f32 v24, null, v27, v27, v17                   // 0000001AD020: D6FC7C18 0446371B
	v_fma_f32 v40, 0xbfb8aa3b, v33, -v29                       // 0000001AD028: D6130028 847642FF BFB8AA3B
	v_rndne_f32_e32 v41, v29                                   // 0000001AD034: 7E52471D
	v_fmac_f32_e32 v26, v35, v26                               // 0000001AD038: 56343523
	v_div_scale_f32 v35, vcc_lo, v16, v32, v16                 // 0000001AD03C: D6FC6A23 04424110
	v_rcp_f32_e32 v37, v24                                     // 0000001AD044: 7E4A5518
	v_fmac_f32_e32 v40, 0xb2a5705f, v33                        // 0000001AD048: 565042FF B2A5705F
	v_sub_f32_e32 v29, v29, v41                                // 0000001AD050: 083A531D
	v_add3_u32 v25, v25, v42, 0x7fff                           // 0000001AD054: D6550019 03FE5519 00007FFF
	v_cvt_i32_f32_e32 v41, v41                                 // 0000001AD060: 7E521129
	.long 0xd41e0001                                           // 0000001AD064: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v33, vcc_lo              // 0000001AD068: 020242FF 42CE8ED0
	global_store_d16_hi_b16 v[30:31], v28, off offset:128      // 0000001AD070: DC960080 007C1C1E
	v_dual_add_f32 v29, v29, v40 :: v_dual_mul_f32 v40, v35, v26// 0000001AD078: C906511D 1D283523
	global_store_d16_hi_b16 v[38:39], v25, off offset:128      // 0000001AD080: DC960080 007C1926
	v_fma_f32 v45, -v24, v37, 1.0                              // 0000001AD088: D613002D 23CA4B18
	v_lshlrev_b32_e32 v25, 16, v126                            // 0000001AD090: 3032FC90
	v_exp_f32_e32 v29, v29                                     // 0000001AD094: 7E3A4B1D
	v_fma_f32 v42, -v36, v40, v35                              // 0000001AD098: D613002A 248E5124
	.long 0x7f3839c8                                           // 0000001AD0A0: 7F3839C8
	v_fmac_f32_e32 v37, v45, v37                               // 0000001AD0A4: 564A4B2D
	v_div_scale_f32 v45, s0, v17, v27, v17                     // 0000001AD0A8: D6FC002D 04463711
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AD0B0: BF870114
	v_fmac_f32_e32 v40, v42, v26                               // 0000001AD0B4: 5650352A
	v_mul_f32_e32 v56, v45, v37                                // 0000001AD0B8: 10704B2D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AD0BC: BF8701A5
	.long 0xd71c001d                                           // 0000001AD0C0: D71C001D
	v_cndmask_b32_e32 v1, v29, v41, vcc_lo                     // 0000001AD0C4: 0202531D
	v_exp_f32_e32 v41, v44                                     // 0000001AD0C8: 7E524B2C
	v_fma_f32 v35, -v36, v40, v35                              // 0000001AD0CC: D6130023 248E5124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD0D4: BF870193
	v_fma_f32 v34, -v24, v56, v45                              // 0000001AD0D8: D6130022 24B67118
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001AD0E0: D501001D 00063A80
	.long 0xd41b0001                                           // 0000001AD0E8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v33, vcc_lo              // 0000001AD0EC: 020242FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD0F4: BF870004
	v_div_fmas_f32 v26, v35, v26, v40                          // 0000001AD0F8: D637001A 04A23523
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43                  // 0000001AD100: 7C3C56FF 42CE8ED0
	v_fmac_f32_e32 v56, v34, v37                               // 0000001AD108: 56704B22
	v_cvt_i32_f32_e32 v34, v53                                 // 0000001AD10C: 7E441135
	v_cndmask_b32_e64 v29, 0x7f800000, v29, s1                 // 0000001AD110: D501001D 00063AFF 7F800000
	.long 0xd41e0001                                           // 0000001AD11C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001AD120: 020232FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD128: BF870214
	v_fma_f32 v24, -v24, v56, v45                              // 0000001AD12C: D6130018 24B67118
	.long 0xd71c0021                                           // 0000001AD134: D71C0021
	v_cndmask_b32_e32 v1, v41, v34, vcc_lo                     // 0000001AD138: 02024529
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AD13C: BF870114
	v_add_f32_e32 v29, 1.0, v29                                // 0000001AD140: 063A3AF2
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000001AD144: 02424280
	s_mov_b32 vcc_lo, s0                                       // 0000001AD148: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001AD14C: BF8701C2
	v_div_scale_f32 v34, null, v29, v29, v18                   // 0000001AD150: D6FC7C22 044A3B1D
	v_div_fmas_f32 v24, v24, v37, v56                          // 0000001AD158: D6370018 04E24B18
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43                  // 0000001AD160: 7C3656FF C2B17218
	v_lshlrev_b32_e32 v37, 16, v125                            // 0000001AD168: 304AFA90
	v_div_fixup_f32 v17, v24, v27, v17                         // 0000001AD16C: D6270011 04463718
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001AD174: 024242FF 7F800000
	v_rcp_f32_e32 v24, v34                                     // 0000001AD17C: 7E305522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD180: BF870193
	v_mul_f32_e32 v42, 0xbfb8aa3b, v37                         // 0000001AD184: 10544AFF BFB8AA3B
	.long 0x7e903991                                           // 0000001AD18C: 7E903991
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AD190: BF870003
	v_add_f32_e32 v27, 1.0, v33                                // 0000001AD194: 063642F2
	v_div_fixup_f32 v16, v26, v32, v16                         // 0000001AD198: D6270010 0442411A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v25                         // 0000001AD1A0: 104032FF BFB8AA3B
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v42                       // 0000001AD1A8: D613002D 84AA4AFF BFB8AA3B
	v_rndne_f32_e32 v52, v42                                   // 0000001AD1B4: 7E68472A
	v_div_scale_f32 v26, null, v27, v27, v19                   // 0000001AD1B8: D6FC7C1A 044E371B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001AD1C0: BF870005
	v_fma_f32 v33, -v34, v24, 1.0                              // 0000001AD1C4: D6130021 23CA3122
	v_fma_f32 v40, 0xbfb8aa3b, v25, -v32                       // 0000001AD1CC: D6130028 848232FF BFB8AA3B
	v_rndne_f32_e32 v41, v32                                   // 0000001AD1D8: 7E524720
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001AD1DC: 565A4AFF B2A5705F
	v_rcp_f32_e32 v35, v26                                     // 0000001AD1E4: 7E46551A
	v_fmac_f32_e32 v24, v33, v24                               // 0000001AD1E8: 56303121
	v_div_scale_f32 v33, vcc_lo, v18, v29, v18                 // 0000001AD1EC: D6FC6A21 044A3B12
	v_fmac_f32_e32 v40, 0xb2a5705f, v25                        // 0000001AD1F4: 565032FF B2A5705F
	v_sub_f32_e32 v32, v32, v41                                // 0000001AD1FC: 08405320
	v_sub_f32_e32 v42, v42, v52                                // 0000001AD200: 0854692A
	v_and_b32_e32 v36, 1, v72                                  // 0000001AD204: 36489081
	v_mul_f32_e32 v44, v33, v24                                // 0000001AD208: 10583121
	v_cvt_i32_f32_e32 v41, v41                                 // 0000001AD20C: 7E521129
	v_add_f32_e32 v32, v32, v40                                // 0000001AD210: 06405120
	v_fma_f32 v43, -v26, v35, 1.0                              // 0000001AD214: D613002B 23CA471A
	v_div_scale_f32 v40, s0, v19, v27, v19                     // 0000001AD21C: D6FC0028 044E3713
	v_add_f32_e32 v42, v42, v45                                // 0000001AD224: 06545B2A
	v_add3_u32 v17, v17, v36, 0x7fff                           // 0000001AD228: D6550011 03FE4911 00007FFF
	v_exp_f32_e32 v32, v32                                     // 0000001AD234: 7E404B20
	v_fmac_f32_e32 v35, v43, v35                               // 0000001AD238: 5646472B
	v_fma_f32 v43, -v34, v44, v33                              // 0000001AD23C: D613002B 24865922
	v_exp_f32_e32 v36, v42                                     // 0000001AD244: 7E484B2A
	.long 0x7e383990                                           // 0000001AD248: 7E383990
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AD24C: BF870112
	v_dual_mul_f32 v53, v40, v35 :: v_dual_fmac_f32 v44, v43, v24// 0000001AD250: C8C04728 352C312B
	v_and_b32_e32 v28, 1, v28                                  // 0000001AD258: 36383881
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD25C: BF870196
	.long 0xd71c0020                                           // 0000001AD260: D71C0020
	v_cndmask_b32_e32 v1, v32, v41, vcc_lo                     // 0000001AD264: 02025320
	v_fma_f32 v43, -v26, v53, v40                              // 0000001AD268: D613002B 24A26B1A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD270: BF870004
	v_fma_f32 v33, -v34, v44, v33                              // 0000001AD274: D6130021 24865922
	v_cvt_i32_f32_e32 v34, v52                                 // 0000001AD27C: 7E441134
	v_add3_u32 v16, v16, v28, 0x7fff                           // 0000001AD280: D6550010 03FE3910 00007FFF
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001AD28C: D5010020 00064080
	v_fmac_f32_e32 v53, v43, v35                               // 0000001AD294: 566A472B
	v_div_fmas_f32 v24, v33, v24, v44                          // 0000001AD298: D6370018 04B23121
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001AD2A0: 7C3632FF C2B17218
	.long 0xd71c0021                                           // 0000001AD2A8: D71C0021
	v_cndmask_b32_e32 v1, v36, v34, vcc_lo                     // 0000001AD2AC: 02024524
	global_store_d16_hi_b16 v[6:7], v16, off offset:160        // 0000001AD2B0: DC9600A0 007C1006
	v_fma_f32 v26, -v26, v53, v40                              // 0000001AD2B8: D613001A 24A26B1A
	v_div_fixup_f32 v16, v24, v29, v18                         // 0000001AD2C0: D6270010 044A3B18
	v_cndmask_b32_e32 v25, 0x7f800000, v32, vcc_lo             // 0000001AD2C8: 023240FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v37                  // 0000001AD2D0: 7C3C4AFF 42CE8ED0
	v_lshlrev_b32_e32 v28, 16, v92                             // 0000001AD2D8: 3038B890
	global_store_d16_hi_b16 v[46:47], v17, off offset:160      // 0000001AD2DC: DC9600A0 007C112E
	.long 0x7e3a3990                                           // 0000001AD2E4: 7E3A3990
	v_add_f32_e32 v25, 1.0, v25                                // 0000001AD2E8: 063232F2
	v_cndmask_b32_e32 v32, 0, v33, vcc_lo                      // 0000001AD2EC: 02404280
	s_mov_b32 vcc_lo, s0                                       // 0000001AD2F0: BEEA0000
	v_mul_f32_e32 v34, 0xbfb8aa3b, v28                         // 0000001AD2F4: 104438FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v35, v53                          // 0000001AD2FC: D637001A 04D6471A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v37                  // 0000001AD304: 7C364AFF C2B17218
	.long 0x7f3a39c8                                           // 0000001AD30C: 7F3A39C8
	s_waitcnt vmcnt(2)                                         // 0000001AD310: BF890BF7
	v_lshlrev_b32_e32 v37, 16, v67                             // 0000001AD314: 304A8690
	v_rndne_f32_e32 v35, v34                                   // 0000001AD318: 7E464722
	v_div_fixup_f32 v19, v26, v27, v19                         // 0000001AD31C: D6270013 044E371A
	v_cndmask_b32_e32 v32, 0x7f800000, v32, vcc_lo             // 0000001AD324: 024040FF 7F800000
	v_div_scale_f32 v26, null, v25, v25, v20                   // 0000001AD32C: D6FC7C1A 04523319
	v_and_b32_e32 v29, 1, v29                                  // 0000001AD334: 363A3A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD338: BF870214
	.long 0x7e903993                                           // 0000001AD33C: 7E903993
	v_add_f32_e32 v27, 1.0, v32                                // 0000001AD340: 063640F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD344: BF870194
	v_rcp_f32_e32 v18, v26                                     // 0000001AD348: 7E24551A
	v_add3_u32 v16, v16, v29, 0x7fff                           // 0000001AD34C: D6550010 03FE3B10 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD358: BF870193
	v_and_b32_e32 v32, 1, v72                                  // 0000001AD35C: 36409081
	v_div_scale_f32 v24, null, v27, v27, v21                   // 0000001AD360: D6FC7C18 0456371B
	global_store_d16_hi_b16 v[14:15], v16, off offset:160      // 0000001AD368: DC9600A0 007C100E
	v_add3_u32 v19, v19, v32, 0x7fff                           // 0000001AD370: D6550013 03FE4113 00007FFF
	v_rcp_f32_e32 v33, v24                                     // 0000001AD37C: 7E425518
	v_fma_f32 v17, -v26, v18, 1.0                              // 0000001AD380: D6130011 23CA251A
	v_fma_f32 v32, 0xbfb8aa3b, v28, -v34                       // 0000001AD388: D6130020 848A38FF BFB8AA3B
	v_sub_f32_e32 v34, v34, v35                                // 0000001AD394: 08444722
	v_cvt_i32_f32_e32 v35, v35                                 // 0000001AD398: 7E461123
	global_store_d16_hi_b16 v[22:23], v19, off offset:160      // 0000001AD39C: DC9600A0 007C1316
	v_fmac_f32_e32 v18, v17, v18                               // 0000001AD3A4: 56242511
	v_div_scale_f32 v17, vcc_lo, v20, v25, v20                 // 0000001AD3A8: D6FC6A11 04523314
	v_fmac_f32_e32 v32, 0xb2a5705f, v28                        // 0000001AD3B0: 564038FF B2A5705F
	v_fma_f32 v36, -v24, v33, 1.0                              // 0000001AD3B8: D6130024 23CA4318
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD3C0: BF870193
	v_mul_f32_e32 v40, v17, v18                                // 0000001AD3C4: 10502511
	v_add_f32_e32 v32, v34, v32                                // 0000001AD3C8: 06404122
	v_mul_f32_e32 v34, 0xbfb8aa3b, v37                         // 0000001AD3CC: 10444AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD3D4: BF870004
	v_fmac_f32_e32 v33, v36, v33                               // 0000001AD3D8: 56424324
	v_div_scale_f32 v36, s0, v21, v27, v21                     // 0000001AD3DC: D6FC0024 04563715
	v_fma_f32 v29, -v26, v40, v17                              // 0000001AD3E4: D613001D 2446511A
	v_exp_f32_e32 v32, v32                                     // 0000001AD3EC: 7E404B20
	v_fma_f32 v42, 0xbfb8aa3b, v37, -v34                       // 0000001AD3F0: D613002A 848A4AFF BFB8AA3B
	v_rndne_f32_e32 v43, v34                                   // 0000001AD3FC: 7E564722
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD400: BF870193
	v_dual_mul_f32 v41, v36, v33 :: v_dual_fmac_f32 v40, v29, v18// 0000001AD404: C8C04324 2928251D
	v_fmac_f32_e32 v42, 0xb2a5705f, v37                        // 0000001AD40C: 56544AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD414: BF870193
	v_sub_f32_e32 v34, v34, v43                                // 0000001AD418: 08445722
	v_fma_f32 v29, -v24, v41, v36                              // 0000001AD41C: D613001D 24925318
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AD424: BF870294
	v_fma_f32 v16, -v26, v40, v17                              // 0000001AD428: D6130010 2446511A
	.long 0xd71c0011                                           // 0000001AD430: D71C0011
	v_cndmask_b32_e32 v1, v32, v35, vcc_lo                     // 0000001AD434: 02024720
	v_cvt_i32_f32_e32 v19, v43                                 // 0000001AD438: 7E26112B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD43C: BF870214
	v_dual_add_f32 v26, v34, v42 :: v_dual_fmac_f32 v41, v29, v33// 0000001AD440: C9005522 1A28431D
	v_div_fmas_f32 v16, v16, v18, v40                          // 0000001AD448: D6370010 04A22510
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001AD450: 7C3C38FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD458: BF870213
	v_fma_f32 v18, -v24, v41, v36                              // 0000001AD45C: D6130012 24925318
	v_exp_f32_e32 v24, v26                                     // 0000001AD464: 7E304B1A
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001AD468: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001AD46C: BEEA0000
	v_div_fixup_f32 v16, v16, v25, v20                         // 0000001AD470: D6270010 04523310
	v_div_fmas_f32 v18, v18, v33, v41                          // 0000001AD478: D6370012 04A64312
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001AD480: 7C3638FF C2B17218
	.long 0x7f2839c8                                           // 0000001AD488: 7F2839C8
	v_lshlrev_b32_e32 v33, 16, v69                             // 0000001AD48C: 30428A90
	.long 0x7e283990                                           // 0000001AD490: 7E283990
	v_div_fixup_f32 v18, v18, v27, v21                         // 0000001AD494: D6270012 04563712
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001AD49C: 022222FF 7F800000
	.long 0xd71c0013                                           // 0000001AD4A4: D71C0013
	v_cndmask_b32_e32 v1, v24, v19, vcc_lo                     // 0000001AD4A8: 02022718
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v37                  // 0000001AD4AC: 7C3C4AFF 42CE8ED0
	v_lshlrev_b32_e32 v24, 16, v104                            // 0000001AD4B4: 3030D090
	.long 0x7e903992                                           // 0000001AD4B8: 7E903992
	v_dual_add_f32 v17, 1.0, v17 :: v_dual_and_b32 v20, 1, v20 // 0000001AD4BC: C92422F2 11142881
	v_cndmask_b32_e32 v19, 0, v19, vcc_lo                      // 0000001AD4C4: 02262680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v37                  // 0000001AD4C8: 7C364AFF C2B17218
	v_mul_f32_e32 v26, 0xbfb8aa3b, v24                         // 0000001AD4D0: 103430FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AD4D8: BF870234
	v_div_scale_f32 v21, null, v17, v17, v8                    // 0000001AD4DC: D6FC7C15 04222311
	v_dual_mul_f32 v36, 0xbfb8aa3b, v33 :: v_dual_and_b32 v27, 1, v72// 0000001AD4E4: C8E442FF 241A9081 BFB8AA3B
	v_cndmask_b32_e32 v19, 0x7f800000, v19, vcc_lo             // 0000001AD4F0: 022626FF 7F800000
	v_fma_f32 v28, 0xbfb8aa3b, v24, -v26                       // 0000001AD4F8: D613001C 846A30FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AD504: BF8701B4
	v_rcp_f32_e32 v25, v21                                     // 0000001AD508: 7E325515
	v_rndne_f32_e32 v29, v26                                   // 0000001AD50C: 7E3A471A
	v_add3_u32 v16, v16, v20, 0x7fff                           // 0000001AD510: D6550010 03FE2910 00007FFF
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_fmac_f32 v28, 0xb2a5705f, v24// 0000001AD51C: C90026F2 131C30FF B2A5705F
	v_add3_u32 v18, v18, v27, 0x7fff                           // 0000001AD528: D6550012 03FE3712 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AD534: BF870224
	v_sub_f32_e32 v26, v26, v29                                // 0000001AD538: 08343B1A
	v_rndne_f32_e32 v27, v36                                   // 0000001AD53C: 7E364724
	v_div_scale_f32 v32, null, v19, v19, v9                    // 0000001AD540: D6FC7C20 04262713
	v_cvt_i32_f32_e32 v29, v29                                 // 0000001AD548: 7E3A111D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001AD54C: BF870005
	v_fma_f32 v34, -v21, v25, 1.0                              // 0000001AD550: D6130022 23CA3315
	v_add_f32_e32 v20, v26, v28                                // 0000001AD558: 0628391A
	v_fma_f32 v26, 0xbfb8aa3b, v33, -v36                       // 0000001AD55C: D613001A 849242FF BFB8AA3B
	v_rcp_f32_e32 v35, v32                                     // 0000001AD568: 7E465520
	v_div_scale_f32 v28, vcc_lo, v8, v17, v8                   // 0000001AD56C: D6FC6A1C 04222308
	v_fmac_f32_e32 v25, v34, v25                               // 0000001AD574: 56323322
	v_exp_f32_e32 v20, v20                                     // 0000001AD578: 7E284B14
	v_fmac_f32_e32 v26, 0xb2a5705f, v33                        // 0000001AD57C: 563442FF B2A5705F
	v_sub_f32_e32 v36, v36, v27                                // 0000001AD584: 08483724
	global_store_d16_hi_b16 v[30:31], v16, off offset:160      // 0000001AD588: DC9600A0 007C101E
	v_mul_f32_e32 v37, v28, v25                                // 0000001AD590: 104A331C
	.long 0xd41e0001                                           // 0000001AD594: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001AD598: 020230FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001AD5A0: 7E36111B
	v_fma_f32 v34, -v32, v35, 1.0                              // 0000001AD5A4: D6130022 23CA4720
	v_add_f32_e32 v26, v36, v26                                // 0000001AD5AC: 06343524
	global_store_d16_hi_b16 v[38:39], v18, off offset:160      // 0000001AD5B0: DC9600A0 007C1226
	.long 0xd71c0010                                           // 0000001AD5B8: D71C0010
	v_cndmask_b32_e32 v1, v20, v29, vcc_lo                     // 0000001AD5BC: 02023B14
	v_fma_f32 v20, -v21, v37, v28                              // 0000001AD5C0: D6130014 24724B15
	v_fmac_f32_e32 v35, v34, v35                               // 0000001AD5C8: 56464722
	v_div_scale_f32 v34, s0, v9, v19, v9                       // 0000001AD5CC: D6FC0022 04262709
	v_exp_f32_e32 v26, v26                                     // 0000001AD5D4: 7E344B1A
	v_cndmask_b32_e64 v16, 0, v16, s1                          // 0000001AD5D8: D5010010 00062080
	v_fmac_f32_e32 v37, v20, v25                               // 0000001AD5E0: 564A3314
	.long 0xd41b0001                                           // 0000001AD5E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v24, vcc_lo              // 0000001AD5E8: 020230FF C2B17218
	v_dual_mul_f32 v29, v34, v35 :: v_dual_lshlrev_b32 v18, 16, v106// 0000001AD5F0: C8E24722 1D12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD5F8: BF870193
	v_fma_f32 v21, -v21, v37, v28                              // 0000001AD5FC: D6130015 24724B15
	v_cndmask_b32_e64 v16, 0x7f800000, v16, s1                 // 0000001AD604: D5010010 000620FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD610: BF870213
	v_fma_f32 v20, -v32, v29, v34                              // 0000001AD614: D6130014 248A3B20
	.long 0xd41e0001                                           // 0000001AD61C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v18, vcc_lo              // 0000001AD620: 020224FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AD628: BF870224
	v_div_fmas_f32 v21, v21, v25, v37                          // 0000001AD62C: D6370015 04963315
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001AD634: 7C3C42FF 42CE8ED0
	v_fmac_f32_e32 v29, v20, v35                               // 0000001AD63C: 563A4714
	.long 0xd71c0014                                           // 0000001AD640: D71C0014
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001AD644: 0202371A
	v_add_f32_e32 v16, 1.0, v16                                // 0000001AD648: 062020F2
	v_div_fixup_f32 v8, v21, v17, v8                           // 0000001AD64C: D6270008 04222315
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD654: BF870214
	v_fma_f32 v24, -v32, v29, v34                              // 0000001AD658: D6130018 248A3B20
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001AD660: 02282880
	s_mov_b32 vcc_lo, s0                                       // 0000001AD664: BEEA0000
	v_div_scale_f32 v25, null, v16, v16, v10                   // 0000001AD668: D6FC7C19 042A2110
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AD670: BF870233
	v_div_fmas_f32 v24, v24, v35, v29                          // 0000001AD674: D6370018 04764718
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001AD67C: 7C3642FF C2B17218
	v_lshlrev_b32_e32 v33, 16, v105                            // 0000001AD684: 3042D290
	v_rcp_f32_e32 v26, v25                                     // 0000001AD688: 7E345519
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AD68C: BF870003
	v_div_fixup_f32 v9, v24, v19, v9                           // 0000001AD690: D6270009 04262718
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001AD698: 022828FF 7F800000
	v_mul_f32_e32 v24, 0xbfb8aa3b, v18                         // 0000001AD6A0: 103024FF BFB8AA3B
	v_div_scale_f32 v32, vcc_lo, v10, v16, v10                 // 0000001AD6A8: D6FC6A20 042A210A
	v_mul_f32_e32 v35, 0xbfb8aa3b, v33                         // 0000001AD6B0: 104642FF BFB8AA3B
	.long 0x7e903989                                           // 0000001AD6B8: 7E903989
	v_add_f32_e32 v17, 1.0, v20                                // 0000001AD6BC: 062228F2
	v_fma_f32 v28, 0xbfb8aa3b, v18, -v24                       // 0000001AD6C0: D613001C 846224FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001AD6CC: BF870005
	v_fma_f32 v20, -v25, v26, 1.0                              // 0000001AD6D0: D6130014 23CA3519
	v_rndne_f32_e32 v29, v24                                   // 0000001AD6D8: 7E3A4718
	v_and_b32_e32 v27, 1, v72                                  // 0000001AD6DC: 36369081
	v_div_scale_f32 v21, null, v17, v17, v11                   // 0000001AD6E0: D6FC7C15 042E2311
	v_fmac_f32_e32 v28, 0xb2a5705f, v18                        // 0000001AD6E8: 563824FF B2A5705F
	v_fmac_f32_e32 v26, v20, v26                               // 0000001AD6F0: 56343514
	v_sub_f32_e32 v24, v24, v29                                // 0000001AD6F4: 08303B18
	.long 0x7e263988                                           // 0000001AD6F8: 7E263988
	v_rcp_f32_e32 v20, v21                                     // 0000001AD6FC: 7E285515
	.long 0x7f2639c8                                           // 0000001AD700: 7F2639C8
	v_mul_f32_e32 v34, v32, v26                                // 0000001AD704: 10443520
	v_add_f32_e32 v24, v24, v28                                // 0000001AD708: 06303918
	v_fma_f32 v36, 0xbfb8aa3b, v33, -v35                       // 0000001AD70C: D6130024 848E42FF BFB8AA3B
	v_rndne_f32_e32 v37, v35                                   // 0000001AD718: 7E4A4723
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001AD71C: D6550009 03FE3709 00007FFF
	v_and_b32_e32 v19, 1, v19                                  // 0000001AD728: 36262681
	v_fma_f32 v28, -v25, v34, v32                              // 0000001AD72C: D613001C 24824519
	v_exp_f32_e32 v24, v24                                     // 0000001AD734: 7E304B18
	v_fma_f32 v27, -v21, v20, 1.0                              // 0000001AD738: D613001B 23CA2915
	v_fmac_f32_e32 v36, 0xb2a5705f, v33                        // 0000001AD740: 564842FF B2A5705F
	v_sub_f32_e32 v35, v35, v37                                // 0000001AD748: 08464B23
	v_add3_u32 v8, v8, v19, 0x7fff                             // 0000001AD74C: D6550008 03FE2708 00007FFF
	v_cvt_i32_f32_e32 v19, v29                                 // 0000001AD758: 7E26111D
	v_fmac_f32_e32 v20, v27, v20                               // 0000001AD75C: 5628291B
	v_div_scale_f32 v27, s0, v11, v17, v11                     // 0000001AD760: D6FC001B 042E230B
	v_dual_fmac_f32 v34, v28, v26 :: v_dual_add_f32 v29, v35, v36// 0000001AD768: C808351C 221C4923
	global_store_d16_hi_b16 v[6:7], v8, off offset:192         // 0000001AD770: DC9600C0 007C0806
	.long 0xd71c0008                                           // 0000001AD778: D71C0008
	v_cndmask_b32_e32 v1, v24, v19, vcc_lo                     // 0000001AD77C: 02022718
	v_mul_f32_e32 v28, v27, v20                                // 0000001AD780: 1038291B
	v_fma_f32 v19, -v25, v34, v32                              // 0000001AD784: D6130013 24824519
	v_exp_f32_e32 v25, v29                                     // 0000001AD78C: 7E324B1D
	global_store_d16_hi_b16 v[46:47], v9, off offset:192       // 0000001AD790: DC9600C0 007C092E
	v_cndmask_b32_e64 v8, 0, v8, s1                            // 0000001AD798: D5010008 00061080
	v_fma_f32 v24, -v21, v28, v27                              // 0000001AD7A0: D6130018 246E3915
	v_div_fmas_f32 v19, v19, v26, v34                          // 0000001AD7A8: D6370013 048A3513
	v_cvt_i32_f32_e32 v26, v37                                 // 0000001AD7B0: 7E341125
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001AD7B4: 7C3624FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD7BC: BF870214
	v_fmac_f32_e32 v28, v24, v20                               // 0000001AD7C0: 56382918
	v_div_fixup_f32 v10, v19, v16, v10                         // 0000001AD7C4: D627000A 042A2113
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD7CC: BF870004
	.long 0xd71c0010                                           // 0000001AD7D0: D71C0010
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000001AD7D4: 02023519
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001AD7D8: 021010FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001AD7E0: 7C3C42FF 42CE8ED0
	v_fma_f32 v18, -v21, v28, v27                              // 0000001AD7E8: D6130012 246E3915
	s_waitcnt vmcnt(1)                                         // 0000001AD7F0: BF8907F7
	v_lshlrev_b32_e32 v24, 16, v66                             // 0000001AD7F4: 30308490
	.long 0x7e2a398a                                           // 0000001AD7F8: 7E2A398A
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001AD7FC: 061010F2
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001AD800: 02202080
	s_mov_b32 vcc_lo, s0                                       // 0000001AD804: BEEA0000
	v_mul_f32_e32 v29, 0xbfb8aa3b, v24                         // 0000001AD808: 103A30FF BFB8AA3B
	v_div_fmas_f32 v18, v18, v20, v28                          // 0000001AD810: D6370012 04722912
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001AD818: 7C3642FF C2B17218
	v_lshlrev_b32_e32 v20, 16, v68                             // 0000001AD820: 30288890
	v_div_scale_f32 v19, null, v8, v8, v12                     // 0000001AD824: D6FC7C13 04321108
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v29                       // 0000001AD82C: D6130021 847630FF BFB8AA3B
	v_div_fixup_f32 v11, v18, v17, v11                         // 0000001AD838: D627000B 042E2312
	v_cndmask_b32_e32 v16, 0x7f800000, v16, vcc_lo             // 0000001AD840: 022020FF 7F800000
	v_mul_f32_e32 v18, 0xbfb8aa3b, v20                         // 0000001AD848: 102428FF BFB8AA3B
	v_rcp_f32_e32 v17, v19                                     // 0000001AD850: 7E225513
	v_rndne_f32_e32 v34, v29                                   // 0000001AD854: 7E44471D
	v_fmac_f32_e32 v33, 0xb2a5705f, v24                        // 0000001AD858: 564230FF B2A5705F
	v_add_f32_e32 v16, 1.0, v16                                // 0000001AD860: 062020F2
	v_fma_f32 v26, 0xbfb8aa3b, v20, -v18                       // 0000001AD864: D613001A 844A28FF BFB8AA3B
	v_rndne_f32_e32 v27, v18                                   // 0000001AD870: 7E364712
	.long 0xd41e0001                                           // 0000001AD874: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v20, vcc_lo              // 0000001AD878: 020228FF 42CE8ED0
	.long 0x7e90398b                                           // 0000001AD880: 7E90398B
	v_div_scale_f32 v25, null, v16, v16, v13                   // 0000001AD884: D6FC7C19 04362110
	v_fmac_f32_e32 v26, 0xb2a5705f, v20                        // 0000001AD88C: 563428FF B2A5705F
	v_sub_f32_e32 v18, v18, v27                                // 0000001AD894: 08243712
	v_fma_f32 v28, -v19, v17, 1.0                              // 0000001AD898: D613001C 23CA2313
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001AD8A0: 7E36111B
	v_rcp_f32_e32 v32, v25                                     // 0000001AD8A4: 7E405519
	.long 0x7f2a39c8                                           // 0000001AD8A8: 7F2A39C8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AD8AC: BF8701B3
	v_dual_add_f32 v18, v18, v26 :: v_dual_fmac_f32 v17, v28, v17// 0000001AD8B0: C9003512 1210231C
	v_div_scale_f32 v26, vcc_lo, v12, v8, v12                  // 0000001AD8B8: D6FC6A1A 0432110C
	v_dual_sub_f32 v28, v29, v34 :: v_dual_and_b32 v35, 1, v72 // 0000001AD8C0: C964451D 1C229081
	v_exp_f32_e32 v18, v18                                     // 0000001AD8C8: 7E244B12
	v_and_b32_e32 v21, 1, v21                                  // 0000001AD8CC: 362A2A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001AD8D0: BF870313
	v_mul_f32_e32 v36, v26, v17                                // 0000001AD8D4: 1048231A
	v_fma_f32 v29, -v25, v32, 1.0                              // 0000001AD8D8: D613001D 23CA4119
	v_add_f32_e32 v28, v28, v33                                // 0000001AD8E0: 0638431C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AD8E4: BF870214
	v_add3_u32 v9, v10, v21, 0x7fff                            // 0000001AD8E8: D6550009 03FE2B0A 00007FFF
	v_fma_f32 v33, -v19, v36, v26                              // 0000001AD8F4: D6130021 246A4913
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD8FC: BF870004
	v_fmac_f32_e32 v32, v29, v32                               // 0000001AD900: 5640411D
	v_div_scale_f32 v29, s0, v13, v16, v13                     // 0000001AD904: D6FC001D 0436210D
	v_exp_f32_e32 v28, v28                                     // 0000001AD90C: 7E384B1C
	.long 0xd71c0012                                           // 0000001AD910: D71C0012
	v_cndmask_b32_e32 v1, v18, v27, vcc_lo                     // 0000001AD914: 02023712
	v_fmac_f32_e32 v36, v33, v17                               // 0000001AD918: 56482321
	v_cvt_i32_f32_e32 v33, v34                                 // 0000001AD91C: 7E421122
	v_mul_f32_e32 v27, v29, v32                                // 0000001AD920: 1036411D
	v_add3_u32 v10, v11, v35, 0x7fff                           // 0000001AD924: D655000A 03FE470B 00007FFF
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001AD930: D5010012 00062480
	.long 0xd41b0001                                           // 0000001AD938: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v20, vcc_lo              // 0000001AD93C: 020228FF C2B17218
	v_fma_f32 v19, -v19, v36, v26                              // 0000001AD944: D6130013 246A4913
	v_fma_f32 v34, -v25, v27, v29                              // 0000001AD94C: D6130022 24763719
	.long 0xd71c001a                                           // 0000001AD954: D71C001A
	v_cndmask_b32_e32 v1, v28, v33, vcc_lo                     // 0000001AD958: 0202431C
	global_store_d16_hi_b16 v[14:15], v9, off offset:192       // 0000001AD95C: DC9600C0 007C090E
	v_cndmask_b32_e64 v18, 0x7f800000, v18, s1                 // 0000001AD964: D5010012 000624FF 7F800000
	.long 0xd41e0001                                           // 0000001AD970: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001AD974: 020230FF 42CE8ED0
	v_fmac_f32_e32 v27, v34, v32                               // 0000001AD97C: 56364122
	v_div_fmas_f32 v17, v19, v17, v36                          // 0000001AD980: D6370011 04922313
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001AD988: 7C3630FF C2B17218
	v_add_f32_e32 v18, 1.0, v18                                // 0000001AD990: 062424F2
	v_cndmask_b32_e64 v20, 0, v26, s1                          // 0000001AD994: D5010014 00063480
	v_fma_f32 v19, -v25, v27, v29                              // 0000001AD99C: D6130013 24763719
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001AD9A4: D6270008 04321111
	global_store_d16_hi_b16 v[22:23], v10, off offset:192      // 0000001AD9AC: DC9600C0 007C0A16
	v_div_scale_f32 v25, null, v18, v18, v0                    // 0000001AD9B4: D6FC7C19 04022512
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001AD9BC: 022828FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001AD9C4: BEEA0000
	v_lshlrev_b32_e32 v17, 16, v55                             // 0000001AD9C8: 30226E90
	v_div_fmas_f32 v19, v19, v32, v27                          // 0000001AD9CC: D6370013 046E4113
	v_rcp_f32_e32 v24, v25                                     // 0000001AD9D4: 7E305519
	v_add_f32_e32 v20, 1.0, v20                                // 0000001AD9D8: 062828F2
	v_lshlrev_b32_e32 v28, 16, v54                             // 0000001AD9DC: 30386C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AD9E0: BF870223
	v_div_fixup_f32 v11, v19, v16, v13                         // 0000001AD9E4: D627000B 04362113
	.long 0x7e203988                                           // 0000001AD9EC: 7E203988
	v_div_scale_f32 v13, null, v20, v20, v1                    // 0000001AD9F0: D6FC7C0D 04062914
	.long 0x7f2039c8                                           // 0000001AD9F8: 7F2039C8
	v_mul_f32_e32 v29, 0xbfb8aa3b, v28                         // 0000001AD9FC: 103A38FF BFB8AA3B
	.long 0x7e90398b                                           // 0000001ADA04: 7E90398B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ADA08: BF8701B5
	v_fma_f32 v9, -v25, v24, 1.0                               // 0000001ADA0C: D6130009 23CA3119
	v_rcp_f32_e32 v12, v13                                     // 0000001ADA14: 7E18550D
	v_and_b32_e32 v16, 1, v16                                  // 0000001ADA18: 36202081
	v_and_b32_e32 v10, 1, v72                                  // 0000001ADA1C: 36149081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ADA20: BF870223
	v_fmac_f32_e32 v24, v9, v24                                // 0000001ADA24: 56303109
	v_div_scale_f32 v9, vcc_lo, v0, v18, v0                    // 0000001ADA28: D6FC6A09 04022500
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000001ADA30: D6550008 03FE2108 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ADA3C: BF870224
	v_add3_u32 v10, v11, v10, 0x7fff                           // 0000001ADA40: D655000A 03FE150B 00007FFF
	v_mul_f32_e32 v11, 0xbfb8aa3b, v17                         // 0000001ADA4C: 101622FF BFB8AA3B
	v_mul_f32_e32 v19, v9, v24                                 // 0000001ADA54: 10263109
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001ADA58: BF870005
	v_fma_f32 v21, -v13, v12, 1.0                              // 0000001ADA5C: D6130015 23CA190D
	s_clause 0x1                                               // 0000001ADA64: BF850001
	global_store_d16_hi_b16 v[30:31], v8, off offset:192       // 0000001ADA68: DC9600C0 007C081E
	global_store_d16_hi_b16 v[38:39], v10, off offset:192      // 0000001ADA70: DC9600C0 007C0A26
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v11                       // 0000001ADA78: D613001A 842E22FF BFB8AA3B
	v_fma_f32 v16, -v25, v19, v9                               // 0000001ADA84: D6130010 24262719
	v_fmac_f32_e32 v12, v21, v12                               // 0000001ADA8C: 56181915
	v_div_scale_f32 v21, s0, v1, v20, v1                       // 0000001ADA90: D6FC0015 04062901
	v_rndne_f32_e32 v27, v11                                   // 0000001ADA98: 7E36470B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ADA9C: BF870114
	v_dual_fmac_f32 v26, 0xb2a5705f, v17 :: v_dual_fmac_f32 v19, v16, v24// 0000001ADAA0: C80022FF 1A123110 B2A5705F
	v_dual_mul_f32 v16, v21, v12 :: v_dual_sub_f32 v11, v11, v27// 0000001ADAAC: C8CA1915 100A370B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ADAB4: BF8701A2
	v_fma_f32 v8, -v25, v19, v9                                // 0000001ADAB8: D6130008 24262719
	v_fma_f32 v25, 0xbfb8aa3b, v28, -v29                       // 0000001ADAC0: D6130019 847638FF BFB8AA3B
	v_fma_f32 v9, -v13, v16, v21                               // 0000001ADACC: D6130009 2456210D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ADAD4: BF870004
	v_add_f32_e32 v11, v11, v26                                // 0000001ADAD8: 0616350B
	v_rndne_f32_e32 v26, v29                                   // 0000001ADADC: 7E34471D
	v_div_fmas_f32 v8, v8, v24, v19                            // 0000001ADAE0: D6370008 044E3108
	v_fmac_f32_e32 v25, 0xb2a5705f, v28                        // 0000001ADAE8: 563238FF B2A5705F
	v_fmac_f32_e32 v16, v9, v12                                // 0000001ADAF0: 56201909
	v_exp_f32_e32 v9, v11                                      // 0000001ADAF4: 7E124B0B
	v_sub_f32_e32 v11, v29, v26                                // 0000001ADAF8: 0816351D
	v_lshlrev_b32_e32 v19, 16, v62                             // 0000001ADAFC: 30267C90
	v_cvt_i32_f32_e32 v24, v27                                 // 0000001ADB00: 7E30111B
	v_fma_f32 v13, -v13, v16, v21                              // 0000001ADB04: D613000D 2456210D
	s_waitcnt vmcnt(0)                                         // 0000001ADB0C: BF8903F7
	v_lshlrev_b32_e32 v21, 16, v63                             // 0000001ADB10: 302A7E90
	v_add_f32_e32 v11, v11, v25                                // 0000001ADB14: 0616330B
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001ADB18: 103226FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001ADB20: 7C3C22FF 42CE8ED0
	v_cvt_i32_f32_e32 v26, v26                                 // 0000001ADB28: 7E34111A
	v_mul_f32_e32 v27, 0xbfb8aa3b, v21                         // 0000001ADB2C: 10362AFF BFB8AA3B
	.long 0xd71c0009                                           // 0000001ADB34: D71C0009
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000001ADB38: 02023109
	v_fma_f32 v24, 0xbfb8aa3b, v19, -v25                       // 0000001ADB3C: D6130018 846626FF BFB8AA3B
	v_rndne_f32_e32 v29, v25                                   // 0000001ADB48: 7E3A4719
	v_exp_f32_e32 v11, v11                                     // 0000001ADB4C: 7E164B0B
	v_fma_f32 v32, 0xbfb8aa3b, v21, -v27                       // 0000001ADB50: D6130020 846E2AFF BFB8AA3B
	v_rndne_f32_e32 v33, v27                                   // 0000001ADB5C: 7E42471B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ADB60: BF870223
	v_dual_fmac_f32 v24, 0xb2a5705f, v19 :: v_dual_sub_f32 v25, v25, v29// 0000001ADB64: C80A26FF 18183B19 B2A5705F
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 0000001ADB70: 02121280
	v_fmac_f32_e32 v32, 0xb2a5705f, v21                        // 0000001ADB74: 56402AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001ADB7C: BF8702B4
	v_sub_f32_e32 v27, v27, v33                                // 0000001ADB80: 0836431B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001ADB84: 7C3622FF C2B17218
	v_add_f32_e32 v24, v25, v24                                // 0000001ADB8C: 06303119
	.long 0xd71c000b                                           // 0000001ADB90: D71C000B
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000001ADB94: 0202350B
	v_cvt_i32_f32_e32 v26, v33                                 // 0000001ADB98: 7E341121
	v_add_f32_e32 v25, v27, v32                                // 0000001ADB9C: 0632411B
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001ADBA0: 021212FF 7F800000
	v_exp_f32_e32 v17, v24                                     // 0000001ADBA8: 7E224B18
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001ADBAC: 7C3C38FF 42CE8ED0
	v_div_fixup_f32 v0, v8, v18, v0                            // 0000001ADBB4: D6270000 04022508
	v_exp_f32_e32 v24, v25                                     // 0000001ADBBC: 7E304B19
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001ADBC0: 7E32111D
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001ADBC4: 061212F2
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000001ADBC8: 02161680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001ADBCC: 7C3638FF C2B17218
	.long 0x7e423980                                           // 0000001ADBD4: 7E423980
	.long 0x7f4239c8                                           // 0000001ADBD8: 7F4239C8
	.long 0xd71c0011                                           // 0000001ADBDC: D71C0011
	v_cndmask_b32_e32 v1, v17, v25, vcc_lo                     // 0000001ADBE0: 02023311
	v_div_scale_f32 v25, null, v9, v9, v2                      // 0000001ADBE4: D6FC7C19 040A1309
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001ADBEC: 021616FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v19                  // 0000001ADBF4: 7C3C26FF 42CE8ED0
	.long 0xd71c0018                                           // 0000001ADBFC: D71C0018
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000001ADC00: 02023518
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ADC04: BF870194
	v_rcp_f32_e32 v26, v25                                     // 0000001ADC08: 7E345519
	v_add_f32_e32 v11, 1.0, v11                                // 0000001ADC0C: 061616F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001ADC10: 02222280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v21                  // 0000001ADC14: 7C3C2AFF 42CE8ED0
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001ADC1C: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001ADC20: 7C3626FF C2B17218
	v_div_scale_f32 v19, null, v11, v11, v3                    // 0000001ADC28: D6FC7C13 040E170B
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001ADC30: 022222FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v21                  // 0000001ADC38: 7C362AFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ADC40: BF870113
	v_rcp_f32_e32 v27, v19                                     // 0000001ADC44: 7E365513
	v_add_f32_e32 v17, 1.0, v17                                // 0000001ADC48: 062222F2
	v_cndmask_b32_e32 v21, 0x7f800000, v24, vcc_lo             // 0000001ADC4C: 022A30FF 7F800000
	v_fma_f32 v24, -v25, v26, 1.0                              // 0000001ADC54: D6130018 23CA3519
	s_mov_b32 vcc_lo, s0                                       // 0000001ADC5C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ADC60: BF870193
	v_div_scale_f32 v28, null, v17, v17, v4                    // 0000001ADC64: D6FC7C1C 04122311
	v_add_f32_e32 v21, 1.0, v21                                // 0000001ADC6C: 062A2AF2
	v_div_fmas_f32 v12, v13, v12, v16                          // 0000001ADC70: D637000C 0442190D
	v_fmac_f32_e32 v26, v24, v26                               // 0000001ADC78: 56343518
	v_div_scale_f32 v16, vcc_lo, v2, v9, v2                    // 0000001ADC7C: D6FC6A10 040A1302
	v_rcp_f32_e32 v13, v28                                     // 0000001ADC84: 7E1A551C
	v_div_scale_f32 v24, null, v21, v21, v5                    // 0000001ADC88: D6FC7C18 04162B15
	v_fma_f32 v29, -v19, v27, 1.0                              // 0000001ADC90: D613001D 23CA3713
	v_div_fixup_f32 v1, v12, v20, v1                           // 0000001ADC98: D6270001 0406290C
	v_mul_f32_e32 v10, v16, v26                                // 0000001ADCA0: 10143510
	v_div_scale_f32 v20, s0, v3, v11, v3                       // 0000001ADCA4: D6FC0014 040E1703
	v_rcp_f32_e32 v12, v24                                     // 0000001ADCAC: 7E185518
	v_fmac_f32_e32 v27, v29, v27                               // 0000001ADCB0: 5636371D
	.long 0x7e903981                                           // 0000001ADCB4: 7E903981
	v_fma_f32 v8, -v25, v10, v16                               // 0000001ADCB8: D6130008 24421519
	v_fma_f32 v29, -v28, v13, 1.0                              // 0000001ADCC0: D613001D 23CA1B1C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ADCC8: BF870114
	v_mul_f32_e32 v18, v20, v27                                // 0000001ADCCC: 10243714
	v_dual_fmac_f32 v10, v8, v26 :: v_dual_fmac_f32 v13, v29, v13// 0000001ADCD0: C8003508 0A0C1B1D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ADCD8: BF870225
	v_fma_f32 v32, -v24, v12, 1.0                              // 0000001ADCDC: D6130020 23CA1918
	v_div_scale_f32 v29, s1, v4, v17, v4                       // 0000001ADCE4: D6FC011D 04122304
	v_fma_f32 v8, -v19, v18, v20                               // 0000001ADCEC: D6130008 24522513
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ADCF4: BF870214
	v_fma_f32 v16, -v25, v10, v16                              // 0000001ADCF8: D6130010 24421519
	v_fmac_f32_e32 v12, v32, v12                               // 0000001ADD00: 56181920
	v_div_scale_f32 v32, s2, v5, v21, v5                       // 0000001ADD04: D6FC0220 04162B05
	v_mul_f32_e32 v34, v29, v13                                // 0000001ADD0C: 10441B1D
	v_fmac_f32_e32 v18, v8, v27                                // 0000001ADD10: 56243708
	v_div_fmas_f32 v10, v16, v26, v10                          // 0000001ADD14: D637000A 042A3510
	s_mov_b32 vcc_lo, s0                                       // 0000001ADD1C: BEEA0000
	v_mul_f32_e32 v25, v32, v12                                // 0000001ADD20: 10321920
	v_fma_f32 v8, -v28, v34, v29                               // 0000001ADD24: D6130008 2476451C
	v_fma_f32 v16, -v19, v18, v20                              // 0000001ADD2C: D6130010 24522513
	v_div_fixup_f32 v2, v10, v9, v2                            // 0000001ADD34: D6270002 040A130A
	v_and_b32_e32 v10, 1, v33                                  // 0000001ADD3C: 36144281
	v_fma_f32 v19, -v24, v25, v32                              // 0000001ADD40: D6130013 24823318
	v_fmac_f32_e32 v34, v8, v13                                // 0000001ADD48: 56441B08
	v_div_fmas_f32 v8, v16, v27, v18                           // 0000001ADD4C: D6370008 044A3710
	s_mov_b32 vcc_lo, s1                                       // 0000001ADD54: BEEA0001
	v_and_b32_e32 v16, 1, v72                                  // 0000001ADD58: 36209081
	v_fmac_f32_e32 v25, v19, v12                               // 0000001ADD5C: 56321913
	v_fma_f32 v9, -v28, v34, v29                               // 0000001ADD60: D6130009 2476451C
	v_div_fixup_f32 v3, v8, v11, v3                            // 0000001ADD68: D6270003 040E1708
	.long 0x7f1639c8                                           // 0000001ADD70: 7F1639C8
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001ADD74: D6550000 03FE1500 00007FFF
	v_fma_f32 v8, -v24, v25, v32                               // 0000001ADD80: D6130008 24823318
	v_div_fmas_f32 v9, v9, v13, v34                            // 0000001ADD88: D6370009 048A1B09
	s_mov_b32 vcc_lo, s2                                       // 0000001ADD90: BEEA0002
	.long 0x7e903983                                           // 0000001ADD94: 7E903983
	v_add3_u32 v1, v1, v16, 0x7fff                             // 0000001ADD98: D6550001 03FE2101 00007FFF
	v_div_fmas_f32 v8, v8, v12, v25                            // 0000001ADDA4: D6370008 04661908
	v_div_fixup_f32 v4, v9, v17, v4                            // 0000001ADDAC: D6270004 04122309
	.long 0x7e123982                                           // 0000001ADDB4: 7E123982
	.long 0x7f1239c8                                           // 0000001ADDB8: 7F1239C8
	global_store_d16_hi_b16 v[6:7], v0, off offset:224         // 0000001ADDBC: DC9600E0 007C0006
	v_div_fixup_f32 v5, v8, v21, v5                            // 0000001ADDC4: D6270005 04162B08
	.long 0x7e163984                                           // 0000001ADDCC: 7E163984
	v_and_b32_e32 v8, 1, v72                                   // 0000001ADDD0: 36109081
	v_and_b32_e32 v9, 1, v9                                    // 0000001ADDD4: 36121281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ADDD8: BF870214
	.long 0x7e903985                                           // 0000001ADDDC: 7E903985
	v_and_b32_e32 v10, 1, v11                                  // 0000001ADDE0: 36141681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001ADDE4: BF870223
	v_add3_u32 v0, v2, v9, 0x7fff                              // 0000001ADDE8: D6550000 03FE1302 00007FFF
	v_add3_u32 v2, v3, v8, 0x7fff                              // 0000001ADDF4: D6550002 03FE1103 00007FFF
	v_and_b32_e32 v11, 1, v72                                  // 0000001ADE00: 36169081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ADE04: BF870114
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001ADE08: D6550003 03FE1504 00007FFF
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001ADE14: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001ADE20: BF850004
	global_store_d16_hi_b16 v[46:47], v1, off offset:224       // 0000001ADE24: DC9600E0 007C012E
	global_store_d16_hi_b16 v[14:15], v0, off offset:224       // 0000001ADE2C: DC9600E0 007C000E
	global_store_d16_hi_b16 v[22:23], v2, off offset:224       // 0000001ADE34: DC9600E0 007C0216
	global_store_d16_hi_b16 v[30:31], v3, off offset:224       // 0000001ADE3C: DC9600E0 007C031E
	global_store_d16_hi_b16 v[38:39], v4, off offset:224       // 0000001ADE44: DC9600E0 007C0426
	s_nop 0                                                    // 0000001ADE4C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001ADE50: BFB60003
	s_endpgm                                                   // 0000001ADE54: BFB00000
		...

