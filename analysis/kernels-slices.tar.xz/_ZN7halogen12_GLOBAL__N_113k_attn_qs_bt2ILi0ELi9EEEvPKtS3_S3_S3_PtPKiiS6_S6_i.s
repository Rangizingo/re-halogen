00000000001c9200 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001C9200: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001C9204: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001C920C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001C9214: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001C9218: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 0000001C921C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001C9224: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 0000001C9228: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 0000001C9230: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001C9238: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001C923C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 0000001C9240: 810E020E
	s_add_u32 s0, s18, s0                                      // 0000001C9244: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001C9248: 82010113
	s_add_i32 s15, s14, 1                                      // 0000001C924C: 810F810E
	s_load_b32 s3, s[0:1], null                                // 0000001C9250: F40000C0 F8000000
	s_ashr_i32 s0, s15, 31                                     // 0000001C9258: 86009F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C925C: BF870499
	s_lshr_b32 s0, s0, 30                                      // 0000001C9260: 85009E00
	s_add_i32 s0, s15, s0                                      // 0000001C9264: 8100000F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C9268: BF870009
	s_and_b32 s1, s0, -4                                       // 0000001C926C: 8B01C400
	s_ashr_i32 s18, s0, 2                                      // 0000001C9270: 86128200
	s_sub_i32 s15, s14, s1                                     // 0000001C9274: 818F010E
	s_mul_hi_i32 s1, s21, s2                                   // 0000001C9278: 97010215
	s_cmp_gt_i32 s15, -1                                       // 0000001C927C: BF02C10F
	s_mul_i32 s0, s21, s2                                      // 0000001C9280: 96000215
	s_cselect_b32 s14, -1, 0                                   // 0000001C9284: 980E80C1
	s_mov_b32 s19, s18                                         // 0000001C9288: BE930012
	s_and_b32 vcc_lo, exec_lo, s14                             // 0000001C928C: 8B6A0E7E
	s_cbranch_vccnz 15                                         // 0000001C9290: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 0000001C9294: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001C9298: BF8704D9
	s_add_u32 s19, s16, s22                                    // 0000001C929C: 80131610
	s_addc_u32 s21, s17, s23                                   // 0000001C92A0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 0000001C92A4: BF89FC07
	s_max_i32 s22, s3, 1                                       // 0000001C92A8: 8A168103
	s_mov_b32 s23, 0                                           // 0000001C92AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001C92B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C92B4: BF870009
	s_add_u32 s19, s19, s22                                    // 0000001C92B8: 80131613
	s_addc_u32 s21, s21, s23                                   // 0000001C92BC: 82151715
	s_add_u32 s22, s19, -4                                     // 0000001C92C0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 0000001C92C4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 0000001C92C8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s14                            // 0000001C92D0: D5010001 00390280
	s_mov_b32 s23, exec_lo                                     // 0000001C92D8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C92DC: BF8704B1
	v_readfirstlane_b32 s14, v1                                // 0000001C92E0: 7E1C0501
	s_waitcnt lgkmcnt(0)                                       // 0000001C92E4: BF89FC07
	s_add_i32 s21, s3, s14                                     // 0000001C92E8: 81150E03
	s_add_i32 s14, s21, 3                                      // 0000001C92EC: 810E8315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C92F0: BF870499
	s_and_b32 s22, s14, -4                                     // 0000001C92F4: 8B16C40E
	.long 0xd4c4007e                                           // 0000001C92F8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 0000001C92FC: 02020016
	s_cbranch_execz 45                                         // 0000001C9300: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001C9304: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001C930C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C9310: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001C9314: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001C9318: 82010111
	.long 0xd7000001                                           // 0000001C931C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001C9320: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C9324: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001C9328: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001C9330: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001C9334: BF840001
	s_branch 18                                                // 0000001C9338: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 0000001C933C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C9340: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 0000001C9344: 4A0808C0
	.long 0xd7000001                                           // 0000001C9348: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 0000001C934C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000001C9354: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 0000001C9358: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001C9360: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 0000001C9368: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000001C936C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 0000001C9374: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C9378: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001C937C: 917E017E
	s_cbranch_execz 13                                         // 0000001C9380: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 0000001C9384: BE80007E
	.long 0xd4c3007e                                           // 0000001C9388: D4C3007E
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000001C938C: 02020803
	s_xor_b32 s0, exec_lo, s0                                  // 0000001C9390: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 0000001C9394: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 0000001C9398: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001C939C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001C93A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 0000001C93A4: BE803000
	s_cbranch_execz 65509                                      // 0000001C93A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001C93AC: DC520000 057C0001
	s_branch 65506                                             // 0000001C93B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001C93B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 0000001C93BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001C93C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 0000001C93C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001C93C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 0000001C93D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001C93D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001C93D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001C93E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 0000001C93E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 0000001C93EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 0000001C93F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001C93F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 0000001C9400: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001C9404: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001C940C: 30020084
	s_add_u32 s4, s4, s16                                      // 0000001C9410: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000001C9414: 82051105
	s_add_u32 s4, s4, s18                                      // 0000001C9418: 80041204
	s_addc_u32 s0, s5, s0                                      // 0000001C941C: 82000005
	.long 0xd7000401                                           // 0000001C9420: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001C9424: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001C9428: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 0000001C9434: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 0000001C943C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 0000001C9440: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001C9448: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001C9450: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001C9454: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C945C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001C9460: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001C9468: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001C946C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 0000001C9474: 8C040400
	s_waitcnt vmcnt(0)                                         // 0000001C9478: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 0000001C947C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001C9484: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001C948C: 917E047E
	s_cbranch_execnz 65515                                     // 0000001C9490: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001C9494: 8C7E017E
	v_lshlrev_b32_e32 v16, 7, v7                               // 0000001C9498: 30200E87
	s_ashr_i32 s14, s14, 2                                     // 0000001C949C: 860E820E
	s_mov_b32 s0, 0                                            // 0000001C94A0: BE800080
	s_cmp_gt_i32 s14, 0                                        // 0000001C94A4: BF02800E
	s_waitcnt lgkmcnt(0)                                       // 0000001C94A8: BF89FC07
	s_barrier                                                  // 0000001C94AC: BFBD0000
	buffer_gl0_inv                                             // 0000001C94B0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 0000001C94B8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001C94BC: 30100E87
	s_branch 1                                                 // 0000001C94C0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s0, -1                                           // 0000001C94C4: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 0000001C94C8: 7E4C0280
	v_and_b32_e32 v228, 15, v0                                 // 0000001C94CC: 37C8008F
	v_bfe_u32 v15, v0, 4, 1                                    // 0000001C94D0: D610000F 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001C94D8: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C94DC: BF870003
	v_mov_b32_e32 v37, v38                                     // 0000001C94E0: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001C94E4: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001C94E8: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001C94EC: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001C94F0: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001C94F4: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001C94F8: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001C94FC: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001C9500: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001C9504: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001C9508: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001C950C: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001C9510: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001C9514: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001C9518: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001C951C: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001C9520: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001C9524: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001C9528: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001C952C: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001C9530: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001C9534: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001C9538: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001C953C: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001C9540: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001C9544: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001C9548: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001C954C: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001C9550: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001C9554: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001C9558: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001C955C: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001C9560: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001C9564: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001C9568: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001C956C: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001C9570: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001C9574: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001C9578: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001C957C: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001C9580: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001C9584: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001C9588: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001C958C: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001C9590: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001C9594: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001C9598: 7E020326
	v_mov_b32_e32 v204, v38                                    // 0000001C959C: 7F980326
	v_mov_b32_e32 v202, v38                                    // 0000001C95A0: 7F940326
	v_mov_b32_e32 v205, v38                                    // 0000001C95A4: 7F9A0326
	v_mov_b32_e32 v203, v38                                    // 0000001C95A8: 7F960326
	v_mov_b32_e32 v206, v38                                    // 0000001C95AC: 7F9C0326
	v_mov_b32_e32 v201, v38                                    // 0000001C95B0: 7F920326
	s_cbranch_vccnz 1243                                       // 0000001C95B4: BFA404DB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1724>
	s_ashr_i32 s21, s20, 31                                    // 0000001C95B8: 86159F14
	s_lshl2_add_u32 s3, s3, s15                                // 0000001C95BC: 87830F03
	v_dual_mov_b32 v201, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 0000001C95C0: CA220080 C9000085
	v_lshlrev_b32_e32 v3, 10, v7                               // 0000001C95C8: 30060E8A
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001C95CC: 84808B14
	s_add_i32 s15, s3, 1                                       // 0000001C95D0: 810F8103
	s_add_u32 s0, s6, s0                                       // 0000001C95D4: 80000006
	v_lshlrev_b32_e32 v1, 2, v228                              // 0000001C95D8: 3003C882
	v_cmp_gt_u32_e32 vcc_lo, 12, v228                          // 0000001C95DC: 7C99C88C
	v_dual_mov_b32 v203, 0 :: v_dual_and_b32 v0, 0x60, v0      // 0000001C95E0: CA240080 CB0000FF 00000060
	.long 0xd7000005                                           // 0000001C95EC: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001C95F0: 02020600
	s_addc_u32 s1, s7, s1                                      // 0000001C95F4: 82010107
	v_lshl_or_b32 v1, v15, 6, v1                               // 0000001C95F8: D6560001 04050D0F
	v_cndmask_b32_e32 v2, 0, v228, vcc_lo                      // 0000001C9600: 0205C880
	v_add_co_ci_u32_e64 v6, null, s1, 0, s0                    // 0000001C9604: D5207C06 00010001
	.long 0xd7006a00                                           // 0000001C960C: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001C9610: 02020105
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C9614: BF870004
	v_add_nc_u32_e32 v1, 0x3cd0, v1                            // 0000001C9618: 4A0202FF 00003CD0
	s_movk_i32 s0, 0x210                                       // 0000001C9620: B0000210
	v_lshlrev_b32_e32 v4, 9, v7                                // 0000001C9624: 30080E89
	s_clause 0x1                                               // 0000001C9628: BF850001
	scratch_store_b32 off, v0, off offset:32                   // 0000001C962C: DC690020 007C0000
	scratch_store_b32 off, v15, off offset:56                  // 0000001C9634: DC690038 007C0F00
	v_add_co_ci_u32_e64 v0, null, 0, v6, vcc_lo                // 0000001C963C: D5207C00 01AA0C80
	v_mad_u32_u24 v2, v2, s0, 0x2410                           // 0000001C9644: D60B0002 03FC0102 00002410
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001C9650: 84808814
	v_xor_b32_e32 v5, 1, v7                                    // 0000001C9654: 3A0A0E81
	scratch_store_b32 off, v0, off offset:36                   // 0000001C9658: DC690024 007C0000
	v_mov_b32_e32 v216, s1                                     // 0000001C9660: 7FB00201
	v_dual_mov_b32 v251, 0xf149f2ca :: v_dual_add_nc_u32 v0, v1, v3// 0000001C9664: CA2000FF FB000701 F149F2CA
	v_lshl_add_u32 v232, v5, 10, v1                            // 0000001C9670: D64600E8 04051505
	v_and_b32_e32 v1, 12, v228                                 // 0000001C9678: 3603C88C
	v_dual_mov_b32 v250, 0xf149f2ca :: v_dual_lshlrev_b32 v7, 8, v7// 0000001C967C: CA2200FF FA060E88 F149F2CA
	scratch_store_b32 off, v0, off offset:40                   // 0000001C9688: DC690028 007C0000
	v_lshl_or_b32 v0, v228, 5, v4                              // 0000001C9690: D6560000 04110BE4
	s_clause 0x1                                               // 0000001C9698: BF850001
	scratch_store_b32 off, v0, off offset:44                   // 0000001C969C: DC69002C 007C0000
	scratch_store_b32 off, v16, off offset:60                  // 0000001C96A4: DC69003C 007C1000
	v_or3_b32 v0, s0, v228, v16                                // 0000001C96AC: D6580000 0443C800
	v_mov_b32_e32 v255, 0xf149f2ca                             // 0000001C96B4: 7FFE02FF F149F2CA
	v_dual_mov_b32 v217, 0xf149f2ca :: v_dual_mov_b32 v252, 0xf149f2ca// 0000001C96BC: CA1000FF D9FC00FF F149F2CA
	v_mov_b32_e32 v227, 0xf149f2ca                             // 0000001C96C8: 7FC602FF F149F2CA
	scratch_store_b32 off, v0, off offset:48                   // 0000001C96D0: DC690030 007C0000
	v_mov_b32_e32 v0, 0                                        // 0000001C96D8: 7E000280
	v_lshlrev_b32_e32 v6, 5, v15                               // 0000001C96DC: 300C1E85
	v_lshlrev_b32_e32 v8, 1, v228                              // 0000001C96E0: 3011C881
	v_add_nc_u32_e32 v218, v2, v7                              // 0000001C96E4: 4BB40F02
	v_dual_mov_b32 v254, 0xf149f2ca :: v_dual_mov_b32 v205, 0  // 0000001C96E8: CA1000FF FECC0080 F149F2CA
	v_mov_b32_e32 v2, v0                                       // 0000001C96F4: 7E040300
	scratch_store_b32 off, v1, off offset:52                   // 0000001C96F8: DC690034 007C0100
	v_mov_b32_e32 v1, v0                                       // 0000001C9700: 7E020300
	v_mov_b32_e32 v3, v0                                       // 0000001C9704: 7E060300
	v_mov_b32_e32 v5, v0                                       // 0000001C9708: 7E0A0300
	v_or3_b32 v215, v4, v6, v8                                 // 0000001C970C: D65800D7 04220D04
	v_mov_b32_e32 v4, v0                                       // 0000001C9714: 7E080300
	v_mov_b32_e32 v6, v0                                       // 0000001C9718: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000001C971C: 7E0E0300
	s_clause 0x1                                               // 0000001C9720: BF850001
	scratch_store_b128 off, v[0:3], off                        // 0000001C9724: DC750000 007C0000
	scratch_store_b128 off, v[4:7], off offset:16              // 0000001C972C: DC750010 007C0400
	v_dual_mov_b32 v0, 0xf149f2ca :: v_dual_mov_b32 v253, 0    // 0000001C9734: CA1000FF 00FC0080 F149F2CA
	v_dual_mov_b32 v206, 0 :: v_dual_mov_b32 v229, 0           // 0000001C9740: CA100080 CEE40080
	v_dual_mov_b32 v202, 0 :: v_dual_mov_b32 v1, 0             // 0000001C9748: CA100080 CA000080
	v_dual_mov_b32 v204, 0 :: v_dual_mov_b32 v3, v201          // 0000001C9750: CA100080 CC0201C9
	v_dual_mov_b32 v2, v201 :: v_dual_mov_b32 v9, 0            // 0000001C9758: CA1001C9 02080080
	v_dual_mov_b32 v4, v201 :: v_dual_mov_b32 v17, 0           // 0000001C9760: CA1001C9 04100080
	v_mov_b32_e32 v5, v201                                     // 0000001C9768: 7E0A03C9
	v_dual_mov_b32 v6, v201 :: v_dual_mov_b32 v25, 0           // 0000001C976C: CA1001C9 06180080
	v_mov_b32_e32 v7, v201                                     // 0000001C9774: 7E0E03C9
	v_dual_mov_b32 v8, v201 :: v_dual_mov_b32 v57, 0           // 0000001C9778: CA1001C9 08380080
	v_dual_mov_b32 v10, v201 :: v_dual_mov_b32 v49, 0          // 0000001C9780: CA1001C9 0A300080
	v_mov_b32_e32 v11, v201                                    // 0000001C9788: 7E1603C9
	v_dual_mov_b32 v12, v201 :: v_dual_mov_b32 v41, 0          // 0000001C978C: CA1001C9 0C280080
	v_mov_b32_e32 v13, v201                                    // 0000001C9794: 7E1A03C9
	v_dual_mov_b32 v14, v201 :: v_dual_mov_b32 v33, 0          // 0000001C9798: CA1001C9 0E200080
	v_mov_b32_e32 v15, v201                                    // 0000001C97A0: 7E1E03C9
	v_mov_b32_e32 v16, v201                                    // 0000001C97A4: 7E2003C9
	v_mov_b32_e32 v18, v201                                    // 0000001C97A8: 7E2403C9
	v_mov_b32_e32 v19, v201                                    // 0000001C97AC: 7E2603C9
	v_mov_b32_e32 v20, v201                                    // 0000001C97B0: 7E2803C9
	v_mov_b32_e32 v21, v201                                    // 0000001C97B4: 7E2A03C9
	v_mov_b32_e32 v22, v201                                    // 0000001C97B8: 7E2C03C9
	v_mov_b32_e32 v23, v201                                    // 0000001C97BC: 7E2E03C9
	v_mov_b32_e32 v24, v201                                    // 0000001C97C0: 7E3003C9
	v_mov_b32_e32 v26, v201                                    // 0000001C97C4: 7E3403C9
	v_mov_b32_e32 v27, v201                                    // 0000001C97C8: 7E3603C9
	v_mov_b32_e32 v28, v201                                    // 0000001C97CC: 7E3803C9
	v_mov_b32_e32 v29, v201                                    // 0000001C97D0: 7E3A03C9
	v_mov_b32_e32 v30, v201                                    // 0000001C97D4: 7E3C03C9
	v_mov_b32_e32 v31, v201                                    // 0000001C97D8: 7E3E03C9
	v_mov_b32_e32 v32, v201                                    // 0000001C97DC: 7E4003C9
	v_mov_b32_e32 v58, v201                                    // 0000001C97E0: 7E7403C9
	v_mov_b32_e32 v59, v201                                    // 0000001C97E4: 7E7603C9
	v_mov_b32_e32 v60, v201                                    // 0000001C97E8: 7E7803C9
	v_mov_b32_e32 v61, v201                                    // 0000001C97EC: 7E7A03C9
	v_mov_b32_e32 v62, v201                                    // 0000001C97F0: 7E7C03C9
	v_mov_b32_e32 v63, v201                                    // 0000001C97F4: 7E7E03C9
	v_mov_b32_e32 v64, v201                                    // 0000001C97F8: 7E8003C9
	v_mov_b32_e32 v50, v201                                    // 0000001C97FC: 7E6403C9
	v_mov_b32_e32 v51, v201                                    // 0000001C9800: 7E6603C9
	v_mov_b32_e32 v52, v201                                    // 0000001C9804: 7E6803C9
	v_mov_b32_e32 v53, v201                                    // 0000001C9808: 7E6A03C9
	v_mov_b32_e32 v54, v201                                    // 0000001C980C: 7E6C03C9
	v_mov_b32_e32 v55, v201                                    // 0000001C9810: 7E6E03C9
	v_mov_b32_e32 v56, v201                                    // 0000001C9814: 7E7003C9
	v_mov_b32_e32 v42, v201                                    // 0000001C9818: 7E5403C9
	v_mov_b32_e32 v43, v201                                    // 0000001C981C: 7E5603C9
	v_mov_b32_e32 v44, v201                                    // 0000001C9820: 7E5803C9
	v_mov_b32_e32 v45, v201                                    // 0000001C9824: 7E5A03C9
	v_mov_b32_e32 v46, v201                                    // 0000001C9828: 7E5C03C9
	v_mov_b32_e32 v47, v201                                    // 0000001C982C: 7E5E03C9
	v_mov_b32_e32 v48, v201                                    // 0000001C9830: 7E6003C9
	v_mov_b32_e32 v34, v201                                    // 0000001C9834: 7E4403C9
	v_mov_b32_e32 v35, v201                                    // 0000001C9838: 7E4603C9
	v_mov_b32_e32 v36, v201                                    // 0000001C983C: 7E4803C9
	v_mov_b32_e32 v37, v201                                    // 0000001C9840: 7E4A03C9
	v_mov_b32_e32 v38, v201                                    // 0000001C9844: 7E4C03C9
	v_mov_b32_e32 v39, v201                                    // 0000001C9848: 7E4E03C9
	v_mov_b32_e32 v40, v201                                    // 0000001C984C: 7E5003C9
	.long 0xd59c40e9                                           // 0000001C9850: D59C40E9
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001C9854: 02010080
	s_mov_b32 s16, 0                                           // 0000001C9858: BE900080
	scratch_load_b32 v66, off, off offset:52                   // 0000001C985C: DC510034 427C0000
	v_mov_b32_e32 v65, s16                                     // 0000001C9864: 7E820210
	s_add_i32 s14, s14, -1                                     // 0000001C9868: 810EC10E
	s_waitcnt vmcnt(0)                                         // 0000001C986C: BF8903F7
	v_add_nc_u32_e32 v66, s16, v66                             // 0000001C9870: 4A848410
	ds_load_b128 v[91:94], v218                                // 0000001C9874: DBFC0000 5B0000DA
	ds_load_b128 v[95:98], v218 offset:16                      // 0000001C987C: DBFC0010 5F0000DA
	ds_load_b128 v[105:108], v218 offset:32                    // 0000001C9884: DBFC0020 690000DA
	ds_load_b128 v[109:112], v218 offset:48                    // 0000001C988C: DBFC0030 6D0000DA
	ds_load_b128 v[119:122], v218 offset:80                    // 0000001C9894: DBFC0050 770000DA
	ds_load_b128 v[115:118], v218 offset:64                    // 0000001C989C: DBFC0040 730000DA
	ds_load_b128 v[238:241], v218 offset:112                   // 0000001C98A4: DBFC0070 EE0000DA
	ds_load_b128 v[234:237], v218 offset:96                    // 0000001C98AC: DBFC0060 EA0000DA
	ds_load_b128 v[141:144], v218 offset:144                   // 0000001C98B4: DBFC0090 8D0000DA
	ds_load_b128 v[137:140], v218 offset:128                   // 0000001C98BC: DBFC0080 890000DA
	ds_load_b128 v[149:152], v218 offset:176                   // 0000001C98C4: DBFC00B0 950000DA
	ds_load_b128 v[145:148], v218 offset:160                   // 0000001C98CC: DBFC00A0 910000DA
	ds_load_b128 v[157:160], v218 offset:208                   // 0000001C98D4: DBFC00D0 9D0000DA
	ds_load_b128 v[153:156], v218 offset:192                   // 0000001C98DC: DBFC00C0 990000DA
	ds_load_b32 v70, v66 offset:1024                           // 0000001C98E4: D8D80400 46000042
	ds_load_b128 v[65:68], v65 offset:1024                     // 0000001C98EC: DBFC0400 41000041
	s_add_i32 s16, s16, 16                                     // 0000001C98F4: 81109010
	s_waitcnt lgkmcnt(1)                                       // 0000001C98F8: BF89FC17
	v_ashrrev_i32_e32 v71, 31, v70                             // 0000001C98FC: 348E8C9F
	s_waitcnt lgkmcnt(0)                                       // 0000001C9900: BF89FC07
	v_ashrrev_i32_e32 v69, 31, v68                             // 0000001C9904: 348A889F
	v_ashrrev_i32_e32 v73, 31, v65                             // 0000001C9908: 3492829F
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v65, v67         // 0000001C990C: CA100141 48400143
	v_ashrrev_i32_e32 v75, 31, v66                             // 0000001C9914: 3496849F
	v_mov_b32_e32 v74, v66                                     // 0000001C9918: 7E940342
	v_ashrrev_i32_e32 v66, 31, v67                             // 0000001C991C: 3484869F
	.long 0xd73c0043                                           // 0000001C9920: D73C0043
	v_cndmask_b32_e32 v1, 9, v68, vcc_lo                       // 0000001C9924: 02028889
	scratch_load_b32 v69, off, off offset:32                   // 0000001C9928: DC510020 457C0000
	.long 0xd73c0046                                           // 0000001C9930: D73C0046
	v_cndmask_b32_e32 v1, 12, v70, vcc_lo                      // 0000001C9934: 02028C8C
	.long 0xd73c0048                                           // 0000001C9938: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001C993C: 02029089
	.long 0xd73c004a                                           // 0000001C9940: D73C004A
	v_cndmask_b32_e32 v1, 9, v74, vcc_lo                       // 0000001C9944: 02029489
	.long 0xd73c0041                                           // 0000001C9948: D73C0041
	v_cndmask_b32_e32 v1, 9, v65, vcc_lo                       // 0000001C994C: 02028289
	s_waitcnt vmcnt(0)                                         // 0000001C9950: BF8903F7
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C9954: BF870004
	.long 0xd7006a4c                                           // 0000001C9958: D7006A4C
	v_cndmask_b32_e32 v1, v69, v70, vcc_lo                     // 0000001C995C: 02028D45
	scratch_load_b32 v69, off, off offset:36                   // 0000001C9960: DC510024 457C0000
	s_waitcnt vmcnt(0)                                         // 0000001C9968: BF8903F7
	v_add_co_ci_u32_e64 v77, null, v69, v71, vcc_lo            // 0000001C996C: D5207C4D 01AA8F45
	scratch_load_b32 v69, off, off offset:48                   // 0000001C9974: DC510030 457C0000
	s_clause 0x1                                               // 0000001C997C: BF850001
	global_load_b128 v[189:192], v[76:77], off offset:912      // 0000001C9980: DC5E0390 BD7C004C
	global_load_b128 v[185:188], v[76:77], off offset:896      // 0000001C9988: DC5E0380 B97C004C
	s_waitcnt vmcnt(2)                                         // 0000001C9990: BF890BF7
	.long 0xd7006a4e                                           // 0000001C9994: D7006A4E
	v_cndmask_b32_e32 v1, v72, v69, vcc_lo                     // 0000001C9998: 02028B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C999C: BF8700A1
	v_add_co_ci_u32_e64 v79, null, v73, v216, vcc_lo           // 0000001C99A0: D5207C4F 01ABB149
	.long 0xd7006a49                                           // 0000001C99A8: D7006A49
	v_cndmask_b32_e32 v1, v74, v69, vcc_lo                     // 0000001C99AC: 02028B4A
	v_add_co_ci_u32_e64 v74, null, v75, v216, vcc_lo           // 0000001C99B0: D5207C4A 01ABB14B
	.long 0xd7006a50                                           // 0000001C99B8: D7006A50
	v_cndmask_b32_e32 v1, v65, v69, vcc_lo                     // 0000001C99BC: 02028B41
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C99C0: BF870001
	v_add_co_ci_u32_e64 v81, null, v66, v216, vcc_lo           // 0000001C99C4: D5207C51 01ABB142
	.long 0xd7006a52                                           // 0000001C99CC: D7006A52
	v_cndmask_b32_e32 v1, v67, v69, vcc_lo                     // 0000001C99D0: 02028B43
	.long 0xd73c004e                                           // 0000001C99D4: D73C004E
	v_cndmask_b32_e32 v1, 3, v78, vcc_lo                       // 0000001C99D8: 02029C83
	v_add_co_ci_u32_e64 v83, null, v68, v216, vcc_lo           // 0000001C99DC: D5207C53 01ABB144
	.long 0xd73c0049                                           // 0000001C99E4: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 0000001C99E8: 02029283
	s_clause 0xd                                               // 0000001C99EC: BF85000D
	global_load_b128 v[127:130], v[76:77], off offset:16       // 0000001C99F0: DC5E0010 7F7C004C
	global_load_b128 v[123:126], v[76:77], off                 // 0000001C99F8: DC5E0000 7B7C004C
	global_load_b128 v[246:249], v[76:77], off offset:144      // 0000001C9A00: DC5E0090 F67C004C
	global_load_b128 v[242:245], v[76:77], off offset:128      // 0000001C9A08: DC5E0080 F27C004C
	global_load_b128 v[69:72], v[76:77], off offset:272        // 0000001C9A10: DC5E0110 457C004C
	global_load_b128 v[65:68], v[76:77], off offset:256        // 0000001C9A18: DC5E0100 417C004C
	global_load_b128 v[223:226], v[76:77], off offset:400      // 0000001C9A20: DC5E0190 DF7C004C
	global_load_b128 v[219:222], v[76:77], off offset:384      // 0000001C9A28: DC5E0180 DB7C004C
	global_load_b128 v[165:168], v[76:77], off offset:528      // 0000001C9A30: DC5E0210 A57C004C
	global_load_b128 v[161:164], v[76:77], off offset:512      // 0000001C9A38: DC5E0200 A17C004C
	global_load_b128 v[173:176], v[76:77], off offset:656      // 0000001C9A40: DC5E0290 AD7C004C
	global_load_b128 v[169:172], v[76:77], off offset:640      // 0000001C9A48: DC5E0280 A97C004C
	global_load_b128 v[181:184], v[76:77], off offset:784      // 0000001C9A50: DC5E0310 B57C004C
	global_load_b128 v[177:180], v[76:77], off offset:768      // 0000001C9A58: DC5E0300 B17C004C
	.long 0xd73c004b                                           // 0000001C9A60: D73C004B
	v_cndmask_b32_e32 v1, 3, v80, vcc_lo                       // 0000001C9A64: 0202A083
	.long 0xd73c0050                                           // 0000001C9A68: D73C0050
	v_cndmask_b32_e32 v1, 3, v82, vcc_lo                       // 0000001C9A6C: 0202A483
	.long 0xd7006a83                                           // 0000001C9A70: D7006A83
	v_cndmask_b32_e32 v1, s8, v78, vcc_lo                      // 0000001C9A74: 02029C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C9A78: BF8700A1
	v_add_co_ci_u32_e64 v132, null, s9, v79, vcc_lo            // 0000001C9A7C: D5207C84 01AA9E09
	.long 0xd7006a85                                           // 0000001C9A84: D7006A85
	v_cndmask_b32_e32 v1, s8, v73, vcc_lo                      // 0000001C9A88: 02029208
	v_add_co_ci_u32_e64 v134, null, s9, v74, vcc_lo            // 0000001C9A8C: D5207C86 01AA9409
	.long 0xd7006a87                                           // 0000001C9A94: D7006A87
	v_cndmask_b32_e32 v1, s8, v75, vcc_lo                      // 0000001C9A98: 02029608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C9A9C: BF8700A1
	v_add_co_ci_u32_e64 v136, null, s9, v76, vcc_lo            // 0000001C9AA0: D5207C88 01AA9809
	.long 0xd7006ae6                                           // 0000001C9AA8: D7006AE6
	v_cndmask_b32_e32 v1, s8, v80, vcc_lo                      // 0000001C9AAC: 0202A008
	v_add_co_ci_u32_e64 v231, null, s9, v81, vcc_lo            // 0000001C9AB0: D5207CE7 01AAA209
	s_clause 0x2                                               // 0000001C9AB8: BF850002
	global_load_b64 v[73:74], v[131:132], off                  // 0000001C9ABC: DC560000 497C0083
	global_load_b64 v[81:82], v[131:132], off offset:128       // 0000001C9AC4: DC560080 517C0083
	global_load_b64 v[89:90], v[131:132], off offset:256       // 0000001C9ACC: DC560100 597C0083
	s_clause 0x1                                               // 0000001C9AD4: BF850001
	scratch_load_b128 v[207:210], off, off                     // 0000001C9AD8: DC5D0000 CF7C0000
	scratch_load_b128 v[211:214], off, off offset:16           // 0000001C9AE0: DC5D0010 D37C0000
	v_cmp_gt_i32_e32 vcc_lo, s15, v228                         // 0000001C9AE8: 7C89C80F
	s_add_i32 s15, s15, -16                                    // 0000001C9AEC: 810FD00F
	s_cmp_lg_u32 s14, 0                                        // 0000001C9AF0: BF07800E
	s_waitcnt vmcnt(0)                                         // 0000001C9AF4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[193:200], v[91:98], v[123:130], v[207:214]// 0000001C9AF8: CC4140C1 1F3EF75B
	s_clause 0xc                                               // 0000001C9B00: BF85000C
	global_load_b64 v[97:98], v[131:132], off offset:384       // 0000001C9B04: DC560180 617C0083
	global_load_b64 v[75:76], v[133:134], off                  // 0000001C9B0C: DC560000 4B7C0085
	global_load_b64 v[83:84], v[133:134], off offset:128       // 0000001C9B14: DC560080 537C0085
	global_load_b64 v[91:92], v[133:134], off offset:256       // 0000001C9B1C: DC560100 5B7C0085
	global_load_b64 v[99:100], v[133:134], off offset:384      // 0000001C9B24: DC560180 637C0085
	global_load_b64 v[77:78], v[135:136], off                  // 0000001C9B2C: DC560000 4D7C0087
	global_load_b64 v[85:86], v[135:136], off offset:128       // 0000001C9B34: DC560080 557C0087
	global_load_b64 v[93:94], v[135:136], off offset:256       // 0000001C9B3C: DC560100 5D7C0087
	global_load_b64 v[101:102], v[135:136], off offset:384     // 0000001C9B44: DC560180 657C0087
	global_load_b64 v[79:80], v[230:231], off                  // 0000001C9B4C: DC560000 4F7C00E6
	global_load_b64 v[87:88], v[230:231], off offset:128       // 0000001C9B54: DC560080 577C00E6
	global_load_b64 v[95:96], v[230:231], off offset:256       // 0000001C9B5C: DC560100 5F7C00E6
	global_load_b64 v[103:104], v[230:231], off offset:384     // 0000001C9B64: DC560180 677C00E6
	v_mov_b32_e32 v207, v229                                   // 0000001C9B6C: 7F9E03E5
	v_wmma_f32_16x16x16_bf16 v[193:200], v[105:112], v[242:249], v[193:200]// 0000001C9B70: CC4140C1 1F07E569
	s_clause 0x1                                               // 0000001C9B78: BF850001
	global_load_b64 v[105:106], v[131:132], off offset:512     // 0000001C9B7C: DC560200 697C0083
	global_load_b64 v[113:114], v[131:132], off offset:640     // 0000001C9B84: DC560280 717C0083
	v_wmma_f32_16x16x16_bf16 v[193:200], v[115:122], v[65:72], v[193:200]// 0000001C9B8C: CC4140C1 1F068373
	ds_load_b128 v[69:72], v218 offset:240                     // 0000001C9B94: DBFC00F0 450000DA
	ds_load_b128 v[65:68], v218 offset:224                     // 0000001C9B9C: DBFC00E0 410000DA
	s_clause 0xd                                               // 0000001C9BA4: BF85000D
	global_load_b64 v[121:122], v[131:132], off offset:768     // 0000001C9BA8: DC560300 797C0083
	global_load_b64 v[129:130], v[131:132], off offset:896     // 0000001C9BB0: DC560380 817C0083
	global_load_b64 v[107:108], v[133:134], off offset:512     // 0000001C9BB8: DC560200 6B7C0085
	global_load_b64 v[115:116], v[133:134], off offset:640     // 0000001C9BC0: DC560280 737C0085
	global_load_b64 v[123:124], v[133:134], off offset:768     // 0000001C9BC8: DC560300 7B7C0085
	global_load_b64 v[131:132], v[133:134], off offset:896     // 0000001C9BD0: DC560380 837C0085
	global_load_b64 v[109:110], v[135:136], off offset:512     // 0000001C9BD8: DC560200 6D7C0087
	global_load_b64 v[117:118], v[135:136], off offset:640     // 0000001C9BE0: DC560280 757C0087
	global_load_b64 v[125:126], v[135:136], off offset:768     // 0000001C9BE8: DC560300 7D7C0087
	global_load_b64 v[133:134], v[135:136], off offset:896     // 0000001C9BF0: DC560380 857C0087
	global_load_b64 v[111:112], v[230:231], off offset:512     // 0000001C9BF8: DC560200 6F7C00E6
	global_load_b64 v[119:120], v[230:231], off offset:640     // 0000001C9C00: DC560280 777C00E6
	global_load_b64 v[127:128], v[230:231], off offset:768     // 0000001C9C08: DC560300 7F7C00E6
	global_load_b64 v[135:136], v[230:231], off offset:896     // 0000001C9C10: DC560380 877C00E6
	v_dual_mov_b32 v230, v204 :: v_dual_mov_b32 v231, v205     // 0000001C9C18: CA1001CC E6E601CD
	v_wmma_f32_16x16x16_bf16 v[193:200], v[234:241], v[219:226], v[193:200]// 0000001C9C20: CC4140C1 1F07B7EA
	.long 0xd59c48ea                                           // 0000001C9C28: D59C48EA
	v_cndmask_b32_e32 v0, v233, v128, vcc_lo                   // 0000001C9C2C: 020101E9
	.long 0xd59c48dc                                           // 0000001C9C30: D59C48DC
	v_cndmask_b32_e32 v0, v233, v128, vcc_lo                   // 0000001C9C34: 020101E9
	.long 0xd59c48db                                           // 0000001C9C38: D59C48DB
	v_cndmask_b32_e32 v0, v233, v128, vcc_lo                   // 0000001C9C3C: 020101E9
	.long 0xd59c48dd                                           // 0000001C9C40: D59C48DD
	v_cndmask_b32_e32 v0, v233, v128, vcc_lo                   // 0000001C9C44: 020101E9
	v_wmma_f32_16x16x16_bf16 v[193:200], v[137:144], v[161:168], v[193:200]// 0000001C9C48: CC4140C1 1F074389
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C9C50: BF870091
	v_wmma_f32_16x16x16_bf16 v[193:200], v[145:152], v[169:176], v[193:200]// 0000001C9C54: CC4140C1 1F075391
	v_wmma_f32_16x16x16_bf16 v[193:200], v[153:160], v[177:184], v[193:200]// 0000001C9C5C: CC4140C1 1F076399
	s_waitcnt lgkmcnt(0)                                       // 0000001C9C64: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C9C68: BF870001
	v_wmma_f32_16x16x16_bf16 v[193:200], v[65:72], v[185:192], v[193:200]// 0000001C9C6C: CC4140C1 1F077341
	scratch_load_b32 v65, off, off offset:40                   // 0000001C9C74: DC510028 417C0000
	s_waitcnt vmcnt(0)                                         // 0000001C9C7C: BF8903F7
	ds_store_2addr_b32 v65, v193, v194 offset1:32              // 0000001C9C80: D8382000 00C2C141
	ds_store_2addr_b32 v65, v195, v196 offset0:64 offset1:96   // 0000001C9C88: D8386040 00C4C341
	ds_store_2addr_b32 v65, v197, v198 offset0:128 offset1:160 // 0000001C9C90: D838A080 00C6C541
	ds_store_2addr_b32 v65, v199, v200 offset0:192 offset1:224 // 0000001C9C98: D838E0C0 00C8C741
	s_waitcnt lgkmcnt(0)                                       // 0000001C9CA0: BF89FC07
	s_barrier                                                  // 0000001C9CA4: BFBD0000
	ds_load_2addr_b32 v[65:66], v232 offset1:32                // 0000001C9CA8: D8DC2000 410000E8
	ds_load_2addr_b32 v[67:68], v232 offset0:64 offset1:96     // 0000001C9CB0: D8DC6040 430000E8
	ds_load_2addr_b32 v[69:70], v232 offset0:128 offset1:160   // 0000001C9CB8: D8DCA080 450000E8
	ds_load_2addr_b32 v[71:72], v232 offset0:192 offset1:224   // 0000001C9CC0: D8DCE0C0 470000E8
	s_waitcnt lgkmcnt(3)                                       // 0000001C9CC8: BF89FC37
	v_dual_mov_b32 v208, v206 :: v_dual_add_f32 v65, v193, v65 // 0000001C9CCC: CA0801CE D04083C1
	s_waitcnt lgkmcnt(2)                                       // 0000001C9CD4: BF89FC27
	v_dual_add_f32 v66, v194, v66 :: v_dual_add_f32 v67, v195, v67// 0000001C9CD8: C90885C2 424287C3
	s_waitcnt lgkmcnt(0)                                       // 0000001C9CE0: BF89FC07
	v_add_f32_e32 v72, v200, v72                               // 0000001C9CE4: 069091C8
	v_dual_add_f32 v68, v196, v68 :: v_dual_add_f32 v69, v197, v69// 0000001C9CE8: C90889C4 44448BC5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C9CF0: BF870123
	v_dual_mul_f32 v66, 0x3d800000, v66 :: v_dual_mul_f32 v67, 0x3d800000, v67// 0000001C9CF4: C8C684FF 424286FF 3D800000
	v_dual_mul_f32 v65, 0x3d800000, v65 :: v_dual_add_f32 v70, v198, v70// 0000001C9D00: C8C882FF 41468DC6 3D800000
	v_dual_add_f32 v71, v199, v71 :: v_dual_cndmask_b32 v66, 0xf149f2ca, v66// 0000001C9D0C: C9128FC7 474284FF F149F2CA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C9D18: BF870194
	v_dual_mul_f32 v68, 0x3d800000, v68 :: v_dual_mul_f32 v69, 0x3d800000, v69// 0000001C9D1C: C8C688FF 44448AFF 3D800000
	v_cndmask_b32_e32 v65, 0xf149f2ca, v65, vcc_lo             // 0000001C9D28: 028282FF F149F2CA
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C9D30: BF870193
	v_dual_mul_f32 v70, 0x3d800000, v70 :: v_dual_mul_f32 v71, 0x3d800000, v71// 0000001C9D34: C8C68CFF 46468EFF 3D800000
	v_dual_cndmask_b32 v68, 0xf149f2ca, v68 :: v_dual_cndmask_b32 v67, 0xf149f2ca, v67// 0000001C9D40: CA5288FF 444286FF F149F2CA
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C9D4C: BF870223
	v_mov_b32_dpp v137, v65 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9D50: 7F1202FA FF096141
	v_mul_f32_e32 v72, 0x3d800000, v72                         // 0000001C9D58: 109090FF 3D800000
	v_cndmask_b32_e32 v71, 0xf149f2ca, v71, vcc_lo             // 0000001C9D60: 028E8EFF F149F2CA
	v_mov_b32_dpp v138, v66 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9D68: 7F1402FA FF096142
	v_dual_cndmask_b32 v70, 0xf149f2ca, v70 :: v_dual_cndmask_b32 v69, 0xf149f2ca, v69// 0000001C9D70: CA528CFF 46448AFF F149F2CA
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C9D7C: BF8701B4
	v_dual_max_f32 v137, v137, v137 :: v_dual_cndmask_b32 v72, 0xf149f2ca, v72// 0000001C9D80: CA931389 894890FF F149F2CA
	v_mov_b32_dpp v139, v67 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9D8C: 7F1602FA FF096143
	v_mov_b32_dpp v140, v68 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9D94: 7F1802FA FF096144
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v65, v137// 0000001C9D9C: CA95158A 8A891341
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C9DA4: BF870244
	v_mov_b32_dpp v144, v72 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9DA8: 7F2002FA FF096148
	v_mov_b32_dpp v141, v69 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9DB0: 7F1A02FA FF096145
	v_mov_b32_dpp v142, v70 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9DB8: 7F1C02FA FF096146
	v_mov_b32_dpp v143, v71 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9DC0: 7F1E02FA FF096147
	v_dual_max_f32 v139, v139, v139 :: v_dual_max_f32 v144, v144, v144// 0000001C9DC8: CA95178B 8B912190
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C9DD0: BF870114
	v_dual_max_f32 v140, v140, v140 :: v_dual_max_f32 v141, v141, v141// 0000001C9DD4: CA95198C 8C8D1B8D
	v_dual_max_f32 v138, v66, v138 :: v_dual_max_f32 v139, v67, v139// 0000001C9DDC: CA951542 8A8B1743
	v_mov_b32_dpp v145, v137 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9DE4: 7F2202FA FF096289
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C9DEC: BF870004
	v_max_f32_e32 v144, v72, v144                              // 0000001C9DF0: 21212148
	v_dual_max_f32 v142, v142, v142 :: v_dual_max_f32 v143, v143, v143// 0000001C9DF4: CA951D8E 8E8F1F8F
	v_dual_max_f32 v140, v68, v140 :: v_dual_max_f32 v141, v69, v141// 0000001C9DFC: CA951944 8C8D1B45
	v_mov_b32_dpp v146, v138 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E04: 7F2402FA FF09628A
	v_max_f32_e32 v145, v145, v145                             // 0000001C9E0C: 21232391
	v_mov_b32_dpp v152, v144 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E10: 7F3002FA FF096290
	v_dual_max_f32 v142, v70, v142 :: v_dual_max_f32 v143, v71, v143// 0000001C9E18: CA951D46 8E8F1F47
	v_mov_b32_dpp v147, v139 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E20: 7F2602FA FF09628B
	v_mov_b32_dpp v148, v140 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E28: 7F2802FA FF09628C
	v_max_f32_e32 v146, v146, v146                             // 0000001C9E30: 21252592
	v_dual_max_f32 v152, v152, v152 :: v_dual_max_f32 v137, v137, v145// 0000001C9E34: CA953198 98892389
	v_mov_b32_dpp v149, v141 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E3C: 7F2A02FA FF09628D
	v_mov_b32_dpp v150, v142 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E44: 7F2C02FA FF09628E
	v_mov_b32_dpp v151, v143 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E4C: 7F2E02FA FF09628F
	v_dual_max_f32 v147, v147, v147 :: v_dual_max_f32 v148, v148, v148// 0000001C9E54: CA952793 93952994
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C9E5C: BF870004
	v_dual_max_f32 v149, v149, v149 :: v_dual_max_f32 v138, v138, v146// 0000001C9E60: CA952B95 958B258A
	v_mov_b32_dpp v145, v137 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E68: 7F2202FA FF096489
	v_max_f32_e32 v144, v144, v152                             // 0000001C9E70: 21213190
	v_dual_max_f32 v150, v150, v150 :: v_dual_max_f32 v151, v151, v151// 0000001C9E74: CA952D96 96972F97
	v_dual_max_f32 v139, v139, v147 :: v_dual_max_f32 v140, v140, v148// 0000001C9E7C: CA95278B 8B8D298C
	v_max_f32_e32 v141, v141, v149                             // 0000001C9E84: 211B2B8D
	v_mov_b32_dpp v146, v138 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E88: 7F2402FA FF09648A
	v_max_f32_e32 v145, v145, v145                             // 0000001C9E90: 21232391
	v_mov_b32_dpp v152, v144 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9E94: 7F3002FA FF096490
	v_dual_max_f32 v142, v142, v150 :: v_dual_max_f32 v143, v143, v151// 0000001C9E9C: CA952D8E 8E8F2F8F
	v_mov_b32_dpp v147, v139 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9EA4: 7F2602FA FF09648B
	v_mov_b32_dpp v148, v140 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9EAC: 7F2802FA FF09648C
	v_max_f32_e32 v146, v146, v146                             // 0000001C9EB4: 21252592
	v_dual_max_f32 v152, v152, v152 :: v_dual_max_f32 v137, v137, v145// 0000001C9EB8: CA953198 98892389
	v_mov_b32_dpp v149, v141 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9EC0: 7F2A02FA FF09648D
	v_mov_b32_dpp v150, v142 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9EC8: 7F2C02FA FF09648E
	v_mov_b32_dpp v151, v143 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9ED0: 7F2E02FA FF09648F
	v_dual_max_f32 v147, v147, v147 :: v_dual_max_f32 v148, v148, v148// 0000001C9ED8: CA952793 93952994
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C9EE0: BF870224
	v_dual_max_f32 v149, v149, v149 :: v_dual_max_f32 v138, v138, v146// 0000001C9EE4: CA952B95 958B258A
	v_mov_b32_dpp v145, v137 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9EEC: 7F2202FA FF096889
	v_dual_max_f32 v150, v150, v150 :: v_dual_max_f32 v151, v151, v151// 0000001C9EF4: CA952D96 96972F97
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C9EFC: BF870214
	v_dual_max_f32 v139, v139, v147 :: v_dual_max_f32 v140, v140, v148// 0000001C9F00: CA95278B 8B8D298C
	v_max_f32_e32 v141, v141, v149                             // 0000001C9F08: 211B2B8D
	v_mov_b32_dpp v146, v138 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F0C: 7F2402FA FF09688A
	v_max3_f32 v137, v250, v137, v145                          // 0000001C9F14: D61C0089 064713FA
	v_max_f32_e32 v144, v144, v152                             // 0000001C9F1C: 21213190
	v_dual_max_f32 v142, v142, v150 :: v_dual_max_f32 v143, v143, v151// 0000001C9F20: CA952D8E 8E8F2F8F
	v_mov_b32_dpp v147, v139 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F28: 7F2602FA FF09688B
	v_mov_b32_dpp v148, v140 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F30: 7F2802FA FF09688C
	v_max3_f32 v138, v251, v138, v146                          // 0000001C9F38: D61C008A 064B15FB
	v_sub_f32_e32 v65, v65, v137                               // 0000001C9F40: 08831341
	v_mov_b32_dpp v152, v144 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F44: 7F3002FA FF096890
	v_mov_b32_dpp v149, v141 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F4C: 7F2A02FA FF09688D
	v_mov_b32_dpp v150, v142 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F54: 7F2C02FA FF09688E
	v_mov_b32_dpp v151, v143 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C9F5C: 7F2E02FA FF09688F
	v_max3_f32 v139, v252, v139, v147                          // 0000001C9F64: D61C008B 064F17FC
	v_max3_f32 v140, v254, v140, v148                          // 0000001C9F6C: D61C008C 065319FE
	v_max3_f32 v144, v227, v144, v152                          // 0000001C9F74: D61C0090 066321E3
	v_sub_f32_e32 v66, v66, v138                               // 0000001C9F7C: 08851542
	v_max3_f32 v141, v255, v141, v149                          // 0000001C9F80: D61C008D 06571BFF
	v_max3_f32 v142, v217, v142, v150                          // 0000001C9F88: D61C008E 065B1DD9
	v_max3_f32 v143, v0, v143, v151                            // 0000001C9F90: D61C008F 065F1F00
	v_dual_sub_f32 v67, v67, v139 :: v_dual_sub_f32 v68, v68, v140// 0000001C9F98: C94B1743 43451944
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C9FA0: BF870224
	v_dual_sub_f32 v69, v69, v141 :: v_dual_sub_f32 v72, v72, v144// 0000001C9FA4: C94B1B45 45492148
	v_mul_f32_e32 v145, 0x3fb8aa3b, v66                        // 0000001C9FAC: 112284FF 3FB8AA3B
	v_dual_sub_f32 v70, v70, v142 :: v_dual_sub_f32 v71, v71, v143// 0000001C9FB4: C94B1D46 46471F47
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C9FBC: BF870114
	v_dual_mul_f32 v146, 0x3fb8aa3b, v65 :: v_dual_mul_f32 v147, 0x3fb8aa3b, v68// 0000001C9FC0: C8C682FF 929288FF 3FB8AA3B
	v_dual_mul_f32 v148, 0x3fb8aa3b, v67 :: v_dual_mul_f32 v149, 0x3fb8aa3b, v70// 0000001C9FCC: C8C686FF 94948CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C9FD8: BF870004
	v_fma_f32 v153, 0x3fb8aa3b, v66, -v145                     // 0000001C9FDC: D6130099 864684FF 3FB8AA3B
	v_rndne_f32_e32 v154, v145                                 // 0000001C9FE8: 7F344791
	v_dual_mul_f32 v150, 0x3fb8aa3b, v69 :: v_dual_mul_f32 v151, 0x3fb8aa3b, v72// 0000001C9FEC: C8C68AFF 969690FF 3FB8AA3B
	v_mul_f32_e32 v152, 0x3fb8aa3b, v71                        // 0000001C9FF8: 11308EFF 3FB8AA3B
	v_fma_f32 v155, 0x3fb8aa3b, v65, -v146                     // 0000001CA000: D613009B 864A82FF 3FB8AA3B
	v_rndne_f32_e32 v156, v146                                 // 0000001CA00C: 7F384792
	v_fma_f32 v157, 0x3fb8aa3b, v68, -v147                     // 0000001CA010: D613009D 864E88FF 3FB8AA3B
	v_rndne_f32_e32 v158, v147                                 // 0000001CA01C: 7F3C4793
	v_rndne_f32_e32 v160, v148                                 // 0000001CA020: 7F404794
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA024: BF870004
	v_dual_fmac_f32 v153, 0x32a5705f, v66 :: v_dual_sub_f32 v146, v146, v156// 0000001CA028: C80A84FF 99933992 32A5705F
	v_sub_f32_e32 v145, v145, v154                             // 0000001CA034: 09233591
	v_fma_f32 v159, 0x3fb8aa3b, v67, -v148                     // 0000001CA038: D613009F 865286FF 3FB8AA3B
	v_rndne_f32_e32 v164, v150                                 // 0000001CA044: 7F484796
	v_dual_fmac_f32 v155, 0x32a5705f, v65 :: v_dual_sub_f32 v148, v148, v160// 0000001CA048: C80A82FF 9B954194 32A5705F
	v_fmac_f32_e32 v157, 0x32a5705f, v68                       // 0000001CA054: 573A88FF 32A5705F
	v_sub_f32_e32 v147, v147, v158                             // 0000001CA05C: 09273D93
	v_add_f32_e32 v145, v145, v153                             // 0000001CA060: 07233391
	v_fma_f32 v163, 0x3fb8aa3b, v69, -v150                     // 0000001CA064: D61300A3 865A8AFF 3FB8AA3B
	v_sub_f32_e32 v150, v150, v164                             // 0000001CA070: 092D4996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CA074: BF870214
	v_dual_add_f32 v146, v146, v155 :: v_dual_add_f32 v147, v147, v157// 0000001CA078: C9093792 92933B93
	v_exp_f32_e32 v145, v145                                   // 0000001CA080: 7F224B91
	v_cvt_i32_f32_e32 v154, v154                               // 0000001CA084: 7F34119A
	v_cvt_i32_f32_e32 v156, v156                               // 0000001CA088: 7F38119C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CA08C: BF870003
	v_exp_f32_e32 v146, v146                                   // 0000001CA090: 7F244B92
	v_exp_f32_e32 v147, v147                                   // 0000001CA094: 7F264B93
	v_cvt_i32_f32_e32 v158, v158                               // 0000001CA098: 7F3C119E
	.long 0xd41b0007                                           // 0000001CA09C: D41B0007
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v66, vcc_lo              // 0000001CA0A0: 020284FF C2CE8ED0
	v_fma_f32 v165, 0x3fb8aa3b, v72, -v151                     // 0000001CA0A8: D61300A5 865E90FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v65                  // 0000001CA0B4: 7C3682FF C2CE8ED0
	.long 0xd41b0000                                           // 0000001CA0BC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v68, vcc_lo              // 0000001CA0C0: 020288FF C2CE8ED0
	.long 0xd71c0091                                           // 0000001CA0C8: D71C0091
	v_cndmask_b32_e32 v1, v145, v154, vcc_lo                   // 0000001CA0CC: 02033591
	v_fma_f32 v167, 0x3fb8aa3b, v71, -v152                     // 0000001CA0D0: D61300A7 86628EFF 3FB8AA3B
	v_rndne_f32_e32 v168, v152                                 // 0000001CA0DC: 7F504798
	.long 0xd71c0092                                           // 0000001CA0E0: D71C0092
	v_cndmask_b32_e32 v1, v146, v156, vcc_lo                   // 0000001CA0E4: 02033992
	.long 0xd71c0093                                           // 0000001CA0E8: D71C0093
	v_cndmask_b32_e32 v1, v147, v158, vcc_lo                   // 0000001CA0EC: 02033D93
	v_cndmask_b32_e64 v145, 0, v145, s7                        // 0000001CA0F0: D5010091 001F2280
	.long 0xd41e0007                                           // 0000001CA0F8: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v66, vcc_lo              // 0000001CA0FC: 020284FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA104: BF870004
	v_dual_fmac_f32 v165, 0x32a5705f, v72 :: v_dual_cndmask_b32 v146, 0, v146// 0000001CA108: C81290FF A5932480 32A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v65                  // 0000001CA114: 7C3C82FF 42B17218
	v_cndmask_b32_e64 v65, 0, v147, s0                         // 0000001CA11C: D5010041 00032680
	.long 0xd41e0000                                           // 0000001CA124: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v68, vcc_lo              // 0000001CA128: 020288FF 42B17218
	v_cndmask_b32_e64 v206, 0x7f800000, v145, s7               // 0000001CA130: D50100CE 001F22FF 7F800000
	v_fma_f32 v161, 0x3fb8aa3b, v70, -v149                     // 0000001CA13C: D61300A1 86568CFF 3FB8AA3B
	v_rndne_f32_e32 v162, v149                                 // 0000001CA148: 7F444795
	v_dual_fmac_f32 v159, 0x32a5705f, v67 :: v_dual_sub_f32 v152, v152, v168// 0000001CA14C: C80A86FF 9F995198 32A5705F
	v_cndmask_b32_e64 v205, 0x7f800000, v65, s0                // 0000001CA158: D50100CD 000282FF 7F800000
	.long 0xd59c08e9                                           // 0000001CA164: D59C08E9
	v_cndmask_b32_e32 v0, v206, v128, vcc_lo                   // 0000001CA168: 020101CE
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CA16C: BF870233
	v_dual_fmac_f32 v161, 0x32a5705f, v70 :: v_dual_add_f32 v148, v148, v159// 0000001CA170: C8088CFF A1953F94 32A5705F
	v_sub_f32_e32 v156, v227, v144                             // 0000001CA17C: 093921E3
	v_cvt_i32_f32_e32 v160, v160                               // 0000001CA180: 7F4011A0
	v_and_b32_e32 v65, 1, v233                                 // 0000001CA184: 3683D281
	.long 0xd59c08e9                                           // 0000001CA188: D59C08E9
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                   // 0000001CA18C: 020101CD
	v_cndmask_b32_e32 v145, 0x7f800000, v146, vcc_lo           // 0000001CA190: 032324FF 7F800000
	v_exp_f32_e32 v148, v148                                   // 0000001CA198: 7F284B94
	v_cvt_i32_f32_e32 v164, v164                               // 0000001CA19C: 7F4811A4
	.long 0xd41b0001                                           // 0000001CA1A0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v67, vcc_lo              // 0000001CA1A4: 020286FF C2CE8ED0
	.long 0xd41b0003                                           // 0000001CA1AC: D41B0003
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v70, vcc_lo              // 0000001CA1B0: 02028CFF C2CE8ED0
	.long 0xd59c08ea                                           // 0000001CA1B8: D59C08EA
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                   // 0000001CA1BC: 02010191
	v_fmac_f32_e32 v167, 0x32a5705f, v71                       // 0000001CA1C0: 574E8EFF 32A5705F
	.long 0xd41b0004                                           // 0000001CA1C8: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v69, vcc_lo              // 0000001CA1CC: 02028AFF C2CE8ED0
	v_rndne_f32_e32 v166, v151                                 // 0000001CA1D4: 7F4C4797
	v_sub_f32_e32 v154, v217, v142                             // 0000001CA1D8: 09351DD9
	v_dual_fmac_f32 v163, 0x32a5705f, v69 :: v_dual_and_b32 v66, 1, v234// 0000001CA1DC: C8248AFF A343D481 32A5705F
	v_dual_add_f32 v152, v152, v167 :: v_dual_sub_f32 v149, v149, v162// 0000001CA1E8: C90B4F98 98954595
	v_cvt_i32_f32_e32 v162, v162                               // 0000001CA1F0: 7F4411A2
	.long 0xd71c0094                                           // 0000001CA1F4: D71C0094
	v_cndmask_b32_e32 v1, v148, v160, vcc_lo                   // 0000001CA1F8: 02034194
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CA1FC: BF870214
	v_add_f32_e32 v150, v150, v163                             // 0000001CA200: 072D4796
	v_exp_f32_e32 v152, v152                                   // 0000001CA204: 7F304B98
	v_add_f32_e32 v149, v149, v161                             // 0000001CA208: 072B4395
	v_cvt_i32_f32_e32 v168, v168                               // 0000001CA20C: 7F5011A8
	v_cndmask_b32_e64 v68, 0, v148, s1                         // 0000001CA210: D5010044 00072880
	v_exp_f32_e32 v150, v150                                   // 0000001CA218: 7F2C4B96
	.long 0xd41e0001                                           // 0000001CA21C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v67, vcc_lo              // 0000001CA220: 020286FF 42B17218
	v_exp_f32_e32 v149, v149                                   // 0000001CA228: 7F2A4B95
	.long 0xd41b0005                                           // 0000001CA22C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v72, vcc_lo              // 0000001CA230: 020290FF C2CE8ED0
	.long 0xd41b0006                                           // 0000001CA238: D41B0006
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v71, vcc_lo              // 0000001CA23C: 02028EFF C2CE8ED0
	v_sub_f32_e32 v153, v255, v141                             // 0000001CA244: 09331BFF
	v_cndmask_b32_e64 v146, 0x7f800000, v68, s1                // 0000001CA248: D5010092 000688FF 7F800000
	.long 0xd71c0098                                           // 0000001CA254: D71C0098
	v_cndmask_b32_e32 v1, v152, v168, vcc_lo                   // 0000001CA258: 02035198
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CA25C: BF870196
	.long 0xd71c0096                                           // 0000001CA260: D71C0096
	v_cndmask_b32_e32 v1, v150, v164, vcc_lo                   // 0000001CA264: 02034996
	.long 0xd59c08db                                           // 0000001CA268: D59C08DB
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 0000001CA26C: 02010192
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CA270: BF870095
	.long 0xd71c0095                                           // 0000001CA274: D71C0095
	v_cndmask_b32_e32 v1, v149, v162, vcc_lo                   // 0000001CA278: 02034595
	v_cndmask_b32_e64 v67, 0, v149, s3                         // 0000001CA27C: D5010043 000F2A80
	.long 0xd41e0003                                           // 0000001CA284: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v70, vcc_lo              // 0000001CA288: 02028CFF 42B17218
	v_cndmask_b32_e64 v70, 0, v150, s4                         // 0000001CA290: D5010046 00132C80
	.long 0xd41e0004                                           // 0000001CA298: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v69, vcc_lo              // 0000001CA29C: 02028AFF 42B17218
	v_sub_f32_e32 v150, v251, v138                             // 0000001CA2A4: 092D15FB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CA2A8: BF870224
	v_cndmask_b32_e64 v204, 0x7f800000, v67, s3                // 0000001CA2AC: D50100CC 000E86FF 7F800000
	v_and_b32_e32 v67, 1, v219                                 // 0000001CA2B8: 3687B681
	v_cndmask_b32_e64 v147, 0x7f800000, v70, s4                // 0000001CA2BC: D5010093 00128CFF 7F800000
	v_and_b32_e32 v70, 1, v233                                 // 0000001CA2C8: 368DD281
	v_add3_u32 v66, v145, v66, 0x7fff                          // 0000001CA2CC: D6550042 03FE8591 00007FFF
	.long 0xd59c08e9                                           // 0000001CA2D8: D59C08E9
	v_cndmask_b32_e32 v0, v204, v128, vcc_lo                   // 0000001CA2DC: 020101CC
	.long 0xd41b0004                                           // 0000001CA2E0: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v154, vcc_lo             // 0000001CA2E4: 020334FF C2CE8ED0
	.long 0xd59c08dc                                           // 0000001CA2EC: D59C08DC
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000001CA2F0: 02010193
	v_sub_f32_e32 v151, v151, v166                             // 0000001CA2F4: 092F4D97
	v_cvt_i32_f32_e32 v166, v166                               // 0000001CA2F8: 7F4C11A6
	v_add3_u32 v70, v205, v70, 0x7fff                          // 0000001CA2FC: D6550046 03FE8DCD 00007FFF
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000001CA308: 7C372CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CA310: BF870094
	v_dual_add_f32 v151, v151, v165 :: v_dual_and_b32 v68, 1, v220// 0000001CA314: C9254B97 9745B881
	v_add3_u32 v68, v147, v68, 0x7fff                          // 0000001CA31C: D6550044 03FE8993 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001CA328: BF8700C2
	v_exp_f32_e32 v151, v151                                   // 0000001CA32C: 7F2E4B97
	ds_store_b16_d16_hi v215, v70 offset:192                   // 0000001CA330: DA8400C0 000046D7
	ds_store_b16_d16_hi v215, v68 offset:256                   // 0000001CA338: DA840100 000044D7
	.long 0xd71c0097                                           // 0000001CA340: D71C0097
	v_cndmask_b32_e32 v1, v151, v166, vcc_lo                   // 0000001CA344: 02034D97
	v_cndmask_b32_e64 v69, 0, v151, s5                         // 0000001CA348: D5010045 00172E80
	.long 0xd41e0005                                           // 0000001CA350: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v72, vcc_lo              // 0000001CA354: 020290FF 42B17218
	v_cndmask_b32_e64 v72, 0, v152, s6                         // 0000001CA35C: D5010048 001B3080
	.long 0xd41e0006                                           // 0000001CA364: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v71, vcc_lo              // 0000001CA368: 02028EFF 42B17218
	v_dual_sub_f32 v152, v254, v140 :: v_dual_and_b32 v71, 1, v233// 0000001CA370: C96519FE 9847D281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CA378: BF870224
	v_cndmask_b32_e64 v229, 0x7f800000, v69, s5                // 0000001CA37C: D50100E5 00168AFF 7F800000
	v_sub_f32_e32 v149, v250, v137                             // 0000001CA388: 092B13FA
	v_cndmask_b32_e64 v148, 0x7f800000, v72, s6                // 0000001CA38C: D5010094 001A90FF 7F800000
	v_mov_b32_e32 v254, v140                                   // 0000001CA398: 7FFC038C
	v_mul_f32_e32 v140, 0x3fb8aa3b, v152                       // 0000001CA39C: 111930FF 3FB8AA3B
	.long 0xd59c08e9                                           // 0000001CA3A4: D59C08E9
	v_cndmask_b32_e32 v0, v229, v128, vcc_lo                   // 0000001CA3A8: 020101E5
	v_mov_b32_e32 v250, v137                                   // 0000001CA3AC: 7FF40389
	.long 0xd59c08dd                                           // 0000001CA3B0: D59C08DD
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 0000001CA3B4: 02010194
	v_add3_u32 v65, v206, v65, 0x7fff                          // 0000001CA3B8: D6550041 03FE83CE 00007FFF
	v_dual_sub_f32 v151, v252, v139 :: v_dual_mov_b32 v252, v139// 0000001CA3C4: C95117FC 97FC018B
	v_add3_u32 v67, v146, v67, 0x7fff                          // 0000001CA3CC: D6550043 03FE8792 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA3D8: BF870004
	v_and_b32_e32 v69, 1, v221                                 // 0000001CA3DC: 368BBA81
	ds_store_b16_d16_hi v215, v66                              // 0000001CA3E0: DA840000 000042D7
	ds_store_b16_d16_hi v215, v65 offset:64                    // 0000001CA3E8: DA840040 000041D7
	ds_store_b16_d16_hi v215, v67 offset:128                   // 0000001CA3F0: DA840080 000043D7
	v_and_b32_e32 v65, 1, v233                                 // 0000001CA3F8: 3683D281
	v_rndne_f32_e32 v164, v140                                 // 0000001CA3FC: 7F48478C
	v_dual_mov_b32 v251, v138 :: v_dual_mul_f32 v138, 0x3fb8aa3b, v150// 0000001CA400: CA06018A FB8B2CFF 3FB8AA3B
	v_add3_u32 v69, v148, v69, 0x7fff                          // 0000001CA40C: D6550045 03FE8B94 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA418: BF870004
	v_add3_u32 v65, v229, v65, 0x7fff                          // 0000001CA41C: D6550041 03FE83E5 00007FFF
	v_fma_f32 v163, 0x3fb8aa3b, v152, -v140                    // 0000001CA428: D61300A3 863330FF 3FB8AA3B
	v_sub_f32_e32 v140, v140, v164                             // 0000001CA434: 0919498C
	v_rndne_f32_e32 v160, v138                                 // 0000001CA438: 7F40478A
	v_dual_sub_f32 v155, v0, v143 :: v_dual_mov_b32 v0, v143   // 0000001CA43C: C9511F00 9B00018F
	v_add3_u32 v66, v204, v71, 0x7fff                          // 0000001CA444: D6550042 03FE8FCC 00007FFF
	ds_store_b16_d16_hi v215, v66 offset:320                   // 0000001CA450: DA840140 000042D7
	ds_store_b16_d16_hi v215, v69 offset:384                   // 0000001CA458: DA840180 000045D7
	ds_store_b16_d16_hi v215, v65 offset:448                   // 0000001CA460: DA8401C0 000041D7
	scratch_load_b32 v69, off, off offset:44                   // 0000001CA468: DC51002C 457C0000
	v_fmac_f32_e32 v163, 0x32a5705f, v152                      // 0000001CA470: 574730FF 32A5705F
	v_mul_f32_e32 v137, 0x3fb8aa3b, v149                       // 0000001CA478: 11132AFF 3FB8AA3B
	v_fma_f32 v159, 0x3fb8aa3b, v150, -v138                    // 0000001CA480: D613009F 862B2CFF 3FB8AA3B
	v_sub_f32_e32 v138, v138, v160                             // 0000001CA48C: 0915418A
	v_cvt_i32_f32_e32 v164, v164                               // 0000001CA490: 7F4811A4
	v_add_f32_e32 v140, v140, v163                             // 0000001CA494: 0719478C
	.long 0xd41b0001                                           // 0000001CA498: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v152, vcc_lo             // 0000001CA49C: 020330FF C2CE8ED0
	v_fmac_f32_e32 v159, 0x32a5705f, v150                      // 0000001CA4A4: 573F2CFF 32A5705F
	v_dual_mov_b32 v227, v144 :: v_dual_mul_f32 v144, 0x3fb8aa3b, v156// 0000001CA4AC: CA060190 E39138FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA4B8: BF870004
	v_exp_f32_e32 v140, v140                                   // 0000001CA4BC: 7F184B8C
	v_fma_f32 v157, 0x3fb8aa3b, v149, -v137                    // 0000001CA4C0: D613009D 86272AFF 3FB8AA3B
	.long 0xd41b0006                                           // 0000001CA4CC: D41B0006
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v156, vcc_lo             // 0000001CA4D0: 020338FF C2CE8ED0
	v_cvt_i32_f32_e32 v160, v160                               // 0000001CA4D8: 7F4011A0
	v_rndne_f32_e32 v172, v144                                 // 0000001CA4DC: 7F584790
	v_dual_mov_b32 v217, v142 :: v_dual_mul_f32 v142, 0x3fb8aa3b, v154// 0000001CA4E0: CA06018E D98F34FF 3FB8AA3B
	v_fma_f32 v171, 0x3fb8aa3b, v156, -v144                    // 0000001CA4EC: D61300AB 864338FF 3FB8AA3B
	v_rndne_f32_e32 v158, v137                                 // 0000001CA4F8: 7F3C4789
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CA4FC: BF870294
	v_sub_f32_e32 v144, v144, v172                             // 0000001CA500: 09215990
	.long 0xd71c008c                                           // 0000001CA504: D71C008C
	v_cndmask_b32_e32 v1, v140, v164, vcc_lo                   // 0000001CA508: 0203498C
	v_fma_f32 v167, 0x3fb8aa3b, v154, -v142                    // 0000001CA50C: D61300A7 863B34FF 3FB8AA3B
	v_rndne_f32_e32 v168, v142                                 // 0000001CA518: 7F50478E
	v_mov_b32_e32 v255, v141                                   // 0000001CA51C: 7FFE038D
	v_cvt_i32_f32_e32 v172, v172                               // 0000001CA520: 7F5811AC
	v_cndmask_b32_e64 v140, 0, v140, s1                        // 0000001CA524: D501008C 00071880
	.long 0xd41e0001                                           // 0000001CA52C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v152, vcc_lo             // 0000001CA530: 020330FF 42B17218
	v_sub_f32_e32 v142, v142, v168                             // 0000001CA538: 091D518E
	v_cvt_i32_f32_e32 v168, v168                               // 0000001CA53C: 7F5011A8
	.long 0xd41b0000                                           // 0000001CA540: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v151, vcc_lo             // 0000001CA544: 02032EFF C2CE8ED0
	.long 0xd41b0003                                           // 0000001CA54C: D41B0003
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v153, vcc_lo             // 0000001CA550: 020332FF C2CE8ED0
	v_cndmask_b32_e64 v140, 0x7f800000, v140, s1               // 0000001CA558: D501008C 000718FF 7F800000
	v_fmac_f32_e32 v167, 0x32a5705f, v154                      // 0000001CA564: 574F34FF 32A5705F
	v_sub_f32_e32 v137, v137, v158                             // 0000001CA56C: 09133D89
	v_cvt_i32_f32_e32 v158, v158                               // 0000001CA570: 7F3C119E
	.long 0xd41b0005                                           // 0000001CA574: D41B0005
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v155, vcc_lo             // 0000001CA578: 020336FF C2CE8ED0
	v_dual_mul_f32 v44, v44, v140 :: v_dual_mul_f32 v141, 0x3fb8aa3b, v153// 0000001CA580: C8C7192C 2C8D32FF 3FB8AA3B
	v_add_f32_e32 v142, v142, v167                             // 0000001CA58C: 071D4F8E
	v_mul_f32_e32 v60, v60, v140                               // 0000001CA590: 1079193C
	v_mul_f32_e32 v52, v52, v140                               // 0000001CA594: 10691934
	v_mul_f32_e32 v36, v36, v140                               // 0000001CA598: 10491924
	v_fma_f32 v165, 0x3fb8aa3b, v153, -v141                    // 0000001CA59C: D61300A5 863732FF 3FB8AA3B
	v_exp_f32_e32 v142, v142                                   // 0000001CA5A8: 7F1C4B8E
	v_rndne_f32_e32 v166, v141                                 // 0000001CA5AC: 7F4C478D
	.long 0xd41b0007                                           // 0000001CA5B0: D41B0007
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v149, vcc_lo             // 0000001CA5B4: 02032AFF C2CE8ED0
	v_mul_f32_e32 v28, v28, v140                               // 0000001CA5BC: 1039191C
	v_mul_f32_e32 v20, v20, v140                               // 0000001CA5C0: 10291914
	v_mul_f32_e32 v12, v12, v140                               // 0000001CA5C4: 1019190C
	v_mul_f32_e32 v4, v4, v140                                 // 0000001CA5C8: 10091904
	v_fmac_f32_e32 v205, v231, v140                            // 0000001CA5CC: 579B19E7
	s_waitcnt vmcnt(0)                                         // 0000001CA5D0: BF8903F7
	ds_load_b128 v[65:68], v69                                 // 0000001CA5D4: DBFC0000 41000045
	ds_load_b128 v[69:72], v69 offset:16                       // 0000001CA5DC: DBFC0010 45000045
	.long 0xd71c008e                                           // 0000001CA5E4: D71C008E
	v_cndmask_b32_e32 v1, v142, v168, vcc_lo                   // 0000001CA5E8: 0203518E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CA5EC: BF8700A1
	v_cndmask_b32_e64 v142, 0, v142, s4                        // 0000001CA5F0: D501008E 00131C80
	.long 0xd41e0004                                           // 0000001CA5F8: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v154, vcc_lo             // 0000001CA5FC: 020334FF 42B17218
	v_cndmask_b32_e64 v142, 0x7f800000, v142, s4               // 0000001CA604: D501008E 00131CFF 7F800000
	v_fmac_f32_e32 v171, 0x32a5705f, v156                      // 0000001CA610: 575738FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CA618: BF8701A2
	v_dual_fmac_f32 v165, 0x32a5705f, v153 :: v_dual_mul_f32 v54, v54, v142// 0000001CA61C: C80732FF A5371D36 32A5705F
	v_dual_mul_f32 v46, v46, v142 :: v_dual_fmac_f32 v157, 0x32a5705f, v149// 0000001CA628: C8C11D2E 2E9D2AFF 32A5705F
	v_add_f32_e32 v144, v144, v171                             // 0000001CA634: 07215790
	v_mul_f32_e32 v62, v62, v142                               // 0000001CA638: 107D1D3E
	v_mul_f32_e32 v38, v38, v142                               // 0000001CA63C: 104D1D26
	v_mul_f32_e32 v30, v30, v142                               // 0000001CA640: 103D1D1E
	v_mul_f32_e32 v22, v22, v142                               // 0000001CA644: 102D1D16
	v_exp_f32_e32 v144, v144                                   // 0000001CA648: 7F204B90
	v_mul_f32_e32 v14, v14, v142                               // 0000001CA64C: 101D1D0E
	v_mul_f32_e32 v6, v6, v142                                 // 0000001CA650: 100D1D06
	v_fmac_f32_e32 v204, v230, v142                            // 0000001CA654: 57991DE6
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CA658: BF870095
	.long 0xd71c0090                                           // 0000001CA65C: D71C0090
	v_cndmask_b32_e32 v1, v144, v172, vcc_lo                   // 0000001CA660: 02035990
	v_cndmask_b32_e64 v144, 0, v144, s6                        // 0000001CA664: D5010090 001B2080
	.long 0xd41e0006                                           // 0000001CA66C: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v156, vcc_lo             // 0000001CA670: 020338FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CA678: BF8701B1
	v_cndmask_b32_e64 v144, 0x7f800000, v144, s6               // 0000001CA67C: D5010090 001B20FF 7F800000
	v_sub_f32_e32 v141, v141, v166                             // 0000001CA688: 091B4D8D
	v_cvt_i32_f32_e32 v166, v166                               // 0000001CA68C: 7F4C11A6
	v_mul_f32_e32 v64, v64, v144                               // 0000001CA690: 10812140
	v_add_f32_e32 v138, v138, v159                             // 0000001CA694: 07153F8A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CA698: BF870234
	v_dual_mul_f32 v56, v56, v144 :: v_dual_add_f32 v141, v141, v165// 0000001CA69C: C8C92138 388D4B8D
	v_mul_f32_e32 v48, v48, v144                               // 0000001CA6A4: 10612130
	v_mul_f32_e32 v40, v40, v144                               // 0000001CA6A8: 10512128
	v_exp_f32_e32 v138, v138                                   // 0000001CA6AC: 7F144B8A
	v_mul_f32_e32 v32, v32, v144                               // 0000001CA6B0: 10412120
	v_exp_f32_e32 v141, v141                                   // 0000001CA6B4: 7F1A4B8D
	v_mul_f32_e32 v24, v24, v144                               // 0000001CA6B8: 10312118
	v_mul_f32_e32 v16, v16, v144                               // 0000001CA6BC: 10212110
	v_mul_f32_e32 v8, v8, v144                                 // 0000001CA6C0: 10112108
	v_fmac_f32_e32 v229, v207, v144                            // 0000001CA6C4: 57CB21CF
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001CA6C8: BF8702A6
	.long 0xd71c008a                                           // 0000001CA6CC: D71C008A
	v_cndmask_b32_e32 v1, v138, v160, vcc_lo                   // 0000001CA6D0: 0203418A
	v_mul_f32_e32 v139, 0x3fb8aa3b, v151                       // 0000001CA6D4: 11172EFF 3FB8AA3B
	.long 0xd71c008d                                           // 0000001CA6DC: D71C008D
	v_cndmask_b32_e32 v1, v141, v166, vcc_lo                   // 0000001CA6E0: 02034D8D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CA6E4: BF870003
	v_cndmask_b32_e32 v138, 0, v138, vcc_lo                    // 0000001CA6E8: 03151480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000001CA6EC: 7C3D2CFF 42B17218
	v_add_f32_e32 v137, v137, v157                             // 0000001CA6F4: 07133B89
	v_fma_f32 v161, 0x3fb8aa3b, v151, -v139                    // 0000001CA6F8: D61300A1 862F2EFF 3FB8AA3B
	v_rndne_f32_e32 v162, v139                                 // 0000001CA704: 7F44478B
	v_cndmask_b32_e64 v141, 0, v141, s3                        // 0000001CA708: D501008D 000F1A80
	v_cndmask_b32_e32 v138, 0x7f800000, v138, vcc_lo           // 0000001CA710: 031514FF 7F800000
	v_mul_f32_e32 v143, 0x3fb8aa3b, v155                       // 0000001CA718: 111F36FF 3FB8AA3B
	v_fmac_f32_e32 v161, 0x32a5705f, v151                      // 0000001CA720: 57432EFF 32A5705F
	v_sub_f32_e32 v139, v139, v162                             // 0000001CA728: 0917458B
	v_exp_f32_e32 v137, v137                                   // 0000001CA72C: 7F124B89
	v_mul_f32_e32 v58, v58, v138                               // 0000001CA730: 1075153A
	v_fma_f32 v169, 0x3fb8aa3b, v155, -v143                    // 0000001CA734: D61300A9 863F36FF 3FB8AA3B
	v_rndne_f32_e32 v170, v143                                 // 0000001CA740: 7F54478F
	v_dual_add_f32 v139, v139, v161 :: v_dual_mul_f32 v34, v34, v138// 0000001CA744: C907438B 8B231522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CA74C: BF870193
	v_dual_mul_f32 v42, v42, v138 :: v_dual_fmac_f32 v169, 0x32a5705f, v155// 0000001CA750: C8C1152A 2AA936FF 32A5705F
	v_sub_f32_e32 v143, v143, v170                             // 0000001CA75C: 091F558F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CA760: BF870003
	v_exp_f32_e32 v139, v139                                   // 0000001CA764: 7F164B8B
	v_cvt_i32_f32_e32 v162, v162                               // 0000001CA768: 7F4411A2
	v_cvt_i32_f32_e32 v170, v170                               // 0000001CA76C: 7F5411AA
	.long 0xd71c0089                                           // 0000001CA770: D71C0089
	v_cndmask_b32_e32 v1, v137, v158, vcc_lo                   // 0000001CA774: 02033D89
	v_add_f32_e32 v143, v143, v169                             // 0000001CA778: 071F538F
	.long 0xd41e0003                                           // 0000001CA77C: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v153, vcc_lo             // 0000001CA780: 020332FF 42B17218
	v_mul_f32_e32 v50, v50, v138                               // 0000001CA788: 10651532
	v_mul_f32_e32 v26, v26, v138                               // 0000001CA78C: 1035151A
	v_cndmask_b32_e64 v137, 0, v137, s7                        // 0000001CA790: D5010089 001F1280
	v_exp_f32_e32 v143, v143                                   // 0000001CA798: 7F1E4B8F
	.long 0xd71c008b                                           // 0000001CA79C: D71C008B
	v_cndmask_b32_e32 v1, v139, v162, vcc_lo                   // 0000001CA7A0: 0203458B
	.long 0xd41e0007                                           // 0000001CA7A4: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v149, vcc_lo             // 0000001CA7A8: 02032AFF 42B17218
	v_cndmask_b32_e64 v141, 0x7f800000, v141, s3               // 0000001CA7B0: D501008D 000F1AFF 7F800000
	v_mul_f32_e32 v18, v18, v138                               // 0000001CA7BC: 10251512
	v_mul_f32_e32 v10, v10, v138                               // 0000001CA7C0: 1015150A
	v_cndmask_b32_e64 v139, 0, v139, s0                        // 0000001CA7C4: D501008B 00031680
	.long 0xd41e0000                                           // 0000001CA7CC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v151, vcc_lo             // 0000001CA7D0: 02032EFF 42B17218
	v_cndmask_b32_e64 v137, 0x7f800000, v137, s7               // 0000001CA7D8: D5010089 001F12FF 7F800000
	v_mul_f32_e32 v61, v61, v141                               // 0000001CA7E4: 107B1B3D
	.long 0xd71c008f                                           // 0000001CA7E8: D71C008F
	v_cndmask_b32_e32 v1, v143, v170, vcc_lo                   // 0000001CA7EC: 0203558F
	v_mul_f32_e32 v53, v53, v141                               // 0000001CA7F0: 106B1B35
	v_cndmask_b32_e64 v139, 0x7f800000, v139, s0               // 0000001CA7F4: D501008B 000316FF 7F800000
	v_mul_f32_e32 v57, v57, v137                               // 0000001CA800: 10731339
	v_mul_f32_e32 v49, v49, v137                               // 0000001CA804: 10631331
	v_cndmask_b32_e64 v143, 0, v143, s5                        // 0000001CA808: D501008F 00171E80
	.long 0xd41e0005                                           // 0000001CA810: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v155, vcc_lo             // 0000001CA814: 020336FF 42B17218
	v_mul_f32_e32 v59, v59, v139                               // 0000001CA81C: 1077173B
	v_mul_f32_e32 v51, v51, v139                               // 0000001CA820: 10671733
	v_mul_f32_e32 v41, v41, v137                               // 0000001CA824: 10531329
	v_mul_f32_e32 v43, v43, v139                               // 0000001CA828: 1057172B
	v_cndmask_b32_e64 v143, 0x7f800000, v143, s5               // 0000001CA82C: D501008F 00171EFF 7F800000
	v_mul_f32_e32 v45, v45, v141                               // 0000001CA838: 105B1B2D
	v_mul_f32_e32 v33, v33, v137                               // 0000001CA83C: 10431321
	v_dual_mul_f32 v35, v35, v139 :: v_dual_mul_f32 v2, v2, v138// 0000001CA840: C8C71723 23031502
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA848: BF870004
	v_mul_f32_e32 v63, v63, v143                               // 0000001CA84C: 107F1F3F
	v_mul_f32_e32 v55, v55, v143                               // 0000001CA850: 106F1F37
	v_mul_f32_e32 v47, v47, v143                               // 0000001CA854: 105F1F2F
	v_mul_f32_e32 v37, v37, v141                               // 0000001CA858: 104B1B25
	v_mul_f32_e32 v39, v39, v143                               // 0000001CA85C: 104F1F27
	v_mul_f32_e32 v25, v25, v137                               // 0000001CA860: 10331319
	v_dual_mul_f32 v27, v27, v139 :: v_dual_fmac_f32 v206, v208, v138// 0000001CA864: C8C1171B 1BCF15D0
	v_mul_f32_e32 v29, v29, v141                               // 0000001CA86C: 103B1B1D
	v_mul_f32_e32 v31, v31, v143                               // 0000001CA870: 103F1F1F
	v_mul_f32_e32 v17, v17, v137                               // 0000001CA874: 10231311
	v_mul_f32_e32 v19, v19, v139                               // 0000001CA878: 10271713
	v_mul_f32_e32 v21, v21, v141                               // 0000001CA87C: 102B1B15
	v_mul_f32_e32 v23, v23, v143                               // 0000001CA880: 102F1F17
	v_mul_f32_e32 v9, v9, v137                                 // 0000001CA884: 10131309
	v_mul_f32_e32 v11, v11, v139                               // 0000001CA888: 1017170B
	v_mul_f32_e32 v13, v13, v141                               // 0000001CA88C: 101B1B0D
	v_mul_f32_e32 v15, v15, v143                               // 0000001CA890: 101F1F0F
	v_mul_f32_e32 v1, v1, v137                                 // 0000001CA894: 10031301
	v_mul_f32_e32 v3, v3, v139                                 // 0000001CA898: 10071703
	v_mul_f32_e32 v5, v5, v141                                 // 0000001CA89C: 100B1B05
	v_mul_f32_e32 v7, v7, v143                                 // 0000001CA8A0: 100F1F07
	v_fma_f32 v201, v201, v137, v145                           // 0000001CA8A4: D61300C9 064713C9
	v_fma_f32 v203, v203, v139, v146                           // 0000001CA8AC: D61300CB 064B17CB
	v_fma_f32 v202, v202, v141, v147                           // 0000001CA8B4: D61300CA 064F1BCA
	v_fma_f32 v253, v253, v143, v148                           // 0000001CA8BC: D61300FD 06531FFD
	s_waitcnt lgkmcnt(0)                                       // 0000001CA8C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001CA8C8: CC414039 1CE69341
	v_wmma_f32_16x16x16_bf16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001CA8D0: CC414031 1CC6A341
	v_wmma_f32_16x16x16_bf16 v[41:48], v[65:72], v[89:96], v[41:48]// 0000001CA8D8: CC414029 1CA6B341
	v_wmma_f32_16x16x16_bf16 v[33:40], v[65:72], v[97:104], v[33:40]// 0000001CA8E0: CC414021 1C86C341
	v_wmma_f32_16x16x16_bf16 v[25:32], v[65:72], v[105:112], v[25:32]// 0000001CA8E8: CC414019 1C66D341
	v_wmma_f32_16x16x16_bf16 v[17:24], v[65:72], v[113:120], v[17:24]// 0000001CA8F0: CC414011 1C46E341
	v_wmma_f32_16x16x16_bf16 v[9:16], v[65:72], v[121:128], v[9:16]// 0000001CA8F8: CC414009 1C26F341
	v_wmma_f32_16x16x16_bf16 v[1:8], v[65:72], v[129:136], v[1:8]// 0000001CA900: CC414001 1C070341
	s_barrier                                                  // 0000001CA908: BFBD0000
	s_cbranch_scc1 64467                                       // 0000001CA90C: BFA2FBD3 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi9EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x65c>
	s_clause 0x1                                               // 0000001CA910: BF850001
	scratch_load_b32 v8, off, off offset:60                    // 0000001CA914: DC51003C 087C0000
	scratch_load_b32 v15, off, off offset:56                   // 0000001CA91C: DC510038 0F7C0000
	s_mul_i32 s0, s20, 12                                      // 0000001CA924: 96008C14
	s_waitcnt vmcnt(1)                                         // 0000001CA928: BF8907F7
	v_or_b32_e32 v7, v8, v228                                  // 0000001CA92C: 380FC908
	s_waitcnt vmcnt(0)                                         // 0000001CA930: BF8903F7
	v_or_b32_e32 v0, s0, v15                                   // 0000001CA934: 38001E00
	v_mov_b32_dpp v78, v204 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA938: 7E9C02FA FF0961CC
	v_mov_b32_dpp v75, v205 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA940: 7E9602FA FF0961CD
	v_mov_b32_dpp v74, v203 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA948: 7E9402FA FF0961CB
	v_mov_b32_dpp v76, v202 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA950: 7E9802FA FF0961CA
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001CA958: 30000088
	v_mov_b32_e32 v8, 0                                        // 0000001CA95C: 7E100280
	v_dual_add_f32 v78, v204, v78 :: v_dual_add_f32 v81, v205, v75// 0000001CA960: C9089DCC 4E5097CD
	v_add_f32_e32 v83, v203, v74                               // 0000001CA968: 06A695CB
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CA96C: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001CA970: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001CA978: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001CA984: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001CA988: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001CA990: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001CA998: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001CA99C: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA9A4: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001CA9AC: 34403E9F
	.long 0xd7006a0f                                           // 0000001CA9B0: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001CA9B4: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CA9B8: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001CA9BC: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001CA9C4: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001CA9C8: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001CA9CC: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CA9D4: BF870233
	.long 0xd73c000f                                           // 0000001CA9D8: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001CA9DC: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001CA9E0: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001CA9E8: 34504E9F
	.long 0xd73c0017                                           // 0000001CA9EC: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001CA9F0: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001CA9F4: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CA9F8: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001CAA00: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001CAA04: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CAA08: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001CAA0C: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001CAA14: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001CAA18: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001CAA1C: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001CAA24: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001CAA28: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001CAA2C: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CAA30: BF8700B3
	.long 0xd73c001f                                           // 0000001CAA34: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001CAA38: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 0000001CAA3C: D5207C38 01AA300B
	.long 0xd7006a27                                           // 0000001CAA44: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001CAA48: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001CAA4C: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001CAA54: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001CAA58: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CAA5C: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001CAA60: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001CAA68: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000001CAA6C: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 0000001CAA70: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001CAA78: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001CAA80: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001CAA84: 02028307
	s_clause 0x2                                               // 0000001CAA88: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001CAA8C: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001CAA94: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001CAA9C: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001CAAA4: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001CAAAC: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001CAAB0: 02024E81
	.long 0xd73c002f                                           // 0000001CAAB4: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001CAAB8: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAABC: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001CAAC4: BF8700C4
	.long 0xd73c0056                                           // 0000001CAAC8: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001CAACC: 02020E81
	v_mov_b32_dpp v8, v206 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAAD0: 7E1002FA FF0961CE
	v_mov_b32_dpp v7, v201 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAAD8: 7E0E02FA FF0961C9
	.long 0xd7006a43                                           // 0000001CAAE0: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001CAAE4: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001CAAE8: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001CAAF0: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001CAAF4: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CAAF8: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001CAAFC: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001CAB04: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 0000001CAB08: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 0000001CAB0C: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001CAB14: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001CAB18: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001CAB20: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001CAB28: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001CAB30: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001CAB38: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001CAB40: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001CAB48: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001CAB50: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001CAB58: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001CAB60: DC4A0040 617C0047
	v_dual_add_f32 v8, v206, v8 :: v_dual_add_f32 v7, v201, v7 // 0000001CAB68: C90811CE 08060FC9
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB70: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB78: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB80: 069C9CFA FF09644E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CAB88: BF870004
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB8C: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB94: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAB9C: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABA4: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABAC: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABB4: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABBC: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001CABC4: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001CABCC: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001CABD4: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABDC: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CABE4: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001CABEC: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001CABF0: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CABF4: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001CABF8: D5207C08 0016200D
	v_rcp_f32_e32 v91, v109                                    // 0000001CAC00: 7EB6556D
	.long 0xd700050f                                           // 0000001CAC04: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001CAC08: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001CAC0C: D5207C10 0016300D
	.long 0xd7000517                                           // 0000001CAC14: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001CAC18: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CAC1C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001CAC20: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001CAC28: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001CAC2C: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001CAC30: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001CAC38: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001CAC3C: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CAC40: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001CAC44: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001CAC4C: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 0000001CAC50: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 0000001CAC54: D5207C30 0016AE0D
	s_clause 0x1f                                              // 0000001CAC5C: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001CAC60: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001CAC68: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001CAC70: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001CAC78: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001CAC80: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001CAC88: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001CAC90: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001CAC98: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001CACA0: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001CACA8: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001CACB0: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001CACB8: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001CACC0: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001CACC8: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001CACD0: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001CACD8: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001CACE0: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001CACE8: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001CACF0: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001CACF8: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001CAD00: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001CAD08: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001CAD10: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001CAD18: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001CAD20: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001CAD28: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001CAD30: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001CAD38: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001CAD40: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001CAD48: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001CAD50: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001CAD58: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001CAD60: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001CAD64: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001CAD6C: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001CAD74: D6130047 23CAB76D
	v_add_f32_e32 v84, v202, v76                               // 0000001CAD7C: 06A899CA
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001CAD80: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001CAD88: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 0000001CAD90: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 0000001CAD94: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CAD98: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 0000001CADA0: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 0000001CADA4: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001CADA8: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001CADB0: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CADB8: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001CADC0: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001CADC8: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001CADD0: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001CADD8: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CADE0: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001CADE8: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001CADF0: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 0000001CADF8: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 0000001CADFC: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001CAE00: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CAE08: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 0000001CAE0C: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001CAE14: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001CAE1C: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001CAE24: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CAE28: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001CAE2C: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001CAE34: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CAE3C: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 0000001CAE40: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001CAE48: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 0000001CAE50: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 0000001CAE58: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CAE60: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 0000001CAE64: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 0000001CAE6C: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CAE70: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001CAE74: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 0000001CAE7C: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CAE84: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 0000001CAE88: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 0000001CAE8C: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 0000001CAE94: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CAE98: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 0000001CAE9C: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 0000001CAEA4: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 0000001CAEAC: D6130090 25D31F73
	.long 0x7f003880                                           // 0000001CAEB4: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 0000001CAEB8: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001CAEBC: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001CAEC4: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001CAEC8: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CAED0: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 0000001CAED4: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001CAEDC: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 0000001CAEE4: D613006C 25C6916E
	.long 0x7f9e3980                                           // 0000001CAEEC: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001CAEF0: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CAEF8: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 0000001CAEFC: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 0000001CAF04: 571EA990
	.long 0x7f983980                                           // 0000001CAF08: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 0000001CAF0C: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CAF10: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 0000001CAF14: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001CAF1C: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001CAF20: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001CAF28: 7F9A3980
	.long 0x7f963980                                           // 0000001CAF2C: 7F963980
	.long 0x7f943980                                           // 0000001CAF30: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 0000001CAF34: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 0000001CAF3C: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001CAF40: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001CAF44: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 0000001CAF48: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 0000001CAF50: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001CAF54: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 0000001CAF58: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 0000001CAF5C: 10048302
	s_waitcnt vmcnt(47)                                        // 0000001CAF60: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001CAF64: 30929290
	s_waitcnt vmcnt(46)                                        // 0000001CAF68: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001CAF6C: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 0000001CAF74: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001CAF78: 3064A490
	s_waitcnt vmcnt(44)                                        // 0000001CAF7C: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 0000001CAF80: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CAF84: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001CAF88: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 0000001CAF90: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 0000001CAF98: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001CAFA0: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001CAFA8: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 0000001CAFB0: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 0000001CAFB4: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001CAFC0: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001CAFCC: 7EE84767
	s_waitcnt vmcnt(40)                                        // 0000001CAFD0: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001CAFD4: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001CAFD8: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 0000001CAFDC: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001CAFE0: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001CAFE4: 30C6C690
	s_waitcnt vmcnt(37)                                        // 0000001CAFE8: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001CAFEC: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001CAFF0: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001CAFFC: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001CB004: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001CB010: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001CB01C: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001CB028: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 0000001CB034: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001CB03C: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001CB048: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001CB04C: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001CB058: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001CB064: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001CB06C: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001CB078: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 0000001CB084: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 0000001CB088: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001CB090: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001CB094: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001CB09C: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 0000001CB0A0: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 0000001CB0A4: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 0000001CB0A8: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001CB0AC: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001CB0B0: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 0000001CB0B4: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 0000001CB0B8: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001CB0BC: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001CB0C8: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001CB0CC: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001CB0D8: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001CB0E0: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001CB0E8: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001CB0F0: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001CB0F4: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001CB100: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001CB10C: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 0000001CB110: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001CB114: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001CB120: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001CB128: 7EE24B71
	.long 0xd71c0067                                           // 0000001CB12C: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001CB130: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 0000001CB134: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001CB13C: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001CB140: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001CB144: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001CB150: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001CB15C: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001CB168: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001CB16C: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001CB178: C913417A 7A66CE80
	.long 0xd71c0070                                           // 0000001CB180: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001CB184: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001CB188: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 0000001CB190: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001CB194: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001CB1A0: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001CB1AC: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001CB1B8: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001CB1BC: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001CB1C8: C9495796 96773977
	.long 0xd71c0071                                           // 0000001CB1D0: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001CB1D4: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001CB1D8: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001CB1DC: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001CB1E4: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001CB1F0: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001CB1F4: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001CB1FC: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001CB200: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001CB204: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 0000001CB20C: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001CB210: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 0000001CB214: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001CB218: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001CB21C: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001CB224: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001CB22C: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001CB230: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 0000001CB234: 7EF24B79
	.long 0xd71c0073                                           // 0000001CB238: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001CB23C: 0202EB73
	.long 0xd71c0075                                           // 0000001CB240: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001CB244: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001CB248: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001CB250: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 0000001CB258: 7EF44B7A
	.long 0xd71c0078                                           // 0000001CB25C: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001CB260: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 0000001CB264: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 0000001CB268: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001CB26C: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001CB270: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 0000001CB278: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001CB27C: 02033779
	v_rndne_f32_e32 v169, v149                                 // 0000001CB280: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 0000001CB284: 09294F94
	v_exp_f32_e32 v145, v145                                   // 0000001CB288: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001CB28C: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001CB290: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 0000001CB298: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001CB29C: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001CB2A0: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 0000001CB2A8: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001CB2AC: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001CB2B0: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CB2B8: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001CB2BC: 072B5195
	v_exp_f32_e32 v148, v148                                   // 0000001CB2C0: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 0000001CB2C4: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 0000001CB2C8: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001CB2CC: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001CB2D0: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 0000001CB2D8: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 0000001CB2DC: 7F2A4B95
	.long 0xd71c0079                                           // 0000001CB2E0: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001CB2E4: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 0000001CB2E8: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001CB2EC: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001CB2F0: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 0000001CB2F8: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001CB2FC: 02034394
	.long 0xd71c0074                                           // 0000001CB300: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001CB304: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 0000001CB308: 06F062F2
	.long 0xd41b0005                                           // 0000001CB30C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001CB310: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001CB318: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001CB320: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001CB328: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001CB32C: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001CB330: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001CB334: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001CB33C: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001CB344: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001CB348: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001CB350: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001CB354: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001CB35C: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001CB360: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001CB368: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001CB370: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001CB378: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001CB37C: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 0000001CB388: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001CB38C: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 0000001CB394: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001CB3A0: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 0000001CB3A8: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB3B4: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 0000001CB3B8: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001CB3C0: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001CB3C8: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001CB3CC: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001CB3D4: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001CB3DC: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001CB3E4: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 0000001CB3EC: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001CB3F4: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001CB400: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001CB404: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001CB40C: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001CB418: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 0000001CB420: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001CB424: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001CB42C: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001CB434: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001CB43C: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 0000001CB448: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CB450: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 0000001CB454: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 0000001CB45C: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CB460: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 0000001CB464: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 0000001CB468: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001CB46C: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001CB474: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 0000001CB47C: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 0000001CB480: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 0000001CB488: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 0000001CB490: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 0000001CB494: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CB498: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 0000001CB49C: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 0000001CB4A0: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CB4A4: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 0000001CB4A8: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 0000001CB4B0: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CB4B8: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001CB4BC: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001CB4C4: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001CB4CC: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 0000001CB4D4: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CB4D8: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 0000001CB4DC: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001CB4E0: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001CB4E8: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 0000001CB4EC: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001CB4F0: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001CB4F8: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001CB4FC: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001CB504: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 0000001CB50C: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001CB514: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 0000001CB51C: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 0000001CB520: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001CB524: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CB52C: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 0000001CB530: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 0000001CB538: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 0000001CB53C: 10CE6533
	.long 0x7e9e39b9                                           // 0000001CB540: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 0000001CB544: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 0000001CB54C: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001CB550: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 0000001CB558: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CB560: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 0000001CB564: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 0000001CB56C: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 0000001CB574: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 0000001CB578: 7EB65564
	.long 0x7e0039ba                                           // 0000001CB57C: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 0000001CB580: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 0000001CB588: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001CB58C: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 0000001CB594: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001CB598: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001CB5A0: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001CB5A8: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 0000001CB5B0: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001CB5B4: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 0000001CB5BC: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001CB5C4: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 0000001CB5D0: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 0000001CB5D4: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 0000001CB5DC: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 0000001CB5E4: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CB5E8: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001CB5EC: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001CB5F4: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001CB5FC: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 0000001CB604: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 0000001CB608: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 0000001CB60C: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001CB610: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 0000001CB618: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 0000001CB61C: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB620: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 0000001CB624: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 0000001CB628: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB630: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 0000001CB634: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 0000001CB638: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 0000001CB63C: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB644: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 0000001CB648: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 0000001CB650: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001CB654: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB65C: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 0000001CB660: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001CB668: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001CB670: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001CB674: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001CB67C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001CB680: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001CB684: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001CB68C: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001CB694: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001CB698: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001CB6A0: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 0000001CB6A8: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001CB6AC: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 0000001CB6B4: 7E9A39BB
	.long 0x7e0039bc                                           // 0000001CB6B8: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001CB6BC: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001CB6C4: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 0000001CB6D0: 107A693D
	s_clause 0x1                                               // 0000001CB6D4: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001CB6D8: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001CB6E0: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 0000001CB6E8: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001CB6EC: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001CB6F4: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 0000001CB6FC: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001CB700: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 0000001CB708: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 0000001CB70C: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001CB710: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001CB718: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 0000001CB720: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001CB724: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001CB72C: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 0000001CB734: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 0000001CB73C: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CB740: BF870314
	v_rcp_f32_e32 v107, v100                                   // 0000001CB744: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 0000001CB748: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 0000001CB750: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 0000001CB754: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 0000001CB758: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB760: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 0000001CB764: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 0000001CB768: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CB770: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 0000001CB774: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 0000001CB778: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB780: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 0000001CB784: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 0000001CB78C: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 0000001CB790: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CB798: BF870291
	v_rcp_f32_e32 v91, v79                                     // 0000001CB79C: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001CB7A0: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001CB7A8: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001CB7AC: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 0000001CB7B4: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001CB7B8: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001CB7BC: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CB7C8: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 0000001CB7CC: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 0000001CB7D4: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB7DC: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 0000001CB7E0: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 0000001CB7E4: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 0000001CB7EC: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 0000001CB7F4: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB7FC: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 0000001CB800: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 0000001CB808: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB810: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000001CB814: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 0000001CB820: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001CB828: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001CB830: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001CB838: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 0000001CB840: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 0000001CB844: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 0000001CB848: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 0000001CB850: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 0000001CB854: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001CB858: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 0000001CB85C: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 0000001CB860: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001CB868: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001CB86C: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 0000001CB874: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001CB878: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001CB880: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001CB884: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001CB88C: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001CB894: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001CB898: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001CB8A0: D637003D 0563236D
	.long 0x7e9839bc                                           // 0000001CB8A8: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001CB8AC: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001CB8B4: BEEA0004
	.long 0x7e0039bb                                           // 0000001CB8B8: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001CB8BC: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 0000001CB8C4: 36909881
	.long 0x7e9639be                                           // 0000001CB8C8: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001CB8CC: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001CB8D4: 368E0081
	.long 0x7e0039bd                                           // 0000001CB8D8: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001CB8DC: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001CB8E8: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001CB8F4: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001CB8F8: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001CB904: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001CB90C: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 0000001CB914: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 0000001CB920: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CB924: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001CB928: D627003A 05C6BD3A
	s_clause 0x1                                               // 0000001CB930: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001CB934: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001CB93C: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 0000001CB944: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 0000001CB94C: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001CB958: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 0000001CB964: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001CB968: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001CB970: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 0000001CB978: 067B2F72
	.long 0x7e0039ba                                           // 0000001CB97C: 7E0039BA
	.long 0x7e9439b9                                           // 0000001CB980: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 0000001CB984: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 0000001CB988: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 0000001CB98C: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001CB990: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 0000001CB998: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 0000001CB99C: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001CB9A4: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CB9AC: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 0000001CB9B0: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 0000001CB9B4: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001CB9B8: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001CB9C4: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 0000001CB9C8: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001CB9CC: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001CB9D8: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001CB9E0: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001CB9E8: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001CB9EC: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001CB9F0: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001CB9F8: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001CB9FC: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001CBA00: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001CBA08: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001CBA0C: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 0000001CBA14: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 0000001CBA18: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001CBA20: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001CBA24: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001CBA2C: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 0000001CBA34: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 0000001CBA38: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001CBA40: D637003E 04FAD748
	.long 0xd71c003c                                           // 0000001CBA48: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001CBA4C: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001CBA50: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 0000001CBA58: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001CBA5C: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001CBA68: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 0000001CBA70: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001CBA74: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001CBA78: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 0000001CBA7C: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001CBA84: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001CBA8C: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 0000001CBA90: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001CBA94: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001CBA9C: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001CBAA4: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001CBAB0: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CBAB4: BF870214
	v_add_f32_e32 v80, v80, v82                                // 0000001CBAB8: 06A0A550
	.long 0x7e0039b6                                           // 0000001CBABC: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CBAC0: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 0000001CBAC4: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001CBAC8: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001CBAD0: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001CBADC: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CBAE0: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001CBAE4: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001CBAEC: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001CBAF8: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001CBAFC: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001CBB04: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 0000001CBB10: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 0000001CBB14: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001CBB18: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001CBB1C: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001CBB24: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBB2C: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001CBB30: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001CBB38: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001CBB40: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001CBB48: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CBB50: BF870113
	v_rcp_f32_e32 v57, v71                                     // 0000001CBB54: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 0000001CBB58: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBB5C: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 0000001CBB60: 067C973E
	.long 0xd41e0001                                           // 0000001CBB64: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001CBB68: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 0000001CBB70: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CBB78: BF870313
	v_exp_f32_e32 v62, v62                                     // 0000001CBB7C: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001CBB80: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBB88: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 0000001CBB8C: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001CBB90: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 0000001CBB94: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001CBB98: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CBBA0: BF8701B5
	.long 0xd71c003e                                           // 0000001CBBA4: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 0000001CBBA8: 0202993E
	v_exp_f32_e32 v76, v80                                     // 0000001CBBAC: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 0000001CBBB0: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 0000001CBBB8: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBBBC: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001CBBC0: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001CBBC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001CBBCC: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 0000001CBBD4: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CBBDC: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001CBBE0: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 0000001CBBEC: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001CBBF0: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBBF4: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 0000001CBBF8: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 0000001CBBFC: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBC04: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001CBC08: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001CBC10: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001CBC18: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001CBC20: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001CBC24: BEEA0000
	.long 0x7f763980                                           // 0000001CBC28: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001CBC2C: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001CBC34: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 0000001CBC3C: 067A7AF2
	.long 0x7e7639a9                                           // 0000001CBC40: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CBC44: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001CBC48: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001CBC50: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001CBC58: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CBC60: BF870113
	.long 0x7e0039aa                                           // 0000001CBC64: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 0000001CBC68: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 0000001CBC6C: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001CBC70: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBC74: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 0000001CBC78: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001CBC80: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBC8C: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001CBC90: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 0000001CBC98: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 0000001CBC9C: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001CBCA4: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001CBCAC: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 0000001CBCB4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001CBCB8: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CBCC0: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001CBCC4: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 0000001CBCD0: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 0000001CBCD4: 7E944739
	s_waitcnt vmcnt(11)                                        // 0000001CBCD8: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBCDC: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 0000001CBCE0: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001CBCEC: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBCF4: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001CBCF8: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 0000001CBD00: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001CBD04: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 0000001CBD10: 36767681
	v_rndne_f32_e32 v81, v77                                   // 0000001CBD14: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001CBD18: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001CBD1C: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001CBD24: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CBD30: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 0000001CBD34: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001CBD38: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 0000001CBD44: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CBD48: BF870004
	v_exp_f32_e32 v57, v57                                     // 0000001CBD4C: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001CBD50: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 0000001CBD54: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001CBD58: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 0000001CBD60: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 0000001CBD68: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001CBD6C: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001CBD74: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 0000001CBD78: D613004B 24FA9347
	.long 0xd71c0039                                           // 0000001CBD80: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001CBD84: 02029539
	v_exp_f32_e32 v74, v77                                     // 0000001CBD88: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001CBD8C: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 0000001CBD90: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 0000001CBD98: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001CBD9C: D5010039 00067280
	.long 0xd41b0001                                           // 0000001CBDA4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001CBDA8: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CBDB0: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 0000001CBDB4: D613003E 24FA9347
	.long 0xd71c003b                                           // 0000001CBDBC: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001CBDC0: 0202774A
	s_waitcnt vmcnt(5)                                         // 0000001CBDC4: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001CBDC8: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001CBDCC: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001CBDD8: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001CBDE0: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CBDE8: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001CBDEC: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001CBDF4: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001CBDFC: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001CBE00: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CBE04: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001CBE08: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001CBE14: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001CBE1C: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001CBE24: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CBE2C: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001CBE30: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001CBE38: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001CBE40: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 0000001CBE44: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 0000001CBE48: 7E9C474B
	.long 0x7e0039a9                                           // 0000001CBE4C: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001CBE50: 066C76F2
	.long 0x7e7639ab                                           // 0000001CBE54: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001CBE58: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 0000001CBE60: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 0000001CBE64: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001CBE68: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001CBE70: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001CBE74: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001CBE7C: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 0000001CBE88: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 0000001CBE8C: 36767681
	v_rcp_f32_e32 v62, v42                                     // 0000001CBE90: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 0000001CBE94: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001CBE98: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 0000001CBEA0: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001CBEA4: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001CBEA8: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 0000001CBEB4: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CBEB8: BF870294
	v_add_f32_e32 v53, v53, v71                                // 0000001CBEBC: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001CBEC0: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 0000001CBEC8: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CBECC: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001CBED0: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 0000001CBEDC: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001CBEE0: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 0000001CBEE8: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001CBEEC: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001CBEF4: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 0000001CBEFC: 109E7D4C
	.long 0xd71c0035                                           // 0000001CBF00: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001CBF04: 02029135
	v_exp_f32_e32 v72, v75                                     // 0000001CBF08: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CBF0C: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 0000001CBF10: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001CBF18: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001CBF20: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001CBF24: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBF2C: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001CBF30: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001CBF34: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001CBF38: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CBF44: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 0000001CBF48: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001CBF50: BF870185
	.long 0xd71c003a                                           // 0000001CBF54: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001CBF58: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 0000001CBF5C: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBF64: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001CBF68: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 0000001CBF70: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBF74: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001CBF78: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 0000001CBF80: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001CBF84: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBF8C: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 0000001CBF90: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 0000001CBF94: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBF9C: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 0000001CBFA0: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001CBFA4: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 0000001CBFAC: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CBFB4: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001CBFB8: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 0000001CBFC4: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001CBFC8: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001CBFD0: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CBFD8: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001CBFDC: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 0000001CBFE4: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 0000001CBFEC: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001CBFF0: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001CBFF8: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001CC000: 7C3694FF C2B17218
	.long 0x7f723980                                           // 0000001CC008: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 0000001CC00C: 06929749
	.long 0x7e7239ad                                           // 0000001CC010: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001CC014: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001CC01C: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001CC024: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC028: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001CC02C: 36727281
	.long 0x7e0039aa                                           // 0000001CC030: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC034: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 0000001CC038: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001CC03C: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 0000001CC044: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001CC048: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001CC050: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 0000001CC05C: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001CC060: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001CC068: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001CC074: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001CC078: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001CC080: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 0000001CC08C: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001CC090: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 0000001CC098: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001CC09C: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001CC0A0: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001CC0A4: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 0000001CC0AC: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001CC0B0: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC0B8: BF870092
	v_exp_f32_e32 v46, v46                                     // 0000001CC0BC: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 0000001CC0C0: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001CC0C4: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CC0CC: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 0000001CC0D0: 109A794A
	.long 0xd71c002e                                           // 0000001CC0D4: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001CC0D8: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001CC0DC: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CC0E0: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 0000001CC0E4: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001CC0EC: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001CC0F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001CC0F8: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CC100: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 0000001CC104: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001CC108: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001CC10C: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001CC118: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001CC11C: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CC124: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001CC128: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001CC130: BF870205
	.long 0xd71c0036                                           // 0000001CC134: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001CC138: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC13C: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 0000001CC140: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 0000001CC148: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001CC14C: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CC154: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001CC158: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 0000001CC160: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC164: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001CC168: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 0000001CC170: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001CC174: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC17C: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 0000001CC180: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 0000001CC184: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC18C: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 0000001CC190: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001CC194: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 0000001CC19C: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CC1A4: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001CC1A8: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001CC1B4: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001CC1B8: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001CC1C0: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC1C8: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001CC1CC: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001CC1D4: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001CC1D8: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001CC1DC: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001CC1E0: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001CC1E8: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001CC1F0: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001CC1F8: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001CC200: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001CC204: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001CC208: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001CC210: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001CC218: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001CC21C: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001CC228: 7E78472B
	.long 0x7e0039a2                                           // 0000001CC22C: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001CC230: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC238: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001CC23C: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 0000001CC244: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC248: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 0000001CC24C: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001CC250: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CC258: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001CC25C: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001CC264: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 0000001CC268: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001CC26C: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 0000001CC278: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 0000001CC27C: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001CC280: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 0000001CC288: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 0000001CC28C: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001CC290: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CC29C: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 0000001CC2A0: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001CC2A4: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001CC2AC: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 0000001CC2B4: D613003D 24DA7739
	.long 0xd71c002b                                           // 0000001CC2BC: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001CC2C0: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001CC2C4: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001CC2C8: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001CC2CC: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001CC2D4: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001CC2D8: D501002B 00065680
	.long 0xd41b0001                                           // 0000001CC2E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001CC2E4: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001CC2EC: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 0000001CC2F4: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 0000001CC2F8: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001CC300: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC30C: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 0000001CC310: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001CC318: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001CC320: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC328: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 0000001CC32C: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001CC330: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001CC334: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001CC338: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC340: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001CC344: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001CC34C: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001CC350: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001CC354: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001CC35C: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC360: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001CC364: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001CC36C: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001CC370: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001CC378: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001CC380: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC388: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001CC38C: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001CC398: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001CC3A0: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001CC3AC: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001CC3B0: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC3B4: BF870193
	.long 0x7e0039a1                                           // 0000001CC3B8: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001CC3BC: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001CC3C0: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001CC3C4: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001CC3CC: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001CC3D0: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001CC3D4: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001CC3DC: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001CC3E0: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001CC3EC: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001CC3F0: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001CC3F8: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001CC3FC: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001CC404: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001CC40C: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001CC410: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001CC414: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001CC41C: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001CC420: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001CC424: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001CC428: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001CC434: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001CC43C: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001CC440: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001CC444: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001CC448: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001CC44C: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001CC454: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001CC45C: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001CC464: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001CC470: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001CC474: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 0000001CC47C: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CC480: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 0000001CC484: 56724D3B
	.long 0xd71c0029                                           // 0000001CC488: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001CC48C: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001CC490: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001CC494: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 0000001CC49C: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001CC4A4: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001CC4AC: D5010029 00065280
	.long 0xd41b0001                                           // 0000001CC4B4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001CC4B8: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001CC4C0: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001CC4C8: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001CC4CC: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001CC4D0: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001CC4D8: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001CC4E0: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001CC4EC: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001CC4F4: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001CC4F8: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001CC4FC: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CC504: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001CC508: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001CC510: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001CC514: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001CC518: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CC51C: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001CC520: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001CC528: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001CC530: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001CC538: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001CC540: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001CC544: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001CC550: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001CC558: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001CC560: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001CC564: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001CC568: 7E7C473B
	.long 0x7e0039a2                                           // 0000001CC56C: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001CC570: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001CC574: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001CC57C: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001CC584: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001CC588: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001CC58C: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001CC594: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001CC5A0: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001CC5A4: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001CC5AC: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001CC5B0: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001CC5B4: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CC5BC: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001CC5C0: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001CC5C8: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001CC5D0: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001CC5DC: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001CC5E0: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001CC5E4: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001CC5E8: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CC5EC: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001CC5F0: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001CC5F8: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001CC604: 7E4C4B26
	.long 0xd41e0001                                           // 0000001CC608: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001CC60C: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001CC614: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001CC61C: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001CC620: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001CC628: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001CC630: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001CC634: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001CC638: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001CC640: 108E5D3C
	.long 0xd71c0026                                           // 0000001CC644: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001CC648: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001CC64C: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001CC650: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC658: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001CC65C: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001CC664: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001CC66C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001CC670: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CC678: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001CC67C: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001CC684: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001CC68C: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001CC690: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001CC694: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001CC6A0: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001CC6A8: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001CC6B0: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001CC6B8: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001CC6BC: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001CC6C0: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001CC6C4: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001CC6C8: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001CC6D4: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001CC6D8: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001CC6DC: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001CC6E0: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001CC6E8: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001CC6F0: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001CC6F8: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001CC6FC: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001CC704: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001CC70C: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001CC714: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001CC71C: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001CC720: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001CC724: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001CC730: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001CC734: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001CC738: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001CC73C: 06465B23
	.long 0x7f523980                                           // 0000001CC740: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001CC744: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001CC748: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001CC750: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001CC758: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001CC75C: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001CC764: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001CC768: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001CC76C: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001CC770: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001CC778: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001CC77C: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001CC788: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001CC78C: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001CC790: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001CC794: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001CC7A0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001CC7A4: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001CC7AC: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001CC7B4: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001CC7B8: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001CC7BC: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001CC7C4: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001CC7C8: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001CC7D0: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001CC7D4: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001CC7DC: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001CC7E0: D5010023 00064680
	.long 0xd41b0001                                           // 0000001CC7E8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001CC7EC: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001CC7F4: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001CC7FC: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001CC800: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001CC808: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC814: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001CC818: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001CC820: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001CC828: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC830: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001CC834: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001CC838: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001CC83C: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001CC840: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC848: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001CC84C: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001CC854: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001CC858: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001CC85C: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001CC864: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC868: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001CC86C: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001CC874: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001CC878: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001CC880: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001CC888: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC890: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001CC894: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001CC8A0: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001CC8A8: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001CC8B4: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001CC8B8: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC8BC: BF870193
	.long 0x7e003999                                           // 0000001CC8C0: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001CC8C4: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001CC8C8: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001CC8CC: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001CC8D4: 7E4A399B
	.long 0x7f4a3980                                           // 0000001CC8D8: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001CC8DC: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001CC8E4: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001CC8E8: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001CC8F4: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001CC8F8: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001CC900: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001CC904: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001CC90C: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CC914: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001CC918: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001CC920: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001CC928: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001CC92C: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001CC930: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001CC934: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001CC940: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001CC944: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001CC94C: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001CC950: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001CC954: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001CC958: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001CC960: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001CC968: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001CC970: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001CC97C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001CC980: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CC988: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001CC98C: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001CC990: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CC994: BF870005
	.long 0xd71c0021                                           // 0000001CC998: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001CC99C: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001CC9A0: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001CC9A4: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001CC9AC: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001CC9B4: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001CC9BC: D5010021 00064280
	.long 0xd41b0001                                           // 0000001CC9C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001CC9C8: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001CC9D0: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001CC9D8: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001CC9DC: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001CC9E0: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001CC9E8: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001CC9F0: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001CC9FC: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001CCA04: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001CCA08: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001CCA0C: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CCA14: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001CCA18: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001CCA20: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001CCA24: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001CCA28: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CCA2C: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001CCA30: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001CCA38: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001CCA40: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001CCA48: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001CCA50: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001CCA54: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001CCA60: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001CCA68: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001CCA70: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001CCA74: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001CCA78: 7E6C472D
	.long 0x7e00399a                                           // 0000001CCA7C: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001CCA80: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001CCA84: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001CCA8C: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001CCA94: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001CCA98: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001CCA9C: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001CCAA4: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001CCAB0: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001CCAB4: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001CCABC: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001CCAC0: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001CCAC4: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CCACC: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001CCAD0: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001CCAD8: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001CCAE0: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001CCAEC: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001CCAF0: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001CCAF4: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001CCAF8: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CCAFC: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001CCB00: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001CCB08: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001CCB14: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001CCB18: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001CCB1C: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001CCB24: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001CCB2C: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001CCB30: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001CCB38: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001CCB3C: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001CCB44: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001CCB4C: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001CCB54: 10724D2E
	.long 0xd71c001e                                           // 0000001CCB58: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001CCB5C: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001CCB60: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CCB64: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001CCB68: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001CCB70: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001CCB74: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001CCB7C: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001CCB84: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001CCB88: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001CCB90: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001CCB98: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001CCBA0: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001CCBA4: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001CCBA8: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001CCBB4: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001CCBBC: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001CCBC4: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001CCBCC: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001CCBD0: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001CCBD4: 063C3CF2
	.long 0xd41e0001                                           // 0000001CCBD8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001CCBDC: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001CCBE4: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001CCBF0: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001CCBF4: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001CCBF8: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001CCBFC: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001CCC04: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001CCC0C: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001CCC14: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001CCC20: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CCC24: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001CCC28: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001CCC30: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001CCC38: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001CCC3C: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001CCC44: 06425321
	.long 0x7e003992                                           // 0000001CCC48: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001CCC4C: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001CCC50: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001CCC54: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001CCC60: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001CCC64: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001CCC68: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001CCC70: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CCC78: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001CCC7C: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001CCC88: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001CCC90: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CCC94: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001CCC98: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001CCC9C: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001CCCA4: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001CCCA8: 06565D2B
	.long 0xd71c0021                                           // 0000001CCCAC: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001CCCB0: 02025521
	.long 0x7e3a3991                                           // 0000001CCCB4: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001CCCB8: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001CCCBC: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001CCCC8: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001CCCCC: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001CCCD4: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CCCDC: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001CCCE0: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001CCCE8: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001CCCF0: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001CCCFC: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CCD00: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001CCD04: C8C04929 362C332C
	s_clause 0x1                                               // 0000001CCD0C: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001CCD10: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001CCD18: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001CCD20: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001CCD28: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001CCD30: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CCD34: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001CCD38: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001CCD3C: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001CCD44: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CCD4C: BF870004
	.long 0xd71c0022                                           // 0000001CCD50: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001CCD54: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001CCD58: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001CCD60: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001CCD68: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001CCD70: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001CCD78: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001CCD80: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CCD84: BF870214
	.long 0x7e3c3991                                           // 0000001CCD88: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001CCD8C: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001CCD90: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001CCD94: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001CCD98: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001CCDA0: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001CCDA8: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001CCDAC: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001CCDB0: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001CCDB4: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001CCDB8: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001CCDC0: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001CCDC8: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CCDD0: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001CCDD4: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001CCDE0: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CCDE4: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001CCDE8: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001CCDEC: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001CCDF0: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001CCDF8: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001CCDFC: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CCE04: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001CCE08: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001CCE14: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001CCE18: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001CCE20: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001CCE2C: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001CCE30: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001CCE34: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001CCE3C: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001CCE40: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001CCE48: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001CCE50: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CCE58: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001CCE5C: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001CCE60: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001CCE64: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CCE6C: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001CCE70: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001CCE74: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001CCE7C: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001CCE84: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001CCE88: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001CCE94: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CCE98: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001CCE9C: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001CCEA4: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CCEAC: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001CCEB0: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001CCEB4: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CCEBC: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001CCEC0: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001CCEC8: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001CCECC: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001CCED0: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CCED4: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001CCED8: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001CCEE0: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001CCEE8: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CCEF0: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001CCEF4: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001CCEFC: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001CCF00: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001CCF04: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001CCF08: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001CCF10: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001CCF18: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001CCF20: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001CCF24: 30448C90
	.long 0x7e2a3991                                           // 0000001CCF28: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001CCF2C: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001CCF34: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001CCF3C: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001CCF40: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001CCF44: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001CCF4C: 3032D090
	.long 0x7e003993                                           // 0000001CCF50: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001CCF54: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001CCF5C: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001CCF60: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001CCF68: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CCF70: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001CCF74: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001CCF7C: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001CCF88: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001CCF90: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CCF9C: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001CCFA0: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001CCFA4: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001CCFA8: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001CCFB4: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001CCFC0: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CCFCC: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001CCFD0: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001CCFD4: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001CCFD8: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001CCFE0: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CCFE4: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001CCFE8: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001CCFF0: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001CCFF4: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001CD000: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001CD004: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001CD00C: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001CD010: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001CD014: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001CD01C: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001CD020: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001CD028: 104C351D
	.long 0xd41e0001                                           // 0000001CD02C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001CD030: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001CD038: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001CD03C: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001CD044: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001CD048: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001CD050: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001CD054: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001CD058: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001CD060: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001CD064: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001CD06C: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001CD070: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001CD078: 564C3515
	.long 0xd41b0001                                           // 0000001CD07C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001CD080: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001CD088: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CD090: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001CD094: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001CD09C: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD0A8: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001CD0AC: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001CD0B4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001CD0B8: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD0C0: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001CD0C4: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001CD0CC: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001CD0D4: 563C4915
	.long 0xd71c0015                                           // 0000001CD0D8: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001CD0DC: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001CD0E0: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001CD0E4: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD0EC: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001CD0F0: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001CD0F8: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001CD0FC: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001CD100: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CD108: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001CD10C: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001CD114: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001CD11C: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001CD120: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CD124: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001CD128: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001CD130: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001CD138: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001CD140: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001CD148: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001CD150: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001CD154: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001CD158: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CD164: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001CD168: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001CD170: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001CD174: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001CD178: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001CD180: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001CD188: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001CD18C: 08323D19
	.long 0x7e283989                                           // 0000001CD190: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001CD194: 7E2A5516
	.long 0x7f283980                                           // 0000001CD198: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001CD19C: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001CD1A0: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001CD1A4: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001CD1B0: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001CD1B4: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001CD1C0: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001CD1C4: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001CD1CC: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001CD1D0: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001CD1D8: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001CD1E0: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001CD1E4: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001CD1F0: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001CD1F4: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001CD1F8: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001CD200: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001CD208: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001CD210: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001CD214: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001CD218: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001CD21C: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001CD224: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001CD228: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001CD230: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001CD238: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001CD240: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001CD248: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001CD24C: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD254: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001CD258: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001CD25C: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CD264: BF870004
	.long 0xd71c0011                                           // 0000001CD268: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001CD26C: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001CD270: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001CD278: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001CD280: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001CD288: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001CD28C: 30328690
	.long 0x7e2c398b                                           // 0000001CD290: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001CD294: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001CD298: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001CD29C: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001CD2A0: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001CD2A8: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001CD2B0: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001CD2B8: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001CD2BC: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001CD2C4: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001CD2D0: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001CD2D8: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001CD2E0: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001CD2E8: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001CD2EC: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001CD2F0: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001CD2F8: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001CD2FC: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001CD308: 7E384713
	.long 0xd41e0001                                           // 0000001CD30C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001CD310: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001CD318: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001CD31C: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001CD324: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001CD32C: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001CD330: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001CD338: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001CD33C: 7E42551A
	.long 0x7f2c3980                                           // 0000001CD340: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CD344: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001CD348: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001CD350: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001CD358: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001CD360: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001CD364: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CD368: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001CD36C: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001CD370: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001CD378: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD37C: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001CD380: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001CD38C: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CD394: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001CD398: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001CD39C: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001CD3A4: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001CD3A8: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001CD3AC: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001CD3B0: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001CD3B4: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001CD3B8: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001CD3BC: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001CD3C8: D5010013 00062680
	.long 0xd41b0001                                           // 0000001CD3D0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001CD3D4: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001CD3DC: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001CD3E4: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001CD3EC: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001CD3F0: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001CD3F4: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001CD3FC: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001CD408: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001CD40C: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001CD414: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001CD418: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001CD420: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001CD428: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001CD42C: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001CD434: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001CD43C: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001CD444: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001CD44C: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001CD454: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001CD45C: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001CD460: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001CD464: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001CD46C: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001CD470: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001CD474: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD478: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001CD47C: D627000C 043A2314
	.long 0x7e223989                                           // 0000001CD484: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001CD488: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001CD490: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001CD494: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001CD49C: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CD4A0: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001CD4A4: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001CD4AC: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001CD4B0: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001CD4B4: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD4B8: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001CD4BC: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001CD4C0: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001CD4C8: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD4D4: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001CD4D8: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001CD4E4: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001CD4EC: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001CD4F0: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001CD4F4: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001CD4FC: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001CD500: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001CD508: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001CD510: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001CD51C: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001CD524: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001CD528: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001CD530: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CD534: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001CD538: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001CD544: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CD54C: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001CD550: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001CD558: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001CD564: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CD56C: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001CD570: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001CD574: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001CD578: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001CD580: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001CD588: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001CD58C: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001CD590: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001CD594: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001CD598: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001CD59C: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001CD5A4: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001CD5A8: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001CD5AC: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001CD5B0: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001CD5B8: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001CD5C0: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001CD5C4: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001CD5CC: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001CD5D0: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001CD5D4: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001CD5E0: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001CD5E4: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001CD5E8: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001CD5F4: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD5F8: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001CD5FC: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001CD608: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001CD60C: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001CD614: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001CD618: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001CD61C: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001CD624: 0632331A
	.long 0xd71c000c                                           // 0000001CD628: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001CD62C: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001CD630: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001CD634: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001CD638: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001CD640: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001CD644: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001CD64C: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001CD654: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001CD658: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001CD65C: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001CD660: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001CD664: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001CD66C: 7E443981
	.long 0x7f443980                                           // 0000001CD670: 7F443980
	.long 0xd71c0012                                           // 0000001CD674: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001CD678: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001CD67C: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001CD684: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001CD68C: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001CD694: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001CD698: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CD69C: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001CD6A0: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001CD6A4: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001CD6A8: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001CD6AC: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001CD6B4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001CD6B8: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001CD6C0: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001CD6C8: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001CD6D0: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CD6D8: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001CD6DC: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001CD6E0: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001CD6E4: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001CD6EC: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001CD6F4: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CD6F8: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001CD6FC: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001CD704: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001CD708: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001CD710: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001CD714: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001CD71C: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001CD720: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001CD728: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001CD730: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001CD738: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001CD73C: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001CD744: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001CD748: 5638391E
	.long 0x7e003982                                           // 0000001CD74C: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001CD750: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001CD758: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CD760: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001CD764: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001CD768: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD770: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001CD774: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001CD77C: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001CD784: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD78C: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001CD790: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001CD798: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001CD79C: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001CD7A4: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001CD7A8: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001CD7AC: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001CD7B4: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001CD7B8: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001CD7BC: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001CD7C4: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001CD7CC: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001CD7D4: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001CD7D8: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001CD7E0: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001CD7E4: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001CD7EC: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CD7F0: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001CD7F4: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001CD7FC: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CD804: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001CD808: D6270004 04121909
	.long 0x7f183980                                           // 0000001CD810: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001CD814: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001CD820: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001CD828: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001CD830: BEEA0002
	.long 0x7e003984                                           // 0000001CD834: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001CD838: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001CD844: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001CD84C: D6270005 0416250A
	.long 0x7e143983                                           // 0000001CD854: 7E143983
	.long 0x7f143980                                           // 0000001CD858: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001CD85C: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001CD864: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001CD86C: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001CD870: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001CD874: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD878: BF870214
	.long 0x7e003986                                           // 0000001CD87C: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001CD880: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CD884: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001CD888: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001CD894: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001CD8A0: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CD8A4: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001CD8A8: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001CD8B4: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001CD8C0: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001CD8C4: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001CD8CC: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001CD8D4: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001CD8DC: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001CD8E4: DC9600E0 007C0027
	s_endpgm                                                   // 0000001CD8EC: BFB00000
		...

