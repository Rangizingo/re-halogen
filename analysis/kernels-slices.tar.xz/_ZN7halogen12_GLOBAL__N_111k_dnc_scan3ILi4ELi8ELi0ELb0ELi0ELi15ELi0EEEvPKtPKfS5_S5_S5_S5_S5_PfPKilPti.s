00000000000fcb00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000FCB00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000FCB04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000FCB0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 5                                      // 0000000FCB14: 841A8503
	s_ashr_i32 s3, s2, 31                                      // 0000000FCB18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000FCB1C: 861B9F1A
	v_dual_mov_b32 v5, v0 :: v_dual_and_b32 v4, 31, v0         // 0000000FCB20: CA240100 0504009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FCB28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v4                                // 0000000FCB2C: 30020882
	s_waitcnt lgkmcnt(0)                                       // 0000000FCB30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000FCB34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000FCB3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000FCB40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000FCB44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000FCB48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FCB4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000FCB50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000FCB54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000FCB58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000FCB5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000FCB64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000FCB6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000FCB70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000FCB74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FCB78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000FCB7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000FCB80: 821E191E
	.long 0xd7001f02                                           // 0000000FCB84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000FCB88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000FCB8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000FCB94: BE9E0080
	s_nop 0                                                    // 0000000FCB98: BF800000
	s_nop 0                                                    // 0000000FCB9C: BF800000
	s_nop 0                                                    // 0000000FCBA0: BF800000
	s_nop 0                                                    // 0000000FCBA4: BF800000
	s_nop 0                                                    // 0000000FCBA8: BF800000
	s_nop 0                                                    // 0000000FCBAC: BF800000
	s_nop 0                                                    // 0000000FCBB0: BF800000
	s_nop 0                                                    // 0000000FCBB4: BF800000
	s_nop 0                                                    // 0000000FCBB8: BF800000
	s_nop 0                                                    // 0000000FCBBC: BF800000
	v_lshrrev_b32_e32 v8, 5, v5                                // 0000000FCBC0: 32100A85
	v_add_nc_u32_e32 v10, 0x80, v5                             // 0000000FCBC4: 4A140AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000FCBD0: 300C1089
	.long 0xd7006a06                                           // 0000000FCBD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000FCBD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FCBDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000FCBE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v5                         // 0000000FCBE8: 7C920AFF 00000F7F
	v_mov_b32_e32 v5, v10                                      // 0000000FCBF0: 7E0A030A
	global_load_b32 v9, v[6:7], off                            // 0000000FCBF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x84, v8, v[1:2]               // 0000000FCBFC: D6FE7C06 040610FF 00000084
	s_or_b32 s30, vcc_lo, s30                                  // 0000000FCC08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000FCC0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000FCC10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000FCC18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000FCC1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000FCC20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000FCC24: F4000780 F8000058
	v_or_b32_e32 v51, 0xffffff80, v0                           // 0000000FCC2C: 386600FF FFFFFF80
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000000FCC34: 32040085
	s_mov_b32 s0, 0                                            // 0000000FCC38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000FCC3C: BF89FC07
	s_barrier                                                  // 0000000FCC40: BFBD0000
	buffer_gl0_inv                                             // 0000000FCC44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000FCC4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000FCC50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x84, v2                             // 0000000FCC54: 160604FF 00000084
	v_or_b32_e32 v5, 0xffffff80, v0                            // 0000000FCC5C: 380A00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FCC64: BF870002
	v_lshl_add_u32 v58, v4, 2, v3                              // 0000000FCC68: D646003A 040D0504
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v52, 2, v4      // 0000000FCC70: CA220080 03340882
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000FCC78: 916A007E
	s_cbranch_vccz 2                                           // 0000000FCC7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2958                                              // 0000000FCC80: BFA00B8E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fbc>
	v_lshlrev_b32_e32 v52, 2, v4                               // 0000000FCC84: 30680882
	s_add_i32 s0, s30, 63                                      // 0000000FCC88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000FCC8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000FCC94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000FCC98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000FCC9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000FCCA0: 84008702
	v_lshlrev_b32_e32 v5, 1, v4                                // 0000000FCCA4: 300A0881
	s_ashr_i32 s1, s0, 31                                      // 0000000FCCA8: 86019F00
	v_lshlrev_b32_e32 v25, 8, v2                               // 0000000FCCAC: 30320488
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000FCCB0: 84808100
	v_add_nc_u32_e32 v56, 1, v2                                // 0000000FCCB4: 4A700481
	s_add_u32 s22, s22, s0                                     // 0000000FCCB8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000FCCBC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000FCCC0: 848A811A
	.long 0xd44c0000                                           // 0000000FCCC4: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000000FCCC8: 020200FF 00000100
	s_add_u32 s22, s22, s10                                    // 0000000FCCD0: 80160A16
	.long 0xd7000a39                                           // 0000000FCCD4: D7000A39
	v_cndmask_b32_e32 v1, s34, v52, vcc_lo                     // 0000000FCCD8: 02026822
	s_addc_u32 s1, s1, s11                                     // 0000000FCCDC: 82010B01
	v_add_co_ci_u32_e64 v59, null, s35, 0, s10                 // 0000000FCCE0: D5207C3B 00290023
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000FCCE8: 848A8902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000FCCEC: BF870249
	v_dual_mov_b32 v28, s11 :: v_dual_lshlrev_b32 v53, 2, v0   // 0000000FCCF0: CA22000B 1C340082
	v_mov_b32_e32 v3, 0                                        // 0000000FCCF8: 7E060280
	v_or_b32_e32 v4, 0x4200, v1                                // 0000000FCCFC: 380802FF 00004200
	v_mad_u32_u24 v58, 0x84, v2, v52                           // 0000000FCD04: D60B003A 04D204FF 00000084
	v_or_b32_e32 v27, s10, v53                                 // 0000000FCD10: 38366A0A
	.long 0xd7000a05                                           // 0000000FCD14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000FCD18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FCD1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000FCD20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000FCD28: D7000107
	v_cndmask_b32_e32 v1, s12, v27, vcc_lo                     // 0000000FCD2C: 0202360C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCD30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v28, s1                 // 0000000FCD34: D5207C08 0006380D
	.long 0xd700011d                                           // 0000000FCD3C: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v27, vcc_lo                 // 0000000FCD40: 020236FF 00030000
	v_add_co_ci_u32_e64 v30, null, 0, v28, s1                  // 0000000FCD48: D5207C1E 00063880
	s_movk_i32 s10, 0x204                                      // 0000000FCD50: B00A0204
	.long 0xd7000109                                           // 0000000FCD54: D7000109
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000000FCD58: 02023A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCD5C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s13, v30, s1                // 0000000FCD60: D5207C0A 00063C0D
	.long 0xd700011f                                           // 0000000FCD68: D700011F
	v_cndmask_b32_e32 v1, 0x60000, v27, vcc_lo                 // 0000000FCD6C: 020236FF 00060000
	v_add_co_ci_u32_e64 v32, null, 0, v28, s1                  // 0000000FCD74: D5207C20 00063880
	.long 0xd7000121                                           // 0000000FCD7C: D7000121
	v_cndmask_b32_e32 v1, 0x90000, v27, vcc_lo                 // 0000000FCD80: 020236FF 00090000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCD88: BF870211
	v_add_co_ci_u32_e64 v34, null, 0, v28, s1                  // 0000000FCD8C: D5207C22 00063880
	.long 0xd700010b                                           // 0000000FCD94: D700010B
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000000FCD98: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCD9C: BF870211
	v_add_co_ci_u32_e64 v12, null, s13, v32, s1                // 0000000FCDA0: D5207C0C 0006400D
	.long 0xd700010d                                           // 0000000FCDA8: D700010D
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 0000000FCDAC: 0202420C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCDB0: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s13, v34, s1                // 0000000FCDB4: D5207C0E 0006440D
	.long 0xd7000123                                           // 0000000FCDBC: D7000123
	v_cndmask_b32_e32 v1, 0xc0000, v27, vcc_lo                 // 0000000FCDC0: 020236FF 000C0000
	v_add_co_ci_u32_e64 v36, null, 0, v28, s1                  // 0000000FCDC8: D5207C24 00063880
	.long 0xd7000125                                           // 0000000FCDD0: D7000125
	v_cndmask_b32_e32 v1, 0xf0000, v27, vcc_lo                 // 0000000FCDD4: 020236FF 000F0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCDDC: BF870211
	v_add_co_ci_u32_e64 v38, null, 0, v28, s1                  // 0000000FCDE0: D5207C26 00063880
	.long 0xd700010f                                           // 0000000FCDE8: D700010F
	v_cndmask_b32_e32 v1, s12, v35, vcc_lo                     // 0000000FCDEC: 0202460C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCDF0: BF870211
	v_add_co_ci_u32_e64 v16, null, s13, v36, s1                // 0000000FCDF4: D5207C10 0006480D
	.long 0xd7000111                                           // 0000000FCDFC: D7000111
	v_cndmask_b32_e32 v1, s12, v37, vcc_lo                     // 0000000FCE00: 02024A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCE04: BF8700A1
	v_add_co_ci_u32_e64 v18, null, s13, v38, s1                // 0000000FCE08: D5207C12 00064C0D
	.long 0xd7000127                                           // 0000000FCE10: D7000127
	v_cndmask_b32_e32 v1, 0x120000, v27, vcc_lo                // 0000000FCE14: 020236FF 00120000
	v_add_co_ci_u32_e64 v40, null, 0, v28, s1                  // 0000000FCE1C: D5207C28 00063880
	.long 0xd7000129                                           // 0000000FCE24: D7000129
	v_cndmask_b32_e32 v1, 0x150000, v27, vcc_lo                // 0000000FCE28: 020236FF 00150000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCE30: BF870211
	v_add_co_ci_u32_e64 v42, null, 0, v28, s1                  // 0000000FCE34: D5207C2A 00063880
	.long 0xd7000113                                           // 0000000FCE3C: D7000113
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000000FCE40: 02024E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FCE44: BF870211
	v_add_co_ci_u32_e64 v20, null, s13, v40, s1                // 0000000FCE48: D5207C14 0006500D
	.long 0xd7000115                                           // 0000000FCE50: D7000115
	v_cndmask_b32_e32 v1, s12, v41, vcc_lo                     // 0000000FCE54: 0202520C
	v_mad_u32_u24 v60, v2, s10, 0x6300                         // 0000000FCE58: D60B003C 03FC1502 00006300
	v_add_co_ci_u32_e64 v22, null, s13, v42, s1                // 0000000FCE64: D5207C16 0006540D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 0000000FCE6C: 848A8E02
	.long 0xd7000117                                           // 0000000FCE70: D7000117
	v_cndmask_b32_e32 v1, s4, v27, vcc_lo                      // 0000000FCE74: 02023604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FCE78: BF8700C1
	v_add_co_ci_u32_e64 v24, null, s5, v28, s1                 // 0000000FCE7C: D5207C18 00063805
	s_add_u32 s1, s14, s10                                     // 0000000FCE84: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 0000000FCE88: 82040B0F
	.long 0xd7000119                                           // 0000000FCE8C: D7000119
	v_cndmask_b32_e32 v1, s1, v25, vcc_lo                      // 0000000FCE90: 02023201
	v_add_co_ci_u32_e64 v26, null, s4, 0, s1                   // 0000000FCE94: D5207C1A 00050004
	.long 0xd700011b                                           // 0000000FCE9C: D700011B
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000000FCEA0: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCEA4: BF8700A1
	v_add_co_ci_u32_e64 v28, null, s7, v28, s1                 // 0000000FCEA8: D5207C1C 00063807
	.long 0xd700011d                                           // 0000000FCEB0: D700011D
	v_cndmask_b32_e32 v1, s6, v29, vcc_lo                      // 0000000FCEB4: 02023A06
	v_add_co_ci_u32_e64 v30, null, s7, v30, s1                 // 0000000FCEB8: D5207C1E 00063C07
	.long 0xd700011f                                           // 0000000FCEC0: D700011F
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 0000000FCEC4: 02023E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCEC8: BF8700A1
	v_add_co_ci_u32_e64 v32, null, s7, v32, s1                 // 0000000FCECC: D5207C20 00064007
	.long 0xd7000121                                           // 0000000FCED4: D7000121
	v_cndmask_b32_e32 v1, s6, v33, vcc_lo                      // 0000000FCED8: 02024206
	v_add_co_ci_u32_e64 v34, null, s7, v34, s1                 // 0000000FCEDC: D5207C22 00064407
	.long 0xd7000123                                           // 0000000FCEE4: D7000123
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 0000000FCEE8: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCEEC: BF8700A1
	v_add_co_ci_u32_e64 v36, null, s7, v36, s1                 // 0000000FCEF0: D5207C24 00064807
	.long 0xd7000125                                           // 0000000FCEF8: D7000125
	v_cndmask_b32_e32 v1, s6, v37, vcc_lo                      // 0000000FCEFC: 02024A06
	v_add_co_ci_u32_e64 v38, null, s7, v38, s1                 // 0000000FCF00: D5207C26 00064C07
	.long 0xd7000127                                           // 0000000FCF08: D7000127
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 0000000FCF0C: 02024E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FCF10: BF870001
	v_add_co_ci_u32_e64 v40, null, s7, v40, s1                 // 0000000FCF14: D5207C28 00065007
	.long 0xd7000129                                           // 0000000FCF1C: D7000129
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 0000000FCF20: 02025206
	v_add_nc_u32_e32 v54, 0x7320, v53                          // 0000000FCF24: 4A6C6AFF 00007320
	v_add_nc_u32_e32 v55, 0x7420, v53                          // 0000000FCF2C: 4A6E6AFF 00007420
	v_add_co_ci_u32_e64 v42, null, s7, v42, s1                 // 0000000FCF34: D5207C2A 00065407
	s_mov_b32 s5, 0                                            // 0000000FCF3C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000FCF40: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000FCF44: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000FCF4C: BF870499
	s_add_i32 s6, s31, s1                                      // 0000000FCF50: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000000FCF54: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FCF58: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000000FCF5C: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000000FCF60: 84078605
	s_add_u32 s10, s8, s10                                     // 0000000FCF64: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000000FCF68: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000000FCF6C: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000FCF74: BE84206A
	s_cbranch_execz 77                                         // 0000000FCF78: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b0>
	v_or_b32_e32 v43, s7, v0                                   // 0000000FCF7C: 38560007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCF80: BF870091
	v_mad_u64_u32 v[43:44], null, v43, 48, s[2:3]              // 0000000FCF84: D6FE7C2B 0009612B
	v_ashrrev_i32_e32 v44, 31, v43                             // 0000000FCF8C: 3458569F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCF90: BF870091
	.long 0xd73c002b                                           // 0000000FCF94: D73C002B
	v_cndmask_b32_e32 v1, 2, v43, vcc_lo                       // 0000000FCF98: 02025682
	.long 0xd700012b                                           // 0000000FCF9C: D700012B
	v_cndmask_b32_e32 v1, s8, v43, vcc_lo                      // 0000000FCFA0: 02025608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FCFA4: BF8700C1
	v_add_co_ci_u32_e64 v44, null, s9, v44, s1                 // 0000000FCFA8: D5207C2C 00065809
	global_load_b32 v43, v[43:44], off                         // 0000000FCFB0: DC520000 2B7C002B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FCFB8: BF890007
	v_sub_f32_e32 v44, s6, v43                                 // 0000000FCFBC: 08585606
	v_dual_mul_f32 v46, 0x3fb8aa3b, v43 :: v_dual_mul_f32 v45, 0x3fb8aa3b, v44// 0000000FCFC0: C8C656FF 2E2C58FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000FCFCC: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v43, -v46                       // 0000000FCFD0: D6130031 84BA56FF 3FB8AA3B
	v_rndne_f32_e32 v50, v46                                   // 0000000FCFDC: 7E64472E
	v_fma_f32 v47, 0x3fb8aa3b, v44, -v45                       // 0000000FCFE0: D613002F 84B658FF 3FB8AA3B
	v_rndne_f32_e32 v48, v45                                   // 0000000FCFEC: 7E60472D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FCFF0: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v43 :: v_dual_sub_f32 v46, v46, v50// 0000000FCFF4: C80A56FF 312E652E 32A5705F
	v_sub_f32_e32 v45, v45, v48                                // 0000000FD000: 085A612D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD004: BF870124
	v_fmac_f32_e32 v47, 0x32a5705f, v44                        // 0000000FD008: 565E58FF 32A5705F
	.long 0xd41b0001                                           // 0000000FD010: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v44, vcc_lo              // 0000000FD014: 020258FF C2CE8ED0
	v_dual_add_f32 v46, v46, v49 :: v_dual_add_f32 v45, v45, v47// 0000000FD01C: C908632E 2E2C5F2D
	v_cvt_i32_f32_e32 v47, v48                                 // 0000000FD024: 7E5E1130
	v_cvt_i32_f32_e32 v48, v50                                 // 0000000FD028: 7E601132
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FD02C: BF870193
	v_exp_f32_e32 v46, v46                                     // 0000000FD030: 7E5C4B2E
	v_exp_f32_e32 v45, v45                                     // 0000000FD034: 7E5A4B2D
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FD038: BF870296
	.long 0xd71c002e                                           // 0000000FD03C: D71C002E
	v_cndmask_b32_e32 v1, v46, v48, vcc_lo                     // 0000000FD040: 0202612E
	.long 0xd71c002d                                           // 0000000FD044: D71C002D
	v_cndmask_b32_e32 v1, v45, v47, vcc_lo                     // 0000000FD048: 02025F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FD04C: BF8700A1
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 0000000FD050: D501002D 00065A80
	.long 0xd41b0001                                           // 0000000FD058: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v43, vcc_lo              // 0000000FD05C: 020256FF C2CE8ED0
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000000FD064: D501002E 00065C80
	.long 0xd41e0001                                           // 0000000FD06C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v44, vcc_lo              // 0000000FD070: 020258FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FD078: BF8700A1
	v_cndmask_b32_e64 v44, 0x7f800000, v45, s1                 // 0000000FD07C: D501002C 00065AFF 7F800000
	.long 0xd41e0001                                           // 0000000FD088: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v43, vcc_lo              // 0000000FD08C: 020256FF 42B17218
	v_cndmask_b32_e64 v43, 0x7f800000, v46, s1                 // 0000000FD094: D501002B 00065CFF 7F800000
	ds_store_b32 v54, v44                                      // 0000000FD0A0: D8340000 00002C36
	ds_store_b32 v55, v43                                      // 0000000FD0A8: D8340000 00002B37
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FD0B0: 8C7E047E
	v_dual_mov_b32 v44, v8 :: v_dual_mov_b32 v43, v7           // 0000000FD0B4: CA100108 2C2A0107
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FD0BC: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FD0C4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FD0C8: BF89FC07
	s_barrier                                                  // 0000000FD0CC: BFBD0000
	buffer_gl0_inv                                             // 0000000FD0D0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FD0D8: BF800000
	s_nop 0                                                    // 0000000FD0DC: BF800000
	s_nop 0                                                    // 0000000FD0E0: BF800000
	s_nop 0                                                    // 0000000FD0E4: BF800000
	s_nop 0                                                    // 0000000FD0E8: BF800000
	s_nop 0                                                    // 0000000FD0EC: BF800000
	s_nop 0                                                    // 0000000FD0F0: BF800000
	s_nop 0                                                    // 0000000FD0F4: BF800000
	s_nop 0                                                    // 0000000FD0F8: BF800000
	s_nop 0                                                    // 0000000FD0FC: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FD100: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FD108: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FD110: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FD114: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FD11C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FD120: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FD128: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FD12C: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FD134: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FD138: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FD13C: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FD144: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FD14C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FD150: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x600>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FD154: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FD158: BF89FC07
	s_barrier                                                  // 0000000FD15C: BFBD0000
	buffer_gl0_inv                                             // 0000000FD160: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FD168: BE842000
	s_cbranch_execz 123                                        // 0000000FD16C: BFA5007B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x85c>
	v_mov_b32_e32 v43, v60                                     // 0000000FD170: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FD174: 7E580300
	s_mov_b32 s10, 0                                           // 0000000FD178: BE8A0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD17C: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FD180: 325A5885
	v_or_b32_e32 v46, s7, v45                                  // 0000000FD184: 385C5A07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD188: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FD18C: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FD194: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FD198: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD19C: BF870091
	.long 0xd700012e                                           // 0000000FD1A0: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FD1A4: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FD1A8: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FD1B0: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FD1B4: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FD1BC: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FD1C0: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FD1C4: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FD1C8: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FD1D0: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FD1D4: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FD1DC: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FD1E4: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FD1EC: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FD1F4: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FD1FC: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FD204: D8DC8786 47000049
	s_cmp_eq_u32 s1, 0                                         // 0000000FD20C: BF068001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FD210: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FD214: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD21C: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FD220: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FD228: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FD230: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FD238: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FD23C: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FD244: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FD24C: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FD254: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD25C: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FD260: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD268: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FD26C: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FD274: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FD27C: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD284: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FD288: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FD290: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FD298: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FD2A0: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FD2A8: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FD2B0: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FD2B4: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FD2BC: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FD2C0: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FD2C8: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD2D0: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FD2D4: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FD2DC: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FD2E4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD2E8: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FD2EC: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FD2F4: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FD2FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD300: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FD304: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FD30C: D613002F 24BE6546
	s_cbranch_scc0 65450                                       // 0000000FD314: BFA1FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6c0>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FD318: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FD320: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FD32C: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FD330: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FD338: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FD33C: CA200130 2C2A56FF 00000810
	s_or_b32 s10, s1, s10                                      // 0000000FD348: 8C0A0A01
	ds_store_b32 v45, v47                                      // 0000000FD34C: D8340000 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FD354: 917E0A7E
	s_cbranch_execnz 65416                                     // 0000000FD358: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x67c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FD35C: 8C7E047E
	v_dual_mov_b32 v44, v10 :: v_dual_mov_b32 v43, v9          // 0000000FD360: CA10010A 2C2A0109
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FD368: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FD370: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FD374: BF89FC07
	s_barrier                                                  // 0000000FD378: BFBD0000
	buffer_gl0_inv                                             // 0000000FD37C: E0AC0000 00000000
	s_nop 0                                                    // 0000000FD384: BF800000
	s_nop 0                                                    // 0000000FD388: BF800000
	s_nop 0                                                    // 0000000FD38C: BF800000
	s_nop 0                                                    // 0000000FD390: BF800000
	s_nop 0                                                    // 0000000FD394: BF800000
	s_nop 0                                                    // 0000000FD398: BF800000
	s_nop 0                                                    // 0000000FD39C: BF800000
	s_nop 0                                                    // 0000000FD3A0: BF800000
	s_nop 0                                                    // 0000000FD3A4: BF800000
	s_nop 0                                                    // 0000000FD3A8: BF800000
	s_nop 0                                                    // 0000000FD3AC: BF800000
	s_nop 0                                                    // 0000000FD3B0: BF800000
	s_nop 0                                                    // 0000000FD3B4: BF800000
	s_nop 0                                                    // 0000000FD3B8: BF800000
	s_nop 0                                                    // 0000000FD3BC: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FD3C0: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FD3C8: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FD3D0: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FD3D4: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FD3DC: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FD3E0: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FD3E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FD3EC: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FD3F4: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FD3F8: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FD3FC: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FD404: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FD40C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FD410: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FD414: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FD418: BF89FC07
	s_barrier                                                  // 0000000FD41C: BFBD0000
	buffer_gl0_inv                                             // 0000000FD420: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FD428: BE842000
	s_cbranch_execz 124                                        // 0000000FD42C: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb20>
	v_mov_b32_e32 v43, v60                                     // 0000000FD430: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FD434: 7E580300
	s_or_b32 s10, s7, 8                                        // 0000000FD438: 8C0A8807
	s_mov_b32 s11, 0                                           // 0000000FD43C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD440: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FD444: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FD448: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD44C: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FD450: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FD458: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FD45C: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD460: BF870091
	.long 0xd700012e                                           // 0000000FD464: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FD468: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FD46C: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FD474: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FD478: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FD480: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FD484: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FD488: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FD48C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FD494: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FD498: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FD4A0: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FD4A8: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FD4B0: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FD4B8: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FD4C0: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FD4C8: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FD4D0: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FD4D4: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FD4D8: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD4E0: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FD4E4: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FD4EC: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FD4F4: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FD4FC: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FD500: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FD508: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FD510: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FD518: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD520: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FD524: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD52C: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FD530: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FD538: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FD540: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD548: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FD54C: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FD554: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FD55C: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FD564: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FD56C: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FD574: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FD578: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FD580: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FD584: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FD58C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD594: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FD598: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FD5A0: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FD5A8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5AC: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FD5B0: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FD5B8: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FD5C0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5C4: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FD5C8: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FD5D0: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FD5D8: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x984>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FD5DC: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FD5E4: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FD5F0: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FD5F4: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FD5FC: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FD600: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FD60C: 8C0B0B01
	ds_store_b32 v45, v47 offset:1056                          // 0000000FD610: D8340420 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FD618: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FD61C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x940>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FD620: 8C7E047E
	v_dual_mov_b32 v44, v12 :: v_dual_mov_b32 v43, v11         // 0000000FD624: CA10010C 2C2A010B
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FD62C: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FD634: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FD638: BF89FC07
	s_barrier                                                  // 0000000FD63C: BFBD0000
	buffer_gl0_inv                                             // 0000000FD640: E0AC0000 00000000
	s_nop 0                                                    // 0000000FD648: BF800000
	s_nop 0                                                    // 0000000FD64C: BF800000
	s_nop 0                                                    // 0000000FD650: BF800000
	s_nop 0                                                    // 0000000FD654: BF800000
	s_nop 0                                                    // 0000000FD658: BF800000
	s_nop 0                                                    // 0000000FD65C: BF800000
	s_nop 0                                                    // 0000000FD660: BF800000
	s_nop 0                                                    // 0000000FD664: BF800000
	s_nop 0                                                    // 0000000FD668: BF800000
	s_nop 0                                                    // 0000000FD66C: BF800000
	s_nop 0                                                    // 0000000FD670: BF800000
	s_nop 0                                                    // 0000000FD674: BF800000
	s_nop 0                                                    // 0000000FD678: BF800000
	s_nop 0                                                    // 0000000FD67C: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FD680: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FD688: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FD690: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FD694: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FD69C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FD6A0: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FD6A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FD6AC: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FD6B4: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FD6B8: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FD6BC: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FD6C4: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FD6CC: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FD6D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FD6D4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FD6D8: BF89FC07
	s_barrier                                                  // 0000000FD6DC: BFBD0000
	buffer_gl0_inv                                             // 0000000FD6E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FD6E8: BE842000
	s_cbranch_execz 124                                        // 0000000FD6EC: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xde0>
	v_mov_b32_e32 v43, v60                                     // 0000000FD6F0: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FD6F4: 7E580300
	s_or_b32 s10, s7, 16                                       // 0000000FD6F8: 8C0A9007
	s_mov_b32 s11, 0                                           // 0000000FD6FC: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD700: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FD704: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FD708: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD70C: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FD710: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FD718: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FD71C: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD720: BF870091
	.long 0xd700012e                                           // 0000000FD724: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FD728: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FD72C: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FD734: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FD738: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FD740: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FD744: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FD748: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FD74C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FD754: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FD758: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FD760: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FD768: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FD770: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FD778: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FD780: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FD788: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FD790: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FD794: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FD798: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD7A0: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FD7A4: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FD7AC: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FD7B4: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FD7BC: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FD7C0: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FD7C8: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FD7D0: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FD7D8: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD7E0: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FD7E4: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FD7EC: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FD7F0: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FD7F8: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FD800: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD808: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FD80C: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FD814: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FD81C: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FD824: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FD82C: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FD834: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FD838: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FD840: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FD844: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FD84C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FD854: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FD858: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FD860: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FD868: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD86C: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FD870: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FD878: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FD880: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD884: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FD888: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FD890: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FD898: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc44>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FD89C: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FD8A4: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FD8B0: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FD8B4: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FD8BC: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FD8C0: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FD8CC: 8C0B0B01
	ds_store_b32 v45, v47 offset:2112                          // 0000000FD8D0: D8340840 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FD8D8: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FD8DC: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc00>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FD8E0: 8C7E047E
	v_dual_mov_b32 v44, v14 :: v_dual_mov_b32 v43, v13         // 0000000FD8E4: CA10010E 2C2A010D
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FD8EC: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FD8F4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FD8F8: BF89FC07
	s_barrier                                                  // 0000000FD8FC: BFBD0000
	buffer_gl0_inv                                             // 0000000FD900: E0AC0000 00000000
	s_nop 0                                                    // 0000000FD908: BF800000
	s_nop 0                                                    // 0000000FD90C: BF800000
	s_nop 0                                                    // 0000000FD910: BF800000
	s_nop 0                                                    // 0000000FD914: BF800000
	s_nop 0                                                    // 0000000FD918: BF800000
	s_nop 0                                                    // 0000000FD91C: BF800000
	s_nop 0                                                    // 0000000FD920: BF800000
	s_nop 0                                                    // 0000000FD924: BF800000
	s_nop 0                                                    // 0000000FD928: BF800000
	s_nop 0                                                    // 0000000FD92C: BF800000
	s_nop 0                                                    // 0000000FD930: BF800000
	s_nop 0                                                    // 0000000FD934: BF800000
	s_nop 0                                                    // 0000000FD938: BF800000
	s_nop 0                                                    // 0000000FD93C: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FD940: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FD948: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FD950: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FD954: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FD95C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FD960: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FD968: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FD96C: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FD974: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FD978: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FD97C: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FD984: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FD98C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FD990: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FD994: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FD998: BF89FC07
	s_barrier                                                  // 0000000FD99C: BFBD0000
	buffer_gl0_inv                                             // 0000000FD9A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FD9A8: BE842000
	s_cbranch_execz 124                                        // 0000000FD9AC: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10a0>
	v_mov_b32_e32 v43, v60                                     // 0000000FD9B0: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FD9B4: 7E580300
	s_or_b32 s10, s7, 24                                       // 0000000FD9B8: 8C0A9807
	s_mov_b32 s11, 0                                           // 0000000FD9BC: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD9C0: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FD9C4: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FD9C8: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD9CC: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FD9D0: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FD9D8: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FD9DC: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD9E0: BF870091
	.long 0xd700012e                                           // 0000000FD9E4: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FD9E8: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FD9EC: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FD9F4: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FD9F8: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FDA00: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FDA04: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FDA08: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FDA0C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FDA14: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FDA18: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FDA20: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FDA28: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FDA30: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FDA38: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FDA40: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FDA48: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FDA50: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FDA54: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FDA58: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FDA60: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FDA64: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FDA6C: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FDA74: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FDA7C: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FDA80: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FDA88: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FDA90: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FDA98: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDAA0: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FDAA4: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FDAAC: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FDAB0: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FDAB8: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FDAC0: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDAC8: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FDACC: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FDAD4: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FDADC: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FDAE4: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FDAEC: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FDAF4: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FDAF8: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FDB00: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FDB04: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FDB0C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDB14: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FDB18: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FDB20: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FDB28: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB2C: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FDB30: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FDB38: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FDB40: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB44: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FDB48: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FDB50: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FDB58: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf04>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FDB5C: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FDB64: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FDB70: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FDB74: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FDB7C: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FDB80: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FDB8C: 8C0B0B01
	ds_store_b32 v45, v47 offset:3168                          // 0000000FDB90: D8340C60 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FDB98: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FDB9C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xec0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FDBA0: 8C7E047E
	v_dual_mov_b32 v44, v16 :: v_dual_mov_b32 v43, v15         // 0000000FDBA4: CA100110 2C2A010F
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FDBAC: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FDBB4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FDBB8: BF89FC07
	s_barrier                                                  // 0000000FDBBC: BFBD0000
	buffer_gl0_inv                                             // 0000000FDBC0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FDBC8: BF800000
	s_nop 0                                                    // 0000000FDBCC: BF800000
	s_nop 0                                                    // 0000000FDBD0: BF800000
	s_nop 0                                                    // 0000000FDBD4: BF800000
	s_nop 0                                                    // 0000000FDBD8: BF800000
	s_nop 0                                                    // 0000000FDBDC: BF800000
	s_nop 0                                                    // 0000000FDBE0: BF800000
	s_nop 0                                                    // 0000000FDBE4: BF800000
	s_nop 0                                                    // 0000000FDBE8: BF800000
	s_nop 0                                                    // 0000000FDBEC: BF800000
	s_nop 0                                                    // 0000000FDBF0: BF800000
	s_nop 0                                                    // 0000000FDBF4: BF800000
	s_nop 0                                                    // 0000000FDBF8: BF800000
	s_nop 0                                                    // 0000000FDBFC: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FDC00: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FDC08: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FDC10: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FDC14: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FDC1C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FDC20: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FDC28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FDC2C: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FDC34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FDC38: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FDC3C: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FDC44: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FDC4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FDC50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FDC54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FDC58: BF89FC07
	s_barrier                                                  // 0000000FDC5C: BFBD0000
	buffer_gl0_inv                                             // 0000000FDC60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FDC68: BE842000
	s_cbranch_execz 124                                        // 0000000FDC6C: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1360>
	v_mov_b32_e32 v43, v60                                     // 0000000FDC70: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FDC74: 7E580300
	s_or_b32 s10, s7, 32                                       // 0000000FDC78: 8C0AA007
	s_mov_b32 s11, 0                                           // 0000000FDC7C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDC80: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FDC84: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FDC88: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDC8C: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FDC90: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FDC98: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FDC9C: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCA0: BF870091
	.long 0xd700012e                                           // 0000000FDCA4: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FDCA8: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FDCAC: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FDCB4: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FDCB8: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FDCC0: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FDCC4: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FDCC8: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FDCCC: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FDCD4: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FDCD8: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FDCE0: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FDCE8: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FDCF0: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FDCF8: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FDD00: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FDD08: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FDD10: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FDD14: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FDD18: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FDD20: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FDD24: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FDD2C: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FDD34: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FDD3C: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FDD40: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FDD48: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FDD50: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FDD58: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDD60: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FDD64: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FDD6C: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FDD70: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FDD78: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FDD80: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDD88: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FDD8C: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FDD94: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FDD9C: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FDDA4: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FDDAC: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FDDB4: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FDDB8: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FDDC0: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FDDC4: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FDDCC: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FDDD4: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FDDD8: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FDDE0: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FDDE8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDEC: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FDDF0: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FDDF8: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FDE00: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDE04: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FDE08: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FDE10: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FDE18: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c4>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FDE1C: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FDE24: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FDE30: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FDE34: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FDE3C: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FDE40: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FDE4C: 8C0B0B01
	ds_store_b32 v45, v47 offset:4224                          // 0000000FDE50: D8341080 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FDE58: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FDE5C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FDE60: 8C7E047E
	v_dual_mov_b32 v44, v18 :: v_dual_mov_b32 v43, v17         // 0000000FDE64: CA100112 2C2A0111
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FDE6C: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FDE74: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FDE78: BF89FC07
	s_barrier                                                  // 0000000FDE7C: BFBD0000
	buffer_gl0_inv                                             // 0000000FDE80: E0AC0000 00000000
	s_nop 0                                                    // 0000000FDE88: BF800000
	s_nop 0                                                    // 0000000FDE8C: BF800000
	s_nop 0                                                    // 0000000FDE90: BF800000
	s_nop 0                                                    // 0000000FDE94: BF800000
	s_nop 0                                                    // 0000000FDE98: BF800000
	s_nop 0                                                    // 0000000FDE9C: BF800000
	s_nop 0                                                    // 0000000FDEA0: BF800000
	s_nop 0                                                    // 0000000FDEA4: BF800000
	s_nop 0                                                    // 0000000FDEA8: BF800000
	s_nop 0                                                    // 0000000FDEAC: BF800000
	s_nop 0                                                    // 0000000FDEB0: BF800000
	s_nop 0                                                    // 0000000FDEB4: BF800000
	s_nop 0                                                    // 0000000FDEB8: BF800000
	s_nop 0                                                    // 0000000FDEBC: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FDEC0: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FDEC8: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FDED0: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FDED4: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FDEDC: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FDEE0: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FDEE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FDEEC: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FDEF4: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FDEF8: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FDEFC: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FDF04: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FDF0C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FDF10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FDF14: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FDF18: BF89FC07
	s_barrier                                                  // 0000000FDF1C: BFBD0000
	buffer_gl0_inv                                             // 0000000FDF20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FDF28: BE842000
	s_cbranch_execz 124                                        // 0000000FDF2C: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1620>
	v_mov_b32_e32 v43, v60                                     // 0000000FDF30: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FDF34: 7E580300
	s_or_b32 s10, s7, 40                                       // 0000000FDF38: 8C0AA807
	s_mov_b32 s11, 0                                           // 0000000FDF3C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF40: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FDF44: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FDF48: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF4C: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FDF50: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FDF58: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FDF5C: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF60: BF870091
	.long 0xd700012e                                           // 0000000FDF64: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FDF68: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FDF6C: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FDF74: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FDF78: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FDF80: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FDF84: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FDF88: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FDF8C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FDF94: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FDF98: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FDFA0: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FDFA8: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FDFB0: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FDFB8: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FDFC0: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FDFC8: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FDFD0: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FDFD4: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FDFD8: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FDFE0: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FDFE4: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FDFEC: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FDFF4: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FDFFC: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FE000: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FE008: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FE010: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FE018: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE020: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FE024: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE02C: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FE030: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FE038: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FE040: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE048: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FE04C: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FE054: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FE05C: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FE064: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FE06C: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FE074: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FE078: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FE080: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FE084: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FE08C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE094: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FE098: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FE0A0: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FE0A8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE0AC: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FE0B0: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FE0B8: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FE0C0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE0C4: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FE0C8: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FE0D0: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FE0D8: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1484>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FE0DC: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FE0E4: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FE0F0: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FE0F4: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FE0FC: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FE100: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FE10C: 8C0B0B01
	ds_store_b32 v45, v47 offset:5280                          // 0000000FE110: D83414A0 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FE118: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FE11C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1440>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FE120: 8C7E047E
	v_dual_mov_b32 v44, v20 :: v_dual_mov_b32 v43, v19         // 0000000FE124: CA100114 2C2A0113
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FE12C: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FE134: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FE138: BF89FC07
	s_barrier                                                  // 0000000FE13C: BFBD0000
	buffer_gl0_inv                                             // 0000000FE140: E0AC0000 00000000
	s_nop 0                                                    // 0000000FE148: BF800000
	s_nop 0                                                    // 0000000FE14C: BF800000
	s_nop 0                                                    // 0000000FE150: BF800000
	s_nop 0                                                    // 0000000FE154: BF800000
	s_nop 0                                                    // 0000000FE158: BF800000
	s_nop 0                                                    // 0000000FE15C: BF800000
	s_nop 0                                                    // 0000000FE160: BF800000
	s_nop 0                                                    // 0000000FE164: BF800000
	s_nop 0                                                    // 0000000FE168: BF800000
	s_nop 0                                                    // 0000000FE16C: BF800000
	s_nop 0                                                    // 0000000FE170: BF800000
	s_nop 0                                                    // 0000000FE174: BF800000
	s_nop 0                                                    // 0000000FE178: BF800000
	s_nop 0                                                    // 0000000FE17C: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FE180: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FE188: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FE190: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FE194: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FE19C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FE1A0: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FE1A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FE1AC: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FE1B4: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FE1B8: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FE1BC: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FE1C4: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FE1CC: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FE1D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1680>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FE1D4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FE1D8: BF89FC07
	s_barrier                                                  // 0000000FE1DC: BFBD0000
	buffer_gl0_inv                                             // 0000000FE1E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FE1E8: BE842000
	s_cbranch_execz 124                                        // 0000000FE1EC: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18e0>
	v_mov_b32_e32 v43, v60                                     // 0000000FE1F0: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FE1F4: 7E580300
	s_or_b32 s10, s7, 48                                       // 0000000FE1F8: 8C0AB007
	s_mov_b32 s11, 0                                           // 0000000FE1FC: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE200: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FE204: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FE208: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE20C: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FE210: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FE218: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FE21C: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE220: BF870091
	.long 0xd700012e                                           // 0000000FE224: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FE228: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FE22C: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FE234: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FE238: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FE240: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FE244: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FE248: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FE24C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FE254: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FE258: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FE260: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FE268: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FE270: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FE278: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FE280: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FE288: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FE290: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FE294: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FE298: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE2A0: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FE2A4: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FE2AC: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FE2B4: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FE2BC: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FE2C0: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FE2C8: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FE2D0: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FE2D8: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE2E0: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FE2E4: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE2EC: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FE2F0: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FE2F8: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FE300: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE308: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FE30C: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FE314: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FE31C: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FE324: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FE32C: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FE334: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FE338: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FE340: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FE344: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FE34C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE354: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FE358: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FE360: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FE368: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE36C: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FE370: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FE378: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FE380: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE384: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FE388: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FE390: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FE398: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1744>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FE39C: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FE3A4: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FE3B0: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FE3B4: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FE3BC: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FE3C0: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FE3CC: 8C0B0B01
	ds_store_b32 v45, v47 offset:6336                          // 0000000FE3D0: D83418C0 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FE3D8: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FE3DC: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1700>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FE3E0: 8C7E047E
	v_dual_mov_b32 v44, v22 :: v_dual_mov_b32 v43, v21         // 0000000FE3E4: CA100116 2C2A0115
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, v51         // 0000000FE3EC: CA100135 2D2E0133
	s_mov_b32 s10, 0                                           // 0000000FE3F4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000FE3F8: BF89FC07
	s_barrier                                                  // 0000000FE3FC: BFBD0000
	buffer_gl0_inv                                             // 0000000FE400: E0AC0000 00000000
	s_nop 0                                                    // 0000000FE408: BF800000
	s_nop 0                                                    // 0000000FE40C: BF800000
	s_nop 0                                                    // 0000000FE410: BF800000
	s_nop 0                                                    // 0000000FE414: BF800000
	s_nop 0                                                    // 0000000FE418: BF800000
	s_nop 0                                                    // 0000000FE41C: BF800000
	s_nop 0                                                    // 0000000FE420: BF800000
	s_nop 0                                                    // 0000000FE424: BF800000
	s_nop 0                                                    // 0000000FE428: BF800000
	s_nop 0                                                    // 0000000FE42C: BF800000
	s_nop 0                                                    // 0000000FE430: BF800000
	s_nop 0                                                    // 0000000FE434: BF800000
	s_nop 0                                                    // 0000000FE438: BF800000
	s_nop 0                                                    // 0000000FE43C: BF800000
	global_load_b32 v47, v[43:44], off                         // 0000000FE440: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000FE448: 4A5C5CFF 00000080
	.long 0xd700012b                                           // 0000000FE450: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FE454: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FE45C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FE460: D5207C2C 00065880
	.long 0xd4490004                                           // 0000000FE468: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000FE46C: 02025CFF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000FE474: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 0000000FE478: BF8903F7
	ds_store_b32 v45, v47 offset:25344                         // 0000000FE47C: D8346300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FE484: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000FE48C: 917E0A7E
	s_cbranch_execnz 65515                                     // 0000000FE490: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FE494: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FE498: BF89FC07
	s_barrier                                                  // 0000000FE49C: BFBD0000
	buffer_gl0_inv                                             // 0000000FE4A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FE4A8: BE842000
	s_cbranch_execz 124                                        // 0000000FE4AC: BFA5007C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ba0>
	v_mov_b32_e32 v43, v60                                     // 0000000FE4B0: 7E56033C
	v_mov_b32_e32 v44, v0                                      // 0000000FE4B4: 7E580300
	s_or_b32 s10, s7, 56                                       // 0000000FE4B8: 8C0AB807
	s_mov_b32 s11, 0                                           // 0000000FE4BC: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4C0: BF870091
	v_lshrrev_b32_e32 v45, 5, v44                              // 0000000FE4C4: 325A5885
	v_or_b32_e32 v46, s10, v45                                 // 0000000FE4C8: 385C5A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4CC: BF870091
	v_mad_u64_u32 v[46:47], null, v46, 48, s[2:3]              // 0000000FE4D0: D6FE7C2E 0009612E
	.long 0xd73c002e                                           // 0000000FE4D8: D73C002E
	v_cndmask_b32_e32 v1, 9, v46, vcc_lo                       // 0000000FE4DC: 02025C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4E0: BF870091
	.long 0xd700012e                                           // 0000000FE4E4: D700012E
	v_cndmask_b32_e32 v1, v57, v46, vcc_lo                     // 0000000FE4E8: 02025D39
	v_add_co_ci_u32_e64 v47, null, v59, v47, s1                // 0000000FE4EC: D5207C2F 00065F3B
	s_movk_i32 s1, 0xfe00                                      // 0000000FE4F4: B001FE00
	global_load_b32 v47, v[46:47], off                         // 0000000FE4F8: DC520000 2F7C002E
	v_mov_b32_e32 v46, v1                                      // 0000000FE500: 7E5C0301
	v_add_nc_u32_e32 v73, s1, v43                              // 0000000FE504: 4A925601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FE508: BF870002
	v_add_nc_u32_e32 v74, 0x400, v46                           // 0000000FE50C: 4A945CFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FE514: 8101C001
	ds_load_2addr_b32 v[48:49], v46 offset1:33                 // 0000000FE518: D8DC2100 3000002E
	ds_load_2addr_b32 v[61:62], v73 offset0:128 offset1:129    // 0000000FE520: D8DC8180 3D000049
	ds_load_2addr_b32 v[63:64], v46 offset0:66 offset1:99      // 0000000FE528: D8DC6342 3F00002E
	ds_load_2addr_b32 v[65:66], v73 offset0:130 offset1:131    // 0000000FE530: D8DC8382 41000049
	ds_load_2addr_b32 v[67:68], v46 offset0:132 offset1:165    // 0000000FE538: D8DCA584 4300002E
	ds_load_2addr_b32 v[69:70], v73 offset0:132 offset1:133    // 0000000FE540: D8DC8584 45000049
	ds_load_2addr_b32 v[71:72], v73 offset0:134 offset1:135    // 0000000FE548: D8DC8786 47000049
	s_cmp_lg_u32 s1, 0                                         // 0000000FE550: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FE554: BF890057
	v_fma_f32 v47, -v61, v48, v47                              // 0000000FE558: D613002F 24BE613D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE560: BF8700D1
	v_fma_f32 v49, -v62, v49, v47                              // 0000000FE564: D6130031 24BE633E
	ds_load_2addr_b32 v[47:48], v46 offset0:198 offset1:231    // 0000000FE56C: D8DCE7C6 2F00002E
	v_add_nc_u32_e32 v46, 0x840, v46                           // 0000000FE574: 4A5C5CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FE57C: BF89FC47
	v_fma_f32 v49, -v65, v63, v49                              // 0000000FE580: D6130031 24C67F41
	v_fma_f32 v63, -v66, v64, v49                              // 0000000FE588: D613003F 24C68142
	ds_load_2addr_b32 v[49:50], v73 offset0:136 offset1:137    // 0000000FE590: D8DC8988 31000049
	ds_load_2addr_b32 v[61:62], v74 offset0:8 offset1:41       // 0000000FE598: D8DC2908 3D00004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE5A0: BF89FC47
	v_fma_f32 v63, -v69, v67, v63                              // 0000000FE5A4: D613003F 24FE8745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE5AC: BF8700D1
	v_fma_f32 v67, -v70, v68, v63                              // 0000000FE5B0: D6130043 24FE8946
	ds_load_2addr_b32 v[63:64], v73 offset0:138 offset1:139    // 0000000FE5B8: D8DC8B8A 3F000049
	ds_load_2addr_b32 v[65:66], v74 offset0:74 offset1:107     // 0000000FE5C0: D8DC6B4A 4100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE5C8: BF89FC47
	v_fma_f32 v47, -v71, v47, v67                              // 0000000FE5CC: D613002F 250E5F47
	v_fma_f32 v71, -v72, v48, v47                              // 0000000FE5D4: D6130047 24BE6148
	ds_load_2addr_b32 v[47:48], v74 offset0:140 offset1:173    // 0000000FE5DC: D8DCAD8C 2F00004A
	ds_load_2addr_b32 v[67:68], v73 offset0:140 offset1:141    // 0000000FE5E4: D8DC8D8C 43000049
	ds_load_2addr_b32 v[69:70], v73 offset0:142 offset1:143    // 0000000FE5EC: D8DC8F8E 45000049
	s_waitcnt lgkmcnt(5)                                       // 0000000FE5F4: BF89FC57
	v_fma_f32 v49, -v49, v61, v71                              // 0000000FE5F8: D6130031 251E7B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FE600: BF8700C1
	v_fma_f32 v61, -v50, v62, v49                              // 0000000FE604: D613003D 24C67D32
	ds_load_2addr_b32 v[49:50], v74 offset0:206 offset1:239    // 0000000FE60C: D8DCEFCE 3100004A
	s_waitcnt lgkmcnt(4)                                       // 0000000FE614: BF89FC47
	v_fma_f32 v61, -v63, v65, v61                              // 0000000FE618: D613003D 24F6833F
	v_fma_f32 v61, -v64, v66, v61                              // 0000000FE620: D613003D 24F68540
	s_waitcnt lgkmcnt(2)                                       // 0000000FE628: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE62C: BF870091
	v_fma_f32 v47, -v67, v47, v61                              // 0000000FE630: D613002F 24F65F43
	v_fma_f32 v47, -v68, v48, v47                              // 0000000FE638: D613002F 24BE6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FE640: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE644: BF870091
	v_fma_f32 v47, -v69, v49, v47                              // 0000000FE648: D613002F 24BE6345
	v_fma_f32 v47, -v70, v50, v47                              // 0000000FE650: D613002F 24BE6546
	s_cbranch_scc1 65450                                       // 0000000FE658: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a04>
	v_add_nc_u32_e32 v48, 0x80, v44                            // 0000000FE65C: 4A6058FF 00000080
	v_mad_u64_u32 v[45:46], null, 0x84, v45, v[4:5]            // 0000000FE664: D6FE7C2D 04125AFF 00000084
	.long 0xd4490001                                           // 0000000FE670: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v44, vcc_lo                    // 0000000FE674: 020258FF 0000007F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000FE67C: BF870003
	v_dual_mov_b32 v44, v48 :: v_dual_add_nc_u32 v43, 0x810, v43// 0000000FE680: CA200130 2C2A56FF 00000810
	s_or_b32 s11, s1, s11                                      // 0000000FE68C: 8C0B0B01
	ds_store_b32 v45, v47 offset:7392                          // 0000000FE690: D8341CE0 00002F2D
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FE698: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FE69C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FE6A0: 8C7E047E
	v_dual_mov_b32 v44, v26 :: v_dual_mov_b32 v43, v25         // 0000000FE6A4: CA10011A 2C2A0119
	v_dual_mov_b32 v46, v24 :: v_dual_mov_b32 v45, v23         // 0000000FE6AC: CA100118 2E2C0117
	v_mov_b32_e32 v61, v56                                     // 0000000FE6B4: 7E7A0338
	s_waitcnt lgkmcnt(0)                                       // 0000000FE6B8: BF89FC07
	s_barrier                                                  // 0000000FE6BC: BFBD0000
	s_mov_b32 s10, 0                                           // 0000000FE6C0: BE8A0080
	buffer_gl0_inv                                             // 0000000FE6C4: E0AC0000 00000000
	s_branch 21                                                // 0000000FE6CC: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c24>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000FE6D0: 8C7E0B7E
	.long 0xd700012d                                           // 0000000FE6D4: D700012D
	v_cndmask_b32_e32 v1, 0x30000, v45, vcc_lo                 // 0000000FE6D8: 02025AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FE6E0: BF870001
	v_add_co_ci_u32_e64 v46, null, 0, v46, s1                  // 0000000FE6E4: D5207C2E 00065C80
	.long 0xd700012b                                           // 0000000FE6EC: D700012B
	v_cndmask_b32_e32 v1, 0x800, v43, vcc_lo                   // 0000000FE6F0: 020256FF 00000800
	v_add_nc_u32_e32 v61, 8, v61                               // 0000000FE6F8: 4A7A7A88
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FE6FC: D5207C2C 00065880
	s_add_i32 s1, s10, 8                                       // 0000000FE704: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000FE708: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000FE70C: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000FE710: BC7C0000
	s_barrier                                                  // 0000000FE714: BFBD0000
	buffer_gl0_inv                                             // 0000000FE718: E0AC0000 00000000
	s_cbranch_scc1 199                                         // 0000000FE720: BFA200C7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	v_dual_mov_b32 v48, v46 :: v_dual_mov_b32 v47, v45         // 0000000FE724: CA10012E 302E012D
	v_dual_mov_b32 v49, v53 :: v_dual_mov_b32 v50, v51         // 0000000FE72C: CA100135 31320133
	s_mov_b32 s11, 0                                           // 0000000FE734: BE8B0080
	s_nop 0                                                    // 0000000FE738: BF800000
	s_nop 0                                                    // 0000000FE73C: BF800000
	global_load_b32 v62, v[47:48], off                         // 0000000FE740: DC520000 3E7C002F
	v_add_nc_u32_e32 v50, 0x80, v50                            // 0000000FE748: 4A6464FF 00000080
	.long 0xd700012f                                           // 0000000FE750: D700012F
	v_cndmask_b32_e32 v1, 0x6000, v47, vcc_lo                  // 0000000FE754: 02025EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FE75C: BF870191
	v_add_co_ci_u32_e64 v48, null, 0, v48, s1                  // 0000000FE760: D5207C30 00066080
	.long 0xd4490004                                           // 0000000FE768: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v50, vcc_lo                   // 0000000FE76C: 020264FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000000FE774: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000000FE778: BF8903F7
	ds_store_b32 v49, v62 offset:25344                         // 0000000FE77C: D8346300 00003E31
	v_add_nc_u32_e32 v49, 0x204, v49                           // 0000000FE784: 4A6262FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FE78C: 917E0B7E
	s_cbranch_execnz 65515                                     // 0000000FE790: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000FE794: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 0000000FE798: BF89FC07
	s_barrier                                                  // 0000000FE79C: BFBD0000
	buffer_gl0_inv                                             // 0000000FE7A0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000FE7A8: BE8B2000
	s_cbranch_execz 65480                                      // 0000000FE7AC: BFA5FFC8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bd0>
	v_dual_mov_b32 v48, v44 :: v_dual_mov_b32 v47, v43         // 0000000FE7B0: CA10012C 302E012B
	v_dual_mov_b32 v62, v60 :: v_dual_mov_b32 v63, v61         // 0000000FE7B8: CA10013C 3E3E013D
	v_mov_b32_e32 v64, v0                                      // 0000000FE7C0: 7E800300
	s_mov_b32 s12, 0                                           // 0000000FE7C4: BE8C0080
	s_branch 19                                                // 0000000FE7C8: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d18>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000FE7CC: 8C7E0D7E
	v_add_nc_u32_e32 v49, 0x80, v64                            // 0000000FE7D0: 4A6280FF 00000080
	.long 0xd4490001                                           // 0000000FE7D8: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v64, vcc_lo                    // 0000000FE7DC: 020280FF 0000007F
	.long 0xd700042f                                           // 0000000FE7E4: D700042F
	v_cndmask_b32_e32 v1, 0x400, v47, vcc_lo                   // 0000000FE7E8: 02025EFF 00000400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FE7F0: BF8704C3
	v_dual_mov_b32 v64, v49 :: v_dual_add_nc_u32 v63, 4, v63   // 0000000FE7F4: CA200131 403E7E84
	v_add_nc_u32_e32 v62, 0x810, v62                           // 0000000FE7FC: 4A7C7CFF 00000810
	v_add_co_ci_u32_e64 v48, null, 0, v48, s4                  // 0000000FE804: D5207C30 00126080
	s_or_b32 s12, s1, s12                                      // 0000000FE80C: 8C0C0C01
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 0000000FE810: 917E0C7E
	s_cbranch_execz 65454                                      // 0000000FE814: BFA5FFAE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bd0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FE818: BF8700A1
	v_lshrrev_b32_e32 v49, 5, v64                              // 0000000FE81C: 32628085
	s_mov_b32 s13, exec_lo                                     // 0000000FE820: BE8D007E
	v_or_b32_e32 v49, s10, v49                                 // 0000000FE824: 3862620A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE828: BF870091
	v_or_b32_e32 v65, s7, v49                                  // 0000000FE82C: 38826207
	.long 0xd4c4007e                                           // 0000000FE830: D4C4007E
	v_cndmask_b32_e32 v1, s30, v65, vcc_lo                     // 0000000FE834: 0202821E
	s_cbranch_execz 65508                                      // 0000000FE838: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ccc>
	v_mov_b32_e32 v66, 0                                       // 0000000FE83C: 7E840280
	v_mov_b32_e32 v50, v1                                      // 0000000FE840: 7E640301
	s_movk_i32 s1, 0xfe00                                      // 0000000FE844: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FE848: BF870119
	v_add_nc_u32_e32 v81, s1, v62                              // 0000000FE84C: 4AA27C01
	v_add_nc_u32_e32 v82, 0x400, v50                           // 0000000FE850: 4AA464FF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FE858: 8101C001
	ds_load_2addr_b32 v[67:68], v50 offset1:33                 // 0000000FE85C: D8DC2100 43000032
	ds_load_2addr_b32 v[69:70], v81 offset0:128 offset1:129    // 0000000FE864: D8DC8180 45000051
	ds_load_2addr_b32 v[71:72], v50 offset0:66 offset1:99      // 0000000FE86C: D8DC6342 47000032
	ds_load_2addr_b32 v[73:74], v81 offset0:130 offset1:131    // 0000000FE874: D8DC8382 49000051
	ds_load_2addr_b32 v[75:76], v50 offset0:132 offset1:165    // 0000000FE87C: D8DCA584 4B000032
	ds_load_2addr_b32 v[77:78], v81 offset0:132 offset1:133    // 0000000FE884: D8DC8584 4D000051
	ds_load_2addr_b32 v[79:80], v81 offset0:134 offset1:135    // 0000000FE88C: D8DC8786 4F000051
	s_cmp_eq_u32 s1, 0                                         // 0000000FE894: BF068001
	s_waitcnt lgkmcnt(5)                                       // 0000000FE898: BF89FC57
	v_fmac_f32_e32 v66, v69, v67                               // 0000000FE89C: 56848745
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE8A0: BF8700D1
	v_fmac_f32_e32 v66, v70, v68                               // 0000000FE8A4: 56848946
	ds_load_2addr_b32 v[67:68], v50 offset0:198 offset1:231    // 0000000FE8A8: D8DCE7C6 43000032
	v_add_nc_u32_e32 v50, 0x840, v50                           // 0000000FE8B0: 4A6464FF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FE8B8: BF89FC47
	v_fmac_f32_e32 v66, v73, v71                               // 0000000FE8BC: 56848F49
	v_fmac_f32_e32 v66, v74, v72                               // 0000000FE8C0: 5684914A
	ds_load_2addr_b32 v[69:70], v81 offset0:136 offset1:137    // 0000000FE8C4: D8DC8988 45000051
	ds_load_2addr_b32 v[71:72], v82 offset0:8 offset1:41       // 0000000FE8CC: D8DC2908 47000052
	s_waitcnt lgkmcnt(4)                                       // 0000000FE8D4: BF89FC47
	v_fmac_f32_e32 v66, v77, v75                               // 0000000FE8D8: 5684974D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FE8DC: BF8700D1
	v_fmac_f32_e32 v66, v78, v76                               // 0000000FE8E0: 5684994E
	ds_load_2addr_b32 v[73:74], v81 offset0:138 offset1:139    // 0000000FE8E4: D8DC8B8A 49000051
	ds_load_2addr_b32 v[75:76], v82 offset0:74 offset1:107     // 0000000FE8EC: D8DC6B4A 4B000052
	s_waitcnt lgkmcnt(4)                                       // 0000000FE8F4: BF89FC47
	v_fmac_f32_e32 v66, v79, v67                               // 0000000FE8F8: 5684874F
	v_fmac_f32_e32 v66, v80, v68                               // 0000000FE8FC: 56848950
	ds_load_2addr_b32 v[67:68], v82 offset0:140 offset1:173    // 0000000FE900: D8DCAD8C 43000052
	ds_load_2addr_b32 v[77:78], v81 offset0:140 offset1:141    // 0000000FE908: D8DC8D8C 4D000051
	ds_load_2addr_b32 v[79:80], v81 offset0:142 offset1:143    // 0000000FE910: D8DC8F8E 4F000051
	s_waitcnt lgkmcnt(5)                                       // 0000000FE918: BF89FC57
	v_fmac_f32_e32 v66, v69, v71                               // 0000000FE91C: 56848F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FE920: BF8700C1
	v_fmac_f32_e32 v66, v70, v72                               // 0000000FE924: 56849146
	ds_load_2addr_b32 v[69:70], v82 offset0:206 offset1:239    // 0000000FE928: D8DCEFCE 45000052
	s_waitcnt lgkmcnt(4)                                       // 0000000FE930: BF89FC47
	v_fmac_f32_e32 v66, v73, v75                               // 0000000FE934: 56849749
	v_fmac_f32_e32 v66, v74, v76                               // 0000000FE938: 5684994A
	s_waitcnt lgkmcnt(2)                                       // 0000000FE93C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE940: BF870091
	v_fmac_f32_e32 v66, v77, v67                               // 0000000FE944: 5684874D
	v_fmac_f32_e32 v66, v78, v68                               // 0000000FE948: 5684894E
	s_waitcnt lgkmcnt(0)                                       // 0000000FE94C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE950: BF870091
	v_fmac_f32_e32 v66, v79, v69                               // 0000000FE954: 56848B4F
	v_fmac_f32_e32 v66, v80, v70                               // 0000000FE958: 56848D50
	s_cbranch_scc0 65466                                       // 0000000FE95C: BFA1FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d48>
	v_lshlrev_b32_e32 v49, 2, v49                              // 0000000FE960: 30626282
	s_mov_b32 s14, 0                                           // 0000000FE964: BE8E0080
	ds_load_b32 v68, v49 offset:29728                          // 0000000FE968: D8D87420 44000031
	v_dual_mov_b32 v50, v48 :: v_dual_mov_b32 v67, v1          // 0000000FE970: CA100130 32420101
	s_waitcnt lgkmcnt(0)                                       // 0000000FE978: BF89FC07
	v_dual_mov_b32 v49, v47 :: v_dual_mul_f32 v66, v66, v68    // 0000000FE97C: CA06012F 31428942
	v_mov_b32_e32 v68, v63                                     // 0000000FE984: 7E88033F
	s_nop 0                                                    // 0000000FE988: BF800000
	s_nop 0                                                    // 0000000FE98C: BF800000
	s_nop 0                                                    // 0000000FE990: BF800000
	s_nop 0                                                    // 0000000FE994: BF800000
	s_nop 0                                                    // 0000000FE998: BF800000
	s_nop 0                                                    // 0000000FE99C: BF800000
	s_nop 0                                                    // 0000000FE9A0: BF800000
	s_nop 0                                                    // 0000000FE9A4: BF800000
	s_nop 0                                                    // 0000000FE9A8: BF800000
	s_nop 0                                                    // 0000000FE9AC: BF800000
	s_nop 0                                                    // 0000000FE9B0: BF800000
	s_nop 0                                                    // 0000000FE9B4: BF800000
	s_nop 0                                                    // 0000000FE9B8: BF800000
	s_nop 0                                                    // 0000000FE9BC: BF800000
	global_load_b32 v69, v[49:50], off                         // 0000000FE9C0: DC520000 457C0031
	ds_load_b32 v70, v67 offset:16896                          // 0000000FE9C8: D8D84200 46000043
	v_add_nc_u32_e32 v68, -1, v68                              // 0000000FE9D0: 4A8888C1
	.long 0xd7000131                                           // 0000000FE9D4: D7000131
	v_cndmask_b32_e32 v0, v49, v132, vcc_lo                    // 0000000FE9D8: 02010931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FE9DC: BF870191
	v_add_co_ci_u32_e64 v50, null, 0, v50, s1                  // 0000000FE9E0: D5207C32 00066480
	.long 0xd44a0004                                           // 0000000FE9E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v68, vcc_lo                       // 0000000FE9EC: 02028880
	v_add_nc_u32_e32 v67, 0x84, v67                            // 0000000FE9F0: 4A8686FF 00000084
	s_or_b32 s14, s4, s14                                      // 0000000FE9F8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FE9FC: BF890007
	v_fmac_f32_e32 v66, v69, v70                               // 0000000FEA00: 56848D45
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000FEA04: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000FEA08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000FEA0C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEA10: BF870121
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FEA14: D6100043 02052142
	v_mad_u64_u32 v[49:50], null, 0x3000, v65, v[5:6]          // 0000000FEA1C: D6FE7C31 041682FF 00003000
	v_add3_u32 v65, v66, v67, 0x7fff                           // 0000000FEA28: D6550041 03FE8742 00007FFF
	global_store_d16_hi_b16 v[49:50], v65, off                 // 0000000FEA34: DC960000 007C4131
	s_branch 65379                                             // 0000000FEA3C: BFA0FF63 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ccc>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 0000000FEA40: A201FF06 3FB8AA3B
	v_mov_b32_e32 v45, v51                                     // 0000000FEA48: 7E5A0333
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FEA4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000FEA50: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 0000000FEA58: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 0000000FEA5C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 0000000FEA64: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 0000000FEA6C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000FEA70: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 0000000FEA74: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000FEA7C: A0010401
	s_mov_b32 s4, 0                                            // 0000000FEA80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000FEA84: BF87000A
	v_exp_f32_e32 v43, s1                                      // 0000000FEA88: 7E564A01
	s_cvt_i32_f32 s1, s7                                       // 0000000FEA8C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000FEA90: BF870585
	.long 0xd71c002b                                           // 0000000FEA94: D71C002B
	v_cndmask_b32_e32 v0, v43, v1, vcc_lo                      // 0000000FEA98: 0200032B
	s_cselect_b32 s1, -1, 0                                    // 0000000FEA9C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000000FEAA0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000FEAA8: BF870131
	v_cndmask_b32_e64 v44, 0, v43, s1                          // 0000000FEAAC: D501002C 00065680
	s_cselect_b32 s1, -1, 0                                    // 0000000FEAB4: 980180C1
	v_mov_b32_e32 v43, v58                                     // 0000000FEAB8: 7E56033A
	v_cndmask_b32_e64 v44, 0x7f800000, v44, s1                 // 0000000FEABC: D501002C 000658FF 7F800000
	ds_load_b32 v46, v43                                       // 0000000FEAC8: D8D80000 2E00002B
	s_waitcnt lgkmcnt(0)                                       // 0000000FEAD0: BF89FC07
	v_dual_mul_f32 v46, v44, v46 :: v_dual_add_nc_u32 v45, 0x80, v45// 0000000FEAD4: C8E05D2C 2E2C5AFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FEAE0: BF8704C1
	.long 0xd4490001                                           // 0000000FEAE4: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v45, vcc_lo                   // 0000000FEAE8: 02025AFF 00000F7F
	ds_store_b32 v43, v46                                      // 0000000FEAF0: D8340000 00002E2B
	v_add_nc_u32_e32 v43, 0x210, v43                           // 0000000FEAF8: 4A5656FF 00000210
	s_or_b32 s4, s1, s4                                        // 0000000FEB00: 8C040401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FEB04: 917E047E
	s_cbranch_execnz 65519                                     // 0000000FEB08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FEB0C: 8C7E047E
	v_dual_mov_b32 v44, v28 :: v_dual_mov_b32 v43, v27         // 0000000FEB10: CA10011C 2C2A011B
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, v53           // 0000000FEB18: CA100080 2D2E0135
	v_mov_b32_e32 v47, v51                                     // 0000000FEB20: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FEB24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FEB28: BF89FC07
	s_barrier                                                  // 0000000FEB2C: BFBD0000
	buffer_gl0_inv                                             // 0000000FEB30: E0AC0000 00000000
	s_nop 0                                                    // 0000000FEB38: BF800000
	s_nop 0                                                    // 0000000FEB3C: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FEB40: DC520000 307C002B
	ds_load_b32 v49, v45 offset:29472                          // 0000000FEB48: D8D87320 3100002D
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FEB50: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FEB58: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FEB5C: 020256FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 0000000FEB64: 4A5A5A84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FEB68: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FEB70: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FEB74: 10606330
	.long 0xd4490004                                           // 0000000FEB78: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FEB7C: 02025EFF 0000037F
	ds_store_b32 v46, v48 offset:25344                         // 0000000FEB84: D8346300 0000302E
	v_add_nc_u32_e32 v46, 0x204, v46                           // 0000000FEB8C: 4A5C5CFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FEB94: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FEB98: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FEB9C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FEBA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FEBA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000FEBA8: BF89FC07
	s_barrier                                                  // 0000000FEBAC: BFBD0000
	buffer_gl0_inv                                             // 0000000FEBB0: E0AC0000 00000000
	ds_load_2addr_b32 v[43:44], v4 offset1:33                  // 0000000FEBB8: D8DC2100 2B000004
	ds_load_2addr_b32 v[45:46], v4 offset0:66 offset1:99       // 0000000FEBC0: D8DC6342 2D000004
	ds_load_2addr_b32 v[47:48], v4 offset0:132 offset1:165     // 0000000FEBC8: D8DCA584 2F000004
	ds_load_2addr_b32 v[49:50], v4 offset0:198 offset1:231     // 0000000FEBD0: D8DCE7C6 31000004
	v_mov_b32_e32 v61, v0                                      // 0000000FEBD8: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000FEBDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FEBE0: BF840001
	s_nop 0                                                    // 0000000FEBE4: BF800000
	s_nop 0                                                    // 0000000FEBE8: BF800000
	s_nop 0                                                    // 0000000FEBEC: BF800000
	s_nop 0                                                    // 0000000FEBF0: BF800000
	s_nop 0                                                    // 0000000FEBF4: BF800000
	s_nop 0                                                    // 0000000FEBF8: BF800000
	s_nop 0                                                    // 0000000FEBFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEC00: BF870121
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FEC04: 327C7A85
	.long 0xd4490001                                           // 0000000FEC08: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FEC0C: 02027AFF 00000F7F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FEC14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FEC18: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FEC24: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FEC28: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FEC30: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FEC38: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FEC40: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FEC44: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FEC50: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FEC54: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FEC60: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FEC68: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FEC70: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FEC74: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FEC78: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FEC84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FEC88: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FEC8C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FEC90: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FEC98: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FEC9C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FECA0: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FECA4: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FECA8: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FECB4: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FECB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FECC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FECC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_set_inst_prefetch_distance 0x2                           // 0000000FECC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FECCC: 8C7E047E
	v_dual_mov_b32 v44, v30 :: v_dual_mov_b32 v43, v29         // 0000000FECD0: CA10011E 2C2A011D
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FECD8: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FECE0: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FECE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FECE8: BF89FC07
	s_barrier                                                  // 0000000FECEC: BFBD0000
	buffer_gl0_inv                                             // 0000000FECF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FECF8: BF800000
	s_nop 0                                                    // 0000000FECFC: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FED00: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29504                          // 0000000FED08: D8D87340 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FED10: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FED18: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FED1C: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FED24: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FED28: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FED30: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FED34: 10606330
	.long 0xd4490004                                           // 0000000FED38: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FED3C: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FED44: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FED4C: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FED54: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FED58: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FED5C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FED60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FED64: 8C7E067E
	v_add_nc_u32_e32 v49, 0x400, v4                            // 0000000FED68: 4A6208FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000FED70: BF89FC07
	s_barrier                                                  // 0000000FED74: BFBD0000
	buffer_gl0_inv                                             // 0000000FED78: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000FED80: 7E7A0300
	ds_load_2addr_b32 v[43:44], v49 offset0:8 offset1:41       // 0000000FED84: D8DC2908 2B000031
	ds_load_2addr_b32 v[45:46], v49 offset0:74 offset1:107     // 0000000FED8C: D8DC6B4A 2D000031
	ds_load_2addr_b32 v[47:48], v49 offset0:140 offset1:173    // 0000000FED94: D8DCAD8C 2F000031
	ds_load_2addr_b32 v[49:50], v49 offset0:206 offset1:239    // 0000000FED9C: D8DCEFCE 31000031
	s_mov_b32 s4, 0                                            // 0000000FEDA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FEDA8: BF840001
	s_nop 0                                                    // 0000000FEDAC: BF800000
	s_nop 0                                                    // 0000000FEDB0: BF800000
	s_nop 0                                                    // 0000000FEDB4: BF800000
	s_nop 0                                                    // 0000000FEDB8: BF800000
	s_nop 0                                                    // 0000000FEDBC: BF800000
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FEDC0: 327C7A85
	.long 0xd4490001                                           // 0000000FEDC4: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FEDC8: 02027AFF 00000F7F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FEDD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FEDD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FEDD8: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FEDE4: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FEDE8: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FEDF0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FEDF8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FEE00: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FEE04: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FEE10: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FEE14: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FEE20: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FEE28: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FEE30: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FEE34: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FEE38: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FEE44: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FEE48: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FEE4C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FEE50: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FEE58: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FEE5C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FEE60: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEE64: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FEE68: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FEE74: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FEE78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FEE80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FEE84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000FEE88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FEE8C: 8C7E047E
	v_dual_mov_b32 v44, v32 :: v_dual_mov_b32 v43, v31         // 0000000FEE90: CA100120 2C2A011F
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FEE98: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FEEA0: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FEEA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FEEA8: BF89FC07
	s_barrier                                                  // 0000000FEEAC: BFBD0000
	buffer_gl0_inv                                             // 0000000FEEB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FEEB8: BF800000
	s_nop 0                                                    // 0000000FEEBC: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FEEC0: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29536                          // 0000000FEEC8: D8D87360 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FEED0: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FEED8: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FEEDC: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FEEE4: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FEEE8: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FEEF0: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FEEF4: 10606330
	.long 0xd4490004                                           // 0000000FEEF8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FEEFC: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FEF04: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FEF0C: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FEF14: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FEF18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FEF1C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FEF20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FEF24: 8C7E067E
	v_add_nc_u32_e32 v49, 0x800, v4                            // 0000000FEF28: 4A6208FF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000FEF30: BF89FC07
	s_barrier                                                  // 0000000FEF34: BFBD0000
	buffer_gl0_inv                                             // 0000000FEF38: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000FEF40: 7E7A0300
	ds_load_2addr_b32 v[43:44], v49 offset0:16 offset1:49      // 0000000FEF44: D8DC3110 2B000031
	ds_load_2addr_b32 v[45:46], v49 offset0:82 offset1:115     // 0000000FEF4C: D8DC7352 2D000031
	ds_load_2addr_b32 v[47:48], v49 offset0:148 offset1:181    // 0000000FEF54: D8DCB594 2F000031
	ds_load_2addr_b32 v[49:50], v49 offset0:214 offset1:247    // 0000000FEF5C: D8DCF7D6 31000031
	s_mov_b32 s4, 0                                            // 0000000FEF64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FEF68: BF840001
	s_nop 0                                                    // 0000000FEF6C: BF800000
	s_nop 0                                                    // 0000000FEF70: BF800000
	s_nop 0                                                    // 0000000FEF74: BF800000
	s_nop 0                                                    // 0000000FEF78: BF800000
	s_nop 0                                                    // 0000000FEF7C: BF800000
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FEF80: 327C7A85
	.long 0xd4490001                                           // 0000000FEF84: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FEF88: 02027AFF 00000F7F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FEF90: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FEF94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FEF98: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FEFA4: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FEFA8: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FEFB0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FEFB8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FEFC0: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FEFC4: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FEFD0: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FEFD4: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FEFE0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FEFE8: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FEFF0: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FEFF4: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FEFF8: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF004: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF008: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF00C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF010: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF018: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF01C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF020: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF024: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF028: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF034: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF038: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF040: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF044: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF048: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF04C: 8C7E047E
	v_dual_mov_b32 v44, v34 :: v_dual_mov_b32 v43, v33         // 0000000FF050: CA100122 2C2A0121
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FF058: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FF060: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FF064: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FF068: BF89FC07
	s_barrier                                                  // 0000000FF06C: BFBD0000
	buffer_gl0_inv                                             // 0000000FF070: E0AC0000 00000000
	s_nop 0                                                    // 0000000FF078: BF800000
	s_nop 0                                                    // 0000000FF07C: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FF080: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29568                          // 0000000FF088: D8D87380 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FF090: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FF098: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FF09C: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FF0A4: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FF0A8: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FF0B0: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FF0B4: 10606330
	.long 0xd4490004                                           // 0000000FF0B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FF0BC: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FF0C4: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FF0CC: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FF0D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FF0D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FF0DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FF0E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2580>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FF0E4: 8C7E067E
	v_add_nc_u32_e32 v49, 0xc00, v4                            // 0000000FF0E8: 4A6208FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF0F0: BF89FC07
	s_barrier                                                  // 0000000FF0F4: BFBD0000
	buffer_gl0_inv                                             // 0000000FF0F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000FF100: 7E7A0300
	ds_load_2addr_b32 v[43:44], v49 offset0:24 offset1:57      // 0000000FF104: D8DC3918 2B000031
	ds_load_2addr_b32 v[45:46], v49 offset0:90 offset1:123     // 0000000FF10C: D8DC7B5A 2D000031
	ds_load_2addr_b32 v[47:48], v49 offset0:156 offset1:189    // 0000000FF114: D8DCBD9C 2F000031
	ds_load_2addr_b32 v[49:50], v49 offset0:222 offset1:255    // 0000000FF11C: D8DCFFDE 31000031
	s_mov_b32 s4, 0                                            // 0000000FF124: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FF128: BF840001
	s_nop 0                                                    // 0000000FF12C: BF800000
	s_nop 0                                                    // 0000000FF130: BF800000
	s_nop 0                                                    // 0000000FF134: BF800000
	s_nop 0                                                    // 0000000FF138: BF800000
	s_nop 0                                                    // 0000000FF13C: BF800000
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FF140: 327C7A85
	.long 0xd4490001                                           // 0000000FF144: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FF148: 02027AFF 00000F7F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FF150: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FF154: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FF158: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FF164: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FF168: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FF170: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FF178: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FF180: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FF184: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FF190: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FF194: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FF1A0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FF1A8: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FF1B0: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FF1B4: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FF1B8: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF1C4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF1C8: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF1CC: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF1D0: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF1D8: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF1DC: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF1E0: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF1E4: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF1E8: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF1F4: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF1F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF200: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF204: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2640>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF208: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF20C: 8C7E047E
	v_dual_mov_b32 v44, v36 :: v_dual_mov_b32 v43, v35         // 0000000FF210: CA100124 2C2A0123
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FF218: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FF220: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FF224: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FF228: BF89FC07
	s_barrier                                                  // 0000000FF22C: BFBD0000
	buffer_gl0_inv                                             // 0000000FF230: E0AC0000 00000000
	s_nop 0                                                    // 0000000FF238: BF800000
	s_nop 0                                                    // 0000000FF23C: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FF240: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29600                          // 0000000FF248: D8D873A0 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FF250: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FF258: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FF25C: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FF264: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FF268: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FF270: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FF274: 10606330
	.long 0xd4490004                                           // 0000000FF278: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FF27C: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FF284: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FF28C: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FF294: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FF298: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FF29C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FF2A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2740>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FF2A4: 8C7E067E
	v_add_nc_u32_e32 v47, 0x1000, v4                           // 0000000FF2A8: 4A5E08FF 00001000
	v_add_nc_u32_e32 v49, 0x1200, v4                           // 0000000FF2B0: 4A6208FF 00001200
	s_waitcnt lgkmcnt(0)                                       // 0000000FF2B8: BF89FC07
	s_barrier                                                  // 0000000FF2BC: BFBD0000
	buffer_gl0_inv                                             // 0000000FF2C0: E0AC0000 00000000
	ds_load_2addr_b32 v[43:44], v47 offset0:32 offset1:65      // 0000000FF2C8: D8DC4120 2B00002F
	ds_load_2addr_b32 v[45:46], v47 offset0:98 offset1:131     // 0000000FF2D0: D8DC8362 2D00002F
	ds_load_2addr_b32 v[47:48], v47 offset0:164 offset1:197    // 0000000FF2D8: D8DCC5A4 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset0:102 offset1:135    // 0000000FF2E0: D8DC8766 31000031
	v_mov_b32_e32 v61, v0                                      // 0000000FF2E8: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000FF2EC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FF2F0: BF840001
	s_nop 0                                                    // 0000000FF2F4: BF800000
	s_nop 0                                                    // 0000000FF2F8: BF800000
	s_nop 0                                                    // 0000000FF2FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF300: BF870121
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FF304: 327C7A85
	.long 0xd4490001                                           // 0000000FF308: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FF30C: 02027AFF 00000F7F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FF314: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FF318: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FF324: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FF328: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FF330: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FF338: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FF340: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FF344: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FF350: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FF354: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FF360: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FF368: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FF370: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FF374: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FF378: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF384: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF388: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF38C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF390: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF398: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF39C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF3A0: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF3A4: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF3A8: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF3B4: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF3B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF3C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF3C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2800>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF3C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF3CC: 8C7E047E
	v_dual_mov_b32 v44, v38 :: v_dual_mov_b32 v43, v37         // 0000000FF3D0: CA100126 2C2A0125
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FF3D8: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FF3E0: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FF3E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FF3E8: BF89FC07
	s_barrier                                                  // 0000000FF3EC: BFBD0000
	buffer_gl0_inv                                             // 0000000FF3F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FF3F8: BF800000
	s_nop 0                                                    // 0000000FF3FC: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FF400: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29632                          // 0000000FF408: D8D873C0 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FF410: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FF418: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FF41C: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FF424: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FF428: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FF430: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FF434: 10606330
	.long 0xd4490004                                           // 0000000FF438: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FF43C: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FF444: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FF44C: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FF454: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FF458: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FF45C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FF460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2900>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FF464: 8C7E067E
	v_add_nc_u32_e32 v47, 0x1400, v4                           // 0000000FF468: 4A5E08FF 00001400
	v_add_nc_u32_e32 v49, 0x1600, v4                           // 0000000FF470: 4A6208FF 00001600
	s_waitcnt lgkmcnt(0)                                       // 0000000FF478: BF89FC07
	s_barrier                                                  // 0000000FF47C: BFBD0000
	buffer_gl0_inv                                             // 0000000FF480: E0AC0000 00000000
	ds_load_2addr_b32 v[43:44], v47 offset0:40 offset1:73      // 0000000FF488: D8DC4928 2B00002F
	ds_load_2addr_b32 v[45:46], v47 offset0:106 offset1:139    // 0000000FF490: D8DC8B6A 2D00002F
	ds_load_2addr_b32 v[47:48], v47 offset0:172 offset1:205    // 0000000FF498: D8DCCDAC 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset0:110 offset1:143    // 0000000FF4A0: D8DC8F6E 31000031
	v_mov_b32_e32 v61, v0                                      // 0000000FF4A8: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000FF4AC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FF4B0: BF840001
	s_nop 0                                                    // 0000000FF4B4: BF800000
	s_nop 0                                                    // 0000000FF4B8: BF800000
	s_nop 0                                                    // 0000000FF4BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF4C0: BF870121
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FF4C4: 327C7A85
	.long 0xd4490001                                           // 0000000FF4C8: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FF4CC: 02027AFF 00000F7F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FF4D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FF4D8: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FF4E4: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FF4E8: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FF4F0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FF4F8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FF500: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FF504: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FF510: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FF514: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FF520: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FF528: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FF530: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FF534: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FF538: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF544: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF548: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF54C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF550: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF558: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF55C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF560: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF564: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF568: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF574: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF578: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF580: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF584: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF588: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF58C: 8C7E047E
	v_dual_mov_b32 v44, v40 :: v_dual_mov_b32 v43, v39         // 0000000FF590: CA100128 2C2A0127
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FF598: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FF5A0: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FF5A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FF5A8: BF89FC07
	s_barrier                                                  // 0000000FF5AC: BFBD0000
	buffer_gl0_inv                                             // 0000000FF5B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000FF5B8: BF800000
	s_nop 0                                                    // 0000000FF5BC: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FF5C0: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29664                          // 0000000FF5C8: D8D873E0 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FF5D0: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FF5D8: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FF5DC: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FF5E4: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FF5E8: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FF5F0: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FF5F4: 10606330
	.long 0xd4490004                                           // 0000000FF5F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FF5FC: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FF604: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FF60C: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FF614: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FF618: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FF61C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FF620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FF624: 8C7E067E
	v_add_nc_u32_e32 v47, 0x1800, v4                           // 0000000FF628: 4A5E08FF 00001800
	v_add_nc_u32_e32 v49, 0x1a00, v4                           // 0000000FF630: 4A6208FF 00001A00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF638: BF89FC07
	s_barrier                                                  // 0000000FF63C: BFBD0000
	buffer_gl0_inv                                             // 0000000FF640: E0AC0000 00000000
	ds_load_2addr_b32 v[43:44], v47 offset0:48 offset1:81      // 0000000FF648: D8DC5130 2B00002F
	ds_load_2addr_b32 v[45:46], v47 offset0:114 offset1:147    // 0000000FF650: D8DC9372 2D00002F
	ds_load_2addr_b32 v[47:48], v47 offset0:180 offset1:213    // 0000000FF658: D8DCD5B4 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset0:118 offset1:151    // 0000000FF660: D8DC9776 31000031
	v_mov_b32_e32 v61, v0                                      // 0000000FF668: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000FF66C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FF670: BF840001
	s_nop 0                                                    // 0000000FF674: BF800000
	s_nop 0                                                    // 0000000FF678: BF800000
	s_nop 0                                                    // 0000000FF67C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF680: BF870121
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FF684: 327C7A85
	.long 0xd4490001                                           // 0000000FF688: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FF68C: 02027AFF 00000F7F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FF694: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FF698: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FF6A4: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FF6A8: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FF6B0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FF6B8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FF6C0: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FF6C4: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FF6D0: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FF6D4: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FF6E0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FF6E8: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FF6F0: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FF6F4: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FF6F8: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF704: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF708: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF70C: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF710: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF718: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF71C: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF720: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF724: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF728: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF734: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF738: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF740: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF744: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b80>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF748: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF74C: 8C7E047E
	v_dual_mov_b32 v44, v42 :: v_dual_mov_b32 v43, v41         // 0000000FF750: CA10012A 2C2A0129
	v_dual_mov_b32 v45, v53 :: v_dual_mov_b32 v46, 0           // 0000000FF758: CA100135 2D2E0080
	v_mov_b32_e32 v47, v51                                     // 0000000FF760: 7E5E0333
	s_mov_b32 s6, 0                                            // 0000000FF764: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000FF768: BF89FC07
	s_barrier                                                  // 0000000FF76C: BFBD0000
	buffer_gl0_inv                                             // 0000000FF770: E0AC0000 00000000
	s_nop 0                                                    // 0000000FF778: BF800000
	s_nop 0                                                    // 0000000FF77C: BF800000
	global_load_b32 v48, v[43:44], off                         // 0000000FF780: DC520000 307C002B
	ds_load_b32 v49, v46 offset:29696                          // 0000000FF788: D8D87400 3100002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 0000000FF790: 4A5E5EFF 00000080
	.long 0xd700012b                                           // 0000000FF798: D700012B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 0000000FF79C: 020256FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 0000000FF7A4: 4A5C5C84
	v_add_co_ci_u32_e64 v44, null, 0, v44, s1                  // 0000000FF7A8: D5207C2C 00065880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FF7B0: BF890007
	v_mul_f32_e32 v48, v48, v49                                // 0000000FF7B4: 10606330
	.long 0xd4490004                                           // 0000000FF7B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 0000000FF7BC: 02025EFF 0000037F
	ds_store_b32 v45, v48 offset:25344                         // 0000000FF7C4: D8346300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000000FF7CC: 4A5A5AFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000000FF7D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FF7D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000FF7DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000FF7E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000FF7E4: 8C7E067E
	v_add_nc_u32_e32 v47, 0x1c00, v4                           // 0000000FF7E8: 4A5E08FF 00001C00
	v_add_nc_u32_e32 v49, 0x1e00, v4                           // 0000000FF7F0: 4A6208FF 00001E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF7F8: BF89FC07
	s_barrier                                                  // 0000000FF7FC: BFBD0000
	buffer_gl0_inv                                             // 0000000FF800: E0AC0000 00000000
	ds_load_2addr_b32 v[43:44], v47 offset0:56 offset1:89      // 0000000FF808: D8DC5938 2B00002F
	ds_load_2addr_b32 v[45:46], v47 offset0:122 offset1:155    // 0000000FF810: D8DC9B7A 2D00002F
	ds_load_2addr_b32 v[47:48], v47 offset0:188 offset1:221    // 0000000FF818: D8DCDDBC 2F00002F
	ds_load_2addr_b32 v[49:50], v49 offset0:126 offset1:159    // 0000000FF820: D8DC9F7E 31000031
	v_mov_b32_e32 v61, v0                                      // 0000000FF828: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000FF82C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000FF830: BF840001
	s_nop 0                                                    // 0000000FF834: BF800000
	s_nop 0                                                    // 0000000FF838: BF800000
	s_nop 0                                                    // 0000000FF83C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF840: BF870121
	v_lshrrev_b32_e32 v62, 5, v61                              // 0000000FF844: 327C7A85
	.long 0xd4490001                                           // 0000000FF848: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v61, vcc_lo                   // 0000000FF84C: 02027AFF 00000F7F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000FF854: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x84, v62, v[1:2]            // 0000000FF858: D6FE7C3E 04067CFF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FF864: 8C040401
	v_add_nc_u32_e32 v63, 0x6200, v69                          // 0000000FF868: 4A7E8AFF 00006200
	ds_load_b32 v70, v62                                       // 0000000FF870: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000FF878: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FF880: BF89FC07
	v_dual_fmac_f32 v70, v63, v43 :: v_dual_add_nc_u32 v65, 0x6600, v69// 0000000FF884: C820573F 46408AFF 00006600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FF890: BF8700D1
	v_dual_fmac_f32 v70, v64, v44 :: v_dual_add_nc_u32 v67, 0x6a00, v69// 0000000FF894: C8205940 46428AFF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000FF8A0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000FF8A8: D8DCC544 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000FF8B0: BF89FC17
	v_fmac_f32_e32 v70, v65, v45                               // 0000000FF8B4: 568C5B41
	v_dual_fmac_f32 v70, v66, v46 :: v_dual_add_nc_u32 v63, 0x6e00, v69// 0000000FF8B8: C8205D42 463E8AFF 00006E00
	s_waitcnt lgkmcnt(0)                                       // 0000000FF8C4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FF8C8: BF8700C1
	v_fmac_f32_e32 v70, v67, v47                               // 0000000FF8CC: 568C5F43
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000FF8D0: D8DCC746 3F00003F
	v_fmac_f32_e32 v70, v68, v48                               // 0000000FF8D8: 568C6144
	s_waitcnt lgkmcnt(0)                                       // 0000000FF8DC: BF89FC07
	v_fmac_f32_e32 v70, v63, v49                               // 0000000FF8E0: 568C633F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8E4: BF870091
	v_dual_fmac_f32 v70, v64, v50 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000FF8E8: C8206540 463E7AFF 00000080
	v_mov_b32_e32 v61, v63                                     // 0000000FF8F4: 7E7A033F
	ds_store_b32 v62, v70                                      // 0000000FF8F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FF900: 917E047E
	s_cbranch_execnz 65486                                     // 0000000FF904: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d40>
	s_set_inst_prefetch_distance 0x2                           // 0000000FF908: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FF90C: 8C7E047E
	.long 0xd7000107                                           // 0000000FF910: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000FF914: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF91C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000FF920: D5207C08 00061080
	.long 0xd7000109                                           // 0000000FF928: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000FF92C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000FF934: D5207C0A 00061480
	.long 0xd700010b                                           // 0000000FF93C: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000FF940: 020216FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF948: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000FF94C: D5207C0C 00061880
	.long 0xd700010d                                           // 0000000FF954: D700010D
	v_cndmask_b32_e32 v1, 0x180000, v13, vcc_lo                // 0000000FF958: 02021AFF 00180000
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000FF960: D5207C0E 00061C80
	.long 0xd700010f                                           // 0000000FF968: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000FF96C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF974: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000FF978: D5207C10 00062080
	.long 0xd7000111                                           // 0000000FF980: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000FF984: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000FF98C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000FF994: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000FF998: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF9A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000FF9A4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000FF9AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000FF9B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000FF9B8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000FF9C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000FF9C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF9CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000FF9D0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000FF9D8: D7000119
	v_cndmask_b32_e32 v1, 0xc0000, v25, vcc_lo                 // 0000000FF9DC: 020232FF 000C0000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000FF9E4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000FF9EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000FF9F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF9F8: BF8700A1
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000FF9FC: D5207C1C 00063880
	.long 0xd700011d                                           // 0000000FFA04: D700011D
	v_cndmask_b32_e32 v1, 0x180000, v29, vcc_lo                // 0000000FFA08: 02023AFF 00180000
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000FFA10: D5207C1E 00063C80
	.long 0xd700011f                                           // 0000000FFA18: D700011F
	v_cndmask_b32_e32 v1, 0x180000, v31, vcc_lo                // 0000000FFA1C: 02023EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FFA24: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000FFA28: D5207C20 00064080
	.long 0xd7000121                                           // 0000000FFA30: D7000121
	v_cndmask_b32_e32 v1, 0x180000, v33, vcc_lo                // 0000000FFA34: 020242FF 00180000
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000FFA3C: D5207C22 00064480
	.long 0xd7000123                                           // 0000000FFA44: D7000123
	v_cndmask_b32_e32 v1, 0x180000, v35, vcc_lo                // 0000000FFA48: 020246FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FFA50: BF8700A1
	v_add_co_ci_u32_e64 v36, null, 0, v36, s1                  // 0000000FFA54: D5207C24 00064880
	.long 0xd7000125                                           // 0000000FFA5C: D7000125
	v_cndmask_b32_e32 v1, 0x180000, v37, vcc_lo                // 0000000FFA60: 02024AFF 00180000
	v_add_co_ci_u32_e64 v38, null, 0, v38, s1                  // 0000000FFA68: D5207C26 00064C80
	.long 0xd7000127                                           // 0000000FFA70: D7000127
	v_cndmask_b32_e32 v1, 0x180000, v39, vcc_lo                // 0000000FFA74: 02024EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FFA7C: BF8700A1
	v_add_co_ci_u32_e64 v40, null, 0, v40, s1                  // 0000000FFA80: D5207C28 00065080
	.long 0xd7000129                                           // 0000000FFA88: D7000129
	v_cndmask_b32_e32 v1, 0x180000, v41, vcc_lo                // 0000000FFA8C: 020252FF 00180000
	v_add_co_ci_u32_e64 v42, null, 0, v42, s1                  // 0000000FFA94: D5207C2A 00065480
	s_add_i32 s5, s5, 1                                        // 0000000FFA9C: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000FFAA0: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000FFAA4: BF062105
	s_barrier                                                  // 0000000FFAA8: BFBD0000
	buffer_gl0_inv                                             // 0000000FFAAC: E0AC0000 00000000
	s_cbranch_scc0 62755                                       // 0000000FFAB4: BFA1F523 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x444>
	v_mov_b32_e32 v5, v51                                      // 0000000FFAB8: 7E0A0333
	s_add_u32 s0, s28, s20                                     // 0000000FFABC: 8000141C
	.long 0xd73c0000                                           // 0000000FFAC0: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000FFAC4: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000FFAC8: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000FFACC: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000FFAD0: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000FFAD4: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000FFAD8: 82010103
	.long 0xd7006a00                                           // 0000000FFADC: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000FFAE0: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FFAE4: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000FFAE8: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000FFAF0: BE810080
	.long 0xd7006a00                                           // 0000000FFAF4: D7006A00
	v_cndmask_b32_e32 v1, v0, v52, vcc_lo                      // 0000000FFAF8: 02026900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000FFAFC: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB04: BF870092
	.long 0xd7006a00                                           // 0000000FFB08: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000FFB0C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000FFB10: D5207C01 01AA0211
	s_nop 0                                                    // 0000000FFB18: BF800000
	s_nop 0                                                    // 0000000FFB1C: BF800000
	s_nop 0                                                    // 0000000FFB20: BF800000
	s_nop 0                                                    // 0000000FFB24: BF800000
	s_nop 0                                                    // 0000000FFB28: BF800000
	s_nop 0                                                    // 0000000FFB2C: BF800000
	s_nop 0                                                    // 0000000FFB30: BF800000
	s_nop 0                                                    // 0000000FFB34: BF800000
	s_nop 0                                                    // 0000000FFB38: BF800000
	s_nop 0                                                    // 0000000FFB3C: BF800000
	ds_load_b32 v2, v58                                        // 0000000FFB40: D8D80000 0200003A
	v_add_nc_u32_e32 v5, 0x80, v5                              // 0000000FFB48: 4A0A0AFF 00000080
	v_add_nc_u32_e32 v58, 0x210, v58                           // 0000000FFB50: 4A7474FF 00000210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FFB58: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v5                         // 0000000FFB5C: 7C920AFF 00000F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000FFB64: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000FFB68: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000FFB6C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000FFB74: D7000000
	v_cndmask_b32_e32 v1, 0x800, v0, vcc_lo                    // 0000000FFB78: 020200FF 00000800
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000FFB80: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000FFB88: 917E017E
	s_cbranch_execnz 65516                                     // 0000000FFB8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi8ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3040>
	s_endpgm                                                   // 0000000FFB90: BFB00000
		...

