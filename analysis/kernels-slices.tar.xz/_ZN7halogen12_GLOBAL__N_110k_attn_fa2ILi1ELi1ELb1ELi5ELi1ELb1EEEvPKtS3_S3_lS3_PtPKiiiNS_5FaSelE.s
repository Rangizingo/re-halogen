000000000002fd00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_load_b256 s[12:19], s[0:1], 0x30                         // 00000002FD00: F40C0300 F8000030
	v_and_b32_e32 v132, 31, v0                                 // 00000002FD08: 3708009F
	v_lshrrev_b32_e32 v153, 5, v0                              // 00000002FD0C: 33320085
	s_waitcnt lgkmcnt(0)                                       // 00000002FD10: BF89FC07
	s_load_b32 s28, s[12:13], null                             // 00000002FD14: F4000706 F8000000
	s_clause 0x1                                               // 00000002FD1C: BF850001
	s_load_b128 s[4:7], s[0:1], 0x50                           // 00000002FD20: F4080100 F8000050
	s_load_b32 s8, s[0:1], 0x60                                // 00000002FD28: F4000200 F8000060
	.long 0xd44c0003                                           // 00000002FD30: D44C0003
	v_cndmask_b32_e32 v1, 16, v132, vcc_lo                     // 00000002FD34: 02030890
	v_lshlrev_b32_e32 v133, 6, v153                            // 00000002FD38: 310B3286
	s_and_saveexec_b32 s9, s3                                  // 00000002FD3C: BE892003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FD40: BF870001
	v_lshl_add_u32 v1, v132, 2, v133                           // 00000002FD44: D6460001 06150584
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000002FD4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 00000002FD58: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s9                              // 00000002FD60: 8C7E097E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 00000002FD64: 160200FF 000000AB
	s_waitcnt lgkmcnt(0)                                       // 00000002FD6C: BF89FC07
	s_lshr_b32 s27, s8, 1                                      // 00000002FD70: 851B8108
	s_lshr_b32 s8, s2, 1                                       // 00000002FD74: 85088102
	.long 0x7f043880                                           // 00000002FD78: 7F043880
	s_not_b32 s8, s8                                           // 00000002FD7C: BE881E08
	.long 0x7e043981                                           // 00000002FD80: 7E043981
	s_add_i32 s27, s27, s8                                     // 00000002FD84: 811B081B
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000002FD88: CA240080 8D9A008F
	s_cmp_eq_u64 s[18:19], 0                                   // 00000002FD90: BF108012
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000002FD94: BF8704B2
	v_add_lshl_u32 v155, s27, v2, 4                            // 00000002FD98: D647009B 0212041B
	v_mov_b32_e32 v140, 0                                      // 00000002FDA0: 7F180280
	s_cselect_b32 s24, -1, 0                                   // 00000002FDA4: 981880C1
	s_and_b32 vcc_lo, exec_lo, s24                             // 00000002FDA8: 8B6A187E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FDAC: BF870092
	v_or_b32_e32 v130, v155, v154                              // 00000002FDB0: 3905359B
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000002FDB4: 3507049F
	s_cbranch_vccnz 10                                         // 00000002FDB8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe4>
	v_mad_i64_i32 v[1:2], null, v130, s7, 0                    // 00000002FDBC: D6FF7C01 02000F82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FDC4: BF870091
	.long 0xd73c0001                                           // 00000002FDC8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002FDCC: 02020282
	.long 0xd7006a8c                                           // 00000002FDD0: D7006A8C
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 00000002FDD4: 02020212
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FDD8: BF870001
	v_add_co_ci_u32_e64 v141, null, s19, v2, vcc_lo            // 00000002FDDC: D5207C8D 01AA0413
	s_clause 0x2                                               // 00000002FDE4: BF850002
	s_load_b64 s[18:19], s[0:1], 0x38                          // 00000002FDE8: F4040480 F8000038
	s_load_b128 s[20:23], s[0:1], 0x20                         // 00000002FDF0: F4080500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000002FDF8: F40C0200 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000002FE00: 7F3C0280
	s_xor_b32 s0, s24, -1                                      // 00000002FE04: 8D00C118
	s_waitcnt lgkmcnt(0)                                       // 00000002FE08: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s18, v130                         // 00000002FE0C: 7C890412
	s_and_b32 s26, s0, vcc_lo                                  // 00000002FE10: 8B1A6A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002FE14: BF870009
	s_and_saveexec_b32 s0, s26                                 // 00000002FE18: BE80201A
	s_cbranch_execz 9                                          // 00000002FE1C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144>
	.long 0xd73c0001                                           // 00000002FE20: D73C0001
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000002FE24: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FE28: BF870091
	.long 0xd7006a01                                           // 00000002FE2C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000002FE30: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000002FE34: D5207C02 01AA0405
	global_load_b32 v158, v[1:2], off                          // 00000002FE3C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002FE44: 8C7E007E
	s_cmp_eq_u64 s[16:17], 0                                   // 00000002FE48: BF108010
	s_mov_b64 s[24:25], 0                                      // 00000002FE4C: BE980180
	s_cbranch_scc1 10                                          // 00000002FE50: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17c>
	s_ashr_i32 s0, s6, 31                                      // 00000002FE54: 86009F06
	s_mul_hi_u32 s1, s27, s6                                   // 00000002FE58: 9681061B
	s_mul_i32 s0, s27, s0                                      // 00000002FE5C: 9600001B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002FE60: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000002FE64: 81010001
	s_mul_i32 s0, s27, s6                                      // 00000002FE68: 9600061B
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000002FE6C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002FE70: BF870009
	s_add_u32 s24, s16, s0                                     // 00000002FE74: 80180010
	s_addc_u32 s25, s17, s1                                    // 00000002FE78: 82190111
	.long 0xd7050001                                           // 00000002FE7C: D7050001
	v_cndmask_b32_e32 v0, v153, v150, vcc_lo                   // 00000002FE80: 02012D99
	s_and_b32 s1, s2, 1                                        // 00000002FE84: 8B018102
	s_lshl_b32 s0, s27, 4                                      // 00000002FE88: 8400841B
	s_add_i32 s2, s18, -1                                      // 00000002FE8C: 8102C112
	s_or_b32 s0, s0, 15                                        // 00000002FE90: 8C008F00
	.long 0xd7390001                                           // 00000002FE94: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000002FE98: 02020288
	s_min_i32 s0, s0, s2                                       // 00000002FE9C: 89000200
	v_lshrrev_b32_e32 v156, 4, v132                            // 00000002FEA0: 33390884
	s_add_i32 s0, s0, s28                                      // 00000002FEA4: 81001C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FEA8: BF8700A9
	s_cmp_lt_i32 s0, -15                                       // 00000002FEAC: BF04CF00
	.long 0xd7050001                                           // 00000002FEB0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000002FEB4: 02011901
	.long 0xd7040001                                           // 00000002FEB8: D7040001
	v_cndmask_b32_e32 v1, v153, v1, vcc_lo                     // 00000002FEBC: 02020399
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FEC0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000002FEC4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 00000002FED0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000002FED4: 7E8A0348
	v_mov_b32_e32 v67, v72                                     // 00000002FED8: 7E860348
	v_mov_b32_e32 v66, v72                                     // 00000002FEDC: 7E840348
	v_mad_u64_u32 v[138:139], null, s1, 12, v[1:2]             // 00000002FEE0: D6FE7C8A 04051801
	v_mov_b32_e32 v70, v72                                     // 00000002FEE8: 7E8C0348
	v_mov_b32_e32 v65, v72                                     // 00000002FEEC: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000002FEF0: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000002FEF4: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000002FEF8: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000002FEFC: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000002FF00: CA220148 4C011488
	v_mov_b32_e32 v68, v72                                     // 00000002FF08: 7E880348
	v_mov_b32_e32 v75, v72                                     // 00000002FF0C: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000002FF10: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000002FF14: 7E920348
	v_mov_b32_e32 v88, v72                                     // 00000002FF18: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000002FF1C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000002FF20: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000002FF24: 7EAA0348
	v_mov_b32_e32 v84, v72                                     // 00000002FF28: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000002FF2C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000002FF30: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000002FF34: 7EA20348
	v_dual_mov_b32 v96, v72 :: v_dual_lshlrev_b32 v157, 1, v1  // 00000002FF38: CA220148 609C0281
	v_mov_b32_e32 v95, v72                                     // 00000002FF40: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000002FF44: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000002FF48: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000002FF4C: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000002FF50: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000002FF54: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000002FF58: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000002FF5C: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000002FF60: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000002FF64: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000002FF68: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000002FF6C: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000002FF70: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000002FF74: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000002FF78: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000002FF7C: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000002FF80: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000002FF84: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000002FF88: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000002FF8C: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000002FF90: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000002FF94: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000002FF98: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000002FF9C: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000002FFA0: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000002FFA4: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000002FFA8: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000002FFAC: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000002FFB0: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000002FFB4: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000002FFB8: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000002FFBC: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000002FFC0: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000002FFC4: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000002FFC8: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000002FFCC: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000002FFD0: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000002FFD4: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000002FFD8: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000002FFDC: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000002FFE0: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000002FFE4: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000002FFE8: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000002FFEC: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000002FFF0: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000002FFF4: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000002FFF8: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000002FFFC: 7E700348
	v_mov_b32_e32 v55, v72                                     // 000000030000: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 000000030004: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 000000030008: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000003000C: 7E680348
	v_mov_b32_e32 v51, v72                                     // 000000030010: 7E660348
	v_mov_b32_e32 v50, v72                                     // 000000030014: 7E640348
	v_mov_b32_e32 v49, v72                                     // 000000030018: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000003001C: 7E600348
	v_mov_b32_e32 v47, v72                                     // 000000030020: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 000000030024: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 000000030028: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000003002C: 7E580348
	v_mov_b32_e32 v43, v72                                     // 000000030030: 7E560348
	v_mov_b32_e32 v42, v72                                     // 000000030034: 7E540348
	v_mov_b32_e32 v41, v72                                     // 000000030038: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000003003C: 7E500348
	v_mov_b32_e32 v39, v72                                     // 000000030040: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 000000030044: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 000000030048: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000003004C: 7E480348
	v_mov_b32_e32 v35, v72                                     // 000000030050: 7E460348
	v_mov_b32_e32 v34, v72                                     // 000000030054: 7E440348
	v_mov_b32_e32 v33, v72                                     // 000000030058: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000003005C: 7E400348
	v_mov_b32_e32 v31, v72                                     // 000000030060: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 000000030064: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 000000030068: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000003006C: 7E380348
	v_mov_b32_e32 v27, v72                                     // 000000030070: 7E360348
	v_mov_b32_e32 v26, v72                                     // 000000030074: 7E340348
	v_mov_b32_e32 v25, v72                                     // 000000030078: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000003007C: 7E300348
	v_mov_b32_e32 v23, v72                                     // 000000030080: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 000000030084: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 000000030088: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000003008C: 7E280348
	v_mov_b32_e32 v19, v72                                     // 000000030090: 7E260348
	v_mov_b32_e32 v18, v72                                     // 000000030094: 7E240348
	v_mov_b32_e32 v17, v72                                     // 000000030098: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000003009C: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000300A0: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000300A4: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000300A8: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000300AC: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000300B0: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000300B4: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000300B8: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000300BC: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000300C0: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000300C4: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000300C8: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000300CC: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000300D0: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000300D4: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000300D8: 7E020348
	s_cbranch_scc1 2588                                        // 0000000300DC: BFA20A1C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c50>
	v_mad_i64_i32 v[1:2], null, 0x3000, v130, s[8:9]           // 0000000300E0: D6FF7C01 002304FF 00003000
	v_add3_u32 v3, s28, 1, v130                                // 0000000300EC: D6550003 0609021C
	s_ashr_i32 s2, s0, 31                                      // 0000000300F4: 86029F00
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v4, 2, v132   // 0000000300F8: CA220080 81050882
	s_lshr_b32 s2, s2, 28                                      // 000000030100: 85029C02
	v_add_nc_u32_e32 v139, s28, v155                           // 000000030104: 4B17361C
	s_add_i32 s0, s0, s2                                       // 000000030108: 81000200
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000003010C: BF8701D4
	.long 0xd7006a8e                                           // 000000030110: D7006A8E
	v_cndmask_b32_e32 v1, v1, v157, vcc_lo                     // 000000030114: 02033B01
	v_ashrrev_i32_e32 v1, 31, v3                               // 000000030118: 3402069F
	s_movk_i32 s2, 0x440                                       // 00000003011C: B0020440
	v_add_co_ci_u32_e64 v143, null, 0, v2, vcc_lo              // 000000030120: D5207C8F 01AA0480
	v_mad_u32_u24 v2, v153, s2, 0x1800                         // 000000030128: D60B0002 03FC0599 00001800
	v_lshrrev_b32_e32 v1, 30, v1                               // 000000030134: 3202029E
	s_ashr_i32 s16, s0, 4                                      // 000000030138: 86108400
	s_cmp_eq_u64 s[24:25], 0                                   // 00000003013C: BF108018
	v_mov_b32_e32 v176, v153                                   // 000000030140: 7F600399
	v_mad_u32_u24 v5, 0x44, v156, v2                           // 000000030144: D60B0005 040B38FF 00000044
	v_add_nc_u32_e32 v1, v3, v1                                // 000000030150: 4A020303
	v_add_nc_u32_e32 v3, v4, v133                              // 000000030154: 4A070B04
	v_mad_u32_u24 v164, 0x44, v132, v2                         // 000000030158: D60B00A4 040B08FF 00000044
	v_lshlrev_b32_e32 v2, 4, v0                                // 000000030164: 30040084
	v_lshl_add_u32 v160, v154, 2, v5                           // 000000030168: D64600A0 0415059A
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v133// 000000030170: CA200181 0A050AFF 00009F00
	v_ashrrev_i32_e32 v161, 2, v1                              // 00000003017C: 35420282
	v_dual_mov_b32 v6, v129 :: v_dual_lshlrev_b32 v1, 9, v153  // 000000030180: CA220181 06013289
	s_cselect_b32 s17, -1, 0                                   // 000000030188: 981180C1
	s_cmp_lg_u64 s[24:25], 0                                   // 00000003018C: BF118018
	v_dual_mov_b32 v144, 0 :: v_dual_add_nc_u32 v167, v5, v4   // 000000030190: CA200080 90A60905
	v_dual_mov_b32 v4, v129 :: v_dual_add_nc_u32 v163, 0x9c00, v3// 000000030198: CA200181 04A206FF 00009C00
	v_mov_b32_e32 v8, v129                                     // 0000000301A4: 7E100381
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v166, 0xa200, v3// 0000000301A8: CA200181 03A606FF 0000A200
	v_dual_mov_b32 v7, v129 :: v_dual_and_b32 v2, 0x1f0, v2    // 0000000301B4: CA240181 070204FF 000001F0
	s_cselect_b32 s27, -1, 0                                   // 0000000301C0: 981B80C1
	s_lshl_b32 s1, s1, 9                                       // 0000000301C4: 84018901
	s_add_i32 s19, s19, -1                                     // 0000000301C8: 8113C113
	v_lshl_add_u32 v165, v132, 5, v1                           // 0000000301CC: D64600A5 04050B84
	v_lshl_or_b32 v169, v154, 5, v1                            // 0000000301D4: D65600A9 04050B9A
	v_mul_u32_u24_e32 v1, 0x210, v153                          // 0000000301DC: 160332FF 00000210
	s_add_u32 s4, s10, s1                                      // 0000000301E4: 8004010A
	s_addc_u32 s2, s11, 0                                      // 0000000301E8: 8202800B
	s_movk_i32 s5, 0x210                                       // 0000000301EC: B0050210
	.long 0xd70004ab                                           // 0000000301F0: D70004AB
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000000301F4: 02020404
	.long 0xd44c0000                                           // 0000000301F8: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000301FC: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s5, 0x7b00                       // 000000030204: D60B009F 03FC0B9A 00007B00
	v_lshl_or_b32 v168, v156, 2, v5                            // 000000030210: D65600A8 0415059C
	v_mad_u32_u24 v170, v154, 48, 0x4b00                       // 000000030218: D60B00AA 03FD619A 00004B00
	v_add_co_ci_u32_e64 v172, null, s2, 0, s4                  // 000000030224: D5207CAC 00110002
	v_lshl_or_b32 v173, v154, 1, 0x4b00                        // 00000003022C: D65600AD 03FD039A 00004B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v174, 0xfffffe80, v0// 000000030238: CA200080 09AE00FF FFFFFE80
	v_lshl_add_u32 v175, v132, 4, v1                           // 000000030244: D64600AF 04050984
	v_lshrrev_b32_e32 v0, 1, v0                                // 00000003024C: 32000081
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 000000030250: CA100080 01020181
	v_dual_mov_b32 v5, v129 :: v_dual_add_nc_u32 v162, v139, v132// 000000030258: CA200181 05A3098B
	v_mov_b32_e32 v11, v129                                    // 000000030260: 7E160381
	v_dual_mov_b32 v12, v129 :: v_dual_mov_b32 v17, 0          // 000000030264: CA100181 0C100080
	v_mov_b32_e32 v13, v129                                    // 00000003026C: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v25, 0          // 000000030270: CA100181 0E180080
	v_mov_b32_e32 v15, v129                                    // 000000030278: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v33, 0          // 00000003027C: CA100181 10200080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v41, 0          // 000000030284: CA100181 12280080
	v_mov_b32_e32 v19, v129                                    // 00000003028C: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v49, 0          // 000000030290: CA100181 14300080
	v_mov_b32_e32 v21, v129                                    // 000000030298: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v57, 0          // 00000003029C: CA100181 16380080
	v_mov_b32_e32 v23, v129                                    // 0000000302A4: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v121, 0         // 0000000302A8: CA100181 18780080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v113, 0         // 0000000302B0: CA100181 1A700080
	v_mov_b32_e32 v27, v129                                    // 0000000302B8: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v105, 0         // 0000000302BC: CA100181 1C680080
	v_mov_b32_e32 v29, v129                                    // 0000000302C4: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v97, 0          // 0000000302C8: CA100181 1E600080
	v_mov_b32_e32 v31, v129                                    // 0000000302D0: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v89, 0          // 0000000302D4: CA100181 20580080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v81, 0          // 0000000302DC: CA100181 22500080
	v_mov_b32_e32 v35, v129                                    // 0000000302E4: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v73, 0          // 0000000302E8: CA100181 24480080
	v_mov_b32_e32 v37, v129                                    // 0000000302F0: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v65, 0          // 0000000302F4: CA100181 26400080
	v_mov_b32_e32 v39, v129                                    // 0000000302FC: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 000000030300: 7E500381
	v_mov_b32_e32 v42, v129                                    // 000000030304: 7E540381
	v_mov_b32_e32 v43, v129                                    // 000000030308: 7E560381
	v_mov_b32_e32 v44, v129                                    // 00000003030C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 000000030310: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 000000030314: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 000000030318: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000003031C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 000000030320: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000030324: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000030328: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000003032C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 000000030330: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000030334: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000030338: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000003033C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000030340: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000030344: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000030348: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000003034C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000030350: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000030354: 7E800381
	v_mov_b32_e32 v122, v129                                   // 000000030358: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000003035C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 000000030360: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 000000030364: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 000000030368: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000003036C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 000000030370: 7F000381
	v_mov_b32_e32 v114, v129                                   // 000000030374: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 000000030378: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000003037C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 000000030380: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 000000030384: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 000000030388: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000003038C: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 000000030390: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 000000030394: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 000000030398: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000003039C: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000303A0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000303A4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000303A8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000303AC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000303B0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000303B4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000303B8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000303BC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000303C0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000303C4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000303C8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000303CC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000303D0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000303D4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000303D8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000303DC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000303E0: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000303E4: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000303E8: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000303EC: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000303F0: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000303F4: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000303F8: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000303FC: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 000000030400: 7E940381
	v_mov_b32_e32 v75, v129                                    // 000000030404: 7E960381
	v_mov_b32_e32 v76, v129                                    // 000000030408: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000003040C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 000000030410: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 000000030414: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000030418: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000003041C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000030420: 7E860381
	v_mov_b32_e32 v68, v129                                    // 000000030424: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000030428: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000003042C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000030430: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 000000030434: 7E900381
	s_add_u32 s11, s12, s1                                     // 000000030438: 800B010C
	s_mov_b32 s28, 0                                           // 00000003043C: BE9C0080
	s_addc_u32 s12, s13, 0                                     // 000000030440: 820C800D
	s_branch 117                                               // 000000030444: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c>
	ds_load_b128 v[145:148], v170                              // 000000030448: DBFC0000 910000AA
	ds_load_b128 v[149:152], v170 offset:16                    // 000000030450: DBFC0010 950000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030458: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[145:152], v[121:128]// 00000003045C: CC414079 1DE72382
	ds_load_b128 v[149:152], v170 offset:784                   // 000000030464: DBFC0310 950000AA
	ds_load_b128 v[145:148], v170 offset:768                   // 00000003046C: DBFC0300 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030474: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[145:152], v[113:120]// 000000030478: CC414071 1DC72382
	ds_load_b128 v[149:152], v170 offset:1552                  // 000000030480: DBFC0610 950000AA
	ds_load_b128 v[145:148], v170 offset:1536                  // 000000030488: DBFC0600 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030490: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[145:152], v[105:112]// 000000030494: CC414069 1DA72382
	ds_load_b128 v[149:152], v170 offset:2320                  // 00000003049C: DBFC0910 950000AA
	ds_load_b128 v[145:148], v170 offset:2304                  // 0000000304A4: DBFC0900 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000304AC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[145:152], v[97:104]// 0000000304B0: CC414061 1D872382
	ds_load_b128 v[149:152], v170 offset:3088                  // 0000000304B8: DBFC0C10 950000AA
	ds_load_b128 v[145:148], v170 offset:3072                  // 0000000304C0: DBFC0C00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000304C8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[145:152], v[89:96]// 0000000304CC: CC414059 1D672382
	ds_load_b128 v[149:152], v170 offset:3856                  // 0000000304D4: DBFC0F10 950000AA
	ds_load_b128 v[145:148], v170 offset:3840                  // 0000000304DC: DBFC0F00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000304E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[145:152], v[81:88]// 0000000304E8: CC414051 1D472382
	ds_load_b128 v[149:152], v170 offset:4624                  // 0000000304F0: DBFC1210 950000AA
	ds_load_b128 v[145:148], v170 offset:4608                  // 0000000304F8: DBFC1200 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030500: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[145:152], v[73:80]// 000000030504: CC414049 1D272382
	ds_load_b128 v[149:152], v170 offset:5392                  // 00000003050C: DBFC1510 950000AA
	ds_load_b128 v[145:148], v170 offset:5376                  // 000000030514: DBFC1500 910000AA
	s_waitcnt lgkmcnt(0)                                       // 00000003051C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[145:152], v[65:72]// 000000030520: CC414041 1D072382
	ds_load_b128 v[149:152], v170 offset:6160                  // 000000030528: DBFC1810 950000AA
	ds_load_b128 v[145:148], v170 offset:6144                  // 000000030530: DBFC1800 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030538: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[145:152], v[57:64]// 00000003053C: CC414039 1CE72382
	ds_load_b128 v[149:152], v170 offset:6928                  // 000000030544: DBFC1B10 950000AA
	ds_load_b128 v[145:148], v170 offset:6912                  // 00000003054C: DBFC1B00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030554: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[145:152], v[49:56]// 000000030558: CC414031 1CC72382
	ds_load_b128 v[149:152], v170 offset:7696                  // 000000030560: DBFC1E10 950000AA
	ds_load_b128 v[145:148], v170 offset:7680                  // 000000030568: DBFC1E00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 000000030570: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[145:152], v[41:48]// 000000030574: CC414029 1CA72382
	ds_load_b128 v[149:152], v170 offset:8464                  // 00000003057C: DBFC2110 950000AA
	ds_load_b128 v[145:148], v170 offset:8448                  // 000000030584: DBFC2100 910000AA
	s_waitcnt lgkmcnt(0)                                       // 00000003058C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[145:152], v[33:40]// 000000030590: CC414021 1C872382
	ds_load_b128 v[149:152], v170 offset:9232                  // 000000030598: DBFC2410 950000AA
	ds_load_b128 v[145:148], v170 offset:9216                  // 0000000305A0: DBFC2400 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000305A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[145:152], v[25:32]// 0000000305AC: CC414019 1C672382
	ds_load_b128 v[149:152], v170 offset:10000                 // 0000000305B4: DBFC2710 950000AA
	ds_load_b128 v[145:148], v170 offset:9984                  // 0000000305BC: DBFC2700 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000305C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[145:152], v[17:24]// 0000000305C8: CC414011 1C472382
	ds_load_b128 v[149:152], v170 offset:10768                 // 0000000305D0: DBFC2A10 950000AA
	ds_load_b128 v[145:148], v170 offset:10752                 // 0000000305D8: DBFC2A00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000305E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[145:152], v[9:16]// 0000000305E4: CC414009 1C272382
	ds_load_b128 v[149:152], v170 offset:11536                 // 0000000305EC: DBFC2D10 950000AA
	ds_load_b128 v[145:148], v170 offset:11520                 // 0000000305F4: DBFC2D00 910000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000305FC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[145:152], v[1:8]// 000000030600: CC414001 1C072382
	v_add_nc_u32_e32 v176, 16, v176                            // 000000030608: 4B616090
	s_add_i32 s1, s28, 1                                       // 00000003060C: 8101811C
	s_cmp_eq_u32 s28, s16                                      // 000000030610: BF06101C
	s_mov_b32 s28, s1                                          // 000000030614: BE9C0001
	s_cbranch_scc1 2253                                        // 000000030618: BFA208CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c50>
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 00000003061C: 916A1B7E
	s_mov_b32 s1, s17                                          // 000000030620: BE810011
	s_cbranch_vccnz 13                                         // 000000030624: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_lshr_b32 s1, s28, 3                                      // 000000030628: 8501831C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003062C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000030630: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 000000030638: 7F040201
	global_load_b32 v130, v130, s[24:25]                       // 00000003063C: DC520000 82180082
	s_waitcnt vmcnt(0)                                         // 000000030644: BF8903F7
	v_lshrrev_b32_e32 v130, s28, v130                          // 000000030648: 3305041C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003064C: BF870091
	v_and_b32_e32 v130, 1, v130                                // 000000030650: 37050481
	.long 0xd44a0001                                           // 000000030654: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000030658: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003065C: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000030660: 916A017E
	s_cbranch_vccnz 65512                                      // 000000030664: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x908>
	s_lshl_b32 s2, s28, 4                                      // 000000030668: 8402841C
	s_waitcnt vmcnt(0)                                         // 00000003066C: BF8903F7
	s_barrier                                                  // 000000030670: BFBD0000
	buffer_gl0_inv                                             // 000000030674: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000003067C: BE812000
	s_cbranch_execz 119                                        // 000000030680: BFA50077 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v176 :: v_dual_mov_b32 v131, v175     // 000000030684: CA1001B0 828201AF
	v_mov_b32_e32 v132, v174                                   // 00000003068C: 7F0803AE
	s_mov_b32 s4, 0                                            // 000000030690: BE840080
	s_nop 0                                                    // 000000030694: BF800000
	s_nop 0                                                    // 000000030698: BF800000
	s_nop 0                                                    // 00000003069C: BF800000
	s_nop 0                                                    // 0000000306A0: BF800000
	s_nop 0                                                    // 0000000306A4: BF800000
	s_nop 0                                                    // 0000000306A8: BF800000
	s_nop 0                                                    // 0000000306AC: BF800000
	s_nop 0                                                    // 0000000306B0: BF800000
	s_nop 0                                                    // 0000000306B4: BF800000
	s_nop 0                                                    // 0000000306B8: BF800000
	s_nop 0                                                    // 0000000306BC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000306C0: BF870112
	v_min_i32_e32 v133, s19, v130                              // 0000000306C4: 230B0413
	v_add_nc_u32_e32 v132, 0x180, v132                         // 0000000306C8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 0000000306D0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000306D4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 0000000306D8: 350F0A9F
	.long 0xd72c0088                                           // 0000000306DC: D72C0088
	v_cndmask_b32_e32 v1, s15, v133, vcc_lo                    // 0000000306E0: 02030A0F
	v_mad_u64_u32 v[133:134], null, s14, v133, 0               // 0000000306E4: D6FE7C85 02030A0E
	.long 0xd72c0087                                           // 0000000306EC: D72C0087
	v_cndmask_b32_e32 v1, s14, v135, vcc_lo                    // 0000000306F0: 02030E0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000306F4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 0000000306F8: D6550086 06230F86
	.long 0xd73c0085                                           // 000000030700: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 000000030704: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030708: BF870091
	.long 0xd7006a85                                           // 00000003070C: D7006A85
	v_cndmask_b32_e32 v1, v171, v133, vcc_lo                   // 000000030710: 02030BAB
	v_add_co_ci_u32_e64 v134, null, v172, v134, vcc_lo         // 000000030714: D5207C86 01AB0DAC
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000003071C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 000000030724: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000003072C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000030730: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 000000030734: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000003073C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000030744: 917E047E
	s_cbranch_execnz 65501                                     // 000000030748: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003074C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 000000030750: 39053402
	s_mov_b32 s4, 0                                            // 000000030754: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030758: BF870091
	v_min_i32_e32 v130, s19, v130                              // 00000003075C: 23050413
	v_ashrrev_i32_e32 v132, 31, v130                           // 000000030760: 3509049F
	.long 0xd72c0085                                           // 000000030764: D72C0085
	v_cndmask_b32_e32 v1, s15, v130, vcc_lo                    // 000000030768: 0203040F
	v_mad_u64_u32 v[130:131], null, s14, v130, 0               // 00000003076C: D6FE7C82 0203040E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030774: BF870093
	.long 0xd72c0084                                           // 000000030778: D72C0084
	v_cndmask_b32_e32 v1, s14, v132, vcc_lo                    // 00000003077C: 0203080E
	v_add3_u32 v131, v131, v132, v133                          // 000000030780: D6550083 06170983
	v_mov_b32_e32 v133, v174                                   // 000000030788: 7F0A03AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003078C: BF870122
	.long 0xd73c0083                                           // 000000030790: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000030794: 02030481
	v_mov_b32_e32 v130, v0                                     // 000000030798: 7F040300
	.long 0xd7006a83                                           // 00000003079C: D7006A83
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 0000000307A0: 0203060B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000307A4: BF870001
	v_add_co_ci_u32_e64 v132, null, s12, v132, vcc_lo          // 0000000307A8: D5207C84 01AB080C
	s_set_inst_prefetch_distance 0x1                           // 0000000307B0: BF840001
	s_nop 0                                                    // 0000000307B4: BF800000
	s_nop 0                                                    // 0000000307B8: BF800000
	s_nop 0                                                    // 0000000307BC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000307C0: BF8701B3
	v_and_b32_e32 v145, 0xf8, v130                             // 0000000307C4: 372304FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 0000000307CC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 0000000307D4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v145                            // 0000000307DC: 310D2281
	v_mad_u32_u24 v145, v145, 48, v173                         // 0000000307E0: D60B0091 06B56191
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000307E8: BF870092
	.long 0xd7006a86                                           // 0000000307EC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 0000000307F0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 0000000307F4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 0000000307FC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 000000030804: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000003080C: BF8903F7
	ds_store_b16 v145, v134                                    // 000000030810: D87C0000 00008691
	ds_store_b16_d16_hi v145, v134 offset:48                   // 000000030818: DA840030 00008691
	ds_store_b16 v145, v135 offset:96                          // 000000030820: D87C0060 00008791
	ds_store_b16_d16_hi v145, v135 offset:144                  // 000000030828: DA840090 00008791
	ds_store_b16 v145, v136 offset:192                         // 000000030830: D87C00C0 00008891
	ds_store_b16_d16_hi v145, v136 offset:240                  // 000000030838: DA8400F0 00008891
	ds_store_b16 v145, v137 offset:288                         // 000000030840: D87C0120 00008991
	ds_store_b16_d16_hi v145, v137 offset:336                  // 000000030848: DA840150 00008991
	s_or_b32 s4, vcc_lo, s4                                    // 000000030850: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030854: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000030858: 917E047E
	s_cbranch_execnz 65496                                     // 00000003085C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 000000030860: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000030864: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000030868: BF89FC07
	s_barrier                                                  // 00000003086C: BFBD0000
	buffer_gl0_inv                                             // 000000030870: E0AC0000 00000000
	s_clause 0x3                                               // 000000030878: BF850003
	global_load_b128 v[149:152], v[142:143], off offset:16     // 00000003087C: DC5E0010 957C008E
	global_load_b128 v[145:148], v[142:143], off               // 000000030884: DC5E0000 917C008E
	global_load_b128 v[181:184], v[142:143], off offset:48     // 00000003088C: DC5E0030 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:32     // 000000030894: DC5E0020 B17C008E
	ds_load_b128 v[185:188], v159                              // 00000003089C: DBFC0000 B900009F
	ds_load_b128 v[189:192], v159 offset:16                    // 0000000308A4: DBFC0010 BD00009F
	v_mov_b32_e32 v136, v129                                   // 0000000308AC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000308B0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000308B4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000308B8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000308BC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000308C0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000308C4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000308C8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000308CC: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000308D0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000308D4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000308D8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000308DC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000308E0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000308E4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000308E8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000308EC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000308F0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 0000000308F4: CC414082 1E0B7391
	s_clause 0x1                                               // 0000000308FC: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:80     // 000000030900: DC5E0050 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:64     // 000000030908: DC5E0040 917C008E
	ds_load_b128 v[185:188], v159 offset:32                    // 000000030910: DBFC0020 B900009F
	ds_load_b128 v[189:192], v159 offset:48                    // 000000030918: DBFC0030 BD00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030920: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000030924: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000003092C: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:112    // 000000030930: DC5E0070 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:96     // 000000030938: DC5E0060 B17C008E
	ds_load_b128 v[189:192], v159 offset:80                    // 000000030940: DBFC0050 BD00009F
	ds_load_b128 v[185:188], v159 offset:64                    // 000000030948: DBFC0040 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030950: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 000000030954: CC414082 1E0B7391
	s_clause 0x1                                               // 00000003095C: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:144    // 000000030960: DC5E0090 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:128    // 000000030968: DC5E0080 917C008E
	ds_load_b128 v[189:192], v159 offset:112                   // 000000030970: DBFC0070 BD00009F
	ds_load_b128 v[185:188], v159 offset:96                    // 000000030978: DBFC0060 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030980: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000030984: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000003098C: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:176    // 000000030990: DC5E00B0 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:160    // 000000030998: DC5E00A0 B17C008E
	ds_load_b128 v[189:192], v159 offset:144                   // 0000000309A0: DBFC0090 BD00009F
	ds_load_b128 v[185:188], v159 offset:128                   // 0000000309A8: DBFC0080 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000309B0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 0000000309B4: CC414082 1E0B7391
	s_clause 0x1                                               // 0000000309BC: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:208    // 0000000309C0: DC5E00D0 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:192    // 0000000309C8: DC5E00C0 917C008E
	ds_load_b128 v[189:192], v159 offset:176                   // 0000000309D0: DBFC00B0 BD00009F
	ds_load_b128 v[185:188], v159 offset:160                   // 0000000309D8: DBFC00A0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000309E0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000309E4: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000309EC: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:240    // 0000000309F0: DC5E00F0 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:224    // 0000000309F8: DC5E00E0 B17C008E
	ds_load_b128 v[189:192], v159 offset:208                   // 000000030A00: DBFC00D0 BD00009F
	ds_load_b128 v[185:188], v159 offset:192                   // 000000030A08: DBFC00C0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030A10: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 000000030A14: CC414082 1E0B7391
	s_clause 0x1                                               // 000000030A1C: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:272    // 000000030A20: DC5E0110 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:256    // 000000030A28: DC5E0100 917C008E
	ds_load_b128 v[189:192], v159 offset:240                   // 000000030A30: DBFC00F0 BD00009F
	ds_load_b128 v[185:188], v159 offset:224                   // 000000030A38: DBFC00E0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030A40: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000030A44: CC414082 1E0B73B1
	s_clause 0x1                                               // 000000030A4C: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:304    // 000000030A50: DC5E0130 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:288    // 000000030A58: DC5E0120 B17C008E
	ds_load_b128 v[189:192], v159 offset:272                   // 000000030A60: DBFC0110 BD00009F
	ds_load_b128 v[185:188], v159 offset:256                   // 000000030A68: DBFC0100 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030A70: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 000000030A74: CC414082 1E0B7391
	s_clause 0x1                                               // 000000030A7C: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:336    // 000000030A80: DC5E0150 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:320    // 000000030A88: DC5E0140 917C008E
	ds_load_b128 v[189:192], v159 offset:304                   // 000000030A90: DBFC0130 BD00009F
	ds_load_b128 v[185:188], v159 offset:288                   // 000000030A98: DBFC0120 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030AA0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000030AA4: CC414082 1E0B73B1
	s_clause 0x1                                               // 000000030AAC: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:368    // 000000030AB0: DC5E0170 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:352    // 000000030AB8: DC5E0160 B17C008E
	ds_load_b128 v[189:192], v159 offset:336                   // 000000030AC0: DBFC0150 BD00009F
	ds_load_b128 v[185:188], v159 offset:320                   // 000000030AC8: DBFC0140 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030AD0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 000000030AD4: CC414082 1E0B7391
	s_clause 0x1                                               // 000000030ADC: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:400    // 000000030AE0: DC5E0190 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:384    // 000000030AE8: DC5E0180 917C008E
	ds_load_b128 v[189:192], v159 offset:368                   // 000000030AF0: DBFC0170 BD00009F
	ds_load_b128 v[185:188], v159 offset:352                   // 000000030AF8: DBFC0160 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030B00: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000030B04: CC414082 1E0B73B1
	s_clause 0x1                                               // 000000030B0C: BF850001
	global_load_b128 v[181:184], v[142:143], off offset:432    // 000000030B10: DC5E01B0 B57C008E
	global_load_b128 v[177:180], v[142:143], off offset:416    // 000000030B18: DC5E01A0 B17C008E
	ds_load_b128 v[189:192], v159 offset:400                   // 000000030B20: DBFC0190 BD00009F
	ds_load_b128 v[185:188], v159 offset:384                   // 000000030B28: DBFC0180 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030B30: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[185:192], v[130:137]// 000000030B34: CC414082 1E0B7391
	ds_load_b128 v[149:152], v159 offset:432                   // 000000030B3C: DBFC01B0 9500009F
	ds_load_b128 v[145:148], v159 offset:416                   // 000000030B44: DBFC01A0 9100009F
	s_clause 0x1                                               // 000000030B4C: BF850001
	global_load_b128 v[189:192], v[142:143], off offset:464    // 000000030B50: DC5E01D0 BD7C008E
	global_load_b128 v[185:188], v[142:143], off offset:448    // 000000030B58: DC5E01C0 B97C008E
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030B60: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[145:152], v[130:137]// 000000030B64: CC414082 1E0B23B1
	s_clause 0x1                                               // 000000030B6C: BF850001
	global_load_b128 v[149:152], v[142:143], off offset:496    // 000000030B70: DC5E01F0 957C008E
	global_load_b128 v[145:148], v[142:143], off offset:480    // 000000030B78: DC5E01E0 917C008E
	ds_load_b128 v[181:184], v159 offset:464                   // 000000030B80: DBFC01D0 B500009F
	ds_load_b128 v[177:180], v159 offset:448                   // 000000030B88: DBFC01C0 B100009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000030B90: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[177:184], v[130:137]// 000000030B94: CC414082 1E0B63B9
	ds_load_b128 v[181:184], v159 offset:496                   // 000000030B9C: DBFC01F0 B500009F
	ds_load_b128 v[177:180], v159 offset:480                   // 000000030BA4: DBFC01E0 B100009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000030BAC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[145:152], v[177:184], v[130:137]// 000000030BB0: CC414082 1E0B6391
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000030BB8: BF870111
	v_dual_mul_f32 v130, 0x3db8aa3b, v130 :: v_dual_mul_f32 v131, 0x3db8aa3b, v131// 000000030BBC: C8C704FF 828306FF 3DB8AA3B
	v_mul_f32_e32 v145, 0x3db8aa3b, v133                       // 000000030BC8: 11230AFF 3DB8AA3B
	v_mov_b32_e32 v133, 0xffff                                 // 000000030BD0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000030BD8: BF870004
	v_mul_f32_e32 v132, 0x3db8aa3b, v132                       // 000000030BDC: 110908FF 3DB8AA3B
	v_dual_mul_f32 v134, 0x3db8aa3b, v134 :: v_dual_mul_f32 v135, 0x3db8aa3b, v135// 000000030BE4: C8C70CFF 86870EFF 3DB8AA3B
	v_dual_mul_f32 v136, 0x3db8aa3b, v136 :: v_dual_mul_f32 v137, 0x3db8aa3b, v137// 000000030BF0: C8C710FF 888912FF 3DB8AA3B
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 000000030BFC: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v145 offset0:68 offset1:102 // 000000030C04: D8386644 009184A0
	ds_store_2addr_b32 v160, v134, v135 offset0:136 offset1:170// 000000030C0C: D838AA88 008786A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 000000030C14: D838EECC 008988A0
	s_and_saveexec_b32 s4, s26                                 // 000000030C1C: BE84201A
	s_cbranch_execz 363                                        // 000000030C20: BFA5016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s5, s28, 2                                      // 000000030C24: 8405821C
	s_mov_b32 s6, exec_lo                                      // 000000030C28: BE86007E
	.long 0xd4c1007e                                           // 000000030C2C: D4C1007E
	v_cndmask_b32_e32 v1, v144, v158, vcc_lo                   // 000000030C30: 02033D90
	s_cbranch_execz 48                                         // 000000030C34: BFA50030 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v145, 31, v144                           // 000000030C38: 3523209F
	s_mov_b32 s7, 0                                            // 000000030C3C: BE870080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030C40: BF870091
	.long 0xd73c0082                                           // 000000030C44: D73C0082
	v_cndmask_b32_e32 v1, 2, v144, vcc_lo                      // 000000030C48: 02032082
	.long 0xd7006a82                                           // 000000030C4C: D7006A82
	v_cndmask_b32_e32 v1, v140, v130, vcc_lo                   // 000000030C50: 0203058C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030C54: BF870001
	v_add_co_ci_u32_e64 v131, null, v141, v131, vcc_lo         // 000000030C58: D5207C83 01AB078D
	s_branch 15                                                // 000000030C60: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 000000030C64: BF800000
	s_nop 0                                                    // 000000030C68: BF800000
	s_nop 0                                                    // 000000030C6C: BF800000
	s_nop 0                                                    // 000000030C70: BF800000
	s_nop 0                                                    // 000000030C74: BF800000
	s_nop 0                                                    // 000000030C78: BF800000
	s_nop 0                                                    // 000000030C7C: BF800000
	s_or_b32 exec_lo, exec_lo, s9                              // 000000030C80: 8C7E097E
	v_mov_b32_e32 v133, v144                                   // 000000030C84: 7F0A0390
	v_mov_b32_e32 v144, v132                                   // 000000030C88: 7F200384
	s_and_b32 s1, exec_lo, s8                                  // 000000030C8C: 8B01087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000030C90: BF870499
	s_or_b32 s7, s1, s7                                        // 000000030C94: 8C070701
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000030C98: 917E077E
	s_cbranch_execz 20                                         // 000000030C9C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 000000030CA0: DC520000 847C0082
	s_or_b32 s8, s8, exec_lo                                   // 000000030CA8: 8C087E08
	s_waitcnt vmcnt(0)                                         // 000000030CAC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s5, v132                          // 000000030CB0: 7C890805
	s_and_saveexec_b32 s9, vcc_lo                              // 000000030CB4: BE89206A
	s_cbranch_execz 65521                                      // 000000030CB8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_add_nc_u32_e32 v132, 1, v144                             // 000000030CBC: 4B092081
	.long 0xd7000182                                           // 000000030CC0: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 000000030CC4: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000030CC8: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 000000030CCC: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 000000030CD4: 7C95099E
	v_mov_b32_e32 v144, v158                                   // 000000030CD8: 7F20039E
	s_and_not1_b32 s1, s8, exec_lo                             // 000000030CDC: 91017E08
	s_and_b32 s8, vcc_lo, exec_lo                              // 000000030CE0: 8B087E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030CE4: BF870009
	s_or_b32 s8, s1, s8                                        // 000000030CE8: 8C080801
	s_branch 65508                                             // 000000030CEC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000030CF0: 8C7E077E
	v_mov_b32_e32 v144, v133                                   // 000000030CF4: 7F200385
	s_or_b32 exec_lo, exec_lo, s6                              // 000000030CF8: 8C7E067E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030CFC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v144       // 000000030D00: CA10008F 85820190
	s_mov_b32 s1, exec_lo                                      // 000000030D08: BE81007E
	.long 0xd4c1007e                                           // 000000030D0C: D4C1007E
	v_cndmask_b32_e32 v1, s5, v161, vcc_lo                     // 000000030D10: 02034205
	s_cbranch_execz 62                                         // 000000030D14: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v144        // 000000030D18: CA100080 85820190
	s_mov_b32 s6, exec_lo                                      // 000000030D20: BE86007E
	.long 0xd4c1007e                                           // 000000030D24: D4C1007E
	v_cndmask_b32_e32 v1, v144, v158, vcc_lo                   // 000000030D28: 02033D90
	s_cbranch_execz 54                                         // 000000030D2C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v144                                   // 000000030D30: 7F040390
	s_mov_b32 s8, 0                                            // 000000030D34: BE880080
	s_set_inst_prefetch_distance 0x1                           // 000000030D38: BF840001
	s_branch 10                                                // 000000030D3C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000030D40: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000030D44: BF870499
	s_and_b32 s13, exec_lo, s10                                // 000000030D48: 8B0D0A7E
	s_or_b32 s8, s13, s8                                       // 000000030D4C: 8C08080D
	s_and_not1_b32 s7, s7, exec_lo                             // 000000030D50: 91077E07
	s_and_b32 s13, s9, exec_lo                                 // 000000030D54: 8B0D7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030D58: BF870009
	s_or_b32 s7, s7, s13                                       // 000000030D5C: 8C070D07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000030D60: 917E087E
	s_cbranch_execz 28                                         // 000000030D64: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000030D68: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 000000030D6C: 7F060382
	s_or_b32 s9, s9, exec_lo                                   // 000000030D70: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 000000030D74: 8C0A7E0A
	s_mov_b32 s13, exec_lo                                     // 000000030D78: BE8D007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000030D7C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030D80: BF870091
	.long 0xd73c0084                                           // 000000030D84: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000030D88: 02030682
	.long 0xd7006a84                                           // 000000030D8C: D7006A84
	v_cndmask_b32_e32 v1, v140, v132, vcc_lo                   // 000000030D90: 0203098C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030D94: BF870001
	v_add_co_ci_u32_e64 v133, null, v141, v133, vcc_lo         // 000000030D98: D5207C85 01AB0B8D
	global_load_b32 v132, v[132:133], off                      // 000000030DA0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 000000030DA8: BF8903F7
	.long 0xd4c4007e                                           // 000000030DAC: D4C4007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 000000030DB0: 02030805
	s_cbranch_execz 65506                                      // 000000030DB4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000030DB8: 4B050681
	s_and_not1_b32 s10, s10, exec_lo                           // 000000030DBC: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000030DC0: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000030DC4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000030DC8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 000000030DCC: 8B1D7E6A
	s_or_b32 s10, s10, s29                                     // 000000030DD0: 8C0A1D0A
	s_branch 65498                                             // 000000030DD4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 000000030DD8: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 000000030DDC: 8C7E087E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 000000030DE0: CA100080 8582019E
	s_and_saveexec_b32 s8, s7                                  // 000000030DE8: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030DEC: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 000000030DF0: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v132                          // 000000030DF4: 7C950805
	v_mov_b32_e32 v130, v131                                   // 000000030DF8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 000000030DFC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s7                              // 000000030E04: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030E08: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 000000030E0C: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030E10: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000030E14: 8C7E017E
	s_or_b32 s6, s5, 1                                         // 000000030E18: 8C068105
	s_mov_b32 s1, exec_lo                                      // 000000030E1C: BE81007E
	.long 0xd4c6007e                                           // 000000030E20: D4C6007E
	v_cndmask_b32_e32 v1, s6, v161, vcc_lo                     // 000000030E24: 02034206
	s_xor_b32 s1, exec_lo, s1                                  // 000000030E28: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 000000030E2C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000030E34: BE813001
	s_cbranch_execz 70                                         // 000000030E38: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s7, exec_lo                                      // 000000030E3C: BE87007E
	.long 0xd4c1007e                                           // 000000030E40: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000030E44: 02033D82
	s_cbranch_execz 64                                         // 000000030E48: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s9, 0                                            // 000000030E4C: BE890080
	s_set_inst_prefetch_distance 0x1                           // 000000030E50: BF840001
	s_branch 20                                                // 000000030E54: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 000000030E58: BF800000
	s_nop 0                                                    // 000000030E5C: BF800000
	s_nop 0                                                    // 000000030E60: BF800000
	s_nop 0                                                    // 000000030E64: BF800000
	s_nop 0                                                    // 000000030E68: BF800000
	s_nop 0                                                    // 000000030E6C: BF800000
	s_nop 0                                                    // 000000030E70: BF800000
	s_nop 0                                                    // 000000030E74: BF800000
	s_nop 0                                                    // 000000030E78: BF800000
	s_nop 0                                                    // 000000030E7C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000030E80: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000030E84: BF870499
	s_and_b32 s29, exec_lo, s13                                // 000000030E88: 8B1D0D7E
	s_or_b32 s9, s29, s9                                       // 000000030E8C: 8C09091D
	s_and_not1_b32 s8, s8, exec_lo                             // 000000030E90: 91087E08
	s_and_b32 s29, s10, exec_lo                                // 000000030E94: 8B1D7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030E98: BF870009
	s_or_b32 s8, s8, s29                                       // 000000030E9C: 8C081D08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000030EA0: 917E097E
	s_cbranch_execz 27                                         // 000000030EA4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 000000030EA8: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 000000030EAC: 8C0A7E0A
	s_or_b32 s13, s13, exec_lo                                 // 000000030EB0: 8C0D7E0D
	s_mov_b32 s29, exec_lo                                     // 000000030EB4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030EB8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000030EBC: 3509069F
	.long 0xd73c0086                                           // 000000030EC0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000030EC4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030EC8: BF870091
	.long 0xd7006a86                                           // 000000030ECC: D7006A86
	v_cndmask_b32_e32 v1, v140, v134, vcc_lo                   // 000000030ED0: 02030D8C
	v_add_co_ci_u32_e64 v135, null, v141, v135, vcc_lo         // 000000030ED4: D5207C87 01AB0F8D
	global_load_b32 v132, v[134:135], off                      // 000000030EDC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000030EE4: BF8903F7
	.long 0xd4c6007e                                           // 000000030EE8: D4C6007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 000000030EEC: 02030805
	s_cbranch_execz 65507                                      // 000000030EF0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000030EF4: 4B050681
	s_and_not1_b32 s13, s13, exec_lo                           // 000000030EF8: 910D7E0D
	s_and_not1_b32 s10, s10, exec_lo                           // 000000030EFC: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000030F00: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000030F04: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000030F08: 8B1E7E6A
	s_or_b32 s13, s13, s30                                     // 000000030F0C: 8C0D1E0D
	s_branch 65499                                             // 000000030F10: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 000000030F14: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 000000030F18: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 000000030F1C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 000000030F20: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030F24: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 000000030F28: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 000000030F2C: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 000000030F30: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030F3C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000030F40: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000030F44: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 000000030F48: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030F4C: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 000000030F50: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030F54: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000030F58: 8C7E017E
	s_or_b32 s6, s5, 2                                         // 000000030F5C: 8C068205
	s_mov_b32 s1, exec_lo                                      // 000000030F60: BE81007E
	.long 0xd4c6007e                                           // 000000030F64: D4C6007E
	v_cndmask_b32_e32 v1, s6, v161, vcc_lo                     // 000000030F68: 02034206
	s_xor_b32 s1, exec_lo, s1                                  // 000000030F6C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000030F70: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000030F78: BE813001
	s_cbranch_execz 69                                         // 000000030F7C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s7, exec_lo                                      // 000000030F80: BE87007E
	.long 0xd4c1007e                                           // 000000030F84: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000030F88: 02033D82
	s_cbranch_execz 63                                         // 000000030F8C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s9, 0                                            // 000000030F90: BE890080
	s_set_inst_prefetch_distance 0x1                           // 000000030F94: BF840001
	s_branch 19                                                // 000000030F98: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 000000030F9C: BF800000
	s_nop 0                                                    // 000000030FA0: BF800000
	s_nop 0                                                    // 000000030FA4: BF800000
	s_nop 0                                                    // 000000030FA8: BF800000
	s_nop 0                                                    // 000000030FAC: BF800000
	s_nop 0                                                    // 000000030FB0: BF800000
	s_nop 0                                                    // 000000030FB4: BF800000
	s_nop 0                                                    // 000000030FB8: BF800000
	s_nop 0                                                    // 000000030FBC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000030FC0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000030FC4: BF870499
	s_and_b32 s29, exec_lo, s13                                // 000000030FC8: 8B1D0D7E
	s_or_b32 s9, s29, s9                                       // 000000030FCC: 8C09091D
	s_and_not1_b32 s8, s8, exec_lo                             // 000000030FD0: 91087E08
	s_and_b32 s29, s10, exec_lo                                // 000000030FD4: 8B1D7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030FD8: BF870009
	s_or_b32 s8, s8, s29                                       // 000000030FDC: 8C081D08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000030FE0: 917E097E
	s_cbranch_execz 27                                         // 000000030FE4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 000000030FE8: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 000000030FEC: 8C0A7E0A
	s_or_b32 s13, s13, exec_lo                                 // 000000030FF0: 8C0D7E0D
	s_mov_b32 s29, exec_lo                                     // 000000030FF4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030FF8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000030FFC: 3509069F
	.long 0xd73c0086                                           // 000000031000: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000031004: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031008: BF870091
	.long 0xd7006a86                                           // 00000003100C: D7006A86
	v_cndmask_b32_e32 v1, v140, v134, vcc_lo                   // 000000031010: 02030D8C
	v_add_co_ci_u32_e64 v135, null, v141, v135, vcc_lo         // 000000031014: D5207C87 01AB0F8D
	global_load_b32 v132, v[134:135], off                      // 00000003101C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000031024: BF8903F7
	.long 0xd4c4007e                                           // 000000031028: D4C4007E
	v_cndmask_b32_e32 v1, s6, v132, vcc_lo                     // 00000003102C: 02030806
	s_cbranch_execz 65507                                      // 000000031030: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000031034: 4B050681
	s_and_not1_b32 s13, s13, exec_lo                           // 000000031038: 910D7E0D
	s_and_not1_b32 s10, s10, exec_lo                           // 00000003103C: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031040: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000031044: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000031048: 8B1E7E6A
	s_or_b32 s13, s13, s30                                     // 00000003104C: 8C0D1E0D
	s_branch 65499                                             // 000000031050: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 000000031054: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 000000031058: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 00000003105C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 000000031060: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031064: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 000000031068: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 00000003106C: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 000000031070: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003107C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000031080: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000031084: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 000000031088: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003108C: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 000000031090: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031094: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031098: 8C7E017E
	s_or_b32 s5, s5, 3                                         // 00000003109C: 8C058305
	s_mov_b32 s1, exec_lo                                      // 0000000310A0: BE81007E
	.long 0xd4c6007e                                           // 0000000310A4: D4C6007E
	v_cndmask_b32_e32 v1, s5, v161, vcc_lo                     // 0000000310A8: 02034205
	s_xor_b32 s1, exec_lo, s1                                  // 0000000310AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000310B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000310B8: BE813001
	s_cbranch_execz 66                                         // 0000000310BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s6, exec_lo                                      // 0000000310C0: BE86007E
	.long 0xd4c1007e                                           // 0000000310C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000310C8: 02033D82
	s_cbranch_execz 60                                         // 0000000310CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s8, 0                                            // 0000000310D0: BE880080
	s_set_inst_prefetch_distance 0x1                           // 0000000310D4: BF840001
	s_branch 19                                                // 0000000310D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 0000000310DC: BF800000
	s_nop 0                                                    // 0000000310E0: BF800000
	s_nop 0                                                    // 0000000310E4: BF800000
	s_nop 0                                                    // 0000000310E8: BF800000
	s_nop 0                                                    // 0000000310EC: BF800000
	s_nop 0                                                    // 0000000310F0: BF800000
	s_nop 0                                                    // 0000000310F4: BF800000
	s_nop 0                                                    // 0000000310F8: BF800000
	s_nop 0                                                    // 0000000310FC: BF800000
	s_or_b32 exec_lo, exec_lo, s13                             // 000000031100: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000031104: BF870499
	s_and_b32 s13, exec_lo, s10                                // 000000031108: 8B0D0A7E
	s_or_b32 s8, s13, s8                                       // 00000003110C: 8C08080D
	s_and_not1_b32 s7, s7, exec_lo                             // 000000031110: 91077E07
	s_and_b32 s13, s9, exec_lo                                 // 000000031114: 8B0D7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031118: BF870009
	s_or_b32 s7, s7, s13                                       // 00000003111C: 8C070D07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000031120: 917E087E
	s_cbranch_execz 26                                         // 000000031124: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000031128: 3507049F
	s_or_b32 s9, s9, exec_lo                                   // 00000003112C: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 000000031130: 8C0A7E0A
	s_mov_b32 s13, exec_lo                                     // 000000031134: BE8D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031138: BF870091
	.long 0xd73c0083                                           // 00000003113C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000031140: 02030482
	.long 0xd7006a83                                           // 000000031144: D7006A83
	v_cndmask_b32_e32 v1, v140, v131, vcc_lo                   // 000000031148: 0203078C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003114C: BF870001
	v_add_co_ci_u32_e64 v132, null, v141, v132, vcc_lo         // 000000031150: D5207C84 01AB098D
	global_load_b32 v131, v[131:132], off                      // 000000031158: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000031160: BF8903F7
	.long 0xd4c4007e                                           // 000000031164: D4C4007E
	v_cndmask_b32_e32 v1, s5, v131, vcc_lo                     // 000000031168: 02030605
	s_cbranch_execz 65508                                      // 00000003116C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 000000031170: 4B050481
	s_and_not1_b32 s10, s10, exec_lo                           // 000000031174: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000031178: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003117C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000031180: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 000000031184: 8B1D7E6A
	s_or_b32 s10, s10, s29                                     // 000000031188: 8C0A1D0A
	s_branch 65500                                             // 00000003118C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 000000031190: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 000000031194: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000031198: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003119C: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 0000000311A0: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v131                          // 0000000311A4: 7C950605
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000311A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000311B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000311B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000311BC: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000311C0: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000311C4: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000311C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000311CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000311D0: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000311D4: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 0000000311D8: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 0000000311E0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 0000000311E4: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000311E8: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000311F0: BF870001
	v_readfirstlane_b32 s1, v130                               // 0000000311F4: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 0000000311F8: BF0C8001
	s_mov_b32 s1, 0                                            // 0000000311FC: BE810080
	s_cbranch_scc1 8                                           // 000000031200: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1524>
	s_or_b32 s1, s2, 15                                        // 000000031204: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031208: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v139                          // 00000003120C: 7C871601
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 000000031210: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 000000031218: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 00000003121C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000031220: 980180C1
	s_and_saveexec_b32 s13, s3                                 // 000000031224: BE8D2003
	s_cbranch_execz 1299                                       // 000000031228: BFA50513 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2978>
	ds_load_b32 v130, v163                                     // 00000003122C: D8D80000 820000A3
	s_xor_b32 s1, s1, -1                                       // 000000031234: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031238: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000003123C: 916A017E
	s_mov_b32 s1, -1                                           // 000000031240: BE8100C1
	s_cbranch_vccnz 798                                        // 000000031244: BFA4031E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21c0>
	v_and_b32_e32 v131, 1, v133                                // 000000031248: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 00000003124C: 7C874402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000031250: BF8704C2
	.long 0xd44a0001                                           // 000000031254: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 000000031258: 02030681
	s_waitcnt lgkmcnt(0)                                       // 00000003125C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 000000031260: 7F060382
	s_and_b32 s37, vcc_lo, s1                                  // 000000031264: 8B25016A
	s_and_saveexec_b32 s1, s37                                 // 000000031268: BE812025
	s_cbranch_execz 7                                          // 00000003126C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	ds_load_b32 v131, v164                                     // 000000031270: D8D80000 830000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031278: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 00000003127C: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031284: BF870001
	v_max_f32_e32 v131, v132, v131                             // 000000031288: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003128C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 000000031290: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 000000031294: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031298: BF8704A2
	.long 0xd44d0001                                           // 00000003129C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000312A0: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 0000000312A4: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 0000000312A8: BE812024
	s_cbranch_execz 7                                          // 0000000312AC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v164 offset:4                            // 0000000312B0: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000312B8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000312BC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000312C4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000312C8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000312CC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000312D0: 37090A84
	s_or_b32 s1, s2, 2                                         // 0000000312D4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000312D8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000312DC: 7C874401
	.long 0xd44d0001                                           // 0000000312E0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000312E4: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000312E8: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000312EC: BF870009
	s_and_saveexec_b32 s1, s34                                 // 0000000312F0: BE812022
	s_cbranch_execz 7                                          // 0000000312F4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v164 offset:8                            // 0000000312F8: D8D80008 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031300: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031304: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003130C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031310: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031314: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 000000031318: 37090A88
	s_or_b32 s1, s2, 3                                         // 00000003131C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031320: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000031324: 7C874401
	.long 0xd44d0001                                           // 000000031328: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003132C: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 000000031330: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031334: BF870009
	s_and_saveexec_b32 s1, s35                                 // 000000031338: BE812023
	s_cbranch_execz 7                                          // 00000003133C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x165c>
	ds_load_b32 v132, v164 offset:12                           // 000000031340: D8D8000C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031348: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003134C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031354: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031358: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003135C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 000000031360: 37090A90
	s_or_b32 s1, s2, 4                                         // 000000031364: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031368: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000003136C: 7C874401
	.long 0xd44d0001                                           // 000000031370: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031374: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 000000031378: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003137C: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000031380: BE81201F
	s_cbranch_execz 7                                          // 000000031384: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16a4>
	ds_load_b32 v132, v164 offset:16                           // 000000031388: D8D80010 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031390: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031394: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003139C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000313A0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000313A4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000313A8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 0000000313AC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000313B0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000313B4: 7C874401
	.long 0xd44d0001                                           // 0000000313B8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000313BC: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000313C0: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000313C4: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000313C8: BE812021
	s_cbranch_execz 7                                          // 0000000313CC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ec>
	ds_load_b32 v132, v164 offset:20                           // 0000000313D0: D8D80014 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000313D8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000313DC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000313E4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000313E8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000313EC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000313F0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 0000000313F4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000313F8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000313FC: 7C874401
	.long 0xd44d0001                                           // 000000031400: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031404: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 000000031408: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003140C: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000031410: BE81201D
	s_cbranch_execz 7                                          // 000000031414: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1734>
	ds_load_b32 v132, v164 offset:24                           // 000000031418: D8D80018 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031420: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031424: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003142C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031430: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031434: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 000000031438: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 000000031440: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031444: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000031448: 7C874401
	.long 0xd44d0001                                           // 00000003144C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031450: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 000000031454: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031458: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000003145C: BE81201E
	s_cbranch_execz 7                                          // 000000031460: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	ds_load_b32 v132, v164 offset:28                           // 000000031464: D8D8001C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 00000003146C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031470: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031478: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003147C: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031480: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 000000031484: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000003148C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031490: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000031494: 7C874401
	.long 0xd44d0001                                           // 000000031498: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003149C: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000314A0: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000314A4: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000314A8: BE812009
	s_cbranch_execz 7                                          // 0000000314AC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17cc>
	ds_load_b32 v132, v164 offset:32                           // 0000000314B0: D8D80020 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000314B8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000314BC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000314C4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000314C8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000314CC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000314D0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000314D8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000314DC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000314E0: 7C874401
	.long 0xd44d0001                                           // 0000000314E4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000314E8: 02030880
	s_and_b32 s10, vcc_lo, s1                                  // 0000000314EC: 8B0A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000314F0: BF870009
	s_and_saveexec_b32 s1, s10                                 // 0000000314F4: BE81200A
	s_cbranch_execz 7                                          // 0000000314F8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1818>
	ds_load_b32 v132, v164 offset:36                           // 0000000314FC: D8D80024 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031504: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031508: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031510: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031514: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031518: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000003151C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 000000031524: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031528: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000003152C: 7C874401
	.long 0xd44d0001                                           // 000000031530: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031534: 02030880
	s_and_b32 s7, vcc_lo, s1                                   // 000000031538: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003153C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 000000031540: BE812007
	s_cbranch_execz 7                                          // 000000031544: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1864>
	ds_load_b32 v132, v164 offset:40                           // 000000031548: D8D80028 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031550: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031554: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003155C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031560: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031564: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 000000031568: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000031570: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031574: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000031578: 7C874401
	.long 0xd44d0001                                           // 00000003157C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031580: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 000000031584: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031588: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000003158C: BE812008
	s_cbranch_execz 7                                          // 000000031590: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18b0>
	ds_load_b32 v132, v164 offset:44                           // 000000031594: D8D8002C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 00000003159C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000315A0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000315A8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000315AC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000315B0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000315B4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000315BC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000315C0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000315C4: 7C874401
	.long 0xd44d0001                                           // 0000000315C8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000315CC: 02030880
	s_and_b32 s5, vcc_lo, s1                                   // 0000000315D0: 8B05016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000315D4: BF870009
	s_and_saveexec_b32 s1, s5                                  // 0000000315D8: BE812005
	s_cbranch_execz 7                                          // 0000000315DC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18fc>
	ds_load_b32 v132, v164 offset:48                           // 0000000315E0: D8D80030 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000315E8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000315EC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000315F4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000315F8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000315FC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 000000031600: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 000000031608: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003160C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000031610: 7C874401
	.long 0xd44d0001                                           // 000000031614: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031618: 02030880
	s_and_b32 s6, vcc_lo, s1                                   // 00000003161C: 8B06016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031620: BF870009
	s_and_saveexec_b32 s1, s6                                  // 000000031624: BE812006
	s_cbranch_execz 7                                          // 000000031628: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1948>
	ds_load_b32 v132, v164 offset:52                           // 00000003162C: D8D80034 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031634: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031638: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031640: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031644: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031648: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000003164C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000031654: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031658: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000003165C: 7C874401
	.long 0xd44d0001                                           // 000000031660: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000031664: 02030880
	s_and_b32 s4, vcc_lo, s1                                   // 000000031668: 8B04016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003166C: BF870009
	s_and_saveexec_b32 s1, s4                                  // 000000031670: BE812004
	s_cbranch_execz 7                                          // 000000031674: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v164 offset:56                           // 000000031678: D8D80038 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031680: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000031684: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003168C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000031690: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000031694: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 000000031698: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000316A0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000316A4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000316A8: 7C874402
	.long 0xd44d0001                                           // 0000000316AC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000316B0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000316B4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000316B8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000316BC: BE822001
	s_cbranch_execz 7                                          // 0000000316C0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v164 offset:60                           // 0000000316C4: D8D8003C 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000316CC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 0000000316D0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000316D8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 0000000316DC: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000316E0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000316E4: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 0000000316EC: BE822025
	s_cbranch_execz 18                                         // 0000000316F0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a3c>
	ds_load_b32 v133, v164                                     // 0000000316F4: D8D80000 850000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000316FC: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 000000031700: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031704: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v133                  // 000000031708: 7C290AFF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 000000031710: D5010086 01A9FE80 42800000
	v_add_f32_e32 v133, v133, v134                             // 00000003171C: 070B0D85
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 000000031720: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003172C: BF870292
	v_exp_f32_e32 v133, v133                                   // 000000031730: 7F0A4B85
	.long 0xd71c0085                                           // 000000031734: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 000000031738: 02030D85
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003173C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031740: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 000000031744: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000003174C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 000000031758: DA840000 000086A5
	s_and_saveexec_b32 s2, s36                                 // 000000031760: BE822024
	s_cbranch_execz 18                                         // 000000031764: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ab0>
	ds_load_b32 v132, v164 offset:4                            // 000000031768: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031770: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 000000031774: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031778: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 00000003177C: 7C2908FF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 000000031784: D5010086 01A9FE80 42800000
	v_add_f32_e32 v132, v132, v134                             // 000000031790: 07090D84
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 000000031794: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000317A0: BF870292
	v_exp_f32_e32 v132, v132                                   // 0000000317A4: 7F084B84
	.long 0xd71c0084                                           // 0000000317A8: D71C0084
	v_cndmask_b32_e32 v1, v132, v134, vcc_lo                   // 0000000317AC: 02030D84
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000317B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000317B4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000317B8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000317C0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000317C4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000317D0: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 0000000317D4: DA840002 000088A5
	s_and_saveexec_b32 s2, s34                                 // 0000000317DC: BE822022
	s_cbranch_execz 18                                         // 0000000317E0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b2c>
	ds_load_b32 v135, v164 offset:8                            // 0000000317E4: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000317EC: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 0000000317F0: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000317F4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v135                  // 0000000317F8: 7C290EFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 000000031800: D5010088 01A9FE80 42800000
	v_add_f32_e32 v135, v135, v136                             // 00000003180C: 070F1187
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 000000031810: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003181C: BF870292
	v_exp_f32_e32 v135, v135                                   // 000000031820: 7F0E4B87
	.long 0xd71c0087                                           // 000000031824: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 000000031828: 02031187
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003182C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031830: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 000000031834: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000003183C: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 000000031848: DA840004 000088A5
	s_and_saveexec_b32 s2, s35                                 // 000000031850: BE822023
	s_cbranch_execz 18                                         // 000000031854: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ba0>
	ds_load_b32 v134, v164 offset:12                           // 000000031858: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031860: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 000000031864: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031868: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v134                  // 00000003186C: 7C290CFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 000000031874: D5010088 01A9FE80 42800000
	v_add_f32_e32 v134, v134, v136                             // 000000031880: 070D1186
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 000000031884: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031890: BF870292
	v_exp_f32_e32 v134, v134                                   // 000000031894: 7F0C4B86
	.long 0xd71c0086                                           // 000000031898: D71C0086
	v_cndmask_b32_e32 v1, v134, v136, vcc_lo                   // 00000003189C: 02031186
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000318A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000318A4: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000318A8: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000318B0: 7F120280
	v_add3_u32 v145, v134, v136, 0x7fff                        // 0000000318B4: D6550091 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000318C0: 7F100280
	ds_store_b16_d16_hi v165, v145 offset:6                    // 0000000318C4: DA840006 000091A5
	s_and_saveexec_b32 s2, s31                                 // 0000000318CC: BE82201F
	s_cbranch_execz 18                                         // 0000000318D0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c1c>
	ds_load_b32 v137, v164 offset:16                           // 0000000318D4: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000318DC: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 0000000318E0: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000318E4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v137                  // 0000000318E8: 7C2912FF C2FC0000
	v_cndmask_b32_e64 v145, 0, 0x42800000, vcc_lo              // 0000000318F0: D5010091 01A9FE80 42800000
	v_add_f32_e32 v137, v137, v145                             // 0000000318FC: 07132389
	v_cndmask_b32_e64 v145, 0, 0xffffffc0, vcc_lo              // 000000031900: D5010091 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003190C: BF870292
	v_exp_f32_e32 v137, v137                                   // 000000031910: 7F124B89
	.long 0xd71c0089                                           // 000000031914: D71C0089
	v_cndmask_b32_e32 v1, v137, v145, vcc_lo                   // 000000031918: 02032389
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003191C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031920: BF870091
	v_bfe_u32 v145, v137, 16, 1                                // 000000031924: D6100091 02052189
	v_add3_u32 v145, v137, v145, 0x7fff                        // 00000003192C: D6550091 03FF2389 00007FFF
	ds_store_b16_d16_hi v165, v145 offset:8                    // 000000031938: DA840008 000091A5
	s_and_saveexec_b32 s2, s33                                 // 000000031940: BE822021
	s_cbranch_execz 18                                         // 000000031944: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c90>
	ds_load_b32 v136, v164 offset:20                           // 000000031948: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031950: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 000000031954: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031958: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v136                  // 00000003195C: 7C2910FF C2FC0000
	v_cndmask_b32_e64 v145, 0, 0x42800000, vcc_lo              // 000000031964: D5010091 01A9FE80 42800000
	v_add_f32_e32 v136, v136, v145                             // 000000031970: 07112388
	v_cndmask_b32_e64 v145, 0, 0xffffffc0, vcc_lo              // 000000031974: D5010091 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031980: BF870292
	v_exp_f32_e32 v136, v136                                   // 000000031984: 7F104B88
	.long 0xd71c0088                                           // 000000031988: D71C0088
	v_cndmask_b32_e32 v1, v136, v145, vcc_lo                   // 00000003198C: 02032388
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031990: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031994: BF870121
	v_bfe_u32 v145, v136, 16, 1                                // 000000031998: D6100091 02052188
	v_mov_b32_e32 v146, 0                                      // 0000000319A0: 7F240280
	v_add3_u32 v147, v136, v145, 0x7fff                        // 0000000319A4: D6550093 03FF2388 00007FFF
	v_mov_b32_e32 v145, 0                                      // 0000000319B0: 7F220280
	ds_store_b16_d16_hi v165, v147 offset:10                   // 0000000319B4: DA84000A 000093A5
	s_and_saveexec_b32 s2, s29                                 // 0000000319BC: BE82201D
	s_cbranch_execz 18                                         // 0000000319C0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d0c>
	ds_load_b32 v146, v164 offset:24                           // 0000000319C4: D8D80018 920000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000319CC: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 0000000319D0: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000319D4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v146                  // 0000000319D8: 7C2924FF C2FC0000
	v_cndmask_b32_e64 v147, 0, 0x42800000, vcc_lo              // 0000000319E0: D5010093 01A9FE80 42800000
	v_add_f32_e32 v146, v146, v147                             // 0000000319EC: 07252792
	v_cndmask_b32_e64 v147, 0, 0xffffffc0, vcc_lo              // 0000000319F0: D5010093 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000319FC: BF870292
	v_exp_f32_e32 v146, v146                                   // 000000031A00: 7F244B92
	.long 0xd71c0092                                           // 000000031A04: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 000000031A08: 02032792
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031A0C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031A10: BF870091
	v_bfe_u32 v147, v146, 16, 1                                // 000000031A14: D6100093 02052192
	v_add3_u32 v147, v146, v147, 0x7fff                        // 000000031A1C: D6550093 03FF2792 00007FFF
	ds_store_b16_d16_hi v165, v147 offset:12                   // 000000031A28: DA84000C 000093A5
	s_and_saveexec_b32 s2, s30                                 // 000000031A30: BE82201E
	s_cbranch_execz 18                                         // 000000031A34: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d80>
	ds_load_b32 v145, v164 offset:28                           // 000000031A38: D8D8001C 910000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031A40: BF89FC07
	v_sub_f32_e32 v145, v145, v131                             // 000000031A44: 09230791
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031A48: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v145                  // 000000031A4C: 7C2922FF C2FC0000
	v_cndmask_b32_e64 v147, 0, 0x42800000, vcc_lo              // 000000031A54: D5010093 01A9FE80 42800000
	v_add_f32_e32 v145, v145, v147                             // 000000031A60: 07232791
	v_cndmask_b32_e64 v147, 0, 0xffffffc0, vcc_lo              // 000000031A64: D5010093 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031A70: BF870292
	v_exp_f32_e32 v145, v145                                   // 000000031A74: 7F224B91
	.long 0xd71c0091                                           // 000000031A78: D71C0091
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 000000031A7C: 02032791
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031A80: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031A84: BF870121
	v_bfe_u32 v147, v145, 16, 1                                // 000000031A88: D6100093 02052191
	v_mov_b32_e32 v148, 0                                      // 000000031A90: 7F280280
	v_add3_u32 v149, v145, v147, 0x7fff                        // 000000031A94: D6550095 03FF2791 00007FFF
	v_mov_b32_e32 v147, 0                                      // 000000031AA0: 7F260280
	ds_store_b16_d16_hi v165, v149 offset:14                   // 000000031AA4: DA84000E 000095A5
	s_and_saveexec_b32 s2, s9                                  // 000000031AAC: BE822009
	s_cbranch_execz 18                                         // 000000031AB0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dfc>
	ds_load_b32 v148, v164 offset:32                           // 000000031AB4: D8D80020 940000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031ABC: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 000000031AC0: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031AC4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v148                  // 000000031AC8: 7C2928FF C2FC0000
	v_cndmask_b32_e64 v149, 0, 0x42800000, vcc_lo              // 000000031AD0: D5010095 01A9FE80 42800000
	v_add_f32_e32 v148, v148, v149                             // 000000031ADC: 07292B94
	v_cndmask_b32_e64 v149, 0, 0xffffffc0, vcc_lo              // 000000031AE0: D5010095 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031AEC: BF870292
	v_exp_f32_e32 v148, v148                                   // 000000031AF0: 7F284B94
	.long 0xd71c0094                                           // 000000031AF4: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 000000031AF8: 02032B94
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031AFC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031B00: BF870091
	v_bfe_u32 v149, v148, 16, 1                                // 000000031B04: D6100095 02052194
	v_add3_u32 v149, v148, v149, 0x7fff                        // 000000031B0C: D6550095 03FF2B94 00007FFF
	ds_store_b16_d16_hi v165, v149 offset:16                   // 000000031B18: DA840010 000095A5
	s_and_saveexec_b32 s2, s10                                 // 000000031B20: BE82200A
	s_cbranch_execz 18                                         // 000000031B24: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e70>
	ds_load_b32 v147, v164 offset:36                           // 000000031B28: D8D80024 930000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031B30: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 000000031B34: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031B38: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v147                  // 000000031B3C: 7C2926FF C2FC0000
	v_cndmask_b32_e64 v149, 0, 0x42800000, vcc_lo              // 000000031B44: D5010095 01A9FE80 42800000
	v_add_f32_e32 v147, v147, v149                             // 000000031B50: 07272B93
	v_cndmask_b32_e64 v149, 0, 0xffffffc0, vcc_lo              // 000000031B54: D5010095 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031B60: BF870292
	v_exp_f32_e32 v147, v147                                   // 000000031B64: 7F264B93
	.long 0xd71c0093                                           // 000000031B68: D71C0093
	v_cndmask_b32_e32 v1, v147, v149, vcc_lo                   // 000000031B6C: 02032B93
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031B70: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031B74: BF870121
	v_bfe_u32 v149, v147, 16, 1                                // 000000031B78: D6100095 02052193
	v_mov_b32_e32 v150, 0                                      // 000000031B80: 7F2C0280
	v_add3_u32 v151, v147, v149, 0x7fff                        // 000000031B84: D6550097 03FF2B93 00007FFF
	v_mov_b32_e32 v149, 0                                      // 000000031B90: 7F2A0280
	ds_store_b16_d16_hi v165, v151 offset:18                   // 000000031B94: DA840012 000097A5
	s_and_saveexec_b32 s2, s7                                  // 000000031B9C: BE822007
	s_cbranch_execz 18                                         // 000000031BA0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1eec>
	ds_load_b32 v150, v164 offset:40                           // 000000031BA4: D8D80028 960000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031BAC: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 000000031BB0: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031BB4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v150                  // 000000031BB8: 7C292CFF C2FC0000
	v_cndmask_b32_e64 v151, 0, 0x42800000, vcc_lo              // 000000031BC0: D5010097 01A9FE80 42800000
	v_add_f32_e32 v150, v150, v151                             // 000000031BCC: 072D2F96
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, vcc_lo              // 000000031BD0: D5010097 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031BDC: BF870292
	v_exp_f32_e32 v150, v150                                   // 000000031BE0: 7F2C4B96
	.long 0xd71c0096                                           // 000000031BE4: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000031BE8: 02032F96
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031BEC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031BF0: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 000000031BF4: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 000000031BFC: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v165, v151 offset:20                   // 000000031C08: DA840014 000097A5
	s_and_saveexec_b32 s2, s8                                  // 000000031C10: BE822008
	s_cbranch_execz 18                                         // 000000031C14: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f60>
	ds_load_b32 v149, v164 offset:44                           // 000000031C18: D8D8002C 950000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031C20: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 000000031C24: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031C28: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v149                  // 000000031C2C: 7C292AFF C2FC0000
	v_cndmask_b32_e64 v151, 0, 0x42800000, vcc_lo              // 000000031C34: D5010097 01A9FE80 42800000
	v_add_f32_e32 v149, v149, v151                             // 000000031C40: 072B2F95
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, vcc_lo              // 000000031C44: D5010097 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031C50: BF870292
	v_exp_f32_e32 v149, v149                                   // 000000031C54: 7F2A4B95
	.long 0xd71c0095                                           // 000000031C58: D71C0095
	v_cndmask_b32_e32 v1, v149, v151, vcc_lo                   // 000000031C5C: 02032F95
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031C60: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031C64: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 000000031C68: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 000000031C70: 7F300280
	v_add3_u32 v177, v149, v151, 0x7fff                        // 000000031C74: D65500B1 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 000000031C80: 7F2E0280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 000000031C84: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s5                                  // 000000031C8C: BE822005
	s_cbranch_execz 18                                         // 000000031C90: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fdc>
	ds_load_b32 v152, v164 offset:48                           // 000000031C94: D8D80030 980000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031C9C: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 000000031CA0: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031CA4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v152                  // 000000031CA8: 7C2930FF C2FC0000
	v_cndmask_b32_e64 v177, 0, 0x42800000, vcc_lo              // 000000031CB0: D50100B1 01A9FE80 42800000
	v_add_f32_e32 v152, v152, v177                             // 000000031CBC: 07316398
	v_cndmask_b32_e64 v177, 0, 0xffffffc0, vcc_lo              // 000000031CC0: D50100B1 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031CCC: BF870292
	v_exp_f32_e32 v152, v152                                   // 000000031CD0: 7F304B98
	.long 0xd71c0098                                           // 000000031CD4: D71C0098
	v_cndmask_b32_e32 v1, v152, v177, vcc_lo                   // 000000031CD8: 02036398
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031CDC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031CE0: BF870091
	v_bfe_u32 v177, v152, 16, 1                                // 000000031CE4: D61000B1 02052198
	v_add3_u32 v177, v152, v177, 0x7fff                        // 000000031CEC: D65500B1 03FF6398 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 000000031CF8: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s6                                  // 000000031D00: BE822006
	s_cbranch_execz 18                                         // 000000031D04: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2050>
	ds_load_b32 v151, v164 offset:52                           // 000000031D08: D8D80034 970000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031D10: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 000000031D14: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031D18: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v151                  // 000000031D1C: 7C292EFF C2FC0000
	v_cndmask_b32_e64 v177, 0, 0x42800000, vcc_lo              // 000000031D24: D50100B1 01A9FE80 42800000
	v_add_f32_e32 v151, v151, v177                             // 000000031D30: 072F6397
	v_cndmask_b32_e64 v177, 0, 0xffffffc0, vcc_lo              // 000000031D34: D50100B1 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031D40: BF870292
	v_exp_f32_e32 v151, v151                                   // 000000031D44: 7F2E4B97
	.long 0xd71c0097                                           // 000000031D48: D71C0097
	v_cndmask_b32_e32 v1, v151, v177, vcc_lo                   // 000000031D4C: 02036397
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031D50: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031D54: BF870121
	v_bfe_u32 v177, v151, 16, 1                                // 000000031D58: D61000B1 02052197
	v_mov_b32_e32 v178, 0                                      // 000000031D60: 7F640280
	v_add3_u32 v179, v151, v177, 0x7fff                        // 000000031D64: D65500B3 03FF6397 00007FFF
	v_mov_b32_e32 v177, 0                                      // 000000031D70: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 000000031D74: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s4                                  // 000000031D7C: BE822004
	s_cbranch_execz 18                                         // 000000031D80: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20cc>
	ds_load_b32 v178, v164 offset:56                           // 000000031D84: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031D8C: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 000000031D90: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031D94: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v178                  // 000000031D98: 7C2964FF C2FC0000
	v_cndmask_b32_e64 v179, 0, 0x42800000, vcc_lo              // 000000031DA0: D50100B3 01A9FE80 42800000
	v_add_f32_e32 v178, v178, v179                             // 000000031DAC: 076567B2
	v_cndmask_b32_e64 v179, 0, 0xffffffc0, vcc_lo              // 000000031DB0: D50100B3 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031DBC: BF870292
	v_exp_f32_e32 v178, v178                                   // 000000031DC0: 7F644BB2
	.long 0xd71c00b2                                           // 000000031DC4: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000031DC8: 020367B2
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031DCC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031DD0: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 000000031DD4: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 000000031DDC: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 000000031DE8: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 000000031DF0: BE822001
	s_cbranch_execz 18                                         // 000000031DF4: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2140>
	ds_load_b32 v177, v164 offset:60                           // 000000031DF8: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 000000031E00: BF89FC07
	v_sub_f32_e32 v177, v177, v131                             // 000000031E04: 096307B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031E08: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v177                  // 000000031E0C: 7C2962FF C2FC0000
	v_cndmask_b32_e64 v179, 0, 0x42800000, vcc_lo              // 000000031E14: D50100B3 01A9FE80 42800000
	v_add_f32_e32 v177, v177, v179                             // 000000031E20: 076367B1
	v_cndmask_b32_e64 v179, 0, 0xffffffc0, vcc_lo              // 000000031E24: D50100B3 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031E30: BF870292
	v_exp_f32_e32 v177, v177                                   // 000000031E34: 7F624BB1
	.long 0xd71c00b1                                           // 000000031E38: D71C00B1
	v_cndmask_b32_e32 v1, v177, v179, vcc_lo                   // 000000031E3C: 020367B1
	s_or_b32 exec_lo, exec_lo, s2                              // 000000031E40: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 000000031E44: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031E48: BF870122
	v_bfe_u32 v133, v177, 16, 1                                // 000000031E4C: D6100085 020521B1
	s_mov_b32 s1, 0                                            // 000000031E54: BE810080
	v_add_f32_e32 v132, v132, v135                             // 000000031E58: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031E5C: BF870112
	v_add3_u32 v133, v177, v133, 0x7fff                        // 000000031E60: D6550085 03FF0BB1 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 000000031E6C: 07090D84
	ds_store_b16_d16_hi v165, v133 offset:30                   // 000000031E70: DA84001E 000085A5
	v_add_f32_e32 v132, v132, v137                             // 000000031E78: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031E7C: BF870091
	v_add_f32_e32 v132, v132, v136                             // 000000031E80: 07091184
	v_add_f32_e32 v132, v132, v146                             // 000000031E84: 07092584
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031E88: BF870091
	v_add_f32_e32 v132, v132, v145                             // 000000031E8C: 07092384
	v_add_f32_e32 v132, v132, v148                             // 000000031E90: 07092984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031E94: BF870091
	v_add_f32_e32 v132, v132, v147                             // 000000031E98: 07092784
	v_add_f32_e32 v132, v132, v150                             // 000000031E9C: 07092D84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031EA0: BF870091
	v_add_f32_e32 v132, v132, v149                             // 000000031EA4: 07092B84
	v_add_f32_e32 v132, v132, v152                             // 000000031EA8: 07093184
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031EAC: BF870091
	v_add_f32_e32 v132, v132, v151                             // 000000031EB0: 07092F84
	v_add_f32_e32 v132, v132, v178                             // 000000031EB4: 07096584
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031EB8: BF870001
	v_add_f32_e32 v132, v132, v177                             // 000000031EBC: 07096384
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000031EC0: 8B6A017E
	s_cbranch_vccz 460                                         // 000000031EC4: BFA301CC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x28f8>
	ds_load_2addr_b32 v[132:133], v164 offset1:1               // 000000031EC8: D8DC0100 840000A4
	ds_load_2addr_b32 v[134:135], v164 offset0:2 offset1:3     // 000000031ED0: D8DC0302 860000A4
	ds_load_2addr_b32 v[136:137], v164 offset0:4 offset1:5     // 000000031ED8: D8DC0504 880000A4
	ds_load_2addr_b32 v[145:146], v164 offset0:6 offset1:7     // 000000031EE0: D8DC0706 910000A4
	ds_load_2addr_b32 v[147:148], v164 offset0:8 offset1:9     // 000000031EE8: D8DC0908 930000A4
	ds_load_2addr_b32 v[149:150], v164 offset0:10 offset1:11   // 000000031EF0: D8DC0B0A 950000A4
	ds_load_2addr_b32 v[151:152], v164 offset0:12 offset1:13   // 000000031EF8: D8DC0D0C 970000A4
	ds_load_2addr_b32 v[177:178], v164 offset0:14 offset1:15   // 000000031F00: D8DC0F0E B10000A4
	.long 0xd59c40b3                                           // 000000031F08: D59C40B3
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 000000031F0C: 02010080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031F10: BF870001
	.long 0xd59c48b5                                           // 000000031F14: D59C48B5
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000031F18: 020101B3
	.long 0xd59c48b4                                           // 000000031F1C: D59C48B4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000031F20: 020101B3
	.long 0xd59c48b6                                           // 000000031F24: D59C48B6
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000031F28: 020101B3
	.long 0xd59c48b7                                           // 000000031F2C: D59C48B7
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000031F30: 020101B3
	s_waitcnt lgkmcnt(7)                                       // 000000031F34: BF89FC77
	v_max3_f32 v131, v130, v132, v133                          // 000000031F38: D61C0083 06170982
	s_waitcnt lgkmcnt(6)                                       // 000000031F40: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031F44: BF8700A1
	v_max3_f32 v131, v131, v134, v135                          // 000000031F48: D61C0083 061F0D83
	s_waitcnt lgkmcnt(5)                                       // 000000031F50: BF89FC57
	v_max3_f32 v131, v131, v136, v137                          // 000000031F54: D61C0083 06271183
	s_waitcnt lgkmcnt(4)                                       // 000000031F5C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031F60: BF8700A1
	v_max3_f32 v131, v131, v145, v146                          // 000000031F64: D61C0083 064B2383
	s_waitcnt lgkmcnt(3)                                       // 000000031F6C: BF89FC37
	v_max3_f32 v131, v131, v147, v148                          // 000000031F70: D61C0083 06532783
	s_waitcnt lgkmcnt(2)                                       // 000000031F78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031F7C: BF8700A1
	v_max3_f32 v131, v131, v149, v150                          // 000000031F80: D61C0083 065B2B83
	s_waitcnt lgkmcnt(1)                                       // 000000031F88: BF89FC17
	v_max3_f32 v131, v131, v151, v152                          // 000000031F8C: D61C0083 06632F83
	s_waitcnt lgkmcnt(0)                                       // 000000031F94: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031F98: BF870091
	v_max3_f32 v131, v131, v177, v178                          // 000000031F9C: D61C0083 06CB6383
	v_sub_f32_e32 v132, v132, v131                             // 000000031FA4: 09090784
	v_sub_f32_e32 v178, v178, v131                             // 000000031FA8: 096507B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031FAC: BF8700A2
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 000000031FB0: 7C2908FF C2FC0000
	v_cndmask_b32_e64 v184, 0, 0x42800000, vcc_lo              // 000000031FB8: D50100B8 01A9FE80 42800000
	v_dual_sub_f32 v133, v133, v131 :: v_dual_add_f32 v132, v132, v184// 000000031FC4: C9490785 85857184
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000031FCC: BF8701A1
	.long 0xd4140001                                           // 000000031FD0: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v133, vcc_lo             // 000000031FD4: 02030AFF C2FC0000
	v_cndmask_b32_e64 v184, 0, 0xffffffc0, vcc_lo              // 000000031FDC: D50100B8 01A9FE80 FFFFFFC0
	v_exp_f32_e32 v132, v132                                   // 000000031FE8: 7F084B84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031FEC: BF870092
	v_cndmask_b32_e64 v185, 0, 0x42800000, s1                  // 000000031FF0: D50100B9 0005FE80 42800000
	v_add_f32_e32 v133, v133, v185                             // 000000031FFC: 070B7385
	v_cndmask_b32_e64 v185, 0, 0xffffffc0, s1                  // 000000032000: D50100B9 0005FE80 FFFFFFC0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003200C: BF870195
	.long 0xd71c0084                                           // 000000032010: D71C0084
	v_cndmask_b32_e32 v1, v132, v184, vcc_lo                   // 000000032014: 02037184
	v_exp_f32_e32 v133, v133                                   // 000000032018: 7F0A4B85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003201C: BF870091
	.long 0xd59c08b4                                           // 000000032020: D59C08B4
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000032024: 02010184
	v_and_b32_e32 v180, 1, v180                                // 000000032028: 37696881
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003202C: BF870095
	.long 0xd71c0085                                           // 000000032030: D71C0085
	v_cndmask_b32_e32 v1, v133, v185, vcc_lo                   // 000000032034: 02037385
	v_dual_sub_f32 v147, v147, v131 :: v_dual_add_f32 v184, v132, v133// 000000032038: C9490793 93B90B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000032040: BF8701B1
	.long 0xd414000a                                           // 000000032044: D414000A
	v_cndmask_b32_e32 v1, 0xc2fc0000, v147, vcc_lo             // 000000032048: 020326FF C2FC0000
	.long 0xd59c08b3                                           // 000000032050: D59C08B3
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000032054: 02010185
	v_add3_u32 v132, v132, v180, 0x7fff                        // 000000032058: D6550084 03FF6984 00007FFF
	v_cndmask_b32_e64 v193, 0, 0x42800000, s10                 // 000000032064: D50100C1 0029FE80 42800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032070: BF870091
	v_dual_sub_f32 v146, v146, v131 :: v_dual_add_f32 v147, v147, v193// 000000032074: C9490792 92938393
	.long 0xd4140007                                           // 00000003207C: D4140007
	v_cndmask_b32_e32 v1, 0xc2fc0000, v146, vcc_lo             // 000000032080: 020324FF C2FC0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032088: BF870092
	v_exp_f32_e32 v147, v147                                   // 00000003208C: 7F264B93
	v_cndmask_b32_e64 v190, 0, 0x42800000, s7                  // 000000032090: D50100BE 001DFE80 42800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003209C: BF870091
	v_dual_sub_f32 v137, v137, v131 :: v_dual_add_f32 v146, v146, v190// 0000000320A0: C9490789 89937D92
	.long 0xd4140005                                           // 0000000320A8: D4140005
	v_cndmask_b32_e32 v1, 0xc2fc0000, v137, vcc_lo             // 0000000320AC: 020312FF C2FC0000
	v_cndmask_b32_e64 v190, 0, 0xffffffc0, s7                  // 0000000320B4: D50100BE 001DFE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000320C0: BF870113
	v_exp_f32_e32 v146, v146                                   // 0000000320C4: 7F244B92
	v_cndmask_b32_e64 v188, 0, 0x42800000, s5                  // 0000000320C8: D50100BC 0015FE80 42800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000320D4: BF870091
	v_dual_sub_f32 v136, v136, v131 :: v_dual_add_f32 v137, v137, v188// 0000000320D8: C9490788 88897989
	.long 0xd4140006                                           // 0000000320E0: D4140006
	v_cndmask_b32_e32 v1, 0xc2fc0000, v136, vcc_lo             // 0000000320E4: 020310FF C2FC0000
	v_cndmask_b32_e64 v188, 0, 0xffffffc0, s5                  // 0000000320EC: D50100BC 0015FE80 FFFFFFC0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000320F8: BF870215
	.long 0xd71c0092                                           // 0000000320FC: D71C0092
	v_cndmask_b32_e32 v1, v146, v190, vcc_lo                   // 000000032100: 02037D92
	v_exp_f32_e32 v137, v137                                   // 000000032104: 7F124B89
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032108: BF870093
	v_cndmask_b32_e64 v189, 0, 0x42800000, s6                  // 00000003210C: D50100BD 0019FE80 42800000
	v_dual_sub_f32 v135, v135, v131 :: v_dual_add_f32 v136, v136, v189// 000000032118: C9490787 87897B88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000032120: BF8702A1
	.long 0xd4140002                                           // 000000032124: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v135, vcc_lo             // 000000032128: 02030EFF C2FC0000
	v_cndmask_b32_e64 v189, 0, 0xffffffc0, s6                  // 000000032130: D50100BD 0019FE80 FFFFFFC0
	.long 0xd71c0089                                           // 00000003213C: D71C0089
	v_cndmask_b32_e32 v1, v137, v188, vcc_lo                   // 000000032140: 02037989
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000032144: BF870194
	v_exp_f32_e32 v136, v136                                   // 000000032148: 7F104B88
	v_cndmask_b32_e64 v186, 0, 0x42800000, s2                  // 00000003214C: D50100BA 0009FE80 42800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032158: BF870091
	v_dual_sub_f32 v134, v134, v131 :: v_dual_add_f32 v135, v135, v186// 00000003215C: C9490786 86877587
	.long 0xd4140004                                           // 000000032164: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v134, vcc_lo             // 000000032168: 02030CFF C2FC0000
	v_cndmask_b32_e64 v186, 0, 0xffffffc0, s2                  // 000000032170: D50100BA 0009FE80 FFFFFFC0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003217C: BF870215
	.long 0xd71c0088                                           // 000000032180: D71C0088
	v_cndmask_b32_e32 v1, v136, v189, vcc_lo                   // 000000032184: 02037B88
	v_exp_f32_e32 v135, v135                                   // 000000032188: 7F0E4B87
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003218C: BF870113
	v_cndmask_b32_e64 v187, 0, 0x42800000, s4                  // 000000032190: D50100BB 0011FE80 42800000
	.long 0xd59c08b6                                           // 00000003219C: D59C08B6
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000321A0: 02010188
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000321A4: BF8701A2
	v_add_f32_e32 v134, v134, v187                             // 0000000321A8: 070D7786
	v_cndmask_b32_e64 v187, 0, 0xffffffc0, s4                  // 0000000321AC: D50100BB 0011FE80 FFFFFFC0
	v_and_b32_e32 v182, 1, v182                                // 0000000321B8: 376D6C81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000321BC: BF870215
	.long 0xd71c0087                                           // 0000000321C0: D71C0087
	v_cndmask_b32_e32 v1, v135, v186, vcc_lo                   // 0000000321C4: 02037587
	v_exp_f32_e32 v134, v134                                   // 0000000321C8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000321CC: BF870095
	.long 0xd71c0086                                           // 0000000321D0: D71C0086
	v_cndmask_b32_e32 v1, v134, v187, vcc_lo                   // 0000000321D4: 02037786
	.long 0xd59c08b5                                           // 0000000321D8: D59C08B5
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000321DC: 02010186
	v_sub_f32_e32 v148, v148, v131                             // 0000000321E0: 09290794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000321E4: BF870112
	v_dual_add_f32 v184, v184, v134 :: v_dual_and_b32 v181, 1, v181// 0000000321E8: C9250DB8 B8B56A81
	.long 0xd4140009                                           // 0000000321F0: D4140009
	v_cndmask_b32_e32 v1, 0xc2fc0000, v148, vcc_lo             // 0000000321F4: 020328FF C2FC0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000321FC: BF870002
	v_add_f32_e32 v184, v184, v135                             // 000000032200: 07710FB8
	v_and_b32_e32 v185, 1, v179                                // 000000032204: 37736681
	.long 0xd59c08b3                                           // 000000032208: D59C08B3
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000003220C: 02010187
	v_add3_u32 v181, v134, v181, 0x7fff                        // 000000032210: D65500B5 03FF6B86 00007FFF
	v_cndmask_b32_e64 v192, 0, 0x42800000, s9                  // 00000003221C: D50100C0 0025FE80 42800000
	v_dual_sub_f32 v145, v145, v131 :: v_dual_add_f32 v180, v184, v136// 000000032228: C9490791 91B511B8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032230: BF870224
	v_and_b32_e32 v186, 1, v179                                // 000000032234: 37756681
	.long 0xd59c08b3                                           // 000000032238: D59C08B3
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000003223C: 02010189
	v_add_f32_e32 v148, v148, v192                             // 000000032240: 07298194
	s_delay_alu instid0(VALU_DEP_4)                            // 000000032244: BF870004
	.long 0xd4140008                                           // 000000032248: D4140008
	v_cndmask_b32_e32 v1, 0xc2fc0000, v145, vcc_lo             // 00000003224C: 020322FF C2FC0000
	v_add3_u32 v136, v136, v182, 0x7fff                        // 000000032254: D6550088 03FF6D88 00007FFF
	v_add3_u32 v133, v133, v185, 0x7fff                        // 000000032260: D6550085 03FF7385 00007FFF
	.long 0xd59c0885                                           // 00000003226C: D59C0885
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000032270: 02010184
	v_exp_f32_e32 v148, v148                                   // 000000032274: 7F284B94
	v_cndmask_b32_e64 v191, 0, 0x42800000, s8                  // 000000032278: D50100BF 0021FE80 42800000
	v_and_b32_e32 v184, 1, v179                                // 000000032284: 37716681
	.long 0xd59c08b3                                           // 000000032288: D59C08B3
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 00000003228C: 02010192
	v_add3_u32 v134, v135, v186, 0x7fff                        // 000000032290: D6550086 03FF7587 00007FFF
	.long 0xd59c0886                                           // 00000003229C: D59C0886
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000000322A0: 020101B5
	v_add_f32_e32 v145, v145, v191                             // 0000000322A4: 07237F91
	v_cndmask_b32_e64 v191, 0, 0xffffffc0, s8                  // 0000000322A8: D50100BF 0021FE80 FFFFFFC0
	v_add3_u32 v135, v137, v184, 0x7fff                        // 0000000322B4: D6550087 03FF7189 00007FFF
	.long 0xd59c0887                                           // 0000000322C0: D59C0887
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000322C4: 02010188
	v_add_f32_e32 v180, v180, v137                             // 0000000322C8: 076913B4
	v_exp_f32_e32 v145, v145                                   // 0000000322CC: 7F224B91
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000322D0: BF870095
	.long 0xd71c0091                                           // 0000000322D4: D71C0091
	v_cndmask_b32_e32 v1, v145, v191, vcc_lo                   // 0000000322D8: 02037F91
	.long 0xd59c08b7                                           // 0000000322DC: D59C08B7
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                   // 0000000322E0: 02010191
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000322E4: BF870112
	v_add_f32_e32 v137, v180, v145                             // 0000000322E8: 071323B4
	v_and_b32_e32 v183, 1, v183                                // 0000000322EC: 376F6E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000322F0: BF870112
	v_add_f32_e32 v137, v137, v146                             // 0000000322F4: 07132589
	v_add3_u32 v182, v145, v183, 0x7fff                        // 0000000322F8: D65500B6 03FF6F91 00007FFF
	v_sub_f32_e32 v145, v149, v131                             // 000000032304: 09230795
	v_sub_f32_e32 v149, v150, v131                             // 000000032308: 092B0796
	v_and_b32_e32 v183, 1, v179                                // 00000003230C: 376F6681
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, s9                  // 000000032310: D5010096 0025FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003231C: BF870214
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v145                  // 000000032320: 7C2922FF C2FC0000
	.long 0xd4140001                                           // 000000032328: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v149, vcc_lo             // 00000003232C: 02032AFF C2FC0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000032334: BF870004
	v_add3_u32 v136, v146, v183, 0x7fff                        // 000000032338: D6550088 03FF6F92 00007FFF
	.long 0xd59c0888                                           // 000000032344: D59C0888
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 000000032348: 020101B6
	v_cndmask_b32_e64 v183, 0, 0xffffffc0, s10                 // 00000003234C: D50100B7 0029FE80 FFFFFFC0
	v_cndmask_b32_e64 v180, 0, 0x42800000, vcc_lo              // 000000032358: D50100B4 01A9FE80 42800000
	v_cndmask_b32_e64 v182, 0, 0x42800000, s1                  // 000000032364: D50100B6 0005FE80 42800000
	.long 0xd71c0094                                           // 000000032370: D71C0094
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                   // 000000032374: 02032D94
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, vcc_lo              // 000000032378: D5010096 01A9FE80 FFFFFFC0
	.long 0xd71c0093                                           // 000000032384: D71C0093
	v_cndmask_b32_e32 v1, v147, v183, vcc_lo                   // 000000032388: 02036F93
	v_add_f32_e32 v145, v145, v180                             // 00000003238C: 07236991
	v_add_f32_e32 v149, v149, v182                             // 000000032390: 072B6D95
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, s1                  // 000000032394: D50100B4 0005FE80 FFFFFFC0
	.long 0xd59c08b3                                           // 0000000323A0: D59C08B3
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 0000000323A4: 02010194
	v_add_f32_e32 v137, v137, v147                             // 0000000323A8: 07132789
	v_exp_f32_e32 v145, v145                                   // 0000000323AC: 7F224B91
	v_exp_f32_e32 v146, v149                                   // 0000000323B0: 7F244B95
	.long 0xd59c0895                                           // 0000000323B4: D59C0895
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000000323B8: 02010193
	.long 0xd59c4895                                           // 0000000323BC: D59C4895
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000323C0: 020101B3
	v_and_b32_e32 v181, 1, v179                                // 0000000323C4: 376B6681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000323C8: BF870312
	v_and_b32_e32 v149, 1, v149                                // 0000000323CC: 372B2A81
	.long 0xd71c0096                                           // 0000000323D0: D71C0096
	v_cndmask_b32_e32 v1, v145, v150, vcc_lo                   // 0000000323D4: 02032D91
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000323D8: BF870215
	.long 0xd71c0092                                           // 0000000323DC: D71C0092
	v_cndmask_b32_e32 v1, v146, v180, vcc_lo                   // 0000000323E0: 02036992
	v_add3_u32 v145, v148, v181, 0x7fff                        // 0000000323E4: D6550091 03FF6B94 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000323F0: BF870004
	v_add3_u32 v132, v147, v149, 0x7fff                        // 0000000323F4: D6550084 03FF2B93 00007FFF
	v_sub_f32_e32 v147, v152, v131                             // 000000032400: 09270798
	v_sub_f32_e32 v149, v151, v131                             // 000000032404: 092B0797
	v_sub_f32_e32 v151, v177, v131                             // 000000032408: 092F07B1
	.long 0xd59c08b3                                           // 00000003240C: D59C08B3
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 000000032410: 02010192
	.long 0xd59c0891                                           // 000000032414: D59C0891
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 000000032418: 02010184
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v147                  // 00000003241C: 7C2926FF C2FC0000
	.long 0xd4140001                                           // 000000032424: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v149, vcc_lo             // 000000032428: 02032AFF C2FC0000
	.long 0xd4140002                                           // 000000032430: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v151, vcc_lo             // 000000032434: 02032EFF C2FC0000
	v_cndmask_b32_e64 v152, 0, 0x42800000, vcc_lo              // 00000003243C: D5010098 01A9FE80 42800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000032448: BF870193
	v_cndmask_b32_e64 v177, 0, 0x42800000, s1                  // 00000003244C: D50100B1 0005FE80 42800000
	v_cndmask_b32_e64 v180, 0, 0x42800000, s2                  // 000000032458: D50100B4 0009FE80 42800000
	v_cndmask_b32_e64 v181, 0, 0xffffffc0, s2                  // 000000032464: D50100B5 0009FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000032470: BF870004
	v_add_f32_e32 v147, v147, v152                             // 000000032474: 07273193
	.long 0xd4140004                                           // 000000032478: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v178, vcc_lo             // 00000003247C: 020364FF C2FC0000
	v_add_f32_e32 v149, v149, v177                             // 000000032484: 072B6395
	v_add_f32_e32 v151, v151, v180                             // 000000032488: 072F6997
	v_and_b32_e32 v177, 1, v179                                // 00000003248C: 37636681
	v_exp_f32_e32 v147, v147                                   // 000000032490: 7F264B93
	v_cndmask_b32_e64 v152, 0, 0x42800000, s4                  // 000000032494: D5010098 0011FE80 42800000
	v_exp_f32_e32 v149, v149                                   // 0000000324A0: 7F2A4B95
	v_exp_f32_e32 v151, v151                                   // 0000000324A4: 7F2E4B97
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, s1                  // 0000000324A8: D50100B4 0005FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000324B4: BF870122
	v_add_f32_e32 v152, v178, v152                             // 0000000324B8: 073131B2
	v_cndmask_b32_e64 v178, 0, 0xffffffc0, vcc_lo              // 0000000324BC: D50100B2 01A9FE80 FFFFFFC0
	v_exp_f32_e32 v152, v152                                   // 0000000324C8: 7F304B98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000324CC: BF870311
	.long 0xd71c0093                                           // 0000000324D0: D71C0093
	v_cndmask_b32_e32 v1, v147, v178, vcc_lo                   // 0000000324D4: 02036593
	.long 0xd71c0097                                           // 0000000324D8: D71C0097
	v_cndmask_b32_e32 v1, v151, v181, vcc_lo                   // 0000000324DC: 02036B97
	.long 0xd59c48b2                                           // 0000000324E0: D59C48B2
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 0000000324E4: 020101B3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000324E8: BF8700C3
	.long 0xd59c08b3                                           // 0000000324EC: D59C08B3
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 0000000324F0: 02010193
	v_add_f32_e32 v137, v137, v148                             // 0000000324F4: 07132989
	.long 0xd59c0894                                           // 0000000324F8: D59C0894
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 0000000324FC: 02010196
	.long 0xd59c4894                                           // 000000032500: D59C4894
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000032504: 020101B3
	v_dual_add_f32 v137, v137, v150 :: v_dual_and_b32 v148, 1, v148// 000000032508: C9252D89 89952881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000032510: BF8701C1
	v_add3_u32 v150, v150, v148, 0x7fff                        // 000000032514: D6550096 03FF2996 00007FFF
	.long 0xd71c0094                                           // 000000032520: D71C0094
	v_cndmask_b32_e32 v1, v149, v180, vcc_lo                   // 000000032524: 02036995
	v_cndmask_b32_e64 v149, 0, 0xffffffc0, s4                  // 000000032528: D5010095 0011FE80 FFFFFFC0
	v_and_b32_e32 v180, 1, v179                                // 000000032534: 37696681
	.long 0xd59c08b2                                           // 000000032538: D59C08B2
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 00000003253C: 02010194
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000032540: BF870233
	.long 0xd71c0095                                           // 000000032544: D71C0095
	v_cndmask_b32_e32 v1, v152, v149, vcc_lo                   // 000000032548: 02032B98
	.long 0xd59c0898                                           // 00000003254C: D59C0898
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 000000032550: 02010197
	.long 0xd59c4898                                           // 000000032554: D59C4898
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 000000032558: 020101B3
	v_and_b32_e32 v178, 1, v178                                // 00000003255C: 37656481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000032560: BF870194
	.long 0xd59c08b3                                           // 000000032564: D59C08B3
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 000000032568: 02010195
	v_dual_add_f32 v137, v137, v146 :: v_dual_and_b32 v152, 1, v152// 00000003256C: C9252589 89993081
	v_add3_u32 v146, v146, v177, 0x7fff                        // 000000032574: D6550092 03FF6392 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032580: BF870223
	v_and_b32_e32 v177, 1, v179                                // 000000032584: 37636681
	v_add3_u32 v178, v148, v178, 0x7fff                        // 000000032588: D65500B2 03FF6594 00007FFF
	v_add3_u32 v152, v151, v152, 0x7fff                        // 000000032594: D6550098 03FF3197 00007FFF
	v_add_f32_e32 v137, v137, v148                             // 0000000325A0: 07132989
	.long 0xd59c0892                                           // 0000000325A4: D59C0892
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 0000000325A8: 02010196
	v_add3_u32 v148, v149, v177, 0x7fff                        // 0000000325AC: D6550094 03FF6395 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000325B8: BF870214
	.long 0xd59c0894                                           // 0000000325BC: D59C0894
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 0000000325C0: 02010198
	v_add_f32_e32 v137, v137, v147                             // 0000000325C4: 07132789
	v_add3_u32 v147, v147, v180, 0x7fff                        // 0000000325C8: D6550093 03FF6993 00007FFF
	.long 0xd59c0893                                           // 0000000325D4: D59C0893
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 0000000325D8: 020101B2
	ds_store_b128 v165, v[133:136]                             // 0000000325DC: DB7C0000 000085A5
	ds_store_b128 v165, v[145:148] offset:16                   // 0000000325E4: DB7C0010 000091A5
	v_add_f32_e32 v137, v137, v151                             // 0000000325EC: 07132F89
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000325F0: BF870001
	v_add_f32_e32 v132, v137, v149                             // 0000000325F4: 07092B89
	v_mov_b32_e32 v133, 0                                      // 0000000325F8: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 0000000325FC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 000000032600: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 000000032604: 7D2304FF EFA18F08
	s_cbranch_execz 15                                         // 00000003260C: BFA5000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x294c>
	v_sub_f32_e32 v130, v130, v131                             // 000000032610: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000032614: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v130                  // 000000032618: 7C2904FF C2FC0000
	v_cndmask_b32_e64 v133, 0, 0x42800000, vcc_lo              // 000000032620: D5010085 01A9FE80 42800000
	v_add_f32_e32 v130, v130, v133                             // 00000003262C: 07050B82
	v_cndmask_b32_e64 v133, 0, 0xffffffc0, vcc_lo              // 000000032630: D5010085 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003263C: BF870292
	v_exp_f32_e32 v130, v130                                   // 000000032640: 7F044B82
	.long 0xd71c0085                                           // 000000032644: D71C0085
	v_cndmask_b32_e32 v1, v130, v133, vcc_lo                   // 000000032648: 02030B82
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003264C: 8C7E017E
	ds_load_b32 v130, v166                                     // 000000032650: D8D80000 820000A6
	s_waitcnt lgkmcnt(0)                                       // 000000032658: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 00000003265C: 57090585
	ds_store_b32 v163, v131                                    // 000000032660: D8340000 000083A3
	ds_store_b32 v166, v132                                    // 000000032668: D8340000 000084A6
	ds_store_b32 v167, v133                                    // 000000032670: D8340000 000085A7
	s_or_b32 exec_lo, exec_lo, s13                             // 000000032678: 8C7E0D7E
	ds_load_2addr_b32 v[151:152], v168 offset1:2               // 00000003267C: D8DC0200 970000A8
	ds_load_2addr_b32 v[149:150], v168 offset0:4 offset1:6     // 000000032684: D8DC0604 950000A8
	ds_load_2addr_b32 v[147:148], v168 offset0:8 offset1:10    // 00000003268C: D8DC0A08 930000A8
	ds_load_2addr_b32 v[145:146], v168 offset0:12 offset1:14   // 000000032694: D8DC0E0C 910000A8
	s_waitcnt lgkmcnt(3)                                       // 00000003269C: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v151                         // 0000000326A0: 7C252EF2
	.long 0xd4120001                                           // 0000000326A4: D4120001
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 0000000326A8: 020330F2
	s_waitcnt lgkmcnt(2)                                       // 0000000326AC: BF89FC27
	.long 0xd4120002                                           // 0000000326B0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000000326B4: 02032AF2
	.long 0xd4120004                                           // 0000000326B8: D4120004
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000326BC: 02032CF2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000326C0: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000326C4: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 0000000326C8: 7C2526F2
	s_and_b32 s2, s1, s2                                       // 0000000326CC: 8B020201
	.long 0xd4120001                                           // 0000000326D0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v148, vcc_lo                    // 0000000326D4: 020328F2
	s_and_b32 s4, s2, s4                                       // 0000000326D8: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000326DC: BF89FC07
	.long 0xd4120002                                           // 0000000326E0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v145, vcc_lo                    // 0000000326E4: 020322F2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000326E8: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v146                         // 0000000326EC: 7C2524F2
	s_and_b32 s1, s4, s1                                       // 0000000326F0: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000326F4: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000326F8: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000326FC: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032700: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000032704: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 00000003270C: 7C9B0480
	ds_load_b128 v[130:133], v169                              // 000000032710: DBFC0000 820000A9
	ds_load_b128 v[134:137], v169 offset:16                    // 000000032718: DBFC0010 860000A9
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000032720: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000032724: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032728: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 00000003272C: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 000000032734: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 000000032738: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000003273C: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000032740: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000032744: 8B6A017E
	s_cbranch_vccnz 63295                                      // 000000032748: BFA4F73F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_dual_mul_f32 v121, v151, v121 :: v_dual_mul_f32 v122, v152, v122// 00000003274C: C8C6F397 797AF598
	v_dual_mul_f32 v123, v149, v123 :: v_dual_mul_f32 v124, v150, v124// 000000032754: C8C6F795 7B7CF996
	v_dual_mul_f32 v125, v147, v125 :: v_dual_mul_f32 v126, v148, v126// 00000003275C: C8C6FB93 7D7EFD94
	v_dual_mul_f32 v127, v145, v127 :: v_dual_mul_f32 v128, v146, v128// 000000032764: C8C6FF91 7F810192
	v_dual_mul_f32 v113, v151, v113 :: v_dual_mul_f32 v114, v152, v114// 00000003276C: C8C6E397 7172E598
	v_dual_mul_f32 v115, v149, v115 :: v_dual_mul_f32 v116, v150, v116// 000000032774: C8C6E795 7374E996
	v_dual_mul_f32 v117, v147, v117 :: v_dual_mul_f32 v118, v148, v118// 00000003277C: C8C6EB93 7576ED94
	v_dual_mul_f32 v119, v145, v119 :: v_dual_mul_f32 v120, v146, v120// 000000032784: C8C6EF91 7778F192
	v_dual_mul_f32 v105, v151, v105 :: v_dual_mul_f32 v106, v152, v106// 00000003278C: C8C6D397 696AD598
	v_dual_mul_f32 v107, v149, v107 :: v_dual_mul_f32 v108, v150, v108// 000000032794: C8C6D795 6B6CD996
	v_dual_mul_f32 v109, v147, v109 :: v_dual_mul_f32 v110, v148, v110// 00000003279C: C8C6DB93 6D6EDD94
	v_dual_mul_f32 v111, v145, v111 :: v_dual_mul_f32 v112, v146, v112// 0000000327A4: C8C6DF91 6F70E192
	v_dual_mul_f32 v97, v151, v97 :: v_dual_mul_f32 v98, v152, v98// 0000000327AC: C8C6C397 6162C598
	v_dual_mul_f32 v99, v149, v99 :: v_dual_mul_f32 v100, v150, v100// 0000000327B4: C8C6C795 6364C996
	v_dual_mul_f32 v101, v147, v101 :: v_dual_mul_f32 v102, v148, v102// 0000000327BC: C8C6CB93 6566CD94
	v_dual_mul_f32 v103, v145, v103 :: v_dual_mul_f32 v104, v146, v104// 0000000327C4: C8C6CF91 6768D192
	v_dual_mul_f32 v89, v151, v89 :: v_dual_mul_f32 v90, v152, v90// 0000000327CC: C8C6B397 595AB598
	v_dual_mul_f32 v91, v149, v91 :: v_dual_mul_f32 v92, v150, v92// 0000000327D4: C8C6B795 5B5CB996
	v_dual_mul_f32 v93, v147, v93 :: v_dual_mul_f32 v94, v148, v94// 0000000327DC: C8C6BB93 5D5EBD94
	v_dual_mul_f32 v95, v145, v95 :: v_dual_mul_f32 v96, v146, v96// 0000000327E4: C8C6BF91 5F60C192
	v_dual_mul_f32 v81, v151, v81 :: v_dual_mul_f32 v82, v152, v82// 0000000327EC: C8C6A397 5152A598
	v_dual_mul_f32 v83, v149, v83 :: v_dual_mul_f32 v84, v150, v84// 0000000327F4: C8C6A795 5354A996
	v_dual_mul_f32 v85, v147, v85 :: v_dual_mul_f32 v86, v148, v86// 0000000327FC: C8C6AB93 5556AD94
	v_dual_mul_f32 v87, v145, v87 :: v_dual_mul_f32 v88, v146, v88// 000000032804: C8C6AF91 5758B192
	v_dual_mul_f32 v73, v151, v73 :: v_dual_mul_f32 v74, v152, v74// 00000003280C: C8C69397 494A9598
	v_dual_mul_f32 v75, v149, v75 :: v_dual_mul_f32 v76, v150, v76// 000000032814: C8C69795 4B4C9996
	v_dual_mul_f32 v77, v147, v77 :: v_dual_mul_f32 v78, v148, v78// 00000003281C: C8C69B93 4D4E9D94
	v_dual_mul_f32 v79, v145, v79 :: v_dual_mul_f32 v80, v146, v80// 000000032824: C8C69F91 4F50A192
	v_dual_mul_f32 v65, v151, v65 :: v_dual_mul_f32 v66, v152, v66// 00000003282C: C8C68397 41428598
	v_dual_mul_f32 v67, v149, v67 :: v_dual_mul_f32 v68, v150, v68// 000000032834: C8C68795 43448996
	v_dual_mul_f32 v69, v147, v69 :: v_dual_mul_f32 v70, v148, v70// 00000003283C: C8C68B93 45468D94
	v_dual_mul_f32 v71, v145, v71 :: v_dual_mul_f32 v72, v146, v72// 000000032844: C8C68F91 47489192
	v_dual_mul_f32 v57, v151, v57 :: v_dual_mul_f32 v58, v152, v58// 00000003284C: C8C67397 393A7598
	v_dual_mul_f32 v59, v149, v59 :: v_dual_mul_f32 v60, v150, v60// 000000032854: C8C67795 3B3C7996
	v_dual_mul_f32 v61, v147, v61 :: v_dual_mul_f32 v62, v148, v62// 00000003285C: C8C67B93 3D3E7D94
	v_dual_mul_f32 v63, v145, v63 :: v_dual_mul_f32 v64, v146, v64// 000000032864: C8C67F91 3F408192
	v_dual_mul_f32 v49, v151, v49 :: v_dual_mul_f32 v50, v152, v50// 00000003286C: C8C66397 31326598
	v_dual_mul_f32 v51, v149, v51 :: v_dual_mul_f32 v52, v150, v52// 000000032874: C8C66795 33346996
	v_dual_mul_f32 v53, v147, v53 :: v_dual_mul_f32 v54, v148, v54// 00000003287C: C8C66B93 35366D94
	v_dual_mul_f32 v55, v145, v55 :: v_dual_mul_f32 v56, v146, v56// 000000032884: C8C66F91 37387192
	v_dual_mul_f32 v41, v151, v41 :: v_dual_mul_f32 v42, v152, v42// 00000003288C: C8C65397 292A5598
	v_dual_mul_f32 v43, v149, v43 :: v_dual_mul_f32 v44, v150, v44// 000000032894: C8C65795 2B2C5996
	v_dual_mul_f32 v45, v147, v45 :: v_dual_mul_f32 v46, v148, v46// 00000003289C: C8C65B93 2D2E5D94
	v_dual_mul_f32 v47, v145, v47 :: v_dual_mul_f32 v48, v146, v48// 0000000328A4: C8C65F91 2F306192
	v_dual_mul_f32 v33, v151, v33 :: v_dual_mul_f32 v34, v152, v34// 0000000328AC: C8C64397 21224598
	v_dual_mul_f32 v35, v149, v35 :: v_dual_mul_f32 v36, v150, v36// 0000000328B4: C8C64795 23244996
	v_dual_mul_f32 v37, v147, v37 :: v_dual_mul_f32 v38, v148, v38// 0000000328BC: C8C64B93 25264D94
	v_dual_mul_f32 v39, v145, v39 :: v_dual_mul_f32 v40, v146, v40// 0000000328C4: C8C64F91 27285192
	v_dual_mul_f32 v25, v151, v25 :: v_dual_mul_f32 v26, v152, v26// 0000000328CC: C8C63397 191A3598
	v_dual_mul_f32 v27, v149, v27 :: v_dual_mul_f32 v28, v150, v28// 0000000328D4: C8C63795 1B1C3996
	v_dual_mul_f32 v29, v147, v29 :: v_dual_mul_f32 v30, v148, v30// 0000000328DC: C8C63B93 1D1E3D94
	v_dual_mul_f32 v31, v145, v31 :: v_dual_mul_f32 v32, v146, v32// 0000000328E4: C8C63F91 1F204192
	v_dual_mul_f32 v17, v151, v17 :: v_dual_mul_f32 v18, v152, v18// 0000000328EC: C8C62397 11122598
	v_dual_mul_f32 v19, v149, v19 :: v_dual_mul_f32 v20, v150, v20// 0000000328F4: C8C62795 13142996
	v_dual_mul_f32 v21, v147, v21 :: v_dual_mul_f32 v22, v148, v22// 0000000328FC: C8C62B93 15162D94
	v_dual_mul_f32 v23, v145, v23 :: v_dual_mul_f32 v24, v146, v24// 000000032904: C8C62F91 17183192
	v_dual_mul_f32 v9, v151, v9 :: v_dual_mul_f32 v10, v152, v10// 00000003290C: C8C61397 090A1598
	v_dual_mul_f32 v11, v149, v11 :: v_dual_mul_f32 v12, v150, v12// 000000032914: C8C61795 0B0C1996
	v_dual_mul_f32 v13, v147, v13 :: v_dual_mul_f32 v14, v148, v14// 00000003291C: C8C61B93 0D0E1D94
	v_dual_mul_f32 v15, v145, v15 :: v_dual_mul_f32 v16, v146, v16// 000000032924: C8C61F91 0F102192
	v_dual_mul_f32 v1, v151, v1 :: v_dual_mul_f32 v2, v152, v2 // 00000003292C: C8C60397 01020598
	v_dual_mul_f32 v3, v149, v3 :: v_dual_mul_f32 v4, v150, v4 // 000000032934: C8C60795 03040996
	v_dual_mul_f32 v5, v147, v5 :: v_dual_mul_f32 v6, v148, v6 // 00000003293C: C8C60B93 05060D94
	v_dual_mul_f32 v7, v145, v7 :: v_dual_mul_f32 v8, v146, v8 // 000000032944: C8C60F91 07081192
	s_branch 63166                                             // 00000003294C: BFA0F6BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_lshlrev_b32_e32 v0, 2, v156                              // 000000032950: 30013882
	.long 0xd700008e                                           // 000000032954: D700008E
	v_cndmask_b32_e32 v1, s22, v157, vcc_lo                    // 000000032958: 02033A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003295C: BF870191
	v_add_co_ci_u32_e64 v143, null, s23, 0, s0                 // 000000032960: D5207C8F 00010017
	v_lshl_or_b32 v0, v153, 6, v0                              // 000000032968: D6560000 04010D99
	v_lshlrev_b32_e32 v144, 10, v138                           // 000000032970: 3121148A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000032974: BF870002
	v_add_nc_u32_e32 v129, 0xa000, v0                          // 000000032978: 4B0200FF 0000A000
	ds_load_2addr_b32 v[137:138], v129 offset0:132 offset1:134 // 000000032980: D8DC8684 89000081
	ds_load_2addr_b32 v[135:136], v129 offset0:136 offset1:138 // 000000032988: D8DC8A88 87000081
	ds_load_2addr_b32 v[133:134], v129 offset0:140 offset1:142 // 000000032990: D8DC8E8C 85000081
	ds_load_2addr_b32 v[139:140], v129 offset0:128 offset1:130 // 000000032998: D8DC8280 8B000081
	.long 0xd7000090                                           // 0000000329A0: D7000090
	v_cndmask_b32_e32 v1, s20, v144, vcc_lo                    // 0000000329A4: 02032014
	s_waitcnt lgkmcnt(0)                                       // 0000000329A8: BF89FC07
	v_div_scale_f32 v130, null, v139, v139, 1.0                // 0000000329AC: D6FC7C82 03CB178B
	v_div_scale_f32 v132, vcc_lo, 1.0, v139, 1.0               // 0000000329B4: D6FC6A84 03CB16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000329BC: BF870292
	v_rcp_f32_e32 v131, v130                                   // 0000000329C0: 7F065582
	v_fma_f32 v0, -v130, v131, 1.0                             // 0000000329C4: D6130000 23CB0782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000329CC: BF870121
	v_fmac_f32_e32 v131, v0, v131                              // 0000000329D0: 57070700
	v_or_b32_e32 v0, v155, v156                                // 0000000329D4: 3801399B
	v_mul_f32_e32 v141, v132, v131                             // 0000000329D8: 111B0784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000329DC: BF870091
	v_fma_f32 v145, -v130, v141, v132                          // 0000000329E0: D6130091 26131B82
	v_dual_fmac_f32 v141, v145, v131 :: v_dual_lshlrev_b32 v146, 1, v154// 0000000329E8: C8230791 8D933481
	v_add_co_ci_u32_e64 v145, null, s21, 0, s0                 // 0000000329F0: D5207C91 00010015
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000329F8: BF870192
	.long 0xd7000081                                           // 0000000329FC: D7000081
	v_cndmask_b32_e32 v1, v142, v146, vcc_lo                   // 000000032A00: 0203258E
	v_fma_f32 v132, -v130, v141, v132                          // 000000032A04: D6130084 26131B82
	v_add_co_ci_u32_e64 v130, null, 0, v143, s0                // 000000032A0C: D5207C82 00031E80
	.long 0xd4440000                                           // 000000032A14: D4440000
	v_cndmask_b32_e32 v1, s18, v0, vcc_lo                      // 000000032A18: 02020012
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000032A1C: BF8700A3
	v_div_fmas_f32 v141, v132, v131, v141                      // 000000032A20: D637008D 06370784
	.long 0xd7006a83                                           // 000000032A28: D7006A83
	v_cndmask_b32_e32 v1, v144, v146, vcc_lo                   // 000000032A2C: 02032590
	v_add_co_ci_u32_e64 v132, null, 0, v145, vcc_lo            // 000000032A30: D5207C84 01AB2280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000032A38: BF870003
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 000000032A3C: D627008B 03CB178D
	s_and_saveexec_b32 s1, s0                                  // 000000032A44: BE812000
	s_cbranch_execz 70                                         // 000000032A48: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e64>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032A4C: BF870112
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000032A50: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000032A5C: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 000000032A60: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000032A68: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000032A6C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032A70: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000032A74: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000032A7C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000032A88: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032A8C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000032A90: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000032A94: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000032A9C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032AA4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000032AA8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000032AAC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000032AB0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032AB4: BF870095
	.long 0xd71c008e                                           // 000000032AB8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000032ABC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000032AC0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000032AC4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032ACC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000032AD0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000032AD8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032ADC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 000000032AE0: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000032AE8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032AEC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000032AF0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000032AF8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 000000032AFC: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B04: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000032B08: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000032B0C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B14: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000032B18: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000032B1C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B24: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000032B28: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 000000032B30: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000032B38: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B44: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000032B48: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000032B50: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 000000032B5C: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000032B64: 8C7E017E
	v_div_scale_f32 v121, null, v140, v140, 1.0                // 000000032B68: D6FC7C79 03CB198C
	v_div_scale_f32 v143, vcc_lo, 1.0, v140, 1.0               // 000000032B70: D6FC6A8F 03CB18F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000032B78: BF870292
	v_rcp_f32_e32 v141, v121                                   // 000000032B7C: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 000000032B80: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B88: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000032B8C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000032B90: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032B94: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 000000032B98: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 000000032BA0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032BA4: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 000000032BA8: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 000000032BB0: D637008D 063B1B79
	v_or_b32_e32 v121, 2, v0                                   // 000000032BB8: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032BBC: BF870112
	v_div_fixup_f32 v140, v141, v140, 1.0                      // 000000032BC0: D627008C 03CB198D
	.long 0xd4440001                                           // 000000032BC8: D4440001
	v_cndmask_b32_e32 v1, s18, v121, vcc_lo                    // 000000032BCC: 0202F212
	s_and_saveexec_b32 s2, s1                                  // 000000032BD0: BE822001
	s_cbranch_execz 69                                         // 000000032BD4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2fec>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000032BD8: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 000000032BE4: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 000000032BE8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000032BF0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000032BF4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032BF8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000032BFC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000032C04: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000032C10: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032C14: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000032C18: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000032C1C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000032C24: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032C2C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000032C30: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000032C34: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000032C38: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C3C: BF870095
	.long 0xd71c008e                                           // 000000032C40: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000032C44: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000032C48: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000032C4C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C54: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000032C58: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000032C60: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C64: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000032C68: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000032C70: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C74: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000032C78: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000032C80: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000032C84: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C8C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000032C90: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000032C94: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C9C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000032CA0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000032CA4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032CAC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000032CB0: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000032CB8: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 000000032CC0: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032CCC: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 000000032CD0: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000032CD8: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000032CE4: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 000000032CEC: 8C7E027E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000032CF0: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000032CF8: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000032D00: BF870292
	v_rcp_f32_e32 v141, v122                                   // 000000032D04: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 000000032D08: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032D10: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000032D14: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000032D18: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032D1C: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 000000032D20: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 000000032D28: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032D2C: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000032D30: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 000000032D38: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 000000032D40: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032D44: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 000000032D48: D6270089 03CB138D
	.long 0xd4440002                                           // 000000032D50: D4440002
	v_cndmask_b32_e32 v1, s18, v122, vcc_lo                    // 000000032D54: 0202F412
	s_and_saveexec_b32 s3, s2                                  // 000000032D58: BE832002
	s_cbranch_execz 69                                         // 000000032D5C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3174>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000032D60: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 000000032D6C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000032D70: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000032D78: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000032D7C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032D80: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000032D84: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000032D8C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000032D98: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032D9C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000032DA0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000032DA4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000032DAC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032DB4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000032DB8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000032DBC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000032DC0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032DC4: BF870095
	.long 0xd71c008e                                           // 000000032DC8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000032DCC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000032DD0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000032DD4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032DDC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000032DE0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000032DE8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032DEC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 000000032DF0: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000032DF8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032DFC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000032E00: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000032E08: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 000000032E0C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032E14: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000032E18: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000032E1C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032E24: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000032E28: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000032E2C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032E34: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000032E38: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 000000032E40: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 000000032E48: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032E54: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 000000032E58: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000032E60: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 000000032E6C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032E74: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 000000032E78: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 000000032E80: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000032E88: BF870292
	v_rcp_f32_e32 v141, v123                                   // 000000032E8C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000032E90: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032E98: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000032E9C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000032EA0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032EA4: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000032EA8: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000032EB0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032EB4: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000032EB8: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000032EC0: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 000000032EC8: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032ECC: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000032ED0: D627008A 03CB158D
	.long 0xd4440003                                           // 000000032ED8: D4440003
	v_cndmask_b32_e32 v1, s18, v123, vcc_lo                    // 000000032EDC: 0202F612
	s_and_saveexec_b32 s4, s3                                  // 000000032EE0: BE842003
	s_cbranch_execz 69                                         // 000000032EE4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32fc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 000000032EE8: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 000000032EF4: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 000000032EF8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000032F00: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000032F04: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F08: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000032F0C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000032F14: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000032F20: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032F24: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000032F28: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000032F2C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000032F34: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032F3C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000032F40: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000032F44: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000032F48: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F4C: BF870095
	.long 0xd71c008e                                           // 000000032F50: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000032F54: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000032F58: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000032F5C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F64: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000032F68: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000032F70: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F74: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000032F78: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000032F80: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F84: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000032F88: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000032F90: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000032F94: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032F9C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000032FA0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000032FA4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032FAC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000032FB0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000032FB4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032FBC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000032FC0: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000032FC8: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 000000032FD0: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032FDC: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000032FE0: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000032FE8: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000032FF4: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000032FFC: 8C7E047E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 000000033000: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 000000033008: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000033010: BF870292
	v_rcp_f32_e32 v141, v124                                   // 000000033014: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 000000033018: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033020: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000033024: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000033028: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003302C: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 000000033030: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 000000033038: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003303C: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 000000033040: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 000000033048: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 000000033050: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000033054: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 000000033058: D6270087 03CB0F8D
	.long 0xd4440004                                           // 000000033060: D4440004
	v_cndmask_b32_e32 v1, s18, v124, vcc_lo                    // 000000033064: 0202F812
	s_and_saveexec_b32 s5, s4                                  // 000000033068: BE852004
	s_cbranch_execz 69                                         // 00000003306C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 000000033070: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000003307C: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000033080: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000033088: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003308C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033090: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000033094: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003309C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000330A8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000330AC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000330B0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000330B4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000330BC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000330C4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000330C8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000330CC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000330D0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000330D4: BF870095
	.long 0xd71c008e                                           // 0000000330D8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000330DC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000330E0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000330E4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000330EC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000330F0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000330F8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000330FC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 000000033100: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000033108: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003310C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000033110: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000033118: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000003311C: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033124: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000033128: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003312C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033134: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000033138: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003313C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033144: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000033148: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 000000033150: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 000000033158: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033164: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 000000033168: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000033170: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000003317C: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000033184: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 000000033188: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 000000033190: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000033198: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000003319C: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000331A0: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000331A8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000331AC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000331B0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000331B4: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000331B8: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000331C0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000331C4: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000331C8: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000331D0: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000331D8: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000331DC: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000331E0: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000331E8: D4440005
	v_cndmask_b32_e32 v1, s18, v125, vcc_lo                    // 0000000331EC: 0202FA12
	s_and_saveexec_b32 s6, s5                                  // 0000000331F0: BE862005
	s_cbranch_execz 69                                         // 0000000331F4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x360c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000331F8: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 000000033204: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 000000033208: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000033210: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000033214: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033218: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003321C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000033224: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000033230: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000033234: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000033238: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003323C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000033244: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003324C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000033250: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000033254: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000033258: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003325C: BF870095
	.long 0xd71c008e                                           // 000000033260: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000033264: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000033268: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003326C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033274: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000033278: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000033280: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033284: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 000000033288: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000033290: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033294: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000033298: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000332A0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000332A4: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000332AC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000332B0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000332B4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000332BC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000332C0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000332C4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000332CC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000332D0: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000332D8: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000332E0: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000332EC: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000332F0: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000332F8: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 000000033304: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000003330C: 8C7E067E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 000000033310: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 000000033318: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000033320: BF870292
	v_rcp_f32_e32 v141, v126                                   // 000000033324: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 000000033328: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033330: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000033334: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000033338: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003333C: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 000000033340: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 000000033348: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003334C: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 000000033350: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 000000033358: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 000000033360: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000033364: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 000000033368: D6270085 03CB0B8D
	.long 0xd4440006                                           // 000000033370: D4440006
	v_cndmask_b32_e32 v1, s18, v126, vcc_lo                    // 000000033374: 0202FC12
	s_and_saveexec_b32 s7, s6                                  // 000000033378: BE872006
	s_cbranch_execz 69                                         // 00000003337C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3794>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 000000033380: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000003338C: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 000000033390: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000033398: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003339C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000333A0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000333A4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000333AC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000333B8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000333BC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000333C0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000333C4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000333CC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000333D4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000333D8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000333DC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000333E0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000333E4: BF870095
	.long 0xd71c008e                                           // 0000000333E8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000333EC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000333F0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000333F4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000333FC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000033400: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000033408: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003340C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 000000033410: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000033418: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003341C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000033420: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000033428: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000003342C: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033434: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000033438: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003343C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033444: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000033448: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003344C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033454: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000033458: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 000000033460: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 000000033468: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033474: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 000000033478: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 000000033480: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000003348C: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 000000033494: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 000000033498: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000334A0: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000334A8: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000334AC: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000334B0: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000334B8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000334BC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000334C0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000334C4: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000334C8: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000334D0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000334D4: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000334D8: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000334E0: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000334E8: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000334EC: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000334F0: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000334F8: D4440007
	v_cndmask_b32_e32 v1, s18, v127, vcc_lo                    // 0000000334FC: 0202FE12
	s_and_saveexec_b32 s8, s7                                  // 000000033500: BE882007
	s_cbranch_execnz 363                                       // 000000033504: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033508: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003350C: BE882000
	s_cbranch_execnz 432                                       // 000000033510: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033514: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033518: BE882001
	s_cbranch_execnz 501                                       // 00000003351C: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033520: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033524: BE882002
	s_cbranch_execnz 570                                       // 000000033528: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4114>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003352C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033530: BE882003
	s_cbranch_execnz 639                                       // 000000033534: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4234>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033538: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003353C: BE882004
	s_cbranch_execnz 708                                       // 000000033540: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4354>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033544: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033548: BE882005
	s_cbranch_execnz 777                                       // 00000003354C: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4474>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033550: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033554: BE882006
	s_cbranch_execnz 846                                       // 000000033558: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4594>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003355C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033560: BE882007
	s_cbranch_execnz 915                                       // 000000033564: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033568: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003356C: BE882000
	s_cbranch_execnz 984                                       // 000000033570: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033574: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033578: BE882001
	s_cbranch_execnz 1053                                      // 00000003357C: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033580: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033584: BE882002
	s_cbranch_execnz 1122                                      // 000000033588: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003358C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033590: BE882003
	s_cbranch_execnz 1191                                      // 000000033594: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b34>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033598: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003359C: BE882004
	s_cbranch_execnz 1260                                      // 0000000335A0: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000335A8: BE882005
	s_cbranch_execnz 1329                                      // 0000000335AC: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335B0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000335B4: BE882006
	s_cbranch_execnz 1398                                      // 0000000335B8: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000335C0: BE882007
	s_cbranch_execnz 1467                                      // 0000000335C4: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000335CC: BE882000
	s_cbranch_execnz 1536                                      // 0000000335D0: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000335D8: BE882001
	s_cbranch_execnz 1605                                      // 0000000335DC: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000335E4: BE882002
	s_cbranch_execnz 1674                                      // 0000000335E8: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5314>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000335F0: BE882003
	s_cbranch_execnz 1743                                      // 0000000335F4: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5434>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000335F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000335FC: BE882004
	s_cbranch_execnz 1812                                      // 000000033600: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5554>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033604: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033608: BE882005
	s_cbranch_execnz 1881                                      // 00000003360C: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5674>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033610: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033614: BE882006
	s_cbranch_execnz 1950                                      // 000000033618: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5794>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003361C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033620: BE882007
	s_cbranch_execnz 2019                                      // 000000033624: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033628: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003362C: BE882000
	s_cbranch_execnz 2088                                      // 000000033630: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033634: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033638: BE882001
	s_cbranch_execnz 2157                                      // 00000003363C: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5af4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033640: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033644: BE882002
	s_cbranch_execnz 2226                                      // 000000033648: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003364C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033650: BE882003
	s_cbranch_execnz 2295                                      // 000000033654: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d34>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033658: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003365C: BE882004
	s_cbranch_execnz 2364                                      // 000000033660: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e54>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033664: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033668: BE882005
	s_cbranch_execnz 2433                                      // 00000003366C: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f74>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033670: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033674: BE882006
	s_cbranch_execnz 2502                                      // 000000033678: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6094>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003367C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033680: BE882007
	s_cbranch_execnz 2571                                      // 000000033684: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033688: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003368C: BE882000
	s_cbranch_execnz 2640                                      // 000000033690: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033694: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033698: BE882001
	s_cbranch_execnz 2709                                      // 00000003369C: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000336A4: BE882002
	s_cbranch_execnz 2778                                      // 0000000336A8: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6514>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336AC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000336B0: BE882003
	s_cbranch_execnz 2847                                      // 0000000336B4: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6634>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000336BC: BE882004
	s_cbranch_execnz 2916                                      // 0000000336C0: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6754>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336C4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000336C8: BE882005
	s_cbranch_execnz 2985                                      // 0000000336CC: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6874>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000336D4: BE882006
	s_cbranch_execnz 3054                                      // 0000000336D8: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6994>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336DC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000336E0: BE882007
	s_cbranch_execnz 3123                                      // 0000000336E4: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ab4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336E8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000336EC: BE882000
	s_cbranch_execnz 3192                                      // 0000000336F0: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000336F4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000336F8: BE882001
	s_cbranch_execnz 3261                                      // 0000000336FC: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6cf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033700: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033704: BE882002
	s_cbranch_execnz 3330                                      // 000000033708: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003370C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033710: BE882003
	s_cbranch_execnz 3399                                      // 000000033714: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f34>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033718: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003371C: BE882004
	s_cbranch_execnz 3468                                      // 000000033720: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7054>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033724: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033728: BE882005
	s_cbranch_execnz 3537                                      // 00000003372C: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7174>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033730: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033734: BE882006
	s_cbranch_execnz 3606                                      // 000000033738: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7294>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003373C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033740: BE882007
	s_cbranch_execnz 3675                                      // 000000033744: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033748: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003374C: BE882000
	s_cbranch_execnz 3744                                      // 000000033750: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033754: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033758: BE882001
	s_cbranch_execnz 3813                                      // 00000003375C: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033760: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033764: BE882002
	s_cbranch_execnz 3882                                      // 000000033768: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7714>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003376C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033770: BE882003
	s_cbranch_execnz 3951                                      // 000000033774: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7834>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033778: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003377C: BE882004
	s_cbranch_execnz 4020                                      // 000000033780: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7954>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033784: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033788: BE882005
	s_cbranch_execnz 4089                                      // 00000003378C: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a74>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033790: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033794: BE882006
	s_cbranch_execnz 4158                                      // 000000033798: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003379C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000337A0: BE882007
	s_cbranch_execnz 4227                                      // 0000000337A4: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7cb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337A8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000337AC: BE882000
	s_cbranch_execnz 4296                                      // 0000000337B0: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7dd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337B4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000337B8: BE882001
	s_cbranch_execnz 4365                                      // 0000000337BC: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ef4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337C0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000337C4: BE882002
	s_cbranch_execnz 4434                                      // 0000000337C8: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8014>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337CC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000337D0: BE882003
	s_cbranch_execnz 4503                                      // 0000000337D4: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8134>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337D8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000337DC: BE882004
	s_cbranch_execnz 4572                                      // 0000000337E0: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8254>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000337E8: BE882005
	s_cbranch_execnz 4641                                      // 0000000337EC: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8374>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337F0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000337F4: BE882006
	s_cbranch_execnz 4710                                      // 0000000337F8: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8494>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000337FC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033800: BE882007
	s_cbranch_execnz 4779                                      // 000000033804: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033808: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003380C: BE882000
	s_cbranch_execnz 4848                                      // 000000033810: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033814: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033818: BE882001
	s_cbranch_execnz 4917                                      // 00000003381C: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033820: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033824: BE882002
	s_cbranch_execnz 4986                                      // 000000033828: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8914>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003382C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033830: BE882003
	s_cbranch_execnz 5055                                      // 000000033834: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a34>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033838: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003383C: BE882004
	s_cbranch_execnz 5124                                      // 000000033840: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b54>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033844: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033848: BE882005
	s_cbranch_execnz 5193                                      // 00000003384C: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c74>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033850: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033854: BE882006
	s_cbranch_execnz 5262                                      // 000000033858: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003385C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033860: BE882007
	s_cbranch_execnz 5331                                      // 000000033864: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8eb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033868: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003386C: BE882000
	s_cbranch_execnz 5400                                      // 000000033870: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8fd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033874: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033878: BE882001
	s_cbranch_execnz 5469                                      // 00000003387C: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033880: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033884: BE882002
	s_cbranch_execnz 5538                                      // 000000033888: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9214>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003388C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033890: BE882003
	s_cbranch_execnz 5607                                      // 000000033894: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9334>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033898: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003389C: BE882004
	s_cbranch_execnz 5676                                      // 0000000338A0: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9454>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338A4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000338A8: BE882005
	s_cbranch_execnz 5745                                      // 0000000338AC: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9574>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338B0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000338B4: BE882006
	s_cbranch_execnz 5814                                      // 0000000338B8: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9694>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000338C0: BE882007
	s_cbranch_execnz 5883                                      // 0000000338C4: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000338CC: BE882000
	s_cbranch_execnz 5952                                      // 0000000338D0: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000338D8: BE882001
	s_cbranch_execnz 6021                                      // 0000000338DC: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000338E4: BE882002
	s_cbranch_execnz 6090                                      // 0000000338E8: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000338F0: BE882003
	s_cbranch_execnz 6159                                      // 0000000338F4: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000338F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000338FC: BE882004
	s_cbranch_execnz 6228                                      // 000000033900: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d54>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033904: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033908: BE882005
	s_cbranch_execnz 6297                                      // 00000003390C: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e74>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033910: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033914: BE882006
	s_cbranch_execnz 6366                                      // 000000033918: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003391C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033920: BE882007
	s_cbranch_execnz 6435                                      // 000000033924: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033928: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003392C: BE882000
	s_cbranch_execnz 6504                                      // 000000033930: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033934: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033938: BE882001
	s_cbranch_execnz 6573                                      // 00000003393C: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033940: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033944: BE882002
	s_cbranch_execnz 6642                                      // 000000033948: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa414>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003394C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033950: BE882003
	s_cbranch_execnz 6711                                      // 000000033954: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa534>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033958: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003395C: BE882004
	s_cbranch_execnz 6780                                      // 000000033960: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa654>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033964: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033968: BE882005
	s_cbranch_execnz 6849                                      // 00000003396C: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa774>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033970: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033974: BE882006
	s_cbranch_execnz 6918                                      // 000000033978: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa894>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003397C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033980: BE882007
	s_cbranch_execnz 6987                                      // 000000033984: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033988: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003398C: BE882000
	s_cbranch_execnz 7056                                      // 000000033990: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaad4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033994: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033998: BE882001
	s_cbranch_execnz 7125                                      // 00000003399C: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xabf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000339A4: BE882002
	s_cbranch_execnz 7194                                      // 0000000339A8: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339AC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000339B0: BE882003
	s_cbranch_execnz 7263                                      // 0000000339B4: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339B8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000339BC: BE882004
	s_cbranch_execnz 7332                                      // 0000000339C0: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339C4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000339C8: BE882005
	s_cbranch_execnz 7401                                      // 0000000339CC: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb074>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000339D4: BE882006
	s_cbranch_execnz 7470                                      // 0000000339D8: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb194>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339DC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000339E0: BE882007
	s_cbranch_execnz 7539                                      // 0000000339E4: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339E8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000339EC: BE882000
	s_cbranch_execnz 7608                                      // 0000000339F0: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000339F4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000339F8: BE882001
	s_cbranch_execnz 7677                                      // 0000000339FC: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A00: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033A04: BE882002
	s_cbranch_execnz 7746                                      // 000000033A08: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb614>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A0C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033A10: BE882003
	s_cbranch_execnz 7815                                      // 000000033A14: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb734>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A18: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000033A1C: BE882004
	s_cbranch_execnz 7884                                      // 000000033A20: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb854>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A24: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000033A28: BE882005
	s_cbranch_execnz 7953                                      // 000000033A2C: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb974>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000033A34: BE882006
	s_cbranch_execnz 8022                                      // 000000033A38: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba94>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A3C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000033A40: BE882007
	s_cbranch_execnz 8091                                      // 000000033A44: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A48: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000033A4C: BE882000
	s_cbranch_execnz 8160                                      // 000000033A50: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033A54: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000033A58: BE802001
	s_cbranch_execnz 8229                                      // 000000033A5C: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbdf4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A60: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000033A64: BE802002
	s_cbranch_execnz 8298                                      // 000000033A68: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf14>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A6C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000033A70: BE802003
	s_cbranch_execnz 8367                                      // 000000033A74: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc034>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A78: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000033A7C: BE802004
	s_cbranch_execnz 8436                                      // 000000033A80: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc154>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A84: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000033A88: BE802005
	s_cbranch_execnz 8505                                      // 000000033A8C: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc274>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A90: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000033A94: BE802006
	s_cbranch_execnz 8574                                      // 000000033A98: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc394>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000033A9C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000033AA0: BE802007
	s_cbranch_execnz 8643                                      // 000000033AA4: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc4b4>
	s_nop 0                                                    // 000000033AA8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000033AAC: BFB60003
	s_endpgm                                                   // 000000033AB0: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 000000033AB4: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000033AC0: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000033AC4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000033ACC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000033AD0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033AD4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000033AD8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000033AE0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000033AEC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000033AF0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000033AF4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000033AF8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000033B00: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000033B08: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000033B0C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000033B10: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000033B14: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B18: BF870095
	.long 0xd71c008e                                           // 000000033B1C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000033B20: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000033B24: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000033B28: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B30: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000033B34: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000033B3C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B40: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 000000033B44: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000033B4C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B50: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000033B54: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000033B5C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000033B60: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B68: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000033B6C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000033B70: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B78: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000033B7C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000033B80: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033B88: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000033B8C: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000033B94: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000033B9C: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033BA8: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000033BAC: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000033BB4: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000033BC0: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033BC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000033BCC: BE882000
	s_cbranch_execz 65104                                      // 000000033BD0: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000033BD4: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000033BE0: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000033BE4: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 000000033BEC: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 000000033BF0: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033BF4: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 000000033BF8: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 000000033C00: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000033C0C: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000033C10: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 000000033C14: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 000000033C18: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 000000033C20: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000033C28: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000033C2C: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000033C30: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 000000033C34: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C38: BF870095
	.long 0xd71c008d                                           // 000000033C3C: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000033C40: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000033C44: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000033C48: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C50: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000033C54: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000033C5C: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C60: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 000000033C64: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 000000033C6C: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C70: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000033C74: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 000000033C7C: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000033C80: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C88: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 000000033C8C: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000033C90: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033C98: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 000000033C9C: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000033CA0: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033CA8: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000033CAC: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 000000033CB4: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000033CBC: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033CC8: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 000000033CCC: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 000000033CD4: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 000000033CE0: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033CE8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000033CEC: BE882001
	s_cbranch_execz 65035                                      // 000000033CF0: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000033CF4: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 000000033D00: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 000000033D04: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 000000033D0C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000033D10: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033D14: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 000000033D18: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 000000033D20: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 000000033D2C: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000033D30: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 000000033D34: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000033D38: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 000000033D40: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000033D48: BF870121
	v_add_f32_e32 v128, v128, v141                             // 000000033D4C: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 000000033D50: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 000000033D54: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033D58: BF870095
	.long 0xd71c0080                                           // 000000033D5C: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000033D60: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 000000033D64: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000033D68: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033D70: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 000000033D74: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000033D7C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033D80: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 000000033D84: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000033D8C: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033D90: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 000000033D94: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000033D9C: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000033DA0: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033DA8: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000033DAC: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000033DB0: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033DB8: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000033DBC: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000033DC0: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033DC8: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000033DCC: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000033DD4: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000033DDC: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033DE8: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000033DEC: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 000000033DF4: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 000000033E00: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033E08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000033E0C: BE882002
	s_cbranch_execz 64966                                      // 000000033E10: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 000000033E14: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000033E20: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000033E28: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000033E2C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033E30: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000033E34: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 000000033E3C: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 000000033E48: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000033E4C: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 000000033E50: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000033E58: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000033E5C: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000033E60: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 000000033E64: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000033E68: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000033E70: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033E74: BF870095
	.long 0xd71c0072                                           // 000000033E78: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 000000033E7C: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000033E80: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000033E84: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033E8C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000033E90: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000033E9C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033EA0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000033EA4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000033EAC: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033EB0: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 000000033EB4: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000033EBC: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000033EC0: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033EC8: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000033ECC: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 000000033ED0: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033ED8: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000033EDC: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 000000033EE0: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033EE8: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000033EEC: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000033EF4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 000000033EFC: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033F08: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 000000033F0C: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 000000033F14: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000033F20: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000033F28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000033F2C: BE882003
	s_cbranch_execz 64897                                      // 000000033F30: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 000000033F34: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000033F40: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000033F48: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000033F4C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033F50: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000033F54: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000033F5C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000033F68: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000033F6C: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000033F70: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000033F74: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000033F7C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000033F84: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000033F88: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000033F8C: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000033F90: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033F94: BF870095
	.long 0xd71c0072                                           // 000000033F98: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000033F9C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000033FA0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000033FA4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033FAC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000033FB0: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000033FBC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033FC0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000033FC4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000033FCC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033FD0: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 000000033FD4: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000033FDC: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 000000033FE0: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033FE8: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000033FEC: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 000000033FF0: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033FF8: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 000000033FFC: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 000000034000: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034008: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 00000003400C: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000034014: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 00000003401C: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034028: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000003402C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000034034: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000034040: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034048: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003404C: BE882004
	s_cbranch_execz 64828                                      // 000000034050: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 000000034054: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000034060: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000034068: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000003406C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034070: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000034074: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000003407C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000034088: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003408C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000034090: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000034094: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000003409C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000340A4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000340A8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000340AC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000340B0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000340B4: BF870095
	.long 0xd71c0072                                           // 0000000340B8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000340BC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000340C0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000340C4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000340CC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000340D0: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000340DC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000340E0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000340E4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000340EC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000340F0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000340F4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000340FC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000034100: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034108: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 00000003410C: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 000000034110: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034118: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 00000003411C: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 000000034120: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034128: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 00000003412C: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000034134: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 00000003413C: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034148: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000003414C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000034154: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000034160: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034168: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003416C: BE882005
	s_cbranch_execz 64759                                      // 000000034170: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 000000034174: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000034180: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000034188: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000003418C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034190: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000034194: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000003419C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000341A8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000341AC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000341B0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000341B4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000341BC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000341C4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000341C8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000341CC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000341D0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000341D4: BF870095
	.long 0xd71c0072                                           // 0000000341D8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000341DC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000341E0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000341E4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000341EC: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000341F0: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000341F8: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034200: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000034204: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000003420C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034210: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000034214: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000003421C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000034220: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034228: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000003422C: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 000000034230: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034238: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 00000003423C: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 000000034240: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034248: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000003424C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000034254: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000003425C: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034268: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000003426C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000034274: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000034280: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034288: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003428C: BE882006
	s_cbranch_execz 64690                                      // 000000034290: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 000000034294: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000342A0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000342A8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000342AC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000342B0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000342B4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000342BC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000342C8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000342CC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000342D0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000342D4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000342DC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000342E4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000342E8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000342EC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000342F0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000342F4: BF870095
	.long 0xd71c0072                                           // 0000000342F8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000342FC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000034300: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000034304: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003430C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 000000034310: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000003431C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034320: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000034324: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000003432C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034330: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000034334: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000003433C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000034340: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034348: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000003434C: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000034350: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034358: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000003435C: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000034360: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034368: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000003436C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000034374: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000003437C: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034388: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000003438C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000034394: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000343A0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000343A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000343AC: BE882007
	s_cbranch_execz 64621                                      // 0000000343B0: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000343B4: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000343C0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000343C8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000343CC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000343D0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000343D4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000343DC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000343E8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000343EC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000343F0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000343F4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000343FC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034404: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000034408: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000003440C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000034410: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034414: BF870095
	.long 0xd71c0072                                           // 000000034418: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000003441C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000034420: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000034424: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003442C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 000000034430: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000003443C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034440: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000034444: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000003444C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034450: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000034454: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000003445C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000034460: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034468: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000003446C: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000034470: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034478: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000003447C: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000034480: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034488: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000003448C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000034494: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 00000003449C: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000344A8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000344AC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000344B4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000344C0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000344C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000344CC: BE882000
	s_cbranch_execz 64552                                      // 0000000344D0: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000344D4: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000344E0: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000344E4: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000344EC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000344F0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000344F4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000344F8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000034500: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000003450C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034510: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000034514: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000034518: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000034520: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034528: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000003452C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000034530: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000034534: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034538: BF870095
	.long 0xd71c0072                                           // 00000003453C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000034540: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000034544: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000034548: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034550: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000034554: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000003455C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034560: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 000000034564: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 00000003456C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034570: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000034574: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000003457C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 000000034580: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034588: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000003458C: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000034590: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034598: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000003459C: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000345A0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000345A8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000345AC: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000345B4: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000345BC: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000345C8: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000345CC: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000345D4: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000345E0: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000345E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000345EC: BE882001
	s_cbranch_execz 64483                                      // 0000000345F0: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000345F4: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000034600: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 000000034604: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 00000003460C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000034610: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034614: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000034618: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034620: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 000000034628: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000034634: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000034638: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 00000003463C: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 000000034644: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034648: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000003464C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000034650: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000034654: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034658: BF870095
	.long 0xd71c0071                                           // 00000003465C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000034660: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000034664: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034668: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034670: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 000000034674: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000003467C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034680: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000034684: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 00000003468C: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034690: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000034694: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000003469C: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000346A0: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000346A8: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000346AC: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000346B0: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000346B8: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000346BC: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000346C0: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000346C8: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000346CC: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000346D4: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000346DC: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000346E8: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000346EC: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000346F4: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000034700: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034708: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003470C: BE882002
	s_cbranch_execz 64414                                      // 000000034710: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000034714: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034720: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034728: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000003472C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034730: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034734: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 00000003473C: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000034748: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003474C: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000034750: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034754: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 00000003475C: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034764: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000034768: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 00000003476C: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000034770: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034774: BF870095
	.long 0xd71c006a                                           // 000000034778: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 00000003477C: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000034780: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034784: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003478C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000034790: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000003479C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347A0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000347A4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000347AC: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347B0: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000347B4: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000347BC: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000347C0: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347C8: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000347CC: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000347D0: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347D8: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000347DC: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000347E0: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347E8: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000347EC: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000347F4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000347FC: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034808: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 00000003480C: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000034814: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034820: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034828: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003482C: BE882003
	s_cbranch_execz 64345                                      // 000000034830: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3898>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000034834: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034840: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034848: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000003484C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034850: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034854: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000003485C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000034868: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003486C: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000034870: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 00000003487C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000034880: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034884: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003488C: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000034890: 7ED44B6A
	.long 0xd71c006a                                           // 000000034894: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000034898: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003489C: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000348A0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000348A4: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000348AC: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000348B8: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000348BC: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000348C0: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000348C8: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000348CC: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000348D0: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000348D8: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000348DC: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000348E0: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000348E8: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000348EC: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000348F0: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000348F8: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000348FC: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000034900: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000034908: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034910: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000034914: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 00000003491C: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000034928: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034930: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000034934: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034940: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034948: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003494C: BE882004
	s_cbranch_execz 64276                                      // 000000034950: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000034954: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034960: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034968: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000003496C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034970: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034974: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000003497C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000034988: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003498C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000034990: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034994: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000003499C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000349A4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000349A8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000349AC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000349B0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000349B4: BF870095
	.long 0xd71c006a                                           // 0000000349B8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000349BC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000349C0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000349C4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000349CC: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000349D0: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000349DC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000349E0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000349E4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000349EC: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000349F0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000349F4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000349FC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000034A00: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034A08: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000034A0C: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000034A10: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034A18: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000034A1C: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000034A20: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034A28: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000034A2C: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000034A34: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000034A3C: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034A48: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000034A4C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000034A54: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034A60: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034A68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000034A6C: BE882005
	s_cbranch_execz 64207                                      // 000000034A70: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000034A74: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034A80: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034A88: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000034A8C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034A90: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034A94: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000034A9C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000034AA8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034AAC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000034AB0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034AB4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000034ABC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034AC4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000034AC8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000034ACC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000034AD0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034AD4: BF870095
	.long 0xd71c006a                                           // 000000034AD8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000034ADC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000034AE0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034AE4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034AEC: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000034AF0: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000034AF8: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B00: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000034B04: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000034B0C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B10: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000034B14: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000034B1C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000034B20: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B28: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000034B2C: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000034B30: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B38: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000034B3C: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000034B40: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B48: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000034B4C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000034B54: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000034B5C: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034B68: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000034B6C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000034B74: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034B80: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034B88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000034B8C: BE882006
	s_cbranch_execz 64138                                      // 000000034B90: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38bc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000034B94: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034BA0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034BA8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000034BAC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034BB0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034BB4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000034BBC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000034BC8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034BCC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000034BD0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034BD4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000034BDC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034BE4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000034BE8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000034BEC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000034BF0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034BF4: BF870095
	.long 0xd71c006a                                           // 000000034BF8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000034BFC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000034C00: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034C04: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C0C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 000000034C10: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000034C1C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C20: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000034C24: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000034C2C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C30: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000034C34: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000034C3C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000034C40: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C48: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000034C4C: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000034C50: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C58: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000034C5C: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000034C60: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C68: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000034C6C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000034C74: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 000000034C7C: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034C88: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000034C8C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000034C94: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034CA0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034CA8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000034CAC: BE882007
	s_cbranch_execz 64069                                      // 000000034CB0: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 000000034CB4: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000034CC0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034CC8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000034CCC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034CD0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034CD4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000034CDC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000034CE8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034CEC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000034CF0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034CF4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000034CFC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034D04: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000034D08: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000034D0C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000034D10: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D14: BF870095
	.long 0xd71c006a                                           // 000000034D18: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000034D1C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000034D20: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034D24: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D2C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 000000034D30: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000034D3C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D40: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000034D44: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000034D4C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D50: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000034D54: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000034D5C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000034D60: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D68: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000034D6C: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000034D70: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D78: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000034D7C: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000034D80: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034D88: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000034D8C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000034D94: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 000000034D9C: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034DA8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000034DAC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000034DB4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000034DC0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034DC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000034DCC: BE882000
	s_cbranch_execz 64000                                      // 000000034DD0: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000034DD4: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000034DE0: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000034DE4: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 000000034DEC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000034DF0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034DF4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000034DF8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000034E00: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000034E0C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034E10: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000034E14: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000034E18: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000034E20: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034E28: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000034E2C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000034E30: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000034E34: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E38: BF870095
	.long 0xd71c006a                                           // 000000034E3C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000034E40: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000034E44: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000034E48: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E50: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000034E54: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000034E5C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E60: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 000000034E64: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 000000034E6C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E70: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000034E74: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000034E7C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 000000034E80: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E88: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000034E8C: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000034E90: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034E98: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000034E9C: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000034EA0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034EA8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000034EAC: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 000000034EB4: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000034EBC: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034EC8: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000034ECC: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000034ED4: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 000000034EE0: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000034EE8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000034EEC: BE882001
	s_cbranch_execz 63931                                      // 000000034EF0: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 000000034EF4: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 000000034F00: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 000000034F04: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 000000034F0C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000034F10: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034F14: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 000000034F18: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000034F20: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 000000034F28: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000034F34: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000034F38: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 000000034F3C: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 000000034F44: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000034F48: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000034F4C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000034F50: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000034F54: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034F58: BF870095
	.long 0xd71c0069                                           // 000000034F5C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000034F60: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000034F64: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000034F68: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034F70: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 000000034F74: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000034F7C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034F80: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 000000034F84: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000034F8C: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034F90: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000034F94: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000034F9C: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000034FA0: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034FA8: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000034FAC: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000034FB0: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034FB8: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000034FBC: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000034FC0: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034FC8: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000034FCC: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000034FD4: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000034FDC: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034FE8: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000034FEC: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 000000034FF4: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 000000035000: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035008: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003500C: BE882002
	s_cbranch_execz 63862                                      // 000000035010: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38ec>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 000000035014: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000035020: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000035028: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000003502C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035030: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000035034: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 00000003503C: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 000000035048: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003504C: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 000000035050: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000035054: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000003505C: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035064: BF870121
	v_add_f32_e32 v98, v98, v105                               // 000000035068: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000003506C: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 000000035070: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035074: BF870095
	.long 0xd71c0062                                           // 000000035078: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000003507C: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000035080: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000035084: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003508C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000035090: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000003509C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000350A0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000350A4: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000350AC: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000350B0: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000350B4: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000350BC: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000350C0: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000350C8: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000350CC: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000350D0: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000350D8: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000350DC: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000350E0: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000350E8: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000350EC: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000350F4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000350FC: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035108: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 00000003510C: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 000000035114: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000035120: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035128: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003512C: BE882003
	s_cbranch_execz 63793                                      // 000000035130: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 000000035134: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000035140: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000035148: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000003514C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035150: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000035154: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000003515C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 000000035168: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003516C: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 000000035170: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000003517C: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 000000035180: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000035184: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003518C: BF870293
	v_exp_f32_e32 v98, v98                                     // 000000035190: 7EC44B62
	.long 0xd71c0062                                           // 000000035194: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000035198: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003519C: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000351A0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000351A4: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000351AC: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000351B8: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000351BC: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000351C0: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000351C8: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000351CC: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000351D0: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000351D8: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000351DC: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000351E0: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000351E8: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000351EC: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000351F0: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000351F8: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000351FC: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 000000035200: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 000000035208: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035210: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000035214: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 00000003521C: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 000000035228: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 000000035230: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000035234: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000035240: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035248: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003524C: BE882004
	s_cbranch_execz 63724                                      // 000000035250: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3904>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 000000035254: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000035260: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000035268: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000003526C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035270: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000035274: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000003527C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000035288: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003528C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000035290: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000035294: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000003529C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000352A4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000352A8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000352AC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000352B0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000352B4: BF870095
	.long 0xd71c0062                                           // 0000000352B8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000352BC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000352C0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000352C4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000352CC: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000352D0: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000352DC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000352E0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000352E4: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000352EC: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000352F0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000352F4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000352FC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000035300: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035308: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 00000003530C: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 000000035310: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035318: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 00000003531C: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 000000035320: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035328: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 00000003532C: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000035334: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 00000003533C: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035348: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000003534C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000035354: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000035360: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035368: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003536C: BE882005
	s_cbranch_execz 63655                                      // 000000035370: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 000000035374: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000035380: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000035388: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000003538C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035390: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000035394: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000003539C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000353A8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000353AC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000353B0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000353B4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000353BC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000353C4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000353C8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000353CC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000353D0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000353D4: BF870095
	.long 0xd71c0062                                           // 0000000353D8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000353DC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000353E0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000353E4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000353EC: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000353F0: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000353F8: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035400: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000035404: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000003540C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035410: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000035414: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000003541C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000035420: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035428: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000003542C: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 000000035430: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035438: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 00000003543C: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 000000035440: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035448: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000003544C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000035454: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 00000003545C: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035468: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000003546C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000035474: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000035480: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035488: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003548C: BE882006
	s_cbranch_execz 63586                                      // 000000035490: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x391c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 000000035494: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000354A0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000354A8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000354AC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000354B0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000354B4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000354BC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000354C8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000354CC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000354D0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000354D4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000354DC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000354E4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000354E8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000354EC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000354F0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000354F4: BF870095
	.long 0xd71c0062                                           // 0000000354F8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000354FC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000035500: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000035504: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003550C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000035510: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000003551C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035520: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000035524: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000003552C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035530: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000035534: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000003553C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000035540: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035548: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000003554C: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000035550: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035558: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000003555C: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000035560: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035568: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000003556C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000035574: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 00000003557C: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035588: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000003558C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000035594: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000355A0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000355A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000355AC: BE882007
	s_cbranch_execz 63517                                      // 0000000355B0: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3928>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000355B4: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000355C0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000355C8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000355CC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000355D0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000355D4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000355DC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000355E8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000355EC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000355F0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000355F4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000355FC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035604: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000035608: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000003560C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000035610: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035614: BF870095
	.long 0xd71c0062                                           // 000000035618: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000003561C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000035620: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000035624: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003562C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000035630: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000003563C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035640: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000035644: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000003564C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035650: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000035654: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000003565C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000035660: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035668: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000003566C: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000035670: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035678: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000003567C: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000035680: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035688: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000003568C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000035694: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 00000003569C: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000356A8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000356AC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000356B4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000356C0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000356C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000356CC: BE882000
	s_cbranch_execz 63448                                      // 0000000356D0: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3934>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000356D4: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000356E0: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000356E4: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000356EC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000356F0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000356F4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000356F8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000035700: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000003570C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000035710: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000035714: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000035718: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000035720: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035728: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000003572C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000035730: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000035734: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035738: BF870095
	.long 0xd71c0062                                           // 00000003573C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000035740: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000035744: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000035748: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035750: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000035754: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000003575C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035760: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 000000035764: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 00000003576C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035770: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000035774: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000003577C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 000000035780: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035788: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000003578C: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000035790: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035798: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000003579C: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000357A0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000357A8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000357AC: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000357B4: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000357BC: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000357C8: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000357CC: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000357D4: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000357E0: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000357E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000357EC: BE882001
	s_cbranch_execz 63379                                      // 0000000357F0: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3940>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000357F4: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000035800: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000035804: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 00000003580C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035810: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035814: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000035818: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035820: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000035828: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000035834: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000035838: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 00000003583C: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 000000035844: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035848: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000003584C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000035850: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000035854: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035858: BF870095
	.long 0xd71c0061                                           // 00000003585C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000035860: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000035864: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035868: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035870: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000035874: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000003587C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035880: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000035884: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 00000003588C: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035890: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000035894: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 00000003589C: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000358A0: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000358A8: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000358AC: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000358B0: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000358B8: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000358BC: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000358C0: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000358C8: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000358CC: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000358D4: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000358DC: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000358E8: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000358EC: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000358F4: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000035900: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035908: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003590C: BE882002
	s_cbranch_execz 63310                                      // 000000035910: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x394c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000035914: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035920: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035928: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000003592C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035930: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035934: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 00000003593C: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000035948: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003594C: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000035950: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035954: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 00000003595C: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035964: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000035968: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 00000003596C: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000035970: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035974: BF870095
	.long 0xd71c005a                                           // 000000035978: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 00000003597C: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035980: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035984: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003598C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000035990: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000003599C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000359A0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000359A4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000359AC: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000359B0: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000359B4: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000359BC: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000359C0: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000359C8: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000359CC: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000359D0: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000359D8: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000359DC: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000359E0: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000359E8: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000359EC: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000359F4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000359FC: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035A08: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000035A0C: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000035A14: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035A20: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035A28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000035A2C: BE882003
	s_cbranch_execz 63241                                      // 000000035A30: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3958>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000035A34: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035A40: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035A48: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035A4C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035A50: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035A54: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000035A5C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000035A68: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035A6C: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000035A70: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000035A7C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000035A80: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035A84: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000035A8C: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000035A90: 7EB44B5A
	.long 0xd71c005a                                           // 000000035A94: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000035A98: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035A9C: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035AA0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035AA4: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000035AAC: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035AB8: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000035ABC: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000035AC0: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000035AC8: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000035ACC: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000035AD0: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035AD8: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000035ADC: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000035AE0: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000035AE8: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035AEC: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000035AF0: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000035AF8: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035AFC: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000035B00: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000035B08: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035B10: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000035B14: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000035B1C: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000035B28: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000035B30: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000035B34: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035B40: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035B48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000035B4C: BE882004
	s_cbranch_execz 63172                                      // 000000035B50: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3964>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000035B54: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035B60: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035B68: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035B6C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035B70: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035B74: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000035B7C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000035B88: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000035B8C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000035B90: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035B94: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000035B9C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035BA4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000035BA8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000035BAC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000035BB0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035BB4: BF870095
	.long 0xd71c005a                                           // 000000035BB8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000035BBC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035BC0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035BC4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035BCC: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000035BD0: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000035BDC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035BE0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000035BE4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000035BEC: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035BF0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000035BF4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000035BFC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000035C00: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035C08: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000035C0C: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000035C10: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035C18: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000035C1C: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000035C20: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035C28: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000035C2C: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000035C34: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000035C3C: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035C48: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000035C4C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000035C54: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035C60: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035C68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000035C6C: BE882005
	s_cbranch_execz 63103                                      // 000000035C70: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3970>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000035C74: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035C80: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035C88: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035C8C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035C90: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035C94: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000035C9C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000035CA8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000035CAC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000035CB0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035CB4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000035CBC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035CC4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000035CC8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000035CCC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000035CD0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035CD4: BF870095
	.long 0xd71c005a                                           // 000000035CD8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000035CDC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035CE0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035CE4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035CEC: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000035CF0: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000035CF8: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D00: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000035D04: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000035D0C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D10: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000035D14: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000035D1C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000035D20: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D28: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000035D2C: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000035D30: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D38: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000035D3C: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000035D40: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D48: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000035D4C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000035D54: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000035D5C: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035D68: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000035D6C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000035D74: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035D80: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035D88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000035D8C: BE882006
	s_cbranch_execz 63034                                      // 000000035D90: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x397c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000035D94: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035DA0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035DA8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035DAC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035DB0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035DB4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000035DBC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000035DC8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000035DCC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000035DD0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035DD4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000035DDC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035DE4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000035DE8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000035DEC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000035DF0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035DF4: BF870095
	.long 0xd71c005a                                           // 000000035DF8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000035DFC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035E00: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035E04: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E0C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 000000035E10: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000035E1C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E20: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000035E24: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000035E2C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E30: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000035E34: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000035E3C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000035E40: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E48: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000035E4C: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000035E50: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E58: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000035E5C: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000035E60: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E68: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000035E6C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000035E74: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000035E7C: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035E88: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000035E8C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000035E94: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035EA0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035EA8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000035EAC: BE882007
	s_cbranch_execz 62965                                      // 000000035EB0: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3988>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000035EB4: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000035EC0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035EC8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035ECC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035ED0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035ED4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000035EDC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000035EE8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000035EEC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000035EF0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000035EF4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000035EFC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000035F04: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000035F08: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000035F0C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000035F10: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F14: BF870095
	.long 0xd71c005a                                           // 000000035F18: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000035F1C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000035F20: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000035F24: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F2C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 000000035F30: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000035F3C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F40: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000035F44: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000035F4C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F50: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000035F54: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000035F5C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000035F60: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F68: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000035F6C: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000035F70: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F78: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000035F7C: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000035F80: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035F88: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000035F8C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000035F94: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000035F9C: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035FA8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000035FAC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000035FB4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000035FC0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000035FC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000035FCC: BE882000
	s_cbranch_execz 62896                                      // 000000035FD0: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3994>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000035FD4: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000035FE0: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000035FE4: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000035FEC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000035FF0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035FF4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000035FF8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000036000: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000003600C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036010: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000036014: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000036018: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000036020: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036028: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000003602C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000036030: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000036034: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036038: BF870095
	.long 0xd71c005a                                           // 00000003603C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000036040: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000036044: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000036048: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036050: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000036054: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000003605C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036060: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 000000036064: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000003606C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036070: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000036074: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000003607C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000036080: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036088: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000003608C: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000036090: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036098: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000003609C: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000360A0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000360A8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000360AC: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000360B4: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000360BC: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000360C8: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000360CC: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000360D4: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000360E0: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000360E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000360EC: BE882001
	s_cbranch_execz 62827                                      // 0000000360F0: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39a0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000360F4: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 000000036100: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 000000036104: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 00000003610C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000036110: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036114: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 000000036118: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000036120: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 000000036128: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000036134: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000036138: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 00000003613C: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 000000036144: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036148: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000003614C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000036150: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000036154: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036158: BF870095
	.long 0xd71c0059                                           // 00000003615C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000036160: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000036164: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000036168: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036170: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 000000036174: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000003617C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036180: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 000000036184: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000003618C: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036190: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000036194: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000003619C: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000361A0: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000361A8: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000361AC: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000361B0: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000361B8: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000361BC: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000361C0: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000361C8: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000361CC: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000361D4: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000361DC: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000361E8: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000361EC: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000361F4: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 000000036200: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036208: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003620C: BE882002
	s_cbranch_execz 62758                                      // 000000036210: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ac>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 000000036214: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000036220: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000036228: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000003622C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036230: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000036234: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 00000003623C: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 000000036248: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003624C: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 000000036250: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000036254: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000003625C: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036264: BF870121
	v_add_f32_e32 v82, v82, v89                                // 000000036268: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000003626C: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 000000036270: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036274: BF870095
	.long 0xd71c0052                                           // 000000036278: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000003627C: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000036280: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000036284: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003628C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000036290: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000003629C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000362A0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000362A4: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000362AC: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000362B0: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000362B4: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000362BC: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000362C0: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000362C8: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000362CC: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000362D0: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000362D8: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000362DC: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000362E0: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000362E8: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000362EC: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000362F4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000362FC: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036308: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 00000003630C: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 000000036314: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000036320: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036328: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003632C: BE882003
	s_cbranch_execz 62689                                      // 000000036330: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 000000036334: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000036340: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000036348: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000003634C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036350: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000036354: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000003635C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 000000036368: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003636C: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 000000036370: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000003637C: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 000000036380: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000036384: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003638C: BF870293
	v_exp_f32_e32 v82, v82                                     // 000000036390: 7EA44B52
	.long 0xd71c0052                                           // 000000036394: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000036398: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003639C: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000363A0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000363A4: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000363AC: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000363B8: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000363BC: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000363C0: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000363C8: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000363CC: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000363D0: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000363D8: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000363DC: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000363E0: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000363E8: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000363EC: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000363F0: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000363F8: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000363FC: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000036400: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 000000036408: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036410: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000036414: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 00000003641C: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 000000036428: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 000000036430: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000036434: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000036440: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036448: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003644C: BE882004
	s_cbranch_execz 62620                                      // 000000036450: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 000000036454: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000036460: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000036468: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000003646C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036470: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000036474: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000003647C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000036488: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003648C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000036490: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000036494: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000003649C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000364A4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000364A8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000364AC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000364B0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000364B4: BF870095
	.long 0xd71c0052                                           // 0000000364B8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000364BC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000364C0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000364C4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000364CC: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000364D0: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000364DC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000364E0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000364E4: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000364EC: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000364F0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000364F4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000364FC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000036500: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036508: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 00000003650C: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000036510: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036518: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 00000003651C: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000036520: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036528: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 00000003652C: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000036534: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 00000003653C: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036548: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000003654C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000036554: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000036560: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036568: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003656C: BE882005
	s_cbranch_execz 62551                                      // 000000036570: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39d0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 000000036574: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000036580: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000036588: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000003658C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036590: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000036594: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000003659C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000365A8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000365AC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000365B0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000365B4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000365BC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000365C4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000365C8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000365CC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000365D0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000365D4: BF870095
	.long 0xd71c0052                                           // 0000000365D8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000365DC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000365E0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000365E4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000365EC: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000365F0: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000365F8: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036600: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000036604: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000003660C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036610: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000036614: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000003661C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000036620: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036628: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000003662C: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 000000036630: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036638: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 00000003663C: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 000000036640: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036648: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000003664C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000036654: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 00000003665C: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036668: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000003666C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000036674: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000036680: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036688: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003668C: BE882006
	s_cbranch_execz 62482                                      // 000000036690: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39dc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 000000036694: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000366A0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000366A8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000366AC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000366B0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000366B4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000366BC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000366C8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000366CC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000366D0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000366D4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000366DC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000366E4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000366E8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000366EC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000366F0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000366F4: BF870095
	.long 0xd71c0052                                           // 0000000366F8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000366FC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000036700: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000036704: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003670C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000036710: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000003671C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036720: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000036724: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000003672C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036730: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000036734: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000003673C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000036740: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036748: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000003674C: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000036750: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036758: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000003675C: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000036760: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036768: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000003676C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000036774: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 00000003677C: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036788: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000003678C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000036794: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000367A0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000367A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000367AC: BE882007
	s_cbranch_execz 62413                                      // 0000000367B0: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39e8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000367B4: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000367C0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000367C8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000367CC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000367D0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000367D4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000367DC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000367E8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000367EC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000367F0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000367F4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000367FC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036804: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000036808: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000003680C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000036810: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036814: BF870095
	.long 0xd71c0052                                           // 000000036818: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000003681C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000036820: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000036824: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003682C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000036830: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000003683C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036840: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000036844: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000003684C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036850: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000036854: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000003685C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000036860: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036868: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000003686C: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000036870: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036878: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000003687C: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000036880: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036888: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000003688C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000036894: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 00000003689C: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000368A8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000368AC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000368B4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000368C0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000368C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000368CC: BE882000
	s_cbranch_execz 62344                                      // 0000000368D0: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39f4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000368D4: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000368E0: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000368E4: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000368EC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000368F0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000368F4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000368F8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000036900: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000003690C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036910: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000036914: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000036918: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000036920: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036928: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000003692C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000036930: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000036934: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036938: BF870095
	.long 0xd71c0052                                           // 00000003693C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000036940: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000036944: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000036948: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036950: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000036954: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000003695C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036960: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 000000036964: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 00000003696C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036970: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000036974: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000003697C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000036980: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036988: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000003698C: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000036990: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036998: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000003699C: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000369A0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000369A8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000369AC: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000369B4: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000369BC: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000369C8: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000369CC: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000369D4: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000369E0: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000369E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000369EC: BE882001
	s_cbranch_execz 62275                                      // 0000000369F0: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a00>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000369F4: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000036A00: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000036A04: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000036A0C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036A10: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036A14: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000036A18: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036A20: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000036A28: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000036A34: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000036A38: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000036A3C: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000036A44: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036A48: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000036A4C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000036A50: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000036A54: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036A58: BF870095
	.long 0xd71c0051                                           // 000000036A5C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000036A60: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000036A64: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000036A68: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036A70: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 000000036A74: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000036A7C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036A80: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 000000036A84: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 000000036A8C: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036A90: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000036A94: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000036A9C: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000036AA0: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036AA8: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000036AAC: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000036AB0: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036AB8: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000036ABC: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000036AC0: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036AC8: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000036ACC: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000036AD4: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000036ADC: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036AE8: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000036AEC: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000036AF4: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000036B00: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036B08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000036B0C: BE882002
	s_cbranch_execz 62206                                      // 000000036B10: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a0c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000036B14: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000036B20: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000036B28: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036B2C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036B30: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000036B34: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000036B3C: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000036B48: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036B4C: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000036B50: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036B54: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000036B5C: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036B64: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000036B68: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000036B6C: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000036B70: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036B74: BF870095
	.long 0xd71c004a                                           // 000000036B78: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000036B7C: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000036B80: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000036B84: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036B8C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000036B90: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000036B9C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036BA0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000036BA4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000036BAC: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036BB0: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000036BB4: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000036BBC: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000036BC0: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036BC8: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000036BCC: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000036BD0: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036BD8: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000036BDC: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000036BE0: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036BE8: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000036BEC: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000036BF4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000036BFC: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036C08: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000036C0C: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000036C14: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000036C20: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036C28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000036C2C: BE882003
	s_cbranch_execz 62137                                      // 000000036C30: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a18>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000036C34: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000036C40: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000036C48: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036C4C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036C50: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000036C54: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000036C5C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000036C68: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036C6C: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000036C70: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000036C7C: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000036C80: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036C84: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000036C8C: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000036C90: 7E944B4A
	.long 0xd71c004a                                           // 000000036C94: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000036C98: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036C9C: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000036CA0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000036CA4: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000036CAC: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036CB8: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000036CBC: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000036CC0: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000036CC8: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000036CCC: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000036CD0: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000036CD8: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000036CDC: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000036CE0: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000036CE8: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036CEC: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000036CF0: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000036CF8: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036CFC: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000036D00: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000036D08: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036D10: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000036D14: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000036D1C: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000036D28: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000036D30: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000036D34: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000036D40: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036D48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000036D4C: BE882004
	s_cbranch_execz 62068                                      // 000000036D50: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a24>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000036D54: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000036D60: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000036D68: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036D6C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036D70: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000036D74: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000036D7C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000036D88: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036D8C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000036D90: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036D94: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000036D9C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036DA4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000036DA8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000036DAC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000036DB0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036DB4: BF870095
	.long 0xd71c004a                                           // 000000036DB8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000036DBC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000036DC0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000036DC4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036DCC: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000036DD0: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000036DDC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036DE0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000036DE4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000036DEC: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036DF0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000036DF4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000036DFC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000036E00: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036E08: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000036E0C: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000036E10: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036E18: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000036E1C: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000036E20: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036E28: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000036E2C: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000036E34: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000036E3C: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036E48: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000036E4C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000036E54: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000036E60: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036E68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000036E6C: BE882005
	s_cbranch_execz 61999                                      // 000000036E70: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a30>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 000000036E74: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000036E80: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000036E88: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036E8C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036E90: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000036E94: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000036E9C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000036EA8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036EAC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000036EB0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036EB4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000036EBC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036EC4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000036EC8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000036ECC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000036ED0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036ED4: BF870095
	.long 0xd71c004a                                           // 000000036ED8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000036EDC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000036EE0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000036EE4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036EEC: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000036EF0: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000036EF8: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F00: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000036F04: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000036F0C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F10: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000036F14: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000036F1C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000036F20: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F28: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000036F2C: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000036F30: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F38: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 000000036F3C: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000036F40: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F48: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000036F4C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000036F54: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 000000036F5C: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036F68: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000036F6C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000036F74: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000036F80: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000036F88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000036F8C: BE882006
	s_cbranch_execz 61930                                      // 000000036F90: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a3c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000036F94: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000036FA0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000036FA8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000036FAC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036FB0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000036FB4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000036FBC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000036FC8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000036FCC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000036FD0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000036FD4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000036FDC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000036FE4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000036FE8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000036FEC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000036FF0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000036FF4: BF870095
	.long 0xd71c004a                                           // 000000036FF8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000036FFC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000037000: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000037004: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003700C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000037010: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000003701C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037020: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000037024: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000003702C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037030: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000037034: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000003703C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000037040: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037048: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000003704C: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000037050: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037058: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000003705C: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000037060: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037068: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000003706C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000037074: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 00000003707C: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037088: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000003708C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000037094: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000370A0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000370A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000370AC: BE882007
	s_cbranch_execz 61861                                      // 0000000370B0: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a48>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000370B4: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000370C0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000370C8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000370CC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000370D0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000370D4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000370DC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000370E8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000370EC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000370F0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000370F4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000370FC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037104: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000037108: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000003710C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000037110: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037114: BF870095
	.long 0xd71c004a                                           // 000000037118: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000003711C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000037120: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000037124: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003712C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000037130: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000003713C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037140: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000037144: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000003714C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037150: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000037154: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000003715C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000037160: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037168: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000003716C: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000037170: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037178: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000003717C: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000037180: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037188: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000003718C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000037194: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 00000003719C: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000371A8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000371AC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000371B4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000371C0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000371C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000371CC: BE882000
	s_cbranch_execz 61792                                      // 0000000371D0: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a54>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000371D4: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000371E0: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000371E4: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000371EC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000371F0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000371F4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000371F8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000037200: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000003720C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000037210: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000037214: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000037218: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000037220: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037228: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000003722C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000037230: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000037234: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037238: BF870095
	.long 0xd71c004a                                           // 00000003723C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000037240: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000037244: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000037248: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037250: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000037254: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000003725C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037260: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 000000037264: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 00000003726C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037270: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000037274: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000003727C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 000000037280: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037288: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000003728C: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000037290: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037298: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000003729C: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000372A0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000372A8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000372AC: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000372B4: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000372BC: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000372C8: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000372CC: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000372D4: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000372E0: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000372E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000372EC: BE882001
	s_cbranch_execz 61723                                      // 0000000372F0: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a60>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000372F4: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000037300: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 000000037304: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 00000003730C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000037310: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037314: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000037318: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000037320: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000037328: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 000000037334: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000037338: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 00000003733C: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 000000037344: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037348: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000003734C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000037350: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000037354: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037358: BF870095
	.long 0xd71c0049                                           // 00000003735C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000037360: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000037364: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000037368: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037370: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 000000037374: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000003737C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037380: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 000000037384: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 00000003738C: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037390: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000037394: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000003739C: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000373A0: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000373A8: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000373AC: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000373B0: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000373B8: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000373BC: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000373C0: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000373C8: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000373CC: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000373D4: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000373DC: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000373E8: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000373EC: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000373F4: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000037400: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037408: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003740C: BE882002
	s_cbranch_execz 61654                                      // 000000037410: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a6c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 000000037414: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000037420: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000037428: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000003742C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037430: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000037434: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 00000003743C: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000037448: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003744C: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000037450: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000037454: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 00000003745C: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037464: BF870121
	v_add_f32_e32 v66, v66, v73                                // 000000037468: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 00000003746C: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 000000037470: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037474: BF870095
	.long 0xd71c0042                                           // 000000037478: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 00000003747C: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000037480: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000037484: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003748C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000037490: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000003749C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000374A0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000374A4: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000374AC: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000374B0: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000374B4: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000374BC: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000374C0: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000374C8: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000374CC: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000374D0: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000374D8: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000374DC: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000374E0: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000374E8: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000374EC: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000374F4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000374FC: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037508: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 00000003750C: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000037514: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000037520: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037528: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003752C: BE882003
	s_cbranch_execz 61585                                      // 000000037530: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a78>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 000000037534: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000037540: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000037548: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000003754C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037550: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000037554: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000003755C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 000000037568: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003756C: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 000000037570: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 00000003757C: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 000000037580: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000037584: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003758C: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000037590: 7E844B42
	.long 0xd71c0042                                           // 000000037594: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000037598: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003759C: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000375A0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000375A4: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000375AC: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000375B8: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000375BC: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000375C0: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000375C8: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000375CC: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000375D0: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000375D8: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000375DC: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000375E0: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000375E8: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000375EC: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000375F0: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000375F8: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000375FC: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000037600: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000037608: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037610: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000037614: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 00000003761C: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000037628: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000037630: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000037634: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000037640: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037648: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003764C: BE882004
	s_cbranch_execz 61516                                      // 000000037650: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a84>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 000000037654: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000037660: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000037668: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000003766C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037670: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000037674: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000003767C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000037688: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003768C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000037690: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000037694: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000003769C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000376A4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000376A8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000376AC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000376B0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000376B4: BF870095
	.long 0xd71c0042                                           // 0000000376B8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000376BC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000376C0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000376C4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000376CC: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000376D0: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000376DC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000376E0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000376E4: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000376EC: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000376F0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000376F4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000376FC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000037700: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037708: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 00000003770C: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000037710: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037718: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 00000003771C: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000037720: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037728: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 00000003772C: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000037734: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 00000003773C: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037748: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000003774C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000037754: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000037760: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037768: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003776C: BE882005
	s_cbranch_execz 61447                                      // 000000037770: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a90>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 000000037774: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000037780: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000037788: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000003778C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037790: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000037794: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000003779C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000377A8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000377AC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000377B0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000377B4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000377BC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000377C4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000377C8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000377CC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000377D0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000377D4: BF870095
	.long 0xd71c0042                                           // 0000000377D8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000377DC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000377E0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000377E4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000377EC: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000377F0: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000377F8: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037800: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000037804: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000003780C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037810: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000037814: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000003781C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000037820: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037828: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000003782C: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000037830: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037838: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 00000003783C: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000037840: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037848: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000003784C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000037854: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 00000003785C: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037868: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000003786C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000037874: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000037880: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037888: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003788C: BE882006
	s_cbranch_execz 61378                                      // 000000037890: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a9c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000037894: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000378A0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000378A8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000378AC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000378B0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000378B4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000378BC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000378C8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000378CC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000378D0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000378D4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000378DC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000378E4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000378E8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000378EC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000378F0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000378F4: BF870095
	.long 0xd71c0042                                           // 0000000378F8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000378FC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000037900: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000037904: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003790C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000037910: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000003791C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037920: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000037924: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000003792C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037930: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000037934: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000003793C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000037940: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037948: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000003794C: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000037950: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037958: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000003795C: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000037960: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037968: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000003796C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000037974: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 00000003797C: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037988: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000003798C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000037994: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000379A0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000379A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000379AC: BE882007
	s_cbranch_execz 61309                                      // 0000000379B0: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3aa8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000379B4: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000379C0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000379C8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000379CC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000379D0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000379D4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000379DC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000379E8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000379EC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000379F0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000379F4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000379FC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037A04: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000037A08: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000037A0C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000037A10: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A14: BF870095
	.long 0xd71c0042                                           // 000000037A18: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000037A1C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000037A20: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000037A24: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A2C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000037A30: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000037A3C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A40: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000037A44: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000037A4C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A50: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000037A54: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000037A5C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000037A60: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A68: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000037A6C: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000037A70: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A78: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000037A7C: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000037A80: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037A88: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000037A8C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000037A94: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000037A9C: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037AA8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000037AAC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000037AB4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000037AC0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037AC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000037ACC: BE882000
	s_cbranch_execz 61240                                      // 000000037AD0: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ab4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000037AD4: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000037AE0: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000037AE4: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000037AEC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000037AF0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037AF4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000037AF8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000037B00: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000037B0C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000037B10: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000037B14: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000037B18: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000037B20: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037B28: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000037B2C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000037B30: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000037B34: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B38: BF870095
	.long 0xd71c0042                                           // 000000037B3C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000037B40: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000037B44: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000037B48: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B50: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000037B54: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000037B5C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B60: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000037B64: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000037B6C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B70: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000037B74: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000037B7C: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000037B80: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B88: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000037B8C: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000037B90: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037B98: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000037B9C: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000037BA0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037BA8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000037BAC: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000037BB4: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000037BBC: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037BC8: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000037BCC: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000037BD4: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000037BE0: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037BE8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000037BEC: BE882001
	s_cbranch_execz 61171                                      // 000000037BF0: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ac0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000037BF4: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000037C00: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000037C04: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000037C0C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000037C10: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037C14: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000037C18: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000037C20: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000037C28: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000037C34: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000037C38: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000037C3C: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000037C44: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037C48: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000037C4C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000037C50: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000037C54: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037C58: BF870095
	.long 0xd71c0041                                           // 000000037C5C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000037C60: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000037C64: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000037C68: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037C70: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000037C74: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000037C7C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037C80: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000037C84: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000037C8C: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037C90: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000037C94: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000037C9C: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000037CA0: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037CA8: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000037CAC: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000037CB0: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037CB8: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000037CBC: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000037CC0: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037CC8: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000037CCC: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000037CD4: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000037CDC: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037CE8: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000037CEC: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000037CF4: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000037D00: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037D08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000037D0C: BE882002
	s_cbranch_execz 61102                                      // 000000037D10: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3acc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000037D14: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000037D20: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000037D28: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000037D2C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037D30: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000037D34: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000037D3C: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000037D48: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000037D4C: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000037D50: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000037D54: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000037D5C: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037D64: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000037D68: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000037D6C: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000037D70: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037D74: BF870095
	.long 0xd71c003a                                           // 000000037D78: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000037D7C: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000037D80: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000037D84: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037D8C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000037D90: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000037D9C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037DA0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000037DA4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000037DAC: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037DB0: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000037DB4: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000037DBC: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000037DC0: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037DC8: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000037DCC: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000037DD0: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037DD8: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000037DDC: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000037DE0: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037DE8: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000037DEC: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000037DF4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000037DFC: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037E08: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000037E0C: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000037E14: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000037E20: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037E28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000037E2C: BE882003
	s_cbranch_execz 61033                                      // 000000037E30: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ad8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000037E34: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000037E40: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000037E48: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000037E4C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037E50: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000037E54: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000037E5C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000037E68: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037E6C: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000037E70: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000037E7C: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000037E80: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000037E84: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000037E8C: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000037E90: 7E744B3A
	.long 0xd71c003a                                           // 000000037E94: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000037E98: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037E9C: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000037EA0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000037EA4: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000037EAC: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037EB8: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000037EBC: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000037EC0: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000037EC8: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000037ECC: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000037ED0: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000037ED8: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000037EDC: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000037EE0: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000037EE8: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037EEC: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000037EF0: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000037EF8: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037EFC: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000037F00: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000037F08: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037F10: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000037F14: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000037F1C: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000037F28: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000037F30: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000037F34: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000037F40: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000037F48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000037F4C: BE882004
	s_cbranch_execz 60964                                      // 000000037F50: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ae4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 000000037F54: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000037F60: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000037F68: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000037F6C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037F70: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000037F74: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000037F7C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000037F88: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000037F8C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000037F90: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000037F94: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000037F9C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000037FA4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000037FA8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000037FAC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000037FB0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037FB4: BF870095
	.long 0xd71c003a                                           // 000000037FB8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000037FBC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000037FC0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000037FC4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037FCC: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000037FD0: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000037FDC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037FE0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000037FE4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000037FEC: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000037FF0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000037FF4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000037FFC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000038000: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038008: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 00000003800C: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000038010: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038018: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 00000003801C: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000038020: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038028: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 00000003802C: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000038034: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 00000003803C: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038048: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000003804C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000038054: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000038060: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038068: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003806C: BE882005
	s_cbranch_execz 60895                                      // 000000038070: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3af0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 000000038074: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000038080: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000038088: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000003808C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038090: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000038094: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000003809C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000380A8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000380AC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000380B0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000380B4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000380BC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000380C4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000380C8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000380CC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000380D0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000380D4: BF870095
	.long 0xd71c003a                                           // 0000000380D8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000380DC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000380E0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000380E4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000380EC: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000380F0: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000380F8: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038100: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000038104: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000003810C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038110: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000038114: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000003811C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000038120: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038128: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000003812C: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 000000038130: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038138: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 00000003813C: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 000000038140: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038148: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000003814C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000038154: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000003815C: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038168: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000003816C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000038174: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000038180: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038188: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003818C: BE882006
	s_cbranch_execz 60826                                      // 000000038190: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3afc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 000000038194: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000381A0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000381A8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000381AC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000381B0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000381B4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000381BC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000381C8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000381CC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000381D0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000381D4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000381DC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000381E4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000381E8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000381EC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000381F0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000381F4: BF870095
	.long 0xd71c003a                                           // 0000000381F8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000381FC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000038200: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000038204: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003820C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 000000038210: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000003821C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038220: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000038224: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000003822C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038230: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000038234: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000003823C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000038240: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038248: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000003824C: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000038250: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038258: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000003825C: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000038260: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038268: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000003826C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000038274: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 00000003827C: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038288: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000003828C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000038294: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000382A0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000382A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000382AC: BE882007
	s_cbranch_execz 60757                                      // 0000000382B0: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b08>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000382B4: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000382C0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000382C8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000382CC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000382D0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000382D4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000382DC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000382E8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000382EC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000382F0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000382F4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000382FC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038304: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000038308: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000003830C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000038310: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038314: BF870095
	.long 0xd71c003a                                           // 000000038318: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000003831C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000038320: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000038324: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003832C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 000000038330: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000003833C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038340: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000038344: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000003834C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038350: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000038354: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000003835C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000038360: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038368: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000003836C: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000038370: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038378: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000003837C: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000038380: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038388: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000003838C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000038394: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 00000003839C: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000383A8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000383AC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000383B4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000383C0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000383C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000383CC: BE882000
	s_cbranch_execz 60688                                      // 0000000383D0: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b14>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000383D4: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000383E0: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000383E4: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000383EC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000383F0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000383F4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000383F8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000038400: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000003840C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000038410: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000038414: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000038418: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000038420: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038428: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000003842C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000038430: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000038434: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038438: BF870095
	.long 0xd71c003a                                           // 00000003843C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000038440: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000038444: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000038448: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038450: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000038454: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000003845C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038460: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 000000038464: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 00000003846C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038470: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 000000038474: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000003847C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 000000038480: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038488: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000003848C: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000038490: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038498: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000003849C: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000384A0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000384A8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000384AC: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000384B4: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000384BC: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000384C8: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000384CC: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000384D4: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000384E0: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000384E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000384EC: BE882001
	s_cbranch_execz 60619                                      // 0000000384F0: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b20>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000384F4: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000038500: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000038504: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 00000003850C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000038510: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038514: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000038518: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038520: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000038528: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 000000038534: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000038538: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 00000003853C: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 000000038544: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038548: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000003854C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000038550: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 000000038554: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038558: BF870095
	.long 0xd71c0039                                           // 00000003855C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 000000038560: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 000000038564: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000038568: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038570: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 000000038574: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000003857C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038580: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 000000038584: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 00000003858C: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038590: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000038594: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000003859C: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000385A0: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000385A8: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000385AC: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000385B0: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000385B8: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000385BC: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000385C0: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000385C8: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000385CC: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000385D4: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000385DC: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000385E8: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000385EC: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000385F4: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000038600: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038608: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003860C: BE882002
	s_cbranch_execz 60550                                      // 000000038610: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b2c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000038614: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038620: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038628: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000003862C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038630: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038634: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 00000003863C: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000038648: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003864C: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000038650: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038654: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 00000003865C: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038664: BF870121
	v_add_f32_e32 v50, v50, v57                                // 000000038668: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 00000003866C: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 000000038670: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038674: BF870095
	.long 0xd71c0032                                           // 000000038678: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 00000003867C: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000038680: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000038684: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003868C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000038690: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000003869C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000386A0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000386A4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000386AC: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000386B0: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000386B4: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000386BC: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000386C0: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000386C8: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000386CC: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000386D0: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000386D8: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000386DC: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000386E0: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000386E8: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000386EC: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000386F4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000386FC: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038708: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 00000003870C: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000038714: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038720: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038728: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003872C: BE882003
	s_cbranch_execz 60481                                      // 000000038730: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b38>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 000000038734: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038740: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038748: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000003874C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038750: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038754: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000003875C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 000000038768: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003876C: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 000000038770: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 00000003877C: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 000000038780: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038784: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003878C: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000038790: 7E644B32
	.long 0xd71c0032                                           // 000000038794: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000038798: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003879C: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000387A0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000387A4: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000387AC: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000387B8: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000387BC: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000387C0: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000387C8: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000387CC: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000387D0: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000387D8: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000387DC: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000387E0: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000387E8: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000387EC: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000387F0: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000387F8: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000387FC: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000038800: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000038808: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038810: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000038814: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 00000003881C: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000038828: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000038830: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000038834: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038840: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038848: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003884C: BE882004
	s_cbranch_execz 60412                                      // 000000038850: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b44>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 000000038854: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038860: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038868: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000003886C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038870: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038874: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000003887C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000038888: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003888C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000038890: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038894: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000003889C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000388A4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000388A8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000388AC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000388B0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000388B4: BF870095
	.long 0xd71c0032                                           // 0000000388B8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000388BC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000388C0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000388C4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000388CC: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000388D0: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000388DC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000388E0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000388E4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000388EC: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000388F0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000388F4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000388FC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000038900: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038908: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 00000003890C: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000038910: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038918: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 00000003891C: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000038920: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038928: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 00000003892C: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000038934: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 00000003893C: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038948: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000003894C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000038954: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038960: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038968: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003896C: BE882005
	s_cbranch_execz 60343                                      // 000000038970: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b50>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000038974: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038980: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038988: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000003898C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038990: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038994: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000003899C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000389A8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000389AC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000389B0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000389B4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000389BC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000389C4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000389C8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000389CC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000389D0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000389D4: BF870095
	.long 0xd71c0032                                           // 0000000389D8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000389DC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000389E0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000389E4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000389EC: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000389F0: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000389F8: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A00: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000038A04: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000038A0C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A10: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000038A14: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000038A1C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000038A20: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A28: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000038A2C: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000038A30: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A38: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000038A3C: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000038A40: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A48: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000038A4C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000038A54: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000038A5C: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038A68: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000038A6C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000038A74: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038A80: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038A88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000038A8C: BE882006
	s_cbranch_execz 60274                                      // 000000038A90: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b5c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000038A94: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038AA0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038AA8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000038AAC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038AB0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038AB4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000038ABC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000038AC8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000038ACC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000038AD0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038AD4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000038ADC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038AE4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000038AE8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000038AEC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000038AF0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038AF4: BF870095
	.long 0xd71c0032                                           // 000000038AF8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000038AFC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000038B00: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000038B04: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B0C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000038B10: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000038B1C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B20: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000038B24: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000038B2C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B30: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000038B34: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000038B3C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000038B40: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B48: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000038B4C: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000038B50: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B58: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000038B5C: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000038B60: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B68: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000038B6C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000038B74: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000038B7C: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038B88: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000038B8C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000038B94: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038BA0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038BA8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000038BAC: BE882007
	s_cbranch_execz 60205                                      // 000000038BB0: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b68>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000038BB4: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000038BC0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038BC8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000038BCC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038BD0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038BD4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000038BDC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000038BE8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000038BEC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000038BF0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038BF4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000038BFC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038C04: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000038C08: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000038C0C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000038C10: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C14: BF870095
	.long 0xd71c0032                                           // 000000038C18: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000038C1C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000038C20: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000038C24: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C2C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000038C30: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000038C3C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C40: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000038C44: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000038C4C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C50: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000038C54: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000038C5C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000038C60: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C68: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000038C6C: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000038C70: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C78: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000038C7C: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000038C80: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038C88: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000038C8C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000038C94: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000038C9C: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038CA8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000038CAC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000038CB4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000038CC0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038CC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000038CCC: BE882000
	s_cbranch_execz 60136                                      // 000000038CD0: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b74>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000038CD4: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000038CE0: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000038CE4: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000038CEC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000038CF0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038CF4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000038CF8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000038D00: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000038D0C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000038D10: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000038D14: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000038D18: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000038D20: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038D28: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000038D2C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000038D30: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000038D34: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D38: BF870095
	.long 0xd71c0032                                           // 000000038D3C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000038D40: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000038D44: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000038D48: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D50: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000038D54: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000038D5C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D60: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000038D64: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000038D6C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D70: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000038D74: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000038D7C: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000038D80: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D88: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000038D8C: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000038D90: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038D98: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000038D9C: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000038DA0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038DA8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000038DAC: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000038DB4: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000038DBC: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038DC8: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000038DCC: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000038DD4: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000038DE0: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038DE8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000038DEC: BE882001
	s_cbranch_execz 60067                                      // 000000038DF0: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b80>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000038DF4: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000038E00: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000038E04: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000038E0C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000038E10: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038E14: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000038E18: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000038E20: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000038E28: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000038E34: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000038E38: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000038E3C: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000038E44: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038E48: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000038E4C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000038E50: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000038E54: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038E58: BF870095
	.long 0xd71c0031                                           // 000000038E5C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000038E60: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000038E64: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000038E68: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038E70: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 000000038E74: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000038E7C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038E80: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000038E84: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000038E8C: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038E90: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000038E94: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000038E9C: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000038EA0: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038EA8: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000038EAC: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000038EB0: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038EB8: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000038EBC: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000038EC0: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038EC8: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000038ECC: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000038ED4: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000038EDC: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038EE8: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000038EEC: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 000000038EF4: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000038F00: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000038F08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000038F0C: BE882002
	s_cbranch_execz 59998                                      // 000000038F10: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b8c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 000000038F14: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000038F20: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000038F28: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000038F2C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038F30: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000038F34: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 000000038F3C: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 000000038F48: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000038F4C: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000038F50: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000038F54: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 000000038F5C: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000038F64: BF870121
	v_add_f32_e32 v42, v42, v49                                // 000000038F68: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 000000038F6C: 7E621132
	v_exp_f32_e32 v42, v42                                     // 000000038F70: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038F74: BF870095
	.long 0xd71c002a                                           // 000000038F78: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 000000038F7C: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000038F80: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000038F84: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038F8C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000038F90: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000038F9C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038FA0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000038FA4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000038FAC: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038FB0: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 000000038FB4: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000038FBC: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000038FC0: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038FC8: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000038FCC: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000038FD0: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038FD8: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000038FDC: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000038FE0: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000038FE8: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000038FEC: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000038FF4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000038FFC: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039008: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 00000003900C: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 000000039014: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000039020: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039028: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003902C: BE882003
	s_cbranch_execz 59929                                      // 000000039030: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b98>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 000000039034: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000039040: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000039048: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000003904C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039050: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000039054: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000003905C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 000000039068: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003906C: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 000000039070: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 00000003907C: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 000000039080: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000039084: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003908C: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000039090: 7E544B2A
	.long 0xd71c002a                                           // 000000039094: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000039098: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003909C: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000390A0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000390A4: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000390AC: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000390B8: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000390BC: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000390C0: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000390C8: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000390CC: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000390D0: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000390D8: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000390DC: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000390E0: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000390E8: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000390EC: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000390F0: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000390F8: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000390FC: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000039100: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 000000039108: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039110: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000039114: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 00000003911C: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 000000039128: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000039130: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000039134: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000039140: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039148: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003914C: BE882004
	s_cbranch_execz 59860                                      // 000000039150: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ba4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 000000039154: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000039160: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000039168: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000003916C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039170: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000039174: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000003917C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000039188: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003918C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000039190: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000039194: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000003919C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000391A4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000391A8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000391AC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000391B0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000391B4: BF870095
	.long 0xd71c002a                                           // 0000000391B8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000391BC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000391C0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000391C4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000391CC: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000391D0: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000391DC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000391E0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000391E4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000391EC: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000391F0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000391F4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000391FC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000039200: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039208: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 00000003920C: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 000000039210: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039218: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 00000003921C: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 000000039220: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039228: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 00000003922C: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000039234: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 00000003923C: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039248: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000003924C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000039254: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000039260: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039268: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003926C: BE882005
	s_cbranch_execz 59791                                      // 000000039270: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bb0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 000000039274: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000039280: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000039288: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000003928C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039290: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000039294: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000003929C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000392A8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000392AC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000392B0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000392B4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000392BC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000392C4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000392C8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000392CC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000392D0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000392D4: BF870095
	.long 0xd71c002a                                           // 0000000392D8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000392DC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000392E0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000392E4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000392EC: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000392F0: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000392F8: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039300: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000039304: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000003930C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039310: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000039314: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000003931C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000039320: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039328: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000003932C: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 000000039330: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039338: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 00000003933C: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 000000039340: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039348: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000003934C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000039354: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000003935C: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039368: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000003936C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000039374: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000039380: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039388: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003938C: BE882006
	s_cbranch_execz 59722                                      // 000000039390: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bbc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 000000039394: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000393A0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000393A8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000393AC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000393B0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000393B4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000393BC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000393C8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000393CC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000393D0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000393D4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000393DC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000393E4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000393E8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000393EC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000393F0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000393F4: BF870095
	.long 0xd71c002a                                           // 0000000393F8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000393FC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000039400: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000039404: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003940C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000039410: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000003941C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039420: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000039424: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000003942C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039430: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000039434: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000003943C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000039440: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039448: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000003944C: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000039450: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039458: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000003945C: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000039460: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039468: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000003946C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000039474: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 00000003947C: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039488: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000003948C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000039494: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000394A0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000394A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000394AC: BE882007
	s_cbranch_execz 59653                                      // 0000000394B0: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bc8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000394B4: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000394C0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000394C8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000394CC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000394D0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000394D4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000394DC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000394E8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000394EC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000394F0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000394F4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000394FC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039504: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000039508: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000003950C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000039510: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039514: BF870095
	.long 0xd71c002a                                           // 000000039518: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000003951C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000039520: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000039524: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003952C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000039530: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000003953C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039540: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000039544: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000003954C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039550: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000039554: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000003955C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000039560: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039568: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000003956C: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000039570: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039578: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000003957C: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000039580: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039588: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000003958C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000039594: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 00000003959C: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000395A8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000395AC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000395B4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000395C0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000395C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000395CC: BE882000
	s_cbranch_execz 59584                                      // 0000000395D0: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bd4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000395D4: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000395E0: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000395E4: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000395EC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000395F0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000395F4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000395F8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000039600: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000003960C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039610: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000039614: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000039618: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000039620: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039628: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000003962C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000039630: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000039634: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039638: BF870095
	.long 0xd71c002a                                           // 00000003963C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000039640: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000039644: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000039648: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039650: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000039654: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000003965C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039660: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 000000039664: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 00000003966C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039670: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000039674: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000003967C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 000000039680: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039688: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000003968C: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000039690: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039698: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000003969C: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000396A0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000396A8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000396AC: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000396B4: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000396BC: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000396C8: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000396CC: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000396D4: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000396E0: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000396E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000396EC: BE882001
	s_cbranch_execz 59515                                      // 0000000396F0: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3be0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000396F4: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000039700: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000039704: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 00000003970C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039710: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039714: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000039718: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039720: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000039728: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000039734: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000039738: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 00000003973C: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 000000039744: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039748: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000003974C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000039750: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000039754: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039758: BF870095
	.long 0xd71c0029                                           // 00000003975C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000039760: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000039764: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039768: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039770: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 000000039774: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000003977C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039780: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 000000039784: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 00000003978C: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039790: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000039794: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000003979C: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000397A0: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000397A8: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000397AC: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000397B0: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000397B8: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000397BC: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000397C0: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000397C8: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000397CC: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000397D4: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000397DC: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000397E8: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000397EC: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000397F4: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000039800: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039808: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003980C: BE882002
	s_cbranch_execz 59446                                      // 000000039810: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bec>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000039814: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039820: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039828: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000003982C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039830: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039834: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 00000003983C: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000039848: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003984C: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000039850: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039854: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 00000003985C: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039864: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000039868: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 00000003986C: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000039870: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039874: BF870095
	.long 0xd71c0022                                           // 000000039878: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 00000003987C: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039880: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039884: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003988C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000039890: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000003989C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000398A0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000398A4: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000398AC: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000398B0: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000398B4: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000398BC: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000398C0: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000398C8: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000398CC: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000398D0: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000398D8: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000398DC: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000398E0: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000398E8: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000398EC: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000398F4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000398FC: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039908: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 00000003990C: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000039914: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039920: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039928: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003992C: BE882003
	s_cbranch_execz 59377                                      // 000000039930: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bf8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000039934: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039940: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039948: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000003994C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039950: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039954: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000003995C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000039968: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003996C: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000039970: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 00000003997C: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000039980: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039984: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003998C: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000039990: 7E444B22
	.long 0xd71c0022                                           // 000000039994: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039998: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003999C: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000399A0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000399A4: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000399AC: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000399B8: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000399BC: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000399C0: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000399C8: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000399CC: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000399D0: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000399D8: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000399DC: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000399E0: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000399E8: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000399EC: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000399F0: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000399F8: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000399FC: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000039A00: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000039A08: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039A10: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000039A14: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000039A1C: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000039A28: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000039A30: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000039A34: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039A40: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039A48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000039A4C: BE882004
	s_cbranch_execz 59308                                      // 000000039A50: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c04>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000039A54: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039A60: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039A68: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039A6C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039A70: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039A74: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000039A7C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000039A88: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039A8C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000039A90: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039A94: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000039A9C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039AA4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000039AA8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000039AAC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000039AB0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039AB4: BF870095
	.long 0xd71c0022                                           // 000000039AB8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039ABC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039AC0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039AC4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039ACC: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000039AD0: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000039ADC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039AE0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000039AE4: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000039AEC: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039AF0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000039AF4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000039AFC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000039B00: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039B08: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000039B0C: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000039B10: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039B18: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000039B1C: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000039B20: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039B28: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000039B2C: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000039B34: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000039B3C: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039B48: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000039B4C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000039B54: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039B60: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039B68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000039B6C: BE882005
	s_cbranch_execz 59239                                      // 000000039B70: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c10>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000039B74: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039B80: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039B88: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039B8C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039B90: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039B94: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000039B9C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000039BA8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039BAC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000039BB0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039BB4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000039BBC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039BC4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000039BC8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000039BCC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000039BD0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039BD4: BF870095
	.long 0xd71c0022                                           // 000000039BD8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039BDC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039BE0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039BE4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039BEC: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000039BF0: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000039BF8: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C00: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000039C04: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000039C0C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C10: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000039C14: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000039C1C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000039C20: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C28: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000039C2C: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000039C30: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C38: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000039C3C: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000039C40: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C48: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000039C4C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000039C54: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000039C5C: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039C68: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000039C6C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000039C74: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039C80: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039C88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000039C8C: BE882006
	s_cbranch_execz 59170                                      // 000000039C90: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c1c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000039C94: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039CA0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039CA8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039CAC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039CB0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039CB4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000039CBC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000039CC8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039CCC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000039CD0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039CD4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000039CDC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039CE4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000039CE8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000039CEC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000039CF0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039CF4: BF870095
	.long 0xd71c0022                                           // 000000039CF8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039CFC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039D00: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039D04: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D0C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000039D10: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000039D1C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D20: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000039D24: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000039D2C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D30: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000039D34: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000039D3C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000039D40: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D48: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000039D4C: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000039D50: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D58: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000039D5C: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000039D60: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D68: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000039D6C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000039D74: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000039D7C: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039D88: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000039D8C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000039D94: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039DA0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039DA8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000039DAC: BE882007
	s_cbranch_execz 59101                                      // 000000039DB0: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c28>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000039DB4: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000039DC0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039DC8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039DCC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039DD0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039DD4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000039DDC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000039DE8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039DEC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000039DF0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039DF4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000039DFC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039E04: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000039E08: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000039E0C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000039E10: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E14: BF870095
	.long 0xd71c0022                                           // 000000039E18: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039E1C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039E20: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039E24: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E2C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000039E30: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000039E3C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E40: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000039E44: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000039E4C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E50: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000039E54: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000039E5C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000039E60: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E68: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000039E6C: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000039E70: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E78: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000039E7C: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000039E80: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039E88: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000039E8C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000039E94: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000039E9C: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039EA8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000039EAC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000039EB4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000039EC0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039EC8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000039ECC: BE882000
	s_cbranch_execz 59032                                      // 000000039ED0: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c34>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000039ED4: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000039EE0: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000039EE4: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000039EEC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000039EF0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039EF4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000039EF8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000039F00: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000039F0C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000039F10: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000039F14: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000039F18: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000039F20: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000039F28: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000039F2C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000039F30: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000039F34: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F38: BF870095
	.long 0xd71c0022                                           // 000000039F3C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000039F40: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000039F44: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000039F48: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F50: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000039F54: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000039F5C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F60: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 000000039F64: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 000000039F6C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F70: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000039F74: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 000000039F7C: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 000000039F80: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F88: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000039F8C: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000039F90: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039F98: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000039F9C: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000039FA0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039FA8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000039FAC: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 000000039FB4: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000039FBC: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000039FC8: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000039FCC: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000039FD4: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000039FE0: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000039FE8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000039FEC: BE882001
	s_cbranch_execz 58963                                      // 000000039FF0: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c40>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 000000039FF4: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 00000003A000: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000003A004: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 00000003A00C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A010: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A014: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 00000003A018: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A020: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 00000003A028: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000003A034: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003A038: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 00000003A03C: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000003A044: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A048: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000003A04C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000003A050: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000003A054: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A058: BF870095
	.long 0xd71c0021                                           // 00000003A05C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000003A060: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000003A064: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A068: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A070: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000003A074: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A07C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A080: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000003A084: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 00000003A08C: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A090: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000003A094: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000003A09C: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 00000003A0A0: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A0A8: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000003A0AC: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000003A0B0: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A0B8: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000003A0BC: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000003A0C0: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A0C8: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000003A0CC: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000003A0D4: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000003A0DC: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A0E8: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000003A0EC: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000003A0F4: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 00000003A100: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A108: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003A10C: BE882002
	s_cbranch_execz 58894                                      // 00000003A110: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c4c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 00000003A114: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A120: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A128: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A12C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A130: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A134: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 00000003A13C: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 00000003A148: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A14C: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 00000003A150: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A154: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000003A15C: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A164: BF870121
	v_add_f32_e32 v26, v26, v33                                // 00000003A168: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 00000003A16C: 7E421122
	v_exp_f32_e32 v26, v26                                     // 00000003A170: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A174: BF870095
	.long 0xd71c001a                                           // 00000003A178: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 00000003A17C: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A180: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A184: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A18C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 00000003A190: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A19C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A1A0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A1A4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 00000003A1AC: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A1B0: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000003A1B4: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 00000003A1BC: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 00000003A1C0: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A1C8: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000003A1CC: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 00000003A1D0: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A1D8: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000003A1DC: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 00000003A1E0: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A1E8: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000003A1EC: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A1F4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 00000003A1FC: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A208: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 00000003A20C: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000003A214: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A220: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A228: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003A22C: BE882003
	s_cbranch_execz 58825                                      // 00000003A230: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c58>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000003A234: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A240: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A248: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A24C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A250: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A254: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A25C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 00000003A268: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A26C: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 00000003A270: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 00000003A27C: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 00000003A280: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A284: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003A28C: BF870293
	v_exp_f32_e32 v26, v26                                     // 00000003A290: 7E344B1A
	.long 0xd71c001a                                           // 00000003A294: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A298: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A29C: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A2A0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A2A4: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 00000003A2AC: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A2B8: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A2BC: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A2C0: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003A2C8: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000003A2CC: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 00000003A2D0: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003A2D8: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000003A2DC: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 00000003A2E0: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 00000003A2E8: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A2EC: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 00000003A2F0: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 00000003A2F8: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A2FC: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 00000003A300: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 00000003A308: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A310: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A314: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 00000003A31C: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000003A328: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003A330: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000003A334: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A340: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A348: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003A34C: BE882004
	s_cbranch_execz 58756                                      // 00000003A350: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c64>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000003A354: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A360: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A368: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A36C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A370: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A374: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A37C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003A388: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A38C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000003A390: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A394: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000003A39C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A3A4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003A3A8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003A3AC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003A3B0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A3B4: BF870095
	.long 0xd71c001a                                           // 00000003A3B8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A3BC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A3C0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A3C4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A3CC: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 00000003A3D0: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A3DC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A3E0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A3E4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000003A3EC: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A3F0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000003A3F4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000003A3FC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000003A400: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A408: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 00000003A40C: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 00000003A410: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A418: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 00000003A41C: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 00000003A420: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A428: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 00000003A42C: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A434: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 00000003A43C: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A448: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000003A44C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000003A454: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A460: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A468: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003A46C: BE882005
	s_cbranch_execz 58687                                      // 00000003A470: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c70>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 00000003A474: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A480: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A488: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A48C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A490: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A494: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A49C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003A4A8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A4AC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000003A4B0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A4B4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000003A4BC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A4C4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003A4C8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003A4CC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003A4D0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A4D4: BF870095
	.long 0xd71c001a                                           // 00000003A4D8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A4DC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A4E0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A4E4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A4EC: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000003A4F0: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 00000003A4F8: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A500: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A504: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000003A50C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A510: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000003A514: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000003A51C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000003A520: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A528: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000003A52C: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 00000003A530: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A538: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 00000003A53C: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 00000003A540: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A548: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000003A54C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A554: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 00000003A55C: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A568: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000003A56C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000003A574: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A580: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A588: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003A58C: BE882006
	s_cbranch_execz 58618                                      // 00000003A590: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c7c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 00000003A594: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A5A0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A5A8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A5AC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A5B0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A5B4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A5BC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003A5C8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A5CC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000003A5D0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A5D4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000003A5DC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A5E4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003A5E8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003A5EC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003A5F0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A5F4: BF870095
	.long 0xd71c001a                                           // 00000003A5F8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A5FC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A600: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A604: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A60C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 00000003A610: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A61C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A620: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A624: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000003A62C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A630: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000003A634: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000003A63C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000003A640: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A648: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000003A64C: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000003A650: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A658: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000003A65C: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000003A660: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A668: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000003A66C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A674: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 00000003A67C: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A688: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000003A68C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000003A694: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A6A0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A6A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003A6AC: BE882007
	s_cbranch_execz 58549                                      // 00000003A6B0: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c88>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 00000003A6B4: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000003A6C0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A6C8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A6CC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A6D0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A6D4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A6DC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003A6E8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A6EC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000003A6F0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A6F4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000003A6FC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A704: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003A708: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003A70C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003A710: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A714: BF870095
	.long 0xd71c001a                                           // 00000003A718: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A71C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A720: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A724: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A72C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 00000003A730: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A73C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A740: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000003A744: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000003A74C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A750: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000003A754: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000003A75C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000003A760: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A768: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000003A76C: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000003A770: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A778: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000003A77C: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000003A780: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A788: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000003A78C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000003A794: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 00000003A79C: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A7A8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000003A7AC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000003A7B4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000003A7C0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A7C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003A7CC: BE882000
	s_cbranch_execz 58480                                      // 00000003A7D0: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c94>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000003A7D4: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000003A7E0: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000003A7E4: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 00000003A7EC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000003A7F0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A7F4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000003A7F8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000003A800: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003A80C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003A810: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000003A814: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000003A818: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000003A820: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A828: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003A82C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003A830: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003A834: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A838: BF870095
	.long 0xd71c001a                                           // 00000003A83C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003A840: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000003A844: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000003A848: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A850: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000003A854: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000003A85C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A860: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 00000003A864: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 00000003A86C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A870: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000003A874: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000003A87C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 00000003A880: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A888: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000003A88C: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000003A890: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A898: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000003A89C: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000003A8A0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A8A8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000003A8AC: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 00000003A8B4: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 00000003A8BC: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A8C8: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 00000003A8CC: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000003A8D4: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 00000003A8E0: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003A8E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003A8EC: BE882001
	s_cbranch_execz 58411                                      // 00000003A8F0: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ca0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 00000003A8F4: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 00000003A900: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 00000003A904: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 00000003A90C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003A910: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A914: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 00000003A918: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003A920: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 00000003A928: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000003A934: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003A938: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 00000003A93C: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000003A944: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003A948: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000003A94C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000003A950: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000003A954: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A958: BF870095
	.long 0xd71c0019                                           // 00000003A95C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000003A960: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000003A964: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003A968: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A970: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 00000003A974: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003A97C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A980: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 00000003A984: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 00000003A98C: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A990: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000003A994: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000003A99C: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 00000003A9A0: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A9A8: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000003A9AC: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000003A9B0: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A9B8: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000003A9BC: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000003A9C0: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A9C8: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000003A9CC: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 00000003A9D4: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 00000003A9DC: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003A9E8: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 00000003A9EC: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000003A9F4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 00000003AA00: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AA08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003AA0C: BE882002
	s_cbranch_execz 58342                                      // 00000003AA10: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cac>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 00000003AA14: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AA20: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AA28: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AA2C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AA30: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AA34: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 00000003AA3C: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 00000003AA48: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003AA4C: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 00000003AA50: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003AA54: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000003AA5C: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003AA64: BF870121
	v_add_f32_e32 v18, v18, v25                                // 00000003AA68: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 00000003AA6C: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 00000003AA70: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AA74: BF870095
	.long 0xd71c0012                                           // 00000003AA78: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 00000003AA7C: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003AA80: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003AA84: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AA8C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 00000003AA90: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003AA9C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AAA0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003AAA4: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 00000003AAAC: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AAB0: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 00000003AAB4: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 00000003AABC: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 00000003AAC0: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AAC8: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000003AACC: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 00000003AAD0: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AAD8: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000003AADC: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 00000003AAE0: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AAE8: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000003AAEC: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003AAF4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 00000003AAFC: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AB08: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 00000003AB0C: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000003AB14: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003AB20: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AB28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003AB2C: BE882003
	s_cbranch_execz 58273                                      // 00000003AB30: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cb8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000003AB34: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AB40: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AB48: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AB4C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AB50: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AB54: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003AB5C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 00000003AB68: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AB6C: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 00000003AB70: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 00000003AB7C: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 00000003AB80: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003AB84: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003AB8C: BF870293
	v_exp_f32_e32 v18, v18                                     // 00000003AB90: 7E244B12
	.long 0xd71c0012                                           // 00000003AB94: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003AB98: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003AB9C: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003ABA0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003ABA4: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 00000003ABAC: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ABB8: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 00000003ABBC: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003ABC0: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003ABC8: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000003ABCC: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000003ABD0: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003ABD8: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000003ABDC: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 00000003ABE0: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 00000003ABE8: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ABEC: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 00000003ABF0: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 00000003ABF8: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ABFC: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 00000003AC00: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 00000003AC08: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003AC10: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003AC14: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 00000003AC1C: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000003AC28: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003AC30: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000003AC34: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003AC40: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AC48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003AC4C: BE882004
	s_cbranch_execz 58204                                      // 00000003AC50: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cc4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000003AC54: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AC60: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AC68: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AC6C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AC70: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AC74: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003AC7C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000003AC88: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003AC8C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000003AC90: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003AC94: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000003AC9C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003ACA4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000003ACA8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000003ACAC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000003ACB0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ACB4: BF870095
	.long 0xd71c0012                                           // 00000003ACB8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003ACBC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003ACC0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003ACC4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ACCC: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 00000003ACD0: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003ACDC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ACE0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003ACE4: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000003ACEC: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ACF0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000003ACF4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000003ACFC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000003AD00: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AD08: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 00000003AD0C: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 00000003AD10: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AD18: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 00000003AD1C: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 00000003AD20: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AD28: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 00000003AD2C: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003AD34: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 00000003AD3C: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AD48: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000003AD4C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000003AD54: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003AD60: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AD68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003AD6C: BE882005
	s_cbranch_execz 58135                                      // 00000003AD70: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cd0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 00000003AD74: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AD80: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AD88: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AD8C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AD90: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AD94: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003AD9C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000003ADA8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003ADAC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000003ADB0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003ADB4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000003ADBC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003ADC4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000003ADC8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000003ADCC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000003ADD0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ADD4: BF870095
	.long 0xd71c0012                                           // 00000003ADD8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003ADDC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003ADE0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003ADE4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ADEC: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000003ADF0: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 00000003ADF8: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE00: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003AE04: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000003AE0C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE10: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000003AE14: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000003AE1C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000003AE20: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE28: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000003AE2C: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 00000003AE30: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE38: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 00000003AE3C: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 00000003AE40: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE48: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000003AE4C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003AE54: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 00000003AE5C: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AE68: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000003AE6C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000003AE74: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003AE80: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AE88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003AE8C: BE882006
	s_cbranch_execz 58066                                      // 00000003AE90: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cdc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000003AE94: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AEA0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AEA8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AEAC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AEB0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AEB4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003AEBC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000003AEC8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003AECC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000003AED0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003AED4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000003AEDC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003AEE4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000003AEE8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000003AEEC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000003AEF0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AEF4: BF870095
	.long 0xd71c0012                                           // 00000003AEF8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003AEFC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003AF00: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003AF04: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF0C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 00000003AF10: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003AF1C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF20: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003AF24: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000003AF2C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF30: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000003AF34: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000003AF3C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000003AF40: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF48: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000003AF4C: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000003AF50: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF58: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000003AF5C: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000003AF60: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF68: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000003AF6C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003AF74: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 00000003AF7C: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AF88: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000003AF8C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000003AF94: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003AFA0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003AFA8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003AFAC: BE882007
	s_cbranch_execz 57997                                      // 00000003AFB0: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ce8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000003AFB4: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000003AFC0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003AFC8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003AFCC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003AFD0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003AFD4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003AFDC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000003AFE8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003AFEC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000003AFF0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003AFF4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000003AFFC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B004: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000003B008: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000003B00C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000003B010: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B014: BF870095
	.long 0xd71c0012                                           // 00000003B018: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003B01C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003B020: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003B024: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B02C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 00000003B030: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003B03C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B040: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000003B044: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000003B04C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B050: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000003B054: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000003B05C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000003B060: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B068: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000003B06C: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 00000003B070: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B078: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000003B07C: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 00000003B080: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B088: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000003B08C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000003B094: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 00000003B09C: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B0A8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000003B0AC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000003B0B4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000003B0C0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B0C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003B0CC: BE882000
	s_cbranch_execz 57928                                      // 00000003B0D0: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cf4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000003B0D4: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000003B0E0: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000003B0E4: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000003B0EC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000003B0F0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B0F4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000003B0F8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000003B100: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000003B10C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B110: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000003B114: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000003B118: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000003B120: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B128: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000003B12C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000003B130: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000003B134: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B138: BF870095
	.long 0xd71c0012                                           // 00000003B13C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000003B140: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000003B144: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000003B148: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B150: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000003B154: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000003B15C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B160: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 00000003B164: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 00000003B16C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B170: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000003B174: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000003B17C: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 00000003B180: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B188: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000003B18C: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000003B190: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B198: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000003B19C: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000003B1A0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B1A8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000003B1AC: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000003B1B4: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 00000003B1BC: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B1C8: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 00000003B1CC: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000003B1D4: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 00000003B1E0: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B1E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003B1EC: BE882001
	s_cbranch_execz 57859                                      // 00000003B1F0: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d00>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000003B1F4: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 00000003B200: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 00000003B204: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 00000003B20C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B210: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B214: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 00000003B218: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B220: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 00000003B228: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000003B234: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003B238: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 00000003B23C: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 00000003B244: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B248: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000003B24C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000003B250: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000003B254: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B258: BF870095
	.long 0xd71c0011                                           // 00000003B25C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000003B260: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000003B264: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B268: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B270: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000003B274: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B27C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B280: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000003B284: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 00000003B28C: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B290: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000003B294: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000003B29C: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 00000003B2A0: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B2A8: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000003B2AC: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000003B2B0: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B2B8: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000003B2BC: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000003B2C0: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B2C8: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000003B2CC: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000003B2D4: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 00000003B2DC: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B2E8: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 00000003B2EC: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000003B2F4: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 00000003B300: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B308: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003B30C: BE882002
	s_cbranch_execz 57790                                      // 00000003B310: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d0c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 00000003B314: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B320: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B328: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B32C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B330: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B334: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 00000003B33C: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 00000003B348: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B34C: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 00000003B350: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B354: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 00000003B35C: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B364: BF870121
	v_add_f32_e32 v10, v10, v17                                // 00000003B368: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 00000003B36C: 7E221112
	v_exp_f32_e32 v10, v10                                     // 00000003B370: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B374: BF870095
	.long 0xd71c000a                                           // 00000003B378: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 00000003B37C: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B380: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B384: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B38C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 00000003B390: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B39C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B3A0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B3A4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 00000003B3AC: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B3B0: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 00000003B3B4: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 00000003B3BC: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 00000003B3C0: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B3C8: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000003B3CC: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 00000003B3D0: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B3D8: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000003B3DC: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 00000003B3E0: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B3E8: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 00000003B3EC: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B3F4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 00000003B3FC: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B408: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 00000003B40C: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000003B414: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B420: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B428: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003B42C: BE882003
	s_cbranch_execz 57721                                      // 00000003B430: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d18>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 00000003B434: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B440: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B448: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B44C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B450: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B454: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003B45C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 00000003B468: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B46C: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 00000003B470: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 00000003B47C: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 00000003B480: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B484: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003B48C: BF870293
	v_exp_f32_e32 v10, v10                                     // 00000003B490: 7E144B0A
	.long 0xd71c000a                                           // 00000003B494: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003B498: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B49C: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B4A0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B4A4: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 00000003B4AC: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B4B8: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B4BC: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B4C0: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003B4C8: BF870291
	v_rcp_f32_e32 v12, v11                                     // 00000003B4CC: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 00000003B4D0: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B4D8: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 00000003B4DC: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 00000003B4E0: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 00000003B4E8: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B4EC: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 00000003B4F0: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 00000003B4F8: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B4FC: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 00000003B500: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 00000003B508: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B510: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B514: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 00000003B51C: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000003B528: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003B530: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000003B534: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B540: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B548: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003B54C: BE882004
	s_cbranch_execz 57652                                      // 00000003B550: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d24>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 00000003B554: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B560: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B568: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B56C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B570: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B574: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003B57C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000003B588: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B58C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000003B590: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B594: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000003B59C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B5A4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000003B5A8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000003B5AC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000003B5B0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B5B4: BF870095
	.long 0xd71c000a                                           // 00000003B5B8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003B5BC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B5C0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B5C4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B5CC: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 00000003B5D0: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B5DC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B5E0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B5E4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000003B5EC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B5F0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000003B5F4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000003B5FC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000003B600: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B608: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 00000003B60C: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 00000003B610: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B618: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 00000003B61C: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 00000003B620: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B628: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 00000003B62C: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B634: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 00000003B63C: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B648: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000003B64C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000003B654: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B660: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B668: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003B66C: BE882005
	s_cbranch_execz 57583                                      // 00000003B670: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d30>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 00000003B674: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B680: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B688: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B68C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B690: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B694: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003B69C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000003B6A8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B6AC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000003B6B0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B6B4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000003B6BC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B6C4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000003B6C8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000003B6CC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000003B6D0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B6D4: BF870095
	.long 0xd71c000a                                           // 00000003B6D8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003B6DC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B6E0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B6E4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B6EC: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000003B6F0: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 00000003B6F8: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B700: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B704: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000003B70C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B710: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000003B714: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000003B71C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000003B720: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B728: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000003B72C: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 00000003B730: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B738: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 00000003B73C: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 00000003B740: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B748: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000003B74C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B754: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 00000003B75C: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B768: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000003B76C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000003B774: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B780: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B788: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003B78C: BE882006
	s_cbranch_execz 57514                                      // 00000003B790: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d3c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 00000003B794: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B7A0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B7A8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B7AC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B7B0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B7B4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003B7BC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000003B7C8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B7CC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000003B7D0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B7D4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000003B7DC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B7E4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000003B7E8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000003B7EC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000003B7F0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B7F4: BF870095
	.long 0xd71c000a                                           // 00000003B7F8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003B7FC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B800: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B804: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B80C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 00000003B810: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B81C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B820: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B824: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000003B82C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B830: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000003B834: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000003B83C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000003B840: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B848: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000003B84C: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000003B850: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B858: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000003B85C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000003B860: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B868: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000003B86C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B874: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 00000003B87C: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B888: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000003B88C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000003B894: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B8A0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B8A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003B8AC: BE882007
	s_cbranch_execz 57445                                      // 00000003B8B0: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d48>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 00000003B8B4: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000003B8C0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B8C8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B8CC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B8D0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B8D4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003B8DC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000003B8E8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003B8EC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000003B8F0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003B8F4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000003B8FC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003B904: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000003B908: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000003B90C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000003B910: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B914: BF870095
	.long 0xd71c000a                                           // 00000003B918: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003B91C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003B920: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003B924: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B92C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 00000003B930: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003B93C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B940: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000003B944: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000003B94C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B950: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000003B954: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000003B95C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000003B960: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B968: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000003B96C: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000003B970: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B978: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000003B97C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000003B980: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B988: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000003B98C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000003B994: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 00000003B99C: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B9A8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000003B9AC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000003B9B4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000003B9C0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003B9C8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003B9CC: BE882000
	s_cbranch_execz 57376                                      // 00000003B9D0: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d54>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 00000003B9D4: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000003B9E0: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 00000003B9E4: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000003B9EC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000003B9F0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003B9F4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000003B9F8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000003BA00: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000003BA0C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003BA10: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000003BA14: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000003BA18: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000003BA20: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BA28: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000003BA2C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000003BA30: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000003BA34: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA38: BF870095
	.long 0xd71c000a                                           // 00000003BA3C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000003BA40: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000003BA44: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000003BA48: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA50: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000003BA54: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000003BA5C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA60: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000003BA64: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 00000003BA6C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA70: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000003BA74: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000003BA7C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 00000003BA80: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA88: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000003BA8C: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000003BA90: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA98: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000003BA9C: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000003BAA0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BAA8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000003BAAC: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 00000003BAB4: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 00000003BABC: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BAC8: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000003BACC: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000003BAD4: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 00000003BAE0: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003BAE8: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000003BAEC: BE802001
	s_cbranch_execz 57307                                      // 00000003BAF0: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d60>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 00000003BAF4: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003BB00: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003BB08: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003BB0C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BB10: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003BB14: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 00000003BB1C: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 00000003BB28: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003BB2C: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 00000003BB30: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000003BB34: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003BB3C: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BB44: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 00000003BB48: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 00000003BB4C: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 00000003BB50: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BB54: BF870095
	.long 0xd71c0001                                           // 00000003BB58: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000003BB5C: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003BB60: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003BB64: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BB6C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 00000003BB70: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003BB7C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BB80: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003BB84: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 00000003BB8C: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BB90: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 00000003BB94: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 00000003BB9C: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000003BBA0: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BBA8: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000003BBAC: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 00000003BBB0: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BBB8: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000003BBBC: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 00000003BBC0: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BBC8: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 00000003BBCC: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003BBD4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 00000003BBDC: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BBE8: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 00000003BBEC: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 00000003BBF4: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003BC00: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003BC08: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000003BC0C: BE802002
	s_cbranch_execz 57238                                      // 00000003BC10: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d6c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 00000003BC14: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003BC20: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003BC28: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003BC2C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BC30: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003BC34: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003BC3C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 00000003BC48: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003BC4C: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000003BC50: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003BC54: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003BC5C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BC64: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003BC68: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 00000003BC6C: 7E041109
	v_exp_f32_e32 v1, v1                                       // 00000003BC70: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BC74: BF870095
	.long 0xd71c0001                                           // 00000003BC78: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003BC7C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003BC80: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003BC84: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BC8C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000003BC90: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003BC9C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BCA0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003BCA4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003BCAC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BCB0: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 00000003BCB4: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 00000003BCBC: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 00000003BCC0: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BCC8: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 00000003BCCC: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 00000003BCD0: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BCD8: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 00000003BCDC: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000003BCE0: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BCE8: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 00000003BCEC: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003BCF4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 00000003BCFC: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BD08: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003BD0C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003BD14: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003BD20: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003BD28: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000003BD2C: BE802003
	s_cbranch_execz 57169                                      // 00000003BD30: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d78>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 00000003BD34: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003BD40: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003BD48: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003BD4C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BD50: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003BD54: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003BD5C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000003BD68: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003BD6C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000003BD70: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003BD74: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003BD7C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BD84: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003BD88: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000003BD8C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000003BD90: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BD94: BF870095
	.long 0xd71c0001                                           // 00000003BD98: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003BD9C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003BDA0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003BDA4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BDAC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 00000003BDB0: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003BDBC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BDC0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003BDC4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003BDCC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BDD0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000003BDD4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000003BDDC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000003BDE0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BDE8: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 00000003BDEC: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 00000003BDF0: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BDF8: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 00000003BDFC: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 00000003BE00: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BE08: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000003BE0C: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003BE14: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 00000003BE1C: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BE28: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003BE2C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003BE34: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003BE40: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003BE48: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000003BE4C: BE802004
	s_cbranch_execz 57100                                      // 00000003BE50: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d84>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 00000003BE54: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003BE60: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003BE68: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003BE6C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BE70: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003BE74: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003BE7C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000003BE88: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003BE8C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000003BE90: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003BE94: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003BE9C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BEA4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003BEA8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000003BEAC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000003BEB0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BEB4: BF870095
	.long 0xd71c0001                                           // 00000003BEB8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003BEBC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003BEC0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003BEC4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BECC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000003BED0: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000003BED8: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BEE0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003BEE4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003BEEC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BEF0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000003BEF4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000003BEFC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000003BF00: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF08: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000003BF0C: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000003BF10: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF18: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000003BF1C: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000003BF20: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF28: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000003BF2C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003BF34: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 00000003BF3C: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF48: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003BF4C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003BF54: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003BF60: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003BF68: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000003BF6C: BE802005
	s_cbranch_execz 57031                                      // 00000003BF70: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d90>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 00000003BF74: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003BF80: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003BF88: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003BF8C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF90: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003BF94: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003BF9C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000003BFA8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003BFAC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000003BFB0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003BFB4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003BFBC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003BFC4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003BFC8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000003BFCC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000003BFD0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BFD4: BF870095
	.long 0xd71c0001                                           // 00000003BFD8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003BFDC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003BFE0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003BFE4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BFEC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000003BFF0: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003BFFC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C000: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003C004: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003C00C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C010: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000003C014: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000003C01C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000003C020: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C028: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000003C02C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000003C030: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C038: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000003C03C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000003C040: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C048: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000003C04C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003C054: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000003C05C: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C068: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003C06C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003C074: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003C080: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003C088: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000003C08C: BE802006
	s_cbranch_execz 56962                                      // 00000003C090: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d9c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 00000003C094: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003C0A0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003C0A8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003C0AC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C0B0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003C0B4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003C0BC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000003C0C8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003C0CC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000003C0D0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003C0D4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003C0DC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C0E4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003C0E8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000003C0EC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000003C0F0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C0F4: BF870095
	.long 0xd71c0001                                           // 00000003C0F8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003C0FC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003C100: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003C104: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C10C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000003C110: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003C11C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C120: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003C124: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003C12C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C130: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000003C134: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000003C13C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000003C140: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C148: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000003C14C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000003C150: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C158: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000003C15C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000003C160: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C168: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000003C16C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003C174: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 00000003C17C: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C188: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003C18C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003C194: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003C1A0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003C1A8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000003C1AC: BE802007
	s_cbranch_execz 56893                                      // 00000003C1B0: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb1EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 00000003C1B4: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000003C1C0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000003C1C8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000003C1CC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C1D0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000003C1D4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000003C1DC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000003C1E8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003C1EC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000003C1F0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000003C1F4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000003C1FC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C204: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000003C208: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000003C20C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000003C210: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C214: BF870095
	.long 0xd71c0001                                           // 00000003C218: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000003C21C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000003C220: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000003C224: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C22C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 00000003C230: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000003C23C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C240: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000003C244: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000003C24C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C250: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000003C254: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000003C25C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000003C260: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C268: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000003C26C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000003C270: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C278: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000003C27C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000003C280: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C288: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000003C28C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000003C294: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 00000003C29C: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C2A8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000003C2AC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000003C2B4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000003C2C0: DC9601E0 007C0200
	s_nop 0                                                    // 00000003C2C8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000003C2CC: BFB60003
	s_endpgm                                                   // 00000003C2D0: BFB00000
		...

