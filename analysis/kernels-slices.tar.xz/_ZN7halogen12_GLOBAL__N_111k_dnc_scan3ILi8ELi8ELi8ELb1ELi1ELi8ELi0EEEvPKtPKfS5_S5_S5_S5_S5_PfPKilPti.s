0000000000074800 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000074800: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000074804: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000007480C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000074814: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000074818: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000007481C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000074820: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000074828: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000007482C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000074830: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000074834: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000007483C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000074840: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000074844: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000074848: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007484C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000074850: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000074854: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000074858: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000007485C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000074864: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000007486C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000074870: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000074874: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000074878: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000007487C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000074880: 821E191E
	.long 0xd7001f02                                           // 000000074884: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000074888: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000007488C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000074894: BE9E0080
	s_nop 0                                                    // 000000074898: BF800000
	s_nop 0                                                    // 00000007489C: BF800000
	s_nop 0                                                    // 0000000748A0: BF800000
	s_nop 0                                                    // 0000000748A4: BF800000
	s_nop 0                                                    // 0000000748A8: BF800000
	s_nop 0                                                    // 0000000748AC: BF800000
	s_nop 0                                                    // 0000000748B0: BF800000
	s_nop 0                                                    // 0000000748B4: BF800000
	s_nop 0                                                    // 0000000748B8: BF800000
	s_nop 0                                                    // 0000000748BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000748C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000748C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000748D0: 300C1089
	.long 0xd7006a06                                           // 0000000748D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000748D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000748DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000748E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000748E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000748F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000748F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000748FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000074908: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000007490C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000074910: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000074918: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000007491C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000074920: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000074924: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 00000007492C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000074934: 32040084
	s_mov_b32 s0, 0                                            // 000000074938: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000007493C: BF89FC07
	s_barrier                                                  // 000000074940: BFBD0000
	buffer_gl0_inv                                             // 000000074944: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000007494C: BF02801E
	s_cbranch_scc1 12                                          // 000000074950: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000074954: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000007495C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000074964: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 000000074968: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000074970: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 000000074974: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000074978: 916A007E
	s_cbranch_vccz 2                                           // 00000007497C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2856                                              // 000000074980: BFA00B28 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e24>
	v_lshlrev_b32_e32 v37, 2, v5                               // 000000074984: 304A0A82
	s_add_i32 s0, s30, 63                                      // 000000074988: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000007498C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000074994: 85218600
	s_add_u32 s34, s10, s24                                    // 000000074998: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000007499C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000749A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000749A4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000749AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000749B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000749B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000749B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000749BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000749C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000749C4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000749C8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000749D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000749D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000749DC: B00A0204
	.long 0xd7000b2a                                           // 0000000749E0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000749E4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000749E8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000749EC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000749F4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000074A00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 000000074A04: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 000000074A10: 38164C0A
	.long 0xd7000a05                                           // 000000074A14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000074A18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000074A1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000074A20: D5207C06 00290001
	.long 0xd7000107                                           // 000000074A28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 000000074A2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074A30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000074A34: D5207C08 0006180D
	.long 0xd7000109                                           // 000000074A3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000074A40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000074A44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 000000074A4C: 84848E02
	.long 0xd700010b                                           // 000000074A50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000074A54: 02021606
	s_add_u32 s4, s14, s4                                      // 000000074A58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 000000074A5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000074A64: 8205050F
	.long 0xd700010d                                           // 000000074A68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 000000074A6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074A70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000074A74: D5207C0E 00050005
	.long 0xd700010f                                           // 000000074A7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000074A80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000074A88: D5207C10 00061880
	.long 0xd7000111                                           // 000000074A90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000074A94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074A9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 000000074AA0: D5207C12 00061880
	.long 0xd7000113                                           // 000000074AA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 000000074AAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 000000074AB4: D5207C14 00061880
	.long 0xd7000115                                           // 000000074ABC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 000000074AC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074AC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 000000074ACC: D5207C16 00061880
	.long 0xd7000117                                           // 000000074AD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 000000074AD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 000000074AE0: D5207C18 00061880
	.long 0xd7000119                                           // 000000074AE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 000000074AEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074AF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 000000074AF8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000074B00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000074B04: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 000000074B0C: 4A504CFF 00004420
	.long 0xd44c0000                                           // 000000074B14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000074B18: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 000000074B20: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 000000074B24: 4A0846FF 00002200
	v_or_b32_e32 v45, 0x2200, v1                               // 000000074B2C: 385A02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000074B34: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v1                            // 000000074B3C: 4A5C02FF 00000400
	v_add_nc_u32_e32 v47, 0x600, v1                            // 000000074B44: 4A5E02FF 00000600
	v_add_nc_u32_e32 v48, 0x800, v1                            // 000000074B4C: 4A6002FF 00000800
	v_add_nc_u32_e32 v49, 0xc00, v1                            // 000000074B54: 4A6202FF 00000C00
	v_add_nc_u32_e32 v50, 0xe00, v1                            // 000000074B5C: 4A6402FF 00000E00
	v_add_nc_u32_e32 v51, 0x1000, v1                           // 000000074B64: 4A6602FF 00001000
	v_add_nc_u32_e32 v52, 0x1400, v1                           // 000000074B6C: 4A6802FF 00001400
	v_add_nc_u32_e32 v53, 0x1600, v1                           // 000000074B74: 4A6A02FF 00001600
	v_add_nc_u32_e32 v54, 0x1800, v1                           // 000000074B7C: 4A6C02FF 00001800
	v_add_nc_u32_e32 v55, 0x1c00, v1                           // 000000074B84: 4A6E02FF 00001C00
	v_add_nc_u32_e32 v56, 0x1e00, v1                           // 000000074B8C: 4A7002FF 00001E00
	v_add_nc_u32_e32 v57, 0x2000, v1                           // 000000074B94: 4A7202FF 00002000
	s_mov_b32 s5, 0                                            // 000000074B9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000074BA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 000000074BA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000074BAC: BF870499
	s_add_i32 s6, s31, s1                                      // 000000074BB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 000000074BB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000074BB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000074BBC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000074BC0: 84078605
	s_add_u32 s10, s8, s10                                     // 000000074BC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 000000074BC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 000000074BCC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000074BD4: BE84206A
	s_cbranch_execz 77                                         // 000000074BD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 000000074BDC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074BE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 000000074BE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 000000074BEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074BF0: BF870091
	.long 0xd73c001d                                           // 000000074BF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 000000074BF8: 02023A82
	.long 0xd700011d                                           // 000000074BFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000074C00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000074C04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000074C08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000074C10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000074C18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 000000074C1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000074C20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000074C2C: BF8701A1
	v_fma_f32 v58, 0x3fb8aa3b, v29, -v32                       // 000000074C30: D613003A 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v59, v32                                   // 000000074C3C: 7E764720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000074C40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 000000074C4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000074C50: BF870191
	v_dual_fmac_f32 v58, 0x32a5705f, v29 :: v_dual_sub_f32 v31, v31, v34// 000000074C54: C80A3AFF 3A1E451F 32A5705F
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_sub_f32 v32, v32, v59// 000000074C60: C80A3CFF 21207720 32A5705F
	.long 0xd41b0001                                           // 000000074C6C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000074C70: 02023CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000074C78: BF8701B2
	v_dual_add_f32 v31, v31, v33 :: v_dual_add_f32 v32, v32, v58// 000000074C7C: C908431F 1F207520
	v_cvt_i32_f32_e32 v33, v34                                 // 000000074C84: 7E421122
	v_cvt_i32_f32_e32 v34, v59                                 // 000000074C88: 7E44113B
	v_exp_f32_e32 v31, v31                                     // 000000074C8C: 7E3E4B1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000074C90: BF870313
	v_exp_f32_e32 v32, v32                                     // 000000074C94: 7E404B20
	.long 0xd71c001f                                           // 000000074C98: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 000000074C9C: 0202431F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000074CA0: BF870115
	.long 0xd71c0020                                           // 000000074CA4: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 000000074CA8: 02024520
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 000000074CAC: D501001F 00063E80
	.long 0xd41b0001                                           // 000000074CB4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 000000074CB8: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074CC0: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 000000074CC4: D5010020 00064080
	.long 0xd41e0001                                           // 000000074CCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 000000074CD0: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 000000074CD8: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 000000074CE4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 000000074CE8: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074CF0: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 000000074CF4: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 000000074D00: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 000000074D08: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 000000074D10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000074D14: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 000000074D1C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000074D20: BF89FC07
	s_barrier                                                  // 000000074D24: BFBD0000
	buffer_gl0_inv                                             // 000000074D28: E0AC0000 00000000
	s_branch 15                                                // 000000074D30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000074D34: 8C7E047E
	.long 0xd700011d                                           // 000000074D38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 000000074D3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074D44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000074D48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000074D50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000074D54: BF08B70A
	s_mov_b32 s10, s1                                          // 000000074D58: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 000000074D5C: BF89FC07
	s_barrier                                                  // 000000074D60: BFBD0000
	buffer_gl0_inv                                             // 000000074D64: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 000000074D6C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000074D70: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 000000074D78: CA100126 21220124
	s_mov_b32 s11, 0                                           // 000000074D80: BE8B0080
	s_nop 0                                                    // 000000074D84: BF800000
	s_nop 0                                                    // 000000074D88: BF800000
	s_nop 0                                                    // 000000074D8C: BF800000
	s_nop 0                                                    // 000000074D90: BF800000
	s_nop 0                                                    // 000000074D94: BF800000
	s_nop 0                                                    // 000000074D98: BF800000
	s_nop 0                                                    // 000000074D9C: BF800000
	s_nop 0                                                    // 000000074DA0: BF800000
	s_nop 0                                                    // 000000074DA4: BF800000
	s_nop 0                                                    // 000000074DA8: BF800000
	s_nop 0                                                    // 000000074DAC: BF800000
	s_nop 0                                                    // 000000074DB0: BF800000
	s_nop 0                                                    // 000000074DB4: BF800000
	s_nop 0                                                    // 000000074DB8: BF800000
	s_nop 0                                                    // 000000074DBC: BF800000
	global_load_b32 v58, v[31:32], off                         // 000000074DC0: DC520000 3A7C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000074DC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 000000074DD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 000000074DD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000074DDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000074DE0: D5207C20 00064080
	.long 0xd4490004                                           // 000000074DE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000074DEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000074DF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000074DF8: BF8903F7
	ds_store_b32 v33, v58 offset:13056                         // 000000074DFC: D8343300 00003A21
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000074E04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000074E0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000074E10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000074E14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000074E18: BF89FC07
	s_barrier                                                  // 000000074E1C: BFBD0000
	buffer_gl0_inv                                             // 000000074E20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000074E28: BE842000
	s_cbranch_execz 65473                                      // 000000074E2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v44 offset1:1                  // 000000074E30: D8DC0100 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:2 offset1:3        // 000000074E38: D8DC0302 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:4 offset1:5        // 000000074E40: D8DC0504 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:6 offset1:7        // 000000074E48: D8DC0706 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000074E50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 000000074E58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000074E60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 000000074E68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v44 offset0:14 offset1:15      // 000000074E70: D8DC0F0E 4800002C
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 000000074E78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 000000074E80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 000000074E88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 000000074E90: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 000000074E98: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074EA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 000000074EA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 000000074EAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 000000074EB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074EB4: BF870091
	.long 0xd7000146                                           // 000000074EB8: D7000146
	v_cndmask_b32_e32 v1, v42, v70, vcc_lo                     // 000000074EBC: 02028D2A
	v_add_co_ci_u32_e64 v71, null, v43, v71, s1                // 000000074EC0: D5207C47 00068F2B
	global_load_b32 v70, v[70:71], off                         // 000000074EC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 000000074ED0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 000000074ED4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074EDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 000000074EE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 000000074EE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 000000074EEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v44 offset0:8 offset1:9        // 000000074EF4: D8DC0908 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:10 offset1:11      // 000000074EFC: D8DC0B0A 3E00002C
	ds_load_2addr_b32 v[70:71], v44 offset0:12 offset1:13      // 000000074F04: D8DC0D0C 4600002C
	v_fma_f32 v33, -v34, v65, v33                              // 000000074F0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 000000074F14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F18: BF870091
	v_fma_f32 v33, -v58, v66, v33                              // 000000074F1C: D6130021 2486853A
	v_fma_f32 v33, -v59, v67, v33                              // 000000074F24: D6130021 2486873B
	s_waitcnt lgkmcnt(8)                                       // 000000074F2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 000000074F34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 000000074F3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 000000074F44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 000000074F4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 000000074F54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 000000074F5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074F60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000074F64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:16 offset1:17      // 000000074F6C: D8DC1110 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:18 offset1:19      // 000000074F74: D8DC1312 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:20 offset1:21      // 000000074F7C: D8DC1514 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:22 offset1:23      // 000000074F84: D8DC1716 3C00002C
	ds_load_2addr_b32 v[64:65], v46 offset0:16 offset1:33      // 000000074F8C: D8DC2110 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:50 offset1:67      // 000000074F94: D8DC4332 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:101     // 000000074F9C: D8DC6554 4400002E
	ds_load_2addr_b32 v[74:75], v46 offset0:118 offset1:135    // 000000074FA4: D8DC8776 4A00002E
	v_fma_f32 v62, -v63, v77, v62                              // 000000074FAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 000000074FB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 000000074FBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 000000074FC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FCC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 000000074FD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 000000074FD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 000000074FE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 000000074FE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 000000074FF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 000000074FF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074FFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 000000075000: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v44 offset0:24 offset1:25      // 000000075008: D8DC1918 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:26 offset1:27      // 000000075010: D8DC1B1A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:28 offset1:29      // 000000075018: D8DC1D1C 4000002C
	ds_load_2addr_b32 v[70:71], v44 offset0:30 offset1:31      // 000000075020: D8DC1F1E 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:152 offset1:169    // 000000075028: D8DCA998 4800002E
	ds_load_2addr_b32 v[76:77], v46 offset0:186 offset1:203    // 000000075030: D8DCCBBA 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:220 offset1:237    // 000000075038: D8DCEDDC 4E00002E
	ds_load_2addr_b32 v[80:81], v47 offset0:126 offset1:143    // 000000075040: D8DC8F7E 5000002F
	v_fma_f32 v33, -v34, v67, v33                              // 000000075048: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 000000075050: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075054: BF870091
	v_fma_f32 v33, -v58, v68, v33                              // 000000075058: D6130021 2486893A
	v_fma_f32 v33, -v59, v69, v33                              // 000000075060: D6130021 24868B3B
	s_waitcnt lgkmcnt(8)                                       // 000000075068: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007506C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000075070: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000075078: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000075080: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075084: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 000000075088: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 000000075090: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 000000075098: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007509C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000750A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:32 offset1:33      // 0000000750A8: D8DC2120 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:34 offset1:35      // 0000000750B0: D8DC2322 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:36 offset1:37      // 0000000750B8: D8DC2524 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:38 offset1:39      // 0000000750C0: D8DC2726 3C00002C
	ds_load_2addr_b32 v[66:67], v48 offset0:32 offset1:49      // 0000000750C8: D8DC3120 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:66 offset1:83      // 0000000750D0: D8DC5342 44000030
	ds_load_2addr_b32 v[72:73], v48 offset0:100 offset1:117    // 0000000750D8: D8DC7564 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:134 offset1:151    // 0000000750E0: D8DC9786 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000750E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000750F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000750F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000750F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000075100: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000075108: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007510C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 000000075110: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 000000075118: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 000000075120: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075124: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000075128: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000075130: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 000000075138: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007513C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 000000075140: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v44 offset0:40 offset1:41      // 000000075148: D8DC2928 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:42 offset1:43      // 000000075150: D8DC2B2A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:44 offset1:45      // 000000075158: D8DC2D2C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:46 offset1:47      // 000000075160: D8DC2F2E 4200002C
	ds_load_2addr_b32 v[70:71], v48 offset0:168 offset1:185    // 000000075168: D8DCB9A8 46000030
	ds_load_2addr_b32 v[76:77], v48 offset0:202 offset1:219    // 000000075170: D8DCDBCA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:236 offset1:253    // 000000075178: D8DCFDEC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:14 offset1:31      // 000000075180: D8DC1F0E 50000031
	v_fma_f32 v33, -v34, v69, v33                              // 000000075188: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 000000075190: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075194: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 000000075198: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000751A0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000751A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000751B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000751B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000751C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000751C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000751D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000751D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000751DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000751E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:48 offset1:49      // 0000000751E8: D8DC3130 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:50 offset1:51      // 0000000751F0: D8DC3332 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:52 offset1:53      // 0000000751F8: D8DC3534 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:54 offset1:55      // 000000075200: D8DC3736 3C00002C
	ds_load_2addr_b32 v[68:69], v49 offset0:48 offset1:65      // 000000075208: D8DC4130 44000031
	ds_load_2addr_b32 v[70:71], v49 offset0:82 offset1:99      // 000000075210: D8DC6352 46000031
	ds_load_2addr_b32 v[72:73], v49 offset0:116 offset1:133    // 000000075218: D8DC8574 48000031
	ds_load_2addr_b32 v[74:75], v49 offset0:150 offset1:167    // 000000075220: D8DCA796 4A000031
	v_fma_f32 v62, -v63, v77, v62                              // 000000075228: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000075230: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075234: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000075238: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000075240: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000075248: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007524C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000075250: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000075258: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000075260: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075264: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000075268: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075270: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075278: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007527C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000075280: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:56 offset1:57      // 000000075288: D8DC3938 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:58 offset1:59      // 000000075290: D8DC3B3A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:60 offset1:61      // 000000075298: D8DC3D3C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:62 offset1:63      // 0000000752A0: D8DC3F3E 4200002C
	ds_load_2addr_b32 v[68:69], v49 offset0:184 offset1:201    // 0000000752A8: D8DCC9B8 44000031
	ds_load_2addr_b32 v[76:77], v49 offset0:218 offset1:235    // 0000000752B0: D8DCEBDA 4C000031
	ds_load_2addr_b32 v[78:79], v50 offset0:124 offset1:141    // 0000000752B8: D8DC8D7C 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:30 offset1:47      // 0000000752C0: D8DC2F1E 50000033
	v_fma_f32 v33, -v34, v71, v33                              // 0000000752C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000752D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752D4: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000752D8: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000752E0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000752E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000752F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000752F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000075300: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075304: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000075308: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075310: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075318: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007531C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000075320: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:64 offset1:65      // 000000075328: D8DC4140 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:66 offset1:67      // 000000075330: D8DC4342 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:68 offset1:69      // 000000075338: D8DC4544 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:70 offset1:71      // 000000075340: D8DC4746 3C00002C
	ds_load_2addr_b32 v[68:69], v51 offset0:64 offset1:81      // 000000075348: D8DC5140 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:98 offset1:115     // 000000075350: D8DC7362 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:132 offset1:149    // 000000075358: D8DC9584 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:166 offset1:183    // 000000075360: D8DCB7A6 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 000000075368: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000075370: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075374: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000075378: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000075380: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000075388: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007538C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000075390: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000075398: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000753A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000753A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000753A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000753B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000753B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000753BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000753C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:72 offset1:73      // 0000000753C8: D8DC4948 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:74 offset1:75      // 0000000753D0: D8DC4B4A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:76 offset1:77      // 0000000753D8: D8DC4D4C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:78 offset1:79      // 0000000753E0: D8DC4F4E 4200002C
	ds_load_2addr_b32 v[68:69], v51 offset0:200 offset1:217    // 0000000753E8: D8DCD9C8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:234 offset1:251    // 0000000753F0: D8DCFBEA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:12 offset1:29      // 0000000753F8: D8DC1D0C 4E000034
	ds_load_2addr_b32 v[80:81], v52 offset0:46 offset1:63      // 000000075400: D8DC3F2E 50000034
	v_fma_f32 v33, -v34, v71, v33                              // 000000075408: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000075410: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075414: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 000000075418: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 000000075420: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 000000075428: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007542C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000075430: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000075438: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000075440: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075444: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000075448: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075450: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075458: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007545C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000075460: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:80 offset1:81      // 000000075468: D8DC5150 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:82 offset1:83      // 000000075470: D8DC5352 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:84 offset1:85      // 000000075478: D8DC5554 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:86 offset1:87      // 000000075480: D8DC5756 3C00002C
	ds_load_2addr_b32 v[68:69], v52 offset0:80 offset1:97      // 000000075488: D8DC6150 44000034
	ds_load_2addr_b32 v[70:71], v52 offset0:114 offset1:131    // 000000075490: D8DC8372 46000034
	ds_load_2addr_b32 v[72:73], v52 offset0:148 offset1:165    // 000000075498: D8DCA594 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:182 offset1:199    // 0000000754A0: D8DCC7B6 4A000034
	v_fma_f32 v62, -v63, v77, v62                              // 0000000754A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000754B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000754B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000754B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000754C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000754C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000754CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000754D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000754D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000754E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000754E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000754E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000754F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000754F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000754FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000075500: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:88 offset1:89      // 000000075508: D8DC5958 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:90 offset1:91      // 000000075510: D8DC5B5A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:92 offset1:93      // 000000075518: D8DC5D5C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:94 offset1:95      // 000000075520: D8DC5F5E 4200002C
	ds_load_2addr_b32 v[68:69], v52 offset0:216 offset1:233    // 000000075528: D8DCE9D8 44000034
	ds_load_2addr_b32 v[76:77], v53 offset0:122 offset1:139    // 000000075530: D8DC8B7A 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:28 offset1:45      // 000000075538: D8DC2D1C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:62 offset1:79      // 000000075540: D8DC4F3E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 000000075548: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000075550: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075554: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 000000075558: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 000000075560: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 000000075568: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007556C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000075570: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000075578: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000075580: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075584: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000075588: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075590: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075598: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007559C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000755A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:96 offset1:97      // 0000000755A8: D8DC6160 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:98 offset1:99      // 0000000755B0: D8DC6362 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:100 offset1:101    // 0000000755B8: D8DC6564 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:102 offset1:103    // 0000000755C0: D8DC6766 3C00002C
	ds_load_2addr_b32 v[68:69], v54 offset0:96 offset1:113     // 0000000755C8: D8DC7160 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:130 offset1:147    // 0000000755D0: D8DC9382 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:164 offset1:181    // 0000000755D8: D8DCB5A4 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:198 offset1:215    // 0000000755E0: D8DCD7C6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000755E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000755F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000755F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000755F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000075600: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000075608: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007560C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000075610: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000075618: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000075620: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075624: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000075628: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075630: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075638: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007563C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000075640: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:104 offset1:105    // 000000075648: D8DC6968 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:106 offset1:107    // 000000075650: D8DC6B6A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:108 offset1:109    // 000000075658: D8DC6D6C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:110 offset1:111    // 000000075660: D8DC6F6E 4200002C
	ds_load_2addr_b32 v[68:69], v54 offset0:232 offset1:249    // 000000075668: D8DCF9E8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:10 offset1:27      // 000000075670: D8DC1B0A 4C000037
	ds_load_2addr_b32 v[78:79], v55 offset0:44 offset1:61      // 000000075678: D8DC3D2C 4E000037
	ds_load_2addr_b32 v[80:81], v55 offset0:78 offset1:95      // 000000075680: D8DC5F4E 50000037
	v_fma_f32 v33, -v34, v71, v33                              // 000000075688: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000075690: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075694: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 000000075698: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000756A0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000756A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000756AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000756B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000756B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000756C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000756C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000756C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000756D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000756D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000756DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000756E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:112 offset1:113    // 0000000756E8: D8DC7170 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:114 offset1:115    // 0000000756F0: D8DC7372 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:116 offset1:117    // 0000000756F8: D8DC7574 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:118 offset1:119    // 000000075700: D8DC7776 3C00002C
	ds_load_2addr_b32 v[68:69], v55 offset0:112 offset1:129    // 000000075708: D8DC8170 44000037
	ds_load_2addr_b32 v[70:71], v55 offset0:146 offset1:163    // 000000075710: D8DCA392 46000037
	ds_load_2addr_b32 v[72:73], v55 offset0:180 offset1:197    // 000000075718: D8DCC5B4 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:214 offset1:231    // 000000075720: D8DCE7D6 4A000037
	v_fma_f32 v62, -v63, v77, v62                              // 000000075728: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000075730: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075734: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000075738: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000075740: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000075748: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007574C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000075750: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000075758: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000075760: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075764: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000075768: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075770: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075778: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007577C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000075780: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:120 offset1:121    // 000000075788: D8DC7978 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:122 offset1:123    // 000000075790: D8DC7B7A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:124 offset1:125    // 000000075798: D8DC7D7C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:126 offset1:127    // 0000000757A0: D8DC7F7E 4200002C
	ds_load_2addr_b32 v[68:69], v56 offset0:120 offset1:137    // 0000000757A8: D8DC8978 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:26 offset1:43      // 0000000757B0: D8DC2B1A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:60 offset1:77      // 0000000757B8: D8DC4D3C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:94 offset1:111     // 0000000757C0: D8DC6F5E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000757C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000757D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000757D4: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000757D8: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000757E0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000757E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000757EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000757F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000757F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000075800: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075804: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000075808: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000075810: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000075818: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007581C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 000000075820: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 000000075828: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 000000075830: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075834: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 000000075838: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 000000075840: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 000000075848: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007584C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 000000075850: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 000000075858: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 000000075864: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000007586C: D8340000 0000201F
	s_branch 64815                                             // 000000075874: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000075878: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000007587C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000075884: 7E3E0309
	v_mov_b32_e32 v58, v41                                     // 000000075888: 7E740329
	s_mov_b32 s10, 0                                           // 00000007588C: BE8A0080
	s_branch 21                                                // 000000075890: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000075894: 8C7E0B7E
	.long 0xd700011f                                           // 000000075898: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000007589C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000758A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000758A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000758B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000758B4: 02023AFF 00000800
	v_add_nc_u32_e32 v58, 8, v58                               // 0000000758BC: 4A747488
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000758C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 0000000758C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000758CC: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000758D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000758D4: BC7C0000
	s_barrier                                                  // 0000000758D8: BFBD0000
	buffer_gl0_inv                                             // 0000000758DC: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 0000000758E4: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000758E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000758EC: CA100120 2220011F
	v_dual_mov_b32 v59, v38 :: v_dual_mov_b32 v60, v36         // 0000000758F4: CA100126 3B3C0124
	s_mov_b32 s11, 0                                           // 0000000758FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 000000075900: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000075908: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000075910: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000075914: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007591C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000075920: D5207C22 00064480
	.long 0xd4490004                                           // 000000075928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000007592C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000075934: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000075938: BF8903F7
	ds_store_b32 v59, v61 offset:13056                         // 00000007593C: D8343300 00003D3B
	v_add_nc_u32_e32 v59, 0x204, v59                           // 000000075944: 4A7676FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007594C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000075950: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000075954: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000075958: BF89FC07
	s_barrier                                                  // 00000007595C: BFBD0000
	buffer_gl0_inv                                             // 000000075960: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000075968: BE8B2000
	s_cbranch_execz 65481                                      // 00000007596C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 000000075970: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075974: BF870091
	v_or_b32_e32 v59, s7, v33                                  // 000000075978: 38764207
	.long 0xd4440001                                           // 00000007597C: D4440001
	v_cndmask_b32_e32 v1, s30, v59, vcc_lo                     // 000000075980: 0202761E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000075984: 8B7E017E
	s_cbranch_execz 65474                                      // 000000075988: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v44 offset1:1                  // 00000007598C: D8DC0100 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000075994: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v44 offset0:2 offset1:3        // 00000007599C: D8DC0302 4000002C
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000759A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v44 offset0:4 offset1:5        // 0000000759AC: D8DC0504 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:6 offset1:7        // 0000000759B4: D8DC0706 4600002C
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000759BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000759C4: D8DC7766 4A000001
	s_mov_b32 s12, 0                                           // 0000000759CC: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 0000000759D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000759D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000759DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000759E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000759E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000759E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000759EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000759F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000759F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000759F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000759FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075A00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075A04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075A08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075A0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075A10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:8 offset1:9        // 000000075A14: D8DC0908 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 000000075A1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v44 offset0:10 offset1:11      // 000000075A24: D8DC0B0A 4000002C
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 000000075A2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v44 offset0:12 offset1:13      // 000000075A34: D8DC0D0C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:14 offset1:15      // 000000075A3C: D8DC0F0E 4600002C
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 000000075A44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 000000075A4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 000000075A54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075A58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075A5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075A60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075A64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075A68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075A6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075A70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075A74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075A78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075A7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075A80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075A84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075A88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075A8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075A90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:16 offset1:17      // 000000075A94: D8DC1110 3C00002C
	ds_load_2addr_b32 v[62:63], v46 offset0:16 offset1:33      // 000000075A9C: D8DC2110 3E00002E
	ds_load_2addr_b32 v[64:65], v44 offset0:18 offset1:19      // 000000075AA4: D8DC1312 4000002C
	ds_load_2addr_b32 v[66:67], v46 offset0:50 offset1:67      // 000000075AAC: D8DC4332 4200002E
	ds_load_2addr_b32 v[68:69], v44 offset0:20 offset1:21      // 000000075AB4: D8DC1514 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:22 offset1:23      // 000000075ABC: D8DC1716 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:84 offset1:101     // 000000075AC4: D8DC6554 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:118 offset1:135    // 000000075ACC: D8DC8776 4A00002E
	s_waitcnt lgkmcnt(6)                                       // 000000075AD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075AD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075ADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075AE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075AE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075AE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075AEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075AF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075AF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075AF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075AFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075B00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075B04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075B08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075B0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075B10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:24 offset1:25      // 000000075B14: D8DC1918 3C00002C
	ds_load_2addr_b32 v[62:63], v46 offset0:152 offset1:169    // 000000075B1C: D8DCA998 3E00002E
	ds_load_2addr_b32 v[64:65], v44 offset0:26 offset1:27      // 000000075B24: D8DC1B1A 4000002C
	ds_load_2addr_b32 v[66:67], v46 offset0:186 offset1:203    // 000000075B2C: D8DCCBBA 4200002E
	ds_load_2addr_b32 v[68:69], v44 offset0:28 offset1:29      // 000000075B34: D8DC1D1C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:30 offset1:31      // 000000075B3C: D8DC1F1E 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:220 offset1:237    // 000000075B44: D8DCEDDC 4800002E
	ds_load_2addr_b32 v[74:75], v47 offset0:126 offset1:143    // 000000075B4C: D8DC8F7E 4A00002F
	s_waitcnt lgkmcnt(6)                                       // 000000075B54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075B58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075B5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075B60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075B64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075B68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075B6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075B70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075B74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075B78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075B7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075B80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075B84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075B88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075B8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075B90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:32 offset1:33      // 000000075B94: D8DC2120 3C00002C
	ds_load_2addr_b32 v[62:63], v48 offset0:32 offset1:49      // 000000075B9C: D8DC3120 3E000030
	ds_load_2addr_b32 v[64:65], v44 offset0:34 offset1:35      // 000000075BA4: D8DC2322 4000002C
	ds_load_2addr_b32 v[66:67], v48 offset0:66 offset1:83      // 000000075BAC: D8DC5342 42000030
	ds_load_2addr_b32 v[68:69], v44 offset0:36 offset1:37      // 000000075BB4: D8DC2524 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:38 offset1:39      // 000000075BBC: D8DC2726 4600002C
	ds_load_2addr_b32 v[72:73], v48 offset0:100 offset1:117    // 000000075BC4: D8DC7564 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:134 offset1:151    // 000000075BCC: D8DC9786 4A000030
	s_waitcnt lgkmcnt(6)                                       // 000000075BD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075BD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075BDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075BE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075BE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075BE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075BEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075BF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075BF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075BF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075BFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075C00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075C04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075C08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075C0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075C10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:40 offset1:41      // 000000075C14: D8DC2928 3C00002C
	ds_load_2addr_b32 v[62:63], v48 offset0:168 offset1:185    // 000000075C1C: D8DCB9A8 3E000030
	ds_load_2addr_b32 v[64:65], v44 offset0:42 offset1:43      // 000000075C24: D8DC2B2A 4000002C
	ds_load_2addr_b32 v[66:67], v48 offset0:202 offset1:219    // 000000075C2C: D8DCDBCA 42000030
	ds_load_2addr_b32 v[68:69], v44 offset0:44 offset1:45      // 000000075C34: D8DC2D2C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:46 offset1:47      // 000000075C3C: D8DC2F2E 4600002C
	ds_load_2addr_b32 v[72:73], v48 offset0:236 offset1:253    // 000000075C44: D8DCFDEC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:14 offset1:31      // 000000075C4C: D8DC1F0E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 000000075C54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075C58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075C5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075C60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075C64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075C68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075C6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075C70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075C74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075C78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075C7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075C80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075C84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075C88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075C8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075C90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:48 offset1:49      // 000000075C94: D8DC3130 3C00002C
	ds_load_2addr_b32 v[62:63], v49 offset0:48 offset1:65      // 000000075C9C: D8DC4130 3E000031
	ds_load_2addr_b32 v[64:65], v44 offset0:50 offset1:51      // 000000075CA4: D8DC3332 4000002C
	ds_load_2addr_b32 v[66:67], v49 offset0:82 offset1:99      // 000000075CAC: D8DC6352 42000031
	ds_load_2addr_b32 v[68:69], v44 offset0:52 offset1:53      // 000000075CB4: D8DC3534 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:54 offset1:55      // 000000075CBC: D8DC3736 4600002C
	ds_load_2addr_b32 v[72:73], v49 offset0:116 offset1:133    // 000000075CC4: D8DC8574 48000031
	ds_load_2addr_b32 v[74:75], v49 offset0:150 offset1:167    // 000000075CCC: D8DCA796 4A000031
	s_waitcnt lgkmcnt(6)                                       // 000000075CD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075CD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075CDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075CE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075CE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075CE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075CEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075CF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075CF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075CF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075CFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075D00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075D04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075D08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075D0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075D10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:56 offset1:57      // 000000075D14: D8DC3938 3C00002C
	ds_load_2addr_b32 v[62:63], v49 offset0:184 offset1:201    // 000000075D1C: D8DCC9B8 3E000031
	ds_load_2addr_b32 v[64:65], v44 offset0:58 offset1:59      // 000000075D24: D8DC3B3A 4000002C
	ds_load_2addr_b32 v[66:67], v49 offset0:218 offset1:235    // 000000075D2C: D8DCEBDA 42000031
	ds_load_2addr_b32 v[68:69], v44 offset0:60 offset1:61      // 000000075D34: D8DC3D3C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:62 offset1:63      // 000000075D3C: D8DC3F3E 4600002C
	ds_load_2addr_b32 v[72:73], v50 offset0:124 offset1:141    // 000000075D44: D8DC8D7C 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:30 offset1:47      // 000000075D4C: D8DC2F1E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000075D54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075D58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075D5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075D60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075D64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075D68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075D6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075D70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075D74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075D78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075D7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075D80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075D84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075D88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075D8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075D90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:64 offset1:65      // 000000075D94: D8DC4140 3C00002C
	ds_load_2addr_b32 v[62:63], v51 offset0:64 offset1:81      // 000000075D9C: D8DC5140 3E000033
	ds_load_2addr_b32 v[64:65], v44 offset0:66 offset1:67      // 000000075DA4: D8DC4342 4000002C
	ds_load_2addr_b32 v[66:67], v51 offset0:98 offset1:115     // 000000075DAC: D8DC7362 42000033
	ds_load_2addr_b32 v[68:69], v44 offset0:68 offset1:69      // 000000075DB4: D8DC4544 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:70 offset1:71      // 000000075DBC: D8DC4746 4600002C
	ds_load_2addr_b32 v[72:73], v51 offset0:132 offset1:149    // 000000075DC4: D8DC9584 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:166 offset1:183    // 000000075DCC: D8DCB7A6 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000075DD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075DD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075DDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075DE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075DE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075DE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075DEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075DF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075DF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075DF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075DFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075E00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075E04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075E08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075E0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075E10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:72 offset1:73      // 000000075E14: D8DC4948 3C00002C
	ds_load_2addr_b32 v[62:63], v51 offset0:200 offset1:217    // 000000075E1C: D8DCD9C8 3E000033
	ds_load_2addr_b32 v[64:65], v44 offset0:74 offset1:75      // 000000075E24: D8DC4B4A 4000002C
	ds_load_2addr_b32 v[66:67], v51 offset0:234 offset1:251    // 000000075E2C: D8DCFBEA 42000033
	ds_load_2addr_b32 v[68:69], v44 offset0:76 offset1:77      // 000000075E34: D8DC4D4C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:78 offset1:79      // 000000075E3C: D8DC4F4E 4600002C
	ds_load_2addr_b32 v[72:73], v52 offset0:12 offset1:29      // 000000075E44: D8DC1D0C 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:46 offset1:63      // 000000075E4C: D8DC3F2E 4A000034
	s_waitcnt lgkmcnt(6)                                       // 000000075E54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075E58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075E5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075E60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075E64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075E68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075E6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075E70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075E74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075E78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075E7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075E80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075E84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075E88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075E8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075E90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:80 offset1:81      // 000000075E94: D8DC5150 3C00002C
	ds_load_2addr_b32 v[62:63], v52 offset0:80 offset1:97      // 000000075E9C: D8DC6150 3E000034
	ds_load_2addr_b32 v[64:65], v44 offset0:82 offset1:83      // 000000075EA4: D8DC5352 4000002C
	ds_load_2addr_b32 v[66:67], v52 offset0:114 offset1:131    // 000000075EAC: D8DC8372 42000034
	ds_load_2addr_b32 v[68:69], v44 offset0:84 offset1:85      // 000000075EB4: D8DC5554 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:86 offset1:87      // 000000075EBC: D8DC5756 4600002C
	ds_load_2addr_b32 v[72:73], v52 offset0:148 offset1:165    // 000000075EC4: D8DCA594 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:182 offset1:199    // 000000075ECC: D8DCC7B6 4A000034
	s_waitcnt lgkmcnt(6)                                       // 000000075ED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075ED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075EDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075EE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075EE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075EE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075EEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075EF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075EF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075EF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075EFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075F00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075F04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075F08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075F0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075F10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:88 offset1:89      // 000000075F14: D8DC5958 3C00002C
	ds_load_2addr_b32 v[62:63], v52 offset0:216 offset1:233    // 000000075F1C: D8DCE9D8 3E000034
	ds_load_2addr_b32 v[64:65], v44 offset0:90 offset1:91      // 000000075F24: D8DC5B5A 4000002C
	ds_load_2addr_b32 v[66:67], v53 offset0:122 offset1:139    // 000000075F2C: D8DC8B7A 42000035
	ds_load_2addr_b32 v[68:69], v44 offset0:92 offset1:93      // 000000075F34: D8DC5D5C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:94 offset1:95      // 000000075F3C: D8DC5F5E 4600002C
	ds_load_2addr_b32 v[72:73], v54 offset0:28 offset1:45      // 000000075F44: D8DC2D1C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:62 offset1:79      // 000000075F4C: D8DC4F3E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000075F54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075F58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075F5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075F60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075F64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075F68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075F6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075F70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075F74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075F78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075F7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000075F80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000075F84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000075F88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000075F8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000075F90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:96 offset1:97      // 000000075F94: D8DC6160 3C00002C
	ds_load_2addr_b32 v[62:63], v54 offset0:96 offset1:113     // 000000075F9C: D8DC7160 3E000036
	ds_load_2addr_b32 v[64:65], v44 offset0:98 offset1:99      // 000000075FA4: D8DC6362 4000002C
	ds_load_2addr_b32 v[66:67], v54 offset0:130 offset1:147    // 000000075FAC: D8DC9382 42000036
	ds_load_2addr_b32 v[68:69], v44 offset0:100 offset1:101    // 000000075FB4: D8DC6564 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:102 offset1:103    // 000000075FBC: D8DC6766 4600002C
	ds_load_2addr_b32 v[72:73], v54 offset0:164 offset1:181    // 000000075FC4: D8DCB5A4 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:198 offset1:215    // 000000075FCC: D8DCD7C6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000075FD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000075FD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075FDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000075FE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000075FE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000075FE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075FEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000075FF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000075FF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000075FF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075FFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000076000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000076004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000076008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007600C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000076010: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:104 offset1:105    // 000000076014: D8DC6968 3C00002C
	ds_load_2addr_b32 v[62:63], v54 offset0:232 offset1:249    // 00000007601C: D8DCF9E8 3E000036
	ds_load_2addr_b32 v[64:65], v44 offset0:106 offset1:107    // 000000076024: D8DC6B6A 4000002C
	ds_load_2addr_b32 v[66:67], v55 offset0:10 offset1:27      // 00000007602C: D8DC1B0A 42000037
	ds_load_2addr_b32 v[68:69], v44 offset0:108 offset1:109    // 000000076034: D8DC6D6C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:110 offset1:111    // 00000007603C: D8DC6F6E 4600002C
	ds_load_2addr_b32 v[72:73], v55 offset0:44 offset1:61      // 000000076044: D8DC3D2C 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:78 offset1:95      // 00000007604C: D8DC5F4E 4A000037
	s_waitcnt lgkmcnt(6)                                       // 000000076054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000076058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007605C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000076060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000076064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000076068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007606C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000076070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000076074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000076078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007607C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000076080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000076084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000076088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007608C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000076090: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:112 offset1:113    // 000000076094: D8DC7170 3C00002C
	ds_load_2addr_b32 v[62:63], v55 offset0:112 offset1:129    // 00000007609C: D8DC8170 3E000037
	ds_load_2addr_b32 v[64:65], v44 offset0:114 offset1:115    // 0000000760A4: D8DC7372 4000002C
	ds_load_2addr_b32 v[66:67], v55 offset0:146 offset1:163    // 0000000760AC: D8DCA392 42000037
	ds_load_2addr_b32 v[68:69], v44 offset0:116 offset1:117    // 0000000760B4: D8DC7574 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:118 offset1:119    // 0000000760BC: D8DC7776 4600002C
	ds_load_2addr_b32 v[72:73], v55 offset0:180 offset1:197    // 0000000760C4: D8DCC5B4 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:214 offset1:231    // 0000000760CC: D8DCE7D6 4A000037
	s_waitcnt lgkmcnt(6)                                       // 0000000760D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000760D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000760DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000760E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000760E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000760E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000760EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000760F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000760F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000760F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000760FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000076100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000076104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000076108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007610C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000076110: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:120 offset1:121    // 000000076114: D8DC7978 3C00002C
	ds_load_2addr_b32 v[62:63], v56 offset0:120 offset1:137    // 00000007611C: D8DC8978 3E000038
	ds_load_2addr_b32 v[64:65], v44 offset0:122 offset1:123    // 000000076124: D8DC7B7A 4000002C
	ds_load_2addr_b32 v[66:67], v57 offset0:26 offset1:43      // 00000007612C: D8DC2B1A 42000039
	ds_load_2addr_b32 v[68:69], v44 offset0:124 offset1:125    // 000000076134: D8DC7D7C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:126 offset1:127    // 00000007613C: D8DC7F7E 4600002C
	ds_load_2addr_b32 v[72:73], v57 offset0:60 offset1:77      // 000000076144: D8DC4D3C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:94 offset1:111     // 00000007614C: D8DC6F5E 4A000039
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000076154: 30424282
	s_waitcnt lgkmcnt(6)                                       // 000000076158: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007615C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 000000076160: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000076168: CA10011E 2220011D
	v_mov_b32_e32 v62, v58                                     // 000000076170: 7E7C033A
	v_fmac_f32_e32 v76, v61, v63                               // 000000076174: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 000000076178: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 00000007617C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076180: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 000000076184: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000076188: 56988741
	s_waitcnt lgkmcnt(2)                                       // 00000007618C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076190: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 000000076194: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 000000076198: 56989345
	s_waitcnt lgkmcnt(1)                                       // 00000007619C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000761A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000761A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000761A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000761AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000761B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000761B4: 1078794C
	s_nop 0                                                    // 0000000761B8: BF800000
	s_nop 0                                                    // 0000000761BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000761C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000761C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000761D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000761D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000761D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000761DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000761E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000761E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000761EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000761F0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 0000000761F8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000761FC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000076200: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000076204: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000076208: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000007620C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076210: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000076214: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v59, v[5:6]          // 00000007621C: D6FE7C21 041676FF 00003000
	v_add3_u32 v59, v60, v61, 0x7fff                           // 000000076228: D655003B 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v59, off                 // 000000076234: DC960000 007C3B21
	s_branch 64917                                             // 00000007623C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000076240: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 000000076248: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007624C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000076250: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000076258: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000007625C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000076264: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000007626C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000076270: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000076274: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000007627C: A0010401
	s_mov_b32 s4, 0                                            // 000000076280: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000076284: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000076288: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000007628C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000076290: BF870585
	.long 0xd71c001d                                           // 000000076294: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000076298: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000007629C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000000762A0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000762A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000762AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000762B4: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000762B8: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000762BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000762C8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000762D0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000762D8: BF870001
	.long 0xd4490001                                           // 0000000762DC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000762E0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000762E8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000762EC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000762F0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000762F4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000762FC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000076304: 917E047E
	s_cbranch_execnz 65519                                     // 000000076308: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007630C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000076310: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 000000076318: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 000000076320: 7E420324
	s_mov_b32 s6, 0                                            // 000000076324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000076328: BF89FC07
	s_barrier                                                  // 00000007632C: BFBD0000
	buffer_gl0_inv                                             // 000000076330: E0AC0000 00000000
	s_nop 0                                                    // 000000076338: BF800000
	s_nop 0                                                    // 00000007633C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000076340: DC520000 227C001D
	ds_load_b32 v58, v31 offset:17184                          // 000000076348: D8D84320 3A00001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000076350: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000076358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007635C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000076364: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000076368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000076370: BF870004
	.long 0xd4490004                                           // 000000076374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000076378: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000076380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000076384: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 000000076388: 10447522
	ds_store_b32 v32, v34 offset:13056                         // 00000007638C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000076394: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007639C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000763A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000763A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000763A8: BF89FC07
	s_barrier                                                  // 0000000763AC: BFBD0000
	buffer_gl0_inv                                             // 0000000763B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000763B8: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000763C0: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000763C8: D8DC5544 2100002D
	ds_load_2addr_b32 v[58:59], v45 offset0:102 offset1:119    // 0000000763D0: D8DC7766 3A00002D
	v_mov_b32_e32 v60, v0                                      // 0000000763D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000763DC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000763E0: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 0000000763E4: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 0000000763E8: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 0000000763EC: BF89FC27
	v_cvt_f16_f32_e32 v31, v31                                 // 0000000763F0: 7E3E151F
	v_cvt_f16_f32_e32 v32, v32                                 // 0000000763F4: 7E401520
	s_waitcnt lgkmcnt(1)                                       // 0000000763F8: BF89FC17
	v_cvt_f16_f32_e32 v33, v33                                 // 0000000763FC: 7E421521
	v_cvt_f16_f32_e32 v34, v34                                 // 000000076400: 7E441522
	s_waitcnt lgkmcnt(0)                                       // 000000076404: BF89FC07
	v_cvt_f16_f32_e32 v58, v58                                 // 000000076408: 7E74153A
	v_cvt_f16_f32_e32 v59, v59                                 // 00000007640C: 7E76153B
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076410: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076414: 7E3C171E
	v_cvt_f32_f16_e32 v31, v31                                 // 000000076418: 7E3E171F
	v_cvt_f32_f16_e32 v32, v32                                 // 00000007641C: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 000000076420: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 000000076424: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 000000076428: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 00000007642C: 7E76173B
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000076430: 327A7884
	.long 0xd4490001                                           // 000000076434: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000076438: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076440: BF870002
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000076444: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000076448: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000076454: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v68                          // 000000076458: 4A7E88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000076460: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000076468: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 000000076470: 4A8888FF 00003E00
	ds_load_b32 v69, v61                                       // 000000076478: D8D80000 4500003D
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000076480: D8DCC342 40000040
	ds_load_2addr_b32 v[62:63], v63 offset0:64 offset1:193     // 000000076488: D8DCC140 3E00003F
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000076490: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000076498: BF89FC27
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007649C: 7E801540
	s_waitcnt lgkmcnt(1)                                       // 0000000764A0: BF89FC17
	v_cvt_f16_f32_e32 v62, v62                                 // 0000000764A4: 7E7C153E
	v_cvt_f16_f32_e32 v70, v63                                 // 0000000764A8: 7E8C153F
	v_cvt_f16_f32_e32 v65, v65                                 // 0000000764AC: 7E821541
	s_waitcnt lgkmcnt(0)                                       // 0000000764B0: BF89FC07
	v_cvt_f16_f32_e32 v66, v66                                 // 0000000764B4: 7E841542
	v_fma_mix_f32 v69, v62, v29, v69 op_sel_hi:[1,0,0]         // 0000000764B8: CC200045 0D163B3E
	ds_load_2addr_b32 v[62:63], v68 offset0:70 offset1:199     // 0000000764C0: D8DCC746 3E000044
	v_fma_mix_f32 v68, v70, v30, v69 op_sel_hi:[1,0,0]         // 0000000764C8: CC200044 0D163D46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000764D0: BF870091
	v_fma_mix_f32 v64, v64, v31, v68 op_sel_hi:[1,0,0]         // 0000000764D4: CC200040 0D123F40
	v_fma_mix_f32 v64, v65, v32, v64 op_sel_hi:[1,0,0]         // 0000000764DC: CC200040 0D024141
	v_cvt_f16_f32_e32 v65, v67                                 // 0000000764E4: 7E821543
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000764E8: BF8701C2
	v_fma_mix_f32 v64, v66, v33, v64 op_sel_hi:[1,0,0]         // 0000000764EC: CC200040 0D024342
	s_waitcnt lgkmcnt(0)                                       // 0000000764F4: BF89FC07
	v_cvt_f16_f32_e32 v62, v62                                 // 0000000764F8: 7E7C153E
	v_cvt_f16_f32_e32 v63, v63                                 // 0000000764FC: 7E7E153F
	v_fma_mix_f32 v64, v65, v34, v64 op_sel_hi:[1,0,0]         // 000000076500: CC200040 0D024541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076508: BF870121
	v_fma_mix_f32 v62, v62, v58, v64 op_sel_hi:[1,0,0]         // 00000007650C: CC20003E 0D02753E
	v_add_nc_u32_e32 v64, 0x80, v60                            // 000000076514: 4A8078FF 00000080
	v_fma_mix_f32 v62, v63, v59, v62 op_sel_hi:[1,0,0]         // 00000007651C: CC20003E 0CFA773F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076524: BF870002
	v_mov_b32_e32 v60, v64                                     // 000000076528: 7E780340
	ds_store_b32 v61, v62                                      // 00000007652C: D8340000 00003E3D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000076534: 917E047E
	s_cbranch_execnz 65469                                     // 000000076538: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c30>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007653C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000076540: CA100110 1E1C010F
	v_dual_mov_b32 v31, v38 :: v_dual_mov_b32 v32, 0           // 000000076548: CA100126 1F200080
	v_mov_b32_e32 v33, v36                                     // 000000076550: 7E420324
	s_mov_b32 s6, 0                                            // 000000076554: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000076558: BF89FC07
	s_barrier                                                  // 00000007655C: BFBD0000
	buffer_gl0_inv                                             // 000000076560: E0AC0000 00000000
	s_nop 0                                                    // 000000076568: BF800000
	s_nop 0                                                    // 00000007656C: BF800000
	s_nop 0                                                    // 000000076570: BF800000
	s_nop 0                                                    // 000000076574: BF800000
	s_nop 0                                                    // 000000076578: BF800000
	s_nop 0                                                    // 00000007657C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000076580: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17216                          // 000000076588: D8D84340 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000076590: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000076598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007659C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000765A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000765A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000765B0: BF870004
	.long 0xd4490004                                           // 0000000765B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000765B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000765C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000765C4: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 0000000765C8: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 0000000765CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000765D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000765DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000765E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000765E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000765E8: BF89FC07
	s_barrier                                                  // 0000000765EC: BFBD0000
	buffer_gl0_inv                                             // 0000000765F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000765F8: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 000000076600: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 000000076608: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[58:59], v45 offset0:238 offset1:255    // 000000076610: D8DCFFEE 3A00002D
	v_mov_b32_e32 v60, v0                                      // 000000076618: 7E780300
	s_mov_b32 s4, 0                                            // 00000007661C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 000000076620: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000076624: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 000000076628: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 00000007662C: BF89FC27
	v_cvt_f16_f32_e32 v31, v31                                 // 000000076630: 7E3E151F
	v_cvt_f16_f32_e32 v32, v32                                 // 000000076634: 7E401520
	s_waitcnt lgkmcnt(1)                                       // 000000076638: BF89FC17
	v_cvt_f16_f32_e32 v33, v33                                 // 00000007663C: 7E421521
	v_cvt_f16_f32_e32 v34, v34                                 // 000000076640: 7E441522
	s_waitcnt lgkmcnt(0)                                       // 000000076644: BF89FC07
	v_cvt_f16_f32_e32 v58, v58                                 // 000000076648: 7E74153A
	v_cvt_f16_f32_e32 v59, v59                                 // 00000007664C: 7E76153B
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076650: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076654: 7E3C171E
	v_cvt_f32_f16_e32 v31, v31                                 // 000000076658: 7E3E171F
	v_cvt_f32_f16_e32 v32, v32                                 // 00000007665C: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 000000076660: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 000000076664: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 000000076668: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 00000007666C: 7E76173B
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000076670: 327A7884
	.long 0xd4490001                                           // 000000076674: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000076678: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076680: BF870002
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000076684: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000076688: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000076694: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v68                          // 000000076698: 4A7E88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000766A0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000766A8: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 0000000766B0: 4A8888FF 00003E00
	ds_load_b32 v69, v61                                       // 0000000766B8: D8D80000 4500003D
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000766C0: D8DCC342 40000040
	ds_load_2addr_b32 v[62:63], v63 offset0:64 offset1:193     // 0000000766C8: D8DCC140 3E00003F
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000766D0: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000766D8: BF89FC27
	v_cvt_f16_f32_e32 v64, v64                                 // 0000000766DC: 7E801540
	s_waitcnt lgkmcnt(1)                                       // 0000000766E0: BF89FC17
	v_cvt_f16_f32_e32 v62, v62                                 // 0000000766E4: 7E7C153E
	v_cvt_f16_f32_e32 v70, v63                                 // 0000000766E8: 7E8C153F
	v_cvt_f16_f32_e32 v65, v65                                 // 0000000766EC: 7E821541
	s_waitcnt lgkmcnt(0)                                       // 0000000766F0: BF89FC07
	v_cvt_f16_f32_e32 v66, v66                                 // 0000000766F4: 7E841542
	v_fma_mix_f32 v69, v62, v29, v69 op_sel_hi:[1,0,0]         // 0000000766F8: CC200045 0D163B3E
	ds_load_2addr_b32 v[62:63], v68 offset0:70 offset1:199     // 000000076700: D8DCC746 3E000044
	v_fma_mix_f32 v68, v70, v30, v69 op_sel_hi:[1,0,0]         // 000000076708: CC200044 0D163D46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076710: BF870091
	v_fma_mix_f32 v64, v64, v31, v68 op_sel_hi:[1,0,0]         // 000000076714: CC200040 0D123F40
	v_fma_mix_f32 v64, v65, v32, v64 op_sel_hi:[1,0,0]         // 00000007671C: CC200040 0D024141
	v_cvt_f16_f32_e32 v65, v67                                 // 000000076724: 7E821543
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000076728: BF8701C2
	v_fma_mix_f32 v64, v66, v33, v64 op_sel_hi:[1,0,0]         // 00000007672C: CC200040 0D024342
	s_waitcnt lgkmcnt(0)                                       // 000000076734: BF89FC07
	v_cvt_f16_f32_e32 v62, v62                                 // 000000076738: 7E7C153E
	v_cvt_f16_f32_e32 v63, v63                                 // 00000007673C: 7E7E153F
	v_fma_mix_f32 v64, v65, v34, v64 op_sel_hi:[1,0,0]         // 000000076740: CC200040 0D024541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076748: BF870121
	v_fma_mix_f32 v62, v62, v58, v64 op_sel_hi:[1,0,0]         // 00000007674C: CC20003E 0D02753E
	v_add_nc_u32_e32 v64, 0x80, v60                            // 000000076754: 4A8078FF 00000080
	v_fma_mix_f32 v62, v63, v59, v62 op_sel_hi:[1,0,0]         // 00000007675C: CC20003E 0CFA773F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076764: BF870002
	v_mov_b32_e32 v60, v64                                     // 000000076768: 7E780340
	ds_store_b32 v61, v62                                      // 00000007676C: D8340000 00003E3D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000076774: 917E047E
	s_cbranch_execnz 65469                                     // 000000076778: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e70>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007677C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000076780: CA100112 1E1C0111
	v_dual_mov_b32 v31, v38 :: v_dual_mov_b32 v32, 0           // 000000076788: CA100126 1F200080
	v_mov_b32_e32 v33, v36                                     // 000000076790: 7E420324
	s_mov_b32 s6, 0                                            // 000000076794: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000076798: BF89FC07
	s_barrier                                                  // 00000007679C: BFBD0000
	buffer_gl0_inv                                             // 0000000767A0: E0AC0000 00000000
	s_nop 0                                                    // 0000000767A8: BF800000
	s_nop 0                                                    // 0000000767AC: BF800000
	s_nop 0                                                    // 0000000767B0: BF800000
	s_nop 0                                                    // 0000000767B4: BF800000
	s_nop 0                                                    // 0000000767B8: BF800000
	s_nop 0                                                    // 0000000767BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000767C0: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17248                          // 0000000767C8: D8D84360 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000767D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000767D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000767DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000767E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000767E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000767F0: BF870004
	.long 0xd4490004                                           // 0000000767F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000767F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000076800: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000076804: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 000000076808: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 00000007680C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000076814: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007681C: 917E067E
	s_cbranch_execnz 65511                                     // 000000076820: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000076824: 8C7E067E
	v_add_nc_u32_e32 v31, 0x400, v45                           // 000000076828: 4A3E5AFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000076830: BF89FC07
	s_barrier                                                  // 000000076834: BFBD0000
	buffer_gl0_inv                                             // 000000076838: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 000000076840: BE840080
	ds_load_2addr_b32 v[29:30], v31 offset0:16 offset1:33      // 000000076844: D8DC2110 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:50 offset1:67      // 00000007684C: D8DC4332 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:84 offset1:101     // 000000076854: D8DC6554 3A00001F
	ds_load_2addr_b32 v[60:61], v31 offset0:118 offset1:135    // 00000007685C: D8DC8776 3C00001F
	s_waitcnt lgkmcnt(3)                                       // 000000076864: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000076868: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 00000007686C: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 000000076870: BF89FC27
	v_cvt_f16_f32_e32 v32, v32                                 // 000000076874: 7E401520
	v_cvt_f16_f32_e32 v33, v33                                 // 000000076878: 7E421521
	s_waitcnt lgkmcnt(1)                                       // 00000007687C: BF89FC17
	v_cvt_f16_f32_e32 v34, v58                                 // 000000076880: 7E44153A
	v_cvt_f16_f32_e32 v58, v59                                 // 000000076884: 7E74153B
	s_waitcnt lgkmcnt(0)                                       // 000000076888: BF89FC07
	v_cvt_f16_f32_e32 v59, v60                                 // 00000007688C: 7E76153C
	v_cvt_f16_f32_e32 v60, v61                                 // 000000076890: 7E78153D
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076894: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076898: 7E3C171E
	v_cvt_f32_f16_e32 v32, v32                                 // 00000007689C: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 0000000768A0: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 0000000768A4: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 0000000768A8: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 0000000768AC: 7E76173B
	v_cvt_f32_f16_e32 v60, v60                                 // 0000000768B0: 7E78173C
	v_mov_b32_e32 v61, v0                                      // 0000000768B4: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000768B8: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000768BC: 327C7A84
	.long 0xd4490001                                           // 0000000768C0: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000768C4: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000768CC: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000768D0: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000768DC: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v69                          // 0000000768E0: 4A808AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000768E8: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000768F0: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000768F8: 4A8A8AFF 00003E00
	ds_load_b32 v70, v62                                       // 000000076900: D8D80000 4600003E
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000076908: D8DCC342 41000041
	ds_load_2addr_b32 v[63:64], v64 offset0:64 offset1:193     // 000000076910: D8DCC140 3F000040
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000076918: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000076920: BF89FC27
	v_cvt_f16_f32_e32 v65, v65                                 // 000000076924: 7E821541
	s_waitcnt lgkmcnt(1)                                       // 000000076928: BF89FC17
	v_cvt_f16_f32_e32 v63, v63                                 // 00000007692C: 7E7E153F
	v_cvt_f16_f32_e32 v71, v64                                 // 000000076930: 7E8E1540
	v_cvt_f16_f32_e32 v66, v66                                 // 000000076934: 7E841542
	s_waitcnt lgkmcnt(0)                                       // 000000076938: BF89FC07
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007693C: 7E861543
	v_fma_mix_f32 v70, v63, v29, v70 op_sel_hi:[1,0,0]         // 000000076940: CC200046 0D1A3B3F
	ds_load_2addr_b32 v[63:64], v69 offset0:70 offset1:199     // 000000076948: D8DCC746 3F000045
	v_fma_mix_f32 v69, v71, v30, v70 op_sel_hi:[1,0,0]         // 000000076950: CC200045 0D1A3D47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076958: BF870091
	v_fma_mix_f32 v65, v65, v32, v69 op_sel_hi:[1,0,0]         // 00000007695C: CC200041 0D164141
	v_fma_mix_f32 v65, v66, v33, v65 op_sel_hi:[1,0,0]         // 000000076964: CC200041 0D064342
	v_cvt_f16_f32_e32 v66, v68                                 // 00000007696C: 7E841544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000076970: BF8701C2
	v_fma_mix_f32 v65, v67, v34, v65 op_sel_hi:[1,0,0]         // 000000076974: CC200041 0D064543
	s_waitcnt lgkmcnt(0)                                       // 00000007697C: BF89FC07
	v_cvt_f16_f32_e32 v63, v63                                 // 000000076980: 7E7E153F
	v_cvt_f16_f32_e32 v64, v64                                 // 000000076984: 7E801540
	v_fma_mix_f32 v65, v66, v58, v65 op_sel_hi:[1,0,0]         // 000000076988: CC200041 0D067542
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076990: BF870121
	v_fma_mix_f32 v63, v63, v59, v65 op_sel_hi:[1,0,0]         // 000000076994: CC20003F 0D06773F
	v_add_nc_u32_e32 v65, 0x80, v61                            // 00000007699C: 4A827AFF 00000080
	v_fma_mix_f32 v63, v64, v60, v63 op_sel_hi:[1,0,0]         // 0000000769A4: CC20003F 0CFE7940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000769AC: BF870002
	v_mov_b32_e32 v61, v65                                     // 0000000769B0: 7E7A0341
	ds_store_b32 v62, v63                                      // 0000000769B4: D8340000 00003F3E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000769BC: 917E047E
	s_cbranch_execnz 65469                                     // 0000000769C0: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20b8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000769C4: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000769C8: CA100114 1E1C0113
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v33, 0           // 0000000769D0: CA100126 20200080
	v_mov_b32_e32 v34, v36                                     // 0000000769D8: 7E440324
	s_mov_b32 s6, 0                                            // 0000000769DC: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000769E0: BF89FC07
	s_barrier                                                  // 0000000769E4: BFBD0000
	buffer_gl0_inv                                             // 0000000769E8: E0AC0000 00000000
	s_nop 0                                                    // 0000000769F0: BF800000
	s_nop 0                                                    // 0000000769F4: BF800000
	s_nop 0                                                    // 0000000769F8: BF800000
	s_nop 0                                                    // 0000000769FC: BF800000
	global_load_b32 v58, v[29:30], off                         // 000000076A00: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17280                          // 000000076A08: D8D84380 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000076A10: 4A4444FF 00000080
	.long 0xd700011d                                           // 000000076A18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000076A1C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 000000076A24: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000076A28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000076A30: BF870004
	.long 0xd4490004                                           // 000000076A34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000076A38: 020244FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000076A40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000076A44: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 000000076A48: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 000000076A4C: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000076A54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000076A5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000076A60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000076A64: 8C7E067E
	v_add_nc_u32_e32 v34, 0x600, v45                           // 000000076A68: 4A445AFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000076A70: BF89FC07
	s_barrier                                                  // 000000076A74: BFBD0000
	buffer_gl0_inv                                             // 000000076A78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:152 offset1:169    // 000000076A80: D8DCA998 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:186 offset1:203    // 000000076A88: D8DCCBBA 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:220 offset1:237    // 000000076A90: D8DCEDDC 3A00001F
	ds_load_2addr_b32 v[60:61], v34 offset0:126 offset1:143    // 000000076A98: D8DC8F7E 3C000022
	s_mov_b32 s4, 0                                            // 000000076AA0: BE840080
	s_waitcnt lgkmcnt(3)                                       // 000000076AA4: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000076AA8: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 000000076AAC: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 000000076AB0: BF89FC27
	v_cvt_f16_f32_e32 v31, v32                                 // 000000076AB4: 7E3E1520
	v_cvt_f16_f32_e32 v32, v33                                 // 000000076AB8: 7E401521
	s_waitcnt lgkmcnt(1)                                       // 000000076ABC: BF89FC17
	v_cvt_f16_f32_e32 v33, v58                                 // 000000076AC0: 7E42153A
	v_cvt_f16_f32_e32 v34, v59                                 // 000000076AC4: 7E44153B
	s_waitcnt lgkmcnt(0)                                       // 000000076AC8: BF89FC07
	v_cvt_f16_f32_e32 v58, v60                                 // 000000076ACC: 7E74153C
	v_cvt_f16_f32_e32 v59, v61                                 // 000000076AD0: 7E76153D
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076AD4: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076AD8: 7E3C171E
	v_cvt_f32_f16_e32 v31, v31                                 // 000000076ADC: 7E3E171F
	v_cvt_f32_f16_e32 v32, v32                                 // 000000076AE0: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 000000076AE4: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 000000076AE8: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 000000076AEC: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 000000076AF0: 7E76173B
	v_mov_b32_e32 v60, v0                                      // 000000076AF4: 7E780300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076AF8: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000076AFC: 327A7884
	.long 0xd4490001                                           // 000000076B00: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000076B04: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000076B0C: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000076B10: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000076B1C: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v68                          // 000000076B20: 4A7E88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000076B28: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000076B30: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 000000076B38: 4A8888FF 00003E00
	ds_load_b32 v69, v61                                       // 000000076B40: D8D80000 4500003D
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000076B48: D8DCC342 40000040
	ds_load_2addr_b32 v[62:63], v63 offset0:64 offset1:193     // 000000076B50: D8DCC140 3E00003F
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000076B58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000076B60: BF89FC27
	v_cvt_f16_f32_e32 v64, v64                                 // 000000076B64: 7E801540
	s_waitcnt lgkmcnt(1)                                       // 000000076B68: BF89FC17
	v_cvt_f16_f32_e32 v62, v62                                 // 000000076B6C: 7E7C153E
	v_cvt_f16_f32_e32 v70, v63                                 // 000000076B70: 7E8C153F
	v_cvt_f16_f32_e32 v65, v65                                 // 000000076B74: 7E821541
	s_waitcnt lgkmcnt(0)                                       // 000000076B78: BF89FC07
	v_cvt_f16_f32_e32 v66, v66                                 // 000000076B7C: 7E841542
	v_fma_mix_f32 v69, v62, v29, v69 op_sel_hi:[1,0,0]         // 000000076B80: CC200045 0D163B3E
	ds_load_2addr_b32 v[62:63], v68 offset0:70 offset1:199     // 000000076B88: D8DCC746 3E000044
	v_fma_mix_f32 v68, v70, v30, v69 op_sel_hi:[1,0,0]         // 000000076B90: CC200044 0D163D46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076B98: BF870091
	v_fma_mix_f32 v64, v64, v31, v68 op_sel_hi:[1,0,0]         // 000000076B9C: CC200040 0D123F40
	v_fma_mix_f32 v64, v65, v32, v64 op_sel_hi:[1,0,0]         // 000000076BA4: CC200040 0D024141
	v_cvt_f16_f32_e32 v65, v67                                 // 000000076BAC: 7E821543
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000076BB0: BF8701C2
	v_fma_mix_f32 v64, v66, v33, v64 op_sel_hi:[1,0,0]         // 000000076BB4: CC200040 0D024342
	s_waitcnt lgkmcnt(0)                                       // 000000076BBC: BF89FC07
	v_cvt_f16_f32_e32 v62, v62                                 // 000000076BC0: 7E7C153E
	v_cvt_f16_f32_e32 v63, v63                                 // 000000076BC4: 7E7E153F
	v_fma_mix_f32 v64, v65, v34, v64 op_sel_hi:[1,0,0]         // 000000076BC8: CC200040 0D024541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076BD0: BF870121
	v_fma_mix_f32 v62, v62, v58, v64 op_sel_hi:[1,0,0]         // 000000076BD4: CC20003E 0D02753E
	v_add_nc_u32_e32 v64, 0x80, v60                            // 000000076BDC: 4A8078FF 00000080
	v_fma_mix_f32 v62, v63, v59, v62 op_sel_hi:[1,0,0]         // 000000076BE4: CC20003E 0CFA773F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076BEC: BF870002
	v_mov_b32_e32 v60, v64                                     // 000000076BF0: 7E780340
	ds_store_b32 v61, v62                                      // 000000076BF4: D8340000 00003E3D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000076BFC: 917E047E
	s_cbranch_execnz 65469                                     // 000000076C00: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22f8>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000076C04: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000076C08: CA100116 1E1C0115
	v_dual_mov_b32 v31, v38 :: v_dual_mov_b32 v32, 0           // 000000076C10: CA100126 1F200080
	v_mov_b32_e32 v33, v36                                     // 000000076C18: 7E420324
	s_mov_b32 s6, 0                                            // 000000076C1C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000076C20: BF89FC07
	s_barrier                                                  // 000000076C24: BFBD0000
	buffer_gl0_inv                                             // 000000076C28: E0AC0000 00000000
	s_nop 0                                                    // 000000076C30: BF800000
	s_nop 0                                                    // 000000076C34: BF800000
	s_nop 0                                                    // 000000076C38: BF800000
	s_nop 0                                                    // 000000076C3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000076C40: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17312                          // 000000076C48: D8D843A0 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000076C50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000076C58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000076C5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000076C64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000076C68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000076C70: BF870004
	.long 0xd4490004                                           // 000000076C74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000076C78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000076C80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000076C84: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 000000076C88: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 000000076C8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000076C94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000076C9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000076CA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000076CA4: 8C7E067E
	v_add_nc_u32_e32 v32, 0x800, v45                           // 000000076CA8: 4A405AFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000076CB0: BF89FC07
	s_barrier                                                  // 000000076CB4: BFBD0000
	buffer_gl0_inv                                             // 000000076CB8: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 000000076CC0: BE840080
	ds_load_2addr_b32 v[29:30], v32 offset0:32 offset1:49      // 000000076CC4: D8DC3120 1D000020
	ds_load_2addr_b32 v[33:34], v32 offset0:66 offset1:83      // 000000076CCC: D8DC5342 21000020
	ds_load_2addr_b32 v[58:59], v32 offset0:100 offset1:117    // 000000076CD4: D8DC7564 3A000020
	ds_load_2addr_b32 v[60:61], v32 offset0:134 offset1:151    // 000000076CDC: D8DC9786 3C000020
	s_waitcnt lgkmcnt(3)                                       // 000000076CE4: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000076CE8: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 000000076CEC: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 000000076CF0: BF89FC27
	v_cvt_f16_f32_e32 v31, v33                                 // 000000076CF4: 7E3E1521
	v_cvt_f16_f32_e32 v33, v34                                 // 000000076CF8: 7E421522
	s_waitcnt lgkmcnt(1)                                       // 000000076CFC: BF89FC17
	v_cvt_f16_f32_e32 v34, v58                                 // 000000076D00: 7E44153A
	v_cvt_f16_f32_e32 v58, v59                                 // 000000076D04: 7E74153B
	s_waitcnt lgkmcnt(0)                                       // 000000076D08: BF89FC07
	v_cvt_f16_f32_e32 v59, v60                                 // 000000076D0C: 7E76153C
	v_cvt_f16_f32_e32 v60, v61                                 // 000000076D10: 7E78153D
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076D14: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076D18: 7E3C171E
	v_cvt_f32_f16_e32 v31, v31                                 // 000000076D1C: 7E3E171F
	v_cvt_f32_f16_e32 v33, v33                                 // 000000076D20: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 000000076D24: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 000000076D28: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 000000076D2C: 7E76173B
	v_cvt_f32_f16_e32 v60, v60                                 // 000000076D30: 7E78173C
	v_mov_b32_e32 v61, v0                                      // 000000076D34: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076D38: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000076D3C: 327C7A84
	.long 0xd4490001                                           // 000000076D40: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000076D44: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000076D4C: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000076D50: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000076D5C: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v69                          // 000000076D60: 4A808AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000076D68: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000076D70: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 000000076D78: 4A8A8AFF 00003E00
	ds_load_b32 v70, v62                                       // 000000076D80: D8D80000 4600003E
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000076D88: D8DCC342 41000041
	ds_load_2addr_b32 v[63:64], v64 offset0:64 offset1:193     // 000000076D90: D8DCC140 3F000040
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000076D98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000076DA0: BF89FC27
	v_cvt_f16_f32_e32 v65, v65                                 // 000000076DA4: 7E821541
	s_waitcnt lgkmcnt(1)                                       // 000000076DA8: BF89FC17
	v_cvt_f16_f32_e32 v63, v63                                 // 000000076DAC: 7E7E153F
	v_cvt_f16_f32_e32 v71, v64                                 // 000000076DB0: 7E8E1540
	v_cvt_f16_f32_e32 v66, v66                                 // 000000076DB4: 7E841542
	s_waitcnt lgkmcnt(0)                                       // 000000076DB8: BF89FC07
	v_cvt_f16_f32_e32 v67, v67                                 // 000000076DBC: 7E861543
	v_fma_mix_f32 v70, v63, v29, v70 op_sel_hi:[1,0,0]         // 000000076DC0: CC200046 0D1A3B3F
	ds_load_2addr_b32 v[63:64], v69 offset0:70 offset1:199     // 000000076DC8: D8DCC746 3F000045
	v_fma_mix_f32 v69, v71, v30, v70 op_sel_hi:[1,0,0]         // 000000076DD0: CC200045 0D1A3D47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076DD8: BF870091
	v_fma_mix_f32 v65, v65, v31, v69 op_sel_hi:[1,0,0]         // 000000076DDC: CC200041 0D163F41
	v_fma_mix_f32 v65, v66, v33, v65 op_sel_hi:[1,0,0]         // 000000076DE4: CC200041 0D064342
	v_cvt_f16_f32_e32 v66, v68                                 // 000000076DEC: 7E841544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000076DF0: BF8701C2
	v_fma_mix_f32 v65, v67, v34, v65 op_sel_hi:[1,0,0]         // 000000076DF4: CC200041 0D064543
	s_waitcnt lgkmcnt(0)                                       // 000000076DFC: BF89FC07
	v_cvt_f16_f32_e32 v63, v63                                 // 000000076E00: 7E7E153F
	v_cvt_f16_f32_e32 v64, v64                                 // 000000076E04: 7E801540
	v_fma_mix_f32 v65, v66, v58, v65 op_sel_hi:[1,0,0]         // 000000076E08: CC200041 0D067542
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076E10: BF870121
	v_fma_mix_f32 v63, v63, v59, v65 op_sel_hi:[1,0,0]         // 000000076E14: CC20003F 0D06773F
	v_add_nc_u32_e32 v65, 0x80, v61                            // 000000076E1C: 4A827AFF 00000080
	v_fma_mix_f32 v63, v64, v60, v63 op_sel_hi:[1,0,0]         // 000000076E24: CC20003F 0CFE7940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000076E2C: BF870002
	v_mov_b32_e32 v61, v65                                     // 000000076E30: 7E7A0341
	ds_store_b32 v62, v63                                      // 000000076E34: D8340000 00003F3E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000076E3C: 917E047E
	s_cbranch_execnz 65469                                     // 000000076E40: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2538>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000076E44: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000076E48: CA100118 1E1C0117
	v_mov_b32_e32 v31, v38                                     // 000000076E50: 7E3E0326
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 000000076E54: CA100080 21220124
	s_mov_b32 s6, 0                                            // 000000076E5C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000076E60: BF89FC07
	s_barrier                                                  // 000000076E64: BFBD0000
	buffer_gl0_inv                                             // 000000076E68: E0AC0000 00000000
	s_nop 0                                                    // 000000076E70: BF800000
	s_nop 0                                                    // 000000076E74: BF800000
	s_nop 0                                                    // 000000076E78: BF800000
	s_nop 0                                                    // 000000076E7C: BF800000
	global_load_b32 v58, v[29:30], off                         // 000000076E80: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17344                          // 000000076E88: D8D843C0 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000076E90: 4A4444FF 00000080
	.long 0xd700011d                                           // 000000076E98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000076E9C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 000000076EA4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000076EA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000076EB0: BF870004
	.long 0xd4490004                                           // 000000076EB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000076EB8: 020244FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000076EC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000076EC4: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 000000076EC8: 1074773A
	ds_store_b32 v31, v58 offset:13056                         // 000000076ECC: D8343300 00003A1F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000076ED4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000076EDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000076EE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2680>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000076EE4: 8C7E067E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 000000076EE8: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000076EF0: BF89FC07
	s_barrier                                                  // 000000076EF4: BFBD0000
	buffer_gl0_inv                                             // 000000076EF8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v32 offset0:168 offset1:185    // 000000076F00: D8DCB9A8 1D000020
	ds_load_2addr_b32 v[33:34], v32 offset0:202 offset1:219    // 000000076F08: D8DCDBCA 21000020
	ds_load_2addr_b32 v[58:59], v32 offset0:236 offset1:253    // 000000076F10: D8DCFDEC 3A000020
	ds_load_2addr_b32 v[60:61], v31 offset0:14 offset1:31      // 000000076F18: D8DC1F0E 3C00001F
	s_mov_b32 s4, 0                                            // 000000076F20: BE840080
	s_waitcnt lgkmcnt(3)                                       // 000000076F24: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000076F28: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 000000076F2C: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 000000076F30: BF89FC27
	v_cvt_f16_f32_e32 v32, v33                                 // 000000076F34: 7E401521
	v_cvt_f16_f32_e32 v33, v34                                 // 000000076F38: 7E421522
	s_waitcnt lgkmcnt(1)                                       // 000000076F3C: BF89FC17
	v_cvt_f16_f32_e32 v34, v58                                 // 000000076F40: 7E44153A
	v_cvt_f16_f32_e32 v58, v59                                 // 000000076F44: 7E74153B
	s_waitcnt lgkmcnt(0)                                       // 000000076F48: BF89FC07
	v_cvt_f16_f32_e32 v59, v60                                 // 000000076F4C: 7E76153C
	v_cvt_f16_f32_e32 v60, v61                                 // 000000076F50: 7E78153D
	v_cvt_f32_f16_e32 v29, v29                                 // 000000076F54: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000076F58: 7E3C171E
	v_cvt_f32_f16_e32 v32, v32                                 // 000000076F5C: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 000000076F60: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 000000076F64: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 000000076F68: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 000000076F6C: 7E76173B
	v_cvt_f32_f16_e32 v60, v60                                 // 000000076F70: 7E78173C
	v_mov_b32_e32 v61, v0                                      // 000000076F74: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076F78: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000076F7C: 327C7A84
	.long 0xd4490001                                           // 000000076F80: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000076F84: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000076F8C: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000076F90: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000076F9C: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v69                          // 000000076FA0: 4A808AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000076FA8: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000076FB0: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 000000076FB8: 4A8A8AFF 00003E00
	ds_load_b32 v70, v62                                       // 000000076FC0: D8D80000 4600003E
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000076FC8: D8DCC342 41000041
	ds_load_2addr_b32 v[63:64], v64 offset0:64 offset1:193     // 000000076FD0: D8DCC140 3F000040
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000076FD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000076FE0: BF89FC27
	v_cvt_f16_f32_e32 v65, v65                                 // 000000076FE4: 7E821541
	s_waitcnt lgkmcnt(1)                                       // 000000076FE8: BF89FC17
	v_cvt_f16_f32_e32 v63, v63                                 // 000000076FEC: 7E7E153F
	v_cvt_f16_f32_e32 v71, v64                                 // 000000076FF0: 7E8E1540
	v_cvt_f16_f32_e32 v66, v66                                 // 000000076FF4: 7E841542
	s_waitcnt lgkmcnt(0)                                       // 000000076FF8: BF89FC07
	v_cvt_f16_f32_e32 v67, v67                                 // 000000076FFC: 7E861543
	v_fma_mix_f32 v70, v63, v29, v70 op_sel_hi:[1,0,0]         // 000000077000: CC200046 0D1A3B3F
	ds_load_2addr_b32 v[63:64], v69 offset0:70 offset1:199     // 000000077008: D8DCC746 3F000045
	v_fma_mix_f32 v69, v71, v30, v70 op_sel_hi:[1,0,0]         // 000000077010: CC200045 0D1A3D47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077018: BF870091
	v_fma_mix_f32 v65, v65, v32, v69 op_sel_hi:[1,0,0]         // 00000007701C: CC200041 0D164141
	v_fma_mix_f32 v65, v66, v33, v65 op_sel_hi:[1,0,0]         // 000000077024: CC200041 0D064342
	v_cvt_f16_f32_e32 v66, v68                                 // 00000007702C: 7E841544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077030: BF8701C2
	v_fma_mix_f32 v65, v67, v34, v65 op_sel_hi:[1,0,0]         // 000000077034: CC200041 0D064543
	s_waitcnt lgkmcnt(0)                                       // 00000007703C: BF89FC07
	v_cvt_f16_f32_e32 v63, v63                                 // 000000077040: 7E7E153F
	v_cvt_f16_f32_e32 v64, v64                                 // 000000077044: 7E801540
	v_fma_mix_f32 v65, v66, v58, v65 op_sel_hi:[1,0,0]         // 000000077048: CC200041 0D067542
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077050: BF870121
	v_fma_mix_f32 v63, v63, v59, v65 op_sel_hi:[1,0,0]         // 000000077054: CC20003F 0D06773F
	v_add_nc_u32_e32 v65, 0x80, v61                            // 00000007705C: 4A827AFF 00000080
	v_fma_mix_f32 v63, v64, v60, v63 op_sel_hi:[1,0,0]         // 000000077064: CC20003F 0CFE7940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007706C: BF870002
	v_mov_b32_e32 v61, v65                                     // 000000077070: 7E7A0341
	ds_store_b32 v62, v63                                      // 000000077074: D8340000 00003F3E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007707C: 917E047E
	s_cbranch_execnz 65469                                     // 000000077080: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2778>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000077084: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000077088: CA10011A 1E1C0119
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v33, 0           // 000000077090: CA100126 20200080
	v_mov_b32_e32 v34, v36                                     // 000000077098: 7E440324
	s_mov_b32 s6, 0                                            // 00000007709C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000770A0: BF89FC07
	s_barrier                                                  // 0000000770A4: BFBD0000
	buffer_gl0_inv                                             // 0000000770A8: E0AC0000 00000000
	s_nop 0                                                    // 0000000770B0: BF800000
	s_nop 0                                                    // 0000000770B4: BF800000
	s_nop 0                                                    // 0000000770B8: BF800000
	s_nop 0                                                    // 0000000770BC: BF800000
	global_load_b32 v58, v[29:30], off                         // 0000000770C0: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17376                          // 0000000770C8: D8D843E0 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000770D0: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000770D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000770DC: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000770E4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000770E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000770F0: BF870004
	.long 0xd4490004                                           // 0000000770F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000770F8: 020244FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000077100: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000077104: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 000000077108: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 00000007710C: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000077114: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007711C: 917E067E
	s_cbranch_execnz 65511                                     // 000000077120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000077124: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000077128: BF89FC07
	s_barrier                                                  // 00000007712C: BFBD0000
	buffer_gl0_inv                                             // 000000077130: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 000000077138: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 000000077140: D8DC6352 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:116 offset1:133    // 000000077148: D8DC8574 3A00001F
	ds_load_2addr_b32 v[60:61], v31 offset0:150 offset1:167    // 000000077150: D8DCA796 3C00001F
	s_mov_b32 s4, 0                                            // 000000077158: BE840080
	s_waitcnt lgkmcnt(3)                                       // 00000007715C: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 000000077160: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 000000077164: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 000000077168: BF89FC27
	v_cvt_f16_f32_e32 v32, v32                                 // 00000007716C: 7E401520
	v_cvt_f16_f32_e32 v33, v33                                 // 000000077170: 7E421521
	s_waitcnt lgkmcnt(1)                                       // 000000077174: BF89FC17
	v_cvt_f16_f32_e32 v34, v58                                 // 000000077178: 7E44153A
	v_cvt_f16_f32_e32 v58, v59                                 // 00000007717C: 7E74153B
	s_waitcnt lgkmcnt(0)                                       // 000000077180: BF89FC07
	v_cvt_f16_f32_e32 v59, v60                                 // 000000077184: 7E76153C
	v_cvt_f16_f32_e32 v60, v61                                 // 000000077188: 7E78153D
	v_cvt_f32_f16_e32 v29, v29                                 // 00000007718C: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 000000077190: 7E3C171E
	v_cvt_f32_f16_e32 v32, v32                                 // 000000077194: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 000000077198: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 00000007719C: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 0000000771A0: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 0000000771A4: 7E76173B
	v_cvt_f32_f16_e32 v60, v60                                 // 0000000771A8: 7E78173C
	v_mov_b32_e32 v61, v0                                      // 0000000771AC: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000771B0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000771B4: 327C7A84
	.long 0xd4490001                                           // 0000000771B8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000771BC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000771C4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000771C8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000771D4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v69                          // 0000000771D8: 4A808AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000771E0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000771E8: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000771F0: 4A8A8AFF 00003E00
	ds_load_b32 v70, v62                                       // 0000000771F8: D8D80000 4600003E
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000077200: D8DCC342 41000041
	ds_load_2addr_b32 v[63:64], v64 offset0:64 offset1:193     // 000000077208: D8DCC140 3F000040
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000077210: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000077218: BF89FC27
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007721C: 7E821541
	s_waitcnt lgkmcnt(1)                                       // 000000077220: BF89FC17
	v_cvt_f16_f32_e32 v63, v63                                 // 000000077224: 7E7E153F
	v_cvt_f16_f32_e32 v71, v64                                 // 000000077228: 7E8E1540
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007722C: 7E841542
	s_waitcnt lgkmcnt(0)                                       // 000000077230: BF89FC07
	v_cvt_f16_f32_e32 v67, v67                                 // 000000077234: 7E861543
	v_fma_mix_f32 v70, v63, v29, v70 op_sel_hi:[1,0,0]         // 000000077238: CC200046 0D1A3B3F
	ds_load_2addr_b32 v[63:64], v69 offset0:70 offset1:199     // 000000077240: D8DCC746 3F000045
	v_fma_mix_f32 v69, v71, v30, v70 op_sel_hi:[1,0,0]         // 000000077248: CC200045 0D1A3D47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077250: BF870091
	v_fma_mix_f32 v65, v65, v32, v69 op_sel_hi:[1,0,0]         // 000000077254: CC200041 0D164141
	v_fma_mix_f32 v65, v66, v33, v65 op_sel_hi:[1,0,0]         // 00000007725C: CC200041 0D064342
	v_cvt_f16_f32_e32 v66, v68                                 // 000000077264: 7E841544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077268: BF8701C2
	v_fma_mix_f32 v65, v67, v34, v65 op_sel_hi:[1,0,0]         // 00000007726C: CC200041 0D064543
	s_waitcnt lgkmcnt(0)                                       // 000000077274: BF89FC07
	v_cvt_f16_f32_e32 v63, v63                                 // 000000077278: 7E7E153F
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007727C: 7E801540
	v_fma_mix_f32 v65, v66, v58, v65 op_sel_hi:[1,0,0]         // 000000077280: CC200041 0D067542
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077288: BF870121
	v_fma_mix_f32 v63, v63, v59, v65 op_sel_hi:[1,0,0]         // 00000007728C: CC20003F 0D06773F
	v_add_nc_u32_e32 v65, 0x80, v61                            // 000000077294: 4A827AFF 00000080
	v_fma_mix_f32 v63, v64, v60, v63 op_sel_hi:[1,0,0]         // 00000007729C: CC20003F 0CFE7940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000772A4: BF870002
	v_mov_b32_e32 v61, v65                                     // 0000000772A8: 7E7A0341
	ds_store_b32 v62, v63                                      // 0000000772AC: D8340000 00003F3E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000772B4: 917E047E
	s_cbranch_execnz 65469                                     // 0000000772B8: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000772BC: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000772C0: CA10011C 1E1C011B
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v33, 0           // 0000000772C8: CA100126 20200080
	v_mov_b32_e32 v34, v36                                     // 0000000772D0: 7E440324
	s_mov_b32 s6, 0                                            // 0000000772D4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000772D8: BF89FC07
	s_barrier                                                  // 0000000772DC: BFBD0000
	buffer_gl0_inv                                             // 0000000772E0: E0AC0000 00000000
	s_nop 0                                                    // 0000000772E8: BF800000
	s_nop 0                                                    // 0000000772EC: BF800000
	s_nop 0                                                    // 0000000772F0: BF800000
	s_nop 0                                                    // 0000000772F4: BF800000
	s_nop 0                                                    // 0000000772F8: BF800000
	s_nop 0                                                    // 0000000772FC: BF800000
	global_load_b32 v58, v[29:30], off                         // 000000077300: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17408                          // 000000077308: D8D84400 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000077310: 4A4444FF 00000080
	.long 0xd700011d                                           // 000000077318: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007731C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 000000077324: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000077328: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000077330: BF870004
	.long 0xd4490004                                           // 000000077334: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000077338: 020244FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000077340: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000077344: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 000000077348: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 00000007734C: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000077354: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007735C: 917E067E
	s_cbranch_execnz 65511                                     // 000000077360: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000077364: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 000000077368: 4A425AFF 00000E00
	v_add_nc_u32_e32 v58, 0x1000, v45                          // 000000077370: 4A745AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000077378: BF89FC07
	s_barrier                                                  // 00000007737C: BFBD0000
	buffer_gl0_inv                                             // 000000077380: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 000000077388: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 000000077390: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000077398: D8DC8D7C 21000021
	ds_load_2addr_b32 v[58:59], v58 offset0:30 offset1:47      // 0000000773A0: D8DC2F1E 3A00003A
	v_mov_b32_e32 v60, v0                                      // 0000000773A8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000773AC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000773B0: BF89FC37
	v_cvt_f16_f32_e32 v29, v29                                 // 0000000773B4: 7E3A151D
	v_cvt_f16_f32_e32 v30, v30                                 // 0000000773B8: 7E3C151E
	s_waitcnt lgkmcnt(2)                                       // 0000000773BC: BF89FC27
	v_cvt_f16_f32_e32 v31, v31                                 // 0000000773C0: 7E3E151F
	v_cvt_f16_f32_e32 v32, v32                                 // 0000000773C4: 7E401520
	s_waitcnt lgkmcnt(1)                                       // 0000000773C8: BF89FC17
	v_cvt_f16_f32_e32 v33, v33                                 // 0000000773CC: 7E421521
	v_cvt_f16_f32_e32 v34, v34                                 // 0000000773D0: 7E441522
	s_waitcnt lgkmcnt(0)                                       // 0000000773D4: BF89FC07
	v_cvt_f16_f32_e32 v58, v58                                 // 0000000773D8: 7E74153A
	v_cvt_f16_f32_e32 v59, v59                                 // 0000000773DC: 7E76153B
	v_cvt_f32_f16_e32 v29, v29                                 // 0000000773E0: 7E3A171D
	v_cvt_f32_f16_e32 v30, v30                                 // 0000000773E4: 7E3C171E
	v_cvt_f32_f16_e32 v31, v31                                 // 0000000773E8: 7E3E171F
	v_cvt_f32_f16_e32 v32, v32                                 // 0000000773EC: 7E401720
	v_cvt_f32_f16_e32 v33, v33                                 // 0000000773F0: 7E421721
	v_cvt_f32_f16_e32 v34, v34                                 // 0000000773F4: 7E441722
	v_cvt_f32_f16_e32 v58, v58                                 // 0000000773F8: 7E74173A
	v_cvt_f32_f16_e32 v59, v59                                 // 0000000773FC: 7E76173B
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000077400: 327A7884
	.long 0xd4490001                                           // 000000077404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000077408: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000077410: BF870002
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000077414: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000077418: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000077424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v68                          // 000000077428: 4A7E88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000077430: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000077438: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 000000077440: 4A8888FF 00003E00
	ds_load_b32 v69, v61                                       // 000000077448: D8D80000 4500003D
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000077450: D8DCC342 40000040
	ds_load_2addr_b32 v[62:63], v63 offset0:64 offset1:193     // 000000077458: D8DCC140 3E00003F
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000077460: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000077468: BF89FC27
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007746C: 7E801540
	s_waitcnt lgkmcnt(1)                                       // 000000077470: BF89FC17
	v_cvt_f16_f32_e32 v62, v62                                 // 000000077474: 7E7C153E
	v_cvt_f16_f32_e32 v70, v63                                 // 000000077478: 7E8C153F
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007747C: 7E821541
	s_waitcnt lgkmcnt(0)                                       // 000000077480: BF89FC07
	v_cvt_f16_f32_e32 v66, v66                                 // 000000077484: 7E841542
	v_fma_mix_f32 v69, v62, v29, v69 op_sel_hi:[1,0,0]         // 000000077488: CC200045 0D163B3E
	ds_load_2addr_b32 v[62:63], v68 offset0:70 offset1:199     // 000000077490: D8DCC746 3E000044
	v_fma_mix_f32 v68, v70, v30, v69 op_sel_hi:[1,0,0]         // 000000077498: CC200044 0D163D46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000774A0: BF870091
	v_fma_mix_f32 v64, v64, v31, v68 op_sel_hi:[1,0,0]         // 0000000774A4: CC200040 0D123F40
	v_fma_mix_f32 v64, v65, v32, v64 op_sel_hi:[1,0,0]         // 0000000774AC: CC200040 0D024141
	v_cvt_f16_f32_e32 v65, v67                                 // 0000000774B4: 7E821543
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000774B8: BF8701C2
	v_fma_mix_f32 v64, v66, v33, v64 op_sel_hi:[1,0,0]         // 0000000774BC: CC200040 0D024342
	s_waitcnt lgkmcnt(0)                                       // 0000000774C4: BF89FC07
	v_cvt_f16_f32_e32 v62, v62                                 // 0000000774C8: 7E7C153E
	v_cvt_f16_f32_e32 v63, v63                                 // 0000000774CC: 7E7E153F
	v_fma_mix_f32 v64, v65, v34, v64 op_sel_hi:[1,0,0]         // 0000000774D0: CC200040 0D024541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000774D8: BF870121
	v_fma_mix_f32 v62, v62, v58, v64 op_sel_hi:[1,0,0]         // 0000000774DC: CC20003E 0D02753E
	v_add_nc_u32_e32 v64, 0x80, v60                            // 0000000774E4: 4A8078FF 00000080
	v_fma_mix_f32 v62, v63, v59, v62 op_sel_hi:[1,0,0]         // 0000000774EC: CC20003E 0CFA773F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000774F4: BF870002
	v_mov_b32_e32 v60, v64                                     // 0000000774F8: 7E780340
	ds_store_b32 v61, v62                                      // 0000000774FC: D8340000 00003E3D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000077504: 917E047E
	s_cbranch_execnz 65469                                     // 000000077508: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c00>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007750C: 8C7E047E
	.long 0xd7000107                                           // 000000077510: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000077514: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007751C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000077520: D5207C08 00061080
	.long 0xd7000109                                           // 000000077528: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000007752C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000077534: D5207C0A 00061480
	.long 0xd700010d                                           // 00000007753C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000077540: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077548: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000007754C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000077554: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000077558: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000077560: D5207C0C 00061880
	.long 0xd700010f                                           // 000000077568: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000007756C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077574: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000077578: D5207C10 00062080
	.long 0xd7000111                                           // 000000077580: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000077584: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000007758C: D5207C12 00062480
	.long 0xd7000113                                           // 000000077594: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000077598: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000775A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000775A4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000775AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000775B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000775B8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000775C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000775C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000775CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000775D0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000775D8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000775DC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000775E4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000775EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000775F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000775F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000775FC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000077604: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000077608: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000007760C: BF062105
	s_barrier                                                  // 000000077610: BFBD0000
	buffer_gl0_inv                                             // 000000077614: E0AC0000 00000000
	s_cbranch_scc0 62817                                       // 00000007761C: BFA1F561 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v36                                      // 000000077620: 7E080324
	s_add_u32 s0, s28, s20                                     // 000000077624: 8000141C
	.long 0xd73c0000                                           // 000000077628: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000007762C: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000077630: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000077634: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000077638: 82031319
	s_add_u32 s0, s2, s0                                       // 00000007763C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000077640: 82010103
	.long 0xd7006a00                                           // 000000077644: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000077648: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007764C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000077650: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000077658: BE810080
	.long 0xd7006a00                                           // 00000007765C: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 000000077660: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000077664: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007766C: BF870092
	.long 0xd7006a00                                           // 000000077670: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000077674: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000077678: D5207C01 01AA0211
	ds_load_b32 v2, v35                                        // 000000077680: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000077688: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 000000077690: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000077698: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007769C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000776A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000776A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000776AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000776B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000776B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000776C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000776C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000776CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e80>
	s_endpgm                                                   // 0000000776D0: BFB00000
		...

