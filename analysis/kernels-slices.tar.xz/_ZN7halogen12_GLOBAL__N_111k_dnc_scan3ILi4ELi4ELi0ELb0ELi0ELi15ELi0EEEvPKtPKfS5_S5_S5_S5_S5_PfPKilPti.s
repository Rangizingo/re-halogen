00000000000ffc00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000FFC00: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 0000000FFC04: F4100200 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 0000000FFC0C: F4080100 F8000048
	s_lshl_b32 s28, s3, 5                                      // 0000000FFC14: 841C8503
	s_ashr_i32 s3, s2, 31                                      // 0000000FFC18: 86039F02
	s_ashr_i32 s29, s28, 31                                    // 0000000FFC1C: 861D9F1C
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 31, v0         // 0000000FFC20: CA240100 0404009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FFC28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000FFC2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000FFC30: BF89FC07
	s_load_b32 s26, s[22:23], null                             // 0000000FFC34: F400068B F8000000
	s_lshl_b64 s[22:23], s[4:5], 2                             // 0000000FFC3C: 84968204
	s_add_u32 s4, s20, s22                                     // 0000000FFC40: 80041614
	s_addc_u32 s5, s21, s23                                    // 0000000FFC44: 82051715
	s_lshl_b64 s[24:25], s[2:3], 16                            // 0000000FFC48: 84989002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FFC4C: BF870009
	s_add_u32 s4, s4, s24                                      // 0000000FFC50: 80041804
	s_addc_u32 s5, s5, s25                                     // 0000000FFC54: 82051905
	s_waitcnt lgkmcnt(0)                                       // 0000000FFC58: BF89FC07
	s_mul_i32 s30, s26, 0x9000000                              // 0000000FFC5C: 961EFF1A 09000000
	s_mul_hi_i32 s31, s26, 0x9000000                           // 0000000FFC64: 971FFF1A 09000000
	s_add_u32 s4, s4, s30                                      // 0000000FFC6C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 0000000FFC70: 82051F05
	s_lshl_b64 s[26:27], s[28:29], 2                           // 0000000FFC74: 849A821C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FFC78: BF8700B9
	s_add_u32 s4, s4, s26                                      // 0000000FFC7C: 80041A04
	s_addc_u32 s5, s5, s27                                     // 0000000FFC80: 82051B05
	.long 0xd7000402                                           // 0000000FFC84: D7000402
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000000FFC88: 02020204
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 0000000FFC8C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 0000000FFC94: BE840080
	s_nop 0                                                    // 0000000FFC98: BF800000
	s_nop 0                                                    // 0000000FFC9C: BF800000
	s_nop 0                                                    // 0000000FFCA0: BF800000
	s_nop 0                                                    // 0000000FFCA4: BF800000
	s_nop 0                                                    // 0000000FFCA8: BF800000
	s_nop 0                                                    // 0000000FFCAC: BF800000
	s_nop 0                                                    // 0000000FFCB0: BF800000
	s_nop 0                                                    // 0000000FFCB4: BF800000
	s_nop 0                                                    // 0000000FFCB8: BF800000
	s_nop 0                                                    // 0000000FFCBC: BF800000
	v_lshrrev_b32_e32 v8, 5, v4                                // 0000000FFCC0: 32100885
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000FFCC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFCCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000FFCD0: 300C1089
	.long 0xd7006a06                                           // 0000000FFCD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000FFCD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FFCDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000FFCE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v4                         // 0000000FFCE8: 7C9208FF 00000F7F
	v_mov_b32_e32 v4, v10                                      // 0000000FFCF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000FFCF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x84, v8, v[1:2]               // 0000000FFCFC: D6FE7C06 040610FF 00000084
	s_or_b32 s4, vcc_lo, s4                                    // 0000000FFD08: 8C04046A
	s_waitcnt vmcnt(0)                                         // 0000000FFD0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000FFD10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FFD18: 917E047E
	s_cbranch_execnz 65512                                     // 0000000FFD1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FFD20: 8C7E047E
	s_load_b32 s33, s[0:1], 0x58                               // 0000000FFD24: F4000840 F8000058
	v_or_b32_e32 v23, 0xffffff80, v0                           // 0000000FFD2C: 382E00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000000FFD34: 32040085
	s_mov_b32 s0, 0                                            // 0000000FFD38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000FFD3C: BF89FC07
	s_barrier                                                  // 0000000FFD40: BFBD0000
	buffer_gl0_inv                                             // 0000000FFD44: E0AC0000 00000000
	s_cmp_gt_i32 s33, 0                                        // 0000000FFD4C: BF028021
	s_cbranch_scc1 12                                          // 0000000FFD50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x84, v2                             // 0000000FFD54: 160604FF 00000084
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000FFD5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FFD64: BF870002
	v_lshl_add_u32 v22, v5, 2, v3                              // 0000000FFD68: D6460016 040D0505
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v24, 2, v5      // 0000000FFD70: CA220080 03180A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000FFD78: 916A007E
	s_cbranch_vccz 2                                           // 0000000FFD7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 779                                               // 0000000FFD80: BFA0030B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdb0>
	v_lshlrev_b32_e32 v24, 2, v5                               // 0000000FFD84: 30300A82
	s_add_i32 s0, s33, 63                                      // 0000000FFD88: 8100BF21
	s_add_i32 s34, s2, 0xbd0                                   // 0000000FFD8C: 8122FF02 00000BD0
	s_lshr_b32 s35, s0, 6                                      // 0000000FFD94: 85238600
	s_add_u32 s14, s14, s26                                    // 0000000FFD98: 800E1A0E
	s_addc_u32 s15, s15, s27                                   // 0000000FFD9C: 820F1B0F
	s_lshl_b32 s0, s2, 7                                       // 0000000FFDA0: 84008702
	v_lshlrev_b32_e32 v25, 2, v0                               // 0000000FFDA4: 30320082
	s_ashr_i32 s1, s0, 31                                      // 0000000FFDA8: 86019F00
	v_lshlrev_b32_e32 v6, 1, v5                                // 0000000FFDAC: 300C0A81
	s_lshl_b64 s[4:5], s[0:1], 1                               // 0000000FFDB0: 84848100
	v_lshlrev_b32_e32 v12, 8, v2                               // 0000000FFDB4: 30180488
	s_add_u32 s6, s6, s4                                       // 0000000FFDB8: 80060406
	s_addc_u32 s7, s7, s5                                      // 0000000FFDBC: 82070507
	s_lshl_b64 s[4:5], s[28:29], 1                             // 0000000FFDC0: 8484811C
	v_mad_u32_u24 v22, 0x84, v2, v24                           // 0000000FFDC4: D60B0016 046204FF 00000084
	s_add_u32 s6, s6, s4                                       // 0000000FFDD0: 80060406
	.long 0xd700041d                                           // 0000000FFDD4: D700041D
	v_cndmask_b32_e32 v1, s14, v24, vcc_lo                     // 0000000FFDD8: 0202300E
	s_addc_u32 s7, s7, s5                                      // 0000000FFDDC: 82070507
	v_add_co_ci_u32_e64 v30, null, s15, 0, s4                  // 0000000FFDE0: D5207C1E 0011000F
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000000FFDE8: 84848902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FFDEC: BF8700B9
	v_dual_mov_b32 v15, s5 :: v_dual_add_nc_u32 v28, 1, v2     // 0000000FFDF0: CA200005 0F1C0481
	v_or_b32_e32 v14, s4, v25                                  // 0000000FFDF8: 381C3204
	.long 0xd7000406                                           // 0000000FFDFC: D7000406
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000000FFE00: 02020C06
	v_add_co_ci_u32_e64 v7, null, s7, 0, s4                    // 0000000FFE04: D5207C07 00110007
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE0C: BF870093
	.long 0xd7000408                                           // 0000000FFE10: D7000408
	v_cndmask_b32_e32 v1, s16, v14, vcc_lo                     // 0000000FFE14: 02021C10
	v_add_co_ci_u32_e64 v9, null, s17, v15, s4                 // 0000000FFE18: D5207C09 00121E11
	s_lshl_b64 s[6:7], s[2:3], 14                              // 0000000FFE20: 84868E02
	.long 0xd700040a                                           // 0000000FFE24: D700040A
	v_cndmask_b32_e32 v1, s8, v14, vcc_lo                      // 0000000FFE28: 02021C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FFE2C: BF8700C1
	v_add_co_ci_u32_e64 v11, null, s9, v15, s4                 // 0000000FFE30: D5207C0B 00121E09
	s_add_u32 s4, s18, s6                                      // 0000000FFE38: 80040612
	s_addc_u32 s5, s19, s7                                     // 0000000FFE3C: 82050713
	.long 0xd700040c                                           // 0000000FFE40: D700040C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000000FFE44: 02021804
	v_add_co_ci_u32_e64 v13, null, s5, 0, s4                   // 0000000FFE48: D5207C0D 00110005
	.long 0xd700040e                                           // 0000000FFE50: D700040E
	v_cndmask_b32_e32 v1, s10, v14, vcc_lo                     // 0000000FFE54: 02021C0A
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v26, 0x6b10, v25 // 0000000FFE58: CA200080 031A32FF 00006B10
	v_add_nc_u32_e32 v27, 0x6c10, v25                          // 0000000FFE64: 4A3632FF 00006C10
	.long 0xd44c0000                                           // 0000000FFE6C: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000FFE70: 020200FF 00000200
	.long 0xd44c0001                                           // 0000000FFE78: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000FFE7C: 020200FF 00000080
	v_add_nc_u32_e32 v4, 0x4200, v22                           // 0000000FFE84: 4A082CFF 00004200
	v_or_b32_e32 v5, 0x4200, v1                                // 0000000FFE8C: 380A02FF 00004200
	v_mul_u32_u24_e32 v31, 0x204, v2                           // 0000000FFE94: 163E04FF 00000204
	v_add_co_ci_u32_e64 v15, null, s11, v15, s4                // 0000000FFE9C: D5207C0F 00121E0B
	s_mov_b32 s6, 0                                            // 0000000FFEA4: BE860080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000FFEA8: 7C9800C0
	s_mul_i32 s4, s6, 0xc00                                    // 0000000FFEAC: 9604FF06 00000C00
	s_lshl_b32 s8, s6, 6                                       // 0000000FFEB4: 84088606
	s_add_i32 s4, s34, s4                                      // 0000000FFEB8: 81040422
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000FFEBC: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000000FFEC0: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000000FFEC4: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FFEC8: BF870009
	s_add_u32 s4, s12, s4                                      // 0000000FFECC: 8004040C
	s_addc_u32 s5, s13, s5                                     // 0000000FFED0: 8205050D
	global_load_b32 v16, v3, s[4:5]                            // 0000000FFED4: DC520000 10040003
	s_waitcnt vmcnt(0)                                         // 0000000FFEDC: BF8903F7
	v_readfirstlane_b32 s7, v16                                // 0000000FFEE0: 7E0E0510
	s_and_saveexec_b32 s5, vcc_lo                              // 0000000FFEE4: BE85206A
	s_cbranch_execz 77                                         // 0000000FFEE8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x420>
	v_or_b32_e32 v16, s8, v0                                   // 0000000FFEEC: 38200008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFEF0: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[2:3]              // 0000000FFEF4: D6FE7C10 00096110
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000000FFEFC: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF00: BF870091
	.long 0xd73c0010                                           // 0000000FFF04: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 0000000FFF08: 02022082
	.long 0xd7000410                                           // 0000000FFF0C: D7000410
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 0000000FFF10: 0202200C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FFF14: BF8700C1
	v_add_co_ci_u32_e64 v17, null, s13, v17, s4                // 0000000FFF18: D5207C11 0012220D
	global_load_b32 v16, v[16:17], off                         // 0000000FFF20: DC520000 107C0010
	s_waitcnt vmcnt(0)                                         // 0000000FFF28: BF8903F7
	v_sub_f32_e32 v17, s7, v16                                 // 0000000FFF2C: 08222007
	v_dual_mul_f32 v19, 0x3fb8aa3b, v16 :: v_dual_mul_f32 v18, 0x3fb8aa3b, v17// 0000000FFF30: C8C620FF 131222FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000FFF3C: BF8701A1
	v_fma_f32 v32, 0x3fb8aa3b, v16, -v19                       // 0000000FFF40: D6130020 844E20FF 3FB8AA3B
	v_rndne_f32_e32 v33, v19                                   // 0000000FFF4C: 7E424713
	v_fma_f32 v20, 0x3fb8aa3b, v17, -v18                       // 0000000FFF50: D6130014 844A22FF 3FB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000000FFF5C: 7E2A4712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FFF60: BF870113
	v_dual_fmac_f32 v32, 0x32a5705f, v16 :: v_dual_sub_f32 v19, v19, v33// 0000000FFF64: C80A20FF 20124313 32A5705F
	v_sub_f32_e32 v18, v18, v21                                // 0000000FFF70: 08242B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFF74: BF870122
	v_dual_fmac_f32 v20, 0x32a5705f, v17 :: v_dual_add_f32 v19, v19, v32// 0000000FFF78: C80822FF 14124113 32A5705F
	.long 0xd41b0004                                           // 0000000FFF84: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v17, vcc_lo              // 0000000FFF88: 020222FF C2CE8ED0
	v_add_f32_e32 v18, v18, v20                                // 0000000FFF90: 06242912
	v_cvt_i32_f32_e32 v20, v21                                 // 0000000FFF94: 7E281115
	v_cvt_i32_f32_e32 v21, v33                                 // 0000000FFF98: 7E2A1121
	v_exp_f32_e32 v19, v19                                     // 0000000FFF9C: 7E264B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000FFFA0: BF870313
	v_exp_f32_e32 v18, v18                                     // 0000000FFFA4: 7E244B12
	.long 0xd71c0013                                           // 0000000FFFA8: D71C0013
	v_cndmask_b32_e32 v1, v19, v21, vcc_lo                     // 0000000FFFAC: 02022B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFFB0: BF870095
	.long 0xd71c0012                                           // 0000000FFFB4: D71C0012
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000000FFFB8: 02022912
	v_cndmask_b32_e64 v18, 0, v18, s4                          // 0000000FFFBC: D5010012 00122480
	.long 0xd41b0004                                           // 0000000FFFC4: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v16, vcc_lo              // 0000000FFFC8: 020220FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FFFD0: BF8700A1
	v_cndmask_b32_e64 v19, 0, v19, s4                          // 0000000FFFD4: D5010013 00122680
	.long 0xd41e0004                                           // 0000000FFFDC: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v17, vcc_lo              // 0000000FFFE0: 020222FF 42B17218
	v_cndmask_b32_e64 v17, 0x7f800000, v18, s4                 // 0000000FFFE8: D5010011 001224FF 7F800000
	.long 0xd41e0004                                           // 0000000FFFF4: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v16, vcc_lo              // 0000000FFFF8: 020220FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100000: BF870001
	v_cndmask_b32_e64 v16, 0x7f800000, v19, s4                 // 000000100004: D5010010 001226FF 7F800000
	ds_store_b32 v26, v17                                      // 000000100010: D8340000 0000111A
	ds_store_b32 v27, v16                                      // 000000100018: D8340000 0000101B
	s_or_b32 exec_lo, exec_lo, s5                              // 000000100020: 8C7E057E
	v_or_b32_e32 v20, s8, v2                                   // 000000100024: 38280408
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v16, v8           // 000000100028: CA100109 11100108
	s_mov_b32 s9, 0                                            // 000000100030: BE890080
	s_waitcnt lgkmcnt(0)                                       // 000000100034: BF89FC07
	s_barrier                                                  // 000000100038: BFBD0000
	buffer_gl0_inv                                             // 00000010003C: E0AC0000 00000000
	s_branch 15                                                // 000000100044: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x484>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000100048: 8C7E057E
	.long 0xd7000410                                           // 00000010004C: D7000410
	v_cndmask_b32_e32 v1, 0x18000, v16, vcc_lo                 // 000000100050: 020220FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100058: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, s4                  // 00000010005C: D5207C11 00122280
	s_add_i32 s4, s9, 4                                        // 000000100064: 81048409
	s_cmp_lt_u32 s9, 60                                        // 000000100068: BF0ABC09
	s_mov_b32 s9, s4                                           // 00000010006C: BE890004
	s_waitcnt lgkmcnt(0)                                       // 000000100070: BF89FC07
	s_barrier                                                  // 000000100074: BFBD0000
	buffer_gl0_inv                                             // 000000100078: E0AC0000 00000000
	s_cbranch_scc0 168                                         // 000000100080: BFA100A8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x724>
	s_and_saveexec_b32 s10, s0                                 // 000000100084: BE8A2000
	s_cbranch_execz 34                                         // 000000100088: BFA50022 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x514>
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 00000010008C: CA100111 13120110
	v_dual_mov_b32 v21, v25 :: v_dual_mov_b32 v32, v23         // 000000100094: CA100119 15200117
	s_mov_b32 s11, 0                                           // 00000010009C: BE8B0080
	s_nop 0                                                    // 0000001000A0: BF800000
	s_nop 0                                                    // 0000001000A4: BF800000
	s_nop 0                                                    // 0000001000A8: BF800000
	s_nop 0                                                    // 0000001000AC: BF800000
	s_nop 0                                                    // 0000001000B0: BF800000
	s_nop 0                                                    // 0000001000B4: BF800000
	s_nop 0                                                    // 0000001000B8: BF800000
	s_nop 0                                                    // 0000001000BC: BF800000
	global_load_b32 v33, v[18:19], off                         // 0000001000C0: DC520000 217C0012
	v_add_nc_u32_e32 v32, 0x80, v32                            // 0000001000C8: 4A4040FF 00000080
	.long 0xd7000412                                           // 0000001000D0: D7000412
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 0000001000D4: 020224FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001000DC: BF870191
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 0000001000E0: D5207C13 00122680
	.long 0xd4490005                                           // 0000001000E8: D4490005
	v_cndmask_b32_e32 v1, 0x17f, v32, vcc_lo                   // 0000001000EC: 020240FF 0000017F
	s_or_b32 s11, s5, s11                                      // 0000001000F4: 8C0B0B05
	s_waitcnt vmcnt(0)                                         // 0000001000F8: BF8903F7
	ds_store_b32 v21, v33 offset:25344                         // 0000001000FC: D8346300 00002115
	v_add_nc_u32_e32 v21, 0x204, v21                           // 000000100104: 4A2A2AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000010010C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000100110: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000100114: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000100118: BF89FC07
	s_barrier                                                  // 00000010011C: BFBD0000
	buffer_gl0_inv                                             // 000000100120: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000100128: BE852001
	s_cbranch_execz 65478                                      // 00000010012C: BFA5FFC6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x448>
	v_or_b32_e32 v18, s9, v20                                  // 000000100130: 38242809
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100134: BF870091
	v_mad_u64_u32 v[18:19], null, v18, 48, s[2:3]              // 000000100138: D6FE7C12 00096112
	.long 0xd73c0012                                           // 000000100140: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000100144: 02022489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100148: BF870091
	.long 0xd7000412                                           // 00000010014C: D7000412
	v_cndmask_b32_e32 v1, v29, v18, vcc_lo                     // 000000100150: 0202251D
	v_add_co_ci_u32_e64 v19, null, v30, v19, s4                // 000000100154: D5207C13 0012271E
	s_movk_i32 s4, 0xfe00                                      // 00000010015C: B004FE00
	global_load_b32 v19, v[18:19], off                         // 000000100160: DC520000 137C0012
	v_mov_b32_e32 v18, v1                                      // 000000100168: 7E240301
	v_add_nc_u32_e32 v21, s4, v31                              // 00000010016C: 4A2A3E04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000100170: BF8704A2
	v_add_nc_u32_e32 v46, 0x400, v18                           // 000000100174: 4A5C24FF 00000400
	s_add_i32 s4, s4, 64                                       // 00000010017C: 8104C004
	s_cmp_eq_u32 s4, 0                                         // 000000100180: BF068004
	s_delay_alu instid0(VALU_DEP_2)                            // 000000100184: BF870002
	v_add_nc_u32_e32 v34, 0x6500, v21                          // 000000100188: 4A442AFF 00006500
	v_add_nc_u32_e32 v38, 0x6508, v21                          // 000000100190: 4A4C2AFF 00006508
	v_add_nc_u32_e32 v42, 0x6510, v21                          // 000000100198: 4A542AFF 00006510
	v_add_nc_u32_e32 v44, 0x6518, v21                          // 0000001001A0: 4A582AFF 00006518
	ds_load_2addr_b32 v[32:33], v18 offset1:33                 // 0000001001A8: D8DC2100 20000012
	ds_load_2addr_b32 v[34:35], v34 offset1:1                  // 0000001001B0: D8DC0100 22000022
	ds_load_2addr_b32 v[36:37], v18 offset0:66 offset1:99      // 0000001001B8: D8DC6342 24000012
	ds_load_2addr_b32 v[38:39], v38 offset1:1                  // 0000001001C0: D8DC0100 26000026
	ds_load_2addr_b32 v[40:41], v18 offset0:132 offset1:165    // 0000001001C8: D8DCA584 28000012
	ds_load_2addr_b32 v[42:43], v42 offset1:1                  // 0000001001D0: D8DC0100 2A00002A
	ds_load_2addr_b32 v[44:45], v44 offset1:1                  // 0000001001D8: D8DC0100 2C00002C
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000001001E0: BF890057
	v_fma_f32 v19, -v34, v32, v19                              // 0000001001E4: D6130013 244E4122
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001001EC: BF870001
	v_fma_f32 v19, -v35, v33, v19                              // 0000001001F0: D6130013 244E4323
	ds_load_2addr_b32 v[32:33], v18 offset0:198 offset1:231    // 0000001001F8: D8DCE7C6 20000012
	v_add_nc_u32_e32 v18, 0x840, v18                           // 000000100200: 4A2424FF 00000840
	s_waitcnt lgkmcnt(4)                                       // 000000100208: BF89FC47
	v_fma_f32 v19, -v38, v36, v19                              // 00000010020C: D6130013 244E4926
	v_add_nc_u32_e32 v36, 0x6520, v21                          // 000000100214: 4A482AFF 00006520
	s_delay_alu instid0(VALU_DEP_2)                            // 00000010021C: BF870002
	v_fma_f32 v19, -v39, v37, v19                              // 000000100220: D6130013 244E4B27
	ds_load_2addr_b32 v[34:35], v46 offset0:8 offset1:41       // 000000100228: D8DC2908 2200002E
	ds_load_2addr_b32 v[36:37], v36 offset1:1                  // 000000100230: D8DC0100 24000024
	s_waitcnt lgkmcnt(4)                                       // 000000100238: BF89FC47
	v_fma_f32 v19, -v42, v40, v19                              // 00000010023C: D6130013 244E512A
	v_add_nc_u32_e32 v40, 0x6528, v21                          // 000000100244: 4A502AFF 00006528
	v_add_nc_u32_e32 v42, 0x6530, v21                          // 00000010024C: 4A542AFF 00006530
	v_add_nc_u32_e32 v21, 0x6538, v21                          // 000000100254: 4A2A2AFF 00006538
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000010025C: BF8700D4
	v_fma_f32 v19, -v43, v41, v19                              // 000000100260: D6130013 244E532B
	ds_load_2addr_b32 v[38:39], v46 offset0:74 offset1:107     // 000000100268: D8DC6B4A 2600002E
	ds_load_2addr_b32 v[40:41], v40 offset1:1                  // 000000100270: D8DC0100 28000028
	s_waitcnt lgkmcnt(4)                                       // 000000100278: BF89FC47
	v_fma_f32 v19, -v44, v32, v19                              // 00000010027C: D6130013 244E412C
	v_fma_f32 v19, -v45, v33, v19                              // 000000100284: D6130013 244E432D
	ds_load_2addr_b32 v[32:33], v46 offset0:140 offset1:173    // 00000010028C: D8DCAD8C 2000002E
	ds_load_2addr_b32 v[42:43], v42 offset1:1                  // 000000100294: D8DC0100 2A00002A
	ds_load_2addr_b32 v[44:45], v21 offset1:1                  // 00000010029C: D8DC0100 2C000015
	s_waitcnt lgkmcnt(5)                                       // 0000001002A4: BF89FC57
	v_fma_f32 v19, -v36, v34, v19                              // 0000001002A8: D6130013 244E4524
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001002B0: BF8700C1
	v_fma_f32 v19, -v37, v35, v19                              // 0000001002B4: D6130013 244E4725
	ds_load_2addr_b32 v[34:35], v46 offset0:206 offset1:239    // 0000001002BC: D8DCEFCE 2200002E
	s_waitcnt lgkmcnt(4)                                       // 0000001002C4: BF89FC47
	v_fma_f32 v19, -v40, v38, v19                              // 0000001002C8: D6130013 244E4D28
	v_fma_f32 v19, -v41, v39, v19                              // 0000001002D0: D6130013 244E4F29
	s_waitcnt lgkmcnt(2)                                       // 0000001002D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002DC: BF870091
	v_fma_f32 v19, -v42, v32, v19                              // 0000001002E0: D6130013 244E412A
	v_fma_f32 v19, -v43, v33, v19                              // 0000001002E8: D6130013 244E432B
	s_waitcnt lgkmcnt(0)                                       // 0000001002F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002F4: BF870091
	v_fma_f32 v19, -v44, v34, v19                              // 0000001002F8: D6130013 244E452C
	v_fma_f32 v19, -v45, v35, v19                              // 000000100300: D6130013 244E472D
	s_cbranch_scc0 65432                                       // 000000100308: BFA1FF98 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x56c>
	v_mad_u64_u32 v[32:33], null, 0x84, s9, v[4:5]             // 00000010030C: D6FE7C20 041012FF 00000084
	ds_store_b32 v32, v19                                      // 000000100318: D8340000 00001320
	s_branch 65353                                             // 000000100320: BFA0FF49 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x448>
	v_dual_mov_b32 v17, v13 :: v_dual_mov_b32 v16, v12         // 000000100324: CA10010D 1110010C
	v_dual_mov_b32 v19, v11 :: v_dual_mov_b32 v18, v10         // 00000010032C: CA10010B 1312010A
	v_mov_b32_e32 v32, v28                                     // 000000100334: 7E40031C
	s_mov_b32 s9, 0                                            // 000000100338: BE890080
	s_branch 21                                                // 00000010033C: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x794>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000100340: 8C7E0A7E
	.long 0xd7000412                                           // 000000100344: D7000412
	v_cndmask_b32_e32 v1, 0x18000, v18, vcc_lo                 // 000000100348: 020224FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100350: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 000000100354: D5207C13 00122680
	.long 0xd7000410                                           // 00000010035C: D7000410
	v_cndmask_b32_e32 v1, 0x400, v16, vcc_lo                   // 000000100360: 020220FF 00000400
	v_add_nc_u32_e32 v32, 4, v32                               // 000000100368: 4A404084
	v_add_co_ci_u32_e64 v17, null, 0, v17, s4                  // 00000010036C: D5207C11 00122280
	s_add_i32 s4, s9, 4                                        // 000000100374: 81048409
	s_cmp_gt_u32 s9, 59                                        // 000000100378: BF08BB09
	s_mov_b32 s9, s4                                           // 00000010037C: BE890004
	s_waitcnt_vscnt null, 0x0                                  // 000000100380: BC7C0000
	s_barrier                                                  // 000000100384: BFBD0000
	buffer_gl0_inv                                             // 000000100388: E0AC0000 00000000
	s_cbranch_scc1 187                                         // 000000100390: BFA200BB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa80>
	s_and_saveexec_b32 s10, s0                                 // 000000100394: BE8A2000
	s_cbranch_execz 30                                         // 000000100398: BFA5001E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x814>
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v20, v18         // 00000010039C: CA100113 15140112
	v_dual_mov_b32 v33, v25 :: v_dual_mov_b32 v34, v23         // 0000001003A4: CA100119 21220117
	s_mov_b32 s11, 0                                           // 0000001003AC: BE8B0080
	s_nop 0                                                    // 0000001003B0: BF800000
	s_nop 0                                                    // 0000001003B4: BF800000
	s_nop 0                                                    // 0000001003B8: BF800000
	s_nop 0                                                    // 0000001003BC: BF800000
	global_load_b32 v35, v[20:21], off                         // 0000001003C0: DC520000 237C0014
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000001003C8: 4A4444FF 00000080
	.long 0xd7000414                                           // 0000001003D0: D7000414
	v_cndmask_b32_e32 v1, 0x6000, v20, vcc_lo                  // 0000001003D4: 020228FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001003DC: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s4                  // 0000001003E0: D5207C15 00122A80
	.long 0xd4490005                                           // 0000001003E8: D4490005
	v_cndmask_b32_e32 v1, 0x17f, v34, vcc_lo                   // 0000001003EC: 020244FF 0000017F
	s_or_b32 s11, s5, s11                                      // 0000001003F4: 8C0B0B05
	s_waitcnt vmcnt(0)                                         // 0000001003F8: BF8903F7
	ds_store_b32 v33, v35 offset:25344                         // 0000001003FC: D8346300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000100404: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000010040C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000100410: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000100414: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000100418: BF89FC07
	s_barrier                                                  // 00000010041C: BFBD0000
	buffer_gl0_inv                                             // 000000100420: E0AC0000 00000000
	s_and_saveexec_b32 s10, s1                                 // 000000100428: BE8A2001
	s_cbranch_execz 65476                                      // 00000010042C: BFA5FFC4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x740>
	v_or_b32_e32 v20, s9, v2                                   // 000000100430: 38280409
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100434: BF870091
	v_or_b32_e32 v33, s8, v20                                  // 000000100438: 38422808
	.long 0xd4440004                                           // 00000010043C: D4440004
	v_cndmask_b32_e32 v1, s33, v33, vcc_lo                     // 000000100440: 02024221
	s_and_b32 exec_lo, exec_lo, s4                             // 000000100444: 8B7E047E
	s_cbranch_execz 65469                                      // 000000100448: BFA5FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x740>
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, v1            // 00000010044C: CA100080 22140101
	s_movk_i32 s4, 0xfe00                                      // 000000100454: B004FE00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000100458: BF870119
	v_add_nc_u32_e32 v49, s4, v31                              // 00000010045C: 4A623E04
	v_add_nc_u32_e32 v50, 0x400, v21                           // 000000100460: 4A642AFF 00000400
	s_add_i32 s4, s4, 64                                       // 000000100468: 8104C004
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010046C: BF870119
	s_cmp_eq_u32 s4, 0                                         // 000000100470: BF068004
	v_add_nc_u32_e32 v37, 0x6500, v49                          // 000000100474: 4A4A62FF 00006500
	ds_load_2addr_b32 v[35:36], v21 offset1:33                 // 00000010047C: D8DC2100 23000015
	ds_load_2addr_b32 v[37:38], v37 offset1:1                  // 000000100484: D8DC0100 25000025
	s_waitcnt lgkmcnt(0)                                       // 00000010048C: BF89FC07
	v_fmac_f32_e32 v34, v37, v35                               // 000000100490: 56444725
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100494: BF870001
	v_dual_fmac_f32 v34, v38, v36 :: v_dual_add_nc_u32 v41, 0x6508, v49// 000000100498: C8204926 222862FF 00006508
	v_add_nc_u32_e32 v45, 0x6510, v49                          // 0000001004A4: 4A5A62FF 00006510
	ds_load_2addr_b32 v[35:36], v21 offset0:198 offset1:231    // 0000001004AC: D8DCE7C6 23000015
	ds_load_2addr_b32 v[39:40], v21 offset0:66 offset1:99      // 0000001004B4: D8DC6342 27000015
	ds_load_2addr_b32 v[41:42], v41 offset1:1                  // 0000001004BC: D8DC0100 29000029
	s_waitcnt lgkmcnt(0)                                       // 0000001004C4: BF89FC07
	v_dual_fmac_f32 v34, v41, v39 :: v_dual_add_nc_u32 v39, 0x6520, v49// 0000001004C8: C8204F29 222662FF 00006520
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001004D4: BF870001
	v_dual_fmac_f32 v34, v42, v40 :: v_dual_add_nc_u32 v47, 0x6518, v49// 0000001004D8: C820512A 222E62FF 00006518
	ds_load_2addr_b32 v[43:44], v21 offset0:132 offset1:165    // 0000001004E4: D8DCA584 2B000015
	ds_load_2addr_b32 v[45:46], v45 offset1:1                  // 0000001004EC: D8DC0100 2D00002D
	ds_load_2addr_b32 v[47:48], v47 offset1:1                  // 0000001004F4: D8DC0100 2F00002F
	ds_load_2addr_b32 v[37:38], v50 offset0:8 offset1:41       // 0000001004FC: D8DC2908 25000032
	ds_load_2addr_b32 v[39:40], v39 offset1:1                  // 000000100504: D8DC0100 27000027
	s_waitcnt lgkmcnt(3)                                       // 00000010050C: BF89FC37
	v_dual_fmac_f32 v34, v45, v43 :: v_dual_add_nc_u32 v21, 0x840, v21// 000000100510: C820572D 22142AFF 00000840
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010051C: BF8700A1
	v_dual_fmac_f32 v34, v46, v44 :: v_dual_add_nc_u32 v43, 0x6528, v49// 000000100520: C820592E 222A62FF 00006528
	s_waitcnt lgkmcnt(2)                                       // 00000010052C: BF89FC27
	v_fmac_f32_e32 v34, v47, v35                               // 000000100530: 5644472F
	ds_load_2addr_b32 v[41:42], v50 offset0:74 offset1:107     // 000000100534: D8DC6B4A 29000032
	ds_load_2addr_b32 v[43:44], v43 offset1:1                  // 00000010053C: D8DC0100 2B00002B
	v_dual_fmac_f32 v34, v48, v36 :: v_dual_add_nc_u32 v45, 0x6530, v49// 000000100544: C8204930 222C62FF 00006530
	s_waitcnt lgkmcnt(2)                                       // 000000100550: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100554: BF870091
	v_fmac_f32_e32 v34, v39, v37                               // 000000100558: 56444B27
	v_dual_fmac_f32 v34, v40, v38 :: v_dual_add_nc_u32 v47, 0x6538, v49// 00000010055C: C8204D28 222E62FF 00006538
	ds_load_2addr_b32 v[35:36], v50 offset0:140 offset1:173    // 000000100568: D8DCAD8C 23000032
	ds_load_2addr_b32 v[45:46], v45 offset1:1                  // 000000100570: D8DC0100 2D00002D
	ds_load_2addr_b32 v[47:48], v47 offset1:1                  // 000000100578: D8DC0100 2F00002F
	ds_load_2addr_b32 v[37:38], v50 offset0:206 offset1:239    // 000000100580: D8DCEFCE 25000032
	s_waitcnt lgkmcnt(4)                                       // 000000100588: BF89FC47
	v_fmac_f32_e32 v34, v43, v41                               // 00000010058C: 5644532B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000100590: BF8700A1
	v_fmac_f32_e32 v34, v44, v42                               // 000000100594: 5644552C
	s_waitcnt lgkmcnt(2)                                       // 000000100598: BF89FC27
	v_fmac_f32_e32 v34, v45, v35                               // 00000010059C: 5644472D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001005A0: BF8700A1
	v_fmac_f32_e32 v34, v46, v36                               // 0000001005A4: 5644492E
	s_waitcnt lgkmcnt(0)                                       // 0000001005A8: BF89FC07
	v_fmac_f32_e32 v34, v47, v37                               // 0000001005AC: 56444B2F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001005B0: BF870001
	v_fmac_f32_e32 v34, v48, v38                               // 0000001005B4: 56444D30
	s_cbranch_scc0 65447                                       // 0000001005B8: BFA1FFA7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x858>
	v_dual_mov_b32 v35, v1 :: v_dual_lshlrev_b32 v20, 2, v20   // 0000001005BC: CA220101 23142882
	s_mov_b32 s11, 0                                           // 0000001005C4: BE8B0080
	ds_load_b32 v36, v20 offset:27664                          // 0000001005C8: D8D86C10 24000014
	v_dual_mov_b32 v21, v17 :: v_dual_mov_b32 v20, v16         // 0000001005D0: CA100111 15140110
	s_waitcnt lgkmcnt(0)                                       // 0000001005D8: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000001005DC: 10444922
	v_mov_b32_e32 v36, v32                                     // 0000001005E0: 7E480320
	s_nop 0                                                    // 0000001005E4: BF800000
	s_nop 0                                                    // 0000001005E8: BF800000
	s_nop 0                                                    // 0000001005EC: BF800000
	s_nop 0                                                    // 0000001005F0: BF800000
	s_nop 0                                                    // 0000001005F4: BF800000
	s_nop 0                                                    // 0000001005F8: BF800000
	s_nop 0                                                    // 0000001005FC: BF800000
	global_load_b32 v37, v[20:21], off                         // 000000100600: DC520000 257C0014
	ds_load_b32 v38, v35 offset:16896                          // 000000100608: D8D84200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 000000100610: 4A4848C1
	.long 0xd7000414                                           // 000000100614: D7000414
	v_cndmask_b32_e32 v0, v20, v132, vcc_lo                    // 000000100618: 02010914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000010061C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s4                  // 000000100620: D5207C15 00122A80
	.long 0xd44a0005                                           // 000000100628: D44A0005
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 00000010062C: 02024880
	v_add_nc_u32_e32 v35, 0x84, v35                            // 000000100630: 4A4646FF 00000084
	s_or_b32 s11, s5, s11                                      // 000000100638: 8C0B0B05
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010063C: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 000000100640: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000100644: 917E0B7E
	s_cbranch_execnz 65517                                     // 000000100648: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa00>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000010064C: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100650: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 000000100654: D6100023 02052122
	v_mad_u64_u32 v[20:21], null, 0x3000, v33, v[6:7]          // 00000010065C: D6FE7C14 041A42FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 000000100668: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[20:21], v33, off                 // 000000100674: DC960000 007C2114
	s_branch 65328                                             // 00000010067C: BFA0FF30 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x740>
	s_mul_f32 s4, s7, 0x3fb8aa3b                               // 000000100680: A204FF07 3FB8AA3B
	v_mov_b32_e32 v18, v23                                     // 000000100688: 7E240317
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000010068C: BF8704CA
	s_xor_b32 s5, s4, 0x80000000                               // 000000100690: 8D05FF04 80000000
	s_rndne_f32 s8, s4                                         // 000000100698: BE886304
	s_fmamk_f32 s5, s7, 0x3fb8aa3b, s5                         // 00000010069C: A3050507 3FB8AA3B
	s_cmp_nlt_f32 s7, 0xc2ce8ed0                               // 0000001006A4: BF4EFF07 C2CE8ED0
	s_sub_f32 s4, s4, s8                                       // 0000001006AC: A0840804
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001006B0: BF870599
	s_fmamk_f32 s5, s7, 0x32a5705f, s5                         // 0000001006B4: A3050507 32A5705F
	s_add_f32 s4, s4, s5                                       // 0000001006BC: A0040504
	s_mov_b32 s5, 0                                            // 0000001006C0: BE850080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000001006C4: BF87000A
	v_exp_f32_e32 v16, s4                                      // 0000001006C8: 7E204A04
	s_cvt_i32_f32 s4, s8                                       // 0000001006CC: BE846608
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000001006D0: BF870585
	.long 0xd71c0010                                           // 0000001006D4: D71C0010
	v_cndmask_b32_e32 v0, v16, v4, vcc_lo                      // 0000001006D8: 02000910
	s_cselect_b32 s4, -1, 0                                    // 0000001006DC: 980480C1
	s_cmp_ngt_f32 s7, 0x42b17218                               // 0000001006E0: BF4BFF07 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001006E8: BF870131
	v_cndmask_b32_e64 v17, 0, v16, s4                          // 0000001006EC: D5010011 00122080
	s_cselect_b32 s4, -1, 0                                    // 0000001006F4: 980480C1
	v_mov_b32_e32 v16, v22                                     // 0000001006F8: 7E200316
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s4                 // 0000001006FC: D5010011 001222FF 7F800000
	ds_load_b32 v19, v16                                       // 000000100708: D8D80000 13000010
	s_waitcnt lgkmcnt(0)                                       // 000000100710: BF89FC07
	v_dual_mul_f32 v19, v17, v19 :: v_dual_add_nc_u32 v18, 0x80, v18// 000000100714: C8E02711 131224FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000100720: BF8704C1
	.long 0xd4490004                                           // 000000100724: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v18, vcc_lo                   // 000000100728: 020224FF 00000F7F
	ds_store_b32 v16, v19                                      // 000000100730: D8340000 00001310
	v_add_nc_u32_e32 v16, 0x210, v16                           // 000000100738: 4A2020FF 00000210
	s_or_b32 s5, s4, s5                                        // 000000100740: 8C050504
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000100744: 917E057E
	s_cbranch_execnz 65519                                     // 000000100748: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb08>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000010074C: 8C7E057E
	v_dual_mov_b32 v17, v15 :: v_dual_mov_b32 v16, v14         // 000000100750: CA10010F 1110010E
	v_mov_b32_e32 v32, 0                                       // 000000100758: 7E400280
	s_mov_b32 s7, 0                                            // 00000010075C: BE870080
	s_waitcnt lgkmcnt(0)                                       // 000000100760: BF89FC07
	s_barrier                                                  // 000000100764: BFBD0000
	buffer_gl0_inv                                             // 000000100768: E0AC0000 00000000
	s_and_saveexec_b32 s8, s0                                  // 000000100770: BE882000
	s_cbranch_execz 43                                         // 000000100774: BFA5002B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc24>
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 000000100778: CA100111 13120110
	v_dual_mov_b32 v20, v32 :: v_dual_mov_b32 v21, v25         // 000000100780: CA100120 14140119
	v_mov_b32_e32 v33, v23                                     // 000000100788: 7E420317
	s_mov_b32 s9, 0                                            // 00000010078C: BE890080
	s_nop 0                                                    // 000000100790: BF800000
	s_nop 0                                                    // 000000100794: BF800000
	s_nop 0                                                    // 000000100798: BF800000
	s_nop 0                                                    // 00000010079C: BF800000
	s_nop 0                                                    // 0000001007A0: BF800000
	s_nop 0                                                    // 0000001007A4: BF800000
	s_nop 0                                                    // 0000001007A8: BF800000
	s_nop 0                                                    // 0000001007AC: BF800000
	s_nop 0                                                    // 0000001007B0: BF800000
	s_nop 0                                                    // 0000001007B4: BF800000
	s_nop 0                                                    // 0000001007B8: BF800000
	s_nop 0                                                    // 0000001007BC: BF800000
	global_load_b32 v34, v[18:19], off                         // 0000001007C0: DC520000 227C0012
	ds_load_b32 v35, v20 offset:27408                          // 0000001007C8: D8D86B10 23000014
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001007D0: 4A4242FF 00000080
	.long 0xd7000412                                           // 0000001007D8: D7000412
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 0000001007DC: 020224FF 00006000
	v_add_nc_u32_e32 v20, 4, v20                               // 0000001007E4: 4A282884
	v_add_co_ci_u32_e64 v19, null, 0, v19, s4                  // 0000001007E8: D5207C13 00122680
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001007F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001007F4: 10444722
	.long 0xd4490005                                           // 0000001007F8: D4490005
	v_cndmask_b32_e32 v1, 0x17f, v33, vcc_lo                   // 0000001007FC: 020242FF 0000017F
	ds_store_b32 v21, v34 offset:25344                         // 000000100804: D8346300 00002215
	v_add_nc_u32_e32 v21, 0x204, v21                           // 00000010080C: 4A2A2AFF 00000204
	s_or_b32 s9, s5, s9                                        // 000000100814: 8C090905
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000100818: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000010081C: 917E097E
	s_cbranch_execnz 65511                                     // 000000100820: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100824: 8C7E087E
	v_mad_u64_u32 v[20:21], null, 0x84, s7, v[5:6]             // 000000100828: D6FE7C14 04140EFF 00000084
	s_waitcnt lgkmcnt(0)                                       // 000000100834: BF89FC07
	s_barrier                                                  // 000000100838: BFBD0000
	buffer_gl0_inv                                             // 00000010083C: E0AC0000 00000000
	v_mov_b32_e32 v33, v0                                      // 000000100844: 7E420300
	s_mov_b32 s5, 0                                            // 000000100848: BE850080
	ds_load_2addr_b32 v[18:19], v20 offset1:33                 // 00000010084C: D8DC2100 12000014
	ds_load_2addr_b32 v[20:21], v20 offset0:66 offset1:99      // 000000100854: D8DC6342 14000014
	s_nop 0                                                    // 00000010085C: BF800000
	s_nop 0                                                    // 000000100860: BF800000
	s_nop 0                                                    // 000000100864: BF800000
	s_nop 0                                                    // 000000100868: BF800000
	s_nop 0                                                    // 00000010086C: BF800000
	s_nop 0                                                    // 000000100870: BF800000
	s_nop 0                                                    // 000000100874: BF800000
	s_nop 0                                                    // 000000100878: BF800000
	s_nop 0                                                    // 00000010087C: BF800000
	v_lshrrev_b32_e32 v34, 5, v33                              // 000000100880: 32444285
	.long 0xd4490004                                           // 000000100884: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v33, vcc_lo                   // 000000100888: 020242FF 00000F7F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000100890: BF870002
	v_lshlrev_b32_e32 v37, 2, v34                              // 000000100894: 304A4482
	v_mad_u64_u32 v[34:35], null, 0x84, v34, v[1:2]            // 000000100898: D6FE7C22 040644FF 00000084
	s_or_b32 s5, s4, s5                                        // 0000001008A4: 8C050504
	v_add_nc_u32_e32 v35, 0x6200, v37                          // 0000001008A8: 4A464AFF 00006200
	v_add_nc_u32_e32 v37, 0x6600, v37                          // 0000001008B0: 4A4A4AFF 00006600
	ds_load_b32 v39, v34                                       // 0000001008B8: D8D80000 27000022
	ds_load_2addr_b32 v[35:36], v35 offset0:64 offset1:193     // 0000001008C0: D8DCC140 23000023
	ds_load_2addr_b32 v[37:38], v37 offset0:66 offset1:195     // 0000001008C8: D8DCC342 25000025
	s_waitcnt lgkmcnt(1)                                       // 0000001008D0: BF89FC17
	v_fmac_f32_e32 v39, v35, v18                               // 0000001008D4: 564E2523
	v_add_nc_u32_e32 v35, 0x80, v33                            // 0000001008D8: 4A4642FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001008E0: BF870112
	v_fmac_f32_e32 v39, v36, v19                               // 0000001008E4: 564E2724
	v_mov_b32_e32 v33, v35                                     // 0000001008E8: 7E420323
	s_waitcnt lgkmcnt(0)                                       // 0000001008EC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001008F0: BF870092
	v_fmac_f32_e32 v39, v37, v20                               // 0000001008F4: 564E2925
	v_fmac_f32_e32 v39, v38, v21                               // 0000001008F8: 564E2B26
	ds_store_b32 v34, v39                                      // 0000001008FC: D8340000 00002722
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000100904: 917E057E
	s_cbranch_execnz 65501                                     // 000000100908: BFA6FFDD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc80>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000010090C: 8C7E057E
	.long 0xd7000410                                           // 000000100910: D7000410
	v_cndmask_b32_e32 v1, 0x18000, v16, vcc_lo                 // 000000100914: 020220FF 00018000
	v_add_nc_u32_e32 v32, 16, v32                              // 00000010091C: 4A404090
	v_add_co_ci_u32_e64 v17, null, 0, v17, s4                  // 000000100920: D5207C11 00122280
	s_add_i32 s4, s7, 4                                        // 000000100928: 81048407
	s_cmp_gt_u32 s7, 59                                        // 00000010092C: BF08BB07
	s_mov_b32 s7, s4                                           // 000000100930: BE870004
	s_cbranch_scc0 65418                                       // 000000100934: BFA1FF8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb60>
	.long 0xd7000408                                           // 000000100938: D7000408
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000010093C: 020210FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000100944: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, s4                    // 000000100948: D5207C09 00121280
	.long 0xd700040a                                           // 000000100950: D700040A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 000000100954: 020214FF 00180000
	v_add_co_ci_u32_e64 v11, null, 0, v11, s4                  // 00000010095C: D5207C0B 00121680
	.long 0xd700040c                                           // 000000100964: D700040C
	v_cndmask_b32_e32 v1, 0xc0000, v12, vcc_lo                 // 000000100968: 020218FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000100970: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, s4                  // 000000100974: D5207C0D 00121A80
	.long 0xd700040e                                           // 00000010097C: D700040E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 000000100980: 02021CFF 00180000
	v_add_co_ci_u32_e64 v15, null, 0, v15, s4                  // 000000100988: D5207C0F 00121E80
	s_add_i32 s6, s6, 1                                        // 000000100990: 81068106
	s_waitcnt lgkmcnt(0)                                       // 000000100994: BF89FC07
	s_cmp_eq_u32 s6, s35                                       // 000000100998: BF062306
	s_barrier                                                  // 00000010099C: BFBD0000
	buffer_gl0_inv                                             // 0000001009A0: E0AC0000 00000000
	s_cbranch_scc0 64832                                       // 0000001009A8: BFA1FD40 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac>
	v_mov_b32_e32 v4, v23                                      // 0000001009AC: 7E080317
	s_add_u32 s0, s30, s24                                     // 0000001009B0: 8000181E
	.long 0xd73c0000                                           // 0000001009B4: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001009B8: 02020489
	s_addc_u32 s1, s31, s25                                    // 0000001009BC: 8201191F
	s_add_u32 s2, s26, s22                                     // 0000001009C0: 8002161A
	s_addc_u32 s3, s27, s23                                    // 0000001009C4: 8203171B
	s_add_u32 s0, s2, s0                                       // 0000001009C8: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000001009CC: 82010103
	.long 0xd7006a00                                           // 0000001009D0: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000001009D4: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001009D8: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001009DC: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001009E4: BE810080
	.long 0xd7006a00                                           // 0000001009E8: D7006A00
	v_cndmask_b32_e32 v1, v0, v24, vcc_lo                      // 0000001009EC: 02023100
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000001009F0: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009F8: BF870092
	.long 0xd7006a00                                           // 0000001009FC: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000100A00: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000100A04: D5207C01 01AA0215
	s_nop 0                                                    // 000000100A0C: BF800000
	s_nop 0                                                    // 000000100A10: BF800000
	s_nop 0                                                    // 000000100A14: BF800000
	s_nop 0                                                    // 000000100A18: BF800000
	s_nop 0                                                    // 000000100A1C: BF800000
	s_nop 0                                                    // 000000100A20: BF800000
	s_nop 0                                                    // 000000100A24: BF800000
	s_nop 0                                                    // 000000100A28: BF800000
	s_nop 0                                                    // 000000100A2C: BF800000
	s_nop 0                                                    // 000000100A30: BF800000
	s_nop 0                                                    // 000000100A34: BF800000
	s_nop 0                                                    // 000000100A38: BF800000
	s_nop 0                                                    // 000000100A3C: BF800000
	ds_load_b32 v2, v22                                        // 000000100A40: D8D80000 02000016
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000100A48: 4A0808FF 00000080
	v_add_nc_u32_e32 v22, 0x210, v22                           // 000000100A50: 4A2C2CFF 00000210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000100A58: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v4                         // 000000100A5C: 7C9208FF 00000F7F
	s_or_b32 s1, vcc_lo, s1                                    // 000000100A64: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000100A68: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000100A6C: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000100A74: D7000000
	v_cndmask_b32_e32 v1, 0x800, v0, vcc_lo                    // 000000100A78: 020200FF 00000800
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000100A80: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000100A88: 917E017E
	s_cbranch_execnz 65516                                     // 000000100A8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi4ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe40>
	s_endpgm                                                   // 000000100A90: BFB00000
		...

