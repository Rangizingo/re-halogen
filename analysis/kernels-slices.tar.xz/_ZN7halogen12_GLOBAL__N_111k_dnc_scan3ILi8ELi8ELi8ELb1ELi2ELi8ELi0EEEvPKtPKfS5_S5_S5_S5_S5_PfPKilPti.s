0000000000082500 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000082500: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000082504: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000008250C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000082514: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000082518: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000008251C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000082520: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000082528: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000008252C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000082530: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000082534: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000008253C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000082540: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000082544: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000082548: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008254C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000082550: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000082554: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000082558: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000008255C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000082564: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000008256C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000082570: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000082574: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000082578: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000008257C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000082580: 821E191E
	.long 0xd7001f02                                           // 000000082584: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000082588: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000008258C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000082594: BE9E0080
	s_nop 0                                                    // 000000082598: BF800000
	s_nop 0                                                    // 00000008259C: BF800000
	s_nop 0                                                    // 0000000825A0: BF800000
	s_nop 0                                                    // 0000000825A4: BF800000
	s_nop 0                                                    // 0000000825A8: BF800000
	s_nop 0                                                    // 0000000825AC: BF800000
	s_nop 0                                                    // 0000000825B0: BF800000
	s_nop 0                                                    // 0000000825B4: BF800000
	s_nop 0                                                    // 0000000825B8: BF800000
	s_nop 0                                                    // 0000000825BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000825C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000825C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000825CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000825D0: 300C1089
	.long 0xd7006a06                                           // 0000000825D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000825D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000825DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000825E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000825E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000825F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000825F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000825FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000082608: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000008260C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000082610: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000082618: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000008261C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000082620: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000082624: F4000780 F8000058
	v_or_b32_e32 v23, 0xffffff80, v0                           // 00000008262C: 382E00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000082634: 32040084
	s_mov_b32 s0, 0                                            // 000000082638: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000008263C: BF89FC07
	s_barrier                                                  // 000000082640: BFBD0000
	buffer_gl0_inv                                             // 000000082644: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000008264C: BF02801E
	s_cbranch_scc1 12                                          // 000000082650: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000082654: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000008265C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000082664: BF870002
	v_lshl_add_u32 v22, v5, 2, v3                              // 000000082668: D6460016 040D0505
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v24, 2, v5      // 000000082670: CA220080 03180A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000082678: 916A007E
	s_cbranch_vccz 2                                           // 00000008267C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 1871                                              // 000000082680: BFA0074F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	v_lshlrev_b32_e32 v24, 2, v5                               // 000000082684: 30300A82
	s_add_i32 s0, s30, 63                                      // 000000082688: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000008268C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000082694: 85218600
	s_add_u32 s34, s10, s24                                    // 000000082698: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000008269C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000826A0: 84008702
	v_lshlrev_b32_e32 v25, 2, v0                               // 0000000826A4: 30320082
	s_ashr_i32 s1, s0, 31                                      // 0000000826A8: 86019F00
	v_lshlrev_b32_e32 v6, 1, v5                                // 0000000826AC: 300C0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000826B0: 84808100
	v_lshlrev_b32_e32 v12, 8, v2                               // 0000000826B4: 30180488
	s_add_u32 s22, s22, s0                                     // 0000000826B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000826BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000826C0: 848A811A
	v_mad_u32_u24 v22, 0x44, v2, v24                           // 0000000826C4: D60B0016 046204FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000826D0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000826D4: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000826D8: B00A0204
	.long 0xd7000b1d                                           // 0000000826DC: D7000B1D
	v_cndmask_b32_e32 v1, s34, v24, vcc_lo                     // 0000000826E0: 02023022
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000826E4: BF8704B1
	v_add_co_ci_u32_e64 v30, null, s35, 0, s11                 // 0000000826E8: D5207C1E 002D0023
	v_mad_u32_u24 v31, v2, s10, 0x3300                         // 0000000826F0: D60B001F 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000826FC: 848A8902
	v_dual_mov_b32 v15, s11 :: v_dual_add_nc_u32 v28, 1, v2    // 000000082700: CA20000B 0F1C0481
	v_or_b32_e32 v14, s10, v25                                 // 000000082708: 381C320A
	.long 0xd7000a06                                           // 00000008270C: D7000A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000082710: 02020C16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000082714: BF870191
	v_add_co_ci_u32_e64 v7, null, s1, 0, s10                   // 000000082718: D5207C07 00290001
	.long 0xd7000108                                           // 000000082720: D7000108
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 000000082724: 02021C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000082728: BF8700B1
	v_add_co_ci_u32_e64 v9, null, s13, v15, s1                 // 00000008272C: D5207C09 00061E0D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000082734: 848A8E02
	.long 0xd700010a                                           // 000000082738: D700010A
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 00000008273C: 02021C04
	v_add_co_ci_u32_e64 v11, null, s5, v15, s1                 // 000000082740: D5207C0B 00061E05
	s_add_u32 s1, s14, s10                                     // 000000082748: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 00000008274C: 82040B0F
	.long 0xd700010c                                           // 000000082750: D700010C
	v_cndmask_b32_e32 v1, s1, v12, vcc_lo                      // 000000082754: 02021801
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082758: BF870001
	v_add_co_ci_u32_e64 v13, null, s4, 0, s1                   // 00000008275C: D5207C0D 00050004
	.long 0xd700010e                                           // 000000082764: D700010E
	v_cndmask_b32_e32 v1, s6, v14, vcc_lo                      // 000000082768: 02021C06
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v26, 0x4320, v25 // 00000008276C: CA200080 031A32FF 00004320
	v_add_nc_u32_e32 v27, 0x4420, v25                          // 000000082778: 4A3632FF 00004420
	.long 0xd44c0000                                           // 000000082780: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000082784: 020200FF 00000080
	v_add_nc_u32_e32 v4, 0x2200, v22                           // 00000008278C: 4A082CFF 00002200
	v_or_b32_e32 v5, 0x2200, v1                                // 000000082794: 380A02FF 00002200
	v_add_co_ci_u32_e64 v15, null, s7, v15, s1                 // 00000008279C: D5207C0F 00061E07
	v_add_nc_u32_e32 v32, 0x400, v1                            // 0000000827A4: 4A4002FF 00000400
	v_add_nc_u32_e32 v33, 0x600, v1                            // 0000000827AC: 4A4202FF 00000600
	v_add_nc_u32_e32 v34, 0x800, v1                            // 0000000827B4: 4A4402FF 00000800
	v_add_nc_u32_e32 v35, 0xc00, v1                            // 0000000827BC: 4A4602FF 00000C00
	v_add_nc_u32_e32 v36, 0xe00, v1                            // 0000000827C4: 4A4802FF 00000E00
	v_add_nc_u32_e32 v37, 0x1000, v1                           // 0000000827CC: 4A4A02FF 00001000
	v_add_nc_u32_e32 v38, 0x1400, v1                           // 0000000827D4: 4A4C02FF 00001400
	v_add_nc_u32_e32 v39, 0x1600, v1                           // 0000000827DC: 4A4E02FF 00001600
	v_add_nc_u32_e32 v40, 0x1800, v1                           // 0000000827E4: 4A5002FF 00001800
	v_add_nc_u32_e32 v41, 0x1c00, v1                           // 0000000827EC: 4A5202FF 00001C00
	v_add_nc_u32_e32 v42, 0x1e00, v1                           // 0000000827F4: 4A5402FF 00001E00
	v_add_nc_u32_e32 v43, 0x2000, v1                           // 0000000827FC: 4A5602FF 00002000
	s_mov_b32 s5, 0                                            // 000000082804: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000082808: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000008280C: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000082814: BF870499
	s_add_i32 s6, s31, s1                                      // 000000082818: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000008281C: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000082820: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000082824: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000082828: 84078605
	s_add_u32 s10, s8, s10                                     // 00000008282C: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 000000082830: 820B0B09
	global_load_b32 v16, v3, s[10:11]                          // 000000082834: DC520000 100A0003
	s_waitcnt vmcnt(0)                                         // 00000008283C: BF8903F7
	v_readfirstlane_b32 s6, v16                                // 000000082840: 7E0C0510
	s_and_saveexec_b32 s4, vcc_lo                              // 000000082844: BE84206A
	s_cbranch_execz 77                                         // 000000082848: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x480>
	v_or_b32_e32 v16, s7, v0                                   // 00000008284C: 38200007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082850: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[2:3]              // 000000082854: D6FE7C10 00096110
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000008285C: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082860: BF870091
	.long 0xd73c0010                                           // 000000082864: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000082868: 02022082
	.long 0xd7000110                                           // 00000008286C: D7000110
	v_cndmask_b32_e32 v1, s8, v16, vcc_lo                      // 000000082870: 02022008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000082874: BF8700C1
	v_add_co_ci_u32_e64 v17, null, s9, v17, s1                 // 000000082878: D5207C11 00062209
	global_load_b32 v16, v[16:17], off                         // 000000082880: DC520000 107C0010
	s_waitcnt vmcnt(0)                                         // 000000082888: BF8903F7
	v_sub_f32_e32 v17, s6, v16                                 // 00000008288C: 08222006
	v_dual_mul_f32 v19, 0x3fb8aa3b, v16 :: v_dual_mul_f32 v18, 0x3fb8aa3b, v17// 000000082890: C8C620FF 131222FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000008289C: BF8701A1
	v_fma_f32 v44, 0x3fb8aa3b, v16, -v19                       // 0000000828A0: D613002C 844E20FF 3FB8AA3B
	v_rndne_f32_e32 v45, v19                                   // 0000000828AC: 7E5A4713
	v_fma_f32 v20, 0x3fb8aa3b, v17, -v18                       // 0000000828B0: D6130014 844A22FF 3FB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000000828BC: 7E2A4712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000828C0: BF870113
	v_dual_fmac_f32 v44, 0x32a5705f, v16 :: v_dual_sub_f32 v19, v19, v45// 0000000828C4: C80A20FF 2C125B13 32A5705F
	v_sub_f32_e32 v18, v18, v21                                // 0000000828D0: 08242B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000828D4: BF870122
	v_dual_fmac_f32 v20, 0x32a5705f, v17 :: v_dual_add_f32 v19, v19, v44// 0000000828D8: C80822FF 14125913 32A5705F
	.long 0xd41b0001                                           // 0000000828E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v17, vcc_lo              // 0000000828E8: 020222FF C2CE8ED0
	v_add_f32_e32 v18, v18, v20                                // 0000000828F0: 06242912
	v_cvt_i32_f32_e32 v20, v21                                 // 0000000828F4: 7E281115
	v_cvt_i32_f32_e32 v21, v45                                 // 0000000828F8: 7E2A112D
	v_exp_f32_e32 v19, v19                                     // 0000000828FC: 7E264B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000082900: BF870313
	v_exp_f32_e32 v18, v18                                     // 000000082904: 7E244B12
	.long 0xd71c0013                                           // 000000082908: D71C0013
	v_cndmask_b32_e32 v1, v19, v21, vcc_lo                     // 00000008290C: 02022B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082910: BF870095
	.long 0xd71c0012                                           // 000000082914: D71C0012
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 000000082918: 02022912
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 00000008291C: D5010012 00062480
	.long 0xd41b0001                                           // 000000082924: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v16, vcc_lo              // 000000082928: 020220FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000082930: BF8700A1
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 000000082934: D5010013 00062680
	.long 0xd41e0001                                           // 00000008293C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v17, vcc_lo              // 000000082940: 020222FF 42B17218
	v_cndmask_b32_e64 v17, 0x7f800000, v18, s1                 // 000000082948: D5010011 000624FF 7F800000
	.long 0xd41e0001                                           // 000000082954: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v16, vcc_lo              // 000000082958: 020220FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082960: BF870001
	v_cndmask_b32_e64 v16, 0x7f800000, v19, s1                 // 000000082964: D5010010 000626FF 7F800000
	ds_store_b32 v26, v17                                      // 000000082970: D8340000 0000111A
	ds_store_b32 v27, v16                                      // 000000082978: D8340000 0000101B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000082980: 8C7E047E
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v16, v8           // 000000082984: CA100109 11100108
	s_mov_b32 s10, 0                                           // 00000008298C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000082990: BF89FC07
	s_barrier                                                  // 000000082994: BFBD0000
	buffer_gl0_inv                                             // 000000082998: E0AC0000 00000000
	s_branch 15                                                // 0000000829A0: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000829A4: 8C7E047E
	.long 0xd7000110                                           // 0000000829A8: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 0000000829AC: 020220FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000829B4: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 0000000829B8: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 0000000829C0: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000829C4: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000829C8: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 0000000829CC: BF89FC07
	s_barrier                                                  // 0000000829D0: BFBD0000
	buffer_gl0_inv                                             // 0000000829D4: E0AC0000 00000000
	s_cbranch_scc1 694                                         // 0000000829DC: BFA202B6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfb8>
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 0000000829E0: CA100111 13120110
	v_dual_mov_b32 v20, v25 :: v_dual_mov_b32 v21, v23         // 0000000829E8: CA100119 14140117
	s_mov_b32 s11, 0                                           // 0000000829F0: BE8B0080
	s_nop 0                                                    // 0000000829F4: BF800000
	s_nop 0                                                    // 0000000829F8: BF800000
	s_nop 0                                                    // 0000000829FC: BF800000
	global_load_b32 v44, v[18:19], off                         // 000000082A00: DC520000 2C7C0012
	v_add_nc_u32_e32 v21, 0x80, v21                            // 000000082A08: 4A2A2AFF 00000080
	.long 0xd7000112                                           // 000000082A10: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 000000082A14: 020224FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000082A1C: BF870191
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000082A20: D5207C13 00062680
	.long 0xd4490004                                           // 000000082A28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v21, vcc_lo                   // 000000082A2C: 02022AFF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000082A34: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000082A38: BF8903F7
	ds_store_b32 v20, v44 offset:13056                         // 000000082A3C: D8343300 00002C14
	v_add_nc_u32_e32 v20, 0x204, v20                           // 000000082A44: 4A2828FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000082A4C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000082A50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x500>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000082A54: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000082A58: BF89FC07
	s_barrier                                                  // 000000082A5C: BFBD0000
	buffer_gl0_inv                                             // 000000082A60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000082A68: BE842000
	s_cbranch_execz 65485                                      // 000000082A6C: BFA5FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a4>
	ds_load_2addr_b32 v[18:19], v31 offset1:1                  // 000000082A70: D8DC0100 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:2 offset1:3        // 000000082A78: D8DC0302 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:4 offset1:5        // 000000082A80: D8DC0504 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:6 offset1:7        // 000000082A88: D8DC0706 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset1:17                  // 000000082A90: D8DC1100 30000001
	ds_load_2addr_b32 v[50:51], v1 offset0:34 offset1:51       // 000000082A98: D8DC3322 32000001
	ds_load_2addr_b32 v[52:53], v1 offset0:68 offset1:85       // 000000082AA0: D8DC5544 34000001
	ds_load_2addr_b32 v[54:55], v1 offset0:102 offset1:119     // 000000082AA8: D8DC7766 36000001
	ds_load_2addr_b32 v[58:59], v31 offset0:14 offset1:15      // 000000082AB0: D8DC0F0E 3A00001F
	ds_load_2addr_b32 v[60:61], v1 offset0:136 offset1:153     // 000000082AB8: D8DC9988 3C000001
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 000000082AC0: D8DCBBAA 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:204 offset1:221     // 000000082AC8: D8DCDDCC 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:238 offset1:255     // 000000082AD0: D8DCFFEE 42000001
	v_or3_b32 v56, s10, s7, v2                                 // 000000082AD8: D6580038 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AE0: BF870091
	v_mad_u64_u32 v[56:57], null, v56, 48, s[2:3]              // 000000082AE4: D6FE7C38 00096138
	.long 0xd73c0038                                           // 000000082AEC: D73C0038
	v_cndmask_b32_e32 v1, 9, v56, vcc_lo                       // 000000082AF0: 02027089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AF4: BF870091
	.long 0xd7000138                                           // 000000082AF8: D7000138
	v_cndmask_b32_e32 v1, v29, v56, vcc_lo                     // 000000082AFC: 0202711D
	v_add_co_ci_u32_e64 v57, null, v30, v57, s1                // 000000082B00: D5207C39 0006731E
	global_load_b32 v56, v[56:57], off                         // 000000082B08: DC520000 387C0038
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 000000082B10: BF890087
	v_fma_f32 v18, -v18, v48, v56                              // 000000082B14: D6130012 24E26112
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000082B1C: BF8700A1
	v_fma_f32 v18, -v19, v49, v18                              // 000000082B20: D6130012 244A6313
	s_waitcnt lgkmcnt(7)                                       // 000000082B28: BF89FC77
	v_fma_f32 v20, -v20, v50, v18                              // 000000082B2C: D6130014 244A6514
	ds_load_2addr_b32 v[18:19], v31 offset0:8 offset1:9        // 000000082B34: D8DC0908 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:10 offset1:11      // 000000082B3C: D8DC0B0A 3000001F
	ds_load_2addr_b32 v[56:57], v31 offset0:12 offset1:13      // 000000082B44: D8DC0D0C 3800001F
	v_fma_f32 v20, -v21, v51, v20                              // 000000082B4C: D6130014 24526715
	s_waitcnt lgkmcnt(9)                                       // 000000082B54: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B58: BF870091
	v_fma_f32 v20, -v44, v52, v20                              // 000000082B5C: D6130014 2452692C
	v_fma_f32 v20, -v45, v53, v20                              // 000000082B64: D6130014 24526B2D
	s_waitcnt lgkmcnt(8)                                       // 000000082B6C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B70: BF870091
	v_fma_f32 v20, -v46, v54, v20                              // 000000082B74: D6130014 24526D2E
	v_fma_f32 v20, -v47, v55, v20                              // 000000082B7C: D6130014 24526F2F
	s_waitcnt lgkmcnt(2)                                       // 000000082B84: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B88: BF870091
	v_fma_f32 v18, -v18, v60, v20                              // 000000082B8C: D6130012 24527912
	v_fma_f32 v18, -v19, v61, v18                              // 000000082B94: D6130012 244A7B13
	s_waitcnt lgkmcnt(1)                                       // 000000082B9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082BA0: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 000000082BA4: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:16 offset1:17      // 000000082BAC: D8DC1110 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:18 offset1:19      // 000000082BB4: D8DC1312 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:20 offset1:21      // 000000082BBC: D8DC1514 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:22 offset1:23      // 000000082BC4: D8DC1716 2E00001F
	ds_load_2addr_b32 v[50:51], v32 offset0:16 offset1:33      // 000000082BCC: D8DC2110 32000020
	ds_load_2addr_b32 v[52:53], v32 offset0:50 offset1:67      // 000000082BD4: D8DC4332 34000020
	ds_load_2addr_b32 v[54:55], v32 offset0:84 offset1:101     // 000000082BDC: D8DC6554 36000020
	ds_load_2addr_b32 v[60:61], v32 offset0:118 offset1:135    // 000000082BE4: D8DC8776 3C000020
	v_fma_f32 v48, -v49, v63, v48                              // 000000082BEC: D6130030 24C27F31
	s_waitcnt lgkmcnt(8)                                       // 000000082BF4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082BF8: BF870091
	v_fma_f32 v48, -v56, v64, v48                              // 000000082BFC: D6130030 24C28138
	v_fma_f32 v48, -v57, v65, v48                              // 000000082C04: D6130030 24C28339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082C0C: BF870091
	v_fma_f32 v48, -v58, v66, v48                              // 000000082C10: D6130030 24C2853A
	v_fma_f32 v48, -v59, v67, v48                              // 000000082C18: D6130030 24C2873B
	s_waitcnt lgkmcnt(3)                                       // 000000082C20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082C24: BF870091
	v_fma_f32 v18, -v18, v50, v48                              // 000000082C28: D6130012 24C26512
	v_fma_f32 v18, -v19, v51, v18                              // 000000082C30: D6130012 244A6713
	s_waitcnt lgkmcnt(2)                                       // 000000082C38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082C3C: BF870001
	v_fma_f32 v20, -v20, v52, v18                              // 000000082C40: D6130014 244A6914
	ds_load_2addr_b32 v[18:19], v31 offset0:24 offset1:25      // 000000082C48: D8DC1918 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:26 offset1:27      // 000000082C50: D8DC1B1A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:28 offset1:29      // 000000082C58: D8DC1D1C 3200001F
	ds_load_2addr_b32 v[56:57], v31 offset0:30 offset1:31      // 000000082C60: D8DC1F1E 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:152 offset1:169    // 000000082C68: D8DCA998 3A000020
	ds_load_2addr_b32 v[62:63], v32 offset0:186 offset1:203    // 000000082C70: D8DCCBBA 3E000020
	ds_load_2addr_b32 v[64:65], v32 offset0:220 offset1:237    // 000000082C78: D8DCEDDC 40000020
	ds_load_2addr_b32 v[66:67], v33 offset0:126 offset1:143    // 000000082C80: D8DC8F7E 42000021
	v_fma_f32 v20, -v21, v53, v20                              // 000000082C88: D6130014 24526B15
	s_waitcnt lgkmcnt(9)                                       // 000000082C90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082C94: BF870091
	v_fma_f32 v20, -v44, v54, v20                              // 000000082C98: D6130014 24526D2C
	v_fma_f32 v20, -v45, v55, v20                              // 000000082CA0: D6130014 24526F2D
	s_waitcnt lgkmcnt(8)                                       // 000000082CA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082CAC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 000000082CB0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 000000082CB8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000082CC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082CC4: BF870091
	v_fma_f32 v18, -v18, v58, v20                              // 000000082CC8: D6130012 24527512
	v_fma_f32 v18, -v19, v59, v18                              // 000000082CD0: D6130012 244A7713
	s_waitcnt lgkmcnt(2)                                       // 000000082CD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082CDC: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 000000082CE0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:32 offset1:33      // 000000082CE8: D8DC2120 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:34 offset1:35      // 000000082CF0: D8DC2322 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:36 offset1:37      // 000000082CF8: D8DC2524 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:38 offset1:39      // 000000082D00: D8DC2726 2E00001F
	ds_load_2addr_b32 v[52:53], v34 offset0:32 offset1:49      // 000000082D08: D8DC3120 34000022
	ds_load_2addr_b32 v[54:55], v34 offset0:66 offset1:83      // 000000082D10: D8DC5342 36000022
	ds_load_2addr_b32 v[58:59], v34 offset0:100 offset1:117    // 000000082D18: D8DC7564 3A000022
	ds_load_2addr_b32 v[60:61], v34 offset0:134 offset1:151    // 000000082D20: D8DC9786 3C000022
	v_fma_f32 v48, -v49, v63, v48                              // 000000082D28: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 000000082D30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D34: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 000000082D38: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000082D40: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000082D48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D4C: BF870091
	v_fma_f32 v48, -v56, v66, v48                              // 000000082D50: D6130030 24C28538
	v_fma_f32 v48, -v57, v67, v48                              // 000000082D58: D6130030 24C28739
	s_waitcnt lgkmcnt(3)                                       // 000000082D60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D64: BF870091
	v_fma_f32 v18, -v18, v52, v48                              // 000000082D68: D6130012 24C26912
	v_fma_f32 v18, -v19, v53, v18                              // 000000082D70: D6130012 244A6B13
	s_waitcnt lgkmcnt(2)                                       // 000000082D78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082D7C: BF870001
	v_fma_f32 v20, -v20, v54, v18                              // 000000082D80: D6130014 244A6D14
	ds_load_2addr_b32 v[18:19], v31 offset0:40 offset1:41      // 000000082D88: D8DC2928 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:42 offset1:43      // 000000082D90: D8DC2B2A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:44 offset1:45      // 000000082D98: D8DC2D2C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:46 offset1:47      // 000000082DA0: D8DC2F2E 3400001F
	ds_load_2addr_b32 v[56:57], v34 offset0:168 offset1:185    // 000000082DA8: D8DCB9A8 38000022
	ds_load_2addr_b32 v[62:63], v34 offset0:202 offset1:219    // 000000082DB0: D8DCDBCA 3E000022
	ds_load_2addr_b32 v[64:65], v34 offset0:236 offset1:253    // 000000082DB8: D8DCFDEC 40000022
	ds_load_2addr_b32 v[66:67], v35 offset0:14 offset1:31      // 000000082DC0: D8DC1F0E 42000023
	v_fma_f32 v20, -v21, v55, v20                              // 000000082DC8: D6130014 24526F15
	s_waitcnt lgkmcnt(9)                                       // 000000082DD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082DD4: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 000000082DD8: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 000000082DE0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 000000082DE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082DEC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 000000082DF0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 000000082DF8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000082E00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E04: BF870091
	v_fma_f32 v18, -v18, v56, v20                              // 000000082E08: D6130012 24527112
	v_fma_f32 v18, -v19, v57, v18                              // 000000082E10: D6130012 244A7313
	s_waitcnt lgkmcnt(2)                                       // 000000082E18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082E1C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 000000082E20: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:48 offset1:49      // 000000082E28: D8DC3130 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:50 offset1:51      // 000000082E30: D8DC3332 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:52 offset1:53      // 000000082E38: D8DC3534 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:54 offset1:55      // 000000082E40: D8DC3736 2E00001F
	ds_load_2addr_b32 v[54:55], v35 offset0:48 offset1:65      // 000000082E48: D8DC4130 36000023
	ds_load_2addr_b32 v[56:57], v35 offset0:82 offset1:99      // 000000082E50: D8DC6352 38000023
	ds_load_2addr_b32 v[58:59], v35 offset0:116 offset1:133    // 000000082E58: D8DC8574 3A000023
	ds_load_2addr_b32 v[60:61], v35 offset0:150 offset1:167    // 000000082E60: D8DCA796 3C000023
	v_fma_f32 v48, -v49, v63, v48                              // 000000082E68: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 000000082E70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E74: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 000000082E78: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000082E80: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000082E88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E8C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 000000082E90: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 000000082E98: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 000000082EA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082EA4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 000000082EA8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000082EB0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000082EB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082EBC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 000000082EC0: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:56 offset1:57      // 000000082EC8: D8DC3938 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:58 offset1:59      // 000000082ED0: D8DC3B3A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:60 offset1:61      // 000000082ED8: D8DC3D3C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:62 offset1:63      // 000000082EE0: D8DC3F3E 3400001F
	ds_load_2addr_b32 v[54:55], v35 offset0:184 offset1:201    // 000000082EE8: D8DCC9B8 36000023
	ds_load_2addr_b32 v[62:63], v35 offset0:218 offset1:235    // 000000082EF0: D8DCEBDA 3E000023
	ds_load_2addr_b32 v[64:65], v36 offset0:124 offset1:141    // 000000082EF8: D8DC8D7C 40000024
	ds_load_2addr_b32 v[66:67], v37 offset0:30 offset1:47      // 000000082F00: D8DC2F1E 42000025
	v_fma_f32 v20, -v21, v57, v20                              // 000000082F08: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 000000082F10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F14: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 000000082F18: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 000000082F20: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 000000082F28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F2C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 000000082F30: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 000000082F38: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000082F40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F44: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 000000082F48: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000082F50: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000082F58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082F5C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 000000082F60: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:64 offset1:65      // 000000082F68: D8DC4140 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:66 offset1:67      // 000000082F70: D8DC4342 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:68 offset1:69      // 000000082F78: D8DC4544 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:70 offset1:71      // 000000082F80: D8DC4746 2E00001F
	ds_load_2addr_b32 v[54:55], v37 offset0:64 offset1:81      // 000000082F88: D8DC5140 36000025
	ds_load_2addr_b32 v[56:57], v37 offset0:98 offset1:115     // 000000082F90: D8DC7362 38000025
	ds_load_2addr_b32 v[58:59], v37 offset0:132 offset1:149    // 000000082F98: D8DC9584 3A000025
	ds_load_2addr_b32 v[60:61], v37 offset0:166 offset1:183    // 000000082FA0: D8DCB7A6 3C000025
	v_fma_f32 v48, -v49, v63, v48                              // 000000082FA8: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 000000082FB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082FB4: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 000000082FB8: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000082FC0: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000082FC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082FCC: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 000000082FD0: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 000000082FD8: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 000000082FE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082FE4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 000000082FE8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000082FF0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000082FF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082FFC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 000000083000: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:72 offset1:73      // 000000083008: D8DC4948 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:74 offset1:75      // 000000083010: D8DC4B4A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:76 offset1:77      // 000000083018: D8DC4D4C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:78 offset1:79      // 000000083020: D8DC4F4E 3400001F
	ds_load_2addr_b32 v[54:55], v37 offset0:200 offset1:217    // 000000083028: D8DCD9C8 36000025
	ds_load_2addr_b32 v[62:63], v37 offset0:234 offset1:251    // 000000083030: D8DCFBEA 3E000025
	ds_load_2addr_b32 v[64:65], v38 offset0:12 offset1:29      // 000000083038: D8DC1D0C 40000026
	ds_load_2addr_b32 v[66:67], v38 offset0:46 offset1:63      // 000000083040: D8DC3F2E 42000026
	v_fma_f32 v20, -v21, v57, v20                              // 000000083048: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 000000083050: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083054: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 000000083058: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 000000083060: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 000000083068: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008306C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 000000083070: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 000000083078: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000083080: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083084: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 000000083088: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000083090: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000083098: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008309C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 0000000830A0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:80 offset1:81      // 0000000830A8: D8DC5150 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:82 offset1:83      // 0000000830B0: D8DC5352 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:84 offset1:85      // 0000000830B8: D8DC5554 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:86 offset1:87      // 0000000830C0: D8DC5756 2E00001F
	ds_load_2addr_b32 v[54:55], v38 offset0:80 offset1:97      // 0000000830C8: D8DC6150 36000026
	ds_load_2addr_b32 v[56:57], v38 offset0:114 offset1:131    // 0000000830D0: D8DC8372 38000026
	ds_load_2addr_b32 v[58:59], v38 offset0:148 offset1:165    // 0000000830D8: D8DCA594 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:182 offset1:199    // 0000000830E0: D8DCC7B6 3C000026
	v_fma_f32 v48, -v49, v63, v48                              // 0000000830E8: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 0000000830F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000830F4: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 0000000830F8: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000083100: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000083108: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008310C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 000000083110: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 000000083118: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 000000083120: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083124: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 000000083128: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000083130: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000083138: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008313C: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 000000083140: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:88 offset1:89      // 000000083148: D8DC5958 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:90 offset1:91      // 000000083150: D8DC5B5A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:92 offset1:93      // 000000083158: D8DC5D5C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:94 offset1:95      // 000000083160: D8DC5F5E 3400001F
	ds_load_2addr_b32 v[54:55], v38 offset0:216 offset1:233    // 000000083168: D8DCE9D8 36000026
	ds_load_2addr_b32 v[62:63], v39 offset0:122 offset1:139    // 000000083170: D8DC8B7A 3E000027
	ds_load_2addr_b32 v[64:65], v40 offset0:28 offset1:45      // 000000083178: D8DC2D1C 40000028
	ds_load_2addr_b32 v[66:67], v40 offset0:62 offset1:79      // 000000083180: D8DC4F3E 42000028
	v_fma_f32 v20, -v21, v57, v20                              // 000000083188: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 000000083190: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083194: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 000000083198: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 0000000831A0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 0000000831A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831AC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 0000000831B0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 0000000831B8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 0000000831C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831C4: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 0000000831C8: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 0000000831D0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 0000000831D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000831DC: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 0000000831E0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:96 offset1:97      // 0000000831E8: D8DC6160 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:98 offset1:99      // 0000000831F0: D8DC6362 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:100 offset1:101    // 0000000831F8: D8DC6564 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:102 offset1:103    // 000000083200: D8DC6766 2E00001F
	ds_load_2addr_b32 v[54:55], v40 offset0:96 offset1:113     // 000000083208: D8DC7160 36000028
	ds_load_2addr_b32 v[56:57], v40 offset0:130 offset1:147    // 000000083210: D8DC9382 38000028
	ds_load_2addr_b32 v[58:59], v40 offset0:164 offset1:181    // 000000083218: D8DCB5A4 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:198 offset1:215    // 000000083220: D8DCD7C6 3C000028
	v_fma_f32 v48, -v49, v63, v48                              // 000000083228: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 000000083230: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083234: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 000000083238: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000083240: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000083248: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008324C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 000000083250: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 000000083258: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 000000083260: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083264: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 000000083268: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000083270: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000083278: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008327C: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 000000083280: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:104 offset1:105    // 000000083288: D8DC6968 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:106 offset1:107    // 000000083290: D8DC6B6A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:108 offset1:109    // 000000083298: D8DC6D6C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:110 offset1:111    // 0000000832A0: D8DC6F6E 3400001F
	ds_load_2addr_b32 v[54:55], v40 offset0:232 offset1:249    // 0000000832A8: D8DCF9E8 36000028
	ds_load_2addr_b32 v[62:63], v41 offset0:10 offset1:27      // 0000000832B0: D8DC1B0A 3E000029
	ds_load_2addr_b32 v[64:65], v41 offset0:44 offset1:61      // 0000000832B8: D8DC3D2C 40000029
	ds_load_2addr_b32 v[66:67], v41 offset0:78 offset1:95      // 0000000832C0: D8DC5F4E 42000029
	v_fma_f32 v20, -v21, v57, v20                              // 0000000832C8: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 0000000832D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832D4: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 0000000832D8: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 0000000832E0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 0000000832E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832EC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 0000000832F0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 0000000832F8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000083300: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083304: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 000000083308: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000083310: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000083318: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008331C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 000000083320: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:112 offset1:113    // 000000083328: D8DC7170 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:114 offset1:115    // 000000083330: D8DC7372 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:116 offset1:117    // 000000083338: D8DC7574 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:118 offset1:119    // 000000083340: D8DC7776 2E00001F
	ds_load_2addr_b32 v[54:55], v41 offset0:112 offset1:129    // 000000083348: D8DC8170 36000029
	ds_load_2addr_b32 v[56:57], v41 offset0:146 offset1:163    // 000000083350: D8DCA392 38000029
	ds_load_2addr_b32 v[58:59], v41 offset0:180 offset1:197    // 000000083358: D8DCC5B4 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:214 offset1:231    // 000000083360: D8DCE7D6 3C000029
	v_fma_f32 v48, -v49, v63, v48                              // 000000083368: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 000000083370: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083374: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 000000083378: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 000000083380: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 000000083388: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008338C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 000000083390: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 000000083398: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 0000000833A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000833A4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 0000000833A8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 0000000833B0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 0000000833B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000833BC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 0000000833C0: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:120 offset1:121    // 0000000833C8: D8DC7978 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:122 offset1:123    // 0000000833D0: D8DC7B7A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:124 offset1:125    // 0000000833D8: D8DC7D7C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:126 offset1:127    // 0000000833E0: D8DC7F7E 3400001F
	ds_load_2addr_b32 v[54:55], v42 offset0:120 offset1:137    // 0000000833E8: D8DC8978 3600002A
	ds_load_2addr_b32 v[62:63], v43 offset0:26 offset1:43      // 0000000833F0: D8DC2B1A 3E00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:60 offset1:77      // 0000000833F8: D8DC4D3C 4000002B
	ds_load_2addr_b32 v[66:67], v43 offset0:94 offset1:111     // 000000083400: D8DC6F5E 4200002B
	v_fma_f32 v20, -v21, v57, v20                              // 000000083408: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 000000083410: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083414: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 000000083418: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 000000083420: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 000000083428: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008342C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 000000083430: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 000000083438: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 000000083440: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083444: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 000000083448: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 000000083450: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 000000083458: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008345C: BF870091
	v_fma_f32 v18, -v48, v62, v18                              // 000000083460: D6130012 244A7D30
	v_fma_f32 v18, -v49, v63, v18                              // 000000083468: D6130012 244A7F31
	s_waitcnt lgkmcnt(1)                                       // 000000083470: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083474: BF870091
	v_fma_f32 v18, -v50, v64, v18                              // 000000083478: D6130012 244A8132
	v_fma_f32 v18, -v51, v65, v18                              // 000000083480: D6130012 244A8333
	s_waitcnt lgkmcnt(0)                                       // 000000083488: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008348C: BF870121
	v_fma_f32 v20, -v52, v66, v18                              // 000000083490: D6130014 244A8534
	v_mad_u64_u32 v[18:19], null, 0x44, s10, v[4:5]            // 000000083498: D6FE7C12 041014FF 00000044
	v_fma_f32 v19, -v53, v67, v20                              // 0000000834A4: D6130013 24528735
	ds_store_b32 v18, v19                                      // 0000000834AC: D8340000 00001312
	s_branch 64827                                             // 0000000834B4: BFA0FD3B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a4>
	v_mov_b32_e32 v17, v13                                     // 0000000834B8: 7E22030D
	v_dual_mov_b32 v19, v11 :: v_dual_mov_b32 v16, v12         // 0000000834BC: CA10010B 1310010C
	v_mov_b32_e32 v18, v10                                     // 0000000834C4: 7E24030A
	v_mov_b32_e32 v44, v28                                     // 0000000834C8: 7E58031C
	s_mov_b32 s10, 0                                           // 0000000834CC: BE8A0080
	s_branch 21                                                // 0000000834D0: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1028>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000834D4: 8C7E0B7E
	.long 0xd7000112                                           // 0000000834D8: D7000112
	v_cndmask_b32_e32 v1, 0x30000, v18, vcc_lo                 // 0000000834DC: 020224FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000834E4: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 0000000834E8: D5207C13 00062680
	.long 0xd7000110                                           // 0000000834F0: D7000110
	v_cndmask_b32_e32 v1, 0x800, v16, vcc_lo                   // 0000000834F4: 020220FF 00000800
	v_add_nc_u32_e32 v44, 8, v44                               // 0000000834FC: 4A585888
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000083500: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 000000083508: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000008350C: BF08B70A
	s_mov_b32 s10, s1                                          // 000000083510: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 000000083514: BC7C0000
	s_barrier                                                  // 000000083518: BFBD0000
	buffer_gl0_inv                                             // 00000008351C: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 000000083524: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000083528: BF870002
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v20, v18         // 00000008352C: CA100113 15140112
	v_dual_mov_b32 v45, v25 :: v_dual_mov_b32 v46, v23         // 000000083534: CA100119 2D2E0117
	s_mov_b32 s11, 0                                           // 00000008353C: BE8B0080
	global_load_b32 v47, v[20:21], off                         // 000000083540: DC520000 2F7C0014
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000083548: 4A5C5CFF 00000080
	.long 0xd7000114                                           // 000000083550: D7000114
	v_cndmask_b32_e32 v1, 0x6000, v20, vcc_lo                  // 000000083554: 020228FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008355C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 000000083560: D5207C15 00062A80
	.long 0xd4490004                                           // 000000083568: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000008356C: 02025CFF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000083574: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000083578: BF8903F7
	ds_store_b32 v45, v47 offset:13056                         // 00000008357C: D8343300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 000000083584: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000008358C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000083590: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1040>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000083594: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000083598: BF89FC07
	s_barrier                                                  // 00000008359C: BFBD0000
	buffer_gl0_inv                                             // 0000000835A0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000835A8: BE8B2000
	s_cbranch_execz 65481                                      // 0000000835AC: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	v_or_b32_e32 v20, s10, v2                                  // 0000000835B0: 3828040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000835B4: BF870091
	v_or_b32_e32 v45, s7, v20                                  // 0000000835B8: 385A2807
	.long 0xd4440001                                           // 0000000835BC: D4440001
	v_cndmask_b32_e32 v1, s30, v45, vcc_lo                     // 0000000835C0: 02025A1E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000835C4: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000835C8: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	ds_load_2addr_b32 v[46:47], v31 offset1:1                  // 0000000835CC: D8DC0100 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset1:17                  // 0000000835D4: D8DC1100 30000001
	ds_load_2addr_b32 v[50:51], v31 offset0:2 offset1:3        // 0000000835DC: D8DC0302 3200001F
	ds_load_2addr_b32 v[52:53], v1 offset0:34 offset1:51       // 0000000835E4: D8DC3322 34000001
	ds_load_2addr_b32 v[54:55], v31 offset0:4 offset1:5        // 0000000835EC: D8DC0504 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:6 offset1:7        // 0000000835F4: D8DC0706 3800001F
	ds_load_2addr_b32 v[58:59], v1 offset0:68 offset1:85       // 0000000835FC: D8DC5544 3A000001
	ds_load_2addr_b32 v[60:61], v1 offset0:102 offset1:119     // 000000083604: D8DC7766 3C000001
	s_mov_b32 s12, 0                                           // 00000008360C: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 000000083610: BF89FC67
	v_fma_f32 v62, v46, v48, 0                                 // 000000083614: D613003E 0202612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008361C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083620: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083624: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083628: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008362C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083630: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083634: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083638: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008363C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083640: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083644: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083648: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008364C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083650: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:8 offset1:9        // 000000083654: D8DC0908 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset0:136 offset1:153     // 00000008365C: D8DC9988 30000001
	ds_load_2addr_b32 v[50:51], v31 offset0:10 offset1:11      // 000000083664: D8DC0B0A 3200001F
	ds_load_2addr_b32 v[52:53], v1 offset0:170 offset1:187     // 00000008366C: D8DCBBAA 34000001
	ds_load_2addr_b32 v[54:55], v31 offset0:12 offset1:13      // 000000083674: D8DC0D0C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:14 offset1:15      // 00000008367C: D8DC0F0E 3800001F
	ds_load_2addr_b32 v[58:59], v1 offset0:204 offset1:221     // 000000083684: D8DCDDCC 3A000001
	ds_load_2addr_b32 v[60:61], v1 offset0:238 offset1:255     // 00000008368C: D8DCFFEE 3C000001
	s_waitcnt lgkmcnt(6)                                       // 000000083694: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083698: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008369C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 0000000836A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 0000000836A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 0000000836A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000836AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 0000000836B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 0000000836B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 0000000836B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000836BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 0000000836C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 0000000836C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 0000000836C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000836CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 0000000836D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:16 offset1:17      // 0000000836D4: D8DC1110 2E00001F
	ds_load_2addr_b32 v[48:49], v32 offset0:16 offset1:33      // 0000000836DC: D8DC2110 30000020
	ds_load_2addr_b32 v[50:51], v31 offset0:18 offset1:19      // 0000000836E4: D8DC1312 3200001F
	ds_load_2addr_b32 v[52:53], v32 offset0:50 offset1:67      // 0000000836EC: D8DC4332 34000020
	ds_load_2addr_b32 v[54:55], v31 offset0:20 offset1:21      // 0000000836F4: D8DC1514 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:22 offset1:23      // 0000000836FC: D8DC1716 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:84 offset1:101     // 000000083704: D8DC6554 3A000020
	ds_load_2addr_b32 v[60:61], v32 offset0:118 offset1:135    // 00000008370C: D8DC8776 3C000020
	s_waitcnt lgkmcnt(6)                                       // 000000083714: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083718: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008371C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083720: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083724: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083728: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008372C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083730: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083734: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083738: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008373C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083740: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083744: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083748: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008374C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083750: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:24 offset1:25      // 000000083754: D8DC1918 2E00001F
	ds_load_2addr_b32 v[48:49], v32 offset0:152 offset1:169    // 00000008375C: D8DCA998 30000020
	ds_load_2addr_b32 v[50:51], v31 offset0:26 offset1:27      // 000000083764: D8DC1B1A 3200001F
	ds_load_2addr_b32 v[52:53], v32 offset0:186 offset1:203    // 00000008376C: D8DCCBBA 34000020
	ds_load_2addr_b32 v[54:55], v31 offset0:28 offset1:29      // 000000083774: D8DC1D1C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:30 offset1:31      // 00000008377C: D8DC1F1E 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:220 offset1:237    // 000000083784: D8DCEDDC 3A000020
	ds_load_2addr_b32 v[60:61], v33 offset0:126 offset1:143    // 00000008378C: D8DC8F7E 3C000021
	s_waitcnt lgkmcnt(6)                                       // 000000083794: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083798: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008379C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 0000000837A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 0000000837A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 0000000837A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000837AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 0000000837B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 0000000837B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 0000000837B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000837BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 0000000837C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 0000000837C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 0000000837C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000837CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 0000000837D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:32 offset1:33      // 0000000837D4: D8DC2120 2E00001F
	ds_load_2addr_b32 v[48:49], v34 offset0:32 offset1:49      // 0000000837DC: D8DC3120 30000022
	ds_load_2addr_b32 v[50:51], v31 offset0:34 offset1:35      // 0000000837E4: D8DC2322 3200001F
	ds_load_2addr_b32 v[52:53], v34 offset0:66 offset1:83      // 0000000837EC: D8DC5342 34000022
	ds_load_2addr_b32 v[54:55], v31 offset0:36 offset1:37      // 0000000837F4: D8DC2524 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:38 offset1:39      // 0000000837FC: D8DC2726 3800001F
	ds_load_2addr_b32 v[58:59], v34 offset0:100 offset1:117    // 000000083804: D8DC7564 3A000022
	ds_load_2addr_b32 v[60:61], v34 offset0:134 offset1:151    // 00000008380C: D8DC9786 3C000022
	s_waitcnt lgkmcnt(6)                                       // 000000083814: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083818: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008381C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083820: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083824: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083828: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008382C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083830: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083834: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083838: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008383C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083840: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083844: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083848: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008384C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083850: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:40 offset1:41      // 000000083854: D8DC2928 2E00001F
	ds_load_2addr_b32 v[48:49], v34 offset0:168 offset1:185    // 00000008385C: D8DCB9A8 30000022
	ds_load_2addr_b32 v[50:51], v31 offset0:42 offset1:43      // 000000083864: D8DC2B2A 3200001F
	ds_load_2addr_b32 v[52:53], v34 offset0:202 offset1:219    // 00000008386C: D8DCDBCA 34000022
	ds_load_2addr_b32 v[54:55], v31 offset0:44 offset1:45      // 000000083874: D8DC2D2C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:46 offset1:47      // 00000008387C: D8DC2F2E 3800001F
	ds_load_2addr_b32 v[58:59], v34 offset0:236 offset1:253    // 000000083884: D8DCFDEC 3A000022
	ds_load_2addr_b32 v[60:61], v35 offset0:14 offset1:31      // 00000008388C: D8DC1F0E 3C000023
	s_waitcnt lgkmcnt(6)                                       // 000000083894: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083898: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008389C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 0000000838A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 0000000838A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 0000000838A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000838AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 0000000838B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 0000000838B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 0000000838B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000838BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 0000000838C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 0000000838C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 0000000838C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000838CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 0000000838D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:48 offset1:49      // 0000000838D4: D8DC3130 2E00001F
	ds_load_2addr_b32 v[48:49], v35 offset0:48 offset1:65      // 0000000838DC: D8DC4130 30000023
	ds_load_2addr_b32 v[50:51], v31 offset0:50 offset1:51      // 0000000838E4: D8DC3332 3200001F
	ds_load_2addr_b32 v[52:53], v35 offset0:82 offset1:99      // 0000000838EC: D8DC6352 34000023
	ds_load_2addr_b32 v[54:55], v31 offset0:52 offset1:53      // 0000000838F4: D8DC3534 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:54 offset1:55      // 0000000838FC: D8DC3736 3800001F
	ds_load_2addr_b32 v[58:59], v35 offset0:116 offset1:133    // 000000083904: D8DC8574 3A000023
	ds_load_2addr_b32 v[60:61], v35 offset0:150 offset1:167    // 00000008390C: D8DCA796 3C000023
	s_waitcnt lgkmcnt(6)                                       // 000000083914: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083918: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008391C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083920: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083924: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083928: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008392C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083930: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083934: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083938: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008393C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083940: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083944: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083948: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008394C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083950: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:56 offset1:57      // 000000083954: D8DC3938 2E00001F
	ds_load_2addr_b32 v[48:49], v35 offset0:184 offset1:201    // 00000008395C: D8DCC9B8 30000023
	ds_load_2addr_b32 v[50:51], v31 offset0:58 offset1:59      // 000000083964: D8DC3B3A 3200001F
	ds_load_2addr_b32 v[52:53], v35 offset0:218 offset1:235    // 00000008396C: D8DCEBDA 34000023
	ds_load_2addr_b32 v[54:55], v31 offset0:60 offset1:61      // 000000083974: D8DC3D3C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:62 offset1:63      // 00000008397C: D8DC3F3E 3800001F
	ds_load_2addr_b32 v[58:59], v36 offset0:124 offset1:141    // 000000083984: D8DC8D7C 3A000024
	ds_load_2addr_b32 v[60:61], v37 offset0:30 offset1:47      // 00000008398C: D8DC2F1E 3C000025
	s_waitcnt lgkmcnt(6)                                       // 000000083994: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083998: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008399C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 0000000839A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 0000000839A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 0000000839A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000839AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 0000000839B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 0000000839B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 0000000839B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000839BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 0000000839C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 0000000839C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 0000000839C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000839CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 0000000839D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:64 offset1:65      // 0000000839D4: D8DC4140 2E00001F
	ds_load_2addr_b32 v[48:49], v37 offset0:64 offset1:81      // 0000000839DC: D8DC5140 30000025
	ds_load_2addr_b32 v[50:51], v31 offset0:66 offset1:67      // 0000000839E4: D8DC4342 3200001F
	ds_load_2addr_b32 v[52:53], v37 offset0:98 offset1:115     // 0000000839EC: D8DC7362 34000025
	ds_load_2addr_b32 v[54:55], v31 offset0:68 offset1:69      // 0000000839F4: D8DC4544 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:70 offset1:71      // 0000000839FC: D8DC4746 3800001F
	ds_load_2addr_b32 v[58:59], v37 offset0:132 offset1:149    // 000000083A04: D8DC9584 3A000025
	ds_load_2addr_b32 v[60:61], v37 offset0:166 offset1:183    // 000000083A0C: D8DCB7A6 3C000025
	s_waitcnt lgkmcnt(6)                                       // 000000083A14: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083A18: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083A1C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083A20: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083A24: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083A28: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083A2C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083A30: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083A34: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083A38: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083A3C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083A40: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083A44: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083A48: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083A4C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083A50: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:72 offset1:73      // 000000083A54: D8DC4948 2E00001F
	ds_load_2addr_b32 v[48:49], v37 offset0:200 offset1:217    // 000000083A5C: D8DCD9C8 30000025
	ds_load_2addr_b32 v[50:51], v31 offset0:74 offset1:75      // 000000083A64: D8DC4B4A 3200001F
	ds_load_2addr_b32 v[52:53], v37 offset0:234 offset1:251    // 000000083A6C: D8DCFBEA 34000025
	ds_load_2addr_b32 v[54:55], v31 offset0:76 offset1:77      // 000000083A74: D8DC4D4C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:78 offset1:79      // 000000083A7C: D8DC4F4E 3800001F
	ds_load_2addr_b32 v[58:59], v38 offset0:12 offset1:29      // 000000083A84: D8DC1D0C 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:46 offset1:63      // 000000083A8C: D8DC3F2E 3C000026
	s_waitcnt lgkmcnt(6)                                       // 000000083A94: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083A98: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083A9C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083AA0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083AA4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083AA8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083AAC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083AB0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083AB4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083AB8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083ABC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083AC0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083AC4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083AC8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083ACC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083AD0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:80 offset1:81      // 000000083AD4: D8DC5150 2E00001F
	ds_load_2addr_b32 v[48:49], v38 offset0:80 offset1:97      // 000000083ADC: D8DC6150 30000026
	ds_load_2addr_b32 v[50:51], v31 offset0:82 offset1:83      // 000000083AE4: D8DC5352 3200001F
	ds_load_2addr_b32 v[52:53], v38 offset0:114 offset1:131    // 000000083AEC: D8DC8372 34000026
	ds_load_2addr_b32 v[54:55], v31 offset0:84 offset1:85      // 000000083AF4: D8DC5554 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:86 offset1:87      // 000000083AFC: D8DC5756 3800001F
	ds_load_2addr_b32 v[58:59], v38 offset0:148 offset1:165    // 000000083B04: D8DCA594 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:182 offset1:199    // 000000083B0C: D8DCC7B6 3C000026
	s_waitcnt lgkmcnt(6)                                       // 000000083B14: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083B18: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083B1C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083B20: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083B24: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083B28: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083B2C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083B30: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083B34: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083B38: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083B3C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083B40: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083B44: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083B48: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083B4C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083B50: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:88 offset1:89      // 000000083B54: D8DC5958 2E00001F
	ds_load_2addr_b32 v[48:49], v38 offset0:216 offset1:233    // 000000083B5C: D8DCE9D8 30000026
	ds_load_2addr_b32 v[50:51], v31 offset0:90 offset1:91      // 000000083B64: D8DC5B5A 3200001F
	ds_load_2addr_b32 v[52:53], v39 offset0:122 offset1:139    // 000000083B6C: D8DC8B7A 34000027
	ds_load_2addr_b32 v[54:55], v31 offset0:92 offset1:93      // 000000083B74: D8DC5D5C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:94 offset1:95      // 000000083B7C: D8DC5F5E 3800001F
	ds_load_2addr_b32 v[58:59], v40 offset0:28 offset1:45      // 000000083B84: D8DC2D1C 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:62 offset1:79      // 000000083B8C: D8DC4F3E 3C000028
	s_waitcnt lgkmcnt(6)                                       // 000000083B94: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083B98: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083B9C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083BA0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083BA4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083BA8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083BAC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083BB0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083BB4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083BB8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083BBC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083BC0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083BC4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083BC8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083BCC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083BD0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:96 offset1:97      // 000000083BD4: D8DC6160 2E00001F
	ds_load_2addr_b32 v[48:49], v40 offset0:96 offset1:113     // 000000083BDC: D8DC7160 30000028
	ds_load_2addr_b32 v[50:51], v31 offset0:98 offset1:99      // 000000083BE4: D8DC6362 3200001F
	ds_load_2addr_b32 v[52:53], v40 offset0:130 offset1:147    // 000000083BEC: D8DC9382 34000028
	ds_load_2addr_b32 v[54:55], v31 offset0:100 offset1:101    // 000000083BF4: D8DC6564 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:102 offset1:103    // 000000083BFC: D8DC6766 3800001F
	ds_load_2addr_b32 v[58:59], v40 offset0:164 offset1:181    // 000000083C04: D8DCB5A4 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:198 offset1:215    // 000000083C0C: D8DCD7C6 3C000028
	s_waitcnt lgkmcnt(6)                                       // 000000083C14: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083C18: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083C1C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083C20: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083C24: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083C28: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083C2C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083C30: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083C34: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083C38: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083C3C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083C40: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083C44: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083C48: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083C4C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083C50: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:104 offset1:105    // 000000083C54: D8DC6968 2E00001F
	ds_load_2addr_b32 v[48:49], v40 offset0:232 offset1:249    // 000000083C5C: D8DCF9E8 30000028
	ds_load_2addr_b32 v[50:51], v31 offset0:106 offset1:107    // 000000083C64: D8DC6B6A 3200001F
	ds_load_2addr_b32 v[52:53], v41 offset0:10 offset1:27      // 000000083C6C: D8DC1B0A 34000029
	ds_load_2addr_b32 v[54:55], v31 offset0:108 offset1:109    // 000000083C74: D8DC6D6C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:110 offset1:111    // 000000083C7C: D8DC6F6E 3800001F
	ds_load_2addr_b32 v[58:59], v41 offset0:44 offset1:61      // 000000083C84: D8DC3D2C 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:78 offset1:95      // 000000083C8C: D8DC5F4E 3C000029
	s_waitcnt lgkmcnt(6)                                       // 000000083C94: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083C98: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083C9C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083CA0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083CA4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083CA8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083CAC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083CB0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083CB4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083CB8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083CBC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083CC0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083CC4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083CC8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083CCC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083CD0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:112 offset1:113    // 000000083CD4: D8DC7170 2E00001F
	ds_load_2addr_b32 v[48:49], v41 offset0:112 offset1:129    // 000000083CDC: D8DC8170 30000029
	ds_load_2addr_b32 v[50:51], v31 offset0:114 offset1:115    // 000000083CE4: D8DC7372 3200001F
	ds_load_2addr_b32 v[52:53], v41 offset0:146 offset1:163    // 000000083CEC: D8DCA392 34000029
	ds_load_2addr_b32 v[54:55], v31 offset0:116 offset1:117    // 000000083CF4: D8DC7574 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:118 offset1:119    // 000000083CFC: D8DC7776 3800001F
	ds_load_2addr_b32 v[58:59], v41 offset0:180 offset1:197    // 000000083D04: D8DCC5B4 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:214 offset1:231    // 000000083D0C: D8DCE7D6 3C000029
	s_waitcnt lgkmcnt(6)                                       // 000000083D14: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083D18: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083D1C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 000000083D20: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 000000083D24: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 000000083D28: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083D2C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 000000083D30: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 000000083D34: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 000000083D38: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083D3C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 000000083D40: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 000000083D44: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 000000083D48: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083D4C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 000000083D50: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:120 offset1:121    // 000000083D54: D8DC7978 2E00001F
	ds_load_2addr_b32 v[48:49], v42 offset0:120 offset1:137    // 000000083D5C: D8DC8978 3000002A
	ds_load_2addr_b32 v[50:51], v31 offset0:122 offset1:123    // 000000083D64: D8DC7B7A 3200001F
	ds_load_2addr_b32 v[52:53], v43 offset0:26 offset1:43      // 000000083D6C: D8DC2B1A 3400002B
	ds_load_2addr_b32 v[54:55], v31 offset0:124 offset1:125    // 000000083D74: D8DC7D7C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:126 offset1:127    // 000000083D7C: D8DC7F7E 3800001F
	ds_load_2addr_b32 v[58:59], v43 offset0:60 offset1:77      // 000000083D84: D8DC4D3C 3A00002B
	ds_load_2addr_b32 v[60:61], v43 offset0:94 offset1:111     // 000000083D8C: D8DC6F5E 3C00002B
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000083D94: 30282882
	s_waitcnt lgkmcnt(6)                                       // 000000083D98: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 000000083D9C: 567C612E
	ds_load_b32 v46, v20 offset:17440                          // 000000083DA0: D8D84420 2E000014
	v_dual_mov_b32 v21, v17 :: v_dual_mov_b32 v20, v16         // 000000083DA8: CA100111 15140110
	v_mov_b32_e32 v48, v44                                     // 000000083DB0: 7E60032C
	v_dual_fmac_f32 v62, v47, v49 :: v_dual_mov_b32 v47, v1    // 000000083DB4: C810632F 3E2E0101
	s_waitcnt lgkmcnt(5)                                       // 000000083DBC: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083DC0: BF870091
	v_fmac_f32_e32 v62, v50, v52                               // 000000083DC4: 567C6932
	v_fmac_f32_e32 v62, v51, v53                               // 000000083DC8: 567C6B33
	s_waitcnt lgkmcnt(2)                                       // 000000083DCC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083DD0: BF870091
	v_fmac_f32_e32 v62, v54, v58                               // 000000083DD4: 567C7536
	v_fmac_f32_e32 v62, v55, v59                               // 000000083DD8: 567C7737
	s_waitcnt lgkmcnt(1)                                       // 000000083DDC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083DE0: BF870091
	v_fmac_f32_e32 v62, v56, v60                               // 000000083DE4: 567C7938
	v_fmac_f32_e32 v62, v57, v61                               // 000000083DE8: 567C7B39
	s_waitcnt lgkmcnt(0)                                       // 000000083DEC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083DF0: BF870001
	v_mul_f32_e32 v46, v62, v46                                // 000000083DF4: 105C5D3E
	s_nop 0                                                    // 000000083DF8: BF800000
	s_nop 0                                                    // 000000083DFC: BF800000
	global_load_b32 v49, v[20:21], off                         // 000000083E00: DC520000 317C0014
	ds_load_b32 v50, v47 offset:8704                           // 000000083E08: D8D82200 3200002F
	v_add_nc_u32_e32 v48, -1, v48                              // 000000083E10: 4A6060C1
	.long 0xd7000114                                           // 000000083E14: D7000114
	v_cndmask_b32_e32 v0, v20, v132, vcc_lo                    // 000000083E18: 02010914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000083E1C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 000000083E20: D5207C15 00062A80
	.long 0xd44a0004                                           // 000000083E28: D44A0004
	v_cndmask_b32_e32 v1, 0, v48, vcc_lo                       // 000000083E2C: 02026080
	v_add_nc_u32_e32 v47, 0x44, v47                            // 000000083E30: 4A5E5EFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000083E38: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000083E3C: BF890007
	v_fmac_f32_e32 v46, v49, v50                               // 000000083E40: 565C6531
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000083E44: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000083E48: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000083E4C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083E50: BF870121
	v_bfe_u32 v47, v46, 16, 1                                  // 000000083E54: D610002F 0205212E
	v_mad_u64_u32 v[20:21], null, 0x3000, v45, v[6:7]          // 000000083E5C: D6FE7C14 041A5AFF 00003000
	v_add3_u32 v45, v46, v47, 0x7fff                           // 000000083E68: D655002D 03FE5F2E 00007FFF
	global_store_d16_hi_b16 v[20:21], v45, off                 // 000000083E74: DC960000 007C2D14
	s_branch 64917                                             // 000000083E7C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000083E80: A201FF06 3FB8AA3B
	v_mov_b32_e32 v18, v23                                     // 000000083E88: 7E240317
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000083E8C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000083E90: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000083E98: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000083E9C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000083EA4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 000000083EAC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000083EB0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000083EB4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000083EBC: A0010401
	s_mov_b32 s4, 0                                            // 000000083EC0: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000083EC4: BF87000A
	v_exp_f32_e32 v16, s1                                      // 000000083EC8: 7E204A01
	s_cvt_i32_f32 s1, s7                                       // 000000083ECC: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000083ED0: BF870585
	.long 0xd71c0010                                           // 000000083ED4: D71C0010
	v_cndmask_b32_e32 v0, v16, v1, vcc_lo                      // 000000083ED8: 02000310
	s_cselect_b32 s1, -1, 0                                    // 000000083EDC: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000083EE0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000083EE8: BF870131
	v_cndmask_b32_e64 v17, 0, v16, s1                          // 000000083EEC: D5010011 00062080
	s_cselect_b32 s1, -1, 0                                    // 000000083EF4: 980180C1
	v_mov_b32_e32 v16, v22                                     // 000000083EF8: 7E200316
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 000000083EFC: D5010011 000622FF 7F800000
	ds_load_b32 v19, v16                                       // 000000083F08: D8D80000 13000010
	v_add_nc_u32_e32 v18, 0x80, v18                            // 000000083F10: 4A2424FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083F18: BF870001
	.long 0xd4490001                                           // 000000083F1C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v18, vcc_lo                   // 000000083F20: 020224FF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000083F28: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000083F2C: BF89FC07
	v_mul_f32_e32 v19, v17, v19                                // 000000083F30: 10262711
	ds_store_b32 v16, v19                                      // 000000083F34: D8340000 00001310
	v_add_nc_u32_e32 v16, 0x220, v16                           // 000000083F3C: 4A2020FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000083F44: 917E047E
	s_cbranch_execnz 65519                                     // 000000083F48: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000083F4C: 8C7E047E
	v_dual_mov_b32 v17, v15 :: v_dual_mov_b32 v16, v14         // 000000083F50: CA10010F 1110010E
	v_mov_b32_e32 v20, 0                                       // 000000083F58: 7E280280
	s_mov_b32 s6, 0                                            // 000000083F5C: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000083F60: BF870112
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 000000083F64: CA100111 13120110
	v_dual_mov_b32 v21, v20 :: v_dual_mov_b32 v44, v25         // 000000083F6C: CA100114 152C0119
	v_mov_b32_e32 v45, v23                                     // 000000083F74: 7E5A0317
	s_mov_b32 s7, 0                                            // 000000083F78: BE870080
	s_waitcnt lgkmcnt(0)                                       // 000000083F7C: BF89FC07
	s_barrier                                                  // 000000083F80: BFBD0000
	buffer_gl0_inv                                             // 000000083F84: E0AC0000 00000000
	s_nop 0                                                    // 000000083F8C: BF800000
	s_nop 0                                                    // 000000083F90: BF800000
	s_nop 0                                                    // 000000083F94: BF800000
	s_nop 0                                                    // 000000083F98: BF800000
	s_nop 0                                                    // 000000083F9C: BF800000
	s_nop 0                                                    // 000000083FA0: BF800000
	s_nop 0                                                    // 000000083FA4: BF800000
	s_nop 0                                                    // 000000083FA8: BF800000
	s_nop 0                                                    // 000000083FAC: BF800000
	s_nop 0                                                    // 000000083FB0: BF800000
	s_nop 0                                                    // 000000083FB4: BF800000
	s_nop 0                                                    // 000000083FB8: BF800000
	s_nop 0                                                    // 000000083FBC: BF800000
	global_load_b32 v46, v[18:19], off                         // 000000083FC0: DC520000 2E7C0012
	ds_load_b32 v47, v21 offset:17184                          // 000000083FC8: D8D84320 2F000015
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000083FD0: 4A5A5AFF 00000080
	.long 0xd7000112                                           // 000000083FD8: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 000000083FDC: 020224FF 00006000
	v_add_nc_u32_e32 v21, 4, v21                               // 000000083FE4: 4A2A2A84
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000083FE8: D5207C13 00062680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000083FF0: BF870004
	.long 0xd4490004                                           // 000000083FF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000083FF8: 02025AFF 0000037F
	s_or_b32 s7, s4, s7                                        // 000000084000: 8C070704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000084004: BF890007
	v_mul_f32_e32 v46, v46, v47                                // 000000084008: 105C5F2E
	ds_store_b32 v44, v46 offset:13056                         // 00000008400C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000084014: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000008401C: 917E077E
	s_cbranch_execnz 65511                                     // 000000084020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000084024: 8C7E077E
	v_mad_u64_u32 v[18:19], null, 0x44, s6, v[5:6]             // 000000084028: D6FE7C12 04140CFF 00000044
	s_waitcnt lgkmcnt(0)                                       // 000000084034: BF89FC07
	s_barrier                                                  // 000000084038: BFBD0000
	buffer_gl0_inv                                             // 00000008403C: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 000000084044: BE840080
	ds_load_2addr_b32 v[44:45], v18 offset0:102 offset1:119    // 000000084048: D8DC7766 2C000012
	ds_load_2addr_b32 v[46:47], v18 offset0:68 offset1:85      // 000000084050: D8DC5544 2E000012
	ds_load_2addr_b32 v[48:49], v18 offset1:17                 // 000000084058: D8DC1100 30000012
	ds_load_2addr_b32 v[18:19], v18 offset0:34 offset1:51      // 000000084060: D8DC3322 12000012
	s_waitcnt lgkmcnt(3)                                       // 000000084068: BF89FC37
	v_bfe_u32 v21, v45, 16, 1                                  // 00000008406C: D6100015 0205212D
	v_bfe_u32 v50, v44, 16, 1                                  // 000000084074: D6100032 0205212C
	s_waitcnt lgkmcnt(2)                                       // 00000008407C: BF89FC27
	v_bfe_u32 v51, v47, 16, 1                                  // 000000084080: D6100033 0205212F
	s_waitcnt lgkmcnt(1)                                       // 000000084088: BF89FC17
	v_bfe_u32 v52, v48, 16, 1                                  // 00000008408C: D6100034 02052130
	v_bfe_u32 v53, v49, 16, 1                                  // 000000084094: D6100035 02052131
	s_waitcnt lgkmcnt(0)                                       // 00000008409C: BF89FC07
	v_bfe_u32 v54, v18, 16, 1                                  // 0000000840A0: D6100036 02052112
	v_bfe_u32 v55, v46, 16, 1                                  // 0000000840A8: D6100037 0205212E
	v_bfe_u32 v56, v19, 16, 1                                  // 0000000840B0: D6100038 02052113
	v_add3_u32 v48, v48, v52, 0x7fff                           // 0000000840B8: D6550030 03FE6930 00007FFF
	v_add3_u32 v49, v49, v53, 0x7fff                           // 0000000840C4: D6550031 03FE6B31 00007FFF
	v_add3_u32 v52, v18, v54, 0x7fff                           // 0000000840D0: D6550034 03FE6D12 00007FFF
	v_add3_u32 v18, v45, v21, 0x7fff                           // 0000000840DC: D6550012 03FE2B2D 00007FFF
	v_add3_u32 v21, v44, v50, 0x7fff                           // 0000000840E8: D6550015 03FE652C 00007FFF
	v_add3_u32 v44, v47, v51, 0x7fff                           // 0000000840F4: D655002C 03FE672F 00007FFF
	v_add3_u32 v45, v46, v55, 0x7fff                           // 000000084100: D655002D 03FE6F2E 00007FFF
	v_add3_u32 v46, v19, v56, 0x7fff                           // 00000008410C: D655002E 03FE7113 00007FFF
	v_and_b32_e32 v18, 0xffff0000, v18                         // 000000084118: 362424FF FFFF0000
	v_and_b32_e32 v19, 0xffff0000, v21                         // 000000084120: 36262AFF FFFF0000
	v_and_b32_e32 v21, 0xffff0000, v44                         // 000000084128: 362A58FF FFFF0000
	v_and_b32_e32 v44, 0xffff0000, v45                         // 000000084130: 36585AFF FFFF0000
	v_and_b32_e32 v45, 0xffff0000, v46                         // 000000084138: 365A5CFF FFFF0000
	v_and_b32_e32 v46, 0xffff0000, v52                         // 000000084140: 365C68FF FFFF0000
	v_and_b32_e32 v47, 0xffff0000, v49                         // 000000084148: 365E62FF FFFF0000
	v_dual_mov_b32 v49, v0 :: v_dual_and_b32 v48, 0xffff0000, v48// 000000084150: CA240100 313060FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008415C: BF870121
	v_lshrrev_b32_e32 v52, 4, v49                              // 000000084160: 32686284
	.long 0xd4490001                                           // 000000084164: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v49, vcc_lo                   // 000000084168: 020262FF 0000077F
	v_lshlrev_b32_e32 v57, 2, v52                              // 000000084170: 30726882
	v_mad_u64_u32 v[52:53], null, 0x44, v52, v[1:2]            // 000000084174: D6FE7C34 040668FF 00000044
	s_or_b32 s4, s1, s4                                        // 000000084180: 8C040401
	v_add_nc_u32_e32 v50, 0x3200, v57                          // 000000084184: 4A6472FF 00003200
	v_add_nc_u32_e32 v54, 0x3600, v57                          // 00000008418C: 4A6C72FF 00003600
	v_add_nc_u32_e32 v55, 0x3a00, v57                          // 000000084194: 4A6E72FF 00003A00
	v_add_nc_u32_e32 v57, 0x3e00, v57                          // 00000008419C: 4A7272FF 00003E00
	ds_load_b32 v59, v52                                       // 0000000841A4: D8D80000 3B000034
	ds_load_2addr_b32 v[55:56], v55 offset0:68 offset1:197     // 0000000841AC: D8DCC544 37000037
	ds_load_2addr_b32 v[50:51], v50 offset0:64 offset1:193     // 0000000841B4: D8DCC140 32000032
	ds_load_2addr_b32 v[53:54], v54 offset0:66 offset1:195     // 0000000841BC: D8DCC342 35000036
	s_waitcnt lgkmcnt(1)                                       // 0000000841C4: BF89FC17
	v_bfe_u32 v58, v50, 16, 1                                  // 0000000841C8: D610003A 02052132
	v_bfe_u32 v60, v51, 16, 1                                  // 0000000841D0: D610003C 02052133
	s_waitcnt lgkmcnt(0)                                       // 0000000841D8: BF89FC07
	v_bfe_u32 v61, v53, 16, 1                                  // 0000000841DC: D610003D 02052135
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000841E4: BF870003
	v_add3_u32 v50, v50, v58, 0x7fff                           // 0000000841E8: D6550032 03FE7532 00007FFF
	ds_load_2addr_b32 v[57:58], v57 offset0:70 offset1:199     // 0000000841F4: D8DCC746 39000039
	v_add3_u32 v51, v51, v60, 0x7fff                           // 0000000841FC: D6550033 03FE7933 00007FFF
	v_bfe_u32 v60, v54, 16, 1                                  // 000000084208: D610003C 02052136
	v_add3_u32 v53, v53, v61, 0x7fff                           // 000000084210: D6550035 03FE7B35 00007FFF
	v_and_b32_e32 v50, 0xffff0000, v50                         // 00000008421C: 366464FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000084224: BF870214
	v_and_b32_e32 v51, 0xffff0000, v51                         // 000000084228: 366666FF FFFF0000
	v_add3_u32 v54, v54, v60, 0x7fff                           // 000000084230: D6550036 03FE7936 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000008423C: BF870214
	v_and_b32_e32 v53, 0xffff0000, v53                         // 000000084240: 366A6AFF FFFF0000
	v_fmac_f32_e32 v59, v50, v48                               // 000000084248: 56766132
	v_bfe_u32 v50, v55, 16, 1                                  // 00000008424C: D6100032 02052137
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000084254: BF8701A2
	v_dual_fmac_f32 v59, v51, v47 :: v_dual_and_b32 v54, 0xffff0000, v54// 000000084258: C8245F33 3B366CFF FFFF0000
	v_bfe_u32 v51, v56, 16, 1                                  // 000000084264: D6100033 02052138
	v_add3_u32 v50, v55, v50, 0x7fff                           // 00000008426C: D6550032 03FE6537 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000084278: BF8701C3
	v_fmac_f32_e32 v59, v53, v46                               // 00000008427C: 56765D35
	s_waitcnt lgkmcnt(0)                                       // 000000084280: BF89FC07
	v_bfe_u32 v53, v57, 16, 1                                  // 000000084284: D6100035 02052139
	v_add3_u32 v51, v56, v51, 0x7fff                           // 00000008428C: D6550033 03FE6738 00007FFF
	v_dual_fmac_f32 v59, v54, v45 :: v_dual_and_b32 v50, 0xffff0000, v50// 000000084298: C8245B36 3B3264FF FFFF0000
	v_bfe_u32 v54, v58, 16, 1                                  // 0000000842A4: D6100036 0205213A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000842AC: BF870214
	v_add3_u32 v53, v57, v53, 0x7fff                           // 0000000842B0: D6550035 03FE6B39 00007FFF
	v_and_b32_e32 v51, 0xffff0000, v51                         // 0000000842BC: 366666FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000842C4: BF870214
	v_fmac_f32_e32 v59, v50, v44                               // 0000000842C8: 56765932
	v_add3_u32 v50, v58, v54, 0x7fff                           // 0000000842CC: D6550032 03FE6D3A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000842D8: BF870114
	v_and_b32_e32 v53, 0xffff0000, v53                         // 0000000842DC: 366A6AFF FFFF0000
	v_dual_fmac_f32 v59, v51, v21 :: v_dual_and_b32 v50, 0xffff0000, v50// 0000000842E4: C8242B33 3B3264FF FFFF0000
	v_add_nc_u32_e32 v51, 0x80, v49                            // 0000000842F0: 4A6662FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000842F8: BF870112
	v_fmac_f32_e32 v59, v53, v19                               // 0000000842FC: 56762735
	v_mov_b32_e32 v49, v51                                     // 000000084300: 7E620333
	s_delay_alu instid0(VALU_DEP_2)                            // 000000084304: BF870002
	v_fmac_f32_e32 v59, v50, v18                               // 000000084308: 56762532
	ds_store_b32 v52, v59                                      // 00000008430C: D8340000 00003B34
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000084314: 917E047E
	s_cbranch_execnz 65424                                     // 000000084318: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c5c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008431C: 8C7E047E
	.long 0xd7000110                                           // 000000084320: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 000000084324: 020220FF 00030000
	v_add_nc_u32_e32 v20, 32, v20                              // 00000008432C: 4A2828A0
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000084330: D5207C11 00062280
	s_add_i32 s1, s6, 8                                        // 000000084338: 81018806
	s_cmp_gt_u32 s6, 55                                        // 00000008433C: BF08B706
	s_mov_b32 s6, s1                                           // 000000084340: BE860001
	s_cbranch_scc0 65286                                       // 000000084344: BFA1FF06 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a60>
	.long 0xd7000108                                           // 000000084348: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000008434C: 020210FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000084354: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 000000084358: D5207C09 00061280
	.long 0xd700010a                                           // 000000084360: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 000000084364: 020214FF 00180000
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 00000008436C: D5207C0B 00061680
	.long 0xd700010c                                           // 000000084374: D700010C
	v_cndmask_b32_e32 v1, 0xc0000, v12, vcc_lo                 // 000000084378: 020218FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000084380: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 000000084384: D5207C0D 00061A80
	.long 0xd700010e                                           // 00000008438C: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 000000084390: 02021CFF 00180000
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 000000084398: D5207C0F 00061E80
	s_add_i32 s5, s5, 1                                        // 0000000843A0: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000843A4: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000843A8: BF062105
	s_barrier                                                  // 0000000843AC: BFBD0000
	buffer_gl0_inv                                             // 0000000843B0: E0AC0000 00000000
	s_cbranch_scc0 63764                                       // 0000000843B8: BFA1F914 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30c>
	v_mov_b32_e32 v4, v23                                      // 0000000843BC: 7E080317
	s_add_u32 s0, s28, s20                                     // 0000000843C0: 8000141C
	.long 0xd73c0000                                           // 0000000843C4: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000843C8: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000843CC: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000843D0: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000843D4: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000843D8: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000843DC: 82010103
	.long 0xd7006a00                                           // 0000000843E0: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000843E4: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000843E8: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000843EC: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000843F4: BE810080
	.long 0xd7006a00                                           // 0000000843F8: D7006A00
	v_cndmask_b32_e32 v1, v0, v24, vcc_lo                      // 0000000843FC: 02023100
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000084400: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084408: BF870092
	.long 0xd7006a00                                           // 00000008440C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000084410: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000084414: D5207C01 01AA0211
	s_nop 0                                                    // 00000008441C: BF800000
	s_nop 0                                                    // 000000084420: BF800000
	s_nop 0                                                    // 000000084424: BF800000
	s_nop 0                                                    // 000000084428: BF800000
	s_nop 0                                                    // 00000008442C: BF800000
	s_nop 0                                                    // 000000084430: BF800000
	s_nop 0                                                    // 000000084434: BF800000
	s_nop 0                                                    // 000000084438: BF800000
	s_nop 0                                                    // 00000008443C: BF800000
	ds_load_b32 v2, v22                                        // 000000084440: D8D80000 02000016
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000084448: 4A0808FF 00000080
	v_add_nc_u32_e32 v22, 0x220, v22                           // 000000084450: 4A2C2CFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000084458: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008445C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000084464: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000084468: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000008446C: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000084474: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000084478: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000084480: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000084488: 917E017E
	s_cbranch_execnz 65516                                     // 00000008448C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	s_endpgm                                                   // 000000084490: BFB00000
		...

