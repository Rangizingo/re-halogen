0000000000192f00 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 000000192F00: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000192F04: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 000000192F0C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 000000192F14: BE940003
	s_ashr_i32 s3, s2, 31                                      // 000000192F18: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 000000192F1C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000192F24: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 000000192F28: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 000000192F30: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000192F38: 84808202
	s_waitcnt lgkmcnt(0)                                       // 000000192F3C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 000000192F40: 810E020E
	s_add_u32 s0, s18, s0                                      // 000000192F44: 80000012
	s_addc_u32 s1, s19, s1                                     // 000000192F48: 82010113
	s_add_i32 s15, s14, 1                                      // 000000192F4C: 810F810E
	s_load_b32 s3, s[0:1], null                                // 000000192F50: F40000C0 F8000000
	s_ashr_i32 s0, s15, 31                                     // 000000192F58: 86009F0F
	s_mul_hi_i32 s1, s21, s2                                   // 000000192F5C: 97010215
	s_lshr_b32 s0, s0, 30                                      // 000000192F60: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000192F64: BF870499
	s_add_i32 s15, s15, s0                                     // 000000192F68: 810F000F
	s_and_b32 s0, s15, -4                                      // 000000192F6C: 8B00C40F
	s_ashr_i32 s18, s15, 2                                     // 000000192F70: 8612820F
	s_sub_i32 s14, s14, s0                                     // 000000192F74: 818E000E
	s_mul_i32 s0, s21, s2                                      // 000000192F78: 96000215
	s_cmp_gt_i32 s14, -1                                       // 000000192F7C: BF02C10E
	s_mov_b32 s19, s18                                         // 000000192F80: BE930012
	s_cselect_b32 s15, -1, 0                                   // 000000192F84: 980F80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000192F88: BF870009
	s_and_b32 vcc_lo, exec_lo, s15                             // 000000192F8C: 8B6A0F7E
	s_cbranch_vccnz 15                                         // 000000192F90: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 000000192F94: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000192F98: BF8704D9
	s_add_u32 s19, s16, s22                                    // 000000192F9C: 80131610
	s_addc_u32 s21, s17, s23                                   // 000000192FA0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 000000192FA4: BF89FC07
	s_max_i32 s22, s3, 1                                       // 000000192FA8: 8A168103
	s_mov_b32 s23, 0                                           // 000000192FAC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 000000192FB0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000192FB4: BF870009
	s_add_u32 s19, s19, s22                                    // 000000192FB8: 80131613
	s_addc_u32 s21, s21, s23                                   // 000000192FBC: 82151715
	s_add_u32 s22, s19, -4                                     // 000000192FC0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 000000192FC4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 000000192FC8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s15                            // 000000192FD0: D5010001 003D0280
	s_mov_b32 s23, exec_lo                                     // 000000192FD8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000192FDC: BF8704B1
	v_readfirstlane_b32 s15, v1                                // 000000192FE0: 7E1E0501
	s_waitcnt lgkmcnt(0)                                       // 000000192FE4: BF89FC07
	s_add_i32 s21, s3, s15                                     // 000000192FE8: 81150F03
	s_add_i32 s15, s21, 3                                      // 000000192FEC: 810F8315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000192FF0: BF870499
	s_and_b32 s22, s15, -4                                     // 000000192FF4: 8B16C40F
	.long 0xd4c4007e                                           // 000000192FF8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000192FFC: 02020016
	s_cbranch_execz 45                                         // 000000193000: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 000000193004: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000019300C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193010: BF8700A9
	s_add_u32 s0, s16, s0                                      // 000000193014: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000193018: 82010111
	.long 0xd7000001                                           // 00000019301C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000193020: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193024: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 000000193028: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 000000193030: BE810080
	s_set_inst_prefetch_distance 0x1                           // 000000193034: BF840001
	s_branch 18                                                // 000000193038: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 00000019303C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000193040: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 000000193044: 4A0808C0
	.long 0xd7000001                                           // 000000193048: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 00000019304C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 000000193054: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 000000193058: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 000000193060: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 000000193068: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000019306C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 000000193074: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000193078: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019307C: 917E017E
	s_cbranch_execz 13                                         // 000000193080: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 000000193084: BE80007E
	.long 0xd4c3007e                                           // 000000193088: D4C3007E
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000019308C: 02020803
	s_xor_b32 s0, exec_lo, s0                                  // 000000193090: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 000000193094: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 000000193098: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019309C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001930A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 0000001930A4: BE803000
	s_cbranch_execz 65509                                      // 0000001930A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001930AC: DC520000 057C0001
	s_branch 65506                                             // 0000001930B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001930B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 0000001930BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001930C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 0000001930C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001930C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 0000001930D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001930D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001930D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001930E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 0000001930E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 0000001930EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 0000001930F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001930F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 000000193100: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 000000193104: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 00000019310C: 30020084
	s_add_u32 s4, s4, s16                                      // 000000193110: 80041004
	s_addc_u32 s5, s5, s17                                     // 000000193114: 82051105
	s_add_u32 s4, s4, s18                                      // 000000193118: 80041204
	s_addc_u32 s0, s5, s0                                      // 00000019311C: 82000005
	.long 0xd7000401                                           // 000000193120: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000193124: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 000000193128: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000193134: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 00000019313C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 000000193140: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 000000193148: 4A0606FF 00000200
	.long 0xd7006a01                                           // 000000193150: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 000000193154: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019315C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000193160: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000193168: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 00000019316C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 000000193174: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000193178: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 00000019317C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 000000193184: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000019318C: 917E047E
	s_cbranch_execnz 65515                                     // 000000193190: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000193194: 8C7E017E
	v_lshlrev_b32_e32 v155, 7, v7                              // 000000193198: 31360E87
	s_ashr_i32 s1, s15, 2                                      // 00000019319C: 8601820F
	s_mov_b32 s0, 0                                            // 0000001931A0: BE800080
	s_cmp_gt_i32 s1, 0                                         // 0000001931A4: BF028001
	s_waitcnt lgkmcnt(0)                                       // 0000001931A8: BF89FC07
	s_barrier                                                  // 0000001931AC: BFBD0000
	buffer_gl0_inv                                             // 0000001931B0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 0000001931B8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001931BC: 30100E87
	s_branch 1                                                 // 0000001931C0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s0, -1                                           // 0000001931C4: BE8000C1
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v153, 15, v0       // 0000001931C8: CA240080 2698008F
	v_bfe_u32 v154, v0, 4, 1                                   // 0000001931D0: D610009A 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001931D8: 916A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001931DC: BF870002
	v_mov_b32_e32 v37, v38                                     // 0000001931E0: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001931E4: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001931E8: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001931EC: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001931F0: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001931F4: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001931F8: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001931FC: 7E580326
	v_mov_b32_e32 v43, v38                                     // 000000193200: 7E560326
	v_mov_b32_e32 v42, v38                                     // 000000193204: 7E540326
	v_mov_b32_e32 v41, v38                                     // 000000193208: 7E520326
	v_mov_b32_e32 v54, v38                                     // 00000019320C: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 000000193210: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 000000193214: 7E680326
	v_mov_b32_e32 v51, v38                                     // 000000193218: 7E660326
	v_mov_b32_e32 v50, v38                                     // 00000019321C: 7E640326
	v_mov_b32_e32 v49, v38                                     // 000000193220: 7E620326
	v_mov_b32_e32 v62, v38                                     // 000000193224: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 000000193228: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 00000019322C: 7E780326
	v_mov_b32_e32 v59, v38                                     // 000000193230: 7E760326
	v_mov_b32_e32 v58, v38                                     // 000000193234: 7E740326
	v_mov_b32_e32 v57, v38                                     // 000000193238: 7E720326
	v_mov_b32_e32 v30, v38                                     // 00000019323C: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 000000193240: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 000000193244: 7E380326
	v_mov_b32_e32 v27, v38                                     // 000000193248: 7E360326
	v_mov_b32_e32 v26, v38                                     // 00000019324C: 7E340326
	v_mov_b32_e32 v25, v38                                     // 000000193250: 7E320326
	v_mov_b32_e32 v22, v38                                     // 000000193254: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 000000193258: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 00000019325C: 7E280326
	v_mov_b32_e32 v19, v38                                     // 000000193260: 7E260326
	v_mov_b32_e32 v18, v38                                     // 000000193264: 7E240326
	v_mov_b32_e32 v17, v38                                     // 000000193268: 7E220326
	v_mov_b32_e32 v14, v38                                     // 00000019326C: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 000000193270: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 000000193274: 7E180326
	v_mov_b32_e32 v11, v38                                     // 000000193278: 7E160326
	v_mov_b32_e32 v10, v38                                     // 00000019327C: 7E140326
	v_mov_b32_e32 v9, v38                                      // 000000193280: 7E120326
	v_mov_b32_e32 v6, v38                                      // 000000193284: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 000000193288: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 00000019328C: 7E080326
	v_mov_b32_e32 v3, v38                                      // 000000193290: 7E060326
	v_mov_b32_e32 v2, v38                                      // 000000193294: 7E040326
	v_mov_b32_e32 v1, v38                                      // 000000193298: 7E020326
	v_mov_b32_e32 v141, v38                                    // 00000019329C: 7F1A0326
	v_mov_b32_e32 v140, v38                                    // 0000001932A0: 7F180326
	v_mov_b32_e32 v139, v38                                    // 0000001932A4: 7F160326
	v_mov_b32_e32 v138, v38                                    // 0000001932A8: 7F140326
	v_mov_b32_e32 v152, v38                                    // 0000001932AC: 7F300326
	v_mov_b32_e32 v137, v38                                    // 0000001932B0: 7F120326
	s_cbranch_vccnz 1373                                       // 0000001932B4: BFA4055D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x192c>
	v_lshlrev_b32_e32 v1, 10, v0                               // 0000001932B8: 3002008A
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 0000001932BC: CA220080 81000085
	s_ashr_i32 s21, s20, 31                                    // 0000001932C4: 86159F14
	v_lshlrev_b32_e32 v2, 10, v7                               // 0000001932C8: 30040E8A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001932CC: BF8701C3
	v_and_b32_e32 v1, 0x3000, v1                               // 0000001932D0: 360202FF 00003000
	s_lshl_b64 s[4:5], s[20:21], 11                            // 0000001932D8: 84848B14
	v_mov_b32_e32 v130, v129                                   // 0000001932DC: 7F040381
	v_dual_mov_b32 v131, v129 :: v_dual_and_b32 v0, 0x60, v0   // 0000001932E0: CA240181 830000FF 00000060
	.long 0xd7000001                                           // 0000001932EC: D7000001
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 0000001932F0: 02020206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001932F4: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s7, 0, s0                    // 0000001932F8: D5207C03 00010007
	s_movk_i32 s0, 0x210                                       // 000000193300: B0000210
	.long 0xd7006a01                                           // 000000193304: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000193308: 02000901
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000019330C: D5207C03 01AA0605
	v_dual_mov_b32 v135, v129 :: v_dual_lshlrev_b32 v4, 9, v7  // 000000193314: CA220181 87040E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019331C: BF870093
	.long 0xd7006a01                                           // 000000193320: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000193324: 02020501
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000193328: D5207C03 01AA0680
	v_xor_b32_e32 v5, 1, v7                                    // 000000193330: 3A0A0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193334: BF870093
	.long 0xd7006a00                                           // 000000193338: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 00000019333C: 02020101
	v_add_co_ci_u32_e64 v1, null, 0, v3, vcc_lo                // 000000193340: D5207C01 01AA0680
	v_cmp_gt_u32_e32 vcc_lo, 12, v153                          // 000000193348: 7C99328C
	v_dual_mov_b32 v179, 0xf149f2ca :: v_dual_lshlrev_b32 v6, 5, v154// 00000019334C: CA2200FF B3073485 F149F2CA
	s_clause 0xf                                               // 000000193358: BF85000F
	global_load_b128 v[69:72], v[0:1], off offset:16           // 00000019335C: DC5E0010 457C0000
	global_load_b128 v[65:68], v[0:1], off                     // 000000193364: DC5E0000 417C0000
	global_load_b128 v[77:80], v[0:1], off offset:144          // 00000019336C: DC5E0090 4D7C0000
	global_load_b128 v[73:76], v[0:1], off offset:128          // 000000193374: DC5E0080 497C0000
	global_load_b128 v[85:88], v[0:1], off offset:272          // 00000019337C: DC5E0110 557C0000
	global_load_b128 v[81:84], v[0:1], off offset:256          // 000000193384: DC5E0100 517C0000
	global_load_b128 v[93:96], v[0:1], off offset:400          // 00000019338C: DC5E0190 5D7C0000
	global_load_b128 v[89:92], v[0:1], off offset:384          // 000000193394: DC5E0180 597C0000
	global_load_b128 v[101:104], v[0:1], off offset:528        // 00000019339C: DC5E0210 657C0000
	global_load_b128 v[97:100], v[0:1], off offset:512         // 0000001933A4: DC5E0200 617C0000
	global_load_b128 v[109:112], v[0:1], off offset:656        // 0000001933AC: DC5E0290 6D7C0000
	global_load_b128 v[105:108], v[0:1], off offset:640        // 0000001933B4: DC5E0280 697C0000
	global_load_b128 v[117:120], v[0:1], off offset:784        // 0000001933BC: DC5E0310 757C0000
	global_load_b128 v[113:116], v[0:1], off offset:768        // 0000001933C4: DC5E0300 717C0000
	global_load_b128 v[125:128], v[0:1], off offset:912        // 0000001933CC: DC5E0390 7D7C0000
	global_load_b128 v[121:124], v[0:1], off offset:896        // 0000001933D4: DC5E0380 797C0000
	v_dual_mov_b32 v133, v129 :: v_dual_lshlrev_b32 v0, 2, v153// 0000001933DC: CA220181 85013282
	v_cndmask_b32_e32 v1, 0, v153, vcc_lo                      // 0000001933E4: 02033280
	v_dual_mov_b32 v177, 0xf149f2ca :: v_dual_lshlrev_b32 v8, 1, v153// 0000001933E8: CA2200FF B1093281 F149F2CA
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001933F4: BF870223
	v_lshl_or_b32 v0, v154, 6, v0                              // 0000001933F8: D6560000 04010D9A
	v_dual_mov_b32 v174, 0xf149f2ca :: v_dual_lshlrev_b32 v7, 8, v7// 000000193400: CA2200FF AE060E88 F149F2CA
	v_mad_u32_u24 v1, v1, s0, 0x2410                           // 00000019340C: D60B0001 03FC0101 00002410
	s_lshl_b64 s[4:5], s[20:21], 8                             // 000000193418: 84848814
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019341C: BF870243
	v_dual_mov_b32 v132, v129 :: v_dual_add_nc_u32 v3, 0x3cd0, v0// 000000193420: CA200181 840200FF 00003CD0
	v_or3_b32 v157, v4, v6, v8                                 // 00000019342C: D658009D 04220D04
	v_lshl_or_b32 v158, v153, 5, v4                            // 000000193434: D656009E 04110B99
	v_or3_b32 v159, s4, v153, v155                             // 00000019343C: D658009F 066F3204
	v_dual_mov_b32 v175, 0xf149f2ca :: v_dual_add_nc_u32 v0, v3, v2// 000000193444: CA2000FF AF000503 F149F2CA
	v_lshl_add_u32 v156, v5, 10, v3                            // 000000193450: D646009C 040D1505
	v_dual_mov_b32 v160, s5 :: v_dual_add_nc_u32 v161, v1, v7  // 000000193458: CA200005 A0A00F01
	v_mov_b32_e32 v176, 0xf149f2ca                             // 000000193460: 7F6002FF F149F2CA
	v_dual_mov_b32 v134, v129 :: v_dual_mov_b32 v173, 0xf149f2ca// 000000193468: CA100181 86AC00FF F149F2CA
	v_dual_mov_b32 v136, v129 :: v_dual_mov_b32 v171, 0xf149f2ca// 000000193474: CA100181 88AA00FF F149F2CA
	v_dual_mov_b32 v178, 0xf149f2ca :: v_dual_mov_b32 v163, v129// 000000193480: CA1000FF B2A20181 F149F2CA
	v_mov_b32_e32 v164, v129                                   // 00000019348C: 7F480381
	v_mov_b32_e32 v165, v129                                   // 000000193490: 7F4A0381
	v_mov_b32_e32 v166, v129                                   // 000000193494: 7F4C0381
	v_mov_b32_e32 v167, v129                                   // 000000193498: 7F4E0381
	v_mov_b32_e32 v168, v129                                   // 00000019349C: 7F500381
	v_mov_b32_e32 v169, v129                                   // 0000001934A0: 7F520381
	v_mov_b32_e32 v162, v129                                   // 0000001934A4: 7F440381
	v_mov_b32_e32 v1, v129                                     // 0000001934A8: 7E020381
	v_mov_b32_e32 v2, v129                                     // 0000001934AC: 7E040381
	v_mov_b32_e32 v3, v129                                     // 0000001934B0: 7E060381
	v_mov_b32_e32 v4, v129                                     // 0000001934B4: 7E080381
	v_mov_b32_e32 v5, v129                                     // 0000001934B8: 7E0A0381
	v_mov_b32_e32 v6, v129                                     // 0000001934BC: 7E0C0381
	v_mov_b32_e32 v7, v129                                     // 0000001934C0: 7E0E0381
	v_mov_b32_e32 v8, v129                                     // 0000001934C4: 7E100381
	v_mov_b32_e32 v9, v129                                     // 0000001934C8: 7E120381
	v_mov_b32_e32 v10, v129                                    // 0000001934CC: 7E140381
	v_mov_b32_e32 v11, v129                                    // 0000001934D0: 7E160381
	v_mov_b32_e32 v12, v129                                    // 0000001934D4: 7E180381
	v_mov_b32_e32 v13, v129                                    // 0000001934D8: 7E1A0381
	v_mov_b32_e32 v14, v129                                    // 0000001934DC: 7E1C0381
	v_mov_b32_e32 v15, v129                                    // 0000001934E0: 7E1E0381
	v_mov_b32_e32 v16, v129                                    // 0000001934E4: 7E200381
	v_mov_b32_e32 v17, v129                                    // 0000001934E8: 7E220381
	v_mov_b32_e32 v18, v129                                    // 0000001934EC: 7E240381
	v_mov_b32_e32 v19, v129                                    // 0000001934F0: 7E260381
	v_mov_b32_e32 v20, v129                                    // 0000001934F4: 7E280381
	v_mov_b32_e32 v21, v129                                    // 0000001934F8: 7E2A0381
	v_mov_b32_e32 v22, v129                                    // 0000001934FC: 7E2C0381
	v_mov_b32_e32 v23, v129                                    // 000000193500: 7E2E0381
	v_mov_b32_e32 v24, v129                                    // 000000193504: 7E300381
	v_mov_b32_e32 v25, v129                                    // 000000193508: 7E320381
	v_mov_b32_e32 v26, v129                                    // 00000019350C: 7E340381
	v_mov_b32_e32 v27, v129                                    // 000000193510: 7E360381
	v_mov_b32_e32 v28, v129                                    // 000000193514: 7E380381
	v_mov_b32_e32 v29, v129                                    // 000000193518: 7E3A0381
	v_mov_b32_e32 v30, v129                                    // 00000019351C: 7E3C0381
	v_mov_b32_e32 v31, v129                                    // 000000193520: 7E3E0381
	v_mov_b32_e32 v32, v129                                    // 000000193524: 7E400381
	v_mov_b32_e32 v57, v129                                    // 000000193528: 7E720381
	v_mov_b32_e32 v58, v129                                    // 00000019352C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000193530: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000193534: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000193538: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000019353C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000193540: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000193544: 7E800381
	v_mov_b32_e32 v49, v129                                    // 000000193548: 7E620381
	v_mov_b32_e32 v50, v129                                    // 00000019354C: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000193550: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000193554: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000193558: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000019355C: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000193560: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000193564: 7E700381
	v_mov_b32_e32 v41, v129                                    // 000000193568: 7E520381
	v_mov_b32_e32 v42, v129                                    // 00000019356C: 7E540381
	v_mov_b32_e32 v43, v129                                    // 000000193570: 7E560381
	v_mov_b32_e32 v44, v129                                    // 000000193574: 7E580381
	v_mov_b32_e32 v45, v129                                    // 000000193578: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 00000019357C: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 000000193580: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000193584: 7E600381
	v_mov_b32_e32 v33, v129                                    // 000000193588: 7E420381
	v_mov_b32_e32 v34, v129                                    // 00000019358C: 7E440381
	v_mov_b32_e32 v35, v129                                    // 000000193590: 7E460381
	v_mov_b32_e32 v36, v129                                    // 000000193594: 7E480381
	v_mov_b32_e32 v37, v129                                    // 000000193598: 7E4A0381
	v_mov_b32_e32 v38, v129                                    // 00000019359C: 7E4C0381
	v_mov_b32_e32 v39, v129                                    // 0000001935A0: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 0000001935A4: 7E500381
	s_lshl2_add_u32 s3, s3, s14                                // 0000001935A8: 87830E03
	s_mov_b32 s18, 0                                           // 0000001935AC: BE920080
	s_add_i32 s3, s3, 1                                        // 0000001935B0: 81038103
	s_branch 249                                               // 0000001935B4: BFA000F9 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xa9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001935B8: 8C7E007E
	s_ashr_i32 s17, s16, 31                                    // 0000001935BC: 86119F10
	s_ashr_i32 s15, s14, 31                                    // 0000001935C0: 860F9F0E
	s_lshl_b64 s[16:17], s[16:17], 9                           // 0000001935C4: 84908910
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000001935C8: 848E890E
	.long 0xd7006abc                                           // 0000001935CC: D7006ABC
	v_cndmask_b32_e32 v1, s16, v159, vcc_lo                    // 0000001935D0: 02033E10
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001935D4: BF870001
	v_add_co_ci_u32_e64 v189, null, s17, v160, vcc_lo          // 0000001935D8: D5207CBD 01AB4011
	s_ashr_i32 s5, s4, 31                                      // 0000001935E0: 86059F04
	.long 0xd7006abe                                           // 0000001935E4: D7006ABE
	v_cndmask_b32_e32 v1, s14, v159, vcc_lo                    // 0000001935E8: 02033E0E
	s_lshl_b64 s[4:5], s[4:5], 9                               // 0000001935EC: 84848904
	.long 0xd73c00bc                                           // 0000001935F0: D73C00BC
	v_cndmask_b32_e32 v1, 3, v188, vcc_lo                      // 0000001935F4: 02037883
	v_add_co_ci_u32_e64 v191, null, s15, v160, vcc_lo          // 0000001935F8: D5207CBF 01AB400F
	.long 0xd7006ac0                                           // 000000193600: D7006AC0
	v_cndmask_b32_e32 v1, s4, v159, vcc_lo                     // 000000193604: 02033E04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193608: BF870001
	v_add_co_ci_u32_e64 v193, null, s5, v160, vcc_lo           // 00000019360C: D5207CC1 01AB4005
	s_ashr_i32 s7, s6, 31                                      // 000000193614: 86079F06
	.long 0xd7006ade                                           // 000000193618: D7006ADE
	v_cndmask_b32_e32 v1, s8, v188, vcc_lo                     // 00000019361C: 02037808
	s_lshl_b64 s[6:7], s[6:7], 9                               // 000000193620: 84868906
	v_add_co_ci_u32_e64 v223, null, s9, v189, vcc_lo           // 000000193624: D5207CDF 01AB7A09
	.long 0xd73c00bc                                           // 00000019362C: D73C00BC
	v_cndmask_b32_e32 v1, 3, v190, vcc_lo                      // 000000193630: 02037C83
	.long 0xd73c00be                                           // 000000193634: D73C00BE
	v_cndmask_b32_e32 v1, 3, v192, vcc_lo                      // 000000193638: 02038083
	.long 0xd7006ac0                                           // 00000019363C: D7006AC0
	v_cndmask_b32_e32 v1, s6, v159, vcc_lo                     // 000000193640: 02033E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000193644: BF870211
	v_add_co_ci_u32_e64 v193, null, s7, v160, vcc_lo           // 000000193648: D5207CC1 01AB4007
	.long 0xd7006ae0                                           // 000000193650: D7006AE0
	v_cndmask_b32_e32 v1, s8, v188, vcc_lo                     // 000000193654: 02037808
	v_bfe_u32 v171, v175, 16, 1                                // 000000193658: D61000AB 020521AF
	v_add_co_ci_u32_e64 v225, null, s9, v189, vcc_lo           // 000000193660: D5207CE1 01AB7A09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000193668: BF870224
	.long 0xd73c00bc                                           // 00000019366C: D73C00BC
	v_cndmask_b32_e32 v1, 3, v192, vcc_lo                      // 000000193670: 02038083
	.long 0xd7006ae2                                           // 000000193674: D7006AE2
	v_cndmask_b32_e32 v1, s8, v190, vcc_lo                     // 000000193678: 02037C08
	v_add3_u32 v171, v175, v171, 0x7fff                        // 00000019367C: D65500AB 03FF57AF 00007FFF
	v_add_co_ci_u32_e64 v227, null, s9, v191, vcc_lo           // 000000193688: D5207CE3 01AB7E09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193690: BF870094
	.long 0xd7006afa                                           // 000000193694: D7006AFA
	v_cndmask_b32_e32 v1, s8, v188, vcc_lo                     // 000000193698: 02037808
	v_add_co_ci_u32_e64 v251, null, s9, v189, vcc_lo           // 00000019369C: D5207CFB 01AB7A09
	ds_store_b16_d16_hi v157, v171 offset:448                  // 0000001936A4: DA8401C0 0000AB9D
	ds_load_b128 v[180:183], v158                              // 0000001936AC: DBFC0000 B400009E
	ds_load_b128 v[184:187], v158 offset:16                    // 0000001936B4: DBFC0010 B800009E
	s_clause 0x1f                                              // 0000001936BC: BF85001F
	global_load_b64 v[188:189], v[222:223], off                // 0000001936C0: DC560000 BC7C00DE
	global_load_b64 v[196:197], v[222:223], off offset:128     // 0000001936C8: DC560080 C47C00DE
	global_load_b64 v[204:205], v[222:223], off offset:256     // 0000001936D0: DC560100 CC7C00DE
	global_load_b64 v[212:213], v[222:223], off offset:384     // 0000001936D8: DC560180 D47C00DE
	global_load_b64 v[190:191], v[224:225], off                // 0000001936E0: DC560000 BE7C00E0
	global_load_b64 v[198:199], v[224:225], off offset:128     // 0000001936E8: DC560080 C67C00E0
	global_load_b64 v[206:207], v[224:225], off offset:256     // 0000001936F0: DC560100 CE7C00E0
	global_load_b64 v[214:215], v[224:225], off offset:384     // 0000001936F8: DC560180 D67C00E0
	global_load_b64 v[192:193], v[226:227], off                // 000000193700: DC560000 C07C00E2
	global_load_b64 v[200:201], v[226:227], off offset:128     // 000000193708: DC560080 C87C00E2
	global_load_b64 v[208:209], v[226:227], off offset:256     // 000000193710: DC560100 D07C00E2
	global_load_b64 v[216:217], v[226:227], off offset:384     // 000000193718: DC560180 D87C00E2
	global_load_b64 v[194:195], v[250:251], off                // 000000193720: DC560000 C27C00FA
	global_load_b64 v[202:203], v[250:251], off offset:128     // 000000193728: DC560080 CA7C00FA
	global_load_b64 v[210:211], v[250:251], off offset:256     // 000000193730: DC560100 D27C00FA
	global_load_b64 v[218:219], v[250:251], off offset:384     // 000000193738: DC560180 DA7C00FA
	global_load_b64 v[220:221], v[222:223], off offset:512     // 000000193740: DC560200 DC7C00DE
	global_load_b64 v[228:229], v[222:223], off offset:640     // 000000193748: DC560280 E47C00DE
	global_load_b64 v[236:237], v[222:223], off offset:768     // 000000193750: DC560300 EC7C00DE
	global_load_b64 v[244:245], v[222:223], off offset:896     // 000000193758: DC560380 F47C00DE
	global_load_b64 v[222:223], v[224:225], off offset:512     // 000000193760: DC560200 DE7C00E0
	global_load_b64 v[230:231], v[224:225], off offset:640     // 000000193768: DC560280 E67C00E0
	global_load_b64 v[238:239], v[224:225], off offset:768     // 000000193770: DC560300 EE7C00E0
	global_load_b64 v[246:247], v[224:225], off offset:896     // 000000193778: DC560380 F67C00E0
	global_load_b64 v[224:225], v[226:227], off offset:512     // 000000193780: DC560200 E07C00E2
	global_load_b64 v[232:233], v[226:227], off offset:640     // 000000193788: DC560280 E87C00E2
	global_load_b64 v[240:241], v[226:227], off offset:768     // 000000193790: DC560300 F07C00E2
	global_load_b64 v[248:249], v[226:227], off offset:896     // 000000193798: DC560380 F87C00E2
	global_load_b64 v[226:227], v[250:251], off offset:512     // 0000001937A0: DC560200 E27C00FA
	global_load_b64 v[234:235], v[250:251], off offset:640     // 0000001937A8: DC560280 EA7C00FA
	global_load_b64 v[242:243], v[250:251], off offset:768     // 0000001937B0: DC560300 F27C00FA
	global_load_b64 v[250:251], v[250:251], off offset:896     // 0000001937B8: DC560380 FA7C00FA
	v_dual_fmac_f32 v137, v163, v172 :: v_dual_fmac_f32 v152, v164, v174// 0000001937C0: C80159A3 89995DA4
	v_dual_fmac_f32 v138, v165, v176 :: v_dual_fmac_f32 v139, v166, v178// 0000001937C8: C80161A5 8A8B65A6
	v_dual_fmac_f32 v140, v167, v179 :: v_dual_fmac_f32 v141, v168, v177// 0000001937D0: C80167A7 8C8D63A8
	v_dual_fmac_f32 v148, v169, v145 :: v_dual_mul_f32 v59, v59, v176// 0000001937D8: C80723A9 943B613B
	v_dual_mul_f32 v57, v57, v172 :: v_dual_mul_f32 v58, v58, v174// 0000001937E0: C8C75939 393B5D3A
	v_dual_mul_f32 v60, v60, v178 :: v_dual_mul_f32 v61, v61, v179// 0000001937E8: C8C7653C 3C3D673D
	v_dual_mul_f32 v62, v62, v177 :: v_dual_mul_f32 v49, v49, v172// 0000001937F0: C8C7633E 3E315931
	v_dual_mul_f32 v63, v63, v145 :: v_dual_mul_f32 v64, v64, v146// 0000001937F8: C8C7233F 3F412540
	v_dual_mul_f32 v50, v50, v174 :: v_dual_mul_f32 v51, v51, v176// 000000193800: C8C75D32 32336133
	v_dual_mul_f32 v52, v52, v178 :: v_dual_mul_f32 v53, v53, v179// 000000193808: C8C76534 34356735
	v_dual_mul_f32 v54, v54, v177 :: v_dual_mul_f32 v41, v41, v172// 000000193810: C8C76336 36295929
	v_dual_mul_f32 v55, v55, v145 :: v_dual_mul_f32 v56, v56, v146// 000000193818: C8C72337 37392538
	v_dual_mul_f32 v42, v42, v174 :: v_dual_mul_f32 v43, v43, v176// 000000193820: C8C75D2A 2A2B612B
	v_dual_mul_f32 v44, v44, v178 :: v_dual_mul_f32 v45, v45, v179// 000000193828: C8C7652C 2C2D672D
	v_dual_mul_f32 v46, v46, v177 :: v_dual_mul_f32 v33, v33, v172// 000000193830: C8C7632E 2E215921
	v_dual_mul_f32 v47, v47, v145 :: v_dual_mul_f32 v48, v48, v146// 000000193838: C8C7232F 2F312530
	v_dual_mul_f32 v34, v34, v174 :: v_dual_mul_f32 v35, v35, v176// 000000193840: C8C75D22 22236123
	v_dual_mul_f32 v36, v36, v178 :: v_dual_mul_f32 v37, v37, v179// 000000193848: C8C76524 24256725
	v_dual_mul_f32 v38, v38, v177 :: v_dual_mul_f32 v25, v25, v172// 000000193850: C8C76326 26195919
	v_dual_mul_f32 v39, v39, v145 :: v_dual_mul_f32 v40, v40, v146// 000000193858: C8C72327 27292528
	v_dual_mul_f32 v26, v26, v174 :: v_dual_mul_f32 v27, v27, v176// 000000193860: C8C75D1A 1A1B611B
	v_dual_mul_f32 v28, v28, v178 :: v_dual_mul_f32 v29, v29, v179// 000000193868: C8C7651C 1C1D671D
	v_dual_mul_f32 v30, v30, v177 :: v_dual_mul_f32 v17, v17, v172// 000000193870: C8C7631E 1E115911
	v_dual_mul_f32 v31, v31, v145 :: v_dual_mul_f32 v32, v32, v146// 000000193878: C8C7231F 1F212520
	v_dual_mul_f32 v18, v18, v174 :: v_dual_mul_f32 v19, v19, v176// 000000193880: C8C75D12 12136113
	v_dual_mul_f32 v20, v20, v178 :: v_dual_mul_f32 v21, v21, v179// 000000193888: C8C76514 14156715
	v_dual_mul_f32 v22, v22, v177 :: v_dual_mul_f32 v9, v9, v172// 000000193890: C8C76316 16095909
	v_dual_mul_f32 v23, v23, v145 :: v_dual_mul_f32 v24, v24, v146// 000000193898: C8C72317 17192518
	v_dual_mul_f32 v10, v10, v174 :: v_dual_mul_f32 v11, v11, v176// 0000001938A0: C8C75D0A 0A0B610B
	v_dual_mul_f32 v12, v12, v178 :: v_dual_mul_f32 v13, v13, v179// 0000001938A8: C8C7650C 0C0D670D
	v_dual_mul_f32 v14, v14, v177 :: v_dual_mul_f32 v1, v1, v172// 0000001938B0: C8C7630E 0E015901
	v_dual_mul_f32 v15, v15, v145 :: v_dual_mul_f32 v16, v16, v146// 0000001938B8: C8C7230F 0F112510
	v_dual_mul_f32 v2, v2, v174 :: v_dual_mul_f32 v3, v3, v176 // 0000001938C0: C8C75D02 02036103
	v_dual_mul_f32 v4, v4, v178 :: v_dual_mul_f32 v5, v5, v179 // 0000001938C8: C8C76504 04056705
	v_dual_mul_f32 v6, v6, v177 :: v_dual_mov_b32 v177, v147   // 0000001938D0: C8D16306 06B00193
	v_dual_mul_f32 v7, v7, v145 :: v_dual_mul_f32 v8, v8, v146 // 0000001938D8: C8C72307 07092508
	v_fma_f32 v162, v162, v146, v175                           // 0000001938E0: D61300A2 06BF25A2
	v_dual_mov_b32 v174, v170 :: v_dual_mov_b32 v173, v143     // 0000001938E8: CA1001AA AEAC018F
	v_dual_mov_b32 v176, v151 :: v_dual_mov_b32 v179, v150     // 0000001938F0: CA100197 B0B20196
	v_dual_mov_b32 v178, v149 :: v_dual_mov_b32 v175, v142     // 0000001938F8: CA100195 B2AE018E
	v_dual_mov_b32 v171, v144 :: v_dual_mov_b32 v166, v139     // 000000193900: CA100190 ABA6018B
	v_dual_mov_b32 v163, v137 :: v_dual_mov_b32 v164, v152     // 000000193908: CA100189 A3A40198
	v_dual_mov_b32 v165, v138 :: v_dual_mov_b32 v168, v141     // 000000193910: CA10018A A5A8018D
	v_mov_b32_e32 v167, v140                                   // 000000193918: 7F4E038C
	v_mov_b32_e32 v169, v148                                   // 00000019391C: 7F520394
	s_add_i32 s18, s18, 1                                      // 000000193920: 81128112
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000193924: BF870009
	s_cmp_lg_u32 s18, s1                                       // 000000193928: BF070112
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 00000019392C: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[180:187], v[188:195], v[57:64]// 000000193930: CC414039 1CE779B4
	s_waitcnt vmcnt(18)                                        // 000000193938: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[180:187], v[196:203], v[49:56]// 00000019393C: CC414031 1CC789B4
	s_waitcnt vmcnt(17)                                        // 000000193944: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[180:187], v[204:211], v[41:48]// 000000193948: CC414029 1CA799B4
	s_waitcnt vmcnt(16)                                        // 000000193950: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[180:187], v[212:219], v[33:40]// 000000193954: CC414021 1C87A9B4
	s_waitcnt vmcnt(3)                                         // 00000019395C: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[180:187], v[220:227], v[25:32]// 000000193960: CC414019 1C67B9B4
	s_waitcnt vmcnt(2)                                         // 000000193968: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[180:187], v[228:235], v[17:24]// 00000019396C: CC414011 1C47C9B4
	s_waitcnt vmcnt(1)                                         // 000000193974: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[180:187], v[236:243], v[9:16]// 000000193978: CC414009 1C27D9B4
	s_waitcnt vmcnt(0)                                         // 000000193980: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[180:187], v[244:251], v[1:8]// 000000193984: CC414001 1C07E9B4
	s_barrier                                                  // 00000019398C: BFBD0000
	buffer_gl0_inv                                             // 000000193990: E0AC0000 00000000
	s_cbranch_scc0 931                                         // 000000193998: BFA103A3 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1928>
	s_lshl_b32 s0, s18, 4                                      // 00000019399C: 84008412
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001939A0: BF870009
	v_mov_b32_e32 v137, s0                                     // 0000001939A4: 7F120200
	ds_load_b128 v[149:152], v161 offset:16                    // 0000001939A8: DBFC0010 950000A1
	ds_load_b128 v[180:183], v161 offset:32                    // 0000001939B0: DBFC0020 B40000A1
	ds_load_b128 v[184:187], v161 offset:48                    // 0000001939B8: DBFC0030 B80000A1
	ds_load_b128 v[188:191], v161 offset:64                    // 0000001939C0: DBFC0040 BC0000A1
	ds_load_b128 v[192:195], v161 offset:80                    // 0000001939C8: DBFC0050 C00000A1
	ds_load_b128 v[196:199], v161 offset:96                    // 0000001939D0: DBFC0060 C40000A1
	ds_load_b128 v[200:203], v161 offset:112                   // 0000001939D8: DBFC0070 C80000A1
	ds_load_b128 v[204:207], v161 offset:128                   // 0000001939E0: DBFC0080 CC0000A1
	ds_load_b128 v[208:211], v161 offset:144                   // 0000001939E8: DBFC0090 D00000A1
	ds_load_b128 v[212:215], v161 offset:160                   // 0000001939F0: DBFC00A0 D40000A1
	ds_load_b128 v[216:219], v161 offset:176                   // 0000001939F8: DBFC00B0 D80000A1
	ds_load_b128 v[220:223], v161 offset:192                   // 000000193A00: DBFC00C0 DC0000A1
	ds_load_b128 v[232:235], v161 offset:240                   // 000000193A08: DBFC00F0 E80000A1
	ds_load_b128 v[224:227], v161 offset:208                   // 000000193A10: DBFC00D0 E00000A1
	ds_load_b128 v[228:231], v161 offset:224                   // 000000193A18: DBFC00E0 E40000A1
	ds_load_b128 v[236:239], v137 offset:1024                  // 000000193A20: DBFC0400 EC000089
	ds_load_b128 v[145:148], v161                              // 000000193A28: DBFC0000 910000A1
	s_sub_i32 s0, s3, s0                                       // 000000193A30: 81800003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000193A34: BF870009
	v_cmp_gt_i32_e32 vcc_lo, s0, v153                          // 000000193A38: 7C893200
	s_waitcnt lgkmcnt(1)                                       // 000000193A3C: BF89FC17
	v_readfirstlane_b32 s16, v236                              // 000000193A40: 7E2005EC
	s_waitcnt vmcnt(14) lgkmcnt(0)                             // 000000193A44: BF893807
	v_wmma_f32_16x16x16_bf16 v[137:144], v[145:152], v[65:72], v[129:136]// 000000193A48: CC414089 1E068391
	v_readfirstlane_b32 s14, v237                              // 000000193A50: 7E1C05ED
	v_readfirstlane_b32 s4, v238                               // 000000193A54: 7E0805EE
	v_readfirstlane_b32 s6, v239                               // 000000193A58: 7E0C05EF
	s_waitcnt vmcnt(12)                                        // 000000193A5C: BF8933F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[180:187], v[73:80], v[137:144]// 000000193A60: CC414089 1E2693B4
	s_waitcnt vmcnt(10)                                        // 000000193A68: BF892BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193A6C: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[137:144], v[188:195], v[81:88], v[137:144]// 000000193A70: CC414089 1E26A3BC
	s_waitcnt vmcnt(8)                                         // 000000193A78: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[196:203], v[89:96], v[137:144]// 000000193A7C: CC414089 1E26B3C4
	s_waitcnt vmcnt(6)                                         // 000000193A84: BF891BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193A88: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[137:144], v[204:211], v[97:104], v[137:144]// 000000193A8C: CC414089 1E26C3CC
	s_waitcnt vmcnt(4)                                         // 000000193A94: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[212:219], v[105:112], v[137:144]// 000000193A98: CC414089 1E26D3D4
	s_waitcnt vmcnt(2)                                         // 000000193AA0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193AA4: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[137:144], v[220:227], v[113:120], v[137:144]// 000000193AA8: CC414089 1E26E3DC
	s_waitcnt vmcnt(0)                                         // 000000193AB0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[228:235], v[121:128], v[137:144]// 000000193AB4: CC414089 1E26F3E4
	ds_store_2addr_b32 v0, v137, v138 offset1:32               // 000000193ABC: D8382000 008A8900
	ds_store_2addr_b32 v0, v139, v140 offset0:64 offset1:96    // 000000193AC4: D8386040 008C8B00
	ds_store_2addr_b32 v0, v141, v142 offset0:128 offset1:160  // 000000193ACC: D838A080 008E8D00
	ds_store_2addr_b32 v0, v143, v144 offset0:192 offset1:224  // 000000193AD4: D838E0C0 00908F00
	s_waitcnt lgkmcnt(0)                                       // 000000193ADC: BF89FC07
	s_barrier                                                  // 000000193AE0: BFBD0000
	buffer_gl0_inv                                             // 000000193AE4: E0AC0000 00000000
	ds_load_2addr_b32 v[150:151], v156 offset1:32              // 000000193AEC: D8DC2000 9600009C
	s_waitcnt lgkmcnt(0)                                       // 000000193AF4: BF89FC07
	v_add_f32_e32 v137, v137, v150                             // 000000193AF8: 07132D89
	ds_load_2addr_b32 v[149:150], v156 offset0:64 offset1:96   // 000000193AFC: D8DC6040 9500009C
	ds_load_2addr_b32 v[147:148], v156 offset0:128 offset1:160 // 000000193B04: D8DCA080 9300009C
	v_mul_f32_e32 v152, 0x3d800000, v137                       // 000000193B0C: 113112FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193B14: BF870091
	v_cndmask_b32_e32 v137, 0xf149f2ca, v152, vcc_lo           // 000000193B18: 031330FF F149F2CA
	v_mov_b32_dpp v145, v137 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193B20: 7F2202FA FF096189
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193B28: BF870091
	v_max_f32_e32 v145, v145, v145                             // 000000193B2C: 21232391
	v_max_f32_e32 v137, v137, v145                             // 000000193B30: 21132389
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193B34: BF870091
	v_mov_b32_dpp v145, v137 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193B38: 7F2202FA FF096289
	v_max_f32_e32 v145, v145, v145                             // 000000193B40: 21232391
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193B44: BF870091
	v_max_f32_e32 v137, v137, v145                             // 000000193B48: 21132389
	v_mov_b32_dpp v145, v137 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193B4C: 7F2202FA FF096489
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000193B54: BF8700B1
	v_max_f32_e32 v170, v145, v145                             // 000000193B58: 21552391
	ds_load_2addr_b32 v[145:146], v156 offset0:192 offset1:224 // 000000193B5C: D8DCE0C0 9100009C
	v_max_f32_e32 v137, v137, v170                             // 000000193B64: 21135589
	v_mov_b32_dpp v170, v137 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193B68: 7F5402FA FF096889
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193B70: BF870001
	v_max3_f32 v170, v174, v137, v170                          // 000000193B74: D61C00AA 06AB13AE
	v_mov_b32_e32 v137, 0                                      // 000000193B7C: 7F120280
	s_and_saveexec_b32 s5, vcc_lo                              // 000000193B80: BE85206A
	s_cbranch_execz 31                                         // 000000193B84: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd04>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193B88: BF870092
	v_sub_f32_e32 v137, v152, v170                             // 000000193B8C: 09135598
	v_mul_f32_e32 v152, 0x3fb8aa3b, v137                       // 000000193B90: 113112FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193B98: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000193B9C: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193BA4: BF870122
	v_fma_f32 v172, 0x3fb8aa3b, v137, -v152                    // 000000193BA8: D61300AC 866312FF 3FB8AA3B
	v_rndne_f32_e32 v180, v152                                 // 000000193BB4: 7F684798
	v_fmac_f32_e32 v172, 0x32a5705f, v137                      // 000000193BB8: 575912FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193BC0: BF870092
	v_sub_f32_e32 v152, v152, v180                             // 000000193BC4: 09316998
	v_add_f32_e32 v152, v152, v172                             // 000000193BC8: 07315998
	v_cvt_i32_f32_e32 v172, v180                               // 000000193BCC: 7F5811B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000193BD0: BF870292
	v_exp_f32_e32 v152, v152                                   // 000000193BD4: 7F304B98
	.long 0xd71c0098                                           // 000000193BD8: D71C0098
	v_cndmask_b32_e32 v1, v152, v172, vcc_lo                   // 000000193BDC: 02035998
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193BE0: BF8700A1
	v_cndmask_b32_e64 v152, 0, v152, s0                        // 000000193BE4: D5010098 00033080
	.long 0xd41e0000                                           // 000000193BEC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000193BF0: 020312FF 42B17218
	v_cndmask_b32_e64 v137, 0x7f800000, v152, s0               // 000000193BF8: D5010089 000330FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193C04: 8C7E057E
	v_mov_b32_e32 v152, 0                                      // 000000193C08: 7F300280
	v_mov_b32_e32 v172, 0                                      // 000000193C0C: 7F580280
	s_mov_b32 s5, exec_lo                                      // 000000193C10: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v174                         // 000000193C14: 7D235CFF EFA18F08
	s_cbranch_execz 31                                         // 000000193C1C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd9c>
	v_sub_f32_e32 v172, v174, v170                             // 000000193C20: 095955AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193C24: BF870121
	v_mul_f32_e32 v174, 0x3fb8aa3b, v172                       // 000000193C28: 115D58FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193C30: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v172, vcc_lo             // 000000193C34: 020358FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v172, -v174                    // 000000193C3C: D61300B4 86BB58FF 3FB8AA3B
	v_rndne_f32_e32 v181, v174                                 // 000000193C48: 7F6A47AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193C4C: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v172                      // 000000193C50: 576958FF 32A5705F
	v_sub_f32_e32 v174, v174, v181                             // 000000193C58: 095D6BAE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193C5C: BF870121
	v_add_f32_e32 v174, v174, v180                             // 000000193C60: 075D69AE
	v_cvt_i32_f32_e32 v180, v181                               // 000000193C64: 7F6811B5
	v_exp_f32_e32 v174, v174                                   // 000000193C68: 7F5C4BAE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193C6C: BF870095
	.long 0xd71c00ae                                           // 000000193C70: D71C00AE
	v_cndmask_b32_e32 v1, v174, v180, vcc_lo                   // 000000193C74: 020369AE
	v_cndmask_b32_e64 v174, 0, v174, s0                        // 000000193C78: D50100AE 00035C80
	.long 0xd41e0000                                           // 000000193C80: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v172, vcc_lo             // 000000193C84: 020358FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193C8C: BF870001
	v_cndmask_b32_e64 v172, 0x7f800000, v174, s0               // 000000193C90: D50100AC 00035CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193C9C: 8C7E057E
	v_add_f32_e32 v138, v138, v151                             // 000000193CA0: 07152F8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193CA4: BF870091
	v_mul_f32_e32 v138, 0x3d800000, v138                       // 000000193CA8: 111514FF 3D800000
	v_cndmask_b32_e32 v151, 0xf149f2ca, v138, vcc_lo           // 000000193CB0: 032F14FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193CB8: BF870091
	v_mov_b32_dpp v174, v151 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193CBC: 7F5C02FA FF096197
	v_max_f32_e32 v174, v174, v174                             // 000000193CC4: 215D5DAE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193CC8: BF870091
	v_max_f32_e32 v151, v151, v174                             // 000000193CCC: 212F5D97
	v_mov_b32_dpp v174, v151 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193CD0: 7F5C02FA FF096297
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193CD8: BF870091
	v_max_f32_e32 v174, v174, v174                             // 000000193CDC: 215D5DAE
	v_max_f32_e32 v151, v151, v174                             // 000000193CE0: 212F5D97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193CE4: BF870091
	v_mov_b32_dpp v174, v151 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193CE8: 7F5C02FA FF096497
	v_max_f32_e32 v174, v174, v174                             // 000000193CF0: 215D5DAE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193CF4: BF870121
	v_max_f32_e32 v151, v151, v174                             // 000000193CF8: 212F5D97
	v_bfe_u32 v174, v137, 16, 1                                // 000000193CFC: D61000AE 02052189
	v_mov_b32_dpp v180, v151 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193D04: 7F6802FA FF096897
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193D0C: BF870112
	v_add3_u32 v174, v137, v174, 0x7fff                        // 000000193D10: D65500AE 03FF5D89 00007FFF
	v_max3_f32 v151, v176, v151, v180                          // 000000193D1C: D61C0097 06D32FB0
	ds_store_b16_d16_hi v157, v174                             // 000000193D24: DA840000 0000AE9D
	s_and_saveexec_b32 s5, vcc_lo                              // 000000193D2C: BE85206A
	s_cbranch_execz 31                                         // 000000193D30: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xeb0>
	v_sub_f32_e32 v138, v138, v151                             // 000000193D34: 09152F8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193D38: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v138                       // 000000193D3C: 113114FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193D44: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v138, vcc_lo             // 000000193D48: 020314FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v138, -v152                    // 000000193D50: D61300AE 866314FF 3FB8AA3B
	v_rndne_f32_e32 v180, v152                                 // 000000193D5C: 7F684798
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193D60: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v138                      // 000000193D64: 575D14FF 32A5705F
	v_sub_f32_e32 v152, v152, v180                             // 000000193D6C: 09316998
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193D70: BF870121
	v_add_f32_e32 v152, v152, v174                             // 000000193D74: 07315D98
	v_cvt_i32_f32_e32 v174, v180                               // 000000193D78: 7F5C11B4
	v_exp_f32_e32 v152, v152                                   // 000000193D7C: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193D80: BF870095
	.long 0xd71c0098                                           // 000000193D84: D71C0098
	v_cndmask_b32_e32 v1, v152, v174, vcc_lo                   // 000000193D88: 02035D98
	v_cndmask_b32_e64 v152, 0, v152, s0                        // 000000193D8C: D5010098 00033080
	.long 0xd41e0000                                           // 000000193D94: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v138, vcc_lo             // 000000193D98: 020314FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193DA0: BF870001
	v_cndmask_b32_e64 v152, 0x7f800000, v152, s0               // 000000193DA4: D5010098 000330FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193DB0: 8C7E057E
	v_mov_b32_e32 v138, 0                                      // 000000193DB4: 7F140280
	v_mov_b32_e32 v174, 0                                      // 000000193DB8: 7F5C0280
	s_mov_b32 s5, exec_lo                                      // 000000193DBC: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v176                         // 000000193DC0: 7D2360FF EFA18F08
	s_cbranch_execz 31                                         // 000000193DC8: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xf48>
	v_sub_f32_e32 v174, v176, v151                             // 000000193DCC: 095D2FB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193DD0: BF870121
	v_mul_f32_e32 v176, 0x3fb8aa3b, v174                       // 000000193DD4: 11615CFF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193DDC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v174, vcc_lo             // 000000193DE0: 02035CFF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v174, -v176                    // 000000193DE8: D61300B4 86C35CFF 3FB8AA3B
	v_rndne_f32_e32 v181, v176                                 // 000000193DF4: 7F6A47B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193DF8: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v174                      // 000000193DFC: 57695CFF 32A5705F
	v_sub_f32_e32 v176, v176, v181                             // 000000193E04: 09616BB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193E08: BF870121
	v_add_f32_e32 v176, v176, v180                             // 000000193E0C: 076169B0
	v_cvt_i32_f32_e32 v180, v181                               // 000000193E10: 7F6811B5
	v_exp_f32_e32 v176, v176                                   // 000000193E14: 7F604BB0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E18: BF870095
	.long 0xd71c00b0                                           // 000000193E1C: D71C00B0
	v_cndmask_b32_e32 v1, v176, v180, vcc_lo                   // 000000193E20: 020369B0
	v_cndmask_b32_e64 v176, 0, v176, s0                        // 000000193E24: D50100B0 00036080
	.long 0xd41e0000                                           // 000000193E2C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v174, vcc_lo             // 000000193E30: 02035CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193E38: BF870001
	v_cndmask_b32_e64 v174, 0x7f800000, v176, s0               // 000000193E3C: D50100AE 000360FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193E48: 8C7E057E
	s_waitcnt lgkmcnt(3)                                       // 000000193E4C: BF89FC37
	v_add_f32_e32 v139, v139, v149                             // 000000193E50: 07172B8B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E54: BF870091
	v_mul_f32_e32 v139, 0x3d800000, v139                       // 000000193E58: 111716FF 3D800000
	v_cndmask_b32_e32 v149, 0xf149f2ca, v139, vcc_lo           // 000000193E60: 032B16FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E68: BF870091
	v_mov_b32_dpp v176, v149 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193E6C: 7F6002FA FF096195
	v_max_f32_e32 v176, v176, v176                             // 000000193E74: 216161B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E78: BF870091
	v_max_f32_e32 v149, v149, v176                             // 000000193E7C: 212B6195
	v_mov_b32_dpp v176, v149 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193E80: 7F6002FA FF096295
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E88: BF870091
	v_max_f32_e32 v176, v176, v176                             // 000000193E8C: 216161B0
	v_max_f32_e32 v149, v149, v176                             // 000000193E90: 212B6195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193E94: BF870091
	v_mov_b32_dpp v176, v149 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193E98: 7F6002FA FF096495
	v_max_f32_e32 v176, v176, v176                             // 000000193EA0: 216161B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193EA4: BF870121
	v_max_f32_e32 v149, v149, v176                             // 000000193EA8: 212B6195
	v_bfe_u32 v176, v152, 16, 1                                // 000000193EAC: D61000B0 02052198
	v_mov_b32_dpp v180, v149 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000193EB4: 7F6802FA FF096895
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193EBC: BF870112
	v_add3_u32 v176, v152, v176, 0x7fff                        // 000000193EC0: D65500B0 03FF6198 00007FFF
	v_max3_f32 v149, v178, v149, v180                          // 000000193ECC: D61C0095 06D32BB2
	ds_store_b16_d16_hi v157, v176 offset:64                   // 000000193ED4: DA840040 0000B09D
	s_and_saveexec_b32 s5, vcc_lo                              // 000000193EDC: BE85206A
	s_cbranch_execz 30                                         // 000000193EE0: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x105c>
	v_sub_f32_e32 v138, v139, v149                             // 000000193EE4: 09152B8B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193EE8: BF870121
	v_mul_f32_e32 v139, 0x3fb8aa3b, v138                       // 000000193EEC: 111714FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193EF4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v138, vcc_lo             // 000000193EF8: 020314FF C2CE8ED0
	v_fma_f32 v176, 0x3fb8aa3b, v138, -v139                    // 000000193F00: D61300B0 862F14FF 3FB8AA3B
	v_rndne_f32_e32 v180, v139                                 // 000000193F0C: 7F68478B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193F10: BF870091
	v_dual_fmac_f32 v176, 0x32a5705f, v138 :: v_dual_sub_f32 v139, v139, v180// 000000193F14: C80B14FF B08B698B 32A5705F
	v_add_f32_e32 v139, v139, v176                             // 000000193F20: 0717618B
	v_cvt_i32_f32_e32 v176, v180                               // 000000193F24: 7F6011B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000193F28: BF870292
	v_exp_f32_e32 v139, v139                                   // 000000193F2C: 7F164B8B
	.long 0xd71c008b                                           // 000000193F30: D71C008B
	v_cndmask_b32_e32 v1, v139, v176, vcc_lo                   // 000000193F34: 0203618B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000193F38: BF8700A1
	v_cndmask_b32_e64 v139, 0, v139, s0                        // 000000193F3C: D501008B 00031680
	.long 0xd41e0000                                           // 000000193F44: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v138, vcc_lo             // 000000193F48: 020314FF 42B17218
	v_cndmask_b32_e64 v138, 0x7f800000, v139, s0               // 000000193F50: D501008A 000316FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193F5C: 8C7E057E
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v176, 0           // 000000193F60: CA100080 8BB00080
	s_mov_b32 s5, exec_lo                                      // 000000193F68: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v178                         // 000000193F6C: 7D2364FF EFA18F08
	s_cbranch_execz 31                                         // 000000193F74: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x10f4>
	v_sub_f32_e32 v176, v178, v149                             // 000000193F78: 09612BB2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193F7C: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v176                       // 000000193F80: 116560FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000193F88: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v176, vcc_lo             // 000000193F8C: 020360FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v176, -v178                    // 000000193F94: D61300B4 86CB60FF 3FB8AA3B
	v_rndne_f32_e32 v181, v178                                 // 000000193FA0: 7F6A47B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000193FA4: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v176                      // 000000193FA8: 576960FF 32A5705F
	v_sub_f32_e32 v178, v178, v181                             // 000000193FB0: 09656BB2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000193FB4: BF870121
	v_add_f32_e32 v178, v178, v180                             // 000000193FB8: 076569B2
	v_cvt_i32_f32_e32 v180, v181                               // 000000193FBC: 7F6811B5
	v_exp_f32_e32 v178, v178                                   // 000000193FC0: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193FC4: BF870095
	.long 0xd71c00b2                                           // 000000193FC8: D71C00B2
	v_cndmask_b32_e32 v1, v178, v180, vcc_lo                   // 000000193FCC: 020369B2
	v_cndmask_b32_e64 v178, 0, v178, s0                        // 000000193FD0: D50100B2 00036480
	.long 0xd41e0000                                           // 000000193FD8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v176, vcc_lo             // 000000193FDC: 020360FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000193FE4: BF870001
	v_cndmask_b32_e64 v176, 0x7f800000, v178, s0               // 000000193FE8: D50100B0 000364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000193FF4: 8C7E057E
	v_add_f32_e32 v140, v140, v150                             // 000000193FF8: 07192D8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000193FFC: BF870091
	v_mul_f32_e32 v140, 0x3d800000, v140                       // 000000194000: 111918FF 3D800000
	v_cndmask_b32_e32 v150, 0xf149f2ca, v140, vcc_lo           // 000000194008: 032D18FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194010: BF870091
	v_mov_b32_dpp v178, v150 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194014: 7F6402FA FF096196
	v_max_f32_e32 v178, v178, v178                             // 00000019401C: 216565B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194020: BF870091
	v_max_f32_e32 v150, v150, v178                             // 000000194024: 212D6596
	v_mov_b32_dpp v178, v150 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194028: 7F6402FA FF096296
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194030: BF870091
	v_max_f32_e32 v178, v178, v178                             // 000000194034: 216565B2
	v_max_f32_e32 v150, v150, v178                             // 000000194038: 212D6596
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019403C: BF870091
	v_mov_b32_dpp v178, v150 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194040: 7F6402FA FF096496
	v_max_f32_e32 v178, v178, v178                             // 000000194048: 216565B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019404C: BF870121
	v_max_f32_e32 v150, v150, v178                             // 000000194050: 212D6596
	v_bfe_u32 v178, v138, 16, 1                                // 000000194054: D61000B2 0205218A
	v_mov_b32_dpp v180, v150 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019405C: 7F6802FA FF096896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000194064: BF870112
	v_add3_u32 v178, v138, v178, 0x7fff                        // 000000194068: D65500B2 03FF658A 00007FFF
	v_max3_f32 v150, v179, v150, v180                          // 000000194074: D61C0096 06D32DB3
	ds_store_b16_d16_hi v157, v178 offset:128                  // 00000019407C: DA840080 0000B29D
	s_and_saveexec_b32 s5, vcc_lo                              // 000000194084: BE85206A
	s_cbranch_execz 31                                         // 000000194088: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1208>
	v_sub_f32_e32 v139, v140, v150                             // 00000019408C: 09172D8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000194090: BF870121
	v_mul_f32_e32 v140, 0x3fb8aa3b, v139                       // 000000194094: 111916FF 3FB8AA3B
	.long 0xd41b0000                                           // 00000019409C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v139, vcc_lo             // 0000001940A0: 020316FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v139, -v140                    // 0000001940A8: D61300B2 863316FF 3FB8AA3B
	v_rndne_f32_e32 v180, v140                                 // 0000001940B4: 7F68478C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001940B8: BF870112
	v_fmac_f32_e32 v178, 0x32a5705f, v139                      // 0000001940BC: 576516FF 32A5705F
	v_sub_f32_e32 v140, v140, v180                             // 0000001940C4: 0919698C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001940C8: BF870121
	v_add_f32_e32 v140, v140, v178                             // 0000001940CC: 0719658C
	v_cvt_i32_f32_e32 v178, v180                               // 0000001940D0: 7F6411B4
	v_exp_f32_e32 v140, v140                                   // 0000001940D4: 7F184B8C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001940D8: BF870095
	.long 0xd71c008c                                           // 0000001940DC: D71C008C
	v_cndmask_b32_e32 v1, v140, v178, vcc_lo                   // 0000001940E0: 0203658C
	v_cndmask_b32_e64 v140, 0, v140, s0                        // 0000001940E4: D501008C 00031880
	.long 0xd41e0000                                           // 0000001940EC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v139, vcc_lo             // 0000001940F0: 020316FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001940F8: BF870001
	v_cndmask_b32_e64 v139, 0x7f800000, v140, s0               // 0000001940FC: D501008B 000318FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000194108: 8C7E057E
	v_mov_b32_e32 v140, 0                                      // 00000019410C: 7F180280
	v_mov_b32_e32 v178, 0                                      // 000000194110: 7F640280
	s_mov_b32 s5, exec_lo                                      // 000000194114: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v179                         // 000000194118: 7D2366FF EFA18F08
	s_cbranch_execz 30                                         // 000000194120: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x129c>
	v_sub_f32_e32 v178, v179, v150                             // 000000194124: 09652DB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000194128: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 00000019412C: 116764FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000194134: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v178, vcc_lo             // 000000194138: 020364FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 000000194140: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 00000019414C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194150: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v178 :: v_dual_sub_f32 v179, v179, v181// 000000194154: C80B64FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 000000194160: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000194164: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000194168: BF870292
	v_exp_f32_e32 v179, v179                                   // 00000019416C: 7F664BB3
	.long 0xd71c00b3                                           // 000000194170: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000194174: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000194178: BF8700A1
	v_cndmask_b32_e64 v179, 0, v179, s0                        // 00000019417C: D50100B3 00036680
	.long 0xd41e0000                                           // 000000194184: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v178, vcc_lo             // 000000194188: 020364FF 42B17218
	v_cndmask_b32_e64 v178, 0x7f800000, v179, s0               // 000000194190: D50100B2 000366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 00000019419C: 8C7E057E
	s_waitcnt lgkmcnt(4)                                       // 0000001941A0: BF89FC47
	v_add_f32_e32 v141, v141, v147                             // 0000001941A4: 071B278D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001941A8: BF870091
	v_mul_f32_e32 v141, 0x3d800000, v141                       // 0000001941AC: 111B1AFF 3D800000
	v_cndmask_b32_e32 v147, 0xf149f2ca, v141, vcc_lo           // 0000001941B4: 03271AFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001941BC: BF870091
	v_mov_b32_dpp v179, v147 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001941C0: 7F6602FA FF096193
	v_max_f32_e32 v179, v179, v179                             // 0000001941C8: 216767B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001941CC: BF870091
	v_max_f32_e32 v147, v147, v179                             // 0000001941D0: 21276793
	v_mov_b32_dpp v179, v147 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001941D4: 7F6602FA FF096293
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001941DC: BF870091
	v_max_f32_e32 v179, v179, v179                             // 0000001941E0: 216767B3
	v_max_f32_e32 v147, v147, v179                             // 0000001941E4: 21276793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001941E8: BF870091
	v_mov_b32_dpp v179, v147 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001941EC: 7F6602FA FF096493
	v_max_f32_e32 v179, v179, v179                             // 0000001941F4: 216767B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001941F8: BF870121
	v_max_f32_e32 v147, v147, v179                             // 0000001941FC: 21276793
	v_bfe_u32 v179, v139, 16, 1                                // 000000194200: D61000B3 0205218B
	v_mov_b32_dpp v180, v147 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194208: 7F6802FA FF096893
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000194210: BF870112
	v_add3_u32 v179, v139, v179, 0x7fff                        // 000000194214: D65500B3 03FF678B 00007FFF
	v_max3_f32 v147, v177, v147, v180                          // 000000194220: D61C0093 06D327B1
	ds_store_b16_d16_hi v157, v179 offset:192                  // 000000194228: DA8400C0 0000B39D
	s_and_saveexec_b32 s5, vcc_lo                              // 000000194230: BE85206A
	s_cbranch_execz 31                                         // 000000194234: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x13b4>
	v_sub_f32_e32 v140, v141, v147                             // 000000194238: 0919278D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019423C: BF870121
	v_mul_f32_e32 v141, 0x3fb8aa3b, v140                       // 000000194240: 111B18FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000194248: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v140, vcc_lo             // 00000019424C: 020318FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v140, -v141                    // 000000194254: D61300B3 863718FF 3FB8AA3B
	v_rndne_f32_e32 v180, v141                                 // 000000194260: 7F68478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000194264: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v140                      // 000000194268: 576718FF 32A5705F
	v_sub_f32_e32 v141, v141, v180                             // 000000194270: 091B698D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000194274: BF870121
	v_add_f32_e32 v141, v141, v179                             // 000000194278: 071B678D
	v_cvt_i32_f32_e32 v179, v180                               // 00000019427C: 7F6611B4
	v_exp_f32_e32 v141, v141                                   // 000000194280: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194284: BF870095
	.long 0xd71c008d                                           // 000000194288: D71C008D
	v_cndmask_b32_e32 v1, v141, v179, vcc_lo                   // 00000019428C: 0203678D
	v_cndmask_b32_e64 v141, 0, v141, s0                        // 000000194290: D501008D 00031A80
	.long 0xd41e0000                                           // 000000194298: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v140, vcc_lo             // 00000019429C: 020318FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001942A4: BF870001
	v_cndmask_b32_e64 v140, 0x7f800000, v141, s0               // 0000001942A8: D501008C 00031AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001942B4: 8C7E057E
	v_mov_b32_e32 v141, 0                                      // 0000001942B8: 7F1A0280
	v_mov_b32_e32 v179, 0                                      // 0000001942BC: 7F660280
	s_mov_b32 s5, exec_lo                                      // 0000001942C0: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v177                         // 0000001942C4: 7D2362FF EFA18F08
	s_cbranch_execz 31                                         // 0000001942CC: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x144c>
	v_sub_f32_e32 v177, v177, v147                             // 0000001942D0: 096327B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001942D4: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000001942D8: 116762FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001942E0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v177, vcc_lo             // 0000001942E4: 020362FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000001942EC: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000001942F8: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001942FC: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 000000194300: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 000000194308: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019430C: BF870121
	v_add_f32_e32 v179, v179, v180                             // 000000194310: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000194314: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 000000194318: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019431C: BF870095
	.long 0xd71c00b3                                           // 000000194320: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000194324: 020369B3
	v_cndmask_b32_e64 v179, 0, v179, s0                        // 000000194328: D50100B3 00036680
	.long 0xd41e0000                                           // 000000194330: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v177, vcc_lo             // 000000194334: 020362FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019433C: BF870001
	v_cndmask_b32_e64 v179, 0x7f800000, v179, s0               // 000000194340: D50100B3 000366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 00000019434C: 8C7E057E
	v_add_f32_e32 v142, v142, v148                             // 000000194350: 071D298E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194354: BF870091
	v_mul_f32_e32 v148, 0x3d800000, v142                       // 000000194358: 11291CFF 3D800000
	v_cndmask_b32_e32 v142, 0xf149f2ca, v148, vcc_lo           // 000000194360: 031D28FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194368: BF870091
	v_mov_b32_dpp v177, v142 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019436C: 7F6202FA FF09618E
	v_max_f32_e32 v177, v177, v177                             // 000000194374: 216363B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194378: BF870091
	v_max_f32_e32 v142, v142, v177                             // 00000019437C: 211D638E
	v_mov_b32_dpp v177, v142 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194380: 7F6202FA FF09628E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194388: BF870091
	v_max_f32_e32 v177, v177, v177                             // 00000019438C: 216363B1
	v_max_f32_e32 v142, v142, v177                             // 000000194390: 211D638E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194394: BF870091
	v_mov_b32_dpp v177, v142 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194398: 7F6202FA FF09648E
	v_max_f32_e32 v177, v177, v177                             // 0000001943A0: 216363B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001943A4: BF870121
	v_max_f32_e32 v142, v142, v177                             // 0000001943A8: 211D638E
	v_bfe_u32 v177, v140, 16, 1                                // 0000001943AC: D61000B1 0205218C
	v_mov_b32_dpp v180, v142 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001943B4: 7F6802FA FF09688E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001943BC: BF870112
	v_add3_u32 v177, v140, v177, 0x7fff                        // 0000001943C0: D65500B1 03FF638C 00007FFF
	v_max3_f32 v142, v175, v142, v180                          // 0000001943CC: D61C008E 06D31DAF
	ds_store_b16_d16_hi v157, v177 offset:256                  // 0000001943D4: DA840100 0000B19D
	s_and_saveexec_b32 s5, vcc_lo                              // 0000001943DC: BE85206A
	s_cbranch_execz 30                                         // 0000001943E0: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x155c>
	v_sub_f32_e32 v141, v148, v142                             // 0000001943E4: 091B1D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001943E8: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v141                       // 0000001943EC: 11291AFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001943F4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v141, vcc_lo             // 0000001943F8: 02031AFF C2CE8ED0
	v_fma_f32 v177, 0x3fb8aa3b, v141, -v148                    // 000000194400: D61300B1 86531AFF 3FB8AA3B
	v_rndne_f32_e32 v180, v148                                 // 00000019440C: 7F684794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194410: BF870091
	v_dual_fmac_f32 v177, 0x32a5705f, v141 :: v_dual_sub_f32 v148, v148, v180// 000000194414: C80B1AFF B1956994 32A5705F
	v_add_f32_e32 v148, v148, v177                             // 000000194420: 07296394
	v_cvt_i32_f32_e32 v177, v180                               // 000000194424: 7F6211B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000194428: BF870292
	v_exp_f32_e32 v148, v148                                   // 00000019442C: 7F284B94
	.long 0xd71c0094                                           // 000000194430: D71C0094
	v_cndmask_b32_e32 v1, v148, v177, vcc_lo                   // 000000194434: 02036394
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000194438: BF8700A1
	v_cndmask_b32_e64 v148, 0, v148, s0                        // 00000019443C: D5010094 00032880
	.long 0xd41e0000                                           // 000000194444: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v141, vcc_lo             // 000000194448: 02031AFF 42B17218
	v_cndmask_b32_e64 v141, 0x7f800000, v148, s0               // 000000194450: D501008D 000328FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 00000019445C: 8C7E057E
	v_dual_mov_b32 v148, 0 :: v_dual_mov_b32 v177, 0           // 000000194460: CA100080 94B00080
	s_mov_b32 s5, exec_lo                                      // 000000194468: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v175                         // 00000019446C: 7D235EFF EFA18F08
	s_cbranch_execz 30                                         // 000000194474: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x15f0>
	v_sub_f32_e32 v175, v175, v142                             // 000000194478: 095F1DAF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019447C: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v175                       // 000000194480: 11635EFF 3FB8AA3B
	.long 0xd41b0000                                           // 000000194488: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v175, vcc_lo             // 00000019448C: 02035EFF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v175, -v177                    // 000000194494: D61300B4 86C75EFF 3FB8AA3B
	v_rndne_f32_e32 v181, v177                                 // 0000001944A0: 7F6A47B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001944A4: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v175 :: v_dual_sub_f32 v177, v177, v181// 0000001944A8: C80B5EFF B4B16BB1 32A5705F
	v_add_f32_e32 v177, v177, v180                             // 0000001944B4: 076369B1
	v_cvt_i32_f32_e32 v180, v181                               // 0000001944B8: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001944BC: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000001944C0: 7F624BB1
	.long 0xd71c00b1                                           // 0000001944C4: D71C00B1
	v_cndmask_b32_e32 v1, v177, v180, vcc_lo                   // 0000001944C8: 020369B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001944CC: BF8700A1
	v_cndmask_b32_e64 v177, 0, v177, s0                        // 0000001944D0: D50100B1 00036280
	.long 0xd41e0000                                           // 0000001944D8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v175, vcc_lo             // 0000001944DC: 02035EFF 42B17218
	v_cndmask_b32_e64 v177, 0x7f800000, v177, s0               // 0000001944E4: D50100B1 000362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001944F0: 8C7E057E
	s_waitcnt lgkmcnt(5)                                       // 0000001944F4: BF89FC57
	v_add_f32_e32 v143, v143, v145                             // 0000001944F8: 071F238F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001944FC: BF870091
	v_mul_f32_e32 v145, 0x3d800000, v143                       // 000000194500: 11231EFF 3D800000
	v_cndmask_b32_e32 v143, 0xf149f2ca, v145, vcc_lo           // 000000194508: 031F22FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194510: BF870091
	v_mov_b32_dpp v175, v143 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194514: 7F5E02FA FF09618F
	v_max_f32_e32 v175, v175, v175                             // 00000019451C: 215F5FAF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194520: BF870091
	v_max_f32_e32 v143, v143, v175                             // 000000194524: 211F5F8F
	v_mov_b32_dpp v175, v143 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194528: 7F5E02FA FF09628F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194530: BF870091
	v_max_f32_e32 v175, v175, v175                             // 000000194534: 215F5FAF
	v_max_f32_e32 v143, v143, v175                             // 000000194538: 211F5F8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019453C: BF870091
	v_mov_b32_dpp v175, v143 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194540: 7F5E02FA FF09648F
	v_max_f32_e32 v175, v175, v175                             // 000000194548: 215F5FAF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019454C: BF870121
	v_max_f32_e32 v143, v143, v175                             // 000000194550: 211F5F8F
	v_bfe_u32 v175, v141, 16, 1                                // 000000194554: D61000AF 0205218D
	v_mov_b32_dpp v180, v143 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019455C: 7F6802FA FF09688F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000194564: BF870112
	v_add3_u32 v175, v141, v175, 0x7fff                        // 000000194568: D65500AF 03FF5F8D 00007FFF
	v_max3_f32 v143, v173, v143, v180                          // 000000194574: D61C008F 06D31FAD
	ds_store_b16_d16_hi v157, v175 offset:320                  // 00000019457C: DA840140 0000AF9D
	s_and_saveexec_b32 s5, vcc_lo                              // 000000194584: BE85206A
	s_cbranch_execz 30                                         // 000000194588: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1704>
	v_sub_f32_e32 v145, v145, v143                             // 00000019458C: 09231F91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194590: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v145                       // 000000194594: 112922FF 3FB8AA3B
	v_fma_f32 v175, 0x3fb8aa3b, v145, -v148                    // 00000019459C: D61300AF 865322FF 3FB8AA3B
	v_rndne_f32_e32 v180, v148                                 // 0000001945A8: 7F684794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001945AC: BF870121
	v_dual_sub_f32 v148, v148, v180 :: v_dual_fmac_f32 v175, 0x32a5705f, v145// 0000001945B0: C9416994 94AF22FF 32A5705F
	.long 0xd41b0000                                           // 0000001945BC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v145, vcc_lo             // 0000001945C0: 020322FF C2CE8ED0
	v_add_f32_e32 v148, v148, v175                             // 0000001945C8: 07295F94
	v_cvt_i32_f32_e32 v175, v180                               // 0000001945CC: 7F5E11B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001945D0: BF870292
	v_exp_f32_e32 v148, v148                                   // 0000001945D4: 7F284B94
	.long 0xd71c0094                                           // 0000001945D8: D71C0094
	v_cndmask_b32_e32 v1, v148, v175, vcc_lo                   // 0000001945DC: 02035F94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001945E0: BF8700A1
	v_cndmask_b32_e64 v148, 0, v148, s0                        // 0000001945E4: D5010094 00032880
	.long 0xd41e0000                                           // 0000001945EC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v145, vcc_lo             // 0000001945F0: 020322FF 42B17218
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s0               // 0000001945F8: D5010094 000328FF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 000000194604: 8C7E057E
	v_mov_b32_e32 v175, 0                                      // 000000194608: 7F5E0280
	v_mov_b32_e32 v145, 0                                      // 00000019460C: 7F220280
	s_mov_b32 s5, exec_lo                                      // 000000194610: BE85007E
	v_cmpx_lt_f32_e32 0xefa18f08, v173                         // 000000194614: 7D235AFF EFA18F08
	s_cbranch_execz 31                                         // 00000019461C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x179c>
	v_sub_f32_e32 v145, v173, v143                             // 000000194620: 09231FAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000194624: BF870121
	v_mul_f32_e32 v173, 0x3fb8aa3b, v145                       // 000000194628: 115B22FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000194630: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v145, vcc_lo             // 000000194634: 020322FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v145, -v173                    // 00000019463C: D61300B4 86B722FF 3FB8AA3B
	v_rndne_f32_e32 v181, v173                                 // 000000194648: 7F6A47AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019464C: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v145                      // 000000194650: 576922FF 32A5705F
	v_sub_f32_e32 v173, v173, v181                             // 000000194658: 095B6BAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019465C: BF870121
	v_add_f32_e32 v173, v173, v180                             // 000000194660: 075B69AD
	v_cvt_i32_f32_e32 v180, v181                               // 000000194664: 7F6811B5
	v_exp_f32_e32 v173, v173                                   // 000000194668: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019466C: BF870095
	.long 0xd71c00ad                                           // 000000194670: D71C00AD
	v_cndmask_b32_e32 v1, v173, v180, vcc_lo                   // 000000194674: 020369AD
	v_cndmask_b32_e64 v173, 0, v173, s0                        // 000000194678: D50100AD 00035A80
	.long 0xd41e0000                                           // 000000194680: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v145, vcc_lo             // 000000194684: 020322FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019468C: BF870001
	v_cndmask_b32_e64 v145, 0x7f800000, v173, s0               // 000000194690: D5010091 00035AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 00000019469C: 8C7E057E
	v_add_f32_e32 v144, v144, v146                             // 0000001946A0: 07212590
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001946A4: BF870091
	v_mul_f32_e32 v146, 0x3d800000, v144                       // 0000001946A8: 112520FF 3D800000
	v_cndmask_b32_e32 v144, 0xf149f2ca, v146, vcc_lo           // 0000001946B0: 032124FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001946B8: BF870091
	v_mov_b32_dpp v173, v144 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001946BC: 7F5A02FA FF096190
	v_max_f32_e32 v173, v173, v173                             // 0000001946C4: 215B5BAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001946C8: BF870091
	v_max_f32_e32 v144, v144, v173                             // 0000001946CC: 21215B90
	v_mov_b32_dpp v173, v144 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001946D0: 7F5A02FA FF096290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001946D8: BF870091
	v_max_f32_e32 v173, v173, v173                             // 0000001946DC: 215B5BAD
	v_max_f32_e32 v144, v144, v173                             // 0000001946E0: 21215B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001946E4: BF870091
	v_mov_b32_dpp v173, v144 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001946E8: 7F5A02FA FF096490
	v_max_f32_e32 v173, v173, v173                             // 0000001946F0: 215B5BAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001946F4: BF870121
	v_max_f32_e32 v144, v144, v173                             // 0000001946F8: 21215B90
	v_bfe_u32 v173, v148, 16, 1                                // 0000001946FC: D61000AD 02052194
	v_mov_b32_dpp v180, v144 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194704: 7F6802FA FF096890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019470C: BF870112
	v_add3_u32 v173, v148, v173, 0x7fff                        // 000000194710: D65500AD 03FF5B94 00007FFF
	v_max3_f32 v144, v171, v144, v180                          // 00000019471C: D61C0090 06D321AB
	ds_store_b16_d16_hi v157, v173 offset:384                  // 000000194724: DA840180 0000AD9D
	s_and_saveexec_b32 s0, vcc_lo                              // 00000019472C: BE80206A
	s_cbranch_execz 27                                         // 000000194730: BFA5001B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18a0>
	v_sub_f32_e32 v146, v146, v144                             // 000000194734: 09252192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194738: BF870091
	v_mul_f32_e32 v173, 0x3fb8aa3b, v146                       // 00000019473C: 115B24FF 3FB8AA3B
	v_fma_f32 v175, 0x3fb8aa3b, v146, -v173                    // 000000194744: D61300AF 86B724FF 3FB8AA3B
	v_rndne_f32_e32 v180, v173                                 // 000000194750: 7F6847AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000194754: BF870112
	v_fmac_f32_e32 v175, 0x32a5705f, v146                      // 000000194758: 575F24FF 32A5705F
	v_sub_f32_e32 v173, v173, v180                             // 000000194760: 095B69AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000194764: BF8701B1
	v_add_f32_e32 v173, v173, v175                             // 000000194768: 075B5FAD
	v_cvt_i32_f32_e32 v175, v180                               // 00000019476C: 7F5E11B4
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 000000194770: 7C3724FF C2CE8ED0
	v_exp_f32_e32 v173, v173                                   // 000000194778: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019477C: BF870095
	.long 0xd71c00ad                                           // 000000194780: D71C00AD
	v_cndmask_b32_e32 v1, v173, v175, vcc_lo                   // 000000194784: 02035FAD
	v_cndmask_b32_e32 v173, 0, v173, vcc_lo                    // 000000194788: 035B5A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000019478C: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000194794: BF870002
	v_cndmask_b32_e32 v175, 0x7f800000, v173, vcc_lo           // 000000194798: 035F5AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001947A0: 8C7E007E
	v_mov_b32_e32 v146, 0                                      // 0000001947A4: 7F240280
	s_mov_b32 s0, exec_lo                                      // 0000001947A8: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v171                         // 0000001947AC: 7D2356FF EFA18F08
	s_cbranch_execz 64384                                      // 0000001947B4: BFA5FB80 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x6b8>
	v_sub_f32_e32 v146, v171, v144                             // 0000001947B8: 092521AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001947BC: BF870121
	v_mul_f32_e32 v171, 0x3fb8aa3b, v146                       // 0000001947C0: 115724FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000001947C8: 7C3724FF C2CE8ED0
	v_fma_f32 v173, 0x3fb8aa3b, v146, -v171                    // 0000001947D0: D61300AD 86AF24FF 3FB8AA3B
	v_rndne_f32_e32 v180, v171                                 // 0000001947DC: 7F6847AB
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001947E0: BF870112
	v_fmac_f32_e32 v173, 0x32a5705f, v146                      // 0000001947E4: 575B24FF 32A5705F
	v_sub_f32_e32 v171, v171, v180                             // 0000001947EC: 095769AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001947F0: BF870121
	v_add_f32_e32 v171, v171, v173                             // 0000001947F4: 07575BAB
	v_cvt_i32_f32_e32 v173, v180                               // 0000001947F8: 7F5A11B4
	v_exp_f32_e32 v171, v171                                   // 0000001947FC: 7F564BAB
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000194800: BF870095
	.long 0xd71c00ab                                           // 000000194804: D71C00AB
	v_cndmask_b32_e32 v1, v171, v173, vcc_lo                   // 000000194808: 02035BAB
	v_cndmask_b32_e32 v171, 0, v171, vcc_lo                    // 00000019480C: 03575680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 000000194810: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000194818: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v171, vcc_lo           // 00000019481C: 032556FF 7F800000
	s_branch 64356                                             // 000000194824: BFA0FB64 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi1ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x6b8>
	v_mov_b32_e32 v8, v155                                     // 000000194828: 7E10039B
	s_mul_i32 s0, s20, 12                                      // 00000019482C: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000194830: BF870001
	v_or_b32_e32 v7, v8, v153                                  // 000000194834: 380F3308
	v_or_b32_e32 v0, s0, v154                                  // 000000194838: 38013400
	v_mov_b32_dpp v78, v141 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019483C: 7E9C02FA FF09618D
	v_mov_b32_dpp v75, v139 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194844: 7E9602FA FF09618B
	v_mov_b32_dpp v74, v138 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019484C: 7E9402FA FF09618A
	v_mov_b32_dpp v76, v140 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194854: 7E9802FA FF09618C
	v_lshlrev_b32_e32 v0, 8, v0                                // 00000019485C: 30000088
	v_mov_b32_e32 v8, 0                                        // 000000194860: 7E100280
	v_dual_add_f32 v78, v141, v78 :: v_dual_add_f32 v81, v139, v75// 000000194864: C9089D8D 4E50978B
	v_add_f32_e32 v83, v138, v74                               // 00000019486C: 06A6958A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000194870: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 000000194874: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 00000019487C: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 000000194888: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 00000019488C: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 000000194894: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 00000019489C: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001948A0: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001948A8: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001948B0: 34403E9F
	.long 0xd7006a0f                                           // 0000001948B4: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001948B8: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001948BC: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001948C0: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001948C8: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001948CC: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001948D0: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001948D8: BF870233
	.long 0xd73c000f                                           // 0000001948DC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001948E0: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001948E4: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001948EC: 34504E9F
	.long 0xd73c0017                                           // 0000001948F0: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001948F4: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001948F8: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001948FC: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 000000194904: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 000000194908: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019490C: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 000000194910: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 000000194918: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 00000019491C: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 000000194920: D5207C20 01AA4108
	.long 0xd7006a37                                           // 000000194928: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 00000019492C: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 000000194930: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000194934: BF8700B3
	.long 0xd73c001f                                           // 000000194938: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 00000019493C: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 000000194940: D5207C38 01AA300B
	.long 0xd7006a27                                           // 000000194948: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 00000019494C: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 000000194950: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 000000194958: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000019495C: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 000000194960: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 000000194964: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 00000019496C: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 000000194970: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 000000194974: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 00000019497C: D5207C40 01AA400B
	.long 0xd7006a07                                           // 000000194984: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 000000194988: 02028307
	s_clause 0x2                                               // 00000019498C: BF850002
	global_load_u16 v80, v[69:70], off                         // 000000194990: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 000000194998: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001949A0: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001949A8: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001949B0: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001949B4: 02024E81
	.long 0xd73c002f                                           // 0000001949B8: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001949BC: 02025E81
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001949C0: 06A2A2FA FF096451
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001949C8: BF8700C4
	.long 0xd73c0056                                           // 0000001949CC: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001949D0: 02020E81
	v_mov_b32_dpp v8, v152 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001949D4: 7E1002FA FF096198
	v_mov_b32_dpp v7, v137 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001949DC: 7E0E02FA FF096189
	.long 0xd7006a43                                           // 0000001949E4: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001949E8: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001949EC: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001949F4: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001949F8: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001949FC: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 000000194A00: D5207C42 01AA600B
	.long 0xd7006a47                                           // 000000194A08: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 000000194A0C: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 000000194A10: D5207C48 01AAAE0B
	s_clause 0x9                                               // 000000194A18: BF850009
	global_load_u16 v99, v[63:64], off                         // 000000194A1C: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 000000194A24: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 000000194A2C: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 000000194A34: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 000000194A3C: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 000000194A44: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 000000194A4C: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 000000194A54: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 000000194A5C: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 000000194A64: DC4A0040 617C0047
	v_dual_add_f32 v8, v152, v8 :: v_dual_add_f32 v7, v137, v7 // 000000194A6C: C9081198 08060F89
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194A74: 069C9CFA FF09644E
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194A7C: 06B0A2FA FF096851
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194A84: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4)                            // 000000194A8C: BF870004
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194A90: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194A98: 060E0EFA FF096207
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AA0: 06A29CFA FF09684E
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 000000194AA8: D6FC7C6E 03CAB158
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AB0: 06A6A6FA FF096453
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AB8: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AC0: 060E0EFA FF096407
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 000000194AC8: D6FC7C73 03CAA351
	v_rcp_f32_e32 v90, v110                                    // 000000194AD0: 7EB4556E
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AD4: 06B2A6FA FF096853
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194ADC: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194AE4: 06D80EFA FF096807
	.long 0xd7000507                                           // 000000194AEC: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 000000194AF0: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000194AF4: BF870211
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 000000194AF8: D5207C08 0016200D
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 000000194B00: D6FC7C76 03CAD76B
	.long 0xd700050f                                           // 000000194B08: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000194B0C: 02022E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000194B10: BF870191
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 000000194B14: D5207C10 0016300D
	v_rcp_f32_e32 v121, v118                                   // 000000194B1C: 7EF25576
	.long 0xd7000517                                           // 000000194B20: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000194B24: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000194B28: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 000000194B2C: D5207C18 0016400D
	.long 0xd700051f                                           // 000000194B34: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 000000194B38: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 000000194B3C: D5207C20 0016500D
	.long 0xd7000527                                           // 000000194B44: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 000000194B48: 02025E0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000194B4C: BF870001
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 000000194B50: D5207C28 0016600D
	.long 0xd700052f                                           // 000000194B58: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 000000194B5C: 0202AC0C
	v_add_f32_e32 v84, v140, v76                               // 000000194B60: 06A8998C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 000000194B64: D5207C30 0016AE0D
	s_clause 0x1f                                              // 000000194B6C: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 000000194B70: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 000000194B78: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 000000194B80: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 000000194B88: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 000000194B90: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 000000194B98: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 000000194BA0: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 000000194BA8: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 000000194BB0: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 000000194BB8: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 000000194BC0: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 000000194BC8: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 000000194BD0: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 000000194BD8: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 000000194BE0: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 000000194BE8: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 000000194BF0: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 000000194BF8: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 000000194C00: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 000000194C08: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 000000194C10: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 000000194C18: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 000000194C20: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 000000194C28: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 000000194C30: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 000000194C38: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 000000194C40: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 000000194C48: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 000000194C50: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 000000194C58: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 000000194C60: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 000000194C68: DC4A00C0 447C0047
	s_clause 0x1                                               // 000000194C70: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 000000194C74: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 000000194C7C: DC4A00E0 407C0041
	v_fma_f32 v66, -v118, v121, 1.0                            // 000000194C84: D6130042 23CAF376
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 000000194C8C: D6FC7C75 03CAD96C
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 000000194C94: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 000000194C9C: D6FC0478 03CAD6F2
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 000000194CA4: D6FC7C6D 03CAB359
	v_fmac_f32_e32 v121, v66, v121                             // 000000194CAC: 56F2F342
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194CB0: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 000000194CB8: 7EF45575
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 000000194CBC: D6FC0270 03CAB2F2
	v_rcp_f32_e32 v91, v109                                    // 000000194CC4: 7EB6556D
	v_mul_f32_e32 v66, v120, v121                              // 000000194CC8: 1084F378
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194CCC: 06A8A8FA FF096454
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 000000194CD4: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 000000194CDC: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 000000194CE4: D6FC0371 03CAB0F2
	v_fma_f32 v145, -v118, v66, v120                           // 000000194CEC: D6130091 25E28576
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000194CF4: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 000000194CFC: D6130041 23CAF575
	v_rcp_f32_e32 v84, v115                                    // 000000194D04: 7EA85573
	v_fma_f32 v71, -v109, v91, 1.0                             // 000000194D08: D6130047 23CAB76D
	v_fmac_f32_e32 v66, v145, v121                             // 000000194D10: 5684F391
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 000000194D14: D6FC7C6F 03CAA753
	v_fmac_f32_e32 v122, v65, v122                             // 000000194D1C: 56F4F541
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 000000194D20: D6FC0072 03CAA6F2
	v_dual_fmac_f32 v91, v71, v91 :: v_dual_fmac_f32 v90, v72, v90// 000000194D28: C800B747 5B5AB548
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000194D30: BF870194
	v_rcp_f32_e32 v85, v111                                    // 000000194D34: 7EAA556F
	v_mul_f32_e32 v65, v119, v122                              // 000000194D38: 1082F577
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000194D3C: BF870236
	v_fma_f32 v143, -v115, v84, 1.0                            // 000000194D40: D613008F 23CAA973
	v_fma_f32 v118, -v118, v66, v120                           // 000000194D48: D6130076 25E28576
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 000000194D50: C8C6B770 4748B571
	v_fma_f32 v144, -v117, v65, v119                           // 000000194D58: D6130090 25DE8375
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000194D60: BF870224
	v_fmac_f32_e32 v84, v143, v84                              // 000000194D64: 56A8A98F
	.long 0x7f003880                                           // 000000194D68: 7F003880
	v_fma_f32 v146, -v109, v71, v112                           // 000000194D6C: D6130092 25C28F6D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000194D74: BF870005
	v_fma_f32 v142, -v111, v85, 1.0                            // 000000194D78: D613008E 23CAAB6F
	v_fmac_f32_e32 v65, v144, v122                             // 000000194D80: 5682F590
	v_mul_f32_e32 v143, v116, v84                              // 000000194D84: 111EA974
	v_fma_f32 v147, -v110, v72, v113                           // 000000194D88: D6130093 25C6916E
	v_fmac_f32_e32 v71, v146, v91                              // 000000194D90: 568EB792
	v_fmac_f32_e32 v85, v142, v85                              // 000000194D94: 56AAAB8E
	v_fma_f32 v117, -v117, v65, v119                           // 000000194D98: D6130075 25DE8375
	v_fma_f32 v144, -v115, v143, v116                          // 000000194DA0: D6130090 25D31F73
	v_fmac_f32_e32 v72, v147, v90                              // 000000194DA8: 5690B593
	v_fma_f32 v109, -v109, v71, v112                           // 000000194DAC: D613006D 25C28F6D
	v_mul_f32_e32 v142, v114, v85                              // 000000194DB4: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 000000194DB8: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 000000194DC0: BEEA0004
	.long 0x7f9e3980                                           // 000000194DC4: 7F9E3980
	v_div_fmas_f32 v117, v118, v121, v66                       // 000000194DC8: D6370075 050AF376
	v_fma_f32 v148, -v111, v142, v114                          // 000000194DD0: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 000000194DD8: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 000000194DE0: D613006C 25C6916E
	.long 0x7f983980                                           // 000000194DE8: 7F983980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 000000194DEC: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000194DF4: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 000000194DF8: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 000000194E00: 571EA990
	.long 0x7f9a3980                                           // 000000194E04: 7F9A3980
	v_mul_f32_e32 v58, v58, v65                                // 000000194E08: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000194E0C: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 000000194E10: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 000000194E18: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 000000194E1C: D613006E 25D31F73
	.long 0x7f963980                                           // 000000194E24: 7F963980
	.long 0x7f943980                                           // 000000194E28: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 000000194E2C: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 000000194E34: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 000000194E38: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 000000194E3C: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 000000194E40: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 000000194E48: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 000000194E4C: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 000000194E50: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 000000194E54: 10048302
	s_waitcnt vmcnt(47)                                        // 000000194E58: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000194E5C: 30929290
	s_waitcnt vmcnt(46)                                        // 000000194E60: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 000000194E64: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 000000194E6C: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 000000194E70: 3064A490
	s_waitcnt vmcnt(44)                                        // 000000194E74: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 000000194E78: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 000000194E7C: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 000000194E80: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 000000194E88: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 000000194E90: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 000000194E98: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000194EA0: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 000000194EA8: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 000000194EAC: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 000000194EB8: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 000000194EC4: 7EE84767
	s_waitcnt vmcnt(40)                                        // 000000194EC8: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 000000194ECC: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 000000194ED0: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 000000194ED4: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000194ED8: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 000000194EDC: 30C6C690
	s_waitcnt vmcnt(37)                                        // 000000194EE0: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 000000194EE4: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 000000194EE8: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 000000194EF4: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 000000194EFC: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 000000194F08: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 000000194F14: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 000000194F20: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 000000194F2C: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 000000194F34: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 000000194F40: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 000000194F44: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 000000194F50: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 000000194F5C: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 000000194F64: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 000000194F70: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 000000194F7C: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 000000194F80: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 000000194F88: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 000000194F8C: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 000000194F94: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 000000194F98: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 000000194F9C: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 000000194FA0: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000194FA4: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000194FA8: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 000000194FAC: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 000000194FB0: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 000000194FB4: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 000000194FC0: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 000000194FC4: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 000000194FD0: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 000000194FD8: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 000000194FE0: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 000000194FE8: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 000000194FEC: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 000000194FF8: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 000000195004: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 000000195008: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 00000019500C: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 000000195018: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 000000195020: 7EE24B71
	.long 0xd71c0067                                           // 000000195024: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 000000195028: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 00000019502C: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 000000195034: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 000000195038: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 00000019503C: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 000000195048: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 000000195054: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 000000195060: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 000000195064: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 000000195070: C913417A 7A66CE80
	.long 0xd71c0070                                           // 000000195078: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 00000019507C: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000195080: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 000000195088: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 00000019508C: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 000000195098: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001950A4: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001950B0: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001950B4: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001950C0: C9495796 96773977
	.long 0xd71c0071                                           // 0000001950C8: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001950CC: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001950D0: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001950D4: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001950DC: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001950E8: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001950EC: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001950F4: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001950F8: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001950FC: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 000000195104: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 000000195108: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 00000019510C: 07234991
	v_exp_f32_e32 v144, v144                                   // 000000195110: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 000000195114: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000019511C: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 000000195124: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 000000195128: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 00000019512C: 7EF24B79
	.long 0xd71c0073                                           // 000000195130: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 000000195134: 0202EB73
	.long 0xd71c0075                                           // 000000195138: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 00000019513C: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 000000195140: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 000000195148: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 000000195150: 7EF44B7A
	.long 0xd71c0078                                           // 000000195154: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 000000195158: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 00000019515C: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 000000195160: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 000000195164: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 000000195168: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 000000195170: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 000000195174: 02033779
	v_rndne_f32_e32 v169, v149                                 // 000000195178: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 00000019517C: 09294F94
	v_exp_f32_e32 v145, v145                                   // 000000195180: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 000000195184: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 000000195188: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 000000195190: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 000000195194: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 000000195198: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 0000001951A0: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001951A4: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001951A8: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001951B0: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001951B4: 072B5195
	v_exp_f32_e32 v148, v148                                   // 0000001951B8: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 0000001951BC: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 0000001951C0: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001951C4: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001951C8: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 0000001951D0: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 0000001951D4: 7F2A4B95
	.long 0xd71c0079                                           // 0000001951D8: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001951DC: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 0000001951E0: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001951E4: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001951E8: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 0000001951F0: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001951F4: 02034394
	.long 0xd71c0074                                           // 0000001951F8: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001951FC: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 000000195200: 06F062F2
	.long 0xd41b0005                                           // 000000195204: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 000000195208: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 000000195210: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 000000195218: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 000000195220: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 000000195224: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 000000195228: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 00000019522C: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 000000195234: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 00000019523C: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 000000195240: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 000000195248: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000019524C: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 000000195254: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 000000195258: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 000000195260: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 000000195268: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 000000195270: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 000000195274: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 000000195280: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 000000195284: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 00000019528C: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 000000195298: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 0000001952A0: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001952AC: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 0000001952B0: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001952B8: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001952C0: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001952C4: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001952CC: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001952D4: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001952DC: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 0000001952E4: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001952EC: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001952F8: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001952FC: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 000000195304: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 000000195310: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 000000195318: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 00000019531C: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 000000195324: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 00000019532C: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 000000195334: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 000000195340: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195348: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 00000019534C: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 000000195354: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195358: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 00000019535C: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 000000195360: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 000000195364: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 00000019536C: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 000000195374: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 000000195378: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 000000195380: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 000000195388: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 00000019538C: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000195390: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 000000195394: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 000000195398: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019539C: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 0000001953A0: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 0000001953A8: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001953B0: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001953B4: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001953BC: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001953C4: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 0000001953CC: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001953D0: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 0000001953D4: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001953D8: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001953E0: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 0000001953E4: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001953E8: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001953F0: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001953F4: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001953FC: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 000000195404: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 00000019540C: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 000000195414: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 000000195418: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 00000019541C: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000195424: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 000000195428: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 000000195430: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 000000195434: 10CE6533
	.long 0x7e9e39b9                                           // 000000195438: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 00000019543C: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 000000195444: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 000000195448: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 000000195450: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195458: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 00000019545C: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 000000195464: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 00000019546C: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 000000195470: 7EB65564
	.long 0x7e0039ba                                           // 000000195474: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 000000195478: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 000000195480: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 000000195484: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 00000019548C: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 000000195490: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 000000195498: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001954A0: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 0000001954A8: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001954AC: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 0000001954B4: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001954BC: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 0000001954C8: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 0000001954CC: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 0000001954D4: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 0000001954DC: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001954E0: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001954E4: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001954EC: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001954F4: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 0000001954FC: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 000000195500: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 000000195504: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 000000195508: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 000000195510: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 000000195514: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195518: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 00000019551C: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 000000195520: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000195528: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 00000019552C: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 000000195530: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 000000195534: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019553C: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 000000195540: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 000000195548: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 00000019554C: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195554: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 000000195558: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 000000195560: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 000000195568: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 00000019556C: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 000000195574: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000195578: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 00000019557C: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 000000195584: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 00000019558C: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 000000195590: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 000000195598: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 0000001955A0: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001955A4: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 0000001955AC: 7E9A39BB
	.long 0x7e0039bc                                           // 0000001955B0: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001955B4: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001955BC: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 0000001955C8: 107A693D
	s_clause 0x1                                               // 0000001955CC: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001955D0: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001955D8: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 0000001955E0: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001955E4: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001955EC: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 0000001955F4: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001955F8: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 000000195600: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 000000195604: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 000000195608: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 000000195610: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 000000195618: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 00000019561C: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 000000195624: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 00000019562C: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 000000195634: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000195638: BF870314
	v_rcp_f32_e32 v107, v100                                   // 00000019563C: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 000000195640: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 000000195648: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 00000019564C: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 000000195650: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195658: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 00000019565C: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 000000195660: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195668: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 00000019566C: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 000000195670: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195678: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 00000019567C: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 000000195684: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 000000195688: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000195690: BF870291
	v_rcp_f32_e32 v91, v79                                     // 000000195694: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 000000195698: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001956A0: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001956A4: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 0000001956AC: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001956B0: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001956B4: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001956C0: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 0000001956C4: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 0000001956CC: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001956D4: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 0000001956D8: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 0000001956DC: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 0000001956E4: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 0000001956EC: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001956F4: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 0000001956F8: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 000000195700: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 000000195708: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 00000019570C: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 000000195718: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 000000195720: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 000000195728: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 000000195730: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 000000195738: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 00000019573C: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 000000195740: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 000000195748: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 00000019574C: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 000000195750: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 000000195754: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 000000195758: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000195760: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 000000195764: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 00000019576C: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 000000195770: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 000000195778: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 00000019577C: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 000000195784: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 00000019578C: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 000000195790: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 000000195798: D637003D 0563236D
	.long 0x7e9839bc                                           // 0000001957A0: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001957A4: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001957AC: BEEA0004
	.long 0x7e0039bb                                           // 0000001957B0: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001957B4: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 0000001957BC: 36909881
	.long 0x7e9639be                                           // 0000001957C0: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001957C4: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001957CC: 368E0081
	.long 0x7e0039bd                                           // 0000001957D0: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001957D4: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001957E0: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001957EC: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001957F0: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001957FC: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 000000195804: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 00000019580C: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 000000195818: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019581C: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 000000195820: D627003A 05C6BD3A
	s_clause 0x1                                               // 000000195828: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 00000019582C: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 000000195834: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 00000019583C: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 000000195844: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 000000195850: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 00000019585C: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 000000195860: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 000000195868: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 000000195870: 067B2F72
	.long 0x7e0039ba                                           // 000000195874: 7E0039BA
	.long 0x7e9439b9                                           // 000000195878: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 00000019587C: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 000000195880: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 000000195884: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 000000195888: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 000000195890: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 000000195894: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 00000019589C: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001958A4: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 0000001958A8: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 0000001958AC: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001958B0: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001958BC: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 0000001958C0: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001958C4: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001958D0: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001958D8: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001958E0: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001958E4: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001958E8: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001958F0: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001958F4: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001958F8: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 000000195900: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 000000195904: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 00000019590C: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 000000195910: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 000000195918: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 00000019591C: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 000000195924: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 00000019592C: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 000000195930: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 000000195938: D637003E 04FAD748
	.long 0xd71c003c                                           // 000000195940: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 000000195944: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000195948: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 000000195950: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 000000195954: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 000000195960: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 000000195968: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 00000019596C: 02787880
	s_mov_b32 vcc_lo, s0                                       // 000000195970: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 000000195974: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000019597C: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 000000195984: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 000000195988: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 00000019598C: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 000000195994: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 00000019599C: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001959A8: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001959AC: BF870214
	v_add_f32_e32 v80, v80, v82                                // 0000001959B0: 06A0A550
	.long 0x7e0039b6                                           // 0000001959B4: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001959B8: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 0000001959BC: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001959C0: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001959C8: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001959D4: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001959D8: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001959DC: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001959E4: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001959F0: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001959F4: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001959FC: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 000000195A08: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 000000195A0C: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 000000195A10: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 000000195A14: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 000000195A1C: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195A24: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 000000195A28: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 000000195A30: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 000000195A38: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 000000195A40: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195A48: BF870113
	v_rcp_f32_e32 v57, v71                                     // 000000195A4C: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 000000195A50: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195A54: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 000000195A58: 067C973E
	.long 0xd41e0001                                           // 000000195A5C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 000000195A60: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 000000195A68: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000195A70: BF870313
	v_exp_f32_e32 v62, v62                                     // 000000195A74: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 000000195A78: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195A80: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 000000195A84: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 000000195A88: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 000000195A8C: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 000000195A90: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000195A98: BF8701B5
	.long 0xd71c003e                                           // 000000195A9C: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000195AA0: 0202993E
	v_exp_f32_e32 v76, v80                                     // 000000195AA4: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 000000195AA8: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 000000195AB0: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195AB4: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 000000195AB8: D501003E 00067C80
	.long 0xd41b0001                                           // 000000195AC0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 000000195AC4: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 000000195ACC: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000195AD4: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 000000195AD8: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 000000195AE4: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 000000195AE8: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195AEC: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 000000195AF0: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 000000195AF4: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000195AFC: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 000000195B00: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 000000195B08: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 000000195B10: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 000000195B18: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 000000195B1C: BEEA0000
	.long 0x7f763980                                           // 000000195B20: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 000000195B24: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 000000195B2C: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 000000195B34: 067A7AF2
	.long 0x7e7639a9                                           // 000000195B38: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000195B3C: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 000000195B40: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 000000195B48: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 000000195B50: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195B58: BF870113
	.long 0x7e0039aa                                           // 000000195B5C: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 000000195B60: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 000000195B64: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 000000195B68: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195B6C: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 000000195B70: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 000000195B78: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195B84: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 000000195B88: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 000000195B90: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 000000195B94: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 000000195B9C: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 000000195BA4: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 000000195BAC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 000000195BB0: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195BB8: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 000000195BBC: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 000000195BC8: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 000000195BCC: 7E944739
	s_waitcnt vmcnt(11)                                        // 000000195BD0: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195BD4: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 000000195BD8: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 000000195BE4: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195BEC: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 000000195BF0: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 000000195BF8: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 000000195BFC: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 000000195C08: 36767681
	v_rndne_f32_e32 v81, v77                                   // 000000195C0C: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 000000195C10: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 000000195C14: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 000000195C1C: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000195C28: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 000000195C2C: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 000000195C30: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 000000195C3C: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000195C40: BF870004
	v_exp_f32_e32 v57, v57                                     // 000000195C44: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 000000195C48: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 000000195C4C: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 000000195C50: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 000000195C58: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 000000195C60: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 000000195C64: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 000000195C6C: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 000000195C70: D613004B 24FA9347
	.long 0xd71c0039                                           // 000000195C78: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 000000195C7C: 02029539
	v_exp_f32_e32 v74, v77                                     // 000000195C80: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 000000195C84: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 000000195C88: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 000000195C90: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 000000195C94: D5010039 00067280
	.long 0xd41b0001                                           // 000000195C9C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 000000195CA0: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000195CA8: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 000000195CAC: D613003E 24FA9347
	.long 0xd71c003b                                           // 000000195CB4: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 000000195CB8: 0202774A
	s_waitcnt vmcnt(5)                                         // 000000195CBC: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 000000195CC0: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 000000195CC4: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 000000195CD0: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 000000195CD8: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000195CE0: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 000000195CE4: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 000000195CEC: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 000000195CF4: 02767680
	s_mov_b32 vcc_lo, s0                                       // 000000195CF8: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000195CFC: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 000000195D00: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 000000195D0C: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 000000195D14: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 000000195D1C: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000195D24: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 000000195D28: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 000000195D30: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 000000195D38: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 000000195D3C: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 000000195D40: 7E9C474B
	.long 0x7e0039a9                                           // 000000195D44: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 000000195D48: 066C76F2
	.long 0x7e7639ab                                           // 000000195D4C: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 000000195D50: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 000000195D58: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 000000195D5C: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 000000195D60: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 000000195D68: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 000000195D6C: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 000000195D74: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 000000195D80: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 000000195D84: 36767681
	v_rcp_f32_e32 v62, v42                                     // 000000195D88: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 000000195D8C: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 000000195D90: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 000000195D98: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 000000195D9C: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 000000195DA0: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 000000195DAC: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000195DB0: BF870294
	v_add_f32_e32 v53, v53, v71                                // 000000195DB4: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 000000195DB8: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 000000195DC0: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195DC4: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 000000195DC8: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 000000195DD4: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 000000195DD8: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 000000195DE0: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 000000195DE4: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 000000195DEC: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 000000195DF4: 109E7D4C
	.long 0xd71c0035                                           // 000000195DF8: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 000000195DFC: 02029135
	v_exp_f32_e32 v72, v75                                     // 000000195E00: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195E04: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 000000195E08: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 000000195E10: D5010035 00066A80
	.long 0xd41b0001                                           // 000000195E18: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 000000195E1C: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195E24: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 000000195E28: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 000000195E2C: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 000000195E30: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000195E3C: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 000000195E40: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 000000195E48: BF870185
	.long 0xd71c003a                                           // 000000195E4C: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 000000195E50: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 000000195E54: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195E5C: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 000000195E60: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 000000195E68: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195E6C: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 000000195E70: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 000000195E78: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 000000195E7C: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195E84: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 000000195E88: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 000000195E8C: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000195E94: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 000000195E98: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 000000195E9C: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 000000195EA4: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195EAC: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 000000195EB0: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 000000195EBC: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 000000195EC0: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 000000195EC8: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195ED0: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 000000195ED4: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 000000195EDC: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 000000195EE4: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 000000195EE8: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 000000195EF0: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 000000195EF8: 7C3694FF C2B17218
	.long 0x7f723980                                           // 000000195F00: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 000000195F04: 06929749
	.long 0x7e7239ad                                           // 000000195F08: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 000000195F0C: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 000000195F14: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 000000195F1C: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195F20: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 000000195F24: 36727281
	.long 0x7e0039aa                                           // 000000195F28: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000195F2C: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 000000195F30: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 000000195F34: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 000000195F3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 000000195F40: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 000000195F48: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 000000195F54: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 000000195F58: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 000000195F60: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 000000195F6C: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 000000195F70: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 000000195F78: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 000000195F84: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 000000195F88: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 000000195F90: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 000000195F94: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 000000195F98: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 000000195F9C: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 000000195FA4: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 000000195FA8: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000195FB0: BF870092
	v_exp_f32_e32 v46, v46                                     // 000000195FB4: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 000000195FB8: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 000000195FBC: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000195FC4: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 000000195FC8: 109A794A
	.long 0xd71c002e                                           // 000000195FCC: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 000000195FD0: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 000000195FD4: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000195FD8: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 000000195FDC: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 000000195FE4: D501002E 00065C80
	.long 0xd41b0001                                           // 000000195FEC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 000000195FF0: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000195FF8: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 000000195FFC: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 000000196000: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 000000196004: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 000000196010: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 000000196014: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019601C: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 000000196020: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000196028: BF870205
	.long 0xd71c0036                                           // 00000019602C: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 000000196030: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000196034: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 000000196038: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 000000196040: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 000000196044: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019604C: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 000000196050: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 000000196058: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019605C: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 000000196060: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 000000196068: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 00000019606C: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000196074: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 000000196078: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 00000019607C: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000196084: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 000000196088: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 00000019608C: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 000000196094: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019609C: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001960A0: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001960AC: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001960B0: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001960B8: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001960C0: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001960C4: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001960CC: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001960D0: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001960D4: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001960D8: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001960E0: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001960E8: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001960F0: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001960F8: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001960FC: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 000000196100: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 000000196108: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 000000196110: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 000000196114: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 000000196120: 7E78472B
	.long 0x7e0039a2                                           // 000000196124: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 000000196128: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196130: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 000000196134: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 00000019613C: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196140: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 000000196144: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 000000196148: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000196150: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 000000196154: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 00000019615C: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 000000196160: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 000000196164: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 000000196170: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 000000196174: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 000000196178: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 000000196180: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 000000196184: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 000000196188: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000196194: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 000000196198: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 00000019619C: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001961A4: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 0000001961AC: D613003D 24DA7739
	.long 0xd71c002b                                           // 0000001961B4: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001961B8: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001961BC: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001961C0: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001961C4: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001961CC: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001961D0: D501002B 00065680
	.long 0xd41b0001                                           // 0000001961D8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001961DC: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001961E4: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 0000001961EC: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 0000001961F0: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001961F8: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196204: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 000000196208: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 000000196210: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 000000196218: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196220: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 000000196224: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 000000196228: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 00000019622C: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 000000196230: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196238: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 00000019623C: D613002A 2522972A
	.long 0xd71c002d                                           // 000000196244: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 000000196248: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 00000019624C: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 000000196254: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000196258: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 00000019625C: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 000000196264: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 000000196268: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 000000196270: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 000000196278: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196280: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 000000196284: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 000000196290: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 000000196298: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001962A4: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001962A8: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001962AC: BF870193
	.long 0x7e0039a1                                           // 0000001962B0: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001962B4: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001962B8: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001962BC: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001962C4: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001962C8: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001962CC: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001962D4: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001962D8: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001962E4: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001962E8: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001962F0: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001962F4: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001962FC: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 000000196304: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 000000196308: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 00000019630C: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 000000196314: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 000000196318: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 00000019631C: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 000000196320: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 00000019632C: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 000000196334: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 000000196338: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 00000019633C: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000196340: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 000000196344: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 00000019634C: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 000000196354: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 00000019635C: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 000000196368: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 00000019636C: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 000000196374: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000196378: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 00000019637C: 56724D3B
	.long 0xd71c0029                                           // 000000196380: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 000000196384: 02027529
	v_exp_f32_e32 v58, v61                                     // 000000196388: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 00000019638C: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 000000196394: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 00000019639C: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001963A4: D5010029 00065280
	.long 0xd41b0001                                           // 0000001963AC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001963B0: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001963B8: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001963C0: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001963C4: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001963C8: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001963D0: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001963D8: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001963E4: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001963EC: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001963F0: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001963F4: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001963FC: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 000000196400: C92252F2 293AFE90
	.long 0x7f563980                                           // 000000196408: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 00000019640C: 02585880
	s_mov_b32 vcc_lo, s0                                       // 000000196410: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000196414: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 000000196418: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 000000196420: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 000000196428: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 000000196430: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 000000196438: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 00000019643C: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 000000196448: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 000000196450: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 000000196458: 30550090
	v_rcp_f32_e32 v35, v45                                     // 00000019645C: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 000000196460: 7E7C473B
	.long 0x7e0039a2                                           // 000000196464: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 000000196468: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 00000019646C: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 000000196474: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 00000019647C: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 000000196480: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 000000196484: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 00000019648C: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 000000196498: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 00000019649C: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001964A4: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001964A8: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001964AC: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001964B4: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001964B8: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001964C0: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001964C8: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001964D4: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001964D8: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001964DC: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001964E0: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001964E4: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001964E8: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001964F0: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001964FC: 7E4C4B26
	.long 0xd41e0001                                           // 000000196500: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 000000196504: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 00000019650C: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 000000196514: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 000000196518: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 000000196520: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 000000196528: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 00000019652C: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 000000196530: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 000000196538: 108E5D3C
	.long 0xd71c0026                                           // 00000019653C: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000196540: 02026D26
	v_exp_f32_e32 v54, v59                                     // 000000196544: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 000000196548: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196550: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 000000196554: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 00000019655C: D5010026 00064C80
	.long 0xd41b0001                                           // 000000196564: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 000000196568: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000196570: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 000000196574: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 00000019657C: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 000000196584: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 000000196588: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 00000019658C: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 000000196598: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001965A0: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001965A8: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001965B0: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001965B4: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001965B8: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001965BC: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001965C0: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001965CC: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001965D0: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001965D4: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001965D8: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001965E0: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001965E8: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001965F0: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001965F4: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001965FC: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 000000196604: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 00000019660C: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 000000196614: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 000000196618: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 00000019661C: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 000000196628: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 00000019662C: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 000000196630: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 000000196634: 06465B23
	.long 0x7f523980                                           // 000000196638: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 00000019663C: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 000000196640: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 000000196648: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 000000196650: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 000000196654: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 00000019665C: 08727939
	v_rcp_f32_e32 v44, v34                                     // 000000196660: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 000000196664: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 000000196668: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 000000196670: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 000000196674: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 000000196680: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 000000196684: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 000000196688: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 00000019668C: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 000000196698: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 00000019669C: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001966A4: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001966AC: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001966B0: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001966B4: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001966BC: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001966C0: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001966C8: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001966CC: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001966D4: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001966D8: D5010023 00064680
	.long 0xd41b0001                                           // 0000001966E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001966E4: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001966EC: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001966F4: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001966F8: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 000000196700: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019670C: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 000000196710: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 000000196718: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 000000196720: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196728: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 00000019672C: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 000000196730: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 000000196734: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 000000196738: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196740: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 000000196744: D6130022 24EA7B22
	.long 0xd71c0025                                           // 00000019674C: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 000000196750: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 000000196754: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 00000019675C: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000196760: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 000000196764: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 00000019676C: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 000000196770: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 000000196778: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 000000196780: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196788: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 00000019678C: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 000000196798: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001967A0: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001967AC: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001967B0: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001967B4: BF870193
	.long 0x7e003999                                           // 0000001967B8: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001967BC: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001967C0: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001967C4: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001967CC: 7E4A399B
	.long 0x7f4a3980                                           // 0000001967D0: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001967D4: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001967DC: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001967E0: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001967EC: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001967F0: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001967F8: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001967FC: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 000000196804: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019680C: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 000000196810: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 000000196818: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 000000196820: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 000000196824: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 000000196828: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 00000019682C: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000196838: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 00000019683C: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 000000196844: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 000000196848: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 00000019684C: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 000000196850: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 000000196858: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 000000196860: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 000000196868: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 000000196874: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 000000196878: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196880: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 000000196884: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 000000196888: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019688C: BF870005
	.long 0xd71c0021                                           // 000000196890: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 000000196894: 02025921
	v_exp_f32_e32 v44, v53                                     // 000000196898: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 00000019689C: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001968A4: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001968AC: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001968B4: D5010021 00064280
	.long 0xd41b0001                                           // 0000001968BC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001968C0: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001968C8: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001968D0: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001968D4: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001968D8: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001968E0: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001968E8: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001968F4: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001968FC: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 000000196900: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 000000196904: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019690C: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 000000196910: C92242F2 212CF690
	.long 0x7f463980                                           // 000000196918: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 00000019691C: 02484880
	s_mov_b32 vcc_lo, s0                                       // 000000196920: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000196924: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 000000196928: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 000000196930: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 000000196938: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 000000196940: D6FC7C25 04464321
	.long 0x7e46399d                                           // 000000196948: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 00000019694C: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 000000196958: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 000000196960: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 000000196968: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 00000019696C: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 000000196970: 7E6C472D
	.long 0x7e00399a                                           // 000000196974: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 000000196978: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 00000019697C: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 000000196984: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 00000019698C: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 000000196990: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 000000196994: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 00000019699C: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001969A8: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001969AC: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001969B4: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001969B8: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001969BC: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001969C4: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001969C8: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001969D0: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001969D8: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001969E4: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001969E8: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001969EC: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001969F0: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001969F4: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001969F8: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 000000196A00: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 000000196A0C: 7E3C4B1E
	.long 0xd41e0001                                           // 000000196A10: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 000000196A14: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 000000196A1C: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 000000196A24: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 000000196A28: D6FC002E 044A3912
	s_clause 0x1                                               // 000000196A30: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 000000196A34: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 000000196A3C: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 000000196A44: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 000000196A4C: 10724D2E
	.long 0xd71c001e                                           // 000000196A50: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 000000196A54: 0202551E
	v_exp_f32_e32 v42, v45                                     // 000000196A58: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000196A5C: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 000000196A60: D6130024 24925325
	.long 0x7f3a3980                                           // 000000196A68: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 000000196A6C: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 000000196A74: D501001E 00063C80
	.long 0xd41b0001                                           // 000000196A7C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 000000196A80: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 000000196A88: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 000000196A90: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 000000196A98: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 000000196A9C: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000196AA0: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 000000196AAC: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 000000196AB4: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 000000196ABC: D6130019 24BA7319
	.long 0xd71c0022                                           // 000000196AC4: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 000000196AC8: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 000000196ACC: 063C3CF2
	.long 0xd41e0001                                           // 000000196AD0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 000000196AD4: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 000000196ADC: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 000000196AE8: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000196AEC: 02444480
	s_mov_b32 vcc_lo, s0                                       // 000000196AF0: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 000000196AF4: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 000000196AFC: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 000000196B04: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 000000196B0C: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 000000196B18: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 000000196B1C: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 000000196B20: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 000000196B28: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 000000196B30: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 000000196B34: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 000000196B3C: 06425321
	.long 0x7e003992                                           // 000000196B40: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 000000196B44: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 000000196B48: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 000000196B4C: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 000000196B58: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 000000196B5C: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 000000196B60: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 000000196B68: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000196B70: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 000000196B74: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 000000196B80: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 000000196B88: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000196B8C: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 000000196B90: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 000000196B94: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 000000196B9C: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 000000196BA0: 06565D2B
	.long 0xd71c0021                                           // 000000196BA4: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 000000196BA8: 02025521
	.long 0x7e3a3991                                           // 000000196BAC: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 000000196BB0: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 000000196BB4: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 000000196BC0: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 000000196BC4: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 000000196BCC: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000196BD4: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 000000196BD8: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 000000196BE0: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 000000196BE8: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 000000196BF4: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 000000196BF8: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 000000196BFC: C8C04929 362C332C
	s_clause 0x1                                               // 000000196C04: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 000000196C08: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 000000196C10: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 000000196C18: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 000000196C20: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 000000196C28: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196C2C: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 000000196C30: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 000000196C34: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 000000196C3C: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000196C44: BF870004
	.long 0xd71c0022                                           // 000000196C48: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 000000196C4C: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 000000196C50: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 000000196C58: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 000000196C60: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 000000196C68: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 000000196C70: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 000000196C78: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196C7C: BF870214
	.long 0x7e3c3991                                           // 000000196C80: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 000000196C84: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 000000196C88: 02424480
	s_mov_b32 vcc_lo, s0                                       // 000000196C8C: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 000000196C90: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 000000196C98: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 000000196CA0: 7E484723
	s_waitcnt vmcnt(2)                                         // 000000196CA4: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 000000196CA8: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 000000196CAC: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 000000196CB0: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 000000196CB8: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 000000196CC0: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196CC8: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 000000196CCC: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 000000196CD8: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196CDC: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 000000196CE0: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 000000196CE4: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 000000196CE8: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 000000196CF0: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 000000196CF4: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000196CFC: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 000000196D00: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 000000196D0C: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 000000196D10: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 000000196D18: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 000000196D24: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 000000196D28: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 000000196D2C: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 000000196D34: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 000000196D38: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 000000196D40: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 000000196D48: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196D50: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 000000196D54: 10522712
	v_add_f32_e32 v33, v35, v33                                // 000000196D58: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 000000196D5C: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000196D64: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 000000196D68: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 000000196D6C: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 000000196D74: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 000000196D7C: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 000000196D80: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 000000196D8C: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196D90: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 000000196D94: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 000000196D9C: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196DA4: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 000000196DA8: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 000000196DAC: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000196DB4: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 000000196DB8: D6130011 244A531B
	.long 0xd71c0012                                           // 000000196DC0: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 000000196DC4: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 000000196DC8: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196DCC: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 000000196DD0: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 000000196DD8: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 000000196DE0: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196DE8: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 000000196DEC: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 000000196DF4: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000196DF8: 02242480
	s_mov_b32 vcc_lo, s0                                       // 000000196DFC: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 000000196E00: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 000000196E08: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 000000196E10: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 000000196E18: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 000000196E1C: 30448C90
	.long 0x7e2a3991                                           // 000000196E20: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 000000196E24: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 000000196E2C: 022424FF 7F800000
	.long 0xd71c0014                                           // 000000196E34: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 000000196E38: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 000000196E3C: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 000000196E44: 3032D090
	.long 0x7e003993                                           // 000000196E48: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 000000196E4C: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 000000196E54: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 000000196E58: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 000000196E60: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000196E68: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 000000196E6C: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 000000196E74: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 000000196E80: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 000000196E88: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000196E94: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 000000196E98: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 000000196E9C: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000196EA0: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 000000196EAC: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 000000196EB8: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000196EC4: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 000000196EC8: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 000000196ECC: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 000000196ED0: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 000000196ED8: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000196EDC: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 000000196EE0: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 000000196EE8: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 000000196EEC: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 000000196EF8: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 000000196EFC: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 000000196F04: 56343523
	v_exp_f32_e32 v21, v21                                     // 000000196F08: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 000000196F0C: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 000000196F14: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 000000196F18: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 000000196F20: 104C351D
	.long 0xd41e0001                                           // 000000196F24: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 000000196F28: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 000000196F30: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 000000196F34: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 000000196F3C: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 000000196F40: DC9600A0 007C1327
	.long 0xd71c0011                                           // 000000196F48: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 000000196F4C: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 000000196F50: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 000000196F58: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 000000196F5C: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 000000196F64: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 000000196F68: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 000000196F70: 564C3515
	.long 0xd41b0001                                           // 000000196F74: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 000000196F78: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 000000196F80: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000196F88: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 000000196F8C: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 000000196F94: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196FA0: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 000000196FA4: D6130015 248E3D21
	.long 0xd41e0001                                           // 000000196FAC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 000000196FB0: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000196FB8: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 000000196FBC: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000196FC4: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 000000196FCC: 563C4915
	.long 0xd71c0015                                           // 000000196FD0: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 000000196FD4: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 000000196FD8: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 000000196FDC: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000196FE4: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 000000196FE8: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 000000196FF0: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 000000196FF4: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 000000196FF8: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000197000: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 000000197004: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019700C: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 000000197014: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 000000197018: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019701C: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 000000197020: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 000000197028: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 000000197030: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 000000197038: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 000000197040: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 000000197048: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 00000019704C: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 000000197050: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019705C: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 000000197060: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 000000197068: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 00000019706C: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000197070: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 000000197078: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 000000197080: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 000000197084: 08323D19
	.long 0x7e283989                                           // 000000197088: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 00000019708C: 7E2A5516
	.long 0x7f283980                                           // 000000197090: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 000000197094: 10463721
	v_add_f32_e32 v25, v25, v29                                // 000000197098: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 00000019709C: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001970A8: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001970AC: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001970B8: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001970BC: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001970C4: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001970C8: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001970D0: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001970D8: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001970DC: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001970E8: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001970EC: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001970F0: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001970F8: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 000000197100: DC9600C0 007C0907
	.long 0xd71c0009                                           // 000000197108: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019710C: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 000000197110: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 000000197114: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 00000019711C: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 000000197120: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 000000197128: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 000000197130: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 000000197138: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 000000197140: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 000000197144: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019714C: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 000000197150: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 000000197154: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019715C: BF870004
	.long 0xd71c0011                                           // 000000197160: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000197164: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 000000197168: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000197170: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 000000197178: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 000000197180: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 000000197184: 30328690
	.long 0x7e2c398b                                           // 000000197188: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 00000019718C: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000197190: 02222280
	s_mov_b32 vcc_lo, s0                                       // 000000197194: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 000000197198: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001971A0: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001971A8: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001971B0: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001971B4: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001971BC: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001971C8: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001971D0: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001971D8: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001971E0: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001971E4: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001971E8: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001971F0: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001971F4: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 000000197200: 7E384713
	.long 0xd41e0001                                           // 000000197204: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 000000197208: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 000000197210: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 000000197214: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 00000019721C: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 000000197224: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 000000197228: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 000000197230: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 000000197234: 7E42551A
	.long 0x7f2c3980                                           // 000000197238: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019723C: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 000000197240: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 000000197248: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 000000197250: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 000000197258: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 00000019725C: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000197260: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 000000197264: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 000000197268: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 000000197270: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000197274: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 000000197278: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 000000197284: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019728C: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 000000197290: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 000000197294: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 00000019729C: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001972A0: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001972A4: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001972A8: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001972AC: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001972B0: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001972B4: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001972C0: D5010013 00062680
	.long 0xd41b0001                                           // 0000001972C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001972CC: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001972D4: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001972DC: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001972E4: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001972E8: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001972EC: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001972F4: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 000000197300: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 000000197304: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 00000019730C: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 000000197310: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000197318: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 000000197320: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 000000197324: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 00000019732C: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 000000197334: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 00000019733C: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 000000197344: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000019734C: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 000000197354: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 000000197358: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 00000019735C: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 000000197364: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 000000197368: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 00000019736C: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000197370: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 000000197374: D627000C 043A2314
	.long 0x7e223989                                           // 00000019737C: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 000000197380: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 000000197388: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 00000019738C: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 000000197394: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000197398: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 00000019739C: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001973A4: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001973A8: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001973AC: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001973B0: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001973B4: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001973B8: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001973C0: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001973CC: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001973D0: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001973DC: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001973E4: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001973E8: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001973EC: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001973F4: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001973F8: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 000000197400: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 000000197408: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 000000197414: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 00000019741C: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 000000197420: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 000000197428: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019742C: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 000000197430: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 00000019743C: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000197444: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 000000197448: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 000000197450: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 00000019745C: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000197464: BF870004
	v_add_f32_e32 v12, v12, v27                                // 000000197468: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 00000019746C: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 000000197470: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 000000197478: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 000000197480: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 000000197484: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 000000197488: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 00000019748C: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 000000197490: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 000000197494: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 00000019749C: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001974A0: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001974A4: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001974A8: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001974B0: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001974B8: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001974BC: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001974C4: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001974C8: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001974CC: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001974D8: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001974DC: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001974E0: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001974EC: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001974F0: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001974F4: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000197500: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 000000197504: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000019750C: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 000000197510: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 000000197514: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 00000019751C: 0632331A
	.long 0xd71c000c                                           // 000000197520: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 000000197524: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 000000197528: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 00000019752C: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 000000197530: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 000000197538: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000019753C: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 000000197544: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 00000019754C: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 000000197550: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 000000197554: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000197558: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000019755C: 7C363AFF C2B17218
	.long 0x7e443981                                           // 000000197564: 7E443981
	.long 0x7f443980                                           // 000000197568: 7F443980
	.long 0xd71c0012                                           // 00000019756C: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 000000197570: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 000000197574: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000019757C: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 000000197584: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 00000019758C: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000197590: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000197594: BF870194
	v_rcp_f32_e32 v27, v26                                     // 000000197598: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 00000019759C: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001975A0: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001975A4: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001975AC: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001975B0: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001975B8: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001975C0: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001975C8: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001975D0: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001975D4: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001975D8: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001975DC: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001975E4: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001975EC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001975F0: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001975F4: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001975FC: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 000000197600: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 000000197608: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 00000019760C: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 000000197614: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 000000197618: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 000000197620: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 000000197628: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 000000197630: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 000000197634: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 00000019763C: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 000000197640: 5638391E
	.long 0x7e003982                                           // 000000197644: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 000000197648: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 000000197650: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000197658: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 00000019765C: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 000000197660: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000197668: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 00000019766C: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 000000197674: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 00000019767C: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000197684: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 000000197688: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 000000197690: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 000000197694: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 00000019769C: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001976A0: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001976A4: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001976AC: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001976B0: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001976B4: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001976BC: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001976C4: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001976CC: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001976D0: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001976D8: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001976DC: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001976E4: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001976E8: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001976EC: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001976F4: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001976FC: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 000000197700: D6270004 04121909
	.long 0x7f183980                                           // 000000197708: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 00000019770C: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 000000197718: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 000000197720: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 000000197728: BEEA0002
	.long 0x7e003984                                           // 00000019772C: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 000000197730: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 00000019773C: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 000000197744: D6270005 0416250A
	.long 0x7e143983                                           // 00000019774C: 7E143983
	.long 0x7f143980                                           // 000000197750: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 000000197754: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 00000019775C: D6270006 041A2D09
	.long 0x7e183985                                           // 000000197764: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 000000197768: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 00000019776C: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000197770: BF870214
	.long 0x7e003986                                           // 000000197774: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 000000197778: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019777C: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 000000197780: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 00000019778C: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 000000197798: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019779C: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001977A0: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001977AC: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001977B8: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001977BC: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001977C4: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001977CC: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001977D4: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001977DC: DC9600E0 007C0027
	s_nop 0                                                    // 0000001977E4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001977E8: BFB60003
	s_endpgm                                                   // 0000001977EC: BFB00000
		...

