00000000000ea200 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000EA200: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000EA204: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000EA20C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000EA214: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000EA218: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000EA21C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000EA220: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EA228: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000EA22C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000EA230: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000EA234: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000EA23C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000EA240: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000EA244: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000EA248: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA24C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000EA250: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000EA254: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000EA258: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000EA25C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000EA264: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000EA26C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000EA270: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000EA274: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000EA278: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000EA27C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000EA280: 821E191E
	.long 0xd7001f02                                           // 0000000EA284: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000EA288: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000EA28C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000EA294: BE9E0080
	s_nop 0                                                    // 0000000EA298: BF800000
	s_nop 0                                                    // 0000000EA29C: BF800000
	s_nop 0                                                    // 0000000EA2A0: BF800000
	s_nop 0                                                    // 0000000EA2A4: BF800000
	s_nop 0                                                    // 0000000EA2A8: BF800000
	s_nop 0                                                    // 0000000EA2AC: BF800000
	s_nop 0                                                    // 0000000EA2B0: BF800000
	s_nop 0                                                    // 0000000EA2B4: BF800000
	s_nop 0                                                    // 0000000EA2B8: BF800000
	s_nop 0                                                    // 0000000EA2BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000EA2C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000EA2C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA2CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000EA2D0: 300C1089
	.long 0xd7006a06                                           // 0000000EA2D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000EA2D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA2DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000EA2E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000EA2E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000EA2F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000EA2F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000EA2FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000EA308: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000EA30C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000EA310: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000EA318: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000EA31C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000EA320: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000EA324: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000EA32C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000EA334: 32040084
	s_mov_b32 s0, 0                                            // 0000000EA338: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000EA33C: BF89FC07
	s_barrier                                                  // 0000000EA340: BFBD0000
	buffer_gl0_inv                                             // 0000000EA344: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000EA34C: BF02801E
	s_cbranch_scc1 12                                          // 0000000EA350: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000EA354: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000EA35C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EA364: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000EA368: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000EA370: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000EA374: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000EA378: 916A007E
	s_cbranch_vccz 2                                           // 0000000EA37C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2201                                              // 0000000EA380: BFA00899 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e8>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000EA384: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000EA388: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000EA38C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000EA394: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000EA398: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000EA39C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000EA3A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000EA3A4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000EA3AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000EA3B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000EA3B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000EA3B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000EA3BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000EA3C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000EA3C4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000EA3C8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000EA3D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000EA3D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000EA3DC: B00A0204
	.long 0xd7000b2a                                           // 0000000EA3E0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000EA3E4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000EA3E8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000EA3EC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000EA3F4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000EA400: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000EA404: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000EA410: 38164C0A
	.long 0xd7000a05                                           // 0000000EA414: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000EA418: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EA41C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000EA420: D5207C06 00290001
	.long 0xd7000107                                           // 0000000EA428: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000EA42C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EA430: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000EA434: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000EA43C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000EA440: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000EA444: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000EA44C: 84848E02
	.long 0xd700010b                                           // 0000000EA450: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000EA454: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000EA458: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000EA45C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000EA464: 8205050F
	.long 0xd700010d                                           // 0000000EA468: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000EA46C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EA470: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000EA474: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000EA47C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000EA480: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000EA488: D5207C10 00061880
	.long 0xd7000111                                           // 0000000EA490: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000EA494: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EA49C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000EA4A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000EA4A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000EA4AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000EA4B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000EA4BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000EA4C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EA4C8: BF8700D1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000EA4CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000EA4D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000EA4D8: 020216FF 000F0000
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000EA4E0: 385A02FF 00002200
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000EA4E8: D5207C18 00061880
	.long 0xd7000119                                           // 0000000EA4F0: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000EA4F4: 020216FF 00120000
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000EA4FC: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000EA504: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000EA508: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000EA510: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000EA518: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000EA51C: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000EA524: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000EA528: 4A0846FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000EA530: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v45                           // 0000000EA538: 4A5C5AFF 00000400
	v_add_nc_u32_e32 v47, 0x600, v45                           // 0000000EA540: 4A5E5AFF 00000600
	v_add_nc_u32_e32 v48, 0x800, v45                           // 0000000EA548: 4A605AFF 00000800
	s_mov_b32 s5, 0                                            // 0000000EA550: BE850080
	s_mov_b32 s6, 0x45800000                                   // 0000000EA554: BE8600FF 45800000
	s_mov_b32 s7, 0x39800000                                   // 0000000EA55C: BE8700FF 39800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000EA564: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000EA568: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000EA570: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000EA574: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000EA578: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA57C: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000EA580: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000EA584: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000EA588: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000EA58C: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000EA590: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000EA598: BE84206A
	s_cbranch_execz 77                                         // 0000000EA59C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v29, s11, v0                                  // 0000000EA5A0: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA5A4: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000EA5A8: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000EA5B0: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA5B4: BF870091
	.long 0xd73c001d                                           // 0000000EA5B8: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000EA5BC: 02023A82
	.long 0xd700011d                                           // 0000000EA5C0: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000EA5C4: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000EA5C8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000EA5CC: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000EA5D4: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EA5DC: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000EA5E0: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000EA5E4: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000EA5F0: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v29, -v32                       // 0000000EA5F4: D6130031 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v50, v32                                   // 0000000EA600: 7E644720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000EA604: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000EA610: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA614: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v50// 0000000EA618: C80A3AFF 31206520 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000EA624: 083E451F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EA628: BF870122
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_add_f32 v32, v32, v49// 0000000EA62C: C8083CFF 21206320 32A5705F
	.long 0xd41b0001                                           // 0000000EA638: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000EA63C: 02023CFF C2CE8ED0
	v_add_f32_e32 v31, v31, v33                                // 0000000EA644: 063E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000EA648: 7E421122
	v_cvt_i32_f32_e32 v34, v50                                 // 0000000EA64C: 7E441132
	v_exp_f32_e32 v32, v32                                     // 0000000EA650: 7E404B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000EA654: BF870313
	v_exp_f32_e32 v31, v31                                     // 0000000EA658: 7E3E4B1F
	.long 0xd71c0020                                           // 0000000EA65C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000EA660: 02024520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA664: BF870095
	.long 0xd71c001f                                           // 0000000EA668: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000EA66C: 0202431F
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000EA670: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000EA678: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000EA67C: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EA684: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000EA688: D5010020 00064080
	.long 0xd41e0001                                           // 0000000EA690: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000EA694: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000EA69C: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000EA6A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000EA6AC: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA6B4: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000EA6B8: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000EA6C4: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000EA6CC: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EA6D4: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000EA6D8: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000EA6E0: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EA6E4: BF89FC07
	s_barrier                                                  // 0000000EA6E8: BFBD0000
	buffer_gl0_inv                                             // 0000000EA6EC: E0AC0000 00000000
	s_branch 15                                                // 0000000EA6F4: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EA6F8: 8C7E047E
	.long 0xd700011d                                           // 0000000EA6FC: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000EA700: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA708: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EA70C: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000EA714: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000EA718: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000EA71C: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000EA720: BF89FC07
	s_barrier                                                  // 0000000EA724: BFBD0000
	buffer_gl0_inv                                             // 0000000EA728: E0AC0000 00000000
	s_cbranch_scc1 185                                         // 0000000EA730: BFA200B9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000EA734: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000EA73C: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000EA744: BE8D0080
	s_nop 0                                                    // 0000000EA748: BF800000
	s_nop 0                                                    // 0000000EA74C: BF800000
	s_nop 0                                                    // 0000000EA750: BF800000
	s_nop 0                                                    // 0000000EA754: BF800000
	s_nop 0                                                    // 0000000EA758: BF800000
	s_nop 0                                                    // 0000000EA75C: BF800000
	s_nop 0                                                    // 0000000EA760: BF800000
	s_nop 0                                                    // 0000000EA764: BF800000
	s_nop 0                                                    // 0000000EA768: BF800000
	s_nop 0                                                    // 0000000EA76C: BF800000
	s_nop 0                                                    // 0000000EA770: BF800000
	s_nop 0                                                    // 0000000EA774: BF800000
	s_nop 0                                                    // 0000000EA778: BF800000
	s_nop 0                                                    // 0000000EA77C: BF800000
	global_load_b32 v49, v[31:32], off                         // 0000000EA780: DC520000 317C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000EA788: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000EA790: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000EA794: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EA79C: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000EA7A0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000EA7A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000EA7AC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000EA7B4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000EA7B8: BF8903F7
	ds_store_b32 v33, v49 offset:13056                         // 0000000EA7BC: D8343300 00003121
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000EA7C4: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000EA7CC: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000EA7D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000EA7D4: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EA7D8: BF89FC07
	s_barrier                                                  // 0000000EA7DC: BFBD0000
	buffer_gl0_inv                                             // 0000000EA7E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000EA7E8: BE842000
	s_cbranch_execz 65474                                      // 0000000EA7EC: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_or3_b32 v31, s12, s11, v2                                // 0000000EA7F0: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA7F8: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000EA7FC: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000EA804: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000EA808: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA80C: BF870091
	.long 0xd700011f                                           // 0000000EA810: D700011F
	v_cndmask_b32_e32 v1, v42, v31, vcc_lo                     // 0000000EA814: 02023F2A
	v_add_co_ci_u32_e64 v32, null, v43, v32, s1                // 0000000EA818: D5207C20 0006412B
	s_mov_b32 s1, 0                                            // 0000000EA820: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000EA824: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000EA82C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000EA838: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000EA83C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000EA840: D8DC1100 21000020
	ds_load_2addr_b32 v[49:50], v32 offset0:34 offset1:51      // 0000000EA848: D8DC3322 31000020
	ds_load_2addr_b32 v[51:52], v32 offset0:68 offset1:85      // 0000000EA850: D8DC5544 33000020
	ds_load_2addr_b32 v[53:54], v32 offset0:102 offset1:119    // 0000000EA858: D8DC7766 35000020
	v_lshl_add_u32 v32, s1, 2, v44                             // 0000000EA860: D6460020 04B10401
	s_mov_b32 s1, s13                                          // 0000000EA868: BE81000D
	ds_load_2addr_b32 v[55:56], v32 offset1:1                  // 0000000EA86C: D8DC0100 37000020
	ds_load_2addr_b32 v[57:58], v32 offset0:2 offset1:3        // 0000000EA874: D8DC0302 39000020
	ds_load_2addr_b32 v[59:60], v32 offset0:4 offset1:5        // 0000000EA87C: D8DC0504 3B000020
	ds_load_2addr_b32 v[61:62], v32 offset0:6 offset1:7        // 0000000EA884: D8DC0706 3D000020
	s_waitcnt lgkmcnt(7)                                       // 0000000EA88C: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000EA890: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EA898: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000EA8A0: BF89FC67
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EA8A4: CC210031 02000D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EA8AC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA8B0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA8B8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000EA8C0: BF870003
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA8C4: CC200031 8A000F31
	s_waitcnt lgkmcnt(3)                                       // 0000000EA8CC: BF89FC37
	v_fma_mixlo_f16 v33, v55, s6, 0                            // 0000000EA8D0: CC210021 02000D37
	v_fma_mixlo_f16 v55, v56, s6, 0                            // 0000000EA8D8: CC210037 02000D38
	s_waitcnt lgkmcnt(2)                                       // 0000000EA8E0: BF89FC27
	v_fma_mixlo_f16 v56, v57, s6, 0                            // 0000000EA8E4: CC210038 02000D39
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EA8EC: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA8F0: CC200021 8A000F21
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA8F8: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000EA900: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000EA904: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000EA908: D613001F 247E4121
	v_fma_mixlo_f16 v32, v50, s6, 0                            // 0000000EA910: CC210020 02000D32
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000EA918: CC210021 02000D3A
	v_fma_mix_f32 v50, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA920: CC200032 8A000F38
	v_fma_f32 v31, -v55, v34, v31                              // 0000000EA928: D613001F 247E4537
	v_fma_mixlo_f16 v34, v51, s6, 0                            // 0000000EA930: CC210022 02000D33
	s_waitcnt lgkmcnt(1)                                       // 0000000EA938: BF89FC17
	v_fma_mixlo_f16 v51, v59, s6, 0                            // 0000000EA93C: CC210033 02000D3B
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA944: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA94C: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000EA954: D613001F 247E6332
	v_fma_mixlo_f16 v49, v52, s6, 0                            // 0000000EA95C: CC210031 02000D34
	v_fma_mixlo_f16 v50, v60, s6, 0                            // 0000000EA964: CC210032 02000D3C
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA96C: CC200022 8A000F22
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA974: CC200033 8A000F33
	v_fma_f32 v31, -v33, v32, v31                              // 0000000EA97C: D613001F 247E4121
	v_fma_mixlo_f16 v32, v53, s6, 0                            // 0000000EA984: CC210020 02000D35
	s_waitcnt lgkmcnt(0)                                       // 0000000EA98C: BF89FC07
	v_fma_mixlo_f16 v33, v61, s6, 0                            // 0000000EA990: CC210021 02000D3D
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA998: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA9A0: CC200032 8A000F32
	v_fma_f32 v31, -v51, v34, v31                              // 0000000EA9A8: D613001F 247E4533
	v_fma_mixlo_f16 v34, v54, s6, 0                            // 0000000EA9B0: CC210022 02000D36
	v_fma_mixlo_f16 v51, v62, s6, 0                            // 0000000EA9B8: CC210033 02000D3E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA9C0: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA9C8: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000EA9D0: D613001F 247E6332
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA9D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EA9E0: CC200031 8A000F33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA9E8: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000EA9EC: D613001F 247E4121
	v_fma_f32 v31, -v49, v34, v31                              // 0000000EA9F4: D613001F 247E4531
	s_cbranch_scc1 65419                                       // 0000000EA9FC: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000EAA00: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000EAA0C: D8340000 00001F20
	s_branch 65336                                             // 0000000EAA14: BFA0FF38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_mov_b32_e32 v30, v14                                     // 0000000EAA18: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000EAA1C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000EAA24: 7E3E0309
	v_mov_b32_e32 v49, v41                                     // 0000000EAA28: 7E620329
	s_mov_b32 s12, 0                                           // 0000000EAA2C: BE8C0080
	s_branch 21                                                // 0000000EAA30: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x888>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000EAA34: 8C7E0D7E
	.long 0xd700011f                                           // 0000000EAA38: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000EAA3C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EAA44: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000EAA48: D5207C20 00064080
	.long 0xd700011d                                           // 0000000EAA50: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000EAA54: 02023AFF 00000800
	v_add_nc_u32_e32 v49, 8, v49                               // 0000000EAA5C: 4A626288
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EAA60: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000EAA68: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000EAA6C: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000EAA70: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000EAA74: BC7C0000
	s_barrier                                                  // 0000000EAA78: BFBD0000
	buffer_gl0_inv                                             // 0000000EAA7C: E0AC0000 00000000
	s_cbranch_scc1 217                                         // 0000000EAA84: BFA200D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbec>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAA88: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000EAA8C: CA100120 2220011F
	v_dual_mov_b32 v50, v38 :: v_dual_mov_b32 v51, v36         // 0000000EAA94: CA100126 32320124
	s_mov_b32 s13, 0                                           // 0000000EAA9C: BE8D0080
	s_nop 0                                                    // 0000000EAAA0: BF800000
	s_nop 0                                                    // 0000000EAAA4: BF800000
	s_nop 0                                                    // 0000000EAAA8: BF800000
	s_nop 0                                                    // 0000000EAAAC: BF800000
	s_nop 0                                                    // 0000000EAAB0: BF800000
	s_nop 0                                                    // 0000000EAAB4: BF800000
	s_nop 0                                                    // 0000000EAAB8: BF800000
	s_nop 0                                                    // 0000000EAABC: BF800000
	global_load_b32 v52, v[33:34], off                         // 0000000EAAC0: DC520000 347C0021
	v_add_nc_u32_e32 v51, 0x80, v51                            // 0000000EAAC8: 4A6666FF 00000080
	.long 0xd7000121                                           // 0000000EAAD0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000EAAD4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EAADC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000EAAE0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000EAAE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v51, vcc_lo                   // 0000000EAAEC: 020266FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000EAAF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000EAAF8: BF8903F7
	ds_store_b32 v50, v52 offset:13056                         // 0000000EAAFC: D8343300 00003432
	v_add_nc_u32_e32 v50, 0x204, v50                           // 0000000EAB04: 4A6464FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000EAB0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000EAB10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000EAB14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EAB18: BF89FC07
	s_barrier                                                  // 0000000EAB1C: BFBD0000
	buffer_gl0_inv                                             // 0000000EAB20: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000EAB28: BE8D2000
	s_cbranch_execz 65473                                      // 0000000EAB2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_or_b32_e32 v33, s12, v2                                  // 0000000EAB30: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAB34: BF870091
	v_or_b32_e32 v50, s11, v33                                 // 0000000EAB38: 3864420B
	.long 0xd4440001                                           // 0000000EAB3C: D4440001
	v_cndmask_b32_e32 v1, s30, v50, vcc_lo                     // 0000000EAB40: 0202641E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000EAB44: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000EAB48: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_mov_b32_e32 v51, 0                                       // 0000000EAB4C: 7E660280
	s_mov_b32 s1, 0                                            // 0000000EAB50: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EAB54: BF870009
	v_lshl_add_u32 v34, s1, 2, v44                             // 0000000EAB58: D6460022 04B10401
	s_add_i32 s4, s1, 8                                        // 0000000EAB60: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000EAB64: B6810078
	ds_load_2addr_b32 v[61:62], v34 offset1:1                  // 0000000EAB68: D8DC0100 3D000022
	ds_load_2addr_b32 v[63:64], v34 offset0:2 offset1:3        // 0000000EAB70: D8DC0302 3F000022
	ds_load_2addr_b32 v[65:66], v34 offset0:4 offset1:5        // 0000000EAB78: D8DC0504 41000022
	ds_load_2addr_b32 v[67:68], v34 offset0:6 offset1:7        // 0000000EAB80: D8DC0706 43000022
	v_mad_u64_u32 v[52:53], null, 0x44, s1, v[1:2]             // 0000000EAB88: D6FE7C34 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000EAB94: BE810004
	ds_load_2addr_b32 v[53:54], v52 offset1:17                 // 0000000EAB98: D8DC1100 35000034
	ds_load_2addr_b32 v[55:56], v52 offset0:34 offset1:51      // 0000000EABA0: D8DC3322 37000034
	ds_load_2addr_b32 v[57:58], v52 offset0:68 offset1:85      // 0000000EABA8: D8DC5544 39000034
	ds_load_2addr_b32 v[59:60], v52 offset0:102 offset1:119    // 0000000EABB0: D8DC7766 3B000034
	s_waitcnt lgkmcnt(7)                                       // 0000000EABB8: BF89FC77
	v_fma_mixlo_f16 v52, v61, s6, 0                            // 0000000EABBC: CC210034 02000D3D
	s_waitcnt lgkmcnt(6)                                       // 0000000EABC4: BF89FC67
	v_fma_mixlo_f16 v61, v63, s6, 0                            // 0000000EABC8: CC21003D 02000D3F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EABD0: BF870002
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EABD4: CC200034 8A000F34
	s_waitcnt lgkmcnt(3)                                       // 0000000EABDC: BF89FC37
	v_fma_mixlo_f16 v34, v53, s6, 0                            // 0000000EABE0: CC210022 02000D35
	v_fma_mixlo_f16 v53, v54, s6, 0                            // 0000000EABE8: CC210035 02000D36
	v_fma_mixlo_f16 v54, v62, s6, 0                            // 0000000EABF0: CC210036 02000D3E
	s_waitcnt lgkmcnt(2)                                       // 0000000EABF8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EABFC: CC210037 02000D37
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC04: CC200022 8A000F22
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC0C: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC14: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EAC1C: BF870214
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC20: CC200037 8A000F37
	v_fmac_f32_e32 v51, v52, v34                               // 0000000EAC28: 56664534
	v_fma_mixlo_f16 v34, v56, s6, 0                            // 0000000EAC2C: CC210022 02000D38
	v_fma_mixlo_f16 v52, v64, s6, 0                            // 0000000EAC34: CC210034 02000D40
	v_fma_mix_f32 v56, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC3C: CC200038 8A000F3D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EAC44: BF870004
	v_fmac_f32_e32 v51, v54, v53                               // 0000000EAC48: 56666B36
	s_waitcnt lgkmcnt(1)                                       // 0000000EAC4C: BF89FC17
	v_fma_mixlo_f16 v53, v57, s6, 0                            // 0000000EAC50: CC210035 02000D39
	v_fma_mixlo_f16 v54, v65, s6, 0                            // 0000000EAC58: CC210036 02000D41
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC60: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC68: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000EAC70: 56666F38
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EAC74: CC210037 02000D3A
	v_fma_mixlo_f16 v56, v66, s6, 0                            // 0000000EAC7C: CC210038 02000D42
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC84: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAC8C: CC200036 8A000F36
	v_fmac_f32_e32 v51, v52, v34                               // 0000000EAC94: 56664534
	s_waitcnt lgkmcnt(0)                                       // 0000000EAC98: BF89FC07
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000EAC9C: CC210022 02000D3B
	v_fma_mixlo_f16 v52, v67, s6, 0                            // 0000000EACA4: CC210034 02000D43
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACAC: CC200037 8A000F37
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACB4: CC200038 8A000F38
	v_fmac_f32_e32 v51, v54, v53                               // 0000000EACBC: 56666B36
	v_fma_mixlo_f16 v53, v60, s6, 0                            // 0000000EACC0: CC210035 02000D3C
	v_fma_mixlo_f16 v54, v68, s6, 0                            // 0000000EACC8: CC210036 02000D44
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACD0: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACD8: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000EACE0: 56666F38
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACE4: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EACEC: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EACF4: BF870093
	v_fmac_f32_e32 v51, v52, v34                               // 0000000EACF8: 56664534
	v_fmac_f32_e32 v51, v54, v53                               // 0000000EACFC: 56666B36
	s_cbranch_scc1 65428                                       // 0000000EAD00: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v52, v1 :: v_dual_lshlrev_b32 v33, 2, v33   // 0000000EAD04: CA220101 34204282
	s_mov_b32 s14, 0                                           // 0000000EAD0C: BE8E0080
	ds_load_b32 v53, v33 offset:17440                          // 0000000EAD10: D8D84420 35000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000EAD18: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000EAD20: BF89FC07
	v_mul_f32_e32 v51, v51, v53                                // 0000000EAD24: 10666B33
	v_mov_b32_e32 v53, v49                                     // 0000000EAD28: 7E6A0331
	s_nop 0                                                    // 0000000EAD2C: BF800000
	s_nop 0                                                    // 0000000EAD30: BF800000
	s_nop 0                                                    // 0000000EAD34: BF800000
	s_nop 0                                                    // 0000000EAD38: BF800000
	s_nop 0                                                    // 0000000EAD3C: BF800000
	global_load_b32 v54, v[33:34], off                         // 0000000EAD40: DC520000 367C0021
	ds_load_b32 v55, v52 offset:8704                           // 0000000EAD48: D8D82200 37000034
	v_add_nc_u32_e32 v53, -1, v53                              // 0000000EAD50: 4A6A6AC1
	.long 0xd7000121                                           // 0000000EAD54: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000EAD58: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EAD5C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000EAD60: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000EAD68: D44A0004
	v_cndmask_b32_e32 v1, 0, v53, vcc_lo                       // 0000000EAD6C: 02026A80
	v_add_nc_u32_e32 v52, 0x44, v52                            // 0000000EAD70: 4A6868FF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000EAD78: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000EAD7C: BF89FC07
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EAD80: CC210037 02000D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000EAD88: BF8700B1
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAD8C: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000EAD94: BF8903F7
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000EAD98: CC210036 02000D36
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EADA0: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EADA8: BF870001
	v_fmac_f32_e32 v51, v54, v55                               // 0000000EADAC: 56666F36
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000EADB0: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000EADB4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000EADB8: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EADBC: BF870121
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000EADC0: D6100034 02052133
	v_mad_u64_u32 v[33:34], null, 0x3000, v50, v[5:6]          // 0000000EADC8: D6FE7C21 041664FF 00003000
	v_add3_u32 v50, v51, v52, 0x7fff                           // 0000000EADD4: D6550032 03FE6933 00007FFF
	global_store_d16_hi_b16 v[33:34], v50, off                 // 0000000EADE0: DC960000 007C3221
	s_branch 65298                                             // 0000000EADE8: BFA0FF12 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000EADEC: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000EADF4: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EADF8: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000EADFC: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000EAE04: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000EAE08: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000EAE10: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000EAE18: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000EAE1C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000EAE20: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000EAE28: A0010401
	s_mov_b32 s4, 0                                            // 0000000EAE2C: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000EAE30: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000EAE34: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000EAE38: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000EAE3C: BF870585
	.long 0xd71c001d                                           // 0000000EAE40: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000EAE44: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000EAE48: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000EAE4C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000EAE54: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000EAE58: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000EAE60: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000EAE64: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000EAE68: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000EAE74: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000EAE7C: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EAE84: BF870001
	.long 0xd4490001                                           // 0000000EAE88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000EAE8C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000EAE94: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000EAE98: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000EAE9C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000EAEA0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000EAEA8: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EAEB0: 917E047E
	s_cbranch_execnz 65519                                     // 0000000EAEB4: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EAEB8: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000EAEBC: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000EAEC4: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000EAECC: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EAED0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EAED4: BF89FC07
	s_barrier                                                  // 0000000EAED8: BFBD0000
	buffer_gl0_inv                                             // 0000000EAEDC: E0AC0000 00000000
	s_nop 0                                                    // 0000000EAEE4: BF800000
	s_nop 0                                                    // 0000000EAEE8: BF800000
	s_nop 0                                                    // 0000000EAEEC: BF800000
	s_nop 0                                                    // 0000000EAEF0: BF800000
	s_nop 0                                                    // 0000000EAEF4: BF800000
	s_nop 0                                                    // 0000000EAEF8: BF800000
	s_nop 0                                                    // 0000000EAEFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EAF00: DC520000 227C001D
	ds_load_b32 v49, v31 offset:17184                          // 0000000EAF08: D8D84320 3100001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EAF10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EAF18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EAF1C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000EAF24: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EAF28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EAF30: BF870004
	.long 0xd4490004                                           // 0000000EAF34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EAF38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EAF40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EAF44: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EAF48: 10446322
	ds_store_b32 v32, v34 offset:13056                         // 0000000EAF4C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000EAF54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EAF5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EAF60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EAF64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EAF68: BF89FC07
	s_barrier                                                  // 0000000EAF6C: BFBD0000
	buffer_gl0_inv                                             // 0000000EAF70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000EAF78: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000EAF80: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000EAF88: D8DC5544 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:102 offset1:119    // 0000000EAF90: D8DC7766 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000EAF98: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EAF9C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EAFA0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EAFA4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EAFAC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EAFB4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EAFB8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EAFC0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EAFC8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EAFCC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EAFD4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EAFDC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EAFE0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EAFE8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAFF0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EAFF8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB000: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB008: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB010: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB018: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB020: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB028: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EB030: 326C6684
	.long 0xd4490001                                           // 0000000EB034: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EB038: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB040: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EB044: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EB048: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EB054: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EB058: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EB060: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EB068: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EB070: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EB078: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EB080: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EB088: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EB090: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EB098: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EB09C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EB0A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB0A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EB0B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EB0B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EB0C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EB0C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB0CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB0D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EB0DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB0E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB0EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB0F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EB0FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB100: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EB104: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EB108: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EB10C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EB114: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EB118: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EB11C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB120: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB128: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EB130: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EB138: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB13C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB140: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB148: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB150: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EB154: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EB158: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EB15C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB164: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EB168: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EB170: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EB178: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EB17C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EB180: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000EB184: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000EB18C: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000EB194: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EB198: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EB19C: BF89FC07
	s_barrier                                                  // 0000000EB1A0: BFBD0000
	buffer_gl0_inv                                             // 0000000EB1A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000EB1AC: BF800000
	s_nop 0                                                    // 0000000EB1B0: BF800000
	s_nop 0                                                    // 0000000EB1B4: BF800000
	s_nop 0                                                    // 0000000EB1B8: BF800000
	s_nop 0                                                    // 0000000EB1BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EB1C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17216                          // 0000000EB1C8: D8D84340 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EB1D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EB1D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EB1DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000EB1E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EB1E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EB1F0: BF870004
	.long 0xd4490004                                           // 0000000EB1F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EB1F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EB200: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EB204: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EB208: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000EB20C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000EB214: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EB21C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EB220: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EB224: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EB228: BF89FC07
	s_barrier                                                  // 0000000EB22C: BFBD0000
	buffer_gl0_inv                                             // 0000000EB230: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000EB238: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000EB240: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000EB248: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:238 offset1:255    // 0000000EB250: D8DCFFEE 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000EB258: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EB25C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EB260: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EB264: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EB26C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EB274: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EB278: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EB280: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EB288: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EB28C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EB294: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EB29C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EB2A0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EB2A8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2B0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2B8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2C0: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2C8: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2D0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2E0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB2E8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EB2F0: 326C6684
	.long 0xd4490001                                           // 0000000EB2F4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EB2F8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB300: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EB304: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EB308: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EB314: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EB318: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EB320: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EB328: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EB330: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EB338: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EB340: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EB348: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EB350: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EB358: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EB35C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EB364: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB368: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EB370: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EB378: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EB380: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EB384: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB38C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB394: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EB39C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB3A4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB3AC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB3B4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EB3BC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB3C0: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EB3C4: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EB3C8: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EB3CC: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EB3D4: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EB3D8: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EB3DC: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB3E0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB3E8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EB3F0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EB3F8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB3FC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB400: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB408: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB410: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EB414: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EB418: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EB41C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB424: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EB428: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EB430: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EB438: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EB43C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EB440: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000EB444: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000EB448: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000EB44C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000EB454: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EB458: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EB45C: BF89FC07
	s_barrier                                                  // 0000000EB460: BFBD0000
	buffer_gl0_inv                                             // 0000000EB464: E0AC0000 00000000
	s_nop 0                                                    // 0000000EB46C: BF800000
	s_nop 0                                                    // 0000000EB470: BF800000
	s_nop 0                                                    // 0000000EB474: BF800000
	s_nop 0                                                    // 0000000EB478: BF800000
	s_nop 0                                                    // 0000000EB47C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EB480: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17248                          // 0000000EB488: D8D84360 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EB490: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EB498: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EB49C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000EB4A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EB4A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EB4B0: BF870004
	.long 0xd4490004                                           // 0000000EB4B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EB4B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EB4C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EB4C4: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EB4C8: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000EB4CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000EB4D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EB4DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EB4E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EB4E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EB4E8: BF89FC07
	s_barrier                                                  // 0000000EB4EC: BFBD0000
	buffer_gl0_inv                                             // 0000000EB4F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:16 offset1:33      // 0000000EB4F8: D8DC2110 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:50 offset1:67      // 0000000EB500: D8DC4332 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:101     // 0000000EB508: D8DC6554 2100002E
	ds_load_2addr_b32 v[49:50], v46 offset0:118 offset1:135    // 0000000EB510: D8DC8776 3100002E
	v_mov_b32_e32 v51, v0                                      // 0000000EB518: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EB51C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EB520: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EB524: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EB52C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EB534: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EB538: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EB540: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EB548: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EB54C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EB554: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EB55C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EB560: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EB568: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB570: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB578: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB580: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB588: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB590: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB598: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB5A0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB5A8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EB5B0: 326C6684
	.long 0xd4490001                                           // 0000000EB5B4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EB5B8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB5C0: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EB5C4: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EB5C8: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EB5D4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EB5D8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EB5E0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EB5E8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EB5F0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EB5F8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EB600: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EB608: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EB610: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EB618: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EB61C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EB624: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB628: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EB630: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EB638: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EB640: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EB644: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB64C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB654: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EB65C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB664: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB66C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB674: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EB67C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB680: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EB684: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EB688: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EB68C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EB694: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EB698: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EB69C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB6A0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB6A8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EB6B0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EB6B8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB6BC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB6C0: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB6C8: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB6D0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EB6D4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EB6D8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EB6DC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB6E4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EB6E8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EB6F0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EB6F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EB6FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EB700: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v31, v38         // 0000000EB704: CA100114 1E1E0126
	v_dual_mov_b32 v29, v19 :: v_dual_mov_b32 v32, 0           // 0000000EB70C: CA100113 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000EB714: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EB718: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EB71C: BF89FC07
	s_barrier                                                  // 0000000EB720: BFBD0000
	buffer_gl0_inv                                             // 0000000EB724: E0AC0000 00000000
	s_nop 0                                                    // 0000000EB72C: BF800000
	s_nop 0                                                    // 0000000EB730: BF800000
	s_nop 0                                                    // 0000000EB734: BF800000
	s_nop 0                                                    // 0000000EB738: BF800000
	s_nop 0                                                    // 0000000EB73C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EB740: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17280                          // 0000000EB748: D8D84380 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EB750: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EB758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EB75C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000EB764: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EB768: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EB770: BF870004
	.long 0xd4490004                                           // 0000000EB774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EB778: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EB780: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EB784: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EB788: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000EB78C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000EB794: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EB79C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EB7A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EB7A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EB7A8: BF89FC07
	s_barrier                                                  // 0000000EB7AC: BFBD0000
	buffer_gl0_inv                                             // 0000000EB7B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:152 offset1:169    // 0000000EB7B8: D8DCA998 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:186 offset1:203    // 0000000EB7C0: D8DCCBBA 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:220 offset1:237    // 0000000EB7C8: D8DCEDDC 2100002E
	ds_load_2addr_b32 v[49:50], v47 offset0:126 offset1:143    // 0000000EB7D0: D8DC8F7E 3100002F
	v_mov_b32_e32 v51, v0                                      // 0000000EB7D8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EB7DC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EB7E0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EB7E4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EB7EC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EB7F4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EB7F8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EB800: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EB808: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EB80C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EB814: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EB81C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EB820: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EB828: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB830: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB838: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB840: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB848: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB850: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB858: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB860: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB868: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EB870: 326C6684
	.long 0xd4490001                                           // 0000000EB874: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EB878: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB880: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EB884: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EB888: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EB894: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EB898: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EB8A0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EB8A8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EB8B0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EB8B8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EB8C0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EB8C8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EB8D0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EB8D8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EB8DC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EB8E4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB8E8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EB8F0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EB8F8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EB900: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EB904: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB90C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB914: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EB91C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB924: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB92C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB934: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EB93C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB940: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EB944: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EB948: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EB94C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EB954: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EB958: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EB95C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EB960: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB968: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EB970: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EB978: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB97C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB980: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EB988: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB990: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EB994: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EB998: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EB99C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB9A4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EB9A8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EB9B0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EB9B8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EB9BC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EB9C0: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000EB9C4: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000EB9C8: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000EB9CC: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000EB9D4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EB9D8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EB9DC: BF89FC07
	s_barrier                                                  // 0000000EB9E0: BFBD0000
	buffer_gl0_inv                                             // 0000000EB9E4: E0AC0000 00000000
	s_nop 0                                                    // 0000000EB9EC: BF800000
	s_nop 0                                                    // 0000000EB9F0: BF800000
	s_nop 0                                                    // 0000000EB9F4: BF800000
	s_nop 0                                                    // 0000000EB9F8: BF800000
	s_nop 0                                                    // 0000000EB9FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EBA00: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17312                          // 0000000EBA08: D8D843A0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EBA10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EBA18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EBA1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000EBA24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EBA28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EBA30: BF870004
	.long 0xd4490004                                           // 0000000EBA34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EBA38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EBA40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EBA44: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EBA48: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000EBA4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000EBA54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EBA5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EBA60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EBA64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EBA68: BF89FC07
	s_barrier                                                  // 0000000EBA6C: BFBD0000
	buffer_gl0_inv                                             // 0000000EBA70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:32 offset1:49      // 0000000EBA78: D8DC3120 1D000030
	ds_load_2addr_b32 v[31:32], v48 offset0:66 offset1:83      // 0000000EBA80: D8DC5342 1F000030
	ds_load_2addr_b32 v[33:34], v48 offset0:100 offset1:117    // 0000000EBA88: D8DC7564 21000030
	ds_load_2addr_b32 v[49:50], v48 offset0:134 offset1:151    // 0000000EBA90: D8DC9786 31000030
	v_mov_b32_e32 v51, v0                                      // 0000000EBA98: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EBA9C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EBAA0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EBAA4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EBAAC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EBAB4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EBAB8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EBAC0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EBAC8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EBACC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EBAD4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EBADC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EBAE0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EBAE8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBAF0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBAF8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB00: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB08: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB10: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB18: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB20: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBB28: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EBB30: 326C6684
	.long 0xd4490001                                           // 0000000EBB34: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EBB38: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EBB40: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EBB44: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EBB48: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EBB54: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EBB58: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EBB60: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EBB68: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EBB70: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EBB78: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EBB80: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EBB88: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EBB90: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EBB98: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EBB9C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EBBA4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EBBA8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EBBB0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EBBB8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EBBC0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EBBC4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBBCC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBBD4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EBBDC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBBE4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBBEC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBBF4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EBBFC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBC00: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EBC04: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EBC08: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EBC0C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EBC14: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EBC18: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EBC1C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EBC20: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBC28: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EBC30: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EBC38: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBC3C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBC40: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBC48: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBC50: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EBC54: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EBC58: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EBC5C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EBC64: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EBC68: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EBC70: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EBC78: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EBC7C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1930>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EBC80: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000EBC84: CA100118 1E1E0126
	v_dual_mov_b32 v29, v23 :: v_dual_mov_b32 v32, 0           // 0000000EBC8C: CA100117 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000EBC94: 7E420324
	s_mov_b32 s10, 0                                           // 0000000EBC98: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EBC9C: BF89FC07
	s_barrier                                                  // 0000000EBCA0: BFBD0000
	buffer_gl0_inv                                             // 0000000EBCA4: E0AC0000 00000000
	s_nop 0                                                    // 0000000EBCAC: BF800000
	s_nop 0                                                    // 0000000EBCB0: BF800000
	s_nop 0                                                    // 0000000EBCB4: BF800000
	s_nop 0                                                    // 0000000EBCB8: BF800000
	s_nop 0                                                    // 0000000EBCBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000EBCC0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17344                          // 0000000EBCC8: D8D843C0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000EBCD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000EBCD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EBCDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000EBCE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EBCE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EBCF0: BF870004
	.long 0xd4490004                                           // 0000000EBCF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000EBCF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EBD00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EBD04: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000EBD08: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000EBD0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000EBD14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EBD1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EBD20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EBD24: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000EBD28: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000EBD30: BF89FC07
	s_barrier                                                  // 0000000EBD34: BFBD0000
	buffer_gl0_inv                                             // 0000000EBD38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:168 offset1:185    // 0000000EBD40: D8DCB9A8 1D000030
	ds_load_2addr_b32 v[32:33], v48 offset0:202 offset1:219    // 0000000EBD48: D8DCDBCA 20000030
	ds_load_2addr_b32 v[49:50], v48 offset0:236 offset1:253    // 0000000EBD50: D8DCFDEC 31000030
	ds_load_2addr_b32 v[51:52], v31 offset0:14 offset1:31      // 0000000EBD58: D8DC1F0E 3300001F
	s_mov_b32 s4, 0                                            // 0000000EBD60: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EBD64: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EBD68: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EBD70: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EBD78: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EBD7C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EBD84: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000EBD8C: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000EBD90: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000EBD98: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000EBDA0: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000EBDA4: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000EBDAC: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDB4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDBC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDC4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDCC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDD4: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDDC: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDE4: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBDEC: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000EBDF4: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EBDF8: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000EBDFC: 326E6884
	.long 0xd4490001                                           // 0000000EBE00: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000EBE04: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000EBE0C: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000EBE10: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EBE1C: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000EBE20: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000EBE28: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000EBE30: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000EBE38: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000EBE40: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000EBE48: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000EBE50: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000EBE58: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000EBE60: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EBE64: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000EBE6C: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EBE70: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000EBE78: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EBE80: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000EBE88: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000EBE8C: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBE94: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBE9C: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000EBEA4: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBEAC: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBEB4: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBEBC: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000EBEC4: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBEC8: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000EBECC: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000EBED0: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000EBED4: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EBEDC: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000EBEE0: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000EBEE4: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EBEE8: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBEF0: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000EBEF8: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000EBF00: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBF04: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBF08: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EBF10: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBF18: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000EBF1C: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000EBF20: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000EBF24: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EBF2C: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000EBF30: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000EBF38: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EBF40: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EBF44: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bf8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EBF48: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000EBF4C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000EBF50: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000EBF58: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000EBF60: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EBF64: BF89FC07
	s_barrier                                                  // 0000000EBF68: BFBD0000
	buffer_gl0_inv                                             // 0000000EBF6C: E0AC0000 00000000
	s_nop 0                                                    // 0000000EBF74: BF800000
	s_nop 0                                                    // 0000000EBF78: BF800000
	s_nop 0                                                    // 0000000EBF7C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000EBF80: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17376                          // 0000000EBF88: D8D843E0 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000EBF90: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000EBF98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EBF9C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000EBFA4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EBFA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EBFB0: BF870004
	.long 0xd4490004                                           // 0000000EBFB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000EBFB8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EBFC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EBFC4: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000EBFC8: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000EBFCC: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000EBFD4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EBFDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EBFE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EBFE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000EBFE8: BF89FC07
	s_barrier                                                  // 0000000EBFEC: BFBD0000
	buffer_gl0_inv                                             // 0000000EBFF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000EBFF8: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000EC000: D8DC6352 2000001F
	ds_load_2addr_b32 v[49:50], v31 offset0:116 offset1:133    // 0000000EC008: D8DC8574 3100001F
	ds_load_2addr_b32 v[51:52], v31 offset0:150 offset1:167    // 0000000EC010: D8DCA796 3300001F
	s_mov_b32 s4, 0                                            // 0000000EC018: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EC01C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EC020: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EC028: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EC030: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EC034: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EC03C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000EC044: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000EC048: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000EC050: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000EC058: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000EC05C: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000EC064: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC06C: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC074: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC07C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC084: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC08C: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC094: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC09C: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC0A4: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000EC0AC: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC0B0: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000EC0B4: 326E6884
	.long 0xd4490001                                           // 0000000EC0B8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000EC0BC: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000EC0C4: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000EC0C8: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EC0D4: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000EC0D8: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000EC0E0: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000EC0E8: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000EC0F0: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000EC0F8: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000EC100: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000EC108: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000EC110: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000EC118: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EC11C: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000EC124: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EC128: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000EC130: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EC138: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000EC140: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000EC144: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC14C: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC154: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000EC15C: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC164: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC16C: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC174: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000EC17C: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC180: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000EC184: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000EC188: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000EC18C: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EC194: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000EC198: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000EC19C: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EC1A0: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC1A8: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000EC1B0: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000EC1B8: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EC1BC: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC1C0: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC1C8: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1D0: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000EC1D4: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000EC1D8: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000EC1DC: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC1E4: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000EC1E8: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000EC1F0: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EC1F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EC1FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EC200: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000EC204: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000EC208: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000EC210: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000EC218: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000EC21C: BF89FC07
	s_barrier                                                  // 0000000EC220: BFBD0000
	buffer_gl0_inv                                             // 0000000EC224: E0AC0000 00000000
	s_nop 0                                                    // 0000000EC22C: BF800000
	s_nop 0                                                    // 0000000EC230: BF800000
	s_nop 0                                                    // 0000000EC234: BF800000
	s_nop 0                                                    // 0000000EC238: BF800000
	s_nop 0                                                    // 0000000EC23C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000EC240: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17408                          // 0000000EC248: D8D84400 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000EC250: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000EC258: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000EC25C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000EC264: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EC268: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EC270: BF870004
	.long 0xd4490004                                           // 0000000EC274: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000EC278: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000EC280: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EC284: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000EC288: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000EC28C: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000EC294: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000EC29C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000EC2A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EC2A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000EC2A8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v49, 0x1000, v45                          // 0000000EC2B0: 4A625AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000EC2B8: BF89FC07
	s_barrier                                                  // 0000000EC2BC: BFBD0000
	buffer_gl0_inv                                             // 0000000EC2C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000EC2C8: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000EC2D0: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000EC2D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[49:50], v49 offset0:30 offset1:47      // 0000000EC2E0: D8DC2F1E 31000031
	v_mov_b32_e32 v51, v0                                      // 0000000EC2E8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000EC2EC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000EC2F0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000EC2F4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000EC2FC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000EC304: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000EC308: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000EC310: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000EC318: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000EC31C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000EC324: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000EC32C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000EC330: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000EC338: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC340: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC348: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC350: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC358: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC360: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC368: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC370: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC378: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000EC380: 326C6684
	.long 0xd4490001                                           // 0000000EC384: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000EC388: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EC390: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000EC394: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000EC398: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EC3A4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000EC3A8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000EC3B0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000EC3B8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000EC3C0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000EC3C8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000EC3D0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000EC3D8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000EC3E0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000EC3E8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000EC3EC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000EC3F4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EC3F8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000EC400: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000EC408: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000EC410: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000EC414: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC41C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC424: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000EC42C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC434: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC43C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC444: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000EC44C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC450: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000EC454: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000EC458: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000EC45C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EC464: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000EC468: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000EC46C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000EC470: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC478: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000EC480: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000EC488: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EC48C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC490: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000EC498: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4A0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000EC4A4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000EC4A8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000EC4AC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC4B4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000EC4B8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000EC4C0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EC4C8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000EC4CC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EC4D0: 8C7E047E
	.long 0xd7000107                                           // 0000000EC4D4: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000EC4D8: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC4E0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000EC4E4: D5207C08 00061080
	.long 0xd7000109                                           // 0000000EC4EC: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000EC4F0: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000EC4F8: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000EC500: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000EC504: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC50C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000EC510: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000EC518: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000EC51C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000EC524: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000EC52C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000EC530: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC538: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000EC53C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000EC544: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000EC548: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000EC550: D5207C12 00062480
	.long 0xd7000113                                           // 0000000EC558: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000EC55C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC564: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000EC568: D5207C14 00062880
	.long 0xd7000115                                           // 0000000EC570: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000EC574: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000EC57C: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000EC584: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000EC588: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC590: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000EC594: D5207C18 00063080
	.long 0xd7000119                                           // 0000000EC59C: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000EC5A0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000EC5A8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000EC5B0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000EC5B4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC5BC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000EC5C0: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000EC5C8: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000EC5CC: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000EC5D0: BF062105
	s_barrier                                                  // 0000000EC5D4: BFBD0000
	buffer_gl0_inv                                             // 0000000EC5D8: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 0000000EC5E0: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x368>
	v_mov_b32_e32 v4, v36                                      // 0000000EC5E4: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000EC5E8: 8000141C
	.long 0xd73c0000                                           // 0000000EC5EC: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000EC5F0: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000EC5F4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000EC5F8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000EC5FC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000EC600: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000EC604: 82010103
	.long 0xd7006a00                                           // 0000000EC608: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000EC60C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000EC610: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000EC614: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000EC61C: BE810080
	.long 0xd7006a00                                           // 0000000EC620: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000EC624: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000EC628: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC630: BF870092
	.long 0xd7006a00                                           // 0000000EC634: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000EC638: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000EC63C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000EC644: BF800000
	s_nop 0                                                    // 0000000EC648: BF800000
	s_nop 0                                                    // 0000000EC64C: BF800000
	s_nop 0                                                    // 0000000EC650: BF800000
	s_nop 0                                                    // 0000000EC654: BF800000
	s_nop 0                                                    // 0000000EC658: BF800000
	s_nop 0                                                    // 0000000EC65C: BF800000
	s_nop 0                                                    // 0000000EC660: BF800000
	s_nop 0                                                    // 0000000EC664: BF800000
	s_nop 0                                                    // 0000000EC668: BF800000
	s_nop 0                                                    // 0000000EC66C: BF800000
	s_nop 0                                                    // 0000000EC670: BF800000
	s_nop 0                                                    // 0000000EC674: BF800000
	s_nop 0                                                    // 0000000EC678: BF800000
	s_nop 0                                                    // 0000000EC67C: BF800000
	ds_load_b32 v2, v35                                        // 0000000EC680: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000EC688: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000EC690: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EC698: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000EC69C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000EC6A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000EC6A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000EC6AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000EC6B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000EC6B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000EC6C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000EC6C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000EC6CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000EC6D0: BFB00000
		...

