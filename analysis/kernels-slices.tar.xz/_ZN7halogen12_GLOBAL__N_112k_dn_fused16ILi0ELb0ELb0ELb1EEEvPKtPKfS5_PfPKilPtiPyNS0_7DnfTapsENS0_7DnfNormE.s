0000000000008500 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x2                                               // 000000008500: BF850002
	s_load_b128 s[4:7], s[0:1], 0x20                           // 000000008504: F4080100 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000000850C: F40C0200 F8000000
	s_load_b32 s33, s[0:1], 0x38                               // 000000008514: F4000840 F8000038
	v_readfirstlane_b32 s41, v0                                // 00000000851C: 7E520500
	v_mov_b32_e32 v73, 0                                       // 000000008520: 7E920280
	v_lshlrev_b32_e32 v1, 5, v0                                // 000000008524: 30020085
	s_ashr_i32 s3, s2, 31                                      // 000000008528: 86039F02
	v_lshrrev_b32_e32 v76, 4, v0                               // 00000000852C: 32980084
	s_lshr_b32 s40, s41, 5                                     // 000000008530: 85288529
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000008534: BF8700B9
	s_lshl_b32 s43, s40, 4                                     // 000000008538: 842B8428
	v_and_b32_e32 v3, 0x200, v1                                // 00000000853C: 360602FF 00000200
	v_and_or_b32 v72, v0, 15, s43                              // 000000008544: D6570048 00AD1F00
	.long 0xd73c0001                                           // 00000000854C: D73C0001
	v_cndmask_b32_e32 v1, 2, v72, vcc_lo                       // 000000008550: 02029082
	s_waitcnt lgkmcnt(0)                                       // 000000008554: BF89FC07
	s_load_b32 s16, s[4:5], null                               // 000000008558: F4000402 F8000000
	s_lshl_b64 s[4:5], s[6:7], 2                               // 000000008560: 84848206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000008564: BF8704B9
	s_add_u32 s4, s14, s4                                      // 000000008568: 8004040E
	s_addc_u32 s5, s15, s5                                     // 00000000856C: 8205050F
	s_lshl_b64 s[22:23], s[2:3], 16                            // 000000008570: 84969002
	s_add_u32 s4, s4, s22                                      // 000000008574: 80041604
	s_addc_u32 s5, s5, s23                                     // 000000008578: 82051705
	s_waitcnt lgkmcnt(0)                                       // 00000000857C: BF89FC07
	s_mul_i32 s6, s16, 0x9000000                               // 000000008580: 9606FF10 09000000
	s_mul_hi_i32 s7, s16, 0x9000000                            // 000000008588: 9707FF10 09000000
	s_add_u32 s4, s4, s6                                       // 000000008590: 80040604
	s_addc_u32 s5, s5, s7                                      // 000000008594: 82050705
	.long 0xd7006a01                                           // 000000008598: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000000859C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000085A0: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000085A4: D5207C02 01AA0405
	s_add_i32 s44, s33, -1                                     // 0000000085AC: 812CC121
	.long 0xd7006a47                                           // 0000000085B0: D7006A47
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000085B4: 02020701
	v_add_co_ci_u32_e64 v72, null, 0, v2, vcc_lo               // 0000000085B8: D5207C48 01AA0480
	v_min_i32_e32 v47, s44, v76                                // 0000000085C0: 225E982C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000085C4: BF870093
	.long 0xd7006a05                                           // 0000000085C8: D7006A05
	v_cndmask_b32_e32 v1, 0x1000, v71, vcc_lo                  // 0000000085CC: 02028EFF 00001000
	v_add_co_ci_u32_e64 v6, null, 0, v72, vcc_lo               // 0000000085D4: D5207C06 01AA9080
	.long 0xd7006a15                                           // 0000000085DC: D7006A15
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000085E0: 0201FF47
	.long 0x00002000                                           // 0000000085E4: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000085E8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v72, vcc_lo              // 0000000085EC: D5207C16 01AA9080
	.long 0xd7006a0b                                           // 0000000085F4: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v71, vcc_lo                  // 0000000085F8: 02028EFF 00002000
	v_add_co_ci_u32_e64 v12, null, 0, v72, vcc_lo              // 000000008600: D5207C0C 01AA9080
	.long 0xd7006a0d                                           // 000000008608: D7006A0D
	v_cndmask_b32_e32 v1, 0x3000, v71, vcc_lo                  // 00000000860C: 02028EFF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008614: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v72, vcc_lo              // 000000008618: D5207C0E 01AA9080
	.long 0xd7006a17                                           // 000000008620: D7006A17
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000008624: 0201FF47
	.long 0x00004000                                           // 000000008628: 00004000
	v_add_co_ci_u32_e64 v24, null, 0, v72, vcc_lo              // 00000000862C: D5207C18 01AA9080
	.long 0xd7006a19                                           // 000000008634: D7006A19
	v_cndmask_b32_e32 v1, 0x4000, v71, vcc_lo                  // 000000008638: 02028EFF 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008640: BF8700A1
	v_add_co_ci_u32_e64 v26, null, 0, v72, vcc_lo              // 000000008644: D5207C1A 01AA9080
	.long 0xd7006a1b                                           // 00000000864C: D7006A1B
	v_cndmask_b32_e32 v1, 0x5000, v71, vcc_lo                  // 000000008650: 02028EFF 00005000
	v_add_co_ci_u32_e64 v28, null, 0, v72, vcc_lo              // 000000008658: D5207C1C 01AA9080
	.long 0xd7006a1f                                           // 000000008660: D7006A1F
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000008664: 0201FF47
	.long 0x00006000                                           // 000000008668: 00006000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000866C: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v72, vcc_lo              // 000000008670: D5207C20 01AA9080
	.long 0xd7006a25                                           // 000000008678: D7006A25
	v_cndmask_b32_e32 v1, 0x6000, v71, vcc_lo                  // 00000000867C: 02028EFF 00006000
	s_clause 0x7                                               // 000000008684: BF850007
	global_load_b32 v8, v[5:6], off offset:1024                // 000000008688: DC520400 087C0005
	global_load_b32 v9, v[5:6], off offset:2048                // 000000008690: DC520800 097C0005
	global_load_b32 v10, v[5:6], off offset:3072               // 000000008698: DC520C00 0A7C0005
	global_load_b32 v5, v[11:12], off offset:1024              // 0000000086A0: DC520400 057C000B
	global_load_b32 v6, v[11:12], off offset:2048              // 0000000086A8: DC520800 067C000B
	global_load_b32 v7, v[11:12], off offset:3072              // 0000000086B0: DC520C00 077C000B
	global_load_b32 v11, v[13:14], off offset:1024             // 0000000086B8: DC520400 0B7C000D
	global_load_b32 v12, v[13:14], off offset:2048             // 0000000086C0: DC520800 0C7C000D
	v_add_co_ci_u32_e64 v38, null, 0, v72, vcc_lo              // 0000000086C8: D5207C26 01AA9080
	s_clause 0x7                                               // 0000000086D0: BF850007
	global_load_b32 v19, v[13:14], off offset:3072             // 0000000086D4: DC520C00 137C000D
	global_load_b32 v16, v[25:26], off offset:1024             // 0000000086DC: DC520400 107C0019
	global_load_b32 v17, v[25:26], off offset:2048             // 0000000086E4: DC520800 117C0019
	global_load_b32 v18, v[25:26], off offset:3072             // 0000000086EC: DC520C00 127C0019
	global_load_b32 v13, v[27:28], off offset:1024             // 0000000086F4: DC520400 0D7C001B
	global_load_b32 v14, v[27:28], off offset:2048             // 0000000086FC: DC520800 0E7C001B
	global_load_b32 v15, v[27:28], off offset:3072             // 000000008704: DC520C00 0F7C001B
	global_load_b32 v20, v[37:38], off offset:1024             // 00000000870C: DC520400 147C0025
	.long 0xd7006a19                                           // 000000008714: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v71, vcc_lo                  // 000000008718: 02028EFF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008720: BF8700A1
	v_add_co_ci_u32_e64 v26, null, 0, v72, vcc_lo              // 000000008724: D5207C1A 01AA9080
	.long 0xd7006a1b                                           // 00000000872C: D7006A1B
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000008730: 0201FF47
	.long 0x00008000                                           // 000000008734: 00008000
	v_add_co_ci_u32_e64 v28, null, 0, v72, vcc_lo              // 000000008738: D5207C1C 01AA9080
	.long 0xd7006a27                                           // 000000008740: D7006A27
	v_cndmask_b32_e32 v1, 0x8000, v71, vcc_lo                  // 000000008744: 02028EFF 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000874C: BF870001
	v_add_co_ci_u32_e64 v40, null, 0, v72, vcc_lo              // 000000008750: D5207C28 01AA9080
	s_clause 0xf                                               // 000000008758: BF85000F
	global_load_b32 v36, v[21:22], off offset:-4096            // 00000000875C: DC521000 247C0015
	global_load_b32 v35, v[21:22], off                         // 000000008764: DC520000 237C0015
	global_load_b32 v34, v[23:24], off offset:-4096            // 00000000876C: DC521000 227C0017
	global_load_b32 v33, v[23:24], off                         // 000000008774: DC520000 217C0017
	global_load_b32 v30, v[31:32], off offset:-4096            // 00000000877C: DC521000 1E7C001F
	global_load_b32 v23, v[31:32], off                         // 000000008784: DC520000 177C001F
	global_load_b32 v22, v[27:28], off offset:-4096            // 00000000878C: DC521000 167C001B
	global_load_b32 v21, v[27:28], off                         // 000000008794: DC520000 157C001B
	global_load_b32 v31, v[37:38], off offset:2048             // 00000000879C: DC520800 1F7C0025
	global_load_b32 v32, v[37:38], off offset:3072             // 0000000087A4: DC520C00 207C0025
	global_load_b32 v27, v[25:26], off offset:1024             // 0000000087AC: DC520400 1B7C0019
	global_load_b32 v28, v[25:26], off offset:2048             // 0000000087B4: DC520800 1C7C0019
	global_load_b32 v29, v[25:26], off offset:3072             // 0000000087BC: DC520C00 1D7C0019
	global_load_b32 v24, v[39:40], off offset:1024             // 0000000087C4: DC520400 187C0027
	global_load_b32 v25, v[39:40], off offset:2048             // 0000000087CC: DC520800 197C0027
	global_load_b32 v26, v[39:40], off offset:3072             // 0000000087D4: DC520C00 1A7C0027
	.long 0xd7006a25                                           // 0000000087DC: D7006A25
	v_cndmask_b32_e32 v1, 0x9000, v71, vcc_lo                  // 0000000087E0: 02028EFF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000087E8: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v72, vcc_lo              // 0000000087EC: D5207C26 01AA9080
	.long 0xd7006a2d                                           // 0000000087F4: D7006A2D
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000087F8: 0201FF47
	.long 0x0000a000                                           // 0000000087FC: 0000A000
	v_add_co_ci_u32_e64 v46, null, 0, v72, vcc_lo              // 000000008800: D5207C2E 01AA9080
	.long 0xd7006a2b                                           // 000000008808: D7006A2B
	v_cndmask_b32_e32 v1, 0xa000, v71, vcc_lo                  // 00000000880C: 02028EFF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008814: BF8700A1
	v_add_co_ci_u32_e64 v44, null, 0, v72, vcc_lo              // 000000008818: D5207C2C 01AA9080
	.long 0xd7006a33                                           // 000000008820: D7006A33
	v_cndmask_b32_e32 v1, 0xb000, v71, vcc_lo                  // 000000008824: 02028EFF 0000B000
	v_add_co_ci_u32_e64 v52, null, 0, v72, vcc_lo              // 00000000882C: D5207C34 01AA9080
	.long 0xd7006a35                                           // 000000008834: D7006A35
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000008838: 0201FF47
	.long 0x0000c000                                           // 00000000883C: 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000008840: BF870001
	v_add_co_ci_u32_e64 v54, null, 0, v72, vcc_lo              // 000000008844: D5207C36 01AA9080
	.long 0xd7006a3b                                           // 00000000884C: D7006A3B
	v_cndmask_b32_e32 v1, 0xc000, v71, vcc_lo                  // 000000008850: 02028EFF 0000C000
	s_mul_hi_i32 s4, s2, 0x55555556                            // 000000008858: 9704FF02 55555556
	v_add_co_ci_u32_e64 v60, null, 0, v72, vcc_lo              // 000000008860: D5207C3C 01AA9080
	.long 0xd7006a3d                                           // 000000008868: D7006A3D
	v_cndmask_b32_e32 v1, 0xd000, v71, vcc_lo                  // 00000000886C: 02028EFF 0000D000
	s_lshr_b32 s5, s4, 31                                      // 000000008874: 85059F04
	v_add_co_ci_u32_e64 v62, null, 0, v72, vcc_lo              // 000000008878: D5207C3E 01AA9080
	.long 0xd7006a37                                           // 000000008880: D7006A37
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000008884: 0201FF47
	.long 0x0000e000                                           // 000000008888: 0000E000
	s_add_i32 s4, s4, s5                                       // 00000000888C: 81040504
	v_mad_i64_i32 v[57:58], null, 0x5000, v47, s[8:9]          // 000000008890: D6FF7C39 00225EFF 00005000
	v_add_co_ci_u32_e64 v56, null, 0, v72, vcc_lo              // 00000000889C: D5207C38 01AA9080
	s_lshl_b32 s4, s4, 7                                       // 0000000088A4: 84048704
	s_clause 0x5                                               // 0000000088A8: BF850005
	global_load_b32 v50, v[45:46], off offset:-4096            // 0000000088AC: DC521000 327C002D
	global_load_b32 v49, v[45:46], off                         // 0000000088B4: DC520000 317C002D
	global_load_b32 v48, v[53:54], off offset:-4096            // 0000000088BC: DC521000 307C0035
	global_load_b32 v47, v[53:54], off                         // 0000000088C4: DC520000 2F7C0035
	global_load_b32 v46, v[55:56], off offset:-4096            // 0000000088CC: DC521000 2E7C0037
	global_load_b32 v45, v[55:56], off                         // 0000000088D4: DC520000 2D7C0037
	v_lshlrev_b32_e32 v53, 4, v0                               // 0000000088DC: 306A0084
	s_ashr_i32 s5, s4, 31                                      // 0000000088E0: 86059F04
	.long 0xd7006a3f                                           // 0000000088E4: D7006A3F
	v_cndmask_b32_e32 v1, 0xe000, v71, vcc_lo                  // 0000000088E8: 02028EFF 0000E000
	s_lshl_b64 s[14:15], s[4:5], 1                             // 0000000088F0: 848E8104
	v_add_co_ci_u32_e64 v64, null, 0, v72, vcc_lo              // 0000000088F4: D5207C40 01AA9080
	.long 0xd7006a41                                           // 0000000088FC: D7006A41
	v_cndmask_b32_e32 v0, v57, v14, vcc_lo                     // 000000008900: 02001D39
	v_and_b32_e32 v67, 0xf0, v53                               // 000000008904: 36866AFF 000000F0
	v_add_co_ci_u32_e64 v66, null, s15, v58, vcc_lo            // 00000000890C: D5207C42 01AA740F
	s_clause 0xf                                               // 000000008914: BF85000F
	global_load_b32 v40, v[37:38], off offset:1024             // 000000008918: DC520400 287C0025
	global_load_b32 v41, v[37:38], off offset:2048             // 000000008920: DC520800 297C0025
	global_load_b32 v42, v[37:38], off offset:3072             // 000000008928: DC520C00 2A7C0025
	global_load_b32 v37, v[43:44], off offset:1024             // 000000008930: DC520400 257C002B
	global_load_b32 v38, v[43:44], off offset:2048             // 000000008938: DC520800 267C002B
	global_load_b32 v39, v[43:44], off offset:3072             // 000000008940: DC520C00 277C002B
	global_load_b32 v43, v[51:52], off offset:1024             // 000000008948: DC520400 2B7C0033
	global_load_b32 v44, v[51:52], off offset:2048             // 000000008950: DC520800 2C7C0033
	global_load_b32 v58, v[51:52], off offset:3072             // 000000008958: DC520C00 3A7C0033
	global_load_b32 v55, v[59:60], off offset:1024             // 000000008960: DC520400 377C003B
	global_load_b32 v56, v[59:60], off offset:2048             // 000000008968: DC520800 387C003B
	global_load_b32 v57, v[59:60], off offset:3072             // 000000008970: DC520C00 397C003B
	global_load_b32 v52, v[61:62], off offset:1024             // 000000008978: DC520400 347C003D
	global_load_b32 v53, v[61:62], off offset:2048             // 000000008980: DC520800 357C003D
	global_load_b32 v54, v[61:62], off offset:3072             // 000000008988: DC520C00 367C003D
	global_load_b32 v51, v[63:64], off offset:1024             // 000000008990: DC520400 337C003F
	.long 0xd7006a41                                           // 000000008998: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 00000000899C: 02028741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000089A0: BF8700A1
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 0000000089A4: D5207C42 01AA8480
	.long 0xd7006a43                                           // 0000000089AC: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v71, vcc_lo                  // 0000000089B0: 02028EFF 0000F000
	v_add_co_ci_u32_e64 v68, null, 0, v72, vcc_lo              // 0000000089B8: D5207C44 01AA9080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000089C0: BF870094
	.long 0xd7006a45                                           // 0000000089C4: D7006A45
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 0000000089C8: 020282FF 00001000
	v_add_co_ci_u32_e64 v70, null, 0, v66, vcc_lo              // 0000000089D0: D5207C46 01AA8480
	s_clause 0x5                                               // 0000000089D8: BF850005
	global_load_b32 v74, v[63:64], off offset:2048             // 0000000089DC: DC520800 4A7C003F
	global_load_b32 v75, v[63:64], off offset:3072             // 0000000089E4: DC520C00 4B7C003F
	global_load_b32 v62, v[67:68], off                         // 0000000089EC: DC520000 3E7C0043
	global_load_b32 v61, v[67:68], off offset:1024             // 0000000089F4: DC520400 3D7C0043
	global_load_b32 v60, v[67:68], off offset:2048             // 0000000089FC: DC520800 3C7C0043
	global_load_b32 v59, v[67:68], off offset:3072             // 000000008A04: DC520C00 3B7C0043
	s_clause 0x1                                               // 000000008A0C: BF850001
	global_load_b128 v[63:66], v[65:66], off                   // 000000008A10: DC5E0000 3F7C0041
	global_load_b128 v[67:70], v[69:70], off                   // 000000008A18: DC5E0000 437C0045
	s_clause 0x3                                               // 000000008A20: BF850003
	global_load_b32 v1, v[71:72], off                          // 000000008A24: DC520000 017C0047
	global_load_b32 v2, v[71:72], off offset:1024              // 000000008A2C: DC520400 027C0047
	global_load_b32 v3, v[71:72], off offset:2048              // 000000008A34: DC520800 037C0047
	global_load_b32 v4, v[71:72], off offset:3072              // 000000008A3C: DC520C00 047C0047
	s_clause 0x1                                               // 000000008A44: BF850001
	s_load_b64 s[6:7], s[0:1], 0x80                            // 000000008A48: F4040180 F8000080
	s_load_b128 s[28:31], s[0:1], 0x70                         // 000000008A50: F4080700 F8000070
	s_mov_b32 s4, exec_lo                                      // 000000008A58: BE84007E
	.long 0xd4c3007e                                           // 000000008A5C: D4C3007E
	v_cndmask_b32_e32 v1, s33, v76, vcc_lo                     // 000000008A60: 02029821
	s_cbranch_execz 11                                         // 000000008A64: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x594>
	s_waitcnt vmcnt(5)                                         // 000000008A68: BF8917F7
	v_mov_b32_e32 v66, 0                                       // 000000008A6C: 7E840280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000008A70: BF870001
	v_mov_b32_e32 v65, v66                                     // 000000008A74: 7E820342
	v_mov_b32_e32 v64, v66                                     // 000000008A78: 7E800342
	v_mov_b32_e32 v63, v66                                     // 000000008A7C: 7E7E0342
	s_waitcnt vmcnt(4)                                         // 000000008A80: BF8913F7
	v_mov_b32_e32 v70, v66                                     // 000000008A84: 7E8C0342
	v_mov_b32_e32 v69, v66                                     // 000000008A88: 7E8A0342
	v_mov_b32_e32 v68, v66                                     // 000000008A8C: 7E880342
	v_mov_b32_e32 v67, v66                                     // 000000008A90: 7E860342
	s_or_b32 exec_lo, exec_lo, s4                              // 000000008A94: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 000000008A98: 7C980090
	.long 0xd4440004                                           // 000000008A9C: D4440004
	v_cndmask_b32_e32 v1, s33, v0, vcc_lo                      // 000000008AA0: 02020021
	v_mov_b32_e32 v138, 0                                      // 000000008AA4: 7F140280
	s_and_b32 s5, vcc_lo, s4                                   // 000000008AA8: 8B05046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000008AAC: BF870009
	s_and_saveexec_b32 s4, s5                                  // 000000008AB0: BE842005
	s_cbranch_execz 27                                         // 000000008AB4: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x624>
	v_mul_u32_u24_e32 v73, 0xc0, v0                            // 000000008AB8: 169200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 000000008AC0: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000008AC4: BF870091
	.long 0xd700054c                                           // 000000008AC8: D700054C
	v_cndmask_b32_e32 v1, s10, v73, vcc_lo                     // 000000008ACC: 0202920A
	v_add_co_ci_u32_e64 v77, null, s11, 0, s5                  // 000000008AD0: D5207C4D 0015000B
	.long 0xd7000549                                           // 000000008AD8: D7000549
	v_cndmask_b32_e32 v1, s12, v73, vcc_lo                     // 000000008ADC: 0202920C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000008AE0: BF870211
	v_add_co_ci_u32_e64 v79, null, s13, 0, s5                  // 000000008AE4: D5207C4F 0015000D
	.long 0xd7006a4c                                           // 000000008AEC: D7006A4C
	v_cndmask_b32_e32 v0, v76, v16, vcc_lo                     // 000000008AF0: 0200214C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000008AF4: BF870211
	v_add_co_ci_u32_e64 v77, null, s17, v77, vcc_lo            // 000000008AF8: D5207C4D 01AA9A11
	.long 0xd7006a4e                                           // 000000008B00: D7006A4E
	v_cndmask_b32_e32 v0, v73, v16, vcc_lo                     // 000000008B04: 02002149
	s_delay_alu instid0(VALU_DEP_1)                            // 000000008B08: BF870001
	v_add_co_ci_u32_e64 v79, null, s17, v79, vcc_lo            // 000000008B0C: D5207C4F 01AA9E11
	global_load_b32 v138, v[76:77], off                        // 000000008B14: DC520000 8A7C004C
	global_load_b32 v73, v[78:79], off                         // 000000008B1C: DC520000 497C004E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000008B24: 8C7E047E
	s_add_i32 s4, s33, 15                                      // 000000008B28: 81048F21
	s_waitcnt vmcnt(2)                                         // 000000008B2C: BF890BF7
	v_dual_mul_f32 v137, 0x43800000, v1 :: v_dual_mul_f32 v136, 0x43800000, v2// 000000008B30: C8C602FF 898804FF 43800000
	s_ashr_i32 s5, s4, 31                                      // 000000008B3C: 86059F04
	s_waitcnt vmcnt(0)                                         // 000000008B40: BF8903F7
	v_dual_mul_f32 v135, 0x43800000, v3 :: v_dual_mul_f32 v134, 0x43800000, v4// 000000008B44: C8C606FF 878608FF 43800000
	s_lshr_b32 s5, s5, 28                                      // 000000008B50: 85059C05
	v_dual_mul_f32 v133, 0x43800000, v36 :: v_dual_mul_f32 v130, 0x43800000, v35// 000000008B54: C8C648FF 858246FF 43800000
	v_dual_mul_f32 v132, 0x43800000, v8 :: v_dual_mul_f32 v131, 0x43800000, v9// 000000008B60: C8C610FF 848212FF 43800000
	v_dual_mul_f32 v155, 0x43800000, v10 :: v_dual_mul_f32 v124, 0x43800000, v12// 000000008B6C: C8C614FF 9B7C18FF 43800000
	v_dual_mul_f32 v129, 0x43800000, v5 :: v_dual_mul_f32 v128, 0x43800000, v6// 000000008B78: C8C60AFF 81800CFF 43800000
	v_dual_mul_f32 v127, 0x43800000, v7 :: v_dual_mul_f32 v126, 0x43800000, v34// 000000008B84: C8C60EFF 7F7E44FF 43800000
	v_dual_mul_f32 v125, 0x43800000, v11 :: v_dual_mul_f32 v122, 0x43800000, v16// 000000008B90: C8C616FF 7D7A20FF 43800000
	v_dual_mul_f32 v154, 0x43800000, v19 :: v_dual_mul_f32 v123, 0x43800000, v33// 000000008B9C: C8C626FF 9A7A42FF 43800000
	v_dual_mul_f32 v121, 0x43800000, v17 :: v_dual_mul_f32 v120, 0x43800000, v18// 000000008BA8: C8C622FF 797824FF 43800000
	v_dual_mul_f32 v119, 0x43800000, v30 :: v_dual_mul_f32 v118, 0x43800000, v13// 000000008BB4: C8C63CFF 77761AFF 43800000
	v_dual_mul_f32 v117, 0x43800000, v14 :: v_dual_mul_f32 v116, 0x43800000, v23// 000000008BC0: C8C61CFF 75742EFF 43800000
	v_dual_mul_f32 v153, 0x43800000, v15 :: v_dual_mul_f32 v112, 0x43800000, v22// 000000008BCC: C8C61EFF 99702CFF 43800000
	v_dual_mul_f32 v115, 0x43800000, v20 :: v_dual_mul_f32 v114, 0x43800000, v31// 000000008BD8: C8C628FF 73723EFF 43800000
	v_dual_mul_f32 v113, 0x43800000, v32 :: v_dual_mul_f32 v152, 0x43800000, v29// 000000008BE4: C8C640FF 71983AFF 43800000
	v_dual_mul_f32 v111, 0x43800000, v27 :: v_dual_mul_f32 v110, 0x43800000, v28// 000000008BF0: C8C636FF 6F6E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v21 :: v_dual_mul_f32 v108, 0x43800000, v24// 000000008BFC: C8C62AFF 6D6C30FF 43800000
	v_dual_mul_f32 v107, 0x43800000, v25 :: v_dual_mul_f32 v106, 0x43800000, v26// 000000008C08: C8C632FF 6B6A34FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v50 :: v_dual_mul_f32 v104, 0x43800000, v40// 000000008C14: C8C664FF 696850FF 43800000
	v_dual_mul_f32 v103, 0x43800000, v41 :: v_dual_mul_f32 v100, 0x43800000, v38// 000000008C20: C8C652FF 67644CFF 43800000
	v_dual_mul_f32 v151, 0x43800000, v42 :: v_dual_mul_f32 v102, 0x43800000, v49// 000000008C2C: C8C654FF 976662FF 43800000
	v_dual_mul_f32 v101, 0x43800000, v37 :: v_dual_mul_f32 v98, 0x43800000, v48// 000000008C38: C8C64AFF 656260FF 43800000
	v_dual_mul_f32 v99, 0x43800000, v39 :: v_dual_mul_f32 v96, 0x43800000, v44// 000000008C44: C8C64EFF 636058FF 43800000
	v_dual_mul_f32 v97, 0x43800000, v43 :: v_dual_mul_f32 v150, 0x43800000, v58// 000000008C50: C8C656FF 619674FF 43800000
	v_dual_mul_f32 v95, 0x43800000, v47 :: v_dual_mul_f32 v92, 0x43800000, v57// 000000008C5C: C8C65EFF 5F5C72FF 43800000
	v_dual_mul_f32 v94, 0x43800000, v55 :: v_dual_mul_f32 v93, 0x43800000, v56// 000000008C68: C8C66EFF 5E5C70FF 43800000
	v_dual_mul_f32 v91, 0x43800000, v46 :: v_dual_mul_f32 v90, 0x43800000, v52// 000000008C74: C8C65CFF 5B5A68FF 43800000
	v_dual_mul_f32 v89, 0x43800000, v53 :: v_dual_mul_f32 v86, 0x43800000, v51// 000000008C80: C8C66AFF 595666FF 43800000
	v_dual_mul_f32 v149, 0x43800000, v54 :: v_dual_mul_f32 v82, 0x43800000, v75// 000000008C8C: C8C66CFF 955296FF 43800000
	v_dual_mul_f32 v87, 0x43800000, v45 :: v_dual_mul_f32 v88, 0x43800000, v62// 000000008C98: C8C65AFF 57587CFF 43800000
	v_dual_mul_f32 v85, 0x43800000, v74 :: v_dual_mul_f32 v84, 0x43800000, v60// 000000008CA4: C8C694FF 555478FF 43800000
	v_dual_mul_f32 v83, 0x43800000, v61 :: v_dual_mul_f32 v148, 0x43800000, v59// 000000008CB0: C8C67AFF 539476FF 43800000
	s_add_i32 s4, s4, s5                                       // 000000008CBC: 81040504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000008CC0: BF870009
	s_ashr_i32 s42, s4, 4                                      // 000000008CC4: 862A8404
	s_cmp_lt_i32 s33, 1                                        // 000000008CC8: BF048121
	s_cbranch_scc1 5486                                        // 000000008CCC: BFA2156E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5d88>
	s_add_u32 s34, s8, s14                                     // 000000008CD0: 80220E08
	s_addc_u32 s35, s9, s15                                    // 000000008CD4: 82230F09
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000008CD8: 84848202
	s_movk_i32 s20, 0x7040                                     // 000000008CDC: B0147040
	s_add_u32 s10, s10, s4                                     // 000000008CE0: 800A040A
	s_addc_u32 s11, s11, s5                                    // 000000008CE4: 820B050B
	s_add_u32 s36, s12, s4                                     // 000000008CE8: 8024040C
	s_addc_u32 s37, s13, s5                                    // 000000008CEC: 8225050D
	s_lshl_b32 s4, s2, 7                                       // 000000008CF0: 84048702
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000008CF4: F40C0300 F8000048
	s_ashr_i32 s5, s4, 31                                      // 000000008CFC: 86059F04
	s_cmp_lg_u32 s40, 0                                        // 000000008D00: BF078028
	s_load_b64 s[0:1], s[0:1], 0x68                            // 000000008D04: F4040000 F8000068
	s_cselect_b32 s45, -1, 0                                   // 000000008D0C: 982D80C1
	s_cmp_gt_u32 s41, 63                                       // 000000008D10: BF08BF29
	.long 0xd71f008c                                           // 000000008D14: D71F008C
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000008D18: 020100C1
	s_cselect_b32 s46, -1, 0                                   // 000000008D1C: 982E80C1
	s_cmp_eq_u32 s40, 0                                        // 000000008D20: BF068028
	v_rsq_f32_e32 v139, 0x43000000                             // 000000008D24: 7F165CFF 43000000
	s_cselect_b32 s3, -1, 0                                    // 000000008D2C: 980380C1
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v2, 16, v140        // 000000008D30: CA240080 01031890
	s_waitcnt lgkmcnt(0)                                       // 000000008D38: BF89FC07
	s_and_b32 s15, s3, exec_lo                                 // 000000008D3C: 8B0F7E03
	s_cselect_b32 s15, s20, 0x7080                             // 000000008D40: 980FFF14 00007080
	s_lshl_b64 s[38:39], s[4:5], 1                             // 000000008D48: 84A68104
	s_add_i32 s4, s40, -3                                      // 000000008D4C: 8104C328
	s_add_u32 s47, s30, s38                                    // 000000008D50: 802F261E
	s_addc_u32 s48, s31, s39                                   // 000000008D54: 8230271F
	s_add_i32 s5, s40, 2                                       // 000000008D58: 81058228
	s_add_i32 s21, s40, 7                                      // 000000008D5C: 81158728
	s_cmp_eq_u32 s40, 2                                        // 000000008D60: BF068228
	v_dual_mov_b32 v74, 0 :: v_dual_add_nc_u32 v141, 16, v2    // 000000008D64: CA200080 4A8C0490
	s_cselect_b32 s49, -1, 0                                   // 000000008D6C: 983180C1
	v_xor_b32_e32 v142, 1, v140                                // 000000008D70: 3B1D1881
	s_and_b32 s24, s49, exec_lo                                // 000000008D74: 8B187E31
	s_cselect_b32 s50, 15, s4                                  // 000000008D78: 9832048F
	s_cselect_b32 s51, 15, s5                                  // 000000008D7C: 9833058F
	s_cselect_b32 s52, 15, s21                                 // 000000008D80: 9834158F
	s_add_u32 s53, s6, s38                                     // 000000008D84: 80352606
	s_addc_u32 s54, s7, s39                                    // 000000008D88: 82362707
	s_max_i32 s55, s42, 1                                      // 000000008D8C: 8A37812A
	s_add_u32 s16, s16, s22                                    // 000000008D90: 80101610
	s_addc_u32 s17, s17, s23                                   // 000000008D94: 82111711
	s_add_u32 s18, s18, s22                                    // 000000008D98: 80121612
	v_xor_b32_e32 v143, 2, v140                                // 000000008D9C: 3B1F1882
	v_xor_b32_e32 v144, 4, v140                                // 000000008DA0: 3B211884
	v_xor_b32_e32 v145, 8, v140                                // 000000008DA4: 3B231888
	v_dual_mov_b32 v146, 0x1000504 :: v_dual_mov_b32 v75, v1   // 000000008DA8: CA1000FF 924A0101 01000504
	v_mov_b32_e32 v147, 0x3020706                              // 000000008DB4: 7F2602FF 03020706
	s_mov_b32 s20, 0                                           // 000000008DBC: BE940080
	s_addc_u32 s19, s19, s23                                   // 000000008DC0: 82131713
	s_add_u32 s56, s0, s22                                     // 000000008DC4: 80381600
	s_addc_u32 s57, s1, s23                                    // 000000008DC8: 82391701
	s_mov_b32 s58, 0x41800000                                  // 000000008DCC: BEBA00FF 41800000
	s_movk_i32 s59, 0x1800                                     // 000000008DD4: B03B1800
	s_movk_i32 s60, 0x3a00                                     // 000000008DD8: B03C3A00
	s_mov_b32 s61, 0x76543210                                  // 000000008DDC: BEBD00FF 76543210
	s_mov_b32 s21, s20                                         // 000000008DE4: BE950014
	s_mov_b32 s22, s20                                         // 000000008DE8: BE960014
	s_mov_b32 s23, s20                                         // 000000008DEC: BE970014
	s_mov_b32 s24, s20                                         // 000000008DF0: BE980014
	s_mov_b32 s25, s20                                         // 000000008DF4: BE990014
	s_mov_b32 s26, s20                                         // 000000008DF8: BE9A0014
	s_mov_b32 s27, s20                                         // 000000008DFC: BE9B0014
	s_mov_b32 s62, 0x3d800000                                  // 000000008E00: BEBE00FF 3D800000
	s_mov_b32 s4, s20                                          // 000000008E08: BE840014
	s_branch 11                                                // 000000008E0C: BFA0000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x93c>
	v_dual_mov_b32 v148, v41 :: v_dual_mov_b32 v155, v54       // 000000008E10: CA100129 949A0136
	v_dual_mov_b32 v149, v45 :: v_dual_mov_b32 v154, v46       // 000000008E18: CA10012D 959A012E
	v_mov_b32_e32 v150, v33                                    // 000000008E20: 7F2C0321
	v_mov_b32_e32 v151, v9                                     // 000000008E24: 7F2E0309
	v_mov_b32_e32 v152, v17                                    // 000000008E28: 7F300311
	v_mov_b32_e32 v153, v25                                    // 000000008E2C: 7F320319
	s_cmp_eq_u32 s63, s55                                      // 000000008E30: BF06373F
	s_mov_b32 s4, s63                                          // 000000008E34: BE84003F
	s_cbranch_scc1 5403                                        // 000000008E38: BFA2151B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5da8>
	v_mov_b32_e32 v45, v0                                      // 000000008E3C: 7E5A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000008E40: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v45                               // 000000008E44: 34045A84
	v_and_b32_e32 v34, 15, v45                                 // 000000008E48: 36445A8F
	.long 0xd4440000                                           // 000000008E4C: D4440000
	v_cndmask_b32_e32 v1, 16, v45, vcc_lo                      // 000000008E50: 02025A90
	.long 0xd72c0003                                           // 000000008E54: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000008E58: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000008E60: BF870001
	v_lshl_add_u32 v3, v34, 4, v3                              // 000000008E64: D6460003 040D0922
	ds_store_b128 v3, v[63:66] offset:14848                    // 000000008E6C: DB7C3A00 00003F03
	ds_store_b128 v3, v[67:70] offset:6144                     // 000000008E74: DB7C1800 00004303
	s_and_saveexec_b32 s1, s0                                  // 000000008E7C: BE812000
	v_lshlrev_b32_e32 v3, 2, v45                               // 000000008E80: 30065A82
	ds_store_b32 v3, v73 offset:28416                          // 000000008E84: D8346F00 00004903
	s_or_b32 exec_lo, exec_lo, s1                              // 000000008E8C: 8C7E017E
	v_and_b32_e32 v35, 1, v45                                  // 000000008E90: 36465A81
	s_lshl_b32 s64, s4, 4                                      // 000000008E94: 84408404
	v_or_b32_e32 v156, s43, v34                                // 000000008E98: 3938442B
	s_mov_b32 s5, exec_lo                                      // 000000008E9C: BE85007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000008EA0: BF870112
	v_or_b32_e32 v15, s64, v35                                 // 000000008EA4: 381E4640
	v_and_b32_e32 v6, 0x7ffffffe, v156                         // 000000008EA8: 360D38FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000008EB0: BF870232
	v_min_i32_e32 v3, s44, v15                                 // 000000008EB4: 22061E2C
	v_or_b32_e32 v5, 2, v15                                    // 000000008EB8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 000000008EBC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 000000008EC0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 000000008EC4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 000000008EC8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s44, v5                                  // 000000008ED4: 220A0A2C
	v_min_i32_e32 v7, s44, v7                                  // 000000008ED8: 220E0E2C
	v_or_b32_e32 v17, 12, v15                                  // 000000008EDC: 38221E8C
	v_min_i32_e32 v8, s44, v8                                  // 000000008EE0: 2210102C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008EE4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 000000008EE8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000008EF4: D7006A09
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 000000008EF8: 02004D03
	v_add_co_ci_u32_e64 v10, null, s39, v4, vcc_lo             // 000000008EFC: D5207C0A 01AA0827
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000008F04: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000008F10: BF870093
	.long 0xd7006a07                                           // 000000008F14: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000008F18: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 000000008F1C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000008F24: D7006A0A
	v_cndmask_b32_e32 v0, v5, v38, vcc_lo                      // 000000008F28: 02004D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000008F2C: BF870211
	v_add_co_ci_u32_e64 v11, null, s39, v6, vcc_lo             // 000000008F30: D5207C0B 01AA0C27
	.long 0xd7006a05                                           // 000000008F38: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000008F3C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000008F44: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000008F48: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000008F50: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000008F54: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008F58: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 000000008F5C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000008F64: D7006A0A
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 000000008F68: 02004D03
	v_add_co_ci_u32_e64 v11, null, s39, v4, vcc_lo             // 000000008F6C: D5207C0B 01AA0827
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000008F74: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000008F80: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000008F84: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008F8C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000008F90: D5207C08 01AA1280
	.long 0xd7006a09                                           // 000000008F98: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000008F9C: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 000000008FA0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 000000008FA8: 38161E88
	.long 0xd7006a03                                           // 000000008FAC: D7006A03
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 000000008FB0: 02004D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000008FB4: BF870191
	v_add_co_ci_u32_e64 v4, null, s39, v4, vcc_lo              // 000000008FB8: D5207C04 01AA0827
	v_min_i32_e32 v11, s44, v11                                // 000000008FC0: 2216162C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000008FC4: BF870093
	.long 0xd7006a0c                                           // 000000008FC8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000008FCC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000008FD0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000008FD8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 000000008FDC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 000000008FE8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 000000008FEC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000008FF4: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 000000008FFC: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000009000: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000009008: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000000900C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000009014: 381A1E8A
	.long 0xd7006a03                                           // 000000009018: D7006A03
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 00000000901C: 02004D03
	v_add_co_ci_u32_e64 v4, null, s39, v4, vcc_lo              // 000000009020: D5207C04 01AA0827
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000009028: BF870193
	v_min_i32_e32 v13, s44, v13                                // 00000000902C: 221A1A2C
	.long 0xd7006a0e                                           // 000000009030: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000009034: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000009038: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000000903C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000009044: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000009050: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009054: BF870094
	.long 0xd7006a0d                                           // 000000009058: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000000905C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000009064: D5207C0E 01AA2080
	v_min_i32_e32 v16, s44, v17                                // 00000000906C: 2220222C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000009070: BF8700A4
	v_min_i32_e32 v15, s44, v15                                // 000000009074: 221E1E2C
	.long 0xd7006a11                                           // 000000009078: D7006A11
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 00000000907C: 02004D03
	v_add_co_ci_u32_e64 v18, null, s39, v4, vcc_lo             // 000000009080: D5207C12 01AA0827
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000009088: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000000908C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 000000009098: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000000909C: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 0000000090A0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000090AC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000090B0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 0000000090B8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 0000000090BC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000090C4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000090C8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 0000000090D0: D7006A03
	v_cndmask_b32_e32 v0, v3, v38, vcc_lo                      // 0000000090D4: 02004D03
	v_add_co_ci_u32_e64 v4, null, s39, v4, vcc_lo              // 0000000090D8: D5207C04 01AA0827
	.long 0xd7006a0f                                           // 0000000090E0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v38, vcc_lo                     // 0000000090E4: 02004D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000090E8: BF870211
	v_add_co_ci_u32_e64 v16, null, s39, v16, vcc_lo            // 0000000090EC: D5207C10 01AA2027
	.long 0xd7006a03                                           // 0000000090F4: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 0000000090F8: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000090FC: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000009100: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000009108: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000000910C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009110: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000009114: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000000911C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000009120: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009128: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000000912C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000009134: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000009138: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009140: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000009144: D5207C10 01AA2080
	s_clause 0x7                                               // 00000000914C: BF850007
	global_load_b32 v43, v[5:6], off                           // 000000009150: DC520000 2B7C0005
	global_load_b32 v42, v[7:8], off                           // 000000009158: DC520000 2A7C0007
	global_load_b32 v41, v[9:10], off                          // 000000009160: DC520000 297C0009
	global_load_b32 v40, v[11:12], off                         // 000000009168: DC520000 287C000B
	global_load_b32 v39, v[13:14], off                         // 000000009170: DC520000 277C000D
	global_load_b32 v38, v[17:18], off                         // 000000009178: DC520000 267C0011
	global_load_b32 v36, v[3:4], off                           // 000000009180: DC520000 247C0003
	global_load_b32 v37, v[15:16], off                         // 000000009188: DC520000 257C000F
	v_lshlrev_b32_e32 v9, 16, v65                              // 000000009190: 30128290
	v_lshlrev_b32_e32 v5, 16, v67                              // 000000009194: 300A8690
	v_and_b32_e32 v4, 0xffff0000, v63                          // 000000009198: 36087EFF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v69                             // 0000000091A0: 30188A90
	v_and_b32_e32 v11, 0xffff0000, v66                         // 0000000091A4: 361684FF FFFF0000
	v_cmp_lt_u32_e32 vcc_lo, v142, v141                        // 0000000091AC: 7C931B8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000091B0: BF870134
	v_dual_mul_f32 v5, v5, v5 :: v_dual_mul_f32 v4, v4, v4     // 0000000091B4: C8C60B05 05040904
	v_and_b32_e32 v6, 0xffff0000, v67                          // 0000000091BC: 360C86FF FFFF0000
	v_dual_mul_f32 v12, v12, v12 :: v_dual_lshlrev_b32 v3, 16, v63// 0000000091C4: C8E2190C 0C027E90
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v13, 0xffff0000, v69// 0000000091CC: C8E40D06 060C8AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000091D8: BF8701A2
	v_mul_f32_e32 v3, v3, v3                                   // 0000000091DC: 10060703
	v_lshlrev_b32_e32 v7, 16, v64                              // 0000000091E0: 300E8090
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v64// 0000000091E4: C8E41B0D 0D0880FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000091F0: BF870193
	v_dual_add_f32 v3, v3, v4 :: v_dual_and_b32 v14, 0xffff0000, v70// 0000000091F4: C9240903 030E8CFF FFFF0000
	v_dual_add_f32 v4, v5, v6 :: v_dual_mul_f32 v5, v7, v7     // 000000009200: C9060D05 04040F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009208: BF870123
	v_mul_f32_e32 v6, v8, v8                                   // 00000000920C: 100C1108
	v_lshlrev_b32_e32 v7, 16, v68                              // 000000009210: 300E8890
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v8, 0xffff0000, v68// 000000009214: C9240D05 050888FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v65                         // 000000009220: 361482FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009228: BF870112
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000000922C: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000009234: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v66                             // 00000000923C: 30148490
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000009240: BF8701A3
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 000000009244: C9080F06 06061B0C
	v_add_f32_e32 v3, v3, v5                                   // 00000000924C: 06060B03
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000009250: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v70// 000000009258: C8E2170B 0A0A8C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009260: BF870114
	v_add_f32_e32 v4, v4, v6                                   // 000000009264: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 000000009268: C9061509 090A170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000009270: BF870241
	v_add_f32_e32 v5, v8, v9                                   // 000000009274: 060A1308
	v_cndmask_b32_e32 v9, v140, v142, vcc_lo                   // 000000009278: 02131D8C
	v_mul_f32_e32 v11, v14, v14                                // 00000000927C: 10161D0E
	v_cmp_lt_u32_e32 vcc_lo, v143, v141                        // 000000009280: 7C931B8F
	v_add_f32_e32 v3, v3, v5                                   // 000000009284: 06060B03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009288: BF870214
	v_lshlrev_b32_e32 v6, 2, v9                                // 00000000928C: 300C1282
	v_add_f32_e32 v8, v10, v11                                 // 000000009290: 0610170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000009294: BF8701B1
	v_add_f32_e32 v5, v7, v8                                   // 000000009298: 060A1107
	v_cndmask_b32_e32 v7, v140, v143, vcc_lo                   // 00000000929C: 020F1F8C
	v_cmp_lt_u32_e32 vcc_lo, v144, v141                        // 0000000092A0: 7C931B90
	v_add_f32_e32 v4, v4, v5                                   // 0000000092A4: 06080B04
	ds_bpermute_b32 v5, v6, v3                                 // 0000000092A8: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000092B0: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 0000000092B8: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000000092BC: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 0000000092C4: 300A0E82
	v_cndmask_b32_e32 v7, v140, v144, vcc_lo                   // 0000000092C8: 020F218C
	v_cmp_lt_u32_e32 vcc_lo, v145, v141                        // 0000000092CC: 7C931B91
	ds_bpermute_b32 v6, v5, v3                                 // 0000000092D0: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 0000000092D8: DACC0000 05000405
	s_waitcnt lgkmcnt(0)                                       // 0000000092E0: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 0000000092E4: C9080D03 03040B04
	v_dual_cndmask_b32 v7, v140, v145 :: v_dual_lshlrev_b32 v6, 2, v7// 0000000092EC: CA63238C 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 0000000092F4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000092FC: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000009304: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000009308: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000000930C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000009314: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000000931C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v34                                   // 000000009324: 7D944480
	s_cbranch_execz 38                                         // 000000009328: BFA50026 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xec4>
	s_waitcnt lgkmcnt(0)                                       // 00000000932C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000009330: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009338: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000000933C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000009348: C8C606FF 050608FF 4B800000
	.long 0xd4140001                                           // 000000009354: D4140001
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 000000009358: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 000000009360: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009368: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s1                           // 00000000936C: D5010004 00060D04
	v_rsq_f32_e32 v4, v4                                       // 000000009374: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009378: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000000937C: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 000000009388: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000938C: BF870291
	v_cndmask_b32_e64 v4, v4, v6, s1                           // 000000009390: D5010004 00060D04
	v_mul_f32_e32 v5, 0x45800000, v3                           // 000000009398: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000093A0: BF870121
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 0000000093A4: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 0000000093A8: 300A0482
	v_mul_f32_e32 v3, v139, v3                                 // 0000000093AC: 1006078B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000093B0: BF870002
	v_add_nc_u32_e32 v5, 0x7000, v5                            // 0000000093B4: 4A0A0AFF 00007000
	ds_store_2addr_b32 v5, v4, v3 offset0:16 offset1:32        // 0000000093BC: D8382010 00030405
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000093C4: 8C7E057E
	v_and_b32_e32 v44, 31, v45                                 // 0000000093C8: 36585A9F
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 0000000093CC: 916A037E
	s_cbranch_vccnz 119                                        // 0000000093D0: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10b0>
	.long 0xd760004e                                           // 0000000093D4: D760004E
	v_cndmask_b32_e32 v0, v138, v128, vcc_lo                   // 0000000093D8: 0201018A
	.long 0xd760004d                                           // 0000000093DC: D760004D
	v_cndmask_b32_e32 v0, v138, v129, vcc_lo                   // 0000000093E0: 0201038A
	.long 0xd760004c                                           // 0000000093E4: D760004C
	v_cndmask_b32_e32 v0, v138, v130, vcc_lo                   // 0000000093E8: 0201058A
	.long 0xd760004b                                           // 0000000093EC: D760004B
	v_cndmask_b32_e32 v0, v138, v131, vcc_lo                   // 0000000093F0: 0201078A
	.long 0xd760004a                                           // 0000000093F4: D760004A
	v_cndmask_b32_e32 v0, v138, v132, vcc_lo                   // 0000000093F8: 0201098A
	.long 0xd7600049                                           // 0000000093FC: D7600049
	v_cndmask_b32_e32 v0, v138, v133, vcc_lo                   // 000000009400: 02010B8A
	.long 0xd7600048                                           // 000000009404: D7600048
	v_cndmask_b32_e32 v0, v138, v134, vcc_lo                   // 000000009408: 02010D8A
	.long 0xd7600047                                           // 00000000940C: D7600047
	v_cndmask_b32_e32 v0, v138, v135, vcc_lo                   // 000000009410: 02010F8A
	.long 0xd7600046                                           // 000000009414: D7600046
	v_cndmask_b32_e32 v0, v138, v136, vcc_lo                   // 000000009418: 0201118A
	.long 0xd7600045                                           // 00000000941C: D7600045
	v_cndmask_b32_e32 v0, v138, v137, vcc_lo                   // 000000009420: 0201138A
	.long 0xd7600044                                           // 000000009424: D7600044
	v_cndmask_b32_e32 v0, v138, v138, vcc_lo                   // 000000009428: 0201158A
	.long 0xd7600043                                           // 00000000942C: D7600043
	v_cndmask_b32_e32 v0, v138, v139, vcc_lo                   // 000000009430: 0201178A
	.long 0xd7600042                                           // 000000009434: D7600042
	v_cndmask_b32_e32 v0, v138, v140, vcc_lo                   // 000000009438: 0201198A
	.long 0xd7600041                                           // 00000000943C: D7600041
	v_cndmask_b32_e32 v0, v138, v141, vcc_lo                   // 000000009440: 02011B8A
	.long 0xd760003f                                           // 000000009444: D760003F
	v_cndmask_b32_e32 v0, v138, v142, vcc_lo                   // 000000009448: 02011D8A
	.long 0xd7600005                                           // 00000000944C: D7600005
	v_cndmask_b32_e32 v0, v138, v143, vcc_lo                   // 000000009450: 02011F8A
	s_mov_b32 s1, exec_lo                                      // 000000009454: BE81007E
	v_cmpx_gt_u32_e32 16, v44                                  // 000000009458: 7D985890
	s_cbranch_execz 83                                         // 00000000945C: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10ac>
	v_cmp_eq_u32_e32 vcc_lo, 0, v44                            // 000000009460: 7C945880
	s_add_f32 s78, s78, 0                                      // 000000009464: A04E804E
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000009468: 30085882
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000000946C: BF8704BA
	s_add_f32 s77, s78, s77                                    // 000000009470: A04D4D4E
	v_cndmask_b32_e64 v3, 0, s78, vcc_lo                       // 000000009474: D5010003 01A89C80
	v_cmp_eq_u32_e32 vcc_lo, 1, v44                            // 00000000947C: 7C945881
	s_add_f32 s76, s77, s76                                    // 000000009480: A04C4C4D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009484: BF8704A2
	v_cndmask_b32_e64 v3, v3, s77, vcc_lo                      // 000000009488: D5010003 01A89B03
	v_cmp_eq_u32_e32 vcc_lo, 2, v44                            // 000000009490: 7C945882
	s_add_f32 s75, s76, s75                                    // 000000009494: A04B4B4C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009498: BF8704A2
	v_cndmask_b32_e64 v3, v3, s76, vcc_lo                      // 00000000949C: D5010003 01A89903
	v_cmp_eq_u32_e32 vcc_lo, 3, v44                            // 0000000094A4: 7C945883
	s_add_f32 s74, s75, s74                                    // 0000000094A8: A04A4A4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000094AC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s75, vcc_lo                      // 0000000094B0: D5010003 01A89703
	v_cmp_eq_u32_e32 vcc_lo, 4, v44                            // 0000000094B8: 7C945884
	s_add_f32 s73, s74, s73                                    // 0000000094BC: A049494A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000094C0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s74, vcc_lo                      // 0000000094C4: D5010003 01A89503
	v_cmp_eq_u32_e32 vcc_lo, 5, v44                            // 0000000094CC: 7C945885
	s_add_f32 s72, s73, s72                                    // 0000000094D0: A0484849
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000094D4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s73, vcc_lo                      // 0000000094D8: D5010003 01A89303
	v_cmp_eq_u32_e32 vcc_lo, 6, v44                            // 0000000094E0: 7C945886
	s_add_f32 s71, s72, s71                                    // 0000000094E4: A0474748
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000094E8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s72, vcc_lo                      // 0000000094EC: D5010003 01A89103
	v_cmp_eq_u32_e32 vcc_lo, 7, v44                            // 0000000094F4: 7C945887
	s_add_f32 s70, s71, s70                                    // 0000000094F8: A0464647
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000094FC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s71, vcc_lo                      // 000000009500: D5010003 01A88F03
	v_cmp_eq_u32_e32 vcc_lo, 8, v44                            // 000000009508: 7C945888
	s_add_f32 s69, s70, s69                                    // 00000000950C: A0454546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009510: BF8704A2
	v_cndmask_b32_e64 v3, v3, s70, vcc_lo                      // 000000009514: D5010003 01A88D03
	v_cmp_eq_u32_e32 vcc_lo, 9, v44                            // 00000000951C: 7C945889
	s_add_f32 s68, s69, s68                                    // 000000009520: A0444445
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009524: BF8704A2
	v_cndmask_b32_e64 v3, v3, s69, vcc_lo                      // 000000009528: D5010003 01A88B03
	v_cmp_eq_u32_e32 vcc_lo, 10, v44                           // 000000009530: 7C94588A
	s_add_f32 s67, s68, s67                                    // 000000009534: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009538: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 00000000953C: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 11, v44                           // 000000009544: 7C94588B
	s_add_f32 s66, s67, s66                                    // 000000009548: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000954C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 000000009550: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 12, v44                           // 000000009558: 7C94588C
	s_add_f32 s65, s66, s65                                    // 00000000955C: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009560: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 000000009564: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 13, v44                           // 00000000956C: 7C94588D
	s_add_f32 s63, s65, s63                                    // 000000009570: A03F3F41
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000009574: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 000000009578: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 14, v44                           // 000000009580: 7C94588E
	s_add_f32 s5, s63, s5                                      // 000000009584: A005053F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000009588: BF870002
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000000958C: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v44                           // 000000009594: 7C94588F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000009598: BF870482
	v_cndmask_b32_e64 v3, v3, s5, vcc_lo                       // 00000000959C: D5010003 01A80B03
	ds_store_b32 v4, v3 offset:28480                           // 0000000095A4: D8346F40 00000304
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000095AC: 8C7E017E
	s_add_i32 s63, s4, 1                                       // 0000000095B0: 813F8104
	s_waitcnt lgkmcnt(0)                                       // 0000000095B4: BF89FC07
	s_barrier                                                  // 0000000095B8: BFBD0000
	s_cmp_ge_i32 s63, s42                                      // 0000000095BC: BF032A3F
	s_cbranch_scc1 67                                          // 0000000095C0: BFA20043 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11d0>
	s_lshl_b32 s1, s63, 4                                      // 0000000095C4: 8401843F
	v_lshlrev_b32_e32 v4, 4, v45                               // 0000000095C8: 30085A84
	s_waitcnt lgkmcnt(0)                                       // 0000000095CC: BF89FC07
	v_add_nc_u32_e32 v6, s1, v2                                // 0000000095D0: 4A0C0401
	s_mov_b32 s5, exec_lo                                      // 0000000095D4: BE85007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000095D8: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 0000000095DC: 360808FF 000000F0
	v_min_i32_e32 v2, s44, v6                                  // 0000000095E4: 22040C2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000095E8: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[34:35]           // 0000000095EC: D6FF7C02 008A04FF 00005000
	.long 0xd7006a02                                           // 0000000095F8: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000000095FC: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009600: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000009604: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000000960C: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000009610: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009618: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000000961C: D5207C05 01AA0680
	s_clause 0x1                                               // 000000009624: BF850001
	global_load_b128 v[63:66], v[2:3], off                     // 000000009628: DC5E0000 3F7C0002
	global_load_b128 v[67:70], v[4:5], off                     // 000000009630: DC5E0000 437C0004
	.long 0xd4c3007e                                           // 000000009638: D4C3007E
	v_cndmask_b32_e32 v1, s33, v6, vcc_lo                      // 00000000963C: 02020C21
	s_cbranch_execz 11                                         // 000000009640: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1170>
	s_waitcnt vmcnt(1)                                         // 000000009644: BF8907F7
	v_mov_b32_e32 v66, 0                                       // 000000009648: 7E840280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000964C: BF870001
	v_mov_b32_e32 v65, v66                                     // 000000009650: 7E820342
	v_mov_b32_e32 v64, v66                                     // 000000009654: 7E800342
	v_mov_b32_e32 v63, v66                                     // 000000009658: 7E7E0342
	s_waitcnt vmcnt(0)                                         // 00000000965C: BF8903F7
	v_mov_b32_e32 v70, v66                                     // 000000009660: 7E8C0342
	v_mov_b32_e32 v69, v66                                     // 000000009664: 7E8A0342
	v_mov_b32_e32 v68, v66                                     // 000000009668: 7E880342
	v_mov_b32_e32 v67, v66                                     // 00000000966C: 7E860342
	s_or_b32 exec_lo, exec_lo, s5                              // 000000009670: 8C7E057E
	s_and_saveexec_b32 s5, s0                                  // 000000009674: BE852000
	s_cbranch_execz 19                                         // 000000009678: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c8>
	v_dual_mov_b32 v73, 0 :: v_dual_add_nc_u32 v2, s1, v45     // 00000000967C: CA200080 49025A01
	v_mov_b32_e32 v138, 0                                      // 000000009684: 7F140280
	s_mov_b32 s0, exec_lo                                      // 000000009688: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000968C: BF870002
	.long 0xd4c4007e                                           // 000000009690: D4C4007E
	v_cndmask_b32_e32 v1, s33, v2, vcc_lo                      // 000000009694: 02020421
	s_cbranch_execz 10                                         // 000000009698: BFA5000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c4>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 00000000969C: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[36:37]             // 0000000096A8: D6FF7C05 009204FF 000000C0
	global_load_b32 v138, v[3:4], off                          // 0000000096B4: DC520000 8A7C0003
	global_load_b32 v73, v[5:6], off                           // 0000000096BC: DC520000 497C0005
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000096C4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000096C8: BF870009
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000096CC: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000096D0: BF870009
	s_and_b32 vcc_lo, exec_lo, s46                             // 0000000096D4: 8B6A2E7E
	s_mov_b32 s0, -1                                           // 0000000096D8: BE8000C1
	s_cbranch_vccz 81                                          // 0000000096DC: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1324>
	v_and_b32_e32 v2, -16, v45                                 // 0000000096E0: 36045AD0
	s_mov_b32 s0, exec_lo                                      // 0000000096E4: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000096E8: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 0000000096EC: 7D9404C0
	s_cbranch_execz 74                                         // 0000000096F0: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x131c>
	v_lshlrev_b32_e32 v4, 2, v45                               // 0000000096F4: 30085A82
	s_waitcnt lgkmcnt(1)                                       // 0000000096F8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000096FC: BF870001
	v_add_nc_u32_e32 v5, 0x6c00, v4                            // 000000009700: 4A0A08FF 00006C00
	ds_load_2addr_b32 v[2:3], v5 offset0:128 offset1:144       // 000000009708: D8DC9080 02000005
	s_waitcnt lgkmcnt(1)                                       // 000000009710: BF89FC17
	ds_load_b32 v6, v1 offset:28540                            // 000000009714: D8D86F7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000000971C: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 000000009720: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:28480                            // 000000009728: D8D86F40 08000004
	s_waitcnt lgkmcnt(1)                                       // 000000009730: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000009734: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000009738: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 000000009740: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000000974C: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009750: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 000000009754: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000000975C: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000009760: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 000000009764: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 000000009770: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 000000009778: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000000977C: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 000000009780: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000000978C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009790: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 000000009794: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000000979C: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000097A0: BF870125
	.long 0xd71c0007                                           // 0000000097A4: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000000097A8: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 0000000097AC: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000000097B0: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000097B4: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000097BC: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 0000000097C0: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 0000000097C8: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 0000000097CC: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 0000000097D4: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000097D8: BF870093
	v_exp_f32_e32 v9, v9                                       // 0000000097DC: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 0000000097E0: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000097E8: BF870095
	.long 0xd71c0009                                           // 0000000097EC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 0000000097F0: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 0000000097F4: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 0000000097F8: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000009800: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000009804: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:28416                           // 00000000980C: D8346F00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:160 offset1:176      // 000000009814: D838B0A0 00020605
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000981C: 8C7E007E
	s_mov_b32 s0, 0                                            // 000000009820: BE800080
	v_lshrrev_b32_e32 v157, 4, v44                             // 000000009824: 333A5884
	v_mul_u32_u24_e32 v51, 0x110, v34                          // 000000009828: 166644FF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000009830: 916A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000009834: BF870002
	v_lshlrev_b32_e32 v50, 2, v157                             // 000000009838: 30653A82
	s_cbranch_vccnz 872                                        // 00000000983C: BFA40368 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20e0>
	v_mad_u32_u24 v2, 0x110, v34, s59                          // 000000009840: D60B0002 00EE44FF 00000110
	s_and_b32 s0, s3, exec_lo                                  // 00000000984C: 8B007E03
	s_cselect_b32 s0, 0, 0x2200                                // 000000009850: 9800FF80 00002200
	v_mad_u32_u24 v3, 0x110, v34, s60                          // 000000009858: D60B0003 00F244FF 00000110
	ds_load_b128 v[10:13], v51 offset:6144                     // 000000009864: DBFC1800 0A000033
	ds_load_b128 v[14:17], v51 offset:6160                     // 00000000986C: DBFC1810 0E000033
	v_add_nc_u32_e32 v4, s0, v2                                // 000000009874: 4A080400
	v_mov_b32_e32 v8, v1                                       // 000000009878: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 00000000987C: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 000000009880: 7E0A0301
	v_cndmask_b32_e64 v46, v3, v2, s3                          // 000000009884: D501002E 000E0503
	v_mov_b32_e32 v3, v1                                       // 00000000988C: 7E060301
	ds_load_b128 v[18:21], v4                                  // 000000009890: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 000000009898: DBFC0010 16000004
	ds_load_b128 v[26:29], v51 offset:6176                     // 0000000098A0: DBFC1820 1A000033
	ds_load_b128 v[30:33], v51 offset:6192                     // 0000000098A8: DBFC1830 1E000033
	ds_load_b128 v[52:55], v46 offset:32                       // 0000000098B0: DBFC0020 3400002E
	ds_load_b128 v[56:59], v46 offset:48                       // 0000000098B8: DBFC0030 3800002E
	ds_load_b128 v[158:161], v46 offset:64                     // 0000000098C0: DBFC0040 9E00002E
	ds_load_b128 v[162:165], v46 offset:80                     // 0000000098C8: DBFC0050 A200002E
	ds_load_b128 v[170:173], v51 offset:6224                   // 0000000098D0: DBFC1850 AA000033
	ds_load_b128 v[166:169], v51 offset:6208                   // 0000000098D8: DBFC1840 A6000033
	v_mov_b32_e32 v2, v1                                       // 0000000098E0: 7E040301
	v_mov_b32_e32 v4, v1                                       // 0000000098E4: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 0000000098E8: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 0000000098EC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000000098F0: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 0000000098F4: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000098F8: BF870212
	v_mov_b32_e32 v8, v7                                       // 0000000098FC: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000009900: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000009904: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000009908: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000000990C: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000009910: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000009914: 7E040301
	ds_load_b128 v[178:181], v51 offset:6256                   // 000000009918: DBFC1870 B2000033
	ds_load_b128 v[174:177], v51 offset:6240                   // 000000009920: DBFC1860 AE000033
	ds_load_b128 v[186:189], v46 offset:112                    // 000000009928: DBFC0070 BA00002E
	ds_load_b128 v[182:185], v46 offset:96                     // 000000009930: DBFC0060 B600002E
	v_or_b32_e32 v49, 8, v157                                  // 000000009938: 38633A88
	v_or_b32_e32 v48, 10, v157                                 // 00000000993C: 38613A8A
	s_and_not1_b32 vcc_lo, exec_lo, s45                        // 000000009940: 916A2D7E
	s_waitcnt lgkmcnt(12)                                      // 000000009944: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000009948: CC414002 1C0A1512
	ds_load_b128 v[14:17], v51 offset:6288                     // 000000009950: DBFC1890 0E000033
	ds_load_b128 v[10:13], v51 offset:6272                     // 000000009958: DBFC1880 0A000033
	ds_load_b128 v[22:25], v46 offset:144                      // 000000009960: DBFC0090 1600002E
	ds_load_b128 v[18:21], v46 offset:128                      // 000000009968: DBFC0080 1200002E
	s_mov_b32 s0, -1                                           // 000000009970: BE8000C1
	s_waitcnt lgkmcnt(12)                                      // 000000009974: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[52:59], v[26:33], v[2:9]// 000000009978: CC414002 1C0A3534
	ds_load_b128 v[30:33], v51 offset:6320                     // 000000009980: DBFC18B0 1E000033
	ds_load_b128 v[26:29], v51 offset:6304                     // 000000009988: DBFC18A0 1A000033
	ds_load_b128 v[59:62], v46 offset:176                      // 000000009990: DBFC00B0 3B00002E
	ds_load_b128 v[55:58], v46 offset:160                      // 000000009998: DBFC00A0 3700002E
	v_lshlrev_b32_e32 v54, 2, v34                              // 0000000099A0: 306C4482
	v_or_b32_e32 v53, 4, v157                                  // 0000000099A4: 386B3A84
	v_or_b32_e32 v52, 6, v157                                  // 0000000099A8: 38693A86
	s_waitcnt lgkmcnt(12)                                      // 0000000099AC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[158:165], v[166:173], v[2:9]// 0000000099B0: CC414002 1C0B4D9E
	ds_load_b128 v[162:165], v51 offset:6352                   // 0000000099B8: DBFC18D0 A2000033
	ds_load_b128 v[158:161], v51 offset:6336                   // 0000000099C0: DBFC18C0 9E000033
	v_add_nc_u32_e32 v47, 64, v54                              // 0000000099C8: 4A5E6CC0
	ds_load_b128 v[170:173], v51 offset:6384                   // 0000000099CC: DBFC18F0 AA000033
	ds_load_b128 v[166:169], v51 offset:6368                   // 0000000099D4: DBFC18E0 A6000033
	s_waitcnt lgkmcnt(12)                                      // 0000000099DC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[182:189], v[174:181], v[2:9]// 0000000099E0: CC414002 1C0B5DB6
	ds_load_b128 v[178:181], v46 offset:208                    // 0000000099E8: DBFC00D0 B200002E
	ds_load_b128 v[174:177], v46 offset:192                    // 0000000099F0: DBFC00C0 AE00002E
	s_waitcnt lgkmcnt(10)                                      // 0000000099F8: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 0000000099FC: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x6c00, v50                          // 000000009A04: 4A1464FF 00006C00
	v_add_nc_u32_e32 v11, s15, v50                             // 000000009A0C: 4A16640F
	ds_load_b128 v[186:189], v46 offset:240                    // 000000009A10: DBFC00F0 BA00002E
	ds_load_b128 v[182:185], v46 offset:224                    // 000000009A18: DBFC00E0 B600002E
	ds_load_2addr_stride64_b32 v[12:13], v47 offset0:111 offset1:112// 000000009A20: D8E0706F 0C00002F
	v_or_b32_e32 v47, 12, v157                                 // 000000009A28: 385F3A8C
	s_waitcnt lgkmcnt(9)                                       // 000000009A2C: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[55:62], v[26:33], v[2:9]// 000000009A30: CC414002 1C0A3537
	ds_load_2addr_b32 v[28:29], v10 offset0:208 offset1:210    // 000000009A38: D8DCD2D0 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:212 offset1:214    // 000000009A40: D8DCD6D4 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:216 offset1:218    // 000000009A48: D8DCDAD8 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:220 offset1:222    // 000000009A50: D8DCDEDC 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 000000009A58: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 000000009A60: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 000000009A68: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 000000009A70: D8DC0E0C 0E00000B
	v_or_b32_e32 v55, 2, v157                                  // 000000009A78: 386F3A82
	v_or_b32_e32 v46, 14, v157                                 // 000000009A7C: 385D3A8E
	s_waitcnt lgkmcnt(11)                                      // 000000009A80: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[174:181], v[158:165], v[2:9]// 000000009A84: CC414002 1C0B3DAE
	s_waitcnt lgkmcnt(9)                                       // 000000009A8C: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009A90: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[182:189], v[166:173], v[2:9]// 000000009A94: CC414002 1C0B4DB6
	s_cbranch_vccnz 353                                        // 000000009A9C: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b24>
	.long 0x7e143880                                           // 000000009AA0: 7E143880
	s_mov_b32 s0, exec_lo                                      // 000000009AA4: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009AA8: BF870001
	.long 0x7f14390a                                           // 000000009AAC: 7F14390A
	.long 0xd4cb007e                                           // 000000009AB0: D4CB007E
	v_cndmask_b32_e32 v1, v34, v157, vcc_lo                    // 000000009AB4: 02033B22
	s_cbranch_execz 34                                         // 000000009AB8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1644>
	s_waitcnt lgkmcnt(7)                                       // 000000009ABC: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000009AC0: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009AC4: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 000000009AC8: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000009AD0: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000009ADC: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009AE0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000009AE4: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000009AF0: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000009AF4: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000009AF8: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000009B00: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000009B04: 7E3C4B1E
	.long 0xd71c001e                                           // 000000009B08: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000009B0C: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000009B10: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000009B14: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009B18: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000009B1C: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000009B20: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 000000009B28: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009B34: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 000000009B38: 10163D0B
	v_fma_mixhi_f16 v10, v11, s58, 0                           // 000000009B3C: CC22000A 0200750B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009B44: 8C7E007E
	v_mul_u32_u24_e32 v11, 48, v157                            // 000000009B48: 16173AB0
	s_mov_b32 s0, exec_lo                                      // 000000009B4C: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009B50: BF870001
	v_lshl_add_u32 v11, v34, 1, v11                            // 000000009B54: D646000B 042D0322
	ds_store_b16_d16_hi v11, v10 offset:27648                  // 000000009B5C: DA846C00 00000A0B
	.long 0xd4cb007e                                           // 000000009B64: D4CB007E
	v_cndmask_b32_e32 v1, v34, v55, vcc_lo                     // 000000009B68: 02026F22
	s_cbranch_execz 34                                         // 000000009B6C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16f8>
	s_waitcnt lgkmcnt(8)                                       // 000000009B70: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 000000009B74: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009B78: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 000000009B7C: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 000000009B84: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000009B90: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009B94: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000009B98: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000009BA4: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000009BA8: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000009BAC: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000009BB0: 7E3C4B1E
	.long 0xd71c001e                                           // 000000009BB4: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000009BB8: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000009BBC: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000009BC0: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000009BC4: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009BCC: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000009BD0: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000009BD4: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000009BDC: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000009BE4: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009BE8: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000009BEC: 10143D0A
	v_fma_mixlo_f16 v10, v10, s58, 0                           // 000000009BF0: CC21000A 0200750A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009BF8: 8C7E007E
	.long 0x7f143880                                           // 000000009BFC: 7F143880
	v_or_b32_e32 v30, 0x6c00, v11                              // 000000009C00: 383C16FF 00006C00
	s_mov_b32 s0, exec_lo                                      // 000000009C08: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000009C0C: BF870002
	.long 0x7e16398a                                           // 000000009C10: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000009C14: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000009C1C: D4CB007E
	v_cndmask_b32_e32 v1, v34, v53, vcc_lo                     // 000000009C20: 02026B22
	s_cbranch_execz 35                                         // 000000009C24: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17b4>
	s_waitcnt lgkmcnt(8)                                       // 000000009C28: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000009C2C: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009C30: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000009C34: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000009C3C: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000009C44: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000009C50: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009C54: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000009C58: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000009C64: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000009C68: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000009C6C: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000009C70: 7E3E4B1F
	.long 0xd71c001f                                           // 000000009C74: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000009C78: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000009C7C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009C80: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 000000009C84: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000009C8C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000009C94: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009C9C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000009CA0: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000009CA4: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009CA8: BF870001
	v_fma_mixlo_f16 v11, v11, s58, 0                           // 000000009CAC: CC21000B 0200750B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009CB4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000009CB8: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000009CBC: BE80007E
	ds_store_b16 v30, v11 offset:192                           // 000000009CC0: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000009CC8: D4CB007E
	v_cndmask_b32_e32 v1, v34, v52, vcc_lo                     // 000000009CCC: 02026922
	s_cbranch_execz 35                                         // 000000009CD0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1860>
	s_waitcnt lgkmcnt(9)                                       // 000000009CD4: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000009CD8: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009CDC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000009CE0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000009CE8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000009CF4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009CF8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000009CFC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000009D04: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000009D08: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000009D0C: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000009D10: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000009D14: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000009D1C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000009D20: BF870135
	.long 0xd71c000b                                           // 000000009D24: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000009D28: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000009D2C: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 000000009D30: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000009D34: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000009D38: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009D40: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000009D44: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000009D4C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009D50: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000009D54: 1014170A
	v_fma_mixhi_f16 v10, v10, s58, 0                           // 000000009D58: CC22000A 0200750A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009D60: 8C7E007E
	.long 0x7e143880                                           // 000000009D64: 7E143880
	s_mov_b32 s0, exec_lo                                      // 000000009D68: BE80007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000009D6C: DA840120 00000A1E
	.long 0x7e16390a                                           // 000000009D74: 7E16390A
	.long 0xd4cb007e                                           // 000000009D78: D4CB007E
	v_cndmask_b32_e32 v1, v34, v49, vcc_lo                     // 000000009D7C: 02026322
	s_cbranch_execz 34                                         // 000000009D80: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x190c>
	s_waitcnt lgkmcnt(9)                                       // 000000009D84: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 000000009D88: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009D8C: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000009D90: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000009D98: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000009DA4: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009DA8: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000009DAC: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000009DB8: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000009DBC: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000009DC0: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000009DC4: 7E3E4B1F
	.long 0xd71c001f                                           // 000000009DC8: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000009DCC: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 000000009DD0: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 000000009DD4: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000009DD8: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009DE0: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000009DE4: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000009DE8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000009DF0: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000009DF8: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009DFC: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000009E00: 10163F0B
	v_fma_mixlo_f16 v11, v11, s58, 0                           // 000000009E04: CC21000B 0200750B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009E0C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000009E10: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000009E14: BE80007E
	ds_store_b16 v30, v11 offset:384                           // 000000009E18: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 000000009E20: D4CB007E
	v_cndmask_b32_e32 v1, v34, v48, vcc_lo                     // 000000009E24: 02026122
	s_cbranch_execz 35                                         // 000000009E28: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19b8>
	s_waitcnt lgkmcnt(10)                                      // 000000009E2C: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 000000009E30: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009E34: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000009E38: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000009E40: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000009E4C: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009E50: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000009E54: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000009E5C: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000009E60: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000009E64: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000009E68: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000009E6C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000009E74: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000009E78: BF870135
	.long 0xd71c000b                                           // 000000009E7C: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000009E80: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 000000009E84: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 000000009E88: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000009E8C: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000009E90: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009E98: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000009E9C: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000009EA4: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009EA8: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000009EAC: 1014170A
	v_fma_mixlo_f16 v10, v10, s58, 0                           // 000000009EB0: CC21000A 0200750A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009EB8: 8C7E007E
	.long 0x7f143880                                           // 000000009EBC: 7F143880
	s_mov_b32 s0, exec_lo                                      // 000000009EC0: BE80007E
	ds_store_b16 v30, v10 offset:480                           // 000000009EC4: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000009ECC: 7E16398A
	.long 0xd4cb007e                                           // 000000009ED0: D4CB007E
	v_cndmask_b32_e32 v1, v34, v47, vcc_lo                     // 000000009ED4: 02025F22
	s_cbranch_execz 35                                         // 000000009ED8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a68>
	s_waitcnt lgkmcnt(10)                                      // 000000009EDC: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000009EE0: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009EE4: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000009EE8: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000009EF0: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000009EF8: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000009F04: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009F08: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000009F0C: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000009F18: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000009F1C: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000009F20: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000009F24: 7E3E4B1F
	.long 0xd71c001f                                           // 000000009F28: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000009F2C: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 000000009F30: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000009F34: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000009F38: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000009F40: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000009F48: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009F50: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000009F54: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000009F58: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000009F5C: BF870001
	v_fma_mixlo_f16 v11, v11, s58, 0                           // 000000009F60: CC21000B 0200750B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000009F68: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000009F6C: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000009F70: BE80007E
	ds_store_b16 v30, v11 offset:576                           // 000000009F74: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 000000009F7C: D4CB007E
	v_cndmask_b32_e32 v1, v34, v46, vcc_lo                     // 000000009F80: 02025D22
	s_cbranch_execz 35                                         // 000000009F84: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b14>
	s_waitcnt lgkmcnt(11)                                      // 000000009F88: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 000000009F8C: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000009F90: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000009F94: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000009F9C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000009FA8: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000009FAC: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000009FB0: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000009FB8: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000009FBC: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000009FC0: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000009FC4: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000009FC8: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000009FD0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000009FD4: BF870135
	.long 0xd71c000b                                           // 000000009FD8: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000009FDC: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000009FE0: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 000000009FE4: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000009FE8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000009FEC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000009FF4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000009FF8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000000A000: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A004: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000000A008: 1014170A
	v_fma_mixhi_f16 v10, v10, s58, 0                           // 00000000A00C: CC22000A 0200750A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A014: 8C7E007E
	s_mov_b32 s0, 0                                            // 00000000A018: BE800080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000000A01C: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000A024: 8B6A007E
	s_cbranch_vccz 365                                         // 00000000A028: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20e0>
	v_or_b32_e32 v10, 0x6f40, v50                              // 00000000A02C: 381464FF 00006F40
	v_mov_b32_e32 v57, 0                                       // 00000000A034: 7E720280
	v_mov_b32_e32 v59, 0                                       // 00000000A038: 7E760280
	s_mov_b32 s0, exec_lo                                      // 00000000A03C: BE80007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000A040: BF870003
	v_subrev_nc_u32_e32 v58, 64, v10                           // 00000000A044: 4E7414C0
	ds_load_2addr_b32 v[32:33], v58 offset0:2 offset1:4        // 00000000A048: D8DC0402 2000003A
	ds_load_2addr_b32 v[30:31], v58 offset0:6 offset1:8        // 00000000A050: D8DC0806 1E00003A
	ds_load_2addr_b32 v[10:11], v58 offset0:10 offset1:12      // 00000000A058: D8DC0C0A 0A00003A
	ds_load_b32 v56, v58 offset:56                             // 00000000A060: D8D80038 3800003A
	.long 0xd4c9007e                                           // 00000000A068: D4C9007E
	v_cndmask_b32_e32 v1, v34, v157, vcc_lo                    // 00000000A06C: 02033B22
	s_cbranch_execz 37                                         // 00000000A070: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c08>
	s_waitcnt lgkmcnt(11)                                      // 00000000A074: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000000A078: 0838191C
	ds_load_b32 v58, v58                                       // 00000000A07C: D8D80000 3A00003A
	s_waitcnt lgkmcnt(8)                                       // 00000000A084: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v59, 0x3fb8aa3b, v28// 00000000A088: C8C63502 023A38FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000A094: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 00000000A098: 1004050D
	v_fma_f32 v60, 0x3fb8aa3b, v28, -v59                       // 00000000A09C: D613003C 84EE38FF 3FB8AA3B
	v_rndne_f32_e32 v61, v59                                   // 00000000A0A8: 7E7A473B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000A0AC: BF870131
	v_dual_sub_f32 v59, v59, v61 :: v_dual_fmac_f32 v60, 0x32a5705f, v28// 00000000A0B0: C9407B3B 3B3C38FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000000A0BC: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000000A0C4: BF89FC07
	v_dual_mul_f32 v2, v58, v2 :: v_dual_add_f32 v59, v59, v60 // 00000000A0C8: C8C8053A 023A793B
	v_cvt_i32_f32_e32 v60, v61                                 // 00000000A0D0: 7E78113D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000A0D4: BF870292
	v_exp_f32_e32 v59, v59                                     // 00000000A0D8: 7E764B3B
	.long 0xd71c003b                                           // 00000000A0DC: D71C003B
	v_cndmask_b32_e32 v1, v59, v60, vcc_lo                     // 00000000A0E0: 0202793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A0E4: BF870121
	v_cndmask_b32_e32 v26, 0, v59, vcc_lo                      // 00000000A0E8: 02347680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000000A0EC: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000000A0F4: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A0FC: BF870001
	.long 0xd508003b                                           // 00000000A100: D508003B
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000000A104: 42023502
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A108: 8C7E007E
	v_or_b32_e32 v2, 0x6f40, v54                               // 00000000A10C: 38046CFF 00006F40
	s_waitcnt lgkmcnt(7)                                       // 00000000A114: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v157                             // 00000000A118: 30353A86
	s_mov_b32 s0, exec_lo                                      // 00000000A11C: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A120: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000000A124: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v59                                       // 00000000A130: D8340000 00003B02
	.long 0xd4c9007e                                           // 00000000A138: D4C9007E
	v_cndmask_b32_e32 v1, v34, v55, vcc_lo                     // 00000000A13C: 02026F22
	s_cbranch_execz 33                                         // 00000000A140: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1cc8>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000000A144: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A14C: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000000A150: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000000A15C: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000000A164: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v54, v28                                   // 00000000A170: 7E6C471C
	s_waitcnt lgkmcnt(4)                                       // 00000000A174: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000000A178: 10060720
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000A17C: BF870193
	v_fmac_f32_e32 v29, 0x32a5705f, v26                        // 00000000A180: 563A34FF 32A5705F
	v_sub_f32_e32 v28, v28, v54                                // 00000000A188: 08386D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A18C: BF870121
	v_add_f32_e32 v28, v28, v29                                // 00000000A190: 06383B1C
	v_cvt_i32_f32_e32 v29, v54                                 // 00000000A194: 7E3A1136
	v_exp_f32_e32 v28, v28                                     // 00000000A198: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A19C: BF870095
	.long 0xd71c001c                                           // 00000000A1A0: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000000A1A4: 02023B1C
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000000A1A8: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000000A1AC: 7C3C34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A1B4: BF870092
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000000A1B8: 023436FF 7F800000
	.long 0xd5080039                                           // 00000000A1C0: D5080039
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000000A1C4: 42023503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A1C8: 8C7E007E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000000A1CC: CA100080 031A0080
	s_mov_b32 s0, exec_lo                                      // 00000000A1D4: BE80007E
	ds_store_b32 v2, v57 offset:128                            // 00000000A1D8: D8340080 00003902
	.long 0xd4c9007e                                           // 00000000A1E0: D4C9007E
	v_cndmask_b32_e32 v1, v34, v53, vcc_lo                     // 00000000A1E4: 02026B22
	s_cbranch_execz 35                                         // 00000000A1E8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d78>
	v_sub_f32_e32 v24, v24, v12                                // 00000000A1EC: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000000A1F0: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000000A1F4: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000A1F8: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000000A1FC: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000000A204: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000000A20C: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000A210: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000000A214: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000000A220: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000000A224: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000000A228: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000A22C: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000000A230: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000000A238: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A23C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000000A240: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000000A244: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000000A248: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A24C: BF870095
	.long 0xd71c001a                                           // 00000000A250: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000000A254: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000000A258: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000000A25C: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A264: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000000A268: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000000A270: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000000A274: 42022D04
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A278: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A27C: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000000A280: BE80007E
	ds_store_b32 v2, v26 offset:256                            // 00000000A284: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000000A28C: D4C9007E
	v_cndmask_b32_e32 v1, v34, v52, vcc_lo                     // 00000000A290: 02026922
	s_cbranch_execz 34                                         // 00000000A294: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e20>
	v_sub_f32_e32 v3, v25, v12                                 // 00000000A298: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000000A29C: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000000A2A0: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A2A4: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000000A2A8: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000000A2B4: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000000A2C0: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000A2C4: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000000A2C8: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000000A2D0: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000A2D4: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000000A2D8: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000000A2DC: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000000A2E0: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000000A2E8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A2EC: BF870095
	.long 0xd71c0004                                           // 00000000A2F0: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000000A2F4: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000000A2F8: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000000A2FC: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000000A304: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A308: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000000A30C: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000000A318: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000000A31C: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A320: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000000A324: CA100080 04040080
	s_mov_b32 s0, exec_lo                                      // 00000000A32C: BE80007E
	ds_store_b32 v2, v3 offset:384                             // 00000000A330: D8340180 00000302
	.long 0xd4c9007e                                           // 00000000A338: D4C9007E
	v_cndmask_b32_e32 v1, v34, v49, vcc_lo                     // 00000000A33C: 02026322
	s_cbranch_execz 34                                         // 00000000A340: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ecc>
	s_waitcnt lgkmcnt(9)                                       // 00000000A344: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000000A348: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A350: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000000A354: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000000A360: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000000A368: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000000A374: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A378: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000000A37C: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000000A388: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000000A38C: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000A390: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000000A394: 7E0A4B05
	.long 0xd71c0005                                           // 00000000A398: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000000A39C: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A3A0: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000000A3A4: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000000A3A8: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000000A3B0: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000000A3B8: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000000A3BC: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A3C0: BF870001
	.long 0xd5080005                                           // 00000000A3C4: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000000A3C8: 42020705
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A3CC: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A3D0: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000000A3D4: BE80007E
	ds_store_b32 v2, v5 offset:512                             // 00000000A3D8: D8340200 00000502
	.long 0xd4c9007e                                           // 00000000A3E0: D4C9007E
	v_cndmask_b32_e32 v1, v34, v48, vcc_lo                     // 00000000A3E4: 02026122
	s_cbranch_execz 35                                         // 00000000A3E8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f78>
	v_sub_f32_e32 v3, v21, v12                                 // 00000000A3EC: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A3F0: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000000A3F4: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000000A3FC: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000000A408: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000A40C: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000000A410: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000000A414: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000000A41C: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A424: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000000A428: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000000A42C: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000000A430: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000A434: BF8700A5
	.long 0xd71c0004                                           // 00000000A438: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000000A43C: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000000A440: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000000A444: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000A44C: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000000A450: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000000A454: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000000A45C: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000000A460: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A46C: BF870001
	.long 0xd5080004                                           // 00000000A470: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000000A474: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A478: 8C7E007E
	v_mov_b32_e32 v3, 0                                        // 00000000A47C: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000000A480: 7E0A0280
	s_mov_b32 s0, exec_lo                                      // 00000000A484: BE80007E
	ds_store_b32 v2, v4 offset:640                             // 00000000A488: D8340280 00000402
	.long 0xd4c9007e                                           // 00000000A490: D4C9007E
	v_cndmask_b32_e32 v1, v34, v47, vcc_lo                     // 00000000A494: 02025F22
	s_cbranch_execz 35                                         // 00000000A498: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2028>
	v_sub_f32_e32 v4, v16, v12                                 // 00000000A49C: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A4A0: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000000A4A4: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000000A4AC: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000000A4B8: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000A4BC: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000000A4C0: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000000A4C4: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000000A4CC: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A4D4: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000000A4D8: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000000A4DC: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000000A4E0: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000A4E4: BF8700A5
	.long 0xd71c0005                                           // 00000000A4E8: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000000A4EC: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000000A4F0: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000000A4F4: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000A4FC: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000000A500: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000000A504: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000000A50C: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000000A510: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A51C: BF870001
	.long 0xd5080005                                           // 00000000A520: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000000A524: 42020905
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A528: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A52C: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000000A530: BE80007E
	ds_store_b32 v2, v5 offset:768                             // 00000000A534: D8340300 00000502
	.long 0xd4c9007e                                           // 00000000A53C: D4C9007E
	v_cndmask_b32_e32 v1, v34, v46, vcc_lo                     // 00000000A540: 02025D22
	s_cbranch_execz 35                                         // 00000000A544: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20d4>
	v_sub_f32_e32 v3, v17, v12                                 // 00000000A548: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A54C: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000000A550: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000000A558: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000000A564: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000A568: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000000A56C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000000A570: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000000A578: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A580: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000000A584: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000000A588: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000000A58C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000A590: BF8700A5
	.long 0xd71c0004                                           // 00000000A594: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000000A598: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000000A59C: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000000A5A0: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000A5A8: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000000A5AC: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000000A5B0: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000000A5B8: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v56, v5// 00000000A5BC: CA4608FF 03040B38 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A5C8: BF870001
	.long 0xd5080003                                           // 00000000A5CC: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000000A5D0: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000A5D4: 8C7E007E
	ds_store_b32 v2, v3 offset:896                             // 00000000A5D8: D8340380 00000302
	s_cmp_lg_u32 s4, 0                                         // 00000000A5E0: BF078004
	s_cselect_b32 s0, -1, 0                                    // 00000000A5E4: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000000A5E8: BF870499
	s_and_b32 s0, s46, s0                                      // 00000000A5EC: 8B00002E
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000000A5F0: 916A007E
	s_cbranch_vccnz 48                                         // 00000000A5F4: BFA40030 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x21b8>
	v_dual_mov_b32 v77, 0 :: v_dual_lshlrev_b32 v2, 3, v44     // 00000000A5F8: CA220080 4D025883
	s_add_i32 s1, s64, -16                                     // 00000000A600: 8101D040
	v_mov_b32_e32 v78, 0                                       // 00000000A604: 7E9C0280
	s_add_i32 s4, s1, s50                                      // 00000000A608: 81043201
	global_load_b64 v[74:75], v2, s[28:29]                     // 00000000A60C: DC560000 4A1C0002
	v_dual_mov_b32 v79, 0 :: v_dual_lshlrev_b32 v2, 2, v44     // 00000000A614: CA220080 4F025882
	s_cmp_ge_i32 s4, s33                                       // 00000000A61C: BF032104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A620: BF870001
	v_lshlrev_b32_e32 v2, 1, v2                                // 00000000A624: 30040481
	s_cbranch_scc1 8                                           // 00000000A628: BFA20008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x214c>
	s_mul_i32 s5, s4, 0x3000                                   // 00000000A62C: 9605FF04 00003000
	s_mul_hi_i32 s65, s4, 0x3000                               // 00000000A634: 9741FF04 00003000
	s_add_u32 s4, s47, s5                                      // 00000000A63C: 8004052F
	s_addc_u32 s5, s48, s65                                    // 00000000A640: 82054130
	global_load_b64 v[78:79], v2, s[4:5]                       // 00000000A644: DC560000 4E040002
	v_mov_b32_e32 v76, 0                                       // 00000000A64C: 7E980280
	s_add_i32 s4, s1, s51                                      // 00000000A650: 81043301
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A654: BF870009
	s_cmp_ge_i32 s4, s33                                       // 00000000A658: BF032104
	s_cbranch_scc1 8                                           // 00000000A65C: BFA20008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2180>
	s_mul_i32 s5, s4, 0x3000                                   // 00000000A660: 9605FF04 00003000
	s_mul_hi_i32 s65, s4, 0x3000                               // 00000000A668: 9741FF04 00003000
	s_add_u32 s4, s47, s5                                      // 00000000A670: 8004052F
	s_addc_u32 s5, s48, s65                                    // 00000000A674: 82054130
	global_load_b64 v[76:77], v2, s[4:5]                       // 00000000A678: DC560000 4C040002
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0             // 00000000A680: CA100080 51500080
	s_add_i32 s1, s1, s52                                      // 00000000A688: 81013401
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A68C: BF870009
	s_cmp_ge_i32 s1, s33                                       // 00000000A690: BF032101
	s_cbranch_scc1 8                                           // 00000000A694: BFA20008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x21b8>
	s_mul_i32 s4, s1, 0x3000                                   // 00000000A698: 9604FF01 00003000
	s_mul_hi_i32 s1, s1, 0x3000                                // 00000000A6A0: 9701FF01 00003000
	s_add_u32 s4, s47, s4                                      // 00000000A6A8: 8004042F
	s_addc_u32 s5, s48, s1                                     // 00000000A6AC: 82050130
	global_load_b64 v[80:81], v2, s[4:5]                       // 00000000A6B0: DC560000 50040002
	s_waitcnt lgkmcnt(0)                                       // 00000000A6B8: BF89FC07
	s_barrier                                                  // 00000000A6BC: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s45                             // 00000000A6C0: 8B6A2D7E
	s_mov_b32 s1, -1                                           // 00000000A6C4: BE8100C1
	s_cbranch_vccz 941                                         // 00000000A6C8: BFA303AD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3080>
	s_mov_b32 s1, exec_lo                                      // 00000000A6CC: BE81007E
	v_cmpx_gt_i32_e32 0x120, v45                               // 00000000A6D0: 7D885AFF 00000120
	s_cbranch_execz 170                                        // 00000000A6D8: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2484>
	v_add_nc_u32_e32 v2, 0xffffff00, v45                       // 00000000A6DC: 4A045AFF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000000A6E4: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000A6E8: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000000A6EC: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000A6F0: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000000A6F4: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 00000000A6FC: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000000A700: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000000A704: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A70C: BF870092
	.long 0xd72c0004                                           // 00000000A710: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000000A714: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000000A71C: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000000A724: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000000A72C: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 00000000A734: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 00000000A738: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000000A740: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000000A748: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000000A750: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000000A754: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000000A758: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000000A75C: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000000A760: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000000A764: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000000A76C: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000000A774: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:28736                      // 00000000A77C: DBFC7040 04000011
	ds_load_b128 v[8:11], v17 offset:28752                     // 00000000A784: DBFC7050 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000000A78C: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000000A790: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000A794: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000000A798: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000000A7A0: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000000A7A8: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000A7AC: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000000A7B0: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000000A7B8: 162418B0
	ds_load_b128 v[12:15], v17 offset:28544                    // 00000000A7BC: DBFC6F80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000000A7C4: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000000A7C8: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000000A7CC: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:28560                    // 00000000A7D4: DBFC6F90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000000A7DC: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000000A7E0: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000000A7E4: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000000A7E8: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000000A7F0: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000000A7F4: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000000A7F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000000A7FC: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000000A800: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000000A808: 7C82069F
	v_fma_mixhi_f16 v4, v4, s58, 0                             // 00000000A80C: CC220004 02007504
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000000A814: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000000A81C: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000000A820: 10141713
	v_fma_mixlo_f16 v4, v12, s58, 0                            // 00000000A824: CC210004 0200750C
	v_fma_mixhi_f16 v5, v5, s58, 0                             // 00000000A82C: CC220005 02007505
	s_or_b32 s4, vcc_lo, s4                                    // 00000000A834: 8C04046A
	v_fma_mixlo_f16 v5, v6, s58, 0                             // 00000000A838: CC210005 02007506
	v_fma_mixhi_f16 v6, v8, s58, 0                             // 00000000A840: CC220006 02007508
	v_fma_mixlo_f16 v6, v7, s58, 0                             // 00000000A848: CC210006 02007507
	v_fma_mixhi_f16 v7, v10, s58, 0                            // 00000000A850: CC220007 0200750A
	v_fma_mixlo_f16 v7, v9, s58, 0                             // 00000000A858: CC210007 02007509
	ds_store_b128 v28, v[4:7]                                  // 00000000A860: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000000A868: 917E047E
	s_cbranch_execnz 65440                                     // 00000000A86C: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x21f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000A870: 8C7E047E
	v_lshl_add_u32 v3, v45, 3, 0xffffff00                      // 00000000A874: D6460003 03FD072D FFFFFF00
	s_mov_b32 s4, 0                                            // 00000000A880: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000000A884: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000A88C: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000000A890: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000000A898: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000000A8A0: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000A8A4: BF870121
	.long 0xd72c0006                                           // 00000000A8A8: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000000A8AC: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000000A8B4: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000000A8B8: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:14848                       // 00000000A8C0: DBFC3A00 04000009
	ds_load_b32 v8, v8 offset:28800                            // 00000000A8C8: D8D87080 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000000A8D0: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000000A8D4: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000000A8DC: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000000A8E0: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000000A8E8: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000000A8F0: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000000A8F4: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000000A8FC: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000000A900: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000A904: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000000A908: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000000A910: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000000A914: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000000A918: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000000A91C: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000000A920: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000000A924: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000000A928: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000000A92C: 7C82049F
	v_fma_mixhi_f16 v4, v4, s58, 0                             // 00000000A930: CC220004 02007504
	v_fma_mixlo_f16 v4, v14, s58, 0                            // 00000000A938: CC210004 0200750E
	v_fma_mixhi_f16 v5, v5, s58, 0                             // 00000000A940: CC220005 02007505
	v_fma_mixlo_f16 v5, v10, s58, 0                            // 00000000A948: CC210005 0200750A
	v_fma_mixhi_f16 v6, v6, s58, 0                             // 00000000A950: CC220006 02007506
	v_fma_mixlo_f16 v6, v11, s58, 0                            // 00000000A958: CC210006 0200750B
	v_fma_mixhi_f16 v7, v7, s58, 0                             // 00000000A960: CC220007 02007507
	v_fma_mixlo_f16 v7, v12, s58, 0                            // 00000000A968: CC210007 0200750C
	s_or_b32 s4, vcc_lo, s4                                    // 00000000A970: 8C04046A
	ds_store_b128 v9, v[4:7] offset:14848                      // 00000000A974: DB7C3A00 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000000A97C: 917E047E
	s_cbranch_execnz 65472                                     // 00000000A980: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2384>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000000A984: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000A988: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000A98C: 8B6A007E
	s_cbranch_vccz 762                                         // 00000000A990: BFA302FA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x307c>
	v_lshl_or_b32 v2, v44, 1, 0x2900                           // 00000000A994: D6560002 03FD032C 00002900
	s_mul_i32 s0, s51, 0x110                                   // 00000000A9A0: 9600FF33 00000110
	s_mul_i32 s1, s52, 0x110                                   // 00000000A9A8: 9601FF34 00000110
	s_waitcnt lgkmcnt(0)                                       // 00000000A9B0: BF89FC07
	v_lshlrev_b32_e32 v14, 2, v44                              // 00000000A9B4: 301C5882
	s_add_i32 s66, s64, -16                                    // 00000000A9B8: 8142D040
	v_add_nc_u32_e32 v4, s0, v2                                // 00000000A9BC: 4A080400
	v_add_nc_u32_e32 v5, s1, v2                                // 00000000A9C0: 4A0A0401
	v_mad_u64_u32 v[2:3], null, 0x110, s50, v[2:3]             // 00000000A9C4: D6FE7C02 040864FF 00000110
	s_add_i32 s68, s66, s50                                    // 00000000A9D0: 81443242
	ds_load_u16 v3, v4 offset:192                              // 00000000A9D4: D8F000C0 03000004
	ds_load_u16 v6, v4 offset:128                              // 00000000A9DC: D8F00080 06000004
	ds_load_u16 v7, v4 offset:64                               // 00000000A9E4: D8F00040 07000004
	ds_load_u16 v8, v5 offset:128                              // 00000000A9EC: D8F00080 08000005
	ds_load_u16 v9, v5                                         // 00000000A9F4: D8F00000 09000005
	ds_load_u16 v10, v5 offset:64                              // 00000000A9FC: D8F00040 0A000005
	ds_load_u16 v5, v5 offset:192                              // 00000000AA04: D8F000C0 05000005
	ds_load_u16 v11, v2                                        // 00000000AA0C: D8F00000 0B000002
	ds_load_u16 v12, v2 offset:64                              // 00000000AA14: D8F00040 0C000002
	ds_load_u16 v13, v2 offset:128                             // 00000000AA1C: D8F00080 0D000002
	ds_load_u16 v2, v2 offset:192                              // 00000000AA24: D8F000C0 02000002
	ds_load_u16 v4, v4                                         // 00000000AA2C: D8F00000 04000004
	s_cmp_ge_i32 s68, s33                                      // 00000000AA34: BF032144
	s_waitcnt lgkmcnt(9)                                       // 00000000AA38: BF89FC97
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000000AA3C: 300E0E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000AA40: BF870091
	v_dual_mul_f32 v7, v7, v7 :: v_dual_lshlrev_b32 v6, 16, v6 // 00000000AA44: C8E20F07 07060C90
	v_mul_f32_e32 v6, v6, v6                                   // 00000000AA4C: 100C0D06
	s_waitcnt lgkmcnt(0)                                       // 00000000AA50: BF89FC07
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000000AA54: 30080890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000AA58: BF870121
	v_dual_mul_f32 v4, v4, v4 :: v_dual_lshlrev_b32 v9, 16, v9 // 00000000AA5C: C8E20904 04081290
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000000AA64: 301A1A90
	v_dual_mul_f32 v9, v9, v9 :: v_dual_lshlrev_b32 v2, 16, v2 // 00000000AA68: C8E21309 09020490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AA70: BF870193
	v_dual_add_f32 v4, v4, v6 :: v_dual_lshlrev_b32 v11, 16, v11// 00000000AA74: C9220D04 040A1690
	v_dual_mul_f32 v13, v13, v13 :: v_dual_lshlrev_b32 v12, 16, v12// 00000000AA7C: C8E21B0D 0D0C1890
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AA84: BF870193
	v_dual_mul_f32 v2, v2, v2 :: v_dual_lshlrev_b32 v5, 16, v5 // 00000000AA88: C8E20502 02040A90
	v_dual_mul_f32 v11, v11, v11 :: v_dual_lshlrev_b32 v10, 16, v10// 00000000AA90: C8E2170B 0B0A1490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AA98: BF870193
	v_dual_mul_f32 v12, v12, v12 :: v_dual_lshlrev_b32 v3, 16, v3// 00000000AA9C: C8E2190C 0C020690
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v8, 16, v8 // 00000000AAA4: C8E20B05 05081090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AAAC: BF870112
	v_dual_mul_f32 v10, v10, v10 :: v_dual_mul_f32 v3, v3, v3  // 00000000AAB0: C8C6150A 0A020703
	v_dual_add_f32 v11, v11, v13 :: v_dual_mul_f32 v8, v8, v8  // 00000000AAB8: C9061B0B 0B081108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AAC0: BF870112
	v_dual_add_f32 v2, v12, v2 :: v_dual_add_f32 v5, v10, v5   // 00000000AAC4: C908050C 02040B0A
	v_dual_add_f32 v3, v7, v3 :: v_dual_add_f32 v6, v9, v8     // 00000000AACC: C9080707 03061109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AAD4: BF870111
	v_dual_add_f32 v2, v11, v2 :: v_dual_add_f32 v5, v6, v5    // 00000000AAD8: C908050B 02040B06
	v_add_f32_e32 v3, v4, v3                                   // 00000000AAE0: 06060704
	v_lshl_or_b32 v6, v44, 3, 0x2900                           // 00000000AAE4: D6560006 03FD072C 00002900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AAF0: BF870193
	v_dual_mov_b32 v4, v5 :: v_dual_mov_b32 v7, v2             // 00000000AAF4: CA100105 04060102
	v_mov_b32_e32 v8, v3                                       // 00000000AAFC: 7E100303
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AB00: BF870192
	v_permlanex16_b32 v4, v4, s61, 0xfedcba98                  // 00000000AB04: D65C0004 03FC7B04 FEDCBA98
	v_permlanex16_b32 v7, v7, s61, 0xfedcba98                  // 00000000AB10: D65C0007 03FC7B07 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AB1C: BF870193
	v_permlanex16_b32 v8, v8, s61, 0xfedcba98                  // 00000000AB20: D65C0008 03FC7B08 FEDCBA98
	v_dual_add_f32 v10, v5, v4 :: v_dual_add_nc_u32 v9, s0, v6 // 00000000AB2C: C9200905 0A080C00
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000AB34: BF870002
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v8     // 00000000AB38: C9080F02 02021103
	v_add_nc_u32_e32 v8, s1, v6                                // 00000000AB40: 4A100C01
	ds_load_b64 v[4:5], v9                                     // 00000000AB44: D9D80000 04000009
	v_add_f32_dpp v7, v10, v10 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB4C: 060E14FA FF09080A
	v_add_f32_dpp v2, v2, v2 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB54: 060404FA FF090802
	v_add_f32_dpp v3, v3, v3 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB5C: 060606FA FF090803
	s_waitcnt vmcnt(0)                                         // 00000000AB64: BF8903F7
	v_and_b32_e32 v10, 0xffff0000, v74                         // 00000000AB68: 361494FF FFFF0000
	v_add_f32_dpp v7, v7, v7 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB70: 060E0EFA FF090407
	v_add_f32_dpp v11, v2, v2 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB78: 061604FA FF090402
	v_add_f32_dpp v12, v3, v3 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB80: 061806FA FF090403
	ds_load_b64 v[2:3], v8                                     // 00000000AB88: D9D80000 02000008
	v_lshlrev_b32_e32 v9, 16, v74                              // 00000000AB90: 30129490
	v_add_f32_dpp v7, v7, v7 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB94: 060E0EFA FF090207
	v_add_f32_dpp v13, v11, v11 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000AB9C: 061A16FA FF09020B
	v_add_f32_dpp v12, v12, v12 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000ABA4: 061818FA FF09020C
	v_lshlrev_b32_e32 v11, 16, v75                             // 00000000ABAC: 30169690
	v_and_b32_e32 v8, 0xffff0000, v75                          // 00000000ABB0: 361096FF FFFF0000
	v_add_f32_dpp v7, v7, v7 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000ABB8: 060E0EFA FF090107
	v_add_f32_dpp v13, v13, v13 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000ABC0: 061A1AFA FF09010D
	v_add_f32_dpp v12, v12, v12 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000ABC8: 061818FA FF09010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000ABD0: BF870193
	.long 0xd7600041                                           // 00000000ABD4: D7600041
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                     // 00000000ABD8: 02010107
	.long 0xd7600000                                           // 00000000ABDC: D7600000
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                    // 00000000ABE0: 0201010D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000ABE4: BF870003
	.long 0xd7600043                                           // 00000000ABE8: D7600043
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                    // 00000000ABEC: 0201010C
	v_lshlrev_b32_e32 v7, 1, v14                               // 00000000ABF0: 300E1C81
	s_cbranch_scc1 199                                         // 00000000ABF4: BFA200C7 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2a14>
	v_and_b32_e32 v12, 0xffff0000, v79                         // 00000000ABF8: 36189EFF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v79                             // 00000000AC00: 301A9E90
	s_mul_f32 s0, s0, 0x3c000000                               // 00000000AC04: A200FF00 3C000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AC0C: BF870112
	v_dual_mul_f32 v12, 0xbfb8aa3b, v12 :: v_dual_lshlrev_b32 v15, 16, v78// 00000000AC10: C8E218FF 0C0E9C90 BFB8AA3B
	v_mul_f32_e32 v16, 0xbfb8aa3b, v13                         // 00000000AC1C: 10201AFF BFB8AA3B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AC24: BF870119
	s_add_f32 s0, s0, 0x358637bd                               // 00000000AC28: A000FF00 358637BD
	v_exp_f32_e32 v17, v12                                     // 00000000AC30: 7E224B0C
	v_mad_u64_u32 v[12:13], null, 0x110, s50, v[6:7]           // 00000000AC34: D6FE7C0C 041864FF 00000110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000000AC40: BF870159
	s_mul_f32 s1, s0, 0x4b800000                               // 00000000AC44: A201FF00 4B800000
	v_mul_f32_e32 v15, 0xbfb8aa3b, v15                         // 00000000AC4C: 101E1EFF BFB8AA3B
	v_exp_f32_e32 v6, v16                                      // 00000000AC54: 7E0C4B10
	s_cmp_lt_f32 s0, 0x800000                                  // 00000000AC58: BF41FF00 00800000
	v_mov_b32_e32 v16, s1                                      // 00000000AC60: 7E200201
	v_exp_f32_e32 v15, v15                                     // 00000000AC64: 7E1E4B0F
	ds_load_b64 v[12:13], v12                                  // 00000000AC68: D9D80000 0C00000C
	v_dual_add_f32 v17, 1.0, v17 :: v_dual_and_b32 v14, 0xffff0000, v78// 00000000AC70: C92422F2 110E9CFF FFFF0000
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000AC7C: 986A80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AC80: BF870111
	v_div_scale_f32 v18, null, v17, v17, 1.0                   // 00000000AC84: D6FC7C12 03CA2311
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_mul_f32 v14, 0xbfb8aa3b, v14// 00000000AC8C: C9061EF2 0F0E1CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000AC98: BF870092
	v_rcp_f32_e32 v22, v18                                     // 00000000AC9C: 7E2C5512
	v_div_scale_f32 v23, null, v15, v15, 1.0                   // 00000000ACA0: D6FC7C17 03CA1F0F
	v_div_scale_f32 v29, s5, 1.0, v15, 1.0                     // 00000000ACA8: D6FC051D 03CA1EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(TRANS32_DEP_3)// 00000000ACB0: BF8703D2
	v_rcp_f32_e32 v28, v23                                     // 00000000ACB4: 7E385517
	s_waitcnt lgkmcnt(0)                                       // 00000000ACB8: BF89FC07
	v_and_b32_e32 v30, 0xffff0000, v13                         // 00000000ACBC: 363C1AFF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000000ACC4: 301A1A90
	v_exp_f32_e32 v14, v14                                     // 00000000ACC8: 7E1C4B0E
	v_fma_f32 v31, -v18, v22, 1.0                              // 00000000ACCC: D613001F 23CA2D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000000ACD4: BF870311
	v_fmac_f32_e32 v22, v31, v22                               // 00000000ACD8: 562C2D1F
	v_fma_f32 v31, -v23, v28, 1.0                              // 00000000ACDC: D613001F 23CA3917
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000ACE4: BF870095
	v_add_f32_e32 v14, 1.0, v14                                // 00000000ACE8: 061C1CF2
	v_div_scale_f32 v21, null, v14, v14, 1.0                   // 00000000ACEC: D6FC7C15 03CA1D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000ACF4: BF870291
	v_rcp_f32_e32 v26, v21                                     // 00000000ACF8: 7E345515
	v_fma_f32 v45, -v21, v26, 1.0                              // 00000000ACFC: D613002D 23CA3515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000AD04: BF8700A1
	v_fmac_f32_e32 v26, v45, v26                               // 00000000AD08: 5634352D
	v_fmac_f32_e32 v28, v31, v28                               // 00000000AD0C: 5638391F
	v_mul_f32_e32 v47, v29, v28                                // 00000000AD10: 105E391D
	v_cndmask_b32_e32 v16, s0, v16, vcc_lo                     // 00000000AD14: 02202000
	v_div_scale_f32 v20, s0, 1.0, v17, 1.0                     // 00000000AD18: D6FC0014 03CA22F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AD20: BF870191
	v_mul_f32_e32 v45, v20, v22                                // 00000000AD24: 105A2D14
	v_rsq_f32_e32 v16, v16                                     // 00000000AD28: 7E205D10
	v_add_f32_e32 v6, 1.0, v6                                  // 00000000AD2C: 060C0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000AD30: BF8701A2
	v_fma_f32 v46, -v18, v45, v20                              // 00000000AD34: D613002E 24525B12
	v_and_b32_e32 v32, 0xffff0000, v12                         // 00000000AD3C: 364018FF FFFF0000
	v_div_scale_f32 v19, null, v6, v6, 1.0                     // 00000000AD44: D6FC7C13 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000AD4C: BF8701A3
	v_fmac_f32_e32 v45, v46, v22                               // 00000000AD50: 565A2D2E
	v_fma_f32 v46, -v23, v47, v29                              // 00000000AD54: D613002E 24765F17
	v_rcp_f32_e32 v24, v19                                     // 00000000AD5C: 7E305513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000AD60: BF870292
	v_fma_f32 v18, -v18, v45, v20                              // 00000000AD64: D6130012 24525B12
	v_fma_f32 v33, -v19, v24, 1.0                              // 00000000AD6C: D6130021 23CA3113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000AD74: BF8700B1
	v_fmac_f32_e32 v24, v33, v24                               // 00000000AD78: 56303121
	v_mul_f32_e32 v33, 0x45800000, v16                         // 00000000AD7C: 104220FF 45800000
	v_div_scale_f32 v25, s1, 1.0, v6, 1.0                      // 00000000AD84: D6FC0119 03CA0CF2
	v_dual_cndmask_b32 v16, v16, v33 :: v_dual_mul_f32 v31, v25, v24// 00000000AD8C: CA464310 101E3119
	v_div_scale_f32 v27, s4, 1.0, v14, 1.0                     // 00000000AD94: D6FC041B 03CA1CF2
	s_mov_b32 vcc_lo, s0                                       // 00000000AD9C: BEEA0000
	s_mul_i32 s0, s68, 0x3000                                  // 00000000ADA0: 9600FF44 00003000
	v_div_fmas_f32 v18, v18, v22, v45                          // 00000000ADA8: D6370012 04B62D12
	v_fma_f32 v48, -v19, v31, v25                              // 00000000ADB0: D6130030 24663F13
	s_mov_b32 vcc_lo, s1                                       // 00000000ADB8: BEEA0001
	s_mul_hi_i32 s1, s68, 0x3000                               // 00000000ADBC: 9701FF44 00003000
	s_add_u32 s0, s53, s0                                      // 00000000ADC4: 80000035
	v_div_fixup_f32 v17, v18, v17, 1.0                         // 00000000ADC8: D6270011 03CA2312
	v_fmac_f32_e32 v31, v48, v24                               // 00000000ADD0: 563E3130
	v_mul_f32_e32 v33, v27, v26                                // 00000000ADD4: 1042351B
	s_addc_u32 s1, s54, s1                                     // 00000000ADD8: 82010136
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000ADDC: BF870112
	v_fma_f32 v19, -v19, v31, v25                              // 00000000ADE0: D6130013 24663F13
	v_fma_f32 v49, -v21, v33, v27                              // 00000000ADE8: D6130031 246E4315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000ADF0: BF870112
	v_div_fmas_f32 v19, v19, v24, v31                          // 00000000ADF4: D6370013 047E3113
	v_fmac_f32_e32 v33, v49, v26                               // 00000000ADFC: 56423531
	v_fmac_f32_e32 v47, v46, v28                               // 00000000AE00: 565E392E
	v_dual_mul_f32 v13, v16, v13 :: v_dual_lshlrev_b32 v12, 16, v12// 00000000AE04: C8E21B10 0D0C1890
	s_mov_b32 vcc_lo, s4                                       // 00000000AE0C: BEEA0004
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AE10: BF870193
	v_fma_f32 v21, -v21, v33, v27                              // 00000000AE14: D6130015 246E4315
	v_fma_f32 v22, -v23, v47, v29                              // 00000000AE1C: D6130016 24765F17
	v_div_fixup_f32 v6, v19, v6, 1.0                           // 00000000AE24: D6270006 03CA0D13
	v_dual_mul_f32 v30, v16, v30 :: v_dual_mul_f32 v13, v13, v11// 00000000AE2C: C8C63D10 1E0C170D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000AE34: BF870004
	v_div_fmas_f32 v19, v21, v26, v33                          // 00000000AE38: D6370013 04863515
	s_mov_b32 vcc_lo, s5                                       // 00000000AE40: BEEA0005
	v_mul_f32_e32 v12, v16, v12                                // 00000000AE44: 10181910
	v_div_fmas_f32 v21, v22, v28, v47                          // 00000000AE48: D6370015 04BE3916
	v_mul_f32_e32 v20, v30, v8                                 // 00000000AE50: 1028111E
	v_mul_f32_e32 v16, v16, v32                                // 00000000AE54: 10204110
	v_mul_f32_e32 v6, v6, v13                                  // 00000000AE58: 100C1B06
	v_mul_f32_e32 v12, v12, v9                                 // 00000000AE5C: 1018130C
	v_div_fixup_f32 v13, v21, v15, 1.0                         // 00000000AE60: D627000D 03CA1F15
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000000AE68: BF870234
	v_dual_mul_f32 v15, v17, v20 :: v_dual_mul_f32 v16, v16, v10// 00000000AE6C: C8C62911 0F101510
	v_div_fixup_f32 v14, v19, v14, 1.0                         // 00000000AE74: D627000E 03CA1D13
	v_bfe_u32 v17, v6, 16, 1                                   // 00000000AE7C: D6100011 02052106
	v_mul_f32_e32 v12, v13, v12                                // 00000000AE84: 1018190D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000AE88: BF870214
	v_bfe_u32 v13, v15, 16, 1                                  // 00000000AE8C: D610000D 0205210F
	v_mul_f32_e32 v14, v14, v16                                // 00000000AE94: 101C210E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000AE98: BF870214
	v_add3_u32 v6, v6, v17, 0x7fff                             // 00000000AE9C: D6550006 03FE2306 00007FFF
	v_bfe_u32 v16, v12, 16, 1                                  // 00000000AEA8: D6100010 0205210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000000AEB0: BF8701D4
	v_add3_u32 v13, v15, v13, 0x7fff                           // 00000000AEB4: D655000D 03FE1B0F 00007FFF
	.long 0x7f1e3880                                           // 00000000AEC0: 7F1E3880
	v_bfe_u32 v17, v14, 16, 1                                  // 00000000AEC4: D6100011 0205210E
	.long 0x7e1e3986                                           // 00000000AECC: 7E1E3986
	v_add3_u32 v6, v12, v16, 0x7fff                            // 00000000AED0: D6550006 03FE210C 00007FFF
	v_add3_u32 v12, v14, v17, 0x7fff                           // 00000000AEDC: D655000C 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AEE8: BF870193
	v_and_or_b32 v13, 0xffff0000, v13, v15                     // 00000000AEEC: D657000D 043E1AFF FFFF0000
	.long 0x7e1e3986                                           // 00000000AEF8: 7E1E3986
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000AEFC: BF870001
	v_and_or_b32 v12, 0xffff0000, v12, v15                     // 00000000AF00: D657000C 043E18FF FFFF0000
	global_store_b64 v7, v[12:13], s[0:1]                      // 00000000AF0C: DC6E0000 00000C07
	s_add_i32 s68, s66, s51                                    // 00000000AF14: 81443342
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000AF18: BF8704A9
	s_cmp_ge_i32 s68, s33                                      // 00000000AF1C: BF032144
	s_cselect_b32 s0, -1, 0                                    // 00000000AF20: 980080C1
	s_or_b32 s0, s49, s0                                       // 00000000AF24: 8C000031
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000AF28: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000AF2C: 8B6A007E
	s_cbranch_vccnz 194                                        // 00000000AF30: BFA400C2 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2d3c>
	s_mul_f32 s0, s67, 0x3c000000                              // 00000000AF34: A200FF43 3C000000
	v_lshlrev_b32_e32 v13, 16, v77                             // 00000000AF3C: 301A9A90
	v_lshlrev_b32_e32 v6, 16, v76                              // 00000000AF40: 300C9890
	s_waitcnt lgkmcnt(1)                                       // 00000000AF44: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v5                              // 00000000AF48: 302E0A90
	s_add_f32 s0, s0, 0x358637bd                               // 00000000AF4C: A000FF00 358637BD
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000000AF54: 360A0AFF FFFF0000
	v_dual_mul_f32 v13, 0xbfb8aa3b, v13 :: v_dual_mul_f32 v6, 0xbfb8aa3b, v6// 00000000AF5C: C8C61AFF 0D060CFF BFB8AA3B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000AF68: BF870139
	s_mul_f32 s1, s0, 0x4b800000                               // 00000000AF6C: A201FF00 4B800000
	s_cmp_lt_f32 s0, 0x800000                                  // 00000000AF74: BF41FF00 00800000
	v_lshlrev_b32_e32 v15, 16, v4                              // 00000000AF7C: 301E0890
	v_exp_f32_e32 v13, v13                                     // 00000000AF80: 7E1A4B0D
	v_mov_b32_e32 v16, s1                                      // 00000000AF84: 7E200201
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000AF88: 986A80C1
	v_and_b32_e32 v12, 0xffff0000, v76                         // 00000000AF8C: 361898FF FFFF0000
	v_exp_f32_e32 v6, v6                                       // 00000000AF94: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000000AF98: BF870106
	v_dual_cndmask_b32 v16, s0, v16 :: v_dual_add_f32 v13, 1.0, v13// 00000000AF9C: CA482000 100C1AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000AFA4: BF870112
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 00000000AFA8: 101818FF BFB8AA3B
	v_rsq_f32_e32 v16, v16                                     // 00000000AFB0: 7E205D10
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000AFB4: BF870196
	v_add_f32_e32 v6, 1.0, v6                                  // 00000000AFB8: 060C0CF2
	v_div_scale_f32 v19, null, v13, v13, 1.0                   // 00000000AFBC: D6FC7C13 03CA1B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000AFC4: BF8701A3
	v_exp_f32_e32 v12, v12                                     // 00000000AFC8: 7E184B0C
	v_div_scale_f32 v29, s4, 1.0, v13, 1.0                     // 00000000AFCC: D6FC041D 03CA1AF2
	v_div_scale_f32 v17, null, v6, v6, 1.0                     // 00000000AFD4: D6FC7C11 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 00000000AFDC: BF8703A3
	v_rcp_f32_e32 v24, v19                                     // 00000000AFE0: 7E305513
	v_div_scale_f32 v25, s0, 1.0, v6, 1.0                      // 00000000AFE4: D6FC0019 03CA0CF2
	v_mul_f32_e32 v28, 0x45800000, v16                         // 00000000AFEC: 103820FF 45800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000AFF4: BF870093
	v_rcp_f32_e32 v20, v17                                     // 00000000AFF8: 7E285511
	v_cndmask_b32_e32 v16, v16, v28, vcc_lo                    // 00000000AFFC: 02203910
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000000B000: BF870327
	v_add_f32_e32 v12, 1.0, v12                                // 00000000B004: 061818F2
	s_mov_b32 vcc_lo, s0                                       // 00000000B008: BEEA0000
	v_fma_f32 v28, -v19, v24, 1.0                              // 00000000B00C: D613001C 23CA3113
	s_mul_i32 s0, s68, 0x3000                                  // 00000000B014: 9600FF44 00003000
	v_mul_f32_e32 v23, v16, v23                                // 00000000B01C: 102E2F10
	v_div_scale_f32 v18, null, v12, v12, 1.0                   // 00000000B020: D6FC7C12 03CA190C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000B028: BF870225
	v_fma_f32 v30, -v17, v20, 1.0                              // 00000000B02C: D613001E 23CA2911
	v_div_scale_f32 v26, s1, 1.0, v12, 1.0                     // 00000000B034: D6FC011A 03CA18F2
	v_dual_fmac_f32 v24, v28, v24 :: v_dual_mul_f32 v23, v23, v11// 00000000B03C: C806311C 18161717
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000000B044: BF870144
	v_rcp_f32_e32 v21, v18                                     // 00000000B048: 7E2A5512
	v_dual_mul_f32 v15, v16, v15 :: v_dual_and_b32 v14, 0xffff0000, v77// 00000000B04C: C8E41F10 0F0E9AFF FFFF0000
	v_dual_fmac_f32 v20, v30, v20 :: v_dual_mul_f32 v5, v16, v5// 00000000B058: C806291E 14040B10
	s_add_u32 s0, s53, s0                                      // 00000000B060: 80000035
	v_mul_f32_e32 v15, v15, v9                                 // 00000000B064: 101E130F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000B068: BF870292
	v_mul_f32_e32 v5, v5, v8                                   // 00000000B06C: 100A1105
	v_fma_f32 v31, -v18, v21, 1.0                              // 00000000B070: D613001F 23CA2B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B078: BF870091
	v_dual_mul_f32 v14, 0xbfb8aa3b, v14 :: v_dual_fmac_f32 v21, v31, v21// 00000000B07C: C8C01CFF 0E142B1F BFB8AA3B
	v_exp_f32_e32 v14, v14                                     // 00000000B088: 7E1C4B0E
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000000B08C: 360808FF FFFF0000
	v_mul_f32_e32 v31, v25, v20                                // 00000000B094: 103E2919
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B098: BF870112
	v_dual_mul_f32 v33, v26, v21 :: v_dual_mul_f32 v4, v16, v4 // 00000000B09C: C8C62B1A 21040910
	v_fma_f32 v28, -v17, v31, v25                              // 00000000B0A4: D613001C 24663F11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B0AC: BF870095
	v_dual_mul_f32 v45, v29, v24 :: v_dual_add_f32 v14, 1.0, v14// 00000000B0B0: C8C8311D 2D0E1CF2
	v_div_scale_f32 v22, null, v14, v14, 1.0                   // 00000000B0B8: D6FC7C16 03CA1D0E
	v_div_scale_f32 v32, s5, 1.0, v14, 1.0                     // 00000000B0C0: D6FC0520 03CA1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000B0C8: BF870292
	v_rcp_f32_e32 v27, v22                                     // 00000000B0CC: 7E365516
	v_fma_f32 v30, -v22, v27, 1.0                              // 00000000B0D0: D613001E 23CA3716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000B0D8: BF8700A1
	v_fmac_f32_e32 v27, v30, v27                               // 00000000B0DC: 5636371E
	v_fma_f32 v30, -v18, v33, v26                              // 00000000B0E0: D613001E 246A4312
	v_dual_fmac_f32 v33, v30, v21 :: v_dual_mul_f32 v30, v32, v27// 00000000B0E8: C8062B1E 211E3720
	v_fmac_f32_e32 v31, v28, v20                               // 00000000B0F0: 563E291C
	v_fma_f32 v28, -v19, v45, v29                              // 00000000B0F4: D613001C 24765B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B0FC: BF870193
	v_fma_f32 v18, -v18, v33, v26                              // 00000000B100: D6130012 246A4312
	v_fma_f32 v17, -v17, v31, v25                              // 00000000B108: D6130011 24663F11
	v_fma_f32 v25, -v22, v30, v32                              // 00000000B110: D6130019 24823D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B118: BF870191
	v_fmac_f32_e32 v30, v25, v27                               // 00000000B11C: 563C3719
	v_div_fmas_f32 v17, v17, v20, v31                          // 00000000B120: D6370011 047E2911
	s_mov_b32 vcc_lo, s1                                       // 00000000B128: BEEA0001
	s_mul_hi_i32 s1, s68, 0x3000                               // 00000000B12C: 9701FF44 00003000
	v_div_fmas_f32 v18, v18, v21, v33                          // 00000000B134: D6370012 04862B12
	v_fma_f32 v16, -v22, v30, v32                              // 00000000B13C: D6130010 24823D16
	v_div_fixup_f32 v6, v17, v6, 1.0                           // 00000000B144: D6270006 03CA0D11
	v_fmac_f32_e32 v45, v28, v24                               // 00000000B14C: 565A311C
	s_mov_b32 vcc_lo, s4                                       // 00000000B150: BEEA0004
	v_div_fixup_f32 v12, v18, v12, 1.0                         // 00000000B154: D627000C 03CA1912
	s_addc_u32 s1, s54, s1                                     // 00000000B15C: 82010136
	v_mul_f32_e32 v6, v6, v15                                  // 00000000B160: 100C1F06
	v_fma_f32 v19, -v19, v45, v29                              // 00000000B164: D6130013 24765B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000000B16C: BF8701C1
	v_div_fmas_f32 v17, v19, v24, v45                          // 00000000B170: D6370011 04B63113
	s_mov_b32 vcc_lo, s5                                       // 00000000B178: BEEA0005
	v_div_fmas_f32 v15, v16, v27, v30                          // 00000000B17C: D637000F 047A3710
	v_bfe_u32 v16, v6, 16, 1                                   // 00000000B184: D6100010 02052106
	v_div_fixup_f32 v13, v17, v13, 1.0                         // 00000000B18C: D627000D 03CA1B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B194: BF870193
	v_div_fixup_f32 v14, v15, v14, 1.0                         // 00000000B198: D627000E 03CA1D0F
	v_add3_u32 v6, v6, v16, 0x7fff                             // 00000000B1A0: D6550006 03FE2106 00007FFF
	.long 0x7f1e3880                                           // 00000000B1AC: 7F1E3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B1B0: BF870193
	v_dual_mul_f32 v5, v14, v5 :: v_dual_mul_f32 v4, v4, v10   // 00000000B1B4: C8C60B0E 05041504
	.long 0x7e1e3986                                           // 00000000B1BC: 7E1E3986
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B1C0: BF870192
	v_bfe_u32 v6, v5, 16, 1                                    // 00000000B1C4: D6100006 02052105
	v_mul_f32_e32 v4, v12, v4                                  // 00000000B1CC: 1008090C
	v_mul_f32_e32 v12, v13, v23                                // 00000000B1D0: 10182F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B1D4: BF870193
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000000B1D8: D6550005 03FE0D05 00007FFF
	v_bfe_u32 v13, v4, 16, 1                                   // 00000000B1E4: D610000D 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B1EC: BF870113
	v_bfe_u32 v14, v12, 16, 1                                  // 00000000B1F0: D610000E 0205210C
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000000B1F8: D6550004 03FE1B04 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B204: BF870112
	v_add3_u32 v12, v12, v14, 0x7fff                           // 00000000B208: D655000C 03FE1D0C 00007FFF
	v_and_or_b32 v4, 0xffff0000, v4, v15                       // 00000000B214: D6570004 043E08FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B220: BF870092
	.long 0x7e1e398c                                           // 00000000B224: 7E1E398C
	v_and_or_b32 v5, 0xffff0000, v5, v15                       // 00000000B228: D6570005 043E0AFF FFFF0000
	global_store_b64 v7, v[4:5], s[0:1]                        // 00000000B234: DC6E0000 00000407
	s_add_i32 s66, s66, s52                                    // 00000000B23C: 81423442
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000B240: BF8704A9
	s_cmp_ge_i32 s66, s33                                      // 00000000B244: BF032142
	s_cselect_b32 s0, -1, 0                                    // 00000000B248: 980080C1
	s_or_b32 s0, s49, s0                                       // 00000000B24C: 8C000031
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000B250: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000B254: 8B6A007E
	s_cbranch_vccnz 200                                        // 00000000B258: BFA400C8 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x307c>
	s_mul_f32 s0, s65, 0x3c000000                              // 00000000B25C: A200FF41 3C000000
	s_waitcnt lgkmcnt(0)                                       // 00000000B264: BF89FC07
	v_lshlrev_b32_e32 v13, 16, v2                              // 00000000B268: 301A0490
	v_lshlrev_b32_e32 v21, 16, v3                              // 00000000B26C: 302A0690
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000000B270: 360606FF FFFF0000
	s_add_f32 s0, s0, 0x358637bd                               // 00000000B278: A000FF00 358637BD
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000000B280: BF8704BB
	s_mul_f32 s1, s0, 0x4b800000                               // 00000000B284: A201FF00 4B800000
	v_and_b32_e32 v5, 0xffff0000, v80                          // 00000000B28C: 360AA0FF FFFF0000
	s_cmp_lt_f32 s0, 0x800000                                  // 00000000B294: BF41FF00 00800000
	v_mov_b32_e32 v14, s1                                      // 00000000B29C: 7E1C0201
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000B2A0: BF870122
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_lshlrev_b32 v4, 16, v80// 00000000B2A4: C8E20AFF 0504A090 BFB8AA3B
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000B2B0: 986A80C1
	v_cndmask_b32_e32 v14, s0, v14, vcc_lo                     // 00000000B2B4: 021C1C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B2B8: BF870192
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000000B2BC: 100808FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 00000000B2C4: 7E0A4B05
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000000B2C8: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B2D0: BF870113
	v_rsq_f32_e32 v14, v14                                     // 00000000B2D4: 7E1C5D0E
	v_exp_f32_e32 v4, v4                                       // 00000000B2D8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B2DC: BF870097
	v_add_f32_e32 v5, 1.0, v5                                  // 00000000B2E0: 060A0AF2
	v_div_scale_f32 v16, null, v5, v5, 1.0                     // 00000000B2E4: D6FC7C10 03CA0B05
	v_div_scale_f32 v24, s1, 1.0, v5, 1.0                      // 00000000B2EC: D6FC0118 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000B2F4: BF870292
	v_rcp_f32_e32 v19, v16                                     // 00000000B2F8: 7E265510
	v_fma_f32 v29, -v16, v19, 1.0                              // 00000000B2FC: D613001D 23CA2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000000B304: BF870311
	v_dual_fmac_f32 v19, v29, v19 :: v_dual_lshlrev_b32 v6, 16, v81// 00000000B308: C822271D 1306A290
	v_add_f32_e32 v4, 1.0, v4                                  // 00000000B310: 060808F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B314: BF870112
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_mul_f32 v31, v24, v19// 00000000B318: C8C60CFF 061E2718 BFB8AA3B
	v_div_scale_f32 v15, null, v4, v4, 1.0                     // 00000000B324: D6FC7C0F 03CA0904
	v_div_scale_f32 v23, s0, 1.0, v4, 1.0                      // 00000000B32C: D6FC0017 03CA08F2
	v_mul_f32_e32 v26, 0x45800000, v14                         // 00000000B334: 10341CFF 45800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B33C: BF870194
	v_exp_f32_e32 v6, v6                                       // 00000000B340: 7E0C4B06
	v_rcp_f32_e32 v18, v15                                     // 00000000B344: 7E24550F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000000B348: BF8704B1
	v_cndmask_b32_e32 v14, v14, v26, vcc_lo                    // 00000000B34C: 021C350E
	s_mov_b32 vcc_lo, s0                                       // 00000000B350: BEEA0000
	s_mul_i32 s0, s66, 0x3000                                  // 00000000B354: 9600FF42 00003000
	s_add_u32 s0, s53, s0                                      // 00000000B35C: 80000035
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 00000000B360: BF870086
	v_dual_mul_f32 v21, v14, v21 :: v_dual_add_f32 v6, 1.0, v6 // 00000000B364: C8C82B0E 15060CF2
	v_mul_f32_e32 v3, v14, v3                                  // 00000000B36C: 1006070E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000B370: BF870225
	v_fma_f32 v28, -v15, v18, 1.0                              // 00000000B374: D613001C 23CA250F
	v_mul_f32_e32 v13, v14, v13                                // 00000000B37C: 101A1B0E
	v_div_scale_f32 v17, null, v6, v6, 1.0                     // 00000000B380: D6FC7C11 03CA0D06
	v_div_scale_f32 v27, s4, 1.0, v6, 1.0                      // 00000000B388: D6FC041B 03CA0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000B390: BF870224
	v_fmac_f32_e32 v18, v28, v18                               // 00000000B394: 5624251C
	v_dual_mul_f32 v3, v3, v8 :: v_dual_and_b32 v12, 0xffff0000, v81// 00000000B398: C8E41103 030CA2FF FFFF0000
	v_rcp_f32_e32 v22, v17                                     // 00000000B3A4: 7E2C5511
	v_mul_f32_e32 v9, v13, v9                                  // 00000000B3A8: 1012130D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B3AC: BF870092
	v_dual_mul_f32 v29, v23, v18 :: v_dual_mul_f32 v12, 0xbfb8aa3b, v12// 00000000B3B0: C8C62517 1D0C18FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 00000000B3BC: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B3C0: BF870096
	v_fma_f32 v26, -v17, v22, 1.0                              // 00000000B3C4: D613001A 23CA2D11
	v_fmac_f32_e32 v22, v26, v22                               // 00000000B3CC: 562C2D1A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000B3D0: BF870003
	v_fma_f32 v26, -v15, v29, v23                              // 00000000B3D4: D613001A 245E3B0F
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 00000000B3DC: BF870105
	v_dual_add_f32 v12, 1.0, v12 :: v_dual_mul_f32 v13, v27, v22// 00000000B3E0: C90618F2 0C0C2D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000B3E8: BF870121
	v_div_scale_f32 v20, null, v12, v12, 1.0                   // 00000000B3EC: D6FC7C14 03CA190C
	v_div_scale_f32 v30, s5, 1.0, v12, 1.0                     // 00000000B3F4: D6FC051E 03CA18F2
	v_rcp_f32_e32 v25, v20                                     // 00000000B3FC: 7E325514
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B400: BF870095
	v_fma_f32 v28, -v20, v25, 1.0                              // 00000000B404: D613001C 23CA3314
	v_dual_fmac_f32 v25, v28, v25 :: v_dual_mul_f32 v2, v14, v2// 00000000B40C: C806331C 1902050E
	v_fma_f32 v28, -v16, v31, v24                              // 00000000B414: D613001C 24623F10
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000B41C: BF870002
	v_mul_f32_e32 v2, v2, v10                                  // 00000000B420: 10041502
	v_mul_f32_e32 v10, v21, v11                                // 00000000B424: 10141715
	v_fma_f32 v11, -v17, v13, v27                              // 00000000B428: D613000B 246E1B11
	v_mul_f32_e32 v21, v30, v25                                // 00000000B430: 102A331E
	v_fmac_f32_e32 v29, v26, v18                               // 00000000B434: 563A251A
	v_fmac_f32_e32 v31, v28, v19                               // 00000000B438: 563E271C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000B43C: BF870214
	v_fmac_f32_e32 v13, v11, v22                               // 00000000B440: 561A2D0B
	v_fma_f32 v11, -v20, v21, v30                              // 00000000B444: D613000B 247A2B14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000B44C: BF870214
	v_fma_f32 v15, -v15, v29, v23                              // 00000000B450: D613000F 245E3B0F
	v_fma_f32 v16, -v16, v31, v24                              // 00000000B458: D6130010 24623F10
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000B460: BF870214
	v_fma_f32 v17, -v17, v13, v27                              // 00000000B464: D6130011 246E1B11
	v_fmac_f32_e32 v21, v11, v25                               // 00000000B46C: 562A330B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000B470: BF870004
	v_div_fmas_f32 v15, v15, v18, v29                          // 00000000B474: D637000F 0476250F
	s_mov_b32 vcc_lo, s1                                       // 00000000B47C: BEEA0001
	s_mul_hi_i32 s1, s66, 0x3000                               // 00000000B480: 9701FF42 00003000
	v_div_fmas_f32 v11, v16, v19, v31                          // 00000000B488: D637000B 047E2710
	v_fma_f32 v14, -v20, v21, v30                              // 00000000B490: D613000E 247A2B14
	v_div_fixup_f32 v4, v15, v4, 1.0                           // 00000000B498: D6270004 03CA090F
	s_mov_b32 vcc_lo, s4                                       // 00000000B4A0: BEEA0004
	s_addc_u32 s1, s54, s1                                     // 00000000B4A4: 82010136
	v_div_fmas_f32 v13, v17, v22, v13                          // 00000000B4A8: D637000D 04362D11
	s_mov_b32 vcc_lo, s5                                       // 00000000B4B0: BEEA0005
	v_mul_f32_e32 v4, v4, v9                                   // 00000000B4B4: 10081304
	v_div_fmas_f32 v9, v14, v25, v21                           // 00000000B4B8: D6370009 0456330E
	v_div_fixup_f32 v5, v11, v5, 1.0                           // 00000000B4C0: D6270005 03CA0B0B
	v_div_fixup_f32 v6, v13, v6, 1.0                           // 00000000B4C8: D6270006 03CA0D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000B4D0: BF870214
	v_bfe_u32 v11, v4, 16, 1                                   // 00000000B4D4: D610000B 02052104
	v_div_fixup_f32 v8, v9, v12, 1.0                           // 00000000B4DC: D6270008 03CA1909
	.long 0x7f123880                                           // 00000000B4E4: 7F123880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B4E8: BF870193
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000000B4EC: D6550004 03FE1704 00007FFF
	v_dual_mul_f32 v3, v8, v3 :: v_dual_mul_f32 v2, v5, v2     // 00000000B4F8: C8C60708 03020505
	v_mul_f32_e32 v5, v6, v10                                  // 00000000B500: 100A1506
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B504: BF870193
	.long 0x7e123984                                           // 00000000B508: 7E123984
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000B50C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000B514: BF870214
	v_bfe_u32 v6, v2, 16, 1                                    // 00000000B518: D6100006 02052102
	v_bfe_u32 v8, v5, 16, 1                                    // 00000000B520: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000B528: BF870193
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000000B52C: D6550003 03FE0903 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 00000000B538: D6550002 03FE0D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B544: BF870113
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000000B548: D6550005 03FE1105 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v9                        // 00000000B554: D6570002 042604FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000B560: BF870092
	.long 0x7e123985                                           // 00000000B564: 7E123985
	v_and_or_b32 v3, 0xffff0000, v3, v9                        // 00000000B568: D6570003 042606FF FFFF0000
	global_store_b64 v7, v[2:3], s[0:1]                        // 00000000B574: DC6E0000 00000207
	s_mov_b32 s1, 0                                            // 00000000B57C: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000B580: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000000B584: 8B6A017E
	s_cbranch_vccz 531                                         // 00000000B588: BFA30213 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x38d8>
	s_mov_b32 s0, exec_lo                                      // 00000000B58C: BE80007E
	v_cmpx_gt_u32_e32 16, v44                                  // 00000000B590: 7D985890
	s_cbranch_execz 527                                        // 00000000B594: BFA5020F <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x38d4>
	v_cmp_eq_u32_e32 vcc_lo, 0, v44                            // 00000000B598: 7C945880
	ds_load_b128 v[52:55], v1 offset:27600                     // 00000000B59C: DBFC6BD0 34000001
	s_waitcnt lgkmcnt(9)                                       // 00000000B5A4: BF89FC97
	ds_load_b128 v[56:59], v1 offset:27616                     // 00000000B5A8: DBFC6BE0 38000001
	s_waitcnt lgkmcnt(2)                                       // 00000000B5B0: BF89FC27
	ds_load_b96 v[14:16], v1 offset:27632                      // 00000000B5B4: DBF86BF0 0E000001
	ds_load_b128 v[10:13], v1 offset:27520                     // 00000000B5BC: DBFC6B80 0A000001
	ds_load_b128 v[6:9], v1 offset:27536                       // 00000000B5C4: DBFC6B90 06000001
	ds_load_b128 v[2:5], v1 offset:27552                       // 00000000B5CC: DBFC6BA0 02000001
	ds_load_b64 v[17:18], v1 offset:27568                      // 00000000B5D4: D9D86BB0 11000001
	v_cndmask_b32_e64 v45, 0, 1.0, vcc_lo                      // 00000000B5DC: D501002D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v44                            // 00000000B5E4: 7C945881
	ds_load_b128 v[46:49], v1 offset:27584                     // 00000000B5E8: DBFC6BC0 2E000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000000B5F0: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v44                            // 00000000B5F8: 7C945882
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000000B5FC: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v44                            // 00000000B604: 7C945883
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000000B608: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v44                            // 00000000B610: 7C945884
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000000B614: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v44                            // 00000000B61C: 7C945885
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000000B620: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v44                            // 00000000B628: 7C945886
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000000B62C: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v44                            // 00000000B634: 7C945887
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000000B638: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v44                            // 00000000B640: 7C945888
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000000B644: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v44                            // 00000000B64C: 7C945889
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000000B650: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v44                           // 00000000B658: 7C94588A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000000B65C: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v44                           // 00000000B664: 7C94588B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000000B668: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v44                           // 00000000B670: 7C94588C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000000B674: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v44                           // 00000000B67C: 7C94588D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000000B680: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v44                           // 00000000B688: 7C94588E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000000B68C: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v44                           // 00000000B694: 7C94588F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000000B698: D5010013 01A9E480
	s_waitcnt lgkmcnt(5)                                       // 00000000B6A0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000B6A4: BF870001
	v_fmac_f32_e32 v21, v19, v16                               // 00000000B6A8: 562A2113
	v_fmac_f32_e32 v22, v19, v15                               // 00000000B6AC: 562C1F13
	v_fmac_f32_e32 v29, v19, v52                               // 00000000B6B0: 563A6913
	v_fmac_f32_e32 v28, v19, v54                               // 00000000B6B4: 56386D13
	v_fmac_f32_e32 v26, v19, v58                               // 00000000B6B8: 56347513
	s_waitcnt lgkmcnt(1)                                       // 00000000B6BC: BF89FC17
	v_dual_fmac_f32 v27, v19, v55 :: v_dual_fmac_f32 v22, v21, v18// 00000000B6C0: C8006F13 1B162515
	v_fmac_f32_e32 v23, v19, v57                               // 00000000B6C8: 562E7313
	v_dual_fmac_f32 v24, v19, v59 :: v_dual_fmac_f32 v29, v21, v6// 00000000B6CC: C8007713 181C0D15
	v_fmac_f32_e32 v25, v19, v56                               // 00000000B6D4: 56327113
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000B6D8: BF870003
	v_dual_fmac_f32 v20, v19, v14 :: v_dual_fmac_f32 v23, v21, v3// 00000000B6DC: C8001D13 14160715
	v_fmac_f32_e32 v28, v21, v8                                // 00000000B6E4: 56381115
	v_fmac_f32_e32 v26, v21, v4                                // 00000000B6E8: 56340915
	v_fmac_f32_e32 v24, v21, v5                                // 00000000B6EC: 56300B15
	v_fmac_f32_e32 v25, v21, v2                                // 00000000B6F0: 56320515
	ds_load_b128 v[2:5], v1 offset:27424                       // 00000000B6F4: DBFC6B20 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000000B6FC: BF89FC17
	v_fmac_f32_e32 v33, v19, v47                               // 00000000B700: 56425F13
	v_fmac_f32_e32 v30, v19, v53                               // 00000000B704: 563C6B13
	ds_load_b128 v[52:55], v1 offset:27456                     // 00000000B708: DBFC6B40 34000001
	ds_load_b128 v[56:59], v1 offset:27488                     // 00000000B710: DBFC6B60 38000001
	ds_load_b128 v[158:161], v1 offset:27472                   // 00000000B718: DBFC6B50 9E000001
	ds_load_b32 v14, v1 offset:27504                           // 00000000B720: D8D86B70 0E000001
	ds_load_b32 v18, v1 offset:27232                           // 00000000B728: D8D86A60 12000001
	v_fmac_f32_e32 v33, v21, v11                               // 00000000B730: 56421715
	v_dual_fmac_f32 v31, v19, v49 :: v_dual_fmac_f32 v30, v21, v7// 00000000B734: C8006313 1F1E0F15
	s_waitcnt lgkmcnt(2)                                       // 00000000B73C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000B740: BF870001
	v_fmac_f32_e32 v30, v22, v159                              // 00000000B744: 563D3F16
	v_fmac_f32_e32 v32, v19, v48                               // 00000000B748: 56406113
	v_fmac_f32_e32 v45, v19, v46                               // 00000000B74C: 565A5D13
	v_fmac_f32_e32 v31, v21, v13                               // 00000000B750: 563E1B15
	v_fmac_f32_e32 v27, v21, v9                                // 00000000B754: 56361315
	ds_load_b128 v[46:49], v1 offset:28416                     // 00000000B758: DBFC6F00 2E000001
	v_fmac_f32_e32 v32, v21, v12                               // 00000000B760: 56401915
	v_fmac_f32_e32 v45, v21, v10                               // 00000000B764: 565A1515
	ds_load_b128 v[6:9], v1 offset:27408                       // 00000000B768: DBFC6B10 06000001
	ds_load_b128 v[10:13], v1 offset:27392                     // 00000000B770: DBFC6B00 0A000001
	v_fmac_f32_e32 v20, v21, v17                               // 00000000B778: 56282315
	v_fmac_f32_e32 v32, v22, v54                               // 00000000B77C: 56406D16
	v_fmac_f32_e32 v45, v22, v52                               // 00000000B780: 565A6916
	s_waitcnt lgkmcnt(4)                                       // 00000000B784: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000B788: BF870003
	v_fmac_f32_e32 v20, v22, v14                               // 00000000B78C: 56281D16
	ds_load_b128 v[14:17], v1 offset:27328                     // 00000000B790: DBFC6AC0 0E000001
	v_fmac_f32_e32 v33, v22, v53                               // 00000000B798: 56426B16
	v_fmac_f32_e32 v24, v22, v59                               // 00000000B79C: 56307716
	v_fmac_f32_e32 v25, v22, v56                               // 00000000B7A0: 56327116
	ds_load_b64 v[59:60], v1 offset:27296                      // 00000000B7A4: D9D86AA0 3B000001
	v_fmac_f32_e32 v24, v20, v5                                // 00000000B7AC: 56300B14
	s_waitcnt lgkmcnt(2)                                       // 00000000B7B0: BF89FC27
	v_fmac_f32_e32 v32, v20, v12                               // 00000000B7B4: 56401914
	v_dual_fmac_f32 v26, v22, v58 :: v_dual_fmac_f32 v33, v20, v11// 00000000B7B8: C8007516 1A201714
	s_waitcnt lgkmcnt(1)                                       // 00000000B7C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B7C4: BF870112
	v_dual_fmac_f32 v23, v22, v57 :: v_dual_fmac_f32 v32, v24, v16// 00000000B7C8: C8007316 17202118
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v28, v22, v160// 00000000B7D0: C8001F18 211D4116
	v_fmac_f32_e32 v45, v20, v10                               // 00000000B7D8: 565A1514
	v_fmac_f32_e32 v31, v22, v55                               // 00000000B7DC: 563E6F16
	ds_load_b128 v[52:55], v1 offset:27344                     // 00000000B7E0: DBFC6AD0 34000001
	ds_load_b96 v[56:58], v1 offset:27360                      // 00000000B7E8: DBF86AE0 38000001
	v_dual_fmac_f32 v29, v22, v158 :: v_dual_fmac_f32 v30, v20, v7// 00000000B7F0: C8013D16 1D1E0F14
	v_dual_fmac_f32 v27, v22, v161 :: v_dual_fmac_f32 v26, v20, v4// 00000000B7F8: C8014316 1B1A0914
	v_fmac_f32_e32 v28, v20, v8                                // 00000000B800: 56381114
	v_fmac_f32_e32 v31, v20, v13                               // 00000000B804: 563E1B14
	s_waitcnt lgkmcnt(0)                                       // 00000000B808: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000B80C: BF870003
	v_fmac_f32_e32 v26, v24, v58                               // 00000000B810: 56347518
	v_fmac_f32_e32 v29, v20, v6                                // 00000000B814: 563A0D14
	v_fmac_f32_e32 v30, v24, v53                               // 00000000B818: 563C6B18
	v_fmac_f32_e32 v27, v20, v9                                // 00000000B81C: 56361314
	ds_load_b128 v[6:9], v1 offset:27280                       // 00000000B820: DBFC6A90 06000001
	ds_load_b128 v[10:13], v1 offset:27264                     // 00000000B828: DBFC6A80 0A000001
	s_waitcnt lgkmcnt(0)                                       // 00000000B830: BF89FC07
	v_dual_fmac_f32 v28, v24, v54 :: v_dual_fmac_f32 v33, v26, v11// 00000000B834: C8006D18 1C20171A
	v_dual_fmac_f32 v32, v26, v12 :: v_dual_fmac_f32 v45, v24, v14// 00000000B83C: C800191A 202C1D18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B844: BF870112
	v_dual_fmac_f32 v25, v20, v2 :: v_dual_fmac_f32 v28, v26, v8// 00000000B848: C8000514 191C111A
	v_fmac_f32_e32 v45, v26, v10                               // 00000000B850: 565A151A
	v_dual_fmac_f32 v30, v26, v7 :: v_dual_fmac_f32 v31, v24, v17// 00000000B854: C8000F1A 1E1E2318
	ds_load_b128 v[14:17], v1 offset:27216                     // 00000000B85C: DBFC6A50 0E000001
	v_fmac_f32_e32 v25, v24, v56                               // 00000000B864: 56327118
	v_fmac_f32_e32 v31, v26, v13                               // 00000000B868: 563E1B1A
	ds_load_b128 v[10:13], v1 offset:27136                     // 00000000B86C: DBFC6A00 0A000001
	v_fmac_f32_e32 v23, v20, v3                                // 00000000B874: 562E0714
	ds_load_b128 v[2:5], v1 offset:27200                       // 00000000B878: DBFC6A40 02000001
	v_fmac_f32_e32 v25, v26, v59                               // 00000000B880: 5632771A
	v_fmac_f32_e32 v23, v24, v57                               // 00000000B884: 562E7318
	ds_load_b96 v[56:58], v1 offset:27088                      // 00000000B888: DBF869D0 38000001
	v_fmac_f32_e32 v23, v26, v60                               // 00000000B890: 562E791A
	v_fmac_f32_e32 v27, v24, v55                               // 00000000B894: 56366F18
	ds_load_b64 v[59:60], v1 offset:27024                      // 00000000B898: D9D86990 3B000001
	v_fmac_f32_e32 v25, v23, v18                               // 00000000B8A0: 56322517
	s_waitcnt lgkmcnt(4)                                       // 00000000B8A4: BF89FC47
	v_fmac_f32_e32 v28, v23, v16                               // 00000000B8A8: 56382117
	v_fmac_f32_e32 v29, v24, v52                               // 00000000B8AC: 563A6918
	ds_load_b128 v[52:55], v1 offset:27152                     // 00000000B8B0: DBFC6A10 34000001
	v_fmac_f32_e32 v30, v23, v15                               // 00000000B8B8: 563C1F17
	s_waitcnt lgkmcnt(3)                                       // 00000000B8BC: BF89FC37
	v_fmac_f32_e32 v33, v23, v3                                // 00000000B8C0: 56420717
	v_fmac_f32_e32 v27, v26, v9                                // 00000000B8C4: 5636131A
	s_waitcnt lgkmcnt(0)                                       // 00000000B8C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000B8CC: BF8700C1
	v_dual_fmac_f32 v27, v23, v17 :: v_dual_fmac_f32 v28, v25, v54// 00000000B8D0: C8002317 1B1C6D19
	v_dual_fmac_f32 v29, v26, v6 :: v_dual_fmac_f32 v30, v25, v53// 00000000B8D8: C8000D1A 1D1E6B19
	ds_load_b128 v[6:9], v1 offset:27072                       // 00000000B8E0: DBFC69C0 06000001
	v_fmac_f32_e32 v27, v25, v55                               // 00000000B8E8: 56366F19
	v_fmac_f32_e32 v30, v27, v57                               // 00000000B8EC: 563C731B
	v_fmac_f32_e32 v29, v23, v14                               // 00000000B8F0: 563A1D17
	v_fmac_f32_e32 v28, v27, v58                               // 00000000B8F4: 5638751B
	v_fmac_f32_e32 v32, v23, v4                                // 00000000B8F8: 56400917
	ds_load_b128 v[14:17], v1 offset:26880                     // 00000000B8FC: DBFC6900 0E000001
	v_fmac_f32_e32 v29, v25, v52                               // 00000000B904: 563A6919
	v_dual_fmac_f32 v30, v28, v60 :: v_dual_fmac_f32 v45, v23, v2// 00000000B908: C800791C 1E2C0517
	v_fmac_f32_e32 v31, v23, v5                                // 00000000B910: 563E0B17
	ds_load_b128 v[2:5], v1 offset:27008                       // 00000000B914: DBFC6980 02000001
	v_fmac_f32_e32 v29, v27, v56                               // 00000000B91C: 563A711B
	v_fmac_f32_e32 v33, v25, v11                               // 00000000B920: 56421719
	v_fmac_f32_e32 v45, v25, v10                               // 00000000B924: 565A1519
	v_fmac_f32_e32 v32, v25, v12                               // 00000000B928: 56401919
	ds_load_b64 v[52:53], v1 offset:26752                      // 00000000B92C: D9D86880 34000001
	v_fmac_f32_e32 v29, v28, v59                               // 00000000B934: 563A771C
	ds_load_b128 v[56:59], v1 offset:28656                     // 00000000B938: DBFC6FF0 38000001
	v_fmac_f32_e32 v31, v25, v13                               // 00000000B940: 563E1B19
	ds_load_b128 v[10:13], v1 offset:26944                     // 00000000B944: DBFC6940 0A000001
	ds_load_b32 v18, v1 offset:26960                           // 00000000B94C: D8D86950 12000001
	s_waitcnt lgkmcnt(6)                                       // 00000000B954: BF89FC67
	v_fmac_f32_e32 v33, v27, v7                                // 00000000B958: 56420F1B
	v_fmac_f32_e32 v32, v27, v8                                // 00000000B95C: 5640111B
	v_fmac_f32_e32 v31, v27, v9                                // 00000000B960: 563E131B
	ds_load_b32 v9, v1 offset:26688                            // 00000000B964: D8D86840 09000001
	s_waitcnt lgkmcnt(5)                                       // 00000000B96C: BF89FC57
	v_fmac_f32_e32 v31, v28, v5                                // 00000000B970: 563E0B1C
	v_fmac_f32_e32 v33, v28, v3                                // 00000000B974: 5642071C
	s_waitcnt lgkmcnt(3)                                       // 00000000B978: BF89FC37
	v_dual_fmac_f32 v32, v28, v4 :: v_dual_mul_f32 v161, v58, v21// 00000000B97C: C806091C 20A02B3A
	s_waitcnt lgkmcnt(2)                                       // 00000000B984: BF89FC27
	v_fmac_f32_e32 v31, v30, v13                               // 00000000B988: 563E1B1E
	s_waitcnt lgkmcnt(1)                                       // 00000000B98C: BF89FC17
	v_fmac_f32_e32 v29, v30, v18                               // 00000000B990: 563A251E
	v_fmac_f32_e32 v33, v30, v11                               // 00000000B994: 5642171E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000B998: BF870002
	v_dual_fmac_f32 v32, v30, v12 :: v_dual_fmac_f32 v31, v29, v17// 00000000B99C: C800191E 201E231D
	v_fmac_f32_e32 v45, v27, v6                                // 00000000B9A4: 565A0D1B
	ds_load_b96 v[6:8], v1 offset:26816                        // 00000000B9A8: DBF868C0 06000001
	v_fmac_f32_e32 v33, v29, v15                               // 00000000B9B0: 56421F1D
	v_dual_fmac_f32 v32, v29, v16 :: v_dual_fmac_f32 v45, v28, v2// 00000000B9B4: C800211D 202C051C
	ds_load_b128 v[2:5], v1 offset:28608                       // 00000000B9BC: DBFC6FC0 02000001
	v_fmac_f32_e32 v45, v30, v10                               // 00000000B9C4: 565A151E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000B9C8: BF8700A1
	v_fmac_f32_e32 v45, v29, v14                               // 00000000B9CC: 565A1D1D
	s_waitcnt lgkmcnt(1)                                       // 00000000B9D0: BF89FC17
	v_fmac_f32_e32 v45, v31, v6                                // 00000000B9D4: 565A0D1F
	v_fmac_f32_e32 v32, v31, v8                                // 00000000B9D8: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 00000000B9DC: 56420F1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000B9E0: BF870112
	v_fmac_f32_e32 v45, v32, v52                               // 00000000B9E4: 565A6920
	v_fmac_f32_e32 v33, v32, v53                               // 00000000B9E8: 56426B20
	ds_load_b128 v[52:55], v1 offset:28640                     // 00000000B9EC: DBFC6FE0 34000001
	s_waitcnt lgkmcnt(1)                                       // 00000000B9F4: BF89FC17
	v_fma_mixlo_f16 v60, v5, v31, 0                            // 00000000B9F8: CC21003C 02023F05
	v_fmac_f32_e32 v45, v33, v9                                // 00000000BA00: 565A1321
	ds_load_b128 v[6:9], v1 offset:28624                       // 00000000BA04: DBFC6FD0 06000001
	ds_load_b128 v[10:13], v1 offset:28464                     // 00000000BA0C: DBFC6F30 0A000001
	v_mul_f32_e32 v15, v3, v33                                 // 00000000BA14: 101E4303
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000000BA18: CC210012 02024303
	v_mul_f32_e32 v14, v2, v45                                 // 00000000BA20: 101C5B02
	v_fma_mixlo_f16 v2, v2, v45, 0                             // 00000000BA24: CC210002 02025B02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000BA2C: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000000BA30: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000000BA38: CC200003 1C39E702
	.long 0x7f043912                                           // 00000000BA40: 7F043912
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000BA44: BF870223
	.long 0x7f1c150f                                           // 00000000BA48: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000000BA4C: 101E4104
	v_cvt_f16_f32_e32 v14, v3                                  // 00000000BA50: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000000BA54: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000000BA5C: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 00000000BA60: BF89FC27
	v_fma_mixlo_f16 v158, v53, v23, 0                          // 00000000BA64: CC21009E 02022F35
	s_waitcnt lgkmcnt(1)                                       // 00000000BA6C: BF89FC17
	v_dual_mul_f32 v5, v6, v29 :: v_dual_mul_f32 v16, v7, v30  // 00000000BA70: C8C63B06 05103D07
	v_fma_mixlo_f16 v61, v7, v30, 0                            // 00000000BA78: CC21003D 02023D07
	v_fma_mix_f32 v17, v60, -1.0, v4 op_sel_hi:[1,1,0]         // 00000000BA80: CC200011 1C11E73C
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000000BA88: CC210004 02023B06
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000000BA90: CC200007 1C3DE703
	v_fma_mixlo_f16 v62, v9, v27, 0                            // 00000000BA98: CC21003E 02023709
	v_fma_mix_f32 v6, v61, -1.0, v16 op_sel_hi:[1,1,0]         // 00000000BAA0: CC200006 1C41E73D
	.long 0x7f1e1511                                           // 00000000BAA8: 7F1E1511
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000000BAAC: CC200005 1C15E704
	v_cvt_f16_f32_e32 v15, v7                                  // 00000000BAB4: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000000BAB8: 100E3908
	.long 0x7f201506                                           // 00000000BABC: 7F201506
	v_fma_mixlo_f16 v6, v52, v25, 0                            // 00000000BAC0: CC210006 02023334
	v_cvt_f16_f32_e32 v16, v5                                  // 00000000BAC8: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000000BACC: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v52, v25  // 00000000BAD4: C8C63709 08083334
	v_dual_mul_f32 v52, v53, v23 :: v_dual_mul_f32 v53, v54, v26// 00000000BADC: C8C62F35 34343536
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000BAE4: BF870193
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000000BAE8: CC200007 1C1DE705
	v_fma_mix_f32 v8, v62, -1.0, v8 op_sel_hi:[1,1,0]          // 00000000BAF0: CC200008 1C21E73E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000BAF8: BF870214
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000000BAFC: CC200009 1C25E706
	v_fma_mix_f32 v159, v158, -1.0, v52 op_sel_hi:[1,1,0]      // 00000000BB04: CC20009F 1CD1E79E
	.long 0xd59c4006                                           // 00000000BB0C: D59C4006
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                   // 00000000BB10: 0201019E
	v_cvt_f16_f32_e32 v17, v7                                  // 00000000BB14: 7E221507
	v_fma_mixlo_f16 v7, v54, v26, 0                            // 00000000BB18: CC210007 02023536
	.long 0x7f221508                                           // 00000000BB20: 7F221508
	v_cvt_f16_f32_e32 v52, v9                                  // 00000000BB24: 7E681509
	.long 0xd58a4034                                           // 00000000BB28: D58A4034
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                   // 00000000BB2C: 0201019F
	v_mul_f32_e32 v9, v55, v24                                 // 00000000BB30: 10123137
	v_fma_mix_f32 v8, v7, -1.0, v53 op_sel_hi:[1,1,0]          // 00000000BB34: CC200008 1CD5E707
	v_fma_mixlo_f16 v159, v55, v24, 0                          // 00000000BB3C: CC21009F 02023137
	v_dual_mul_f32 v54, v56, v20 :: v_dual_mul_f32 v55, v57, v22// 00000000BB44: C8C62938 36362D39
	v_fma_mixlo_f16 v57, v57, v22, 0                           // 00000000BB4C: CC210039 02022D39
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000BB54: BF870214
	v_cvt_f16_f32_e32 v53, v8                                  // 00000000BB58: 7E6A1508
	v_fma_mix_f32 v160, v159, -1.0, v9 op_sel_hi:[1,1,0]       // 00000000BB5C: CC2000A0 1C25E79F
	v_fma_mixlo_f16 v8, v56, v20, 0                            // 00000000BB64: CC210008 02022938
	v_fma_mixlo_f16 v9, v58, v21, 0                            // 00000000BB6C: CC210009 02022B3A
	v_fma_mix_f32 v55, v57, -1.0, v55 op_sel_hi:[1,1,0]        // 00000000BB74: CC200037 1CDDE739
	v_mul_f32_e32 v58, v59, v19                                // 00000000BB7C: 1074273B
	v_fma_mixlo_f16 v59, v59, v19, 0                           // 00000000BB80: CC21003B 0202273B
	v_fma_mix_f32 v54, v8, -1.0, v54 op_sel_hi:[1,1,0]         // 00000000BB88: CC200036 1CD9E708
	v_fma_mix_f32 v56, v9, -1.0, v161 op_sel_hi:[1,1,0]        // 00000000BB90: CC200038 1E85E709
	.long 0xd58a4035                                           // 00000000BB98: D58A4035
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                   // 00000000BB9C: 020101A0
	.long 0x7f103939                                           // 00000000BBA0: 7F103939
	v_fma_mix_f32 v160, v59, -1.0, v58 op_sel_hi:[1,1,0]       // 00000000BBA4: CC2000A0 1CE9E73B
	v_cvt_f16_f32_e32 v54, v54                                 // 00000000BBAC: 7E6C1536
	.long 0x7f6c1537                                           // 00000000BBB0: 7F6C1537
	v_cvt_f16_f32_e32 v55, v56                                 // 00000000BBB4: 7E6E1538
	.long 0x7f12393b                                           // 00000000BBB8: 7F12393B
	ds_load_b128 v[56:59], v1 offset:28432                     // 00000000BBBC: DBFC6F10 38000001
	v_mul_u32_u24_e32 v161, 48, v44                            // 00000000BBC4: 174258B0
	.long 0xd59c4007                                           // 00000000BBC8: D59C4007
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                   // 00000000BBCC: 0201019F
	.long 0x7f06393c                                           // 00000000BBD0: 7F06393C
	.long 0x7f08393d                                           // 00000000BBD4: 7F08393D
	.long 0x7f0a393e                                           // 00000000BBD8: 7F0A393E
	v_mul_f32_e32 v18, v46, v45                                // 00000000BBDC: 10245B2E
	v_fma_mixlo_f16 v44, v46, v45, 0                           // 00000000BBE0: CC21002C 02025B2E
	v_mul_f32_e32 v45, v47, v33                                // 00000000BBE8: 105A432F
	v_fma_mixlo_f16 v33, v47, v33, 0                           // 00000000BBEC: CC210021 0202432F
	ds_store_b128 v161, v[6:9] offset:23568                    // 00000000BBF4: DB7C5C10 000006A1
	ds_store_b128 v161, v[2:5] offset:23552                    // 00000000BBFC: DB7C5C00 000002A1
	ds_load_b128 v[2:5], v1 offset:28448                       // 00000000BC04: DBFC6F20 02000001
	v_fma_mix_f32 v18, v44, -1.0, v18 op_sel_hi:[1,1,0]        // 00000000BC0C: CC200012 1C49E72C
	v_mul_f32_e32 v7, v48, v32                                 // 00000000BC14: 100E4130
	v_fma_mix_f32 v45, v33, -1.0, v45 op_sel_hi:[1,1,0]        // 00000000BC18: CC20002D 1CB5E721
	v_mul_f32_e32 v8, v49, v31                                 // 00000000BC20: 10103F31
	.long 0xd58a4037                                           // 00000000BC24: D58A4037
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                   // 00000000BC28: 020101A0
	v_cvt_f16_f32_e32 v6, v18                                  // 00000000BC2C: 7E0C1512
	v_fma_mixlo_f16 v18, v49, v31, 0                           // 00000000BC30: CC210012 02023F31
	.long 0x7f0c152d                                           // 00000000BC38: 7F0C152D
	v_fma_mixlo_f16 v45, v48, v32, 0                           // 00000000BC3C: CC21002D 02024130
	s_waitcnt lgkmcnt(3)                                       // 00000000BC44: BF89FC37
	v_mul_f32_e32 v9, v56, v29                                 // 00000000BC48: 10123B38
	v_mul_f32_e32 v31, v57, v30                                // 00000000BC4C: 103E3D39
	v_fma_mixlo_f16 v30, v57, v30, 0                           // 00000000BC50: CC21001E 02023D39
	v_fma_mixlo_f16 v46, v56, v29, 0                           // 00000000BC58: CC21002E 02023B38
	v_fma_mix_f32 v7, v45, -1.0, v7 op_sel_hi:[1,1,0]          // 00000000BC60: CC200007 1C1DE72D
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000000BC68: CC200008 1C21E712
	v_fma_mixlo_f16 v47, v58, v28, 0                           // 00000000BC70: CC21002F 0202393A
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000000BC78: CC20001D 1C7DE71E
	v_fma_mix_f32 v9, v46, -1.0, v9 op_sel_hi:[1,1,0]          // 00000000BC80: CC200009 1C25E72E
	v_dual_mul_f32 v31, v58, v28 :: v_dual_mul_f32 v28, v59, v27// 00000000BC88: C8C6393A 1F1C373B
	v_fma_mixlo_f16 v27, v59, v27, 0                           // 00000000BC90: CC21001B 0202373B
	v_cvt_f16_f32_e32 v7, v7                                   // 00000000BC98: 7E0E1507
	.long 0x7f0e1508                                           // 00000000BC9C: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000000BCA0: 7E101509
	.long 0x7f10151d                                           // 00000000BCA4: 7F10151D
	v_fma_mix_f32 v9, v47, -1.0, v31 op_sel_hi:[1,1,0]         // 00000000BCA8: CC200009 1C7DE72F
	s_waitcnt lgkmcnt(0)                                       // 00000000BCB0: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000000BCB4: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000000BCB8: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000000BCC0: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000000BCC4: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000000BCCC: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000000BCD4: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000000BCD8: 102E3504
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000000BCDC: CC20001C 1C75E702
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000000BCE4: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000000BCEC: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000000BCF0: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000000BCF8: 10342D0B
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000000BCFC: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000000BD04: 7F04391F
	.long 0x7f583921                                           // 00000000BD08: 7F583921
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000000BD0C: CC200004 1C5DE703
	v_cvt_f16_f32_e32 v23, v28                                 // 00000000BD14: 7E2E151C
	.long 0x7f2e1519                                           // 00000000BD18: 7F2E1519
	v_mul_f32_e32 v25, v5, v24                                 // 00000000BD1C: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000000BD20: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000000BD28: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000000BD2C: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000000BD30: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000000BD38: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000000BD40: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000000BD48: 10322B0C
	.long 0x7f06391c                                           // 00000000BD4C: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000000BD50: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000000BD58: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000000BD60: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000000BD64: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000000BD6C: 7F08390B
	.long 0x7f5a3912                                           // 00000000BD70: 7F5A3912
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000000BD74: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000000BD7C: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000000BD80: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000000BD88: 7F0A390D
	.long 0x7f5c391e                                           // 00000000BD8C: 7F5C391E
	.long 0x7f5e391b                                           // 00000000BD90: 7F5E391B
	.long 0x7f301516                                           // 00000000BD94: 7F301516
	.long 0x7f321514                                           // 00000000BD98: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000000BD9C: 7E34150C
	.long 0x7f34150a                                           // 00000000BDA0: 7F34150A
	ds_store_b128 v161, v[52:55] offset:24336                  // 00000000BDA4: DB7C5F10 000034A1
	ds_store_b128 v161, v[14:17] offset:24320                  // 00000000BDAC: DB7C5F00 00000EA1
	ds_store_b128 v161, v[2:5] offset:25104                    // 00000000BDB4: DB7C6210 000002A1
	ds_store_b128 v161, v[44:47] offset:25088                  // 00000000BDBC: DB7C6200 00002CA1
	ds_store_b128 v161, v[23:26] offset:25872                  // 00000000BDC4: DB7C6510 000017A1
	ds_store_b128 v161, v[6:9] offset:25856                    // 00000000BDCC: DB7C6500 000006A1
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000BDD4: 8C7E007E
	v_lshlrev_b32_e32 v52, 1, v156                             // 00000000BDD8: 30693881
	s_waitcnt lgkmcnt(0)                                       // 00000000BDDC: BF89FC07
	s_barrier                                                  // 00000000BDE0: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v35                            // 00000000BDE4: 7C944680
	v_mul_u32_u24_e32 v53, 48, v34                             // 00000000BDE8: 166A44B0
	s_cmp_lt_i32 s64, s33                                      // 00000000BDEC: BF042140
	s_waitcnt lgkmcnt(0)                                       // 00000000BDF0: BF89FC07
	ds_load_u16 v2, v52 offset:6416                            // 00000000BDF4: D8F01910 02000034
	ds_load_u16 v3, v52 offset:7776                            // 00000000BDFC: D8F01E60 03000034
	ds_load_u16 v4, v52 offset:7232                            // 00000000BE04: D8F01C40 04000034
	ds_load_u16 v5, v52 offset:6688                            // 00000000BE0C: D8F01A20 05000034
	ds_load_u16 v6, v52 offset:6144                            // 00000000BE14: D8F01800 06000034
	ds_load_b128 v[22:25], v53 offset:24336                    // 00000000BE1C: DBFC5F10 16000035
	ds_load_b128 v[18:21], v53 offset:24320                    // 00000000BE24: DBFC5F00 12000035
	ds_load_b128 v[26:29], v53 offset:23552                    // 00000000BE2C: DBFC5C00 1A000035
	ds_load_b128 v[30:33], v53 offset:23568                    // 00000000BE34: DBFC5C10 1E000035
	s_cselect_b32 s0, -1, 0                                    // 00000000BE3C: 980080C1
	s_or_b32 s1, s64, 1                                        // 00000000BE40: 8C018140
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000BE44: BF870009
	s_cmp_lt_i32 s1, s33                                       // 00000000BE48: BF042101
	s_cselect_b32 s1, -1, 0                                    // 00000000BE4C: 980180C1
	s_waitcnt lgkmcnt(8)                                       // 00000000BE50: BF89FC87
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BE54: 30040490
	s_waitcnt lgkmcnt(4)                                       // 00000000BE58: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000000BE5C: 300C0C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000000BE60: BF8700D2
	.long 0x7f141502                                           // 00000000BE64: 7F141502
	ds_load_u16 v2, v52 offset:6960                            // 00000000BE68: D8F01B30 02000034
	v_cvt_f16_f32_e32 v10, v6                                  // 00000000BE70: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000000BE74: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BE78: 30040490
	.long 0x7f161502                                           // 00000000BE7C: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000000BE80: 30040A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000BE84: BF8700C1
	v_cvt_f16_f32_e32 v11, v2                                  // 00000000BE88: 7E161502
	ds_load_u16 v2, v52 offset:7504                            // 00000000BE8C: D8F01D50 02000034
	s_waitcnt lgkmcnt(0)                                       // 00000000BE94: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BE98: 30040490
	.long 0x7f181502                                           // 00000000BE9C: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000000BEA0: 30040890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000BEA4: BF8700C1
	v_cvt_f16_f32_e32 v12, v2                                  // 00000000BEA8: 7E181502
	ds_load_u16 v2, v52 offset:8048                            // 00000000BEAC: D8F01F70 02000034
	s_waitcnt lgkmcnt(0)                                       // 00000000BEB4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BEB8: 30040490
	.long 0x7f1a1502                                           // 00000000BEBC: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000000BEC0: 30040690
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000BEC4: BF870001
	v_cvt_f16_f32_e32 v13, v2                                  // 00000000BEC8: 7E1A1502
	ds_load_u16 v2, v52 offset:8592                            // 00000000BECC: D8F02190 02000034
	ds_load_u16 v3, v52 offset:9952                            // 00000000BED4: D8F026E0 03000034
	ds_load_u16 v4, v52 offset:9408                            // 00000000BEDC: D8F024C0 04000034
	ds_load_u16 v5, v52 offset:8864                            // 00000000BEE4: D8F022A0 05000034
	ds_load_u16 v6, v52 offset:8320                            // 00000000BEEC: D8F02080 06000034
	s_waitcnt lgkmcnt(4)                                       // 00000000BEF4: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BEF8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000BEFC: BF8700B1
	.long 0x7f1c1502                                           // 00000000BF00: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 00000000BF04: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000000BF08: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 00000000BF0C: 7E1C1502
	ds_load_u16 v2, v52 offset:9136                            // 00000000BF10: D8F023B0 02000034
	s_waitcnt lgkmcnt(0)                                       // 00000000BF18: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BF1C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000BF20: BF8700A1
	.long 0x7f1e1502                                           // 00000000BF24: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000000BF28: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 00000000BF2C: 7E1E1502
	ds_load_u16 v2, v52 offset:9680                            // 00000000BF30: D8F025D0 02000034
	s_waitcnt lgkmcnt(0)                                       // 00000000BF38: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BF3C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000BF40: BF8700A1
	.long 0x7f201502                                           // 00000000BF44: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000000BF48: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 00000000BF4C: 7E201502
	ds_load_u16 v2, v52 offset:10224                           // 00000000BF50: D8F027F0 02000034
	s_waitcnt lgkmcnt(0)                                       // 00000000BF58: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000000BF5C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000BF60: BF8700A1
	.long 0x7f221502                                           // 00000000BF64: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000000BF68: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 00000000BF6C: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 00000000BF70: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000000BF78: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 00000000BF80: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000000BF88: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000BF90: BF870121
	v_wmma_f32_16x16x16_f16 v[54:61], v[18:25], v[10:17], v[2:9]// 00000000BF94: CC404036 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 00000000BF9C: 7E240280
	v_wmma_f32_16x16x16_f16 v[54:61], v[26:33], v[10:17], v[54:61]// 00000000BFA0: CC404036 1CDA151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v146// 00000000BFA8: CA120080 0A0B24FF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000000BFB4: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 00000000BFBC: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 00000000BFC0: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000BFC4: BF870003
	v_mov_b32_dpp v10, v43 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000BFC8: 7E1402FA FF00B12B
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000000BFD0: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000000BFD8: 7E220280
	s_waitcnt vmcnt(6)                                         // 00000000BFDC: BF891BF7
	v_mov_b32_dpp v12, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000BFE0: 7E1802FA FF00B12A
	v_perm_b32 v10, v43, v10, v11                              // 00000000BFE8: D644000A 042E152B
	s_waitcnt vmcnt(5)                                         // 00000000BFF0: BF8917F7
	v_mov_b32_dpp v13, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000BFF4: 7E1A02FA FF00B129
	s_waitcnt vmcnt(4)                                         // 00000000BFFC: BF8913F7
	v_mov_b32_dpp v14, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000C000: 7E1C02FA FF00B128
	s_waitcnt vmcnt(3)                                         // 00000000C008: BF890FF7
	v_mov_b32_dpp v15, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000C00C: 7E1E02FA FF00B127
	s_waitcnt vmcnt(2)                                         // 00000000C014: BF890BF7
	v_mov_b32_dpp v16, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000C018: 7E2002FA FF00B126
	s_waitcnt vmcnt(1)                                         // 00000000C020: BF8907F7
	v_mov_b32_dpp v17, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000C024: 7E2202FA FF00B124
	s_waitcnt vmcnt(0)                                         // 00000000C02C: BF8903F7
	v_mov_b32_dpp v18, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000000C030: 7E2402FA FF00B125
	v_perm_b32 v12, v42, v12, v11                              // 00000000C038: D644000C 042E192A
	v_perm_b32 v13, v41, v13, v11                              // 00000000C040: D644000D 042E1B29
	v_perm_b32 v14, v40, v14, v11                              // 00000000C048: D644000E 042E1D28
	v_perm_b32 v15, v39, v15, v11                              // 00000000C050: D644000F 042E1F27
	v_perm_b32 v16, v38, v16, v11                              // 00000000C058: D6440010 042E2126
	v_perm_b32 v17, v36, v17, v11                              // 00000000C060: D6440011 042E2324
	v_perm_b32 v11, v37, v18, v11                              // 00000000C068: D644000B 042E2525
	v_lshlrev_b32_e32 v18, 16, v10                             // 00000000C070: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 00000000C074: 362614FF FFFF0000
	ds_load_b128 v[30:33], v53 offset:25872                    // 00000000C07C: DBFC6510 1E000035
	ds_load_b128 v[26:29], v53 offset:25856                    // 00000000C084: DBFC6500 1A000035
	ds_load_b128 v[38:41], v53 offset:25104                    // 00000000C08C: DBFC6210 26000035
	ds_load_b128 v[34:37], v53 offset:25088                    // 00000000C094: DBFC6200 22000035
	v_cmp_eq_u32_e32 vcc_lo, 0, v157                           // 00000000C09C: 7C953A80
	v_cvt_f16_f32_e32 v10, v18                                 // 00000000C0A0: 7E141512
	.long 0x7f141513                                           // 00000000C0A4: 7F141513
	v_cndmask_b32_e32 v62, 0x7060302, v147, vcc_lo             // 00000000C0A8: 027D26FF 07060302
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000C0B0: BF870193
	v_cndmask_b16 v18, 0, v10, s0                              // 00000000C0B4: D65D0012 00021480
	v_cndmask_b16 v18, 0, v10, s1                              // 00000000C0BC: D65D5012 00061480
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000000C0C4: 30141890
	s_or_b32 s0, s64, 2                                        // 00000000C0C8: 8C008240
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C0CC: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C0D0: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C0D4: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C0D8: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C0DC: BF870481
	v_cndmask_b16 v19, 0, v10, s0                              // 00000000C0E0: D65D0013 00021480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 00000000C0E8: 361418FF FFFF0000
	s_or_b32 s0, s64, 3                                        // 00000000C0F0: 8C008340
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C0F4: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C0F8: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C0FC: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C100: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C104: BF870481
	v_cndmask_b16 v19, 0, v10, s0                              // 00000000C108: D65D4013 00021480
	v_lshlrev_b32_e32 v10, 16, v13                             // 00000000C110: 30141A90
	s_or_b32 s0, s64, 4                                        // 00000000C114: 8C008440
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C118: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C11C: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C120: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C124: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C128: BF870481
	v_cndmask_b16 v20, 0, v10, s0                              // 00000000C12C: D65D0014 00021480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 00000000C134: 36141AFF FFFF0000
	s_or_b32 s0, s64, 5                                        // 00000000C13C: 8C008540
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C140: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C144: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C148: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C14C: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C150: BF870481
	v_cndmask_b16 v20, 0, v10, s0                              // 00000000C154: D65D4014 00021480
	v_lshlrev_b32_e32 v10, 16, v14                             // 00000000C15C: 30141C90
	s_or_b32 s0, s64, 6                                        // 00000000C160: 8C008640
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C164: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C168: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C16C: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C170: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C174: BF870481
	v_cndmask_b16 v21, 0, v10, s0                              // 00000000C178: D65D0015 00021480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 00000000C180: 36141CFF FFFF0000
	s_or_b32 s0, s64, 7                                        // 00000000C188: 8C008740
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C18C: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C190: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C194: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C198: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C19C: BF870481
	v_cndmask_b16 v21, 0, v10, s0                              // 00000000C1A0: D65D4015 00021480
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000000C1A8: 30141E90
	s_or_b32 s0, s64, 8                                        // 00000000C1AC: 8C008840
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C1B0: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C1B4: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C1B8: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C1BC: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C1C0: BF870481
	v_cndmask_b16 v22, 0, v10, s0                              // 00000000C1C4: D65D0016 00021480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 00000000C1CC: 36141EFF FFFF0000
	s_or_b32 s0, s64, 9                                        // 00000000C1D4: 8C008940
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C1D8: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C1DC: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C1E0: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C1E4: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C1E8: BF870481
	v_cndmask_b16 v22, 0, v10, s0                              // 00000000C1EC: D65D4016 00021480
	v_lshlrev_b32_e32 v10, 16, v16                             // 00000000C1F4: 30142090
	s_or_b32 s0, s64, 10                                       // 00000000C1F8: 8C008A40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C1FC: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C200: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C204: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C208: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C20C: BF870481
	v_cndmask_b16 v23, 0, v10, s0                              // 00000000C210: D65D0017 00021480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 00000000C218: 361420FF FFFF0000
	s_or_b32 s0, s64, 11                                       // 00000000C220: 8C008B40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C224: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C228: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C22C: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C230: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C234: BF870481
	v_cndmask_b16 v23, 0, v10, s0                              // 00000000C238: D65D4017 00021480
	v_lshlrev_b32_e32 v10, 16, v17                             // 00000000C240: 30142290
	s_or_b32 s0, s64, 12                                       // 00000000C244: 8C008C40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C248: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C24C: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C250: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C254: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C258: BF870481
	v_cndmask_b16 v24, 0, v10, s0                              // 00000000C25C: D65D0018 00021480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 00000000C264: 361422FF FFFF0000
	s_or_b32 s0, s64, 13                                       // 00000000C26C: 8C008D40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C270: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C274: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C278: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C27C: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C280: BF870481
	v_cndmask_b16 v24, 0, v10, s0                              // 00000000C284: D65D4018 00021480
	v_lshlrev_b32_e32 v10, 16, v11                             // 00000000C28C: 30141690
	s_or_b32 s0, s64, 14                                       // 00000000C290: 8C008E40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C294: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C298: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C29C: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C2A0: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C2A4: BF870481
	v_cndmask_b16 v25, 0, v10, s0                              // 00000000C2A8: D65D0019 00021480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000000C2B0: 361416FF FFFF0000
	s_or_b32 s0, s64, 15                                       // 00000000C2B8: 8C008F40
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C2BC: BF870099
	s_cmp_lt_i32 s0, s33                                       // 00000000C2C0: BF042100
	v_cvt_f16_f32_e32 v10, v10                                 // 00000000C2C4: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000000C2C8: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000000C2CC: BF870481
	v_cndmask_b16 v25, 0, v10, s0                              // 00000000C2D0: D65D4019 00021480
	s_waitcnt lgkmcnt(2)                                       // 00000000C2D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000C2DC: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000000C2E0: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 00000000C2E8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 00000000C2EC: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v54                                 // 00000000C2F4: 7E241536
	v_mad_u32_u24 v22, 0x110, v157, v52                        // 00000000C2F8: D60B0016 04D33AFF 00000110
	.long 0x7f241537                                           // 00000000C304: 7F241537
	v_cvt_f16_f32_e32 v19, v56                                 // 00000000C308: 7E261538
	.long 0x7f261539                                           // 00000000C30C: 7F261539
	v_cvt_f16_f32_e32 v20, v58                                 // 00000000C310: 7E28153A
	.long 0x7f28153b                                           // 00000000C314: 7F28153B
	v_cvt_f16_f32_e32 v21, v60                                 // 00000000C318: 7E2A153C
	.long 0x7f2a153d                                           // 00000000C31C: 7F2A153D
	ds_store_b16 v22, v18 offset:19200                         // 00000000C320: D87C4B00 00001216
	ds_store_b16_d16_hi v22, v18 offset:19744                  // 00000000C328: DA844D20 00001216
	ds_store_b16 v22, v19 offset:20288                         // 00000000C330: D87C4F40 00001316
	ds_store_b16_d16_hi v22, v19 offset:20832                  // 00000000C338: DA845160 00001316
	ds_store_b16 v22, v20 offset:21376                         // 00000000C340: D87C5380 00001416
	ds_store_b16_d16_hi v22, v20 offset:21920                  // 00000000C348: DA8455A0 00001416
	ds_store_b16 v22, v21 offset:22464                         // 00000000C350: D87C57C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:23008                  // 00000000C358: DA8459E0 00001516
	v_fma_mixlo_f16 v18, v137, s62, 0                          // 00000000C360: CC210012 02007D89
	v_fma_mixhi_f16 v18, v136, s62, 0                          // 00000000C368: CC220012 02007D88
	v_cndmask_b32_e32 v54, 0x5040100, v146, vcc_lo             // 00000000C370: 026D24FF 05040100
	s_waitcnt lgkmcnt(0)                                       // 00000000C378: BF89FC07
	s_barrier                                                  // 00000000C37C: BFBD0000
	ds_load_b128 v[46:49], v51 offset:19216                    // 00000000C380: DBFC4B10 2E000033
	ds_load_b128 v[42:45], v51 offset:19200                    // 00000000C388: DBFC4B00 2A000033
	ds_load_b128 v[162:165], v51 offset:19248                  // 00000000C390: DBFC4B30 A2000033
	ds_load_b128 v[158:161], v51 offset:19232                  // 00000000C398: DBFC4B20 9E000033
	v_mov_b32_e32 v19, v18                                     // 00000000C3A0: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C3A4: BF870091
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C3A8: D65C0013 03FC7B13 FEDCBA98
	v_perm_b32 v26, v18, v19, v54                              // 00000000C3B4: D644001A 04DA2712
	v_perm_b32 v27, v18, v19, v62                              // 00000000C3BC: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v135, s62, 0                          // 00000000C3C4: CC210012 02007D87
	v_fma_mixhi_f16 v18, v134, s62, 0                          // 00000000C3CC: CC220012 02007D86
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C3D4: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000000C3D8: 7E260312
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C3DC: D65C0013 03FC7B13 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000C3E8: BF8700C1
	v_perm_b32 v28, v18, v19, v54                              // 00000000C3EC: D644001C 04DA2712
	v_perm_b32 v29, v18, v19, v62                              // 00000000C3F4: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v133, s62, 0                          // 00000000C3FC: CC210012 02007D85
	v_fma_mixhi_f16 v18, v132, s62, 0                          // 00000000C404: CC220012 02007D84
	v_mov_b32_e32 v19, v18                                     // 00000000C40C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C410: BF870091
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C414: D65C0013 03FC7B13 FEDCBA98
	v_perm_b32 v30, v18, v19, v54                              // 00000000C420: D644001E 04DA2712
	v_perm_b32 v31, v18, v19, v62                              // 00000000C428: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v131, s62, 0                          // 00000000C430: CC210012 02007D83
	v_fma_mixhi_f16 v18, v155, s62, 0                          // 00000000C438: CC220012 02007D9B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C440: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000000C444: 7E260312
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C448: D65C0013 03FC7B13 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000C454: BF8700C1
	v_perm_b32 v32, v18, v19, v54                              // 00000000C458: D6440020 04DA2712
	v_perm_b32 v33, v18, v19, v62                              // 00000000C460: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v130, s62, 0                          // 00000000C468: CC210012 02007D82
	v_fma_mixhi_f16 v18, v129, s62, 0                          // 00000000C470: CC220012 02007D81
	v_mov_b32_e32 v19, v18                                     // 00000000C478: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C47C: BF870091
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C480: D65C0013 03FC7B13 FEDCBA98
	v_perm_b32 v34, v18, v19, v54                              // 00000000C48C: D6440022 04DA2712
	v_perm_b32 v35, v18, v19, v62                              // 00000000C494: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v128, s62, 0                          // 00000000C49C: CC210012 02007D80
	v_fma_mixhi_f16 v18, v127, s62, 0                          // 00000000C4A4: CC220012 02007D7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C4AC: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000000C4B0: 7E260312
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C4B4: D65C0013 03FC7B13 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000C4C0: BF8700C1
	v_perm_b32 v36, v18, v19, v54                              // 00000000C4C4: D6440024 04DA2712
	v_perm_b32 v37, v18, v19, v62                              // 00000000C4CC: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v126, s62, 0                          // 00000000C4D4: CC210012 02007D7E
	v_fma_mixhi_f16 v18, v125, s62, 0                          // 00000000C4DC: CC220012 02007D7D
	v_mov_b32_e32 v19, v18                                     // 00000000C4E4: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C4E8: BF870091
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C4EC: D65C0013 03FC7B13 FEDCBA98
	v_perm_b32 v38, v18, v19, v54                              // 00000000C4F8: D6440026 04DA2712
	v_perm_b32 v39, v18, v19, v62                              // 00000000C500: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v124, s62, 0                          // 00000000C508: CC210012 02007D7C
	v_fma_mixhi_f16 v18, v154, s62, 0                          // 00000000C510: CC220012 02007D9A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000C518: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000000C51C: 7E260312
	v_permlanex16_b32 v19, v19, s61, 0xfedcba98                // 00000000C520: D65C0013 03FC7B13 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000000C52C: BF8700D1
	v_perm_b32 v40, v18, v19, v54                              // 00000000C530: D6440028 04DA2712
	v_perm_b32 v41, v18, v19, v62                              // 00000000C538: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 00000000C540: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 00000000C544: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 00000000C54C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[158:165], v[34:41], v[18:25]// 00000000C550: CC404012 1C4A459E
	ds_load_b128 v[158:161], v51 offset:14848                  // 00000000C558: DBFC3A00 9E000033
	ds_load_b128 v[162:165], v51 offset:14864                  // 00000000C560: DBFC3A10 A2000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C568: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[158:165], v[26:33], v[2:9]// 00000000C56C: CC40402A 1C0A359E
	ds_load_b128 v[26:29], v51 offset:14880                    // 00000000C574: DBFC3A20 1A000033
	ds_load_b128 v[30:33], v51 offset:14896                    // 00000000C57C: DBFC3A30 1E000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C584: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000000C588: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v123, s62, 0                          // 00000000C590: CC21001B 02007D7B
	v_fma_mixhi_f16 v27, v122, s62, 0                          // 00000000C598: CC22001B 02007D7A
	v_fma_mixlo_f16 v29, v121, s62, 0                          // 00000000C5A0: CC21001D 02007D79
	v_fma_mixhi_f16 v29, v120, s62, 0                          // 00000000C5A8: CC22001D 02007D78
	v_fma_mixlo_f16 v31, v119, s62, 0                          // 00000000C5B0: CC21001F 02007D77
	v_fma_mixhi_f16 v31, v118, s62, 0                          // 00000000C5B8: CC22001F 02007D76
	v_fma_mixlo_f16 v33, v117, s62, 0                          // 00000000C5C0: CC210021 02007D75
	v_fma_mixhi_f16 v33, v153, s62, 0                          // 00000000C5C8: CC220021 02007D99
	v_mov_b32_e32 v28, v27                                     // 00000000C5D0: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000C5D4: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000C5D8: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C5DC: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000C5E0: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000C5E4: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C5F0: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000C5F4: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000C600: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C60C: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000C610: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000C61C: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000C624: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000C62C: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000C634: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000C63C: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000C644: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000C64C: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000C654: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19280                    // 00000000C65C: DBFC4B50 26000033
	ds_load_b128 v[34:37], v51 offset:19264                    // 00000000C664: DBFC4B40 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C66C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000C670: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:14928                    // 00000000C678: DBFC3A50 26000033
	ds_load_b128 v[34:37], v51 offset:14912                    // 00000000C680: DBFC3A40 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C688: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000C68C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v116, s62, 0                          // 00000000C694: CC21001B 02007D74
	v_fma_mixhi_f16 v27, v115, s62, 0                          // 00000000C69C: CC22001B 02007D73
	v_fma_mixlo_f16 v29, v114, s62, 0                          // 00000000C6A4: CC21001D 02007D72
	v_fma_mixhi_f16 v29, v113, s62, 0                          // 00000000C6AC: CC22001D 02007D71
	v_fma_mixlo_f16 v31, v112, s62, 0                          // 00000000C6B4: CC21001F 02007D70
	v_fma_mixhi_f16 v31, v111, s62, 0                          // 00000000C6BC: CC22001F 02007D6F
	v_fma_mixlo_f16 v33, v110, s62, 0                          // 00000000C6C4: CC210021 02007D6E
	v_fma_mixhi_f16 v33, v152, s62, 0                          // 00000000C6CC: CC220021 02007D98
	v_mov_b32_e32 v28, v27                                     // 00000000C6D4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000C6D8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000C6DC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C6E0: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000C6E4: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000C6E8: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C6F4: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000C6F8: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000C704: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C710: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000C714: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000C720: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000C728: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000C730: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000C738: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000C740: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000C748: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000C750: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000C758: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19312                    // 00000000C760: DBFC4B70 26000033
	ds_load_b128 v[34:37], v51 offset:19296                    // 00000000C768: DBFC4B60 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C770: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000C774: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:14960                    // 00000000C77C: DBFC3A70 26000033
	ds_load_b128 v[34:37], v51 offset:14944                    // 00000000C784: DBFC3A60 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C78C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000C790: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v109, s62, 0                          // 00000000C798: CC21001B 02007D6D
	v_fma_mixhi_f16 v27, v108, s62, 0                          // 00000000C7A0: CC22001B 02007D6C
	v_fma_mixlo_f16 v29, v107, s62, 0                          // 00000000C7A8: CC21001D 02007D6B
	v_fma_mixhi_f16 v29, v106, s62, 0                          // 00000000C7B0: CC22001D 02007D6A
	v_fma_mixlo_f16 v31, v105, s62, 0                          // 00000000C7B8: CC21001F 02007D69
	v_fma_mixhi_f16 v31, v104, s62, 0                          // 00000000C7C0: CC22001F 02007D68
	v_fma_mixlo_f16 v33, v103, s62, 0                          // 00000000C7C8: CC210021 02007D67
	v_fma_mixhi_f16 v33, v151, s62, 0                          // 00000000C7D0: CC220021 02007D97
	v_mov_b32_e32 v28, v27                                     // 00000000C7D8: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000C7DC: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000C7E0: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C7E4: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000C7E8: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000C7EC: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C7F8: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000C7FC: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000C808: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C814: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000C818: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000C824: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000C82C: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000C834: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000C83C: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000C844: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000C84C: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000C854: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000C85C: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19344                    // 00000000C864: DBFC4B90 26000033
	ds_load_b128 v[34:37], v51 offset:19328                    // 00000000C86C: DBFC4B80 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C874: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000C878: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:14992                    // 00000000C880: DBFC3A90 26000033
	ds_load_b128 v[34:37], v51 offset:14976                    // 00000000C888: DBFC3A80 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C890: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000C894: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v102, s62, 0                          // 00000000C89C: CC21001B 02007D66
	v_fma_mixhi_f16 v27, v101, s62, 0                          // 00000000C8A4: CC22001B 02007D65
	v_fma_mixlo_f16 v29, v100, s62, 0                          // 00000000C8AC: CC21001D 02007D64
	v_fma_mixhi_f16 v29, v99, s62, 0                           // 00000000C8B4: CC22001D 02007D63
	v_fma_mixlo_f16 v31, v98, s62, 0                           // 00000000C8BC: CC21001F 02007D62
	v_fma_mixhi_f16 v31, v97, s62, 0                           // 00000000C8C4: CC22001F 02007D61
	v_fma_mixlo_f16 v33, v96, s62, 0                           // 00000000C8CC: CC210021 02007D60
	v_fma_mixhi_f16 v33, v150, s62, 0                          // 00000000C8D4: CC220021 02007D96
	v_mov_b32_e32 v28, v27                                     // 00000000C8DC: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000C8E0: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000C8E4: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C8E8: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000C8EC: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000C8F0: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C8FC: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000C900: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000C90C: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C918: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000C91C: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000C928: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000C930: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000C938: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000C940: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000C948: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000C950: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000C958: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000C960: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19376                    // 00000000C968: DBFC4BB0 26000033
	ds_load_b128 v[34:37], v51 offset:19360                    // 00000000C970: DBFC4BA0 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C978: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000C97C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:15024                    // 00000000C984: DBFC3AB0 26000033
	ds_load_b128 v[34:37], v51 offset:15008                    // 00000000C98C: DBFC3AA0 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000C994: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000C998: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v95, s62, 0                           // 00000000C9A0: CC21001B 02007D5F
	v_fma_mixhi_f16 v27, v94, s62, 0                           // 00000000C9A8: CC22001B 02007D5E
	v_fma_mixlo_f16 v29, v93, s62, 0                           // 00000000C9B0: CC21001D 02007D5D
	v_fma_mixhi_f16 v29, v92, s62, 0                           // 00000000C9B8: CC22001D 02007D5C
	v_fma_mixlo_f16 v31, v91, s62, 0                           // 00000000C9C0: CC21001F 02007D5B
	v_fma_mixhi_f16 v31, v90, s62, 0                           // 00000000C9C8: CC22001F 02007D5A
	v_fma_mixlo_f16 v33, v89, s62, 0                           // 00000000C9D0: CC210021 02007D59
	v_fma_mixhi_f16 v33, v149, s62, 0                          // 00000000C9D8: CC220021 02007D95
	v_mov_b32_e32 v28, v27                                     // 00000000C9E0: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000C9E4: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000C9E8: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000C9EC: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000C9F0: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000C9F4: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CA00: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000CA04: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000CA10: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CA1C: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000CA20: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000CA2C: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000CA34: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000CA3C: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000CA44: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000CA4C: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000CA54: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000CA5C: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000CA64: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19408                    // 00000000CA6C: DBFC4BD0 26000033
	ds_load_b128 v[34:37], v51 offset:19392                    // 00000000CA74: DBFC4BC0 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000CA7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000CA80: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:15056                    // 00000000CA88: DBFC3AD0 26000033
	ds_load_b128 v[34:37], v51 offset:15040                    // 00000000CA90: DBFC3AC0 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000CA98: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000CA9C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v87, s62, 0                           // 00000000CAA4: CC21001B 02007D57
	v_fma_mixhi_f16 v27, v86, s62, 0                           // 00000000CAAC: CC22001B 02007D56
	v_fma_mixlo_f16 v29, v85, s62, 0                           // 00000000CAB4: CC21001D 02007D55
	v_fma_mixhi_f16 v29, v82, s62, 0                           // 00000000CABC: CC22001D 02007D52
	v_fma_mixlo_f16 v31, v88, s62, 0                           // 00000000CAC4: CC21001F 02007D58
	v_fma_mixhi_f16 v31, v83, s62, 0                           // 00000000CACC: CC22001F 02007D53
	v_fma_mixlo_f16 v33, v84, s62, 0                           // 00000000CAD4: CC210021 02007D54
	v_fma_mixhi_f16 v33, v148, s62, 0                          // 00000000CADC: CC220021 02007D94
	v_mov_b32_e32 v28, v27                                     // 00000000CAE4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000000CAE8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000000CAEC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CAF0: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000000CAF4: 7E440321
	v_permlanex16_b32 v28, v28, s61, 0xfedcba98                // 00000000CAF8: D65C001C 03FC7B1C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CB04: BF870214
	v_permlanex16_b32 v30, v30, s61, 0xfedcba98                // 00000000CB08: D65C001E 03FC7B1E FEDCBA98
	v_permlanex16_b32 v32, v32, s61, 0xfedcba98                // 00000000CB14: D65C0020 03FC7B20 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CB20: BF870214
	v_permlanex16_b32 v34, v34, s61, 0xfedcba98                // 00000000CB24: D65C0022 03FC7B22 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000000CB30: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v62                              // 00000000CB38: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v54                              // 00000000CB40: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000000CB48: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000000CB50: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v62                              // 00000000CB58: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v54                              // 00000000CB60: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v62                              // 00000000CB68: D6440021 04FA4521
	ds_load_b128 v[38:41], v51 offset:19440                    // 00000000CB70: DBFC4BF0 26000033
	ds_load_b128 v[34:37], v51 offset:19424                    // 00000000CB78: DBFC4BE0 22000033
	s_waitcnt lgkmcnt(0)                                       // 00000000CB80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000000CB84: CC404012 1C4A3522
	ds_load_b128 v[38:41], v51 offset:15088                    // 00000000CB8C: DBFC3AF0 26000033
	ds_load_b128 v[34:37], v51 offset:15072                    // 00000000CB94: DBFC3AE0 22000033
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 00000000CB9C: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000000CBA8: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 00000000CBB4: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000CBBC: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 00000000CBC0: 0814250A
	v_or_b32_e32 v18, s64, v157                                // 00000000CBC4: 38253A40
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000000CBC8: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 00000000CBD0: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CBD4: BF870214
	v_fma_mixlo_f16 v10, v10, s58, 0                           // 00000000CBD8: CC21000A 0200750A
	v_or_b32_e32 v19, 2, v18                                   // 00000000CBE0: 38262482
	.long 0xd4440000                                           // 00000000CBE4: D4440000
	v_cndmask_b32_e32 v1, s33, v18, vcc_lo                     // 00000000CBE8: 02022421
	v_fma_mixhi_f16 v10, v11, s58, 0                           // 00000000CBEC: CC22000A 0200750B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 00000000CBF4: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000CC00: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s33, v19                          // 00000000CC04: 7C882621
	v_cndmask_b16 v10, 0, v10, s0                              // 00000000CC08: D65D000A 00021480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000000CC10: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 00000000CC14: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000000CC20: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000000CC28: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 00000000CC30: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000000CC34: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 00000000CC3C: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CC44: BF870093
	v_mov_b32_e32 v11, v10                                     // 00000000CC48: 7E16030A
	v_permlanex16_b32 v11, v11, s61, 0xfedcba98                // 00000000CC4C: D65C000B 03FC7B0B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000CC58: BF8700B1
	v_perm_b32 v55, v10, v11, v54                              // 00000000CC5C: D6440037 04DA170A
	v_perm_b32 v56, v10, v11, v62                              // 00000000CC64: D6440038 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 00000000CC6C: 38142484
	v_cmp_gt_i32_e32 vcc_lo, s33, v10                          // 00000000CC70: 7C881421
	v_or_b32_e32 v10, 6, v18                                   // 00000000CC74: 38142486
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000CC78: BF870131
	.long 0xd4440001                                           // 00000000CC7C: D4440001
	v_cndmask_b32_e32 v1, s33, v10, vcc_lo                     // 00000000CC80: 02021421
	v_fma_mixlo_f16 v10, v12, s58, 0                           // 00000000CC84: CC21000A 0200750C
	v_fma_mixhi_f16 v10, v13, s58, 0                           // 00000000CC8C: CC22000A 0200750D
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000000CC94: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CC9C: BF870092
	v_cndmask_b16 v10, 0, v10, s1                              // 00000000CCA0: D65D500A 00061480
	v_mov_b32_e32 v11, v10                                     // 00000000CCA8: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CCAC: BF870091
	v_permlanex16_b32 v11, v11, s61, 0xfedcba98                // 00000000CCB0: D65C000B 03FC7B0B FEDCBA98
	v_perm_b32 v57, v10, v11, v54                              // 00000000CCBC: D6440039 04DA170A
	v_perm_b32 v58, v10, v11, v62                              // 00000000CCC4: D644003A 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 00000000CCCC: 38142488
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000CCD0: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s33, v10                          // 00000000CCD4: 7C881421
	v_or_b32_e32 v10, 10, v18                                  // 00000000CCD8: 3814248A
	.long 0xd4440001                                           // 00000000CCDC: D4440001
	v_cndmask_b32_e32 v1, s33, v10, vcc_lo                     // 00000000CCE0: 02021421
	v_fma_mixlo_f16 v10, v14, s58, 0                           // 00000000CCE4: CC21000A 0200750E
	v_fma_mixhi_f16 v10, v15, s58, 0                           // 00000000CCEC: CC22000A 0200750F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000CCF4: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000000CCF8: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s1                              // 00000000CD00: D65D500A 00061480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CD08: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000000CD0C: 7E16030A
	v_permlanex16_b32 v11, v11, s61, 0xfedcba98                // 00000000CD10: D65C000B 03FC7B0B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000CD1C: BF8700B1
	v_perm_b32 v59, v10, v11, v54                              // 00000000CD20: D644003B 04DA170A
	v_perm_b32 v60, v10, v11, v62                              // 00000000CD28: D644003C 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 00000000CD30: 3814248C
	v_cmp_gt_i32_e32 vcc_lo, s33, v10                          // 00000000CD34: 7C881421
	v_or_b32_e32 v10, 14, v18                                  // 00000000CD38: 3814248E
	ds_load_b128 v[18:21], v53 offset:27648                    // 00000000CD3C: DBFC6C00 12000035
	ds_load_b128 v[22:25], v53 offset:27664                    // 00000000CD44: DBFC6C10 16000035
	.long 0xd4440001                                           // 00000000CD4C: D4440001
	v_cndmask_b32_e32 v1, s33, v10, vcc_lo                     // 00000000CD50: 02021421
	v_fma_mixlo_f16 v10, v16, s58, 0                           // 00000000CD54: CC21000A 02007510
	v_fma_mixhi_f16 v10, v17, s58, 0                           // 00000000CD5C: CC22000A 02007511
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000CD64: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000000CD68: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s1                              // 00000000CD70: D65D500A 00061480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CD78: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000000CD7C: 7E16030A
	v_permlanex16_b32 v11, v11, s61, 0xfedcba98                // 00000000CD80: D65C000B 03FC7B0B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000CD8C: BF8700B1
	v_perm_b32 v61, v10, v11, v54                              // 00000000CD90: D644003D 04DA170A
	v_perm_b32 v62, v10, v11, v62                              // 00000000CD98: D644003E 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 00000000CDA0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[55:62], v[2:9]// 00000000CDA4: CC40400A 1C0A6F12
	.long 0x7f063880                                           // 00000000CDAC: 7F063880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000CDB0: BF870001
	.long 0x7f083983                                           // 00000000CDB4: 7F083983
	s_and_saveexec_b32 s1, s0                                  // 00000000CDB8: BE812000
	s_cbranch_execz 14                                         // 00000000CDBC: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x48f8>
	ds_load_b32 v2, v50 offset:28672                           // 00000000CDC0: D8D87000 02000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CDC8: BF89FC07
	v_mul_f32_e32 v2, v42, v2                                  // 00000000CDCC: 1004052A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CDD0: BF870091
	v_add_f32_e32 v2, v10, v2                                  // 00000000CDD4: 0604050A
	v_mul_f32_e32 v2, 0x3b800000, v2                           // 00000000CDD8: 100404FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CDE0: BF870091
	v_bfe_u32 v4, v2, 16, 1                                    // 00000000CDE4: D6100004 02052102
	v_add3_u32 v4, v2, v4, 0x7fff                              // 00000000CDEC: D6550004 03FE0902 00007FFF
	s_or_b32 exec_lo, exec_lo, s1                              // 00000000CDF8: 8C7E017E
	v_add_nc_u32_e32 v2, 0x1800, v52                           // 00000000CDFC: 4A0468FF 00001800
	v_or3_b32 v5, v157, s64, 2                                 // 00000000CE04: D6580005 0208819D
	s_mov_b32 s0, exec_lo                                      // 00000000CE0C: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000CE10: BF870002
	v_mad_u32_u24 v2, 0x110, v157, v2                          // 00000000CE14: D60B0002 040B3AFF 00000110
	ds_store_b16_d16_hi v2, v4 offset:4352                     // 00000000CE20: DA841100 00000402
	.long 0xd4c4007e                                           // 00000000CE28: D4C4007E
	v_cndmask_b32_e32 v1, s33, v5, vcc_lo                      // 00000000CE2C: 02020A21
	s_cbranch_execz 14                                         // 00000000CE30: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x496c>
	ds_load_b32 v3, v50 offset:28680                           // 00000000CE34: D8D87008 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CE3C: BF89FC07
	v_mul_f32_e32 v3, v43, v3                                  // 00000000CE40: 1006072B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CE44: BF870091
	v_add_f32_e32 v3, v11, v3                                  // 00000000CE48: 0606070B
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000CE4C: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CE54: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000CE58: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000000CE60: D6550003 03FE0903 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000CE6C: 8C7E007E
	v_or3_b32 v5, v157, s64, 4                                 // 00000000CE70: D6580005 0210819D
	.long 0x7f083880                                           // 00000000CE78: 7F083880
	v_add_nc_u32_e32 v2, 0x1100, v2                            // 00000000CE7C: 4A0404FF 00001100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000CE84: BF870193
	v_cmp_gt_i32_e32 vcc_lo, s33, v5                           // 00000000CE88: 7C880A21
	.long 0x7f0a3984                                           // 00000000CE8C: 7F0A3984
	ds_store_b16_d16_hi v2, v3 offset:544                      // 00000000CE90: DA840220 00000302
	s_and_saveexec_b32 s0, vcc_lo                              // 00000000CE98: BE80206A
	s_cbranch_execz 14                                         // 00000000CE9C: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x49d8>
	ds_load_b32 v3, v50 offset:28688                           // 00000000CEA0: D8D87010 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CEA8: BF89FC07
	v_mul_f32_e32 v3, v44, v3                                  // 00000000CEAC: 1006072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CEB0: BF870091
	v_add_f32_e32 v3, v12, v3                                  // 00000000CEB4: 0606070C
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000CEB8: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CEC0: BF870091
	v_bfe_u32 v5, v3, 16, 1                                    // 00000000CEC4: D6100005 02052103
	v_add3_u32 v5, v3, v5, 0x7fff                              // 00000000CECC: D6550005 03FE0B03 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000CED8: 8C7E007E
	v_or3_b32 v3, v157, s64, 6                                 // 00000000CEDC: D6580003 0218819D
	s_mov_b32 s0, exec_lo                                      // 00000000CEE4: BE80007E
	ds_store_b16_d16_hi v2, v5 offset:1088                     // 00000000CEE8: DA840440 00000502
	.long 0xd4c4007e                                           // 00000000CEF0: D4C4007E
	v_cndmask_b32_e32 v1, s33, v3, vcc_lo                      // 00000000CEF4: 02020621
	s_cbranch_execz 14                                         // 00000000CEF8: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4a34>
	ds_load_b32 v3, v50 offset:28696                           // 00000000CEFC: D8D87018 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CF04: BF89FC07
	v_mul_f32_e32 v3, v45, v3                                  // 00000000CF08: 1006072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CF0C: BF870091
	v_add_f32_e32 v3, v13, v3                                  // 00000000CF10: 0606070D
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000CF14: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CF1C: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000CF20: D6100004 02052103
	v_add3_u32 v4, v3, v4, 0x7fff                              // 00000000CF28: D6550004 03FE0903 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000CF34: 8C7E007E
	v_or3_b32 v3, v157, s64, 8                                 // 00000000CF38: D6580003 0220819D
	.long 0x7f0a3880                                           // 00000000CF40: 7F0A3880
	ds_store_b16_d16_hi v2, v4 offset:1632                     // 00000000CF44: DA840660 00000402
	v_cmp_gt_i32_e32 vcc_lo, s33, v3                           // 00000000CF4C: 7C880621
	.long 0x7f063985                                           // 00000000CF50: 7F063985
	s_and_saveexec_b32 s0, vcc_lo                              // 00000000CF54: BE80206A
	s_cbranch_execz 14                                         // 00000000CF58: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4a94>
	ds_load_b32 v3, v50 offset:28704                           // 00000000CF5C: D8D87020 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CF64: BF89FC07
	v_mul_f32_e32 v3, v46, v3                                  // 00000000CF68: 1006072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CF6C: BF870091
	v_add_f32_e32 v3, v14, v3                                  // 00000000CF70: 0606070E
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000CF74: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CF7C: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000CF80: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000000CF88: D6550003 03FE0903 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000CF94: 8C7E007E
	v_or3_b32 v4, v157, s64, 10                                // 00000000CF98: D6580004 0228819D
	s_mov_b32 s0, exec_lo                                      // 00000000CFA0: BE80007E
	ds_store_b16_d16_hi v2, v3 offset:2176                     // 00000000CFA4: DA840880 00000302
	.long 0xd4c4007e                                           // 00000000CFAC: D4C4007E
	v_cndmask_b32_e32 v1, s33, v4, vcc_lo                      // 00000000CFB0: 02020821
	s_cbranch_execz 14                                         // 00000000CFB4: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4af0>
	ds_load_b32 v3, v50 offset:28712                           // 00000000CFB8: D8D87028 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000CFC0: BF89FC07
	v_mul_f32_e32 v3, v47, v3                                  // 00000000CFC4: 1006072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CFC8: BF870091
	v_add_f32_e32 v3, v15, v3                                  // 00000000CFCC: 0606070F
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000CFD0: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000CFD8: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000CFDC: D6100004 02052103
	v_add3_u32 v5, v3, v4, 0x7fff                              // 00000000CFE4: D6550005 03FE0903 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000CFF0: 8C7E007E
	v_or3_b32 v4, v157, s64, 12                                // 00000000CFF4: D6580004 0230819D
	.long 0x7f063880                                           // 00000000CFFC: 7F063880
	ds_store_b16_d16_hi v2, v5 offset:2720                     // 00000000D000: DA840AA0 00000502
	v_cmp_gt_i32_e32 vcc_lo, s33, v4                           // 00000000D008: 7C880821
	.long 0x7f083983                                           // 00000000D00C: 7F083983
	s_and_saveexec_b32 s0, vcc_lo                              // 00000000D010: BE80206A
	s_cbranch_execz 14                                         // 00000000D014: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4b50>
	ds_load_b32 v4, v50 offset:28720                           // 00000000D018: D8D87030 04000032
	s_waitcnt lgkmcnt(0)                                       // 00000000D020: BF89FC07
	v_mul_f32_e32 v4, v48, v4                                  // 00000000D024: 10080930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D028: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 00000000D02C: 06080910
	v_mul_f32_e32 v4, 0x3b800000, v4                           // 00000000D030: 100808FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D038: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 00000000D03C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000000D044: D6550004 03FE0B04 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000D050: 8C7E007E
	v_or3_b32 v5, v157, s64, 14                                // 00000000D054: D6580005 0238819D
	s_mov_b32 s0, exec_lo                                      // 00000000D05C: BE80007E
	ds_store_b16_d16_hi v2, v4 offset:3264                     // 00000000D060: DA840CC0 00000402
	.long 0xd4c4007e                                           // 00000000D068: D4C4007E
	v_cndmask_b32_e32 v1, s33, v5, vcc_lo                      // 00000000D06C: 02020A21
	s_cbranch_execz 14                                         // 00000000D070: BFA5000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4bac>
	ds_load_b32 v3, v50 offset:28728                           // 00000000D074: D8D87038 03000032
	s_waitcnt lgkmcnt(0)                                       // 00000000D07C: BF89FC07
	v_mul_f32_e32 v3, v49, v3                                  // 00000000D080: 10060731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D084: BF870091
	v_add_f32_e32 v3, v17, v3                                  // 00000000D088: 06060711
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 00000000D08C: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D094: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000000D098: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000000D0A0: D6550003 03FE0903 00007FFF
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000D0AC: 8C7E007E
	ds_load_b32 v34, v1 offset:28540                           // 00000000D0B0: D8D86F7C 22000001
	v_or_b32_e32 v4, 0x5c00, v53                               // 00000000D0B8: 38086AFF 00005C00
	v_dual_mov_b32 v181, s27 :: v_dual_mov_b32 v178, s24       // 00000000D0C0: CA10001B B5B20018
	ds_store_b16_d16_hi v2, v3 offset:3808                     // 00000000D0C8: DA840EE0 00000302
	v_dual_mov_b32 v180, s26 :: v_dual_add_nc_u32 v35, 0xffffa400, v4// 00000000D0D0: CA20001A B42208FF FFFFA400
	v_dual_mov_b32 v176, s22 :: v_dual_mov_b32 v175, s21       // 00000000D0DC: CA100016 B0AE0015
	s_add_i32 s64, s64, 16                                     // 00000000D0E4: 81409040
	ds_load_b128 v[162:165], v35 offset:2320                   // 00000000D0E8: DBFC0910 A2000023
	ds_load_b128 v[158:161], v35 offset:2304                   // 00000000D0F0: DBFC0900 9E000023
	ds_load_b128 v[170:173], v35 offset:3088                   // 00000000D0F8: DBFC0C10 AA000023
	ds_load_b128 v[166:169], v35 offset:3072                   // 00000000D100: DBFC0C00 A6000023
	ds_load_b128 v[4:7], v35                                   // 00000000D108: DBFC0000 04000023
	ds_load_b128 v[8:11], v35 offset:16                        // 00000000D110: DBFC0010 08000023
	ds_load_b128 v[182:185], v35 offset:3840                   // 00000000D118: DBFC0F00 B6000023
	ds_load_b128 v[186:189], v35 offset:3856                   // 00000000D120: DBFC0F10 BA000023
	v_mov_b32_e32 v179, s25                                    // 00000000D128: 7F660219
	v_mov_b32_e32 v177, s23                                    // 00000000D12C: 7F620217
	s_waitcnt lgkmcnt(9)                                       // 00000000D130: BF89FC97
	v_readfirstlane_b32 s0, v34                                // 00000000D134: 7E000522
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v34                  // 00000000D138: 7C3644FF C2CE8ED0
	s_mul_f32 s0, s0, 0x3fb8aa3b                               // 00000000D140: A200FF00 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000000D148: BF8700CB
	s_xor_b32 s1, s0, 0x80000000                               // 00000000D14C: 8D01FF00 80000000
	s_cmp_lg_u32 s12, s64                                      // 00000000D154: BF07400C
	v_fma_f32 v12, 0x3fb8aa3b, v34, s1                         // 00000000D158: D613000C 000644FF 3FB8AA3B
	s_rndne_f32 s1, s0                                         // 00000000D164: BE816300
	v_fmac_f32_e32 v12, 0x32a5705f, v34                        // 00000000D168: 561844FF 32A5705F
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000000D170: BF87000A
	s_sub_f32 s0, s0, s1                                       // 00000000D174: A0800100
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000000D178: BF870581
	v_add_f32_e32 v20, s0, v12                                 // 00000000D17C: 06281800
	ds_load_b128 v[16:19], v35 offset:784                      // 00000000D180: DBFC0310 10000023
	ds_load_b128 v[12:15], v35 offset:768                      // 00000000D188: DBFC0300 0C000023
	ds_load_b128 v[30:33], v35 offset:1552                     // 00000000D190: DBFC0610 1E000023
	ds_load_b128 v[26:29], v35 offset:1536                     // 00000000D198: DBFC0600 1A000023
	s_cvt_i32_f32 s0, s1                                       // 00000000D1A0: BE806601
	v_exp_f32_e32 v20, v20                                     // 00000000D1A4: 7E284B14
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_2) // 00000000D1A8: BF870505
	.long 0xd71c0002                                           // 00000000D1AC: D71C0002
	v_cndmask_b32_e32 v0, v20, v0, vcc_lo                      // 00000000D1B0: 02000114
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000D1B4: BF870121
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000000D1B8: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v34                  // 00000000D1BC: 7C3C44FF 42B17218
	v_cndmask_b32_e32 v190, 0x7f800000, v2, vcc_lo             // 00000000D1C4: 037C04FF 7F800000
	v_mov_b32_e32 v174, s20                                    // 00000000D1CC: 7F5C0214
	s_waitcnt lgkmcnt(2)                                       // 00000000D1D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000000D1D4: BF870131
	v_wmma_f32_16x16x16_f16 v[39:46], v[12:19], v[55:62], v[174:181]// 00000000D1D8: CC404027 1EBA6F0C
	s_waitcnt lgkmcnt(0)                                       // 00000000D1E0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[26:33], v[55:62], v[174:181]// 00000000D1E4: CC404012 1EBA6F1A
	v_fma_f32 v130, v130, v190, v39                            // 00000000D1EC: D6130082 049F7D82
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000D1F4: BF870193
	v_fma_f32 v129, v129, v190, v40                            // 00000000D1F8: D6130081 04A37D81
	v_fmac_f32_e32 v25, v153, v190                             // 00000000D200: 56337D99
	v_wmma_f32_16x16x16_f16 v[47:54], v[4:11], v[55:62], v[174:181]// 00000000D204: CC40402F 1EBA6F04
	v_wmma_f32_16x16x16_f16 v[10:17], v[158:165], v[55:62], v[174:181]// 00000000D20C: CC40400A 1EBA6F9E
	ds_load_b128 v[162:165], v35 offset:4624                   // 00000000D214: DBFC1210 A2000023
	ds_load_b128 v[158:161], v35 offset:4608                   // 00000000D21C: DBFC1200 9E000023
	v_wmma_f32_16x16x16_f16 v[2:9], v[166:173], v[55:62], v[174:181]// 00000000D224: CC404002 1EBA6FA6
	ds_load_b128 v[170:173], v35 offset:5392                   // 00000000D22C: DBFC1510 AA000023
	ds_load_b128 v[166:169], v35 offset:5376                   // 00000000D234: DBFC1500 A6000023
	v_fma_f32 v128, v128, v190, v41                            // 00000000D23C: D6130080 04A77D80
	v_fma_f32 v127, v127, v190, v42                            // 00000000D244: D613007F 04AB7D7F
	v_fma_f32 v126, v126, v190, v43                            // 00000000D24C: D613007E 04AF7D7E
	v_fma_f32 v125, v125, v190, v44                            // 00000000D254: D613007D 04B37D7D
	v_fma_f32 v124, v124, v190, v45                            // 00000000D25C: D613007C 04B77D7C
	v_wmma_f32_16x16x16_f16 v[26:33], v[182:189], v[55:62], v[174:181]// 00000000D264: CC40401A 1EBA6FB6
	v_fma_f32 v137, v137, v190, v47                            // 00000000D26C: D6130089 04BF7D89
	v_fma_f32 v136, v136, v190, v48                            // 00000000D274: D6130088 04C37D88
	v_fma_f32 v135, v135, v190, v49                            // 00000000D27C: D6130087 04C77D87
	v_fma_f32 v134, v134, v190, v50                            // 00000000D284: D6130086 04CB7D86
	v_fma_f32 v133, v133, v190, v51                            // 00000000D28C: D6130085 04CF7D85
	v_fma_f32 v132, v132, v190, v52                            // 00000000D294: D6130084 04D37D84
	v_fma_f32 v131, v131, v190, v53                            // 00000000D29C: D6130083 04D77D83
	v_fmac_f32_e32 v54, v155, v190                             // 00000000D2A4: 566D7D9B
	v_dual_fmac_f32 v46, v154, v190 :: v_dual_mul_f32 v153, 0x3b800000, v129// 00000000D2A8: C8077D9A 2E9902FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 00000000D2B4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[38:45], v[158:165], v[55:62], v[174:181]// 00000000D2B8: CC404026 1EBA6F9E
	v_fma_f32 v123, v123, v190, v18                            // 00000000D2C0: D613007B 044B7D7B
	v_fma_f32 v122, v122, v190, v19                            // 00000000D2C8: D613007A 044F7D7A
	v_fma_f32 v121, v121, v190, v20                            // 00000000D2D0: D6130079 04537D79
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000D2D8: BF870004
	v_fma_f32 v95, v95, v190, v38                              // 00000000D2DC: D613005F 049B7D5F
	v_fma_f32 v94, v94, v190, v39                              // 00000000D2E4: D613005E 049F7D5E
	v_fma_f32 v93, v93, v190, v40                              // 00000000D2EC: D613005D 04A37D5D
	v_fma_f32 v92, v92, v190, v41                              // 00000000D2F4: D613005C 04A77D5C
	s_waitcnt lgkmcnt(0)                                       // 00000000D2FC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[34:41], v[166:173], v[55:62], v[174:181]// 00000000D300: CC404022 1EBA6FA6
	v_fma_f32 v120, v120, v190, v21                            // 00000000D308: D6130078 04577D78
	v_fma_f32 v119, v119, v190, v22                            // 00000000D310: D6130077 045B7D77
	v_fma_f32 v118, v118, v190, v23                            // 00000000D318: D6130076 045F7D76
	v_fma_f32 v117, v117, v190, v24                            // 00000000D320: D6130075 04637D75
	v_fma_f32 v116, v116, v190, v10                            // 00000000D328: D6130074 042B7D74
	v_fma_f32 v115, v115, v190, v11                            // 00000000D330: D6130073 042F7D73
	v_fma_f32 v114, v114, v190, v12                            // 00000000D338: D6130072 04337D72
	v_fma_f32 v113, v113, v190, v13                            // 00000000D340: D6130071 04377D71
	v_fma_f32 v112, v112, v190, v14                            // 00000000D348: D6130070 043B7D70
	v_fma_f32 v111, v111, v190, v15                            // 00000000D350: D613006F 043F7D6F
	v_fma_f32 v110, v110, v190, v16                            // 00000000D358: D613006E 04437D6E
	v_dual_fmac_f32 v17, v152, v190 :: v_dual_mul_f32 v154, 0x3b800000, v137// 00000000D360: C8077D98 119B12FF 3B800000
	v_fma_f32 v109, v109, v190, v2                             // 00000000D36C: D613006D 040B7D6D
	v_fma_f32 v108, v108, v190, v3                             // 00000000D374: D613006C 040F7D6C
	v_fma_f32 v107, v107, v190, v4                             // 00000000D37C: D613006B 04137D6B
	v_fma_f32 v106, v106, v190, v5                             // 00000000D384: D613006A 04177D6A
	v_fma_f32 v105, v105, v190, v6                             // 00000000D38C: D6130069 041B7D69
	v_fma_f32 v104, v104, v190, v7                             // 00000000D394: D6130068 041F7D68
	v_fma_f32 v103, v103, v190, v8                             // 00000000D39C: D6130067 04237D67
	v_fmac_f32_e32 v9, v151, v190                              // 00000000D3A4: 56137D97
	v_fma_f32 v102, v102, v190, v26                            // 00000000D3A8: D6130066 046B7D66
	v_fma_f32 v101, v101, v190, v27                            // 00000000D3B0: D6130065 046F7D65
	v_fma_f32 v100, v100, v190, v28                            // 00000000D3B8: D6130064 04737D64
	v_fma_f32 v99, v99, v190, v29                              // 00000000D3C0: D6130063 04777D63
	v_fma_f32 v98, v98, v190, v30                              // 00000000D3C8: D6130062 047B7D62
	v_fma_f32 v97, v97, v190, v31                              // 00000000D3D0: D6130061 047F7D61
	v_fma_f32 v96, v96, v190, v32                              // 00000000D3D8: D6130060 04837D60
	v_dual_fmac_f32 v33, v150, v190 :: v_dual_mul_f32 v4, 0x3b800000, v133// 00000000D3E0: C8077D96 21050AFF 3B800000
	v_fma_f32 v91, v91, v190, v42                              // 00000000D3EC: D613005B 04AB7D5B
	v_fma_f32 v90, v90, v190, v43                              // 00000000D3F4: D613005A 04AF7D5A
	v_fma_f32 v89, v89, v190, v44                              // 00000000D3FC: D6130059 04B37D59
	v_dual_fmac_f32 v45, v149, v190 :: v_dual_mul_f32 v158, 0x3b800000, v132// 00000000D404: C8077D95 2D9F08FF 3B800000
	v_fma_f32 v87, v87, v190, v34                              // 00000000D410: D6130057 048B7D57
	v_fma_f32 v86, v86, v190, v35                              // 00000000D418: D6130056 048F7D56
	v_fma_f32 v85, v85, v190, v36                              // 00000000D420: D6130055 04937D55
	v_fma_f32 v82, v82, v190, v37                              // 00000000D428: D6130052 04977D52
	v_fma_f32 v88, v88, v190, v38                              // 00000000D430: D6130058 049B7D58
	v_fma_f32 v83, v83, v190, v39                              // 00000000D438: D6130053 049F7D53
	v_fma_f32 v84, v84, v190, v40                              // 00000000D440: D6130054 04A37D54
	v_dual_fmac_f32 v41, v148, v190 :: v_dual_mul_f32 v148, 0x3b800000, v128// 00000000D448: C8077D94 299500FF 3B800000
	v_lshl_add_u32 v2, v157, 7, v156                           // 00000000D454: D6460002 06710F9D
	v_dual_mul_f32 v155, 0x3b800000, v136 :: v_dual_mul_f32 v156, 0x3b800000, v135// 00000000D45C: C8C710FF 9B9D0EFF 3B800000
	v_dual_mul_f32 v157, 0x3b800000, v134 :: v_dual_mul_f32 v150, 0x3b800000, v125// 00000000D468: C8C70CFF 9D96FAFF 3B800000
	v_dual_mul_f32 v159, 0x3b800000, v131 :: v_dual_mul_f32 v160, 0x3b800000, v54// 00000000D474: C8C706FF 9FA06CFF 3B800000
	v_mul_f32_e32 v149, 0x3b800000, v127                       // 00000000D480: 112AFEFF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v130 :: v_dual_mul_f32 v62, 0x3b800000, v120// 00000000D488: C8C704FF 053EF0FF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v126 :: v_dual_mul_f32 v151, 0x3b800000, v124// 00000000D494: C8C6FCFF 0696F8FF 3B800000
	v_dual_mul_f32 v152, 0x3b800000, v46 :: v_dual_mul_f32 v7, 0x3b800000, v123// 00000000D4A0: C8C65CFF 9806F6FF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v122 :: v_dual_mul_f32 v61, 0x3b800000, v121// 00000000D4AC: C8C6F4FF 3C3CF2FF 3B800000
	v_dual_mul_f32 v8, 0x3b800000, v119 :: v_dual_mul_f32 v53, 0x3b800000, v118// 00000000D4B8: C8C6EEFF 0834ECFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v10, 0x3b800000, v116// 00000000D4C4: C8C6EAFF 370AE8FF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v25 :: v_dual_mul_f32 v57, 0x3b800000, v115// 00000000D4D0: C8C632FF 3838E6FF 3B800000
	v_dual_mul_f32 v58, 0x3b800000, v114 :: v_dual_mul_f32 v59, 0x3b800000, v113// 00000000D4DC: C8C6E4FF 3A3AE2FF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v52, 0x3b800000, v110// 00000000D4E8: C8C6E0FF 0B34DCFF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v111 :: v_dual_mul_f32 v40, 0x3b800000, v17// 00000000D4F4: C8C6DEFF 332822FF 3B800000
	v_dual_mul_f32 v12, 0x3b800000, v109 :: v_dual_mul_f32 v43, 0x3b800000, v108// 00000000D500: C8C6DAFF 0C2AD8FF 3B800000
	v_dual_mul_f32 v44, 0x3b800000, v107 :: v_dual_mul_f32 v47, 0x3b800000, v106// 00000000D50C: C8C6D6FF 2C2ED4FF 3B800000
	v_dual_mul_f32 v14, 0x3b800000, v105 :: v_dual_mul_f32 v49, 0x3b800000, v103// 00000000D518: C8C6D2FF 0E30CEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v104 :: v_dual_mul_f32 v15, 0x3b800000, v102// 00000000D524: C8C6D0FF 300ECCFF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v9 :: v_dual_mul_f32 v35, 0x3b800000, v100// 00000000D530: C8C612FF 3222C8FF 3B800000
	v_dual_mul_f32 v42, 0x3b800000, v101 :: v_dual_mul_f32 v27, 0x3b800000, v98// 00000000D53C: C8C6CAFF 2A1AC4FF 3B800000
	v_dual_mul_f32 v36, 0x3b800000, v99 :: v_dual_mul_f32 v37, 0x3b800000, v97// 00000000D548: C8C6C6FF 2424C2FF 3B800000
	v_dual_mul_f32 v38, 0x3b800000, v96 :: v_dual_mul_f32 v39, 0x3b800000, v33// 00000000D554: C8C6C0FF 262642FF 3B800000
	v_dual_mul_f32 v28, 0x3b800000, v95 :: v_dual_mul_f32 v31, 0x3b800000, v94// 00000000D560: C8C6BEFF 1C1EBCFF 3B800000
	v_dual_mul_f32 v32, 0x3b800000, v93 :: v_dual_mul_f32 v29, 0x3b800000, v91// 00000000D56C: C8C6BAFF 201CB6FF 3B800000
	v_dual_mul_f32 v34, 0x3b800000, v92 :: v_dual_mul_f32 v21, 0x3b800000, v89// 00000000D578: C8C6B8FF 2214B2FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v90 :: v_dual_mul_f32 v19, 0x3b800000, v84// 00000000D584: C8C6B4FF 1412A8FF 3B800000
	v_dual_mul_f32 v22, 0x3b800000, v45 :: v_dual_mul_f32 v23, 0x3b800000, v86// 00000000D590: C8C65AFF 1616ACFF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v87 :: v_dual_mul_f32 v13, 0x3b800000, v41// 00000000D59C: C8C6AEFF 1E0C52FF 3B800000
	v_mul_f32_e32 v24, 0x3b800000, v85                         // 00000000D5A8: 1030AAFF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v82                         // 00000000D5B0: 1034A4FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v88                         // 00000000D5B8: 1020B0FF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v83                         // 00000000D5C0: 1024A6FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000000D5C8: BF89FC07
	s_barrier                                                  // 00000000D5CC: BFBD0000
	s_cbranch_scc0 5                                           // 00000000D5D0: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x50e8>
	s_cmp_lg_u32 s13, s64                                      // 00000000D5D4: BF07400D
	s_cbranch_scc0 273                                         // 00000000D5D8: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5520>
	s_cmp_lg_u32 s14, s64                                      // 00000000D5DC: BF07400E
	s_cbranch_scc1 60939                                       // 00000000D5E0: BFA2EE0B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x910>
	s_branch 540                                               // 00000000D5E4: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5958>
	v_mov_b32_e32 v161, v2                                     // 00000000D5E8: 7F420302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D5EC: BF870091
	v_ashrrev_i32_e32 v162, 31, v161                           // 00000000D5F0: 3545429F
	.long 0xd73c00a1                                           // 00000000D5F4: D73C00A1
	v_cndmask_b32_e32 v1, 2, v161, vcc_lo                      // 00000000D5F8: 02034282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D5FC: BF870091
	.long 0xd7006aa1                                           // 00000000D600: D7006AA1
	v_cndmask_b32_e32 v1, s16, v161, vcc_lo                    // 00000000D604: 02034210
	v_add_co_ci_u32_e64 v162, null, s17, v162, vcc_lo          // 00000000D608: D5207CA2 01AB4411
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000D610: BF870092
	.long 0xd7006aa3                                           // 00000000D614: D7006AA3
	v_cndmask_b32_e32 v1, 0x1000, v161, vcc_lo                 // 00000000D618: 020342FF 00001000
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D620: D5207CA4 01AB4480
	.long 0xd7006aa5                                           // 00000000D628: D7006AA5
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D62C: 0201FFA1
	.long 0x00002000                                           // 00000000D630: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D634: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v162, vcc_lo            // 00000000D638: D5207CA6 01AB4480
	.long 0xd7006aa7                                           // 00000000D640: D7006AA7
	v_cndmask_b32_e32 v1, 0x2000, v161, vcc_lo                 // 00000000D644: 020342FF 00002000
	v_add_co_ci_u32_e64 v168, null, 0, v162, vcc_lo            // 00000000D64C: D5207CA8 01AB4480
	s_clause 0x7                                               // 00000000D654: BF850007
	global_store_b32 v[161:162], v154, off                     // 00000000D658: DC6A0000 007C9AA1
	global_store_b32 v[161:162], v155, off offset:1024         // 00000000D660: DC6A0400 007C9BA1
	global_store_b32 v[161:162], v156, off offset:2048         // 00000000D668: DC6A0800 007C9CA1
	global_store_b32 v[161:162], v157, off offset:3072         // 00000000D670: DC6A0C00 007C9DA1
	global_store_b32 v[163:164], v158, off offset:1024         // 00000000D678: DC6A0400 007C9EA3
	global_store_b32 v[163:164], v159, off offset:2048         // 00000000D680: DC6A0800 007C9FA3
	global_store_b32 v[163:164], v160, off offset:3072         // 00000000D688: DC6A0C00 007CA0A3
	global_store_b32 v[167:168], v153, off offset:1024         // 00000000D690: DC6A0400 007C99A7
	.long 0xd7006aa3                                           // 00000000D698: D7006AA3
	v_cndmask_b32_e32 v1, 0x3000, v161, vcc_lo                 // 00000000D69C: 020342FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D6A4: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D6A8: D5207CA4 01AB4480
	.long 0xd7006aa9                                           // 00000000D6B0: D7006AA9
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D6B4: 0201FFA1
	.long 0x00004000                                           // 00000000D6B8: 00004000
	v_add_co_ci_u32_e64 v170, null, 0, v162, vcc_lo            // 00000000D6BC: D5207CAA 01AB4480
	.long 0xd7006aab                                           // 00000000D6C4: D7006AAB
	v_cndmask_b32_e32 v1, 0x4000, v161, vcc_lo                 // 00000000D6C8: 020342FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000D6D0: BF870001
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000D6D4: D5207CAC 01AB4480
	s_clause 0x7                                               // 00000000D6DC: BF850007
	global_store_b32 v[167:168], v148, off offset:2048         // 00000000D6E0: DC6A0800 007C94A7
	global_store_b32 v[167:168], v149, off offset:3072         // 00000000D6E8: DC6A0C00 007C95A7
	global_store_b32 v[163:164], v150, off offset:1024         // 00000000D6F0: DC6A0400 007C96A3
	global_store_b32 v[163:164], v151, off offset:2048         // 00000000D6F8: DC6A0800 007C97A3
	global_store_b32 v[163:164], v152, off offset:3072         // 00000000D700: DC6A0C00 007C98A3
	global_store_b32 v[171:172], v60, off offset:1024          // 00000000D708: DC6A0400 007C3CAB
	global_store_b32 v[171:172], v61, off offset:2048          // 00000000D710: DC6A0800 007C3DAB
	global_store_b32 v[171:172], v62, off offset:3072          // 00000000D718: DC6A0C00 007C3EAB
	.long 0xd7006aa3                                           // 00000000D720: D7006AA3
	v_cndmask_b32_e32 v1, 0x5000, v161, vcc_lo                 // 00000000D724: 020342FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D72C: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D730: D5207CA4 01AB4480
	.long 0xd7006aa7                                           // 00000000D738: D7006AA7
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D73C: 0201FFA1
	.long 0x00006000                                           // 00000000D740: 00006000
	v_add_co_ci_u32_e64 v168, null, 0, v162, vcc_lo            // 00000000D744: D5207CA8 01AB4480
	.long 0xd7006aab                                           // 00000000D74C: D7006AAB
	v_cndmask_b32_e32 v1, 0x6000, v161, vcc_lo                 // 00000000D750: 020342FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D758: BF8700A1
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000D75C: D5207CAC 01AB4480
	.long 0xd7006aad                                           // 00000000D764: D7006AAD
	v_cndmask_b32_e32 v1, 0x7000, v161, vcc_lo                 // 00000000D768: 020342FF 00007000
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000D770: D5207CAE 01AB4480
	.long 0xd7006aaf                                           // 00000000D778: D7006AAF
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D77C: 0201FFA1
	.long 0x00008000                                           // 00000000D780: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000D784: BF870001
	v_add_co_ci_u32_e64 v176, null, 0, v162, vcc_lo            // 00000000D788: D5207CB0 01AB4480
	s_clause 0x7                                               // 00000000D790: BF850007
	global_store_b32 v[163:164], v53, off offset:1024          // 00000000D794: DC6A0400 007C35A3
	global_store_b32 v[163:164], v55, off offset:2048          // 00000000D79C: DC6A0800 007C37A3
	global_store_b32 v[163:164], v56, off offset:3072          // 00000000D7A4: DC6A0C00 007C38A3
	global_store_b32 v[171:172], v57, off offset:1024          // 00000000D7AC: DC6A0400 007C39AB
	global_store_b32 v[171:172], v58, off offset:2048          // 00000000D7B4: DC6A0800 007C3AAB
	global_store_b32 v[171:172], v59, off offset:3072          // 00000000D7BC: DC6A0C00 007C3BAB
	global_store_b32 v[173:174], v51, off offset:1024          // 00000000D7C4: DC6A0400 007C33AD
	global_store_b32 v[173:174], v52, off offset:2048          // 00000000D7CC: DC6A0800 007C34AD
	.long 0xd7006aa3                                           // 00000000D7D4: D7006AA3
	v_cndmask_b32_e32 v1, 0x8000, v161, vcc_lo                 // 00000000D7D8: 020342FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D7E0: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D7E4: D5207CA4 01AB4480
	.long 0xd7006aab                                           // 00000000D7EC: D7006AAB
	v_cndmask_b32_e32 v1, 0x9000, v161, vcc_lo                 // 00000000D7F0: 020342FF 00009000
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000D7F8: D5207CAC 01AB4480
	.long 0xd7006ab1                                           // 00000000D800: D7006AB1
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D804: 0201FFA1
	.long 0x0000a000                                           // 00000000D808: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D80C: BF8700A1
	v_add_co_ci_u32_e64 v178, null, 0, v162, vcc_lo            // 00000000D810: D5207CB2 01AB4480
	.long 0xd7006ab3                                           // 00000000D818: D7006AB3
	v_cndmask_b32_e32 v1, 0xa000, v161, vcc_lo                 // 00000000D81C: 020342FF 0000A000
	v_add_co_ci_u32_e64 v180, null, 0, v162, vcc_lo            // 00000000D824: D5207CB4 01AB4480
	s_clause 0x7                                               // 00000000D82C: BF850007
	global_store_b32 v[173:174], v40, off offset:3072          // 00000000D830: DC6A0C00 007C28AD
	global_store_b32 v[163:164], v43, off offset:1024          // 00000000D838: DC6A0400 007C2BA3
	global_store_b32 v[163:164], v44, off offset:2048          // 00000000D840: DC6A0800 007C2CA3
	global_store_b32 v[163:164], v47, off offset:3072          // 00000000D848: DC6A0C00 007C2FA3
	global_store_b32 v[171:172], v48, off offset:1024          // 00000000D850: DC6A0400 007C30AB
	global_store_b32 v[171:172], v49, off offset:2048          // 00000000D858: DC6A0800 007C31AB
	global_store_b32 v[171:172], v50, off offset:3072          // 00000000D860: DC6A0C00 007C32AB
	global_store_b32 v[179:180], v42, off offset:1024          // 00000000D868: DC6A0400 007C2AB3
	.long 0xd7006aa3                                           // 00000000D870: D7006AA3
	v_cndmask_b32_e32 v1, 0xb000, v161, vcc_lo                 // 00000000D874: 020342FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D87C: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D880: D5207CA4 01AB4480
	.long 0xd7006aab                                           // 00000000D888: D7006AAB
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D88C: 0201FFA1
	.long 0x0000c000                                           // 00000000D890: 0000C000
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000D894: D5207CAC 01AB4480
	.long 0xd7006aad                                           // 00000000D89C: D7006AAD
	v_cndmask_b32_e32 v1, 0xc000, v161, vcc_lo                 // 00000000D8A0: 020342FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000D8A8: BF870001
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000D8AC: D5207CAE 01AB4480
	s_clause 0x7                                               // 00000000D8B4: BF850007
	global_store_b32 v[179:180], v35, off offset:2048          // 00000000D8B8: DC6A0800 007C23B3
	global_store_b32 v[179:180], v36, off offset:3072          // 00000000D8C0: DC6A0C00 007C24B3
	global_store_b32 v[163:164], v37, off offset:1024          // 00000000D8C8: DC6A0400 007C25A3
	global_store_b32 v[163:164], v38, off offset:2048          // 00000000D8D0: DC6A0800 007C26A3
	global_store_b32 v[163:164], v39, off offset:3072          // 00000000D8D8: DC6A0C00 007C27A3
	global_store_b32 v[173:174], v31, off offset:1024          // 00000000D8E0: DC6A0400 007C1FAD
	global_store_b32 v[173:174], v32, off offset:2048          // 00000000D8E8: DC6A0800 007C20AD
	global_store_b32 v[173:174], v34, off offset:3072          // 00000000D8F0: DC6A0C00 007C22AD
	.long 0xd7006aa3                                           // 00000000D8F8: D7006AA3
	v_cndmask_b32_e32 v1, 0xd000, v161, vcc_lo                 // 00000000D8FC: 020342FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000D904: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000D908: D5207CA4 01AB4480
	.long 0xd7006aad                                           // 00000000D910: D7006AAD
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000D914: 0201FFA1
	.long 0x0000e000                                           // 00000000D918: 0000E000
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000D91C: D5207CAE 01AB4480
	.long 0xd7006ab3                                           // 00000000D924: D7006AB3
	v_cndmask_b32_e32 v1, 0xe000, v161, vcc_lo                 // 00000000D928: 020342FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000D930: BF870001
	v_add_co_ci_u32_e64 v180, null, 0, v162, vcc_lo            // 00000000D934: D5207CB4 01AB4480
	.long 0xd7006aa1                                           // 00000000D93C: D7006AA1
	v_cndmask_b32_e32 v1, 0xf000, v161, vcc_lo                 // 00000000D940: 020342FF 0000F000
	s_clause 0x7                                               // 00000000D948: BF850007
	global_store_b32 v[175:176], v11, off offset:-4096         // 00000000D94C: DC6A1000 007C0BAF
	global_store_b32 v[175:176], v12, off                      // 00000000D954: DC6A0000 007C0CAF
	global_store_b32 v[177:178], v14, off offset:-4096         // 00000000D95C: DC6A1000 007C0EB1
	global_store_b32 v[177:178], v15, off                      // 00000000D964: DC6A0000 007C0FB1
	global_store_b32 v[171:172], v27, off offset:-4096         // 00000000D96C: DC6A1000 007C1BAB
	global_store_b32 v[171:172], v28, off                      // 00000000D974: DC6A0000 007C1CAB
	global_store_b32 v[173:174], v29, off offset:-4096         // 00000000D97C: DC6A1000 007C1DAD
	global_store_b32 v[173:174], v30, off                      // 00000000D984: DC6A0000 007C1EAD
	v_add_co_ci_u32_e64 v162, null, 0, v162, vcc_lo            // 00000000D98C: D5207CA2 01AB4480
	s_clause 0xf                                               // 00000000D994: BF85000F
	global_store_b32 v[163:164], v20, off offset:1024          // 00000000D998: DC6A0400 007C14A3
	global_store_b32 v[163:164], v21, off offset:2048          // 00000000D9A0: DC6A0800 007C15A3
	global_store_b32 v[163:164], v22, off offset:3072          // 00000000D9A8: DC6A0C00 007C16A3
	global_store_b32 v[179:180], v23, off offset:1024          // 00000000D9B0: DC6A0400 007C17B3
	global_store_b32 v[179:180], v24, off offset:2048          // 00000000D9B8: DC6A0800 007C18B3
	global_store_b32 v[179:180], v26, off offset:3072          // 00000000D9C0: DC6A0C00 007C1AB3
	global_store_b32 v[161:162], v16, off                      // 00000000D9C8: DC6A0000 007C10A1
	global_store_b32 v[161:162], v18, off offset:1024          // 00000000D9D0: DC6A0400 007C12A1
	global_store_b32 v[161:162], v19, off offset:2048          // 00000000D9D8: DC6A0800 007C13A1
	global_store_b32 v[165:166], v4, off offset:-4096          // 00000000D9E0: DC6A1000 007C04A5
	global_store_b32 v[165:166], v5, off                       // 00000000D9E8: DC6A0000 007C05A5
	global_store_b32 v[169:170], v6, off offset:-4096          // 00000000D9F0: DC6A1000 007C06A9
	global_store_b32 v[169:170], v7, off                       // 00000000D9F8: DC6A0000 007C07A9
	global_store_b32 v[167:168], v8, off offset:-4096          // 00000000DA00: DC6A1000 007C08A7
	global_store_b32 v[167:168], v10, off                      // 00000000DA08: DC6A0000 007C0AA7
	global_store_b32 v[161:162], v13, off offset:3072          // 00000000DA10: DC6A0C00 007C0DA1
	s_cmp_lg_u32 s13, s64                                      // 00000000DA18: BF07400D
	s_cbranch_scc1 65263                                       // 00000000DA1C: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x50dc>
	v_mov_b32_e32 v161, v2                                     // 00000000DA20: 7F420302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000DA24: BF870091
	v_ashrrev_i32_e32 v162, 31, v161                           // 00000000DA28: 3545429F
	.long 0xd73c00a1                                           // 00000000DA2C: D73C00A1
	v_cndmask_b32_e32 v1, 2, v161, vcc_lo                      // 00000000DA30: 02034282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000DA34: BF870091
	.long 0xd7006aa1                                           // 00000000DA38: D7006AA1
	v_cndmask_b32_e32 v1, s18, v161, vcc_lo                    // 00000000DA3C: 02034212
	v_add_co_ci_u32_e64 v162, null, s19, v162, vcc_lo          // 00000000DA40: D5207CA2 01AB4413
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000DA48: BF870092
	.long 0xd7006aa3                                           // 00000000DA4C: D7006AA3
	v_cndmask_b32_e32 v1, 0x1000, v161, vcc_lo                 // 00000000DA50: 020342FF 00001000
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DA58: D5207CA4 01AB4480
	.long 0xd7006aa5                                           // 00000000DA60: D7006AA5
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DA64: 0201FFA1
	.long 0x00002000                                           // 00000000DA68: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DA6C: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v162, vcc_lo            // 00000000DA70: D5207CA6 01AB4480
	.long 0xd7006aa7                                           // 00000000DA78: D7006AA7
	v_cndmask_b32_e32 v1, 0x2000, v161, vcc_lo                 // 00000000DA7C: 020342FF 00002000
	v_add_co_ci_u32_e64 v168, null, 0, v162, vcc_lo            // 00000000DA84: D5207CA8 01AB4480
	s_clause 0x7                                               // 00000000DA8C: BF850007
	global_store_b32 v[161:162], v154, off                     // 00000000DA90: DC6A0000 007C9AA1
	global_store_b32 v[161:162], v155, off offset:1024         // 00000000DA98: DC6A0400 007C9BA1
	global_store_b32 v[161:162], v156, off offset:2048         // 00000000DAA0: DC6A0800 007C9CA1
	global_store_b32 v[161:162], v157, off offset:3072         // 00000000DAA8: DC6A0C00 007C9DA1
	global_store_b32 v[163:164], v158, off offset:1024         // 00000000DAB0: DC6A0400 007C9EA3
	global_store_b32 v[163:164], v159, off offset:2048         // 00000000DAB8: DC6A0800 007C9FA3
	global_store_b32 v[163:164], v160, off offset:3072         // 00000000DAC0: DC6A0C00 007CA0A3
	global_store_b32 v[167:168], v153, off offset:1024         // 00000000DAC8: DC6A0400 007C99A7
	.long 0xd7006aa3                                           // 00000000DAD0: D7006AA3
	v_cndmask_b32_e32 v1, 0x3000, v161, vcc_lo                 // 00000000DAD4: 020342FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DADC: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DAE0: D5207CA4 01AB4480
	.long 0xd7006aa9                                           // 00000000DAE8: D7006AA9
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DAEC: 0201FFA1
	.long 0x00004000                                           // 00000000DAF0: 00004000
	v_add_co_ci_u32_e64 v170, null, 0, v162, vcc_lo            // 00000000DAF4: D5207CAA 01AB4480
	.long 0xd7006aab                                           // 00000000DAFC: D7006AAB
	v_cndmask_b32_e32 v1, 0x4000, v161, vcc_lo                 // 00000000DB00: 020342FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DB08: BF870001
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000DB0C: D5207CAC 01AB4480
	s_clause 0x7                                               // 00000000DB14: BF850007
	global_store_b32 v[167:168], v148, off offset:2048         // 00000000DB18: DC6A0800 007C94A7
	global_store_b32 v[167:168], v149, off offset:3072         // 00000000DB20: DC6A0C00 007C95A7
	global_store_b32 v[163:164], v150, off offset:1024         // 00000000DB28: DC6A0400 007C96A3
	global_store_b32 v[163:164], v151, off offset:2048         // 00000000DB30: DC6A0800 007C97A3
	global_store_b32 v[163:164], v152, off offset:3072         // 00000000DB38: DC6A0C00 007C98A3
	global_store_b32 v[171:172], v60, off offset:1024          // 00000000DB40: DC6A0400 007C3CAB
	global_store_b32 v[171:172], v61, off offset:2048          // 00000000DB48: DC6A0800 007C3DAB
	global_store_b32 v[171:172], v62, off offset:3072          // 00000000DB50: DC6A0C00 007C3EAB
	.long 0xd7006aa3                                           // 00000000DB58: D7006AA3
	v_cndmask_b32_e32 v1, 0x5000, v161, vcc_lo                 // 00000000DB5C: 020342FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DB64: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DB68: D5207CA4 01AB4480
	.long 0xd7006aa7                                           // 00000000DB70: D7006AA7
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DB74: 0201FFA1
	.long 0x00006000                                           // 00000000DB78: 00006000
	v_add_co_ci_u32_e64 v168, null, 0, v162, vcc_lo            // 00000000DB7C: D5207CA8 01AB4480
	.long 0xd7006aab                                           // 00000000DB84: D7006AAB
	v_cndmask_b32_e32 v1, 0x6000, v161, vcc_lo                 // 00000000DB88: 020342FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DB90: BF8700A1
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000DB94: D5207CAC 01AB4480
	.long 0xd7006aad                                           // 00000000DB9C: D7006AAD
	v_cndmask_b32_e32 v1, 0x7000, v161, vcc_lo                 // 00000000DBA0: 020342FF 00007000
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000DBA8: D5207CAE 01AB4480
	.long 0xd7006aaf                                           // 00000000DBB0: D7006AAF
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DBB4: 0201FFA1
	.long 0x00008000                                           // 00000000DBB8: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DBBC: BF870001
	v_add_co_ci_u32_e64 v176, null, 0, v162, vcc_lo            // 00000000DBC0: D5207CB0 01AB4480
	s_clause 0x7                                               // 00000000DBC8: BF850007
	global_store_b32 v[163:164], v53, off offset:1024          // 00000000DBCC: DC6A0400 007C35A3
	global_store_b32 v[163:164], v55, off offset:2048          // 00000000DBD4: DC6A0800 007C37A3
	global_store_b32 v[163:164], v56, off offset:3072          // 00000000DBDC: DC6A0C00 007C38A3
	global_store_b32 v[171:172], v57, off offset:1024          // 00000000DBE4: DC6A0400 007C39AB
	global_store_b32 v[171:172], v58, off offset:2048          // 00000000DBEC: DC6A0800 007C3AAB
	global_store_b32 v[171:172], v59, off offset:3072          // 00000000DBF4: DC6A0C00 007C3BAB
	global_store_b32 v[173:174], v51, off offset:1024          // 00000000DBFC: DC6A0400 007C33AD
	global_store_b32 v[173:174], v52, off offset:2048          // 00000000DC04: DC6A0800 007C34AD
	.long 0xd7006aa3                                           // 00000000DC0C: D7006AA3
	v_cndmask_b32_e32 v1, 0x8000, v161, vcc_lo                 // 00000000DC10: 020342FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DC18: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DC1C: D5207CA4 01AB4480
	.long 0xd7006aab                                           // 00000000DC24: D7006AAB
	v_cndmask_b32_e32 v1, 0x9000, v161, vcc_lo                 // 00000000DC28: 020342FF 00009000
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000DC30: D5207CAC 01AB4480
	.long 0xd7006ab1                                           // 00000000DC38: D7006AB1
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DC3C: 0201FFA1
	.long 0x0000a000                                           // 00000000DC40: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DC44: BF8700A1
	v_add_co_ci_u32_e64 v178, null, 0, v162, vcc_lo            // 00000000DC48: D5207CB2 01AB4480
	.long 0xd7006ab3                                           // 00000000DC50: D7006AB3
	v_cndmask_b32_e32 v1, 0xa000, v161, vcc_lo                 // 00000000DC54: 020342FF 0000A000
	v_add_co_ci_u32_e64 v180, null, 0, v162, vcc_lo            // 00000000DC5C: D5207CB4 01AB4480
	s_clause 0x7                                               // 00000000DC64: BF850007
	global_store_b32 v[173:174], v40, off offset:3072          // 00000000DC68: DC6A0C00 007C28AD
	global_store_b32 v[163:164], v43, off offset:1024          // 00000000DC70: DC6A0400 007C2BA3
	global_store_b32 v[163:164], v44, off offset:2048          // 00000000DC78: DC6A0800 007C2CA3
	global_store_b32 v[163:164], v47, off offset:3072          // 00000000DC80: DC6A0C00 007C2FA3
	global_store_b32 v[171:172], v48, off offset:1024          // 00000000DC88: DC6A0400 007C30AB
	global_store_b32 v[171:172], v49, off offset:2048          // 00000000DC90: DC6A0800 007C31AB
	global_store_b32 v[171:172], v50, off offset:3072          // 00000000DC98: DC6A0C00 007C32AB
	global_store_b32 v[179:180], v42, off offset:1024          // 00000000DCA0: DC6A0400 007C2AB3
	.long 0xd7006aa3                                           // 00000000DCA8: D7006AA3
	v_cndmask_b32_e32 v1, 0xb000, v161, vcc_lo                 // 00000000DCAC: 020342FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DCB4: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DCB8: D5207CA4 01AB4480
	.long 0xd7006aab                                           // 00000000DCC0: D7006AAB
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DCC4: 0201FFA1
	.long 0x0000c000                                           // 00000000DCC8: 0000C000
	v_add_co_ci_u32_e64 v172, null, 0, v162, vcc_lo            // 00000000DCCC: D5207CAC 01AB4480
	.long 0xd7006aad                                           // 00000000DCD4: D7006AAD
	v_cndmask_b32_e32 v1, 0xc000, v161, vcc_lo                 // 00000000DCD8: 020342FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DCE0: BF870001
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000DCE4: D5207CAE 01AB4480
	s_clause 0x7                                               // 00000000DCEC: BF850007
	global_store_b32 v[179:180], v35, off offset:2048          // 00000000DCF0: DC6A0800 007C23B3
	global_store_b32 v[179:180], v36, off offset:3072          // 00000000DCF8: DC6A0C00 007C24B3
	global_store_b32 v[163:164], v37, off offset:1024          // 00000000DD00: DC6A0400 007C25A3
	global_store_b32 v[163:164], v38, off offset:2048          // 00000000DD08: DC6A0800 007C26A3
	global_store_b32 v[163:164], v39, off offset:3072          // 00000000DD10: DC6A0C00 007C27A3
	global_store_b32 v[173:174], v31, off offset:1024          // 00000000DD18: DC6A0400 007C1FAD
	global_store_b32 v[173:174], v32, off offset:2048          // 00000000DD20: DC6A0800 007C20AD
	global_store_b32 v[173:174], v34, off offset:3072          // 00000000DD28: DC6A0C00 007C22AD
	.long 0xd7006aa3                                           // 00000000DD30: D7006AA3
	v_cndmask_b32_e32 v1, 0xd000, v161, vcc_lo                 // 00000000DD34: 020342FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DD3C: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v162, vcc_lo            // 00000000DD40: D5207CA4 01AB4480
	.long 0xd7006aad                                           // 00000000DD48: D7006AAD
	v_cndmask_b32_e32 v0, v161, v255, vcc_lo                   // 00000000DD4C: 0201FFA1
	.long 0x0000e000                                           // 00000000DD50: 0000E000
	v_add_co_ci_u32_e64 v174, null, 0, v162, vcc_lo            // 00000000DD54: D5207CAE 01AB4480
	.long 0xd7006ab3                                           // 00000000DD5C: D7006AB3
	v_cndmask_b32_e32 v1, 0xe000, v161, vcc_lo                 // 00000000DD60: 020342FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DD68: BF870001
	v_add_co_ci_u32_e64 v180, null, 0, v162, vcc_lo            // 00000000DD6C: D5207CB4 01AB4480
	.long 0xd7006aa1                                           // 00000000DD74: D7006AA1
	v_cndmask_b32_e32 v1, 0xf000, v161, vcc_lo                 // 00000000DD78: 020342FF 0000F000
	s_clause 0x7                                               // 00000000DD80: BF850007
	global_store_b32 v[175:176], v11, off offset:-4096         // 00000000DD84: DC6A1000 007C0BAF
	global_store_b32 v[175:176], v12, off                      // 00000000DD8C: DC6A0000 007C0CAF
	global_store_b32 v[177:178], v14, off offset:-4096         // 00000000DD94: DC6A1000 007C0EB1
	global_store_b32 v[177:178], v15, off                      // 00000000DD9C: DC6A0000 007C0FB1
	global_store_b32 v[171:172], v27, off offset:-4096         // 00000000DDA4: DC6A1000 007C1BAB
	global_store_b32 v[171:172], v28, off                      // 00000000DDAC: DC6A0000 007C1CAB
	global_store_b32 v[173:174], v29, off offset:-4096         // 00000000DDB4: DC6A1000 007C1DAD
	global_store_b32 v[173:174], v30, off                      // 00000000DDBC: DC6A0000 007C1EAD
	v_add_co_ci_u32_e64 v162, null, 0, v162, vcc_lo            // 00000000DDC4: D5207CA2 01AB4480
	s_clause 0xf                                               // 00000000DDCC: BF85000F
	global_store_b32 v[163:164], v20, off offset:1024          // 00000000DDD0: DC6A0400 007C14A3
	global_store_b32 v[163:164], v21, off offset:2048          // 00000000DDD8: DC6A0800 007C15A3
	global_store_b32 v[163:164], v22, off offset:3072          // 00000000DDE0: DC6A0C00 007C16A3
	global_store_b32 v[179:180], v23, off offset:1024          // 00000000DDE8: DC6A0400 007C17B3
	global_store_b32 v[179:180], v24, off offset:2048          // 00000000DDF0: DC6A0800 007C18B3
	global_store_b32 v[179:180], v26, off offset:3072          // 00000000DDF8: DC6A0C00 007C1AB3
	global_store_b32 v[161:162], v16, off                      // 00000000DE00: DC6A0000 007C10A1
	global_store_b32 v[161:162], v18, off offset:1024          // 00000000DE08: DC6A0400 007C12A1
	global_store_b32 v[161:162], v19, off offset:2048          // 00000000DE10: DC6A0800 007C13A1
	global_store_b32 v[165:166], v4, off offset:-4096          // 00000000DE18: DC6A1000 007C04A5
	global_store_b32 v[165:166], v5, off                       // 00000000DE20: DC6A0000 007C05A5
	global_store_b32 v[169:170], v6, off offset:-4096          // 00000000DE28: DC6A1000 007C06A9
	global_store_b32 v[169:170], v7, off                       // 00000000DE30: DC6A0000 007C07A9
	global_store_b32 v[167:168], v8, off offset:-4096          // 00000000DE38: DC6A1000 007C08A7
	global_store_b32 v[167:168], v10, off                      // 00000000DE40: DC6A0000 007C0AA7
	global_store_b32 v[161:162], v13, off offset:3072          // 00000000DE48: DC6A0C00 007C0DA1
	s_cmp_lg_u32 s14, s64                                      // 00000000DE50: BF07400E
	s_cbranch_scc1 60398                                       // 00000000DE54: BFA2EBEE <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x910>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000000DE58: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000DE5C: BF870091
	.long 0xd73c0002                                           // 00000000DE60: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000000DE64: 02020482
	.long 0xd7006a02                                           // 00000000DE68: D7006A02
	v_cndmask_b32_e32 v1, s56, v2, vcc_lo                      // 00000000DE6C: 02020438
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000DE70: BF870111
	v_add_co_ci_u32_e64 v3, null, s57, v3, vcc_lo              // 00000000DE74: D5207C03 01AA0639
	.long 0xd7006aa1                                           // 00000000DE7C: D7006AA1
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000000DE80: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DE88: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v3, vcc_lo              // 00000000DE8C: D5207CA2 01AA0680
	.long 0xd7006aa3                                           // 00000000DE94: D7006AA3
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000DE98: 0201FF02
	.long 0x00002000                                           // 00000000DE9C: 00002000
	v_add_co_ci_u32_e64 v164, null, 0, v3, vcc_lo              // 00000000DEA0: D5207CA4 01AA0680
	.long 0xd7006aa5                                           // 00000000DEA8: D7006AA5
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000000DEAC: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DEB4: BF870001
	v_add_co_ci_u32_e64 v166, null, 0, v3, vcc_lo              // 00000000DEB8: D5207CA6 01AA0680
	s_clause 0x7                                               // 00000000DEC0: BF850007
	global_store_b32 v[2:3], v154, off                         // 00000000DEC4: DC6A0000 007C9A02
	global_store_b32 v[2:3], v155, off offset:1024             // 00000000DECC: DC6A0400 007C9B02
	global_store_b32 v[2:3], v156, off offset:2048             // 00000000DED4: DC6A0800 007C9C02
	global_store_b32 v[2:3], v157, off offset:3072             // 00000000DEDC: DC6A0C00 007C9D02
	global_store_b32 v[161:162], v158, off offset:1024         // 00000000DEE4: DC6A0400 007C9EA1
	global_store_b32 v[161:162], v159, off offset:2048         // 00000000DEEC: DC6A0800 007C9FA1
	global_store_b32 v[161:162], v160, off offset:3072         // 00000000DEF4: DC6A0C00 007CA0A1
	global_store_b32 v[165:166], v153, off offset:1024         // 00000000DEFC: DC6A0400 007C99A5
	.long 0xd7006a99                                           // 00000000DF04: D7006A99
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000000DF08: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DF10: BF8700A1
	v_add_co_ci_u32_e64 v154, null, 0, v3, vcc_lo              // 00000000DF14: D5207C9A 01AA0680
	.long 0xd7006a9b                                           // 00000000DF1C: D7006A9B
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000DF20: 0201FF02
	.long 0x00004000                                           // 00000000DF24: 00004000
	v_add_co_ci_u32_e64 v156, null, 0, v3, vcc_lo              // 00000000DF28: D5207C9C 01AA0680
	.long 0xd7006a9d                                           // 00000000DF30: D7006A9D
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 00000000DF34: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DF3C: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v3, vcc_lo              // 00000000DF40: D5207C9E 01AA0680
	s_clause 0x7                                               // 00000000DF48: BF850007
	global_store_b32 v[165:166], v148, off offset:2048         // 00000000DF4C: DC6A0800 007C94A5
	global_store_b32 v[165:166], v149, off offset:3072         // 00000000DF54: DC6A0C00 007C95A5
	global_store_b32 v[153:154], v150, off offset:1024         // 00000000DF5C: DC6A0400 007C9699
	global_store_b32 v[153:154], v151, off offset:2048         // 00000000DF64: DC6A0800 007C9799
	global_store_b32 v[153:154], v152, off offset:3072         // 00000000DF6C: DC6A0C00 007C9899
	global_store_b32 v[157:158], v60, off offset:1024          // 00000000DF74: DC6A0400 007C3C9D
	global_store_b32 v[157:158], v61, off offset:2048          // 00000000DF7C: DC6A0800 007C3D9D
	global_store_b32 v[157:158], v62, off offset:3072          // 00000000DF84: DC6A0C00 007C3E9D
	.long 0xd7006a3c                                           // 00000000DF8C: D7006A3C
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 00000000DF90: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DF98: BF8700A1
	v_add_co_ci_u32_e64 v61, null, 0, v3, vcc_lo               // 00000000DF9C: D5207C3D 01AA0680
	.long 0xd7006a94                                           // 00000000DFA4: D7006A94
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000DFA8: 0201FF02
	.long 0x00006000                                           // 00000000DFAC: 00006000
	v_add_co_ci_u32_e64 v149, null, 0, v3, vcc_lo              // 00000000DFB0: D5207C95 01AA0680
	.long 0xd7006a96                                           // 00000000DFB8: D7006A96
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000000DFBC: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000DFC4: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v3, vcc_lo              // 00000000DFC8: D5207C97 01AA0680
	.long 0xd7006a98                                           // 00000000DFD0: D7006A98
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000000DFD4: 020204FF 00007000
	v_add_co_ci_u32_e64 v153, null, 0, v3, vcc_lo              // 00000000DFDC: D5207C99 01AA0680
	.long 0xd7006a9d                                           // 00000000DFE4: D7006A9D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000DFE8: 0201FF02
	.long 0x00008000                                           // 00000000DFEC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000DFF0: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v3, vcc_lo              // 00000000DFF4: D5207C9E 01AA0680
	s_clause 0x7                                               // 00000000DFFC: BF850007
	global_store_b32 v[60:61], v53, off offset:1024            // 00000000E000: DC6A0400 007C353C
	global_store_b32 v[60:61], v55, off offset:2048            // 00000000E008: DC6A0800 007C373C
	global_store_b32 v[60:61], v56, off offset:3072            // 00000000E010: DC6A0C00 007C383C
	global_store_b32 v[150:151], v57, off offset:1024          // 00000000E018: DC6A0400 007C3996
	global_store_b32 v[150:151], v58, off offset:2048          // 00000000E020: DC6A0800 007C3A96
	global_store_b32 v[150:151], v59, off offset:3072          // 00000000E028: DC6A0C00 007C3B96
	global_store_b32 v[152:153], v51, off offset:1024          // 00000000E030: DC6A0400 007C3398
	global_store_b32 v[152:153], v52, off offset:2048          // 00000000E038: DC6A0800 007C3498
	.long 0xd7006a33                                           // 00000000E040: D7006A33
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000000E044: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000E04C: BF8700A1
	v_add_co_ci_u32_e64 v52, null, 0, v3, vcc_lo               // 00000000E050: D5207C34 01AA0680
	.long 0xd7006a37                                           // 00000000E058: D7006A37
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000000E05C: 020204FF 00009000
	v_add_co_ci_u32_e64 v56, null, 0, v3, vcc_lo               // 00000000E064: D5207C38 01AA0680
	.long 0xd7006a39                                           // 00000000E06C: D7006A39
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000E070: 0201FF02
	.long 0x0000a000                                           // 00000000E074: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000E078: BF8700A1
	v_add_co_ci_u32_e64 v58, null, 0, v3, vcc_lo               // 00000000E07C: D5207C3A 01AA0680
	.long 0xd7006a3b                                           // 00000000E084: D7006A3B
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000000E088: 020204FF 0000A000
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000000E090: D5207C3C 01AA0680
	s_clause 0x7                                               // 00000000E098: BF850007
	global_store_b32 v[152:153], v40, off offset:3072          // 00000000E09C: DC6A0C00 007C2898
	global_store_b32 v[51:52], v43, off offset:1024            // 00000000E0A4: DC6A0400 007C2B33
	global_store_b32 v[51:52], v44, off offset:2048            // 00000000E0AC: DC6A0800 007C2C33
	global_store_b32 v[51:52], v47, off offset:3072            // 00000000E0B4: DC6A0C00 007C2F33
	global_store_b32 v[55:56], v48, off offset:1024            // 00000000E0BC: DC6A0400 007C3037
	global_store_b32 v[55:56], v49, off offset:2048            // 00000000E0C4: DC6A0800 007C3137
	global_store_b32 v[55:56], v50, off offset:3072            // 00000000E0CC: DC6A0C00 007C3237
	global_store_b32 v[59:60], v42, off offset:1024            // 00000000E0D4: DC6A0400 007C2A3B
	.long 0xd7006a2a                                           // 00000000E0DC: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 00000000E0E0: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000E0E8: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 00000000E0EC: D5207C2B 01AA0680
	.long 0xd7006a2f                                           // 00000000E0F4: D7006A2F
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000E0F8: 0201FF02
	.long 0x0000c000                                           // 00000000E0FC: 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v3, vcc_lo               // 00000000E100: D5207C30 01AA0680
	.long 0xd7006a31                                           // 00000000E108: D7006A31
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 00000000E10C: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000E114: BF870001
	v_add_co_ci_u32_e64 v50, null, 0, v3, vcc_lo               // 00000000E118: D5207C32 01AA0680
	s_clause 0x7                                               // 00000000E120: BF850007
	global_store_b32 v[59:60], v35, off offset:2048            // 00000000E124: DC6A0800 007C233B
	global_store_b32 v[59:60], v36, off offset:3072            // 00000000E12C: DC6A0C00 007C243B
	global_store_b32 v[42:43], v37, off offset:1024            // 00000000E134: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 00000000E13C: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 00000000E144: DC6A0C00 007C272A
	global_store_b32 v[49:50], v31, off offset:1024            // 00000000E14C: DC6A0400 007C1F31
	global_store_b32 v[49:50], v32, off offset:2048            // 00000000E154: DC6A0800 007C2031
	global_store_b32 v[49:50], v34, off offset:3072            // 00000000E15C: DC6A0C00 007C2231
	.long 0xd7006a1f                                           // 00000000E164: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000000E168: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000E170: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 00000000E174: D5207C20 01AA0680
	.long 0xd7006a22                                           // 00000000E17C: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000000E180: 0201FF02
	.long 0x0000e000                                           // 00000000E184: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000000E188: D5207C23 01AA0680
	.long 0xd7006a24                                           // 00000000E190: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 00000000E194: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000E19C: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 00000000E1A0: D5207C25 01AA0680
	.long 0xd7006a02                                           // 00000000E1A8: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 00000000E1AC: 020204FF 0000F000
	s_clause 0x7                                               // 00000000E1B4: BF850007
	global_store_b32 v[157:158], v11, off offset:-4096         // 00000000E1B8: DC6A1000 007C0B9D
	global_store_b32 v[157:158], v12, off                      // 00000000E1C0: DC6A0000 007C0C9D
	global_store_b32 v[57:58], v14, off offset:-4096           // 00000000E1C8: DC6A1000 007C0E39
	global_store_b32 v[57:58], v15, off                        // 00000000E1D0: DC6A0000 007C0F39
	global_store_b32 v[47:48], v27, off offset:-4096           // 00000000E1D8: DC6A1000 007C1B2F
	global_store_b32 v[47:48], v28, off                        // 00000000E1E0: DC6A0000 007C1C2F
	global_store_b32 v[34:35], v29, off offset:-4096           // 00000000E1E8: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 00000000E1F0: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000000E1F8: D5207C03 01AA0680
	s_clause 0xf                                               // 00000000E200: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 00000000E204: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 00000000E20C: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 00000000E214: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 00000000E21C: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 00000000E224: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 00000000E22C: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 00000000E234: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 00000000E23C: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 00000000E244: DC6A0800 007C1302
	global_store_b32 v[163:164], v4, off offset:-4096          // 00000000E24C: DC6A1000 007C04A3
	global_store_b32 v[163:164], v5, off                       // 00000000E254: DC6A0000 007C05A3
	global_store_b32 v[155:156], v6, off offset:-4096          // 00000000E25C: DC6A1000 007C069B
	global_store_b32 v[155:156], v7, off                       // 00000000E264: DC6A0000 007C079B
	global_store_b32 v[148:149], v8, off offset:-4096          // 00000000E26C: DC6A1000 007C0894
	global_store_b32 v[148:149], v10, off                      // 00000000E274: DC6A0000 007C0A94
	global_store_b32 v[2:3], v13, off offset:3072              // 00000000E27C: DC6A0C00 007C0D02
	s_branch 60130                                             // 00000000E284: BFA0EAE2 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x910>
	v_dual_mov_b32 v54, v155 :: v_dual_mov_b32 v25, v153       // 00000000E288: CA10019B 36180199
	v_dual_mov_b32 v46, v154 :: v_dual_mov_b32 v17, v152       // 00000000E290: CA10019A 2E100198
	v_mov_b32_e32 v9, v151                                     // 00000000E298: 7E120397
	v_mov_b32_e32 v33, v150                                    // 00000000E29C: 7E420396
	v_mov_b32_e32 v45, v149                                    // 00000000E2A0: 7E5A0395
	v_mov_b32_e32 v41, v148                                    // 00000000E2A4: 7E520394
	v_dual_mul_f32 v3, 0x3b800000, v137 :: v_dual_mul_f32 v4, 0x3b800000, v136// 00000000E2A8: C8C712FF 030510FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v135 :: v_dual_mul_f32 v6, 0x3b800000, v134// 00000000E2B4: C8C70EFF 05070CFF 3B800000
	.long 0xd7006a01                                           // 00000000E2C0: D7006A01
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E2C4: 0201FF47
	.long 0x00002000                                           // 00000000E2C8: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v133 :: v_dual_mul_f32 v8, 0x3b800000, v132// 00000000E2CC: C8C70AFF 070908FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo               // 00000000E2D8: D5207C02 01AA9080
	v_dual_mul_f32 v10, 0x3b800000, v131 :: v_dual_mul_f32 v11, 0x3b800000, v54// 00000000E2E0: C8C706FF 0A0A6CFF 3B800000
	s_clause 0x7                                               // 00000000E2EC: BF850007
	global_store_b32 v[71:72], v3, off                         // 00000000E2F0: DC6A0000 007C0347
	global_store_b32 v[71:72], v4, off offset:1024             // 00000000E2F8: DC6A0400 007C0447
	global_store_b32 v[71:72], v5, off offset:2048             // 00000000E300: DC6A0800 007C0547
	global_store_b32 v[71:72], v6, off offset:3072             // 00000000E308: DC6A0C00 007C0647
	global_store_b32 v[1:2], v7, off offset:-4096              // 00000000E310: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 00000000E318: DC6A1400 007C0801
	global_store_b32 v[1:2], v10, off offset:-2048             // 00000000E320: DC6A1800 007C0A01
	global_store_b32 v[1:2], v11, off offset:-1024             // 00000000E328: DC6A1C00 007C0B01
	v_dual_mul_f32 v5, 0x3b800000, v130 :: v_dual_mul_f32 v6, 0x3b800000, v129// 00000000E330: C8C704FF 050702FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v128 :: v_dual_mul_f32 v8, 0x3b800000, v127// 00000000E33C: C8C700FF 0708FEFF 3B800000
	.long 0xd7006a03                                           // 00000000E348: D7006A03
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E34C: 0201FF47
	.long 0x00004000                                           // 00000000E350: 00004000
	v_dual_mul_f32 v10, 0x3b800000, v126 :: v_dual_mul_f32 v11, 0x3b800000, v125// 00000000E354: C8C6FCFF 0A0AFAFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v72, vcc_lo               // 00000000E360: D5207C04 01AA9080
	v_dual_mul_f32 v12, 0x3b800000, v124 :: v_dual_mul_f32 v13, 0x3b800000, v46// 00000000E368: C8C6F8FF 0C0C5CFF 3B800000
	s_clause 0x7                                               // 00000000E374: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000000E378: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000000E380: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000000E388: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000000E390: DC6A0C00 007C0801
	global_store_b32 v[3:4], v10, off offset:-4096             // 00000000E398: DC6A1000 007C0A03
	global_store_b32 v[3:4], v11, off offset:-3072             // 00000000E3A0: DC6A1400 007C0B03
	global_store_b32 v[3:4], v12, off offset:-2048             // 00000000E3A8: DC6A1800 007C0C03
	global_store_b32 v[3:4], v13, off offset:-1024             // 00000000E3B0: DC6A1C00 007C0D03
	v_dual_mul_f32 v5, 0x3b800000, v123 :: v_dual_mul_f32 v6, 0x3b800000, v122// 00000000E3B8: C8C6F6FF 0506F4FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v121 :: v_dual_mul_f32 v8, 0x3b800000, v120// 00000000E3C4: C8C6F2FF 0708F0FF 3B800000
	.long 0xd7006a01                                           // 00000000E3D0: D7006A01
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E3D4: 0201FF47
	.long 0x00006000                                           // 00000000E3D8: 00006000
	v_dual_mul_f32 v10, 0x3b800000, v119 :: v_dual_mul_f32 v11, 0x3b800000, v118// 00000000E3DC: C8C6EEFF 0A0AECFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo               // 00000000E3E8: D5207C02 01AA9080
	v_mul_f32_e32 v12, 0x3b800000, v117                        // 00000000E3F0: 1018EAFF 3B800000
	v_mul_f32_e32 v13, 0x3b800000, v25                         // 00000000E3F8: 101A32FF 3B800000
	s_clause 0x7                                               // 00000000E400: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000000E404: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000000E40C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000000E414: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000000E41C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v10, off offset:-4096             // 00000000E424: DC6A1000 007C0A01
	global_store_b32 v[1:2], v11, off offset:-3072             // 00000000E42C: DC6A1400 007C0B01
	global_store_b32 v[1:2], v12, off offset:-2048             // 00000000E434: DC6A1800 007C0C01
	global_store_b32 v[1:2], v13, off offset:-1024             // 00000000E43C: DC6A1C00 007C0D01
	v_dual_mul_f32 v5, 0x3b800000, v116 :: v_dual_mul_f32 v6, 0x3b800000, v115// 00000000E444: C8C6E8FF 0506E6FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v114 :: v_dual_mul_f32 v8, 0x3b800000, v113// 00000000E450: C8C6E4FF 0708E2FF 3B800000
	.long 0xd7006a03                                           // 00000000E45C: D7006A03
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E460: 0201FF47
	.long 0x00008000                                           // 00000000E464: 00008000
	v_dual_mul_f32 v10, 0x3b800000, v112 :: v_dual_mul_f32 v11, 0x3b800000, v111// 00000000E468: C8C6E0FF 0A0ADEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v72, vcc_lo               // 00000000E474: D5207C04 01AA9080
	v_dual_mul_f32 v12, 0x3b800000, v110 :: v_dual_mul_f32 v13, 0x3b800000, v17// 00000000E47C: C8C6DCFF 0C0C22FF 3B800000
	s_clause 0x7                                               // 00000000E488: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000000E48C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000000E494: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000000E49C: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000000E4A4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v10, off offset:-4096             // 00000000E4AC: DC6A1000 007C0A03
	global_store_b32 v[3:4], v11, off offset:-3072             // 00000000E4B4: DC6A1400 007C0B03
	global_store_b32 v[3:4], v12, off offset:-2048             // 00000000E4BC: DC6A1800 007C0C03
	global_store_b32 v[3:4], v13, off offset:-1024             // 00000000E4C4: DC6A1C00 007C0D03
	v_dual_mul_f32 v5, 0x3b800000, v109 :: v_dual_mul_f32 v6, 0x3b800000, v108// 00000000E4CC: C8C6DAFF 0506D8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v107 :: v_dual_mul_f32 v8, 0x3b800000, v106// 00000000E4D8: C8C6D6FF 0708D4FF 3B800000
	.long 0xd7006a01                                           // 00000000E4E4: D7006A01
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E4E8: 0201FF47
	.long 0x0000a000                                           // 00000000E4EC: 0000A000
	v_dual_mul_f32 v10, 0x3b800000, v105 :: v_dual_mul_f32 v11, 0x3b800000, v104// 00000000E4F0: C8C6D2FF 0A0AD0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo               // 00000000E4FC: D5207C02 01AA9080
	v_dual_mul_f32 v12, 0x3b800000, v103 :: v_dual_mul_f32 v9, 0x3b800000, v9// 00000000E504: C8C6CEFF 0C0812FF 3B800000
	s_clause 0x7                                               // 00000000E510: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000000E514: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000000E51C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000000E524: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000000E52C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v10, off offset:-4096             // 00000000E534: DC6A1000 007C0A01
	global_store_b32 v[1:2], v11, off offset:-3072             // 00000000E53C: DC6A1400 007C0B01
	global_store_b32 v[1:2], v12, off offset:-2048             // 00000000E544: DC6A1800 007C0C01
	global_store_b32 v[1:2], v9, off offset:-1024              // 00000000E54C: DC6A1C00 007C0901
	v_dual_mul_f32 v5, 0x3b800000, v102 :: v_dual_mul_f32 v6, 0x3b800000, v101// 00000000E554: C8C6CCFF 0506CAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v100 :: v_dual_mul_f32 v8, 0x3b800000, v99// 00000000E560: C8C6C8FF 0708C6FF 3B800000
	.long 0xd7006a03                                           // 00000000E56C: D7006A03
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E570: 0201FF47
	.long 0x0000c000                                           // 00000000E574: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v98 :: v_dual_mul_f32 v10, 0x3b800000, v97// 00000000E578: C8C6C4FF 090AC2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v72, vcc_lo               // 00000000E584: D5207C04 01AA9080
	v_dual_mul_f32 v11, 0x3b800000, v96 :: v_dual_mul_f32 v12, 0x3b800000, v33// 00000000E58C: C8C6C0FF 0B0C42FF 3B800000
	s_clause 0x7                                               // 00000000E598: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000000E59C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000000E5A4: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000000E5AC: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000000E5B4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000000E5BC: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000000E5C4: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000000E5CC: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000000E5D4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v95 :: v_dual_mul_f32 v6, 0x3b800000, v94// 00000000E5DC: C8C6BEFF 0506BCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v93 :: v_dual_mul_f32 v8, 0x3b800000, v92// 00000000E5E8: C8C6BAFF 0708B8FF 3B800000
	.long 0xd7006a01                                           // 00000000E5F4: D7006A01
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E5F8: 0201FF47
	.long 0x0000e000                                           // 00000000E5FC: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v91 :: v_dual_mul_f32 v10, 0x3b800000, v90// 00000000E600: C8C6B6FF 090AB4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v72, vcc_lo               // 00000000E60C: D5207C02 01AA9080
	v_mul_f32_e32 v11, 0x3b800000, v89                         // 00000000E614: 1016B2FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v45                         // 00000000E61C: 10185AFF 3B800000
	s_clause 0x7                                               // 00000000E624: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000000E628: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000000E630: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000000E638: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000000E640: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000000E648: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000000E650: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000000E658: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000000E660: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v87 :: v_dual_mul_f32 v6, 0x3b800000, v86// 00000000E668: C8C6AEFF 0506ACFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v85 :: v_dual_mul_f32 v8, 0x3b800000, v82// 00000000E674: C8C6AAFF 0708A4FF 3B800000
	.long 0xd7006a03                                           // 00000000E680: D7006A03
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000000E684: 0201FF47
	.long 0x0000fc00                                           // 00000000E688: 0000FC00
	s_cmp_gt_u32 s41, 63                                       // 00000000E68C: BF08BF29
	v_dual_mul_f32 v9, 0x3b800000, v88 :: v_dual_mul_f32 v10, 0x3b800000, v83// 00000000E690: C8C6B0FF 090AA6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v72, vcc_lo               // 00000000E69C: D5207C04 01AA9080
	v_dual_mul_f32 v11, 0x3b800000, v84 :: v_dual_mul_f32 v12, 0x3b800000, v41// 00000000E6A4: C8C6A8FF 0B0C52FF 3B800000
	s_clause 0x7                                               // 00000000E6B0: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000000E6B4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000000E6BC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000000E6C4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000000E6CC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 00000000E6D4: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 00000000E6DC: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 00000000E6E4: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 00000000E6EC: DC6A0000 007C0C03
	s_cbranch_scc0 439                                         // 00000000E6F4: BFA101B7 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x68d4>
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v2, 31, v0          // 00000000E6F8: CA240080 0502009F
	s_lshl4_add_u32 s5, s42, -16                               // 00000000E700: 8885D02A
	s_add_i32 s0, s40, -3                                      // 00000000E704: 8100C328
	s_cmp_eq_u32 s40, 2                                        // 00000000E708: BF068228
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000E70C: BF870001
	v_dual_mov_b32 v9, 0 :: v_dual_lshlrev_b32 v0, 3, v2       // 00000000E710: CA220080 09000483
	s_cselect_b32 s8, -1, 0                                    // 00000000E718: 980880C1
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v13, 2, v2      // 00000000E71C: CA220080 080C0482
	s_waitcnt lgkmcnt(0)                                       // 00000000E724: BF89FC07
	global_load_b64 v[10:11], v0, s[28:29]                     // 00000000E728: DC560000 0A1C0000
	s_and_b32 s1, s8, exec_lo                                  // 00000000E730: 8B017E08
	s_cselect_b32 s0, 15, s0                                   // 00000000E734: 9800008F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000000E738: BF870499
	s_add_i32 s12, s0, s5                                      // 00000000E73C: 810C0500
	s_cmp_lt_i32 s12, s33                                      // 00000000E740: BF04210C
	s_cselect_b32 s1, -1, 0                                    // 00000000E744: 980180C1
	s_cmp_ge_i32 s12, s33                                      // 00000000E748: BF03210C
	s_cbranch_scc1 14                                          // 00000000E74C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x6288>
	s_lshl_b32 s10, s2, 7                                      // 00000000E750: 840A8702
	s_mul_i32 s3, s12, 0x3000                                  // 00000000E754: 9603FF0C 00003000
	s_ashr_i32 s11, s10, 31                                    // 00000000E75C: 860B9F0A
	s_mul_hi_i32 s4, s12, 0x3000                               // 00000000E760: 9704FF0C 00003000
	s_add_u32 s3, s30, s3                                      // 00000000E768: 8003031E
	s_addc_u32 s4, s31, s4                                     // 00000000E76C: 8204041F
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000000E770: 848A810A
	v_lshlrev_b32_e32 v0, 1, v13                               // 00000000E774: 30001A81
	s_add_u32 s10, s3, s10                                     // 00000000E778: 800A0A03
	s_addc_u32 s11, s4, s11                                    // 00000000E77C: 820B0B04
	global_load_b64 v[8:9], v0, s[10:11]                       // 00000000E780: DC560000 080A0000
	s_add_i32 s3, s40, 2                                       // 00000000E788: 81038228
	s_and_b32 s4, s8, exec_lo                                  // 00000000E78C: 8B047E08
	s_cselect_b32 s3, 15, s3                                   // 00000000E790: 9803038F
	v_mov_b32_e32 v4, 0                                        // 00000000E794: 7E080280
	s_add_i32 s9, s3, s5                                       // 00000000E798: 81090503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000E79C: BF8704A9
	s_cmp_ge_i32 s9, s33                                       // 00000000E7A0: BF032109
	s_cselect_b32 s13, -1, 0                                   // 00000000E7A4: 980D80C1
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000000E7A8: 8B6A0D7E
	s_cbranch_vccnz 14                                         // 00000000E7AC: BFA4000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x62e8>
	s_lshl_b32 s10, s2, 7                                      // 00000000E7B0: 840A8702
	s_mul_i32 s4, s9, 0x3000                                   // 00000000E7B4: 9604FF09 00003000
	s_ashr_i32 s11, s10, 31                                    // 00000000E7BC: 860B9F0A
	s_mul_hi_i32 s14, s9, 0x3000                               // 00000000E7C0: 970EFF09 00003000
	s_add_u32 s4, s30, s4                                      // 00000000E7C8: 8004041E
	s_addc_u32 s14, s31, s14                                   // 00000000E7CC: 820E0E1F
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000000E7D0: 848A810A
	v_lshlrev_b32_e32 v0, 1, v13                               // 00000000E7D4: 30001A81
	s_add_u32 s10, s4, s10                                     // 00000000E7D8: 800A0A04
	s_addc_u32 s11, s14, s11                                   // 00000000E7DC: 820B0B0E
	global_load_b64 v[4:5], v0, s[10:11]                       // 00000000E7E0: DC560000 040A0000
	s_add_i32 s40, s40, 7                                      // 00000000E7E8: 81288728
	s_and_b32 s4, s8, exec_lo                                  // 00000000E7EC: 8B047E08
	s_cselect_b32 s4, 15, s40                                  // 00000000E7F0: 9804288F
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 00000000E7F4: CA100080 01000080
	s_add_i32 s5, s4, s5                                       // 00000000E7FC: 81050504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000E800: BF8704A9
	s_cmp_ge_i32 s5, s33                                       // 00000000E804: BF032105
	s_cselect_b32 s10, -1, 0                                   // 00000000E808: 980A80C1
	s_and_b32 vcc_lo, exec_lo, s10                             // 00000000E80C: 8B6A0A7E
	s_cbranch_vccnz 14                                         // 00000000E810: BFA4000E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x634c>
	s_lshl_b32 s14, s2, 7                                      // 00000000E814: 840E8702
	s_mul_i32 s11, s5, 0x3000                                  // 00000000E818: 960BFF05 00003000
	s_ashr_i32 s15, s14, 31                                    // 00000000E820: 860F9F0E
	s_mul_hi_i32 s16, s5, 0x3000                               // 00000000E824: 9710FF05 00003000
	s_add_u32 s11, s30, s11                                    // 00000000E82C: 800B0B1E
	s_addc_u32 s16, s31, s16                                   // 00000000E830: 8210101F
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000000E834: 848E810E
	v_lshlrev_b32_e32 v0, 1, v13                               // 00000000E838: 30001A81
	s_add_u32 s14, s11, s14                                    // 00000000E83C: 800E0E0B
	s_addc_u32 s15, s16, s15                                   // 00000000E840: 820F0F10
	global_load_b64 v[0:1], v0, s[14:15]                       // 00000000E844: DC560000 000E0000
	v_lshl_or_b32 v3, v2, 1, 0x2900                            // 00000000E84C: D6560003 03FD0302 00002900
	s_mulk_i32 s3, 0x110                                       // 00000000E858: B8030110
	s_mulk_i32 s4, 0x110                                       // 00000000E85C: B8040110
	s_mov_b32 s11, 0x76543210                                  // 00000000E860: BE8B00FF 76543210
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000000E868: 916A017E
	v_add_nc_u32_e32 v12, s3, v3                               // 00000000E86C: 4A180603
	v_add_nc_u32_e32 v14, s4, v3                               // 00000000E870: 4A1C0604
	s_waitcnt vmcnt(0)                                         // 00000000E874: BF8903F7
	v_mad_u64_u32 v[6:7], null, 0x110, s0, v[3:4]              // 00000000E878: D6FE7C06 040C00FF 00000110
	ds_load_u16 v3, v12 offset:192                             // 00000000E884: D8F000C0 0300000C
	ds_load_u16 v7, v12 offset:128                             // 00000000E88C: D8F00080 0700000C
	ds_load_u16 v15, v12 offset:64                             // 00000000E894: D8F00040 0F00000C
	ds_load_u16 v16, v14 offset:128                            // 00000000E89C: D8F00080 1000000E
	ds_load_u16 v17, v14                                       // 00000000E8A4: D8F00000 1100000E
	ds_load_u16 v18, v14 offset:64                             // 00000000E8AC: D8F00040 1200000E
	ds_load_u16 v14, v14 offset:192                            // 00000000E8B4: D8F000C0 0E00000E
	ds_load_u16 v19, v6                                        // 00000000E8BC: D8F00000 13000006
	ds_load_u16 v20, v6 offset:64                              // 00000000E8C4: D8F00040 14000006
	ds_load_u16 v21, v6 offset:128                             // 00000000E8CC: D8F00080 15000006
	ds_load_u16 v6, v6 offset:192                              // 00000000E8D4: D8F000C0 06000006
	ds_load_u16 v12, v12                                       // 00000000E8DC: D8F00000 0C00000C
	s_waitcnt lgkmcnt(6)                                       // 00000000E8E4: BF89FC67
	v_lshlrev_b32_e32 v18, 16, v18                             // 00000000E8E8: 30242490
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000000E8EC: 301E1E90
	s_waitcnt lgkmcnt(5)                                       // 00000000E8F0: BF89FC57
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000000E8F4: 301C1C90
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000000E8F8: 300E0E90
	s_waitcnt lgkmcnt(1)                                       // 00000000E8FC: BF89FC17
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000000E900: 300C0C90
	v_dual_mul_f32 v18, v18, v18 :: v_dual_lshlrev_b32 v19, 16, v19// 00000000E904: C8E22512 12122690
	v_dual_mul_f32 v15, v15, v15 :: v_dual_mul_f32 v14, v14, v14// 00000000E90C: C8C61F0F 0F0E1D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000E914: BF870193
	v_mul_f32_e32 v6, v6, v6                                   // 00000000E918: 100C0D06
	v_dual_mul_f32 v19, v19, v19 :: v_dual_lshlrev_b32 v20, 16, v20// 00000000E91C: C8E22713 13142890
	v_lshlrev_b32_e32 v3, 16, v3                               // 00000000E924: 30060690
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000E928: BF870112
	v_dual_mul_f32 v7, v7, v7 :: v_dual_mul_f32 v20, v20, v20  // 00000000E92C: C8C60F07 07142914
	v_dual_mul_f32 v3, v3, v3 :: v_dual_lshlrev_b32 v16, 16, v16// 00000000E934: C8E20703 03102090
	s_waitcnt lgkmcnt(0)                                       // 00000000E93C: BF89FC07
	v_lshlrev_b32_e32 v12, 16, v12                             // 00000000E940: 30181890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000E944: BF870192
	v_dual_mul_f32 v16, v16, v16 :: v_dual_lshlrev_b32 v21, 16, v21// 00000000E948: C8E22110 10142A90
	v_add_f32_e32 v3, v15, v3                                  // 00000000E950: 0606070F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000E954: BF870193
	v_dual_mul_f32 v12, v12, v12 :: v_dual_lshlrev_b32 v17, 16, v17// 00000000E958: C8E2190C 0C102290
	v_mul_f32_e32 v21, v21, v21                                // 00000000E960: 102A2B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000E964: BF870192
	v_mul_f32_e32 v17, v17, v17                                // 00000000E968: 10222311
	v_add_f32_e32 v7, v12, v7                                  // 00000000E96C: 060E0F0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000E970: BF870112
	v_dual_add_f32 v19, v19, v21 :: v_dual_add_f32 v12, v17, v16// 00000000E974: C9082B13 130C2111
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v3, v7, v3    // 00000000E97C: C9080D14 06020707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000E984: BF870091
	v_dual_add_f32 v14, v18, v14 :: v_dual_mov_b32 v15, v3     // 00000000E988: C9101D12 0E0E0103
	v_add_f32_e32 v7, v12, v14                                 // 00000000E990: 060E1D0C
	v_lshl_or_b32 v12, v2, 3, 0x2900                           // 00000000E994: D656000C 03FD0702 00002900
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000E9A0: BF870214
	v_add_f32_e32 v6, v19, v6                                  // 00000000E9A4: 060C0D13
	v_permlanex16_b32 v15, v15, s11, 0xfedcba98                // 00000000E9A8: D65C000F 03FC170F FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000E9B4: BF8701A2
	v_mov_b32_e32 v14, v6                                      // 00000000E9B8: 7E1C0306
	v_mov_b32_e32 v16, v7                                      // 00000000E9BC: 7E200307
	v_add_f32_e32 v3, v3, v15                                  // 00000000E9C0: 06061F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000E9C4: BF870093
	v_permlanex16_b32 v14, v14, s11, 0xfedcba98                // 00000000E9C8: D65C000E 03FC170E FEDCBA98
	v_add_f32_e32 v2, v6, v14                                  // 00000000E9D4: 06041D06
	v_add_nc_u32_e32 v14, s4, v12                              // 00000000E9D8: 4A1C1804
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000E9DC: BF870092
	v_add_f32_dpp v15, v2, v2 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000E9E0: 061E04FA FF090802
	v_add_f32_dpp v18, v15, v15 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000E9E8: 06241EFA FF09040F
	v_lshlrev_b32_e32 v15, 16, v10                             // 00000000E9F0: 301E1490
	v_permlanex16_b32 v16, v16, s11, 0xfedcba98                // 00000000E9F4: D65C0010 03FC1710 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000EA00: BF8701B1
	v_add_f32_e32 v6, v7, v16                                  // 00000000EA04: 060C2107
	v_add_nc_u32_e32 v7, s3, v12                               // 00000000EA08: 4A0E1803
	v_add_f32_dpp v16, v3, v3 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA0C: 062006FA FF090803
	v_add_f32_dpp v17, v6, v6 row_shl:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA14: 06220CFA FF090806
	ds_load_b64 v[6:7], v7                                     // 00000000EA1C: D9D80000 06000007
	ds_load_b64 v[2:3], v14                                    // 00000000EA24: D9D80000 0200000E
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA2C: 062020FA FF090410
	v_and_b32_e32 v14, 0xffff0000, v10                         // 00000000EA34: 361C14FF FFFF0000
	v_add_f32_dpp v10, v18, v18 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA3C: 061424FA FF090212
	v_add_f32_dpp v17, v17, v17 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA44: 062222FA FF090411
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000EA4C: BF870224
	v_add_f32_dpp v18, v16, v16 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA50: 062420FA FF090210
	v_lshlrev_b32_e32 v16, 16, v11                             // 00000000EA58: 30201690
	v_add_f32_dpp v19, v10, v10 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA5C: 062614FA FF09010A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000000EA64: BF870234
	v_add_f32_dpp v17, v17, v17 row_shl:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA68: 062222FA FF090211
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000000EA70: 361416FF FFFF0000
	v_add_f32_dpp v18, v18, v18 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA78: 062424FA FF090112
	.long 0xd7600003                                           // 00000000EA80: D7600003
	v_cndmask_b32_e32 v0, v19, v128, vcc_lo                    // 00000000EA84: 02010113
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EA88: BF870194
	v_add_f32_dpp v17, v17, v17 row_shl:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000000EA8C: 062222FA FF090111
	.long 0xd760000e                                           // 00000000EA94: D760000E
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                    // 00000000EA98: 02010112
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000EA9C: BF870002
	.long 0xd760000b                                           // 00000000EAA0: D760000B
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                    // 00000000EAA4: 02010111
	s_cbranch_vccz 205                                         // 00000000EAA8: BFA300CD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x68e0>
	s_or_b32 s0, s8, s13                                       // 00000000EAAC: 8C000D08
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000EAB0: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000EAB4: 8B6A007E
	s_cbranch_vccz 407                                         // 00000000EAB8: BFA30197 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x6c18>
	s_or_b32 s0, s8, s10                                       // 00000000EABC: 8C000A08
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000EAC0: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000EAC4: 8B6A007E
	s_cbranch_vccnz 194                                        // 00000000EAC8: BFA400C2 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x68d4>
	v_lshlrev_b32_e32 v5, 16, v1                               // 00000000EACC: 300A0290
	v_lshlrev_b32_e32 v4, 16, v0                               // 00000000EAD0: 30080090
	s_mul_f32 s0, s11, 0x3c000000                              // 00000000EAD4: A200FF0B 3C000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(SALU_CYCLE_2)// 00000000EADC: BF870511
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 00000000EAE0: C8C60AFF 050408FF BFB8AA3B
	s_add_f32 s0, s0, 0x358637bd                               // 00000000EAEC: A000FF00 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000EAF4: BF870091
	v_exp_f32_e32 v5, v5                                       // 00000000EAF8: 7E0A4B05
	v_exp_f32_e32 v4, v4                                       // 00000000EAFC: 7E084B04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000EB00: BF870009
	s_mul_f32 s1, s0, 0x4b800000                               // 00000000EB04: A201FF00 4B800000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000000EB0C: 360000FF FFFF0000
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000000EB14: 360202FF FFFF0000
	s_cmp_lt_f32 s0, 0x800000                                  // 00000000EB1C: BF41FF00 00800000
	s_waitcnt lgkmcnt(1)                                       // 00000000EB24: BF89FC17
	v_mov_b32_e32 v7, s1                                       // 00000000EB28: 7E0E0201
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000EB2C: 986A80C1
	s_waitcnt lgkmcnt(0)                                       // 00000000EB30: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000000EB34: BF8701C1
	v_dual_cndmask_b32 v7, s0, v7 :: v_dual_lshlrev_b32 v6, 16, v2// 00000000EB38: CA620E00 07060490
	v_add_f32_e32 v4, 1.0, v4                                  // 00000000EB40: 060808F2
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 00000000EB44: C8C600FF 000002FF BFB8AA3B
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_and_b32 v2, 0xffff0000, v2// 00000000EB50: C9240AF2 050204FF FFFF0000
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 00000000EB5C: D6FC7C08 03CA0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EB64: BF870193
	v_exp_f32_e32 v0, v0                                       // 00000000EB68: 7E004B00
	v_exp_f32_e32 v1, v1                                       // 00000000EB6C: 7E024B01
	v_rsq_f32_e32 v7, v7                                       // 00000000EB70: 7E0E5D07
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 00000000EB74: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v8                                      // 00000000EB7C: 7E185508
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 00000000EB80: D6FC0015 03CA08F2
	v_div_scale_f32 v25, s3, 1.0, v5, 1.0                      // 00000000EB88: D6FC0319 03CA0AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000000EB90: BF870323
	v_rcp_f32_e32 v20, v11                                     // 00000000EB94: 7E28550B
	v_dual_add_f32 v0, 1.0, v0 :: v_dual_add_f32 v1, 1.0, v1   // 00000000EB98: C90800F2 000002F2
	v_fma_f32 v26, -v8, v12, 1.0                               // 00000000EBA0: D613001A 23CA1908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EBA8: BF870192
	v_div_scale_f32 v9, null, v0, v0, 1.0                      // 00000000EBAC: D6FC7C09 03CA0100
	v_div_scale_f32 v18, null, v1, v1, 1.0                     // 00000000EBB4: D6FC7C12 03CA0301
	v_lshlrev_b32_e32 v19, 16, v3                              // 00000000EBBC: 30260690
	v_div_scale_f32 v22, s1, 1.0, v0, 1.0                      // 00000000EBC0: D6FC0116 03CA00F2
	v_fmac_f32_e32 v12, v26, v12                               // 00000000EBC8: 5618191A
	v_rcp_f32_e32 v17, v9                                      // 00000000EBCC: 7E225509
	v_rcp_f32_e32 v23, v18                                     // 00000000EBD0: 7E2E5512
	v_div_scale_f32 v28, s4, 1.0, v1, 1.0                      // 00000000EBD4: D6FC041C 03CA02F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000000EBDC: BF8702A6
	v_fma_f32 v27, -v9, v17, 1.0                               // 00000000EBE0: D613001B 23CA2309
	v_mul_f32_e32 v24, 0x45800000, v7                          // 00000000EBE8: 10300EFF 45800000
	v_fma_f32 v26, -v18, v23, 1.0                              // 00000000EBF0: D613001A 23CA2F12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EBF8: BF870193
	v_fmac_f32_e32 v17, v27, v17                               // 00000000EBFC: 5622231B
	v_cndmask_b32_e32 v7, v7, v24, vcc_lo                      // 00000000EC00: 020E3107
	v_fma_f32 v24, -v11, v20, 1.0                              // 00000000EC04: D6130018 23CA290B
	v_mul_f32_e32 v27, v21, v12                                // 00000000EC0C: 10361915
	s_mov_b32 vcc_lo, s0                                       // 00000000EC10: BEEA0000
	s_lshl_b32 s0, s2, 7                                       // 00000000EC14: 84008702
	v_mul_f32_e32 v6, v7, v6                                   // 00000000EC18: 100C0D07
	v_fmac_f32_e32 v20, v24, v20                               // 00000000EC1C: 56282918
	v_fma_f32 v24, -v8, v27, v21                               // 00000000EC20: D6130018 24563708
	v_mul_f32_e32 v29, v22, v17                                // 00000000EC28: 103A2316
	s_mul_i32 s2, s5, 0x3000                                   // 00000000EC2C: 9602FF05 00003000
	v_mul_f32_e32 v6, v6, v15                                  // 00000000EC34: 100C1F06
	v_mul_f32_e32 v2, v7, v2                                   // 00000000EC38: 10040507
	v_mul_f32_e32 v19, v7, v19                                 // 00000000EC3C: 10262707
	v_fmac_f32_e32 v23, v26, v23                               // 00000000EC40: 562E2F1A
	v_mul_f32_e32 v15, v25, v20                                // 00000000EC44: 101E2919
	v_fma_f32 v26, -v9, v29, v22                               // 00000000EC48: D613001A 245A3B09
	v_mul_f32_e32 v2, v2, v14                                  // 00000000EC50: 10041D02
	v_mul_f32_e32 v14, v19, v16                                // 00000000EC54: 101C2113
	v_fmac_f32_e32 v27, v24, v12                               // 00000000EC58: 56361918
	v_fma_f32 v16, -v11, v15, v25                              // 00000000EC5C: D6130010 24661F0B
	v_mul_f32_e32 v19, v28, v23                                // 00000000EC64: 10262F1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EC68: BF870193
	v_fma_f32 v8, -v8, v27, v21                                // 00000000EC6C: D6130008 24563708
	v_fmac_f32_e32 v15, v16, v20                               // 00000000EC74: 561E2910
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EC78: BF870193
	v_fma_f32 v16, -v18, v19, v28                              // 00000000EC7C: D6130010 24722712
	v_div_fmas_f32 v8, v8, v12, v27                            // 00000000EC84: D6370008 046E1908
	s_mov_b32 vcc_lo, s1                                       // 00000000EC8C: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EC90: BF870193
	v_fma_f32 v11, -v11, v15, v25                              // 00000000EC94: D613000B 24661F0B
	v_fmac_f32_e32 v19, v16, v23                               // 00000000EC9C: 56262F10
	s_ashr_i32 s1, s0, 31                                      // 00000000ECA0: 86019F00
	v_div_fixup_f32 v4, v8, v4, 1.0                            // 00000000ECA4: D6270004 03CA0908
	v_fmac_f32_e32 v29, v26, v17                               // 00000000ECAC: 563A231A
	s_add_u32 s2, s6, s2                                       // 00000000ECB0: 80020206
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000ECB4: BF870112
	v_mul_f32_e32 v4, v4, v6                                   // 00000000ECB8: 10080D04
	v_fma_f32 v9, -v9, v29, v22                                // 00000000ECBC: D6130009 245A3B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000ECC4: BF870001
	v_div_fmas_f32 v9, v9, v17, v29                            // 00000000ECC8: D6370009 04762309
	s_mov_b32 vcc_lo, s3                                       // 00000000ECD0: BEEA0003
	s_mul_hi_i32 s3, s5, 0x3000                                // 00000000ECD4: 9703FF05 00003000
	v_div_fmas_f32 v8, v11, v20, v15                           // 00000000ECDC: D6370008 043E290B
	s_mov_b32 vcc_lo, s4                                       // 00000000ECE4: BEEA0004
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 00000000ECE8: D6270000 03CA0109
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000000ECF0: 360606FF FFFF0000
	s_addc_u32 s3, s7, s3                                      // 00000000ECF8: 82030307
	v_div_fixup_f32 v5, v8, v5, 1.0                            // 00000000ECFC: D6270005 03CA0B08
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000000ED04: 84808100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000ED08: BF8701A2
	v_dual_mul_f32 v0, v0, v2 :: v_dual_mul_f32 v3, v7, v3     // 00000000ED0C: C8C60500 00020707
	v_fma_f32 v7, -v18, v19, v28                               // 00000000ED14: D6130007 24722712
	v_mul_f32_e32 v2, v5, v14                                  // 00000000ED1C: 10041D05
	s_add_u32 s0, s2, s0                                       // 00000000ED20: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000000ED24: 82010103
	v_mul_f32_e32 v3, v3, v10                                  // 00000000ED28: 10061503
	v_div_fmas_f32 v6, v7, v23, v19                            // 00000000ED2C: D6370006 044E2F07
	v_bfe_u32 v7, v4, 16, 1                                    // 00000000ED34: D6100007 02052104
	v_bfe_u32 v5, v2, 16, 1                                    // 00000000ED3C: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000ED44: BF870193
	v_div_fixup_f32 v1, v6, v1, 1.0                            // 00000000ED48: D6270001 03CA0306
	v_add3_u32 v4, v4, v7, 0x7fff                              // 00000000ED50: D6550004 03FE0F04 00007FFF
	.long 0x7f0c3880                                           // 00000000ED5C: 7F0C3880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000ED60: BF870214
	v_add3_u32 v2, v2, v5, 0x7fff                              // 00000000ED64: D6550002 03FE0B02 00007FFF
	v_mul_f32_e32 v1, v1, v3                                   // 00000000ED70: 10020701
	v_bfe_u32 v3, v0, 16, 1                                    // 00000000ED74: D6100003 02052100
	.long 0x7e0c3984                                           // 00000000ED7C: 7E0C3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000ED80: BF870193
	v_bfe_u32 v4, v1, 16, 1                                    // 00000000ED84: D6100004 02052101
	v_add3_u32 v0, v0, v3, 0x7fff                              // 00000000ED8C: D6550000 03FE0700 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000ED98: BF870112
	v_add3_u32 v1, v1, v4, 0x7fff                              // 00000000ED9C: D6550001 03FE0901 00007FFF
	v_and_or_b32 v0, 0xffff0000, v0, v6                        // 00000000EDA8: D6570000 041A00FF FFFF0000
	.long 0x7e0c3982                                           // 00000000EDB4: 7E0C3982
	v_lshlrev_b32_e32 v2, 1, v13                               // 00000000EDB8: 30041A81
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000EDBC: BF870002
	v_and_or_b32 v1, 0xffff0000, v1, v6                        // 00000000EDC0: D6570001 041A02FF FFFF0000
	global_store_b64 v2, v[0:1], s[0:1]                        // 00000000EDCC: DC6E0000 00000002
	s_nop 0                                                    // 00000000EDD4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000000EDD8: BFB60003
	s_endpgm                                                   // 00000000EDDC: BFB00000
	v_and_b32_e32 v11, 0xffff0000, v9                          // 00000000EDE0: 361612FF FFFF0000
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000000EDE8: 30121290
	v_and_b32_e32 v17, 0xffff0000, v8                          // 00000000EDEC: 362210FF FFFF0000
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000000EDF4: 30101090
	s_mul_f32 s1, s3, 0x3c000000                               // 00000000EDF8: A201FF03 3C000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000000EE00: BF8704A1
	v_dual_mul_f32 v18, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v8// 00000000EE04: C8C612FF 121210FF BFB8AA3B
	v_mad_u64_u32 v[8:9], null, 0x110, s0, v[12:13]            // 00000000EE10: D6FE7C08 043000FF 00000110
	s_add_f32 s1, s1, 0x358637bd                               // 00000000EE1C: A001FF01 358637BD
	v_exp_f32_e32 v12, v18                                     // 00000000EE24: 7E184B12
	v_exp_f32_e32 v18, v19                                     // 00000000EE28: 7E244B13
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000EE2C: BF870009
	s_mul_f32 s0, s1, 0x4b800000                               // 00000000EE30: A200FF01 4B800000
	s_cmp_lt_f32 s1, 0x800000                                  // 00000000EE38: BF41FF01 00800000
	ds_load_b64 v[8:9], v8                                     // 00000000EE40: D9D80000 08000008
	v_mov_b32_e32 v19, s0                                      // 00000000EE48: 7E260200
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000EE4C: 986A80C1
	v_dual_add_f32 v12, 1.0, v12 :: v_dual_mul_f32 v11, 0xbfb8aa3b, v11// 00000000EE50: C90618F2 0C0A16FF BFB8AA3B
	v_add_f32_e32 v18, 1.0, v18                                // 00000000EE5C: 062424F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EE60: BF870192
	v_div_scale_f32 v21, null, v12, v12, 1.0                   // 00000000EE64: D6FC7C15 03CA190C
	v_exp_f32_e32 v11, v11                                     // 00000000EE6C: 7E164B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000EE70: BF8701A2
	v_div_scale_f32 v25, null, v18, v18, 1.0                   // 00000000EE74: D6FC7C19 03CA2512
	v_div_scale_f32 v31, s4, 1.0, v18, 1.0                     // 00000000EE7C: D6FC041F 03CA24F2
	v_rcp_f32_e32 v26, v21                                     // 00000000EE84: 7E345515
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 00000000EE88: BF8703A2
	v_rcp_f32_e32 v30, v25                                     // 00000000EE8C: 7E3C5519
	s_waitcnt lgkmcnt(0)                                       // 00000000EE90: BF89FC07
	v_dual_add_f32 v11, 1.0, v11 :: v_dual_and_b32 v32, 0xffff0000, v9// 00000000EE94: C92416F2 0B2012FF FFFF0000
	v_and_b32_e32 v34, 0xffff0000, v8                          // 00000000EEA0: 364410FF FFFF0000
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000000EEA8: 30101090
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000EEAC: BF870216
	v_fma_f32 v35, -v21, v26, 1.0                              // 00000000EEB0: D6130023 23CA3515
	v_div_scale_f32 v20, null, v11, v11, 1.0                   // 00000000EEB8: D6FC7C14 03CA170B
	v_div_scale_f32 v22, s0, 1.0, v11, 1.0                     // 00000000EEC0: D6FC0016 03CA16F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EEC8: BF870193
	v_dual_fmac_f32 v26, v35, v26 :: v_dual_mul_f32 v17, 0xbfb8aa3b, v17// 00000000EECC: C8063523 1A1022FF BFB8AA3B
	v_rcp_f32_e32 v24, v20                                     // 00000000EED8: 7E305514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000000EEDC: BF870311
	v_exp_f32_e32 v17, v17                                     // 00000000EEE0: 7E224B11
	v_fma_f32 v33, -v20, v24, 1.0                              // 00000000EEE4: D6130021 23CA3114
	v_cndmask_b32_e32 v19, s1, v19, vcc_lo                     // 00000000EEEC: 02262601
	v_div_scale_f32 v27, s1, 1.0, v12, 1.0                     // 00000000EEF0: D6FC011B 03CA18F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000000EEF8: BF870185
	v_dual_add_f32 v17, 1.0, v17 :: v_dual_fmac_f32 v24, v33, v24// 00000000EEFC: C90022F2 11183121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000EF04: BF8701B3
	v_rsq_f32_e32 v19, v19                                     // 00000000EF08: 7E265D13
	v_fma_f32 v33, -v25, v30, 1.0                              // 00000000EF0C: D6130021 23CA3D19
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000000EF14: 30121290
	v_div_scale_f32 v23, null, v17, v17, 1.0                   // 00000000EF18: D6FC7C17 03CA2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000EF20: BF870113
	v_fmac_f32_e32 v30, v33, v30                               // 00000000EF24: 563C3D21
	v_rcp_f32_e32 v28, v23                                     // 00000000EF28: 7E385517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000EF2C: BF870296
	v_mul_f32_e32 v35, 0x45800000, v19                         // 00000000EF30: 104626FF 45800000
	v_fma_f32 v36, -v23, v28, 1.0                              // 00000000EF38: D6130024 23CA3917
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000000EF40: BF8701C1
	v_fmac_f32_e32 v28, v36, v28                               // 00000000EF44: 56383924
	v_mul_f32_e32 v36, v22, v24                                // 00000000EF48: 10483116
	v_mul_f32_e32 v38, v31, v30                                // 00000000EF4C: 104C3D1F
	v_div_scale_f32 v29, s3, 1.0, v17, 1.0                     // 00000000EF50: D6FC031D 03CA22F2
	v_fma_f32 v37, -v20, v36, v22                              // 00000000EF58: D6130025 245A4914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000EF60: BF870091
	v_dual_mul_f32 v33, v27, v26 :: v_dual_fmac_f32 v36, v37, v24// 00000000EF64: C8C0351B 21243125
	v_fma_f32 v39, -v21, v33, v27                              // 00000000EF6C: D6130027 246E4315
	v_fma_f32 v37, -v25, v38, v31                              // 00000000EF74: D6130025 247E4D19
	v_cndmask_b32_e32 v19, v19, v35, vcc_lo                    // 00000000EF7C: 02264713
	s_mov_b32 vcc_lo, s0                                       // 00000000EF80: BEEA0000
	v_fma_f32 v20, -v20, v36, v22                              // 00000000EF84: D6130014 245A4914
	s_lshl_b32 s0, s2, 7                                       // 00000000EF8C: 84008702
	v_fmac_f32_e32 v38, v37, v30                               // 00000000EF90: 564C3D25
	v_mul_f32_e32 v8, v19, v8                                  // 00000000EF94: 10101113
	v_fmac_f32_e32 v33, v39, v26                               // 00000000EF98: 56423527
	v_div_fmas_f32 v20, v20, v24, v36                          // 00000000EF9C: D6370014 04923114
	s_mov_b32 vcc_lo, s1                                       // 00000000EFA4: BEEA0001
	v_fma_f32 v24, -v25, v38, v31                              // 00000000EFA8: D6130018 247E4D19
	v_mul_f32_e32 v8, v8, v15                                  // 00000000EFB0: 10101F08
	v_fma_f32 v21, -v21, v33, v27                              // 00000000EFB4: D6130015 246E4315
	v_mul_f32_e32 v9, v19, v9                                  // 00000000EFBC: 10121313
	v_div_fixup_f32 v11, v20, v11, 1.0                         // 00000000EFC0: D627000B 03CA1714
	s_ashr_i32 s1, s0, 31                                      // 00000000EFC8: 86019F00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000EFCC: BF870193
	v_div_fmas_f32 v21, v21, v26, v33                          // 00000000EFD0: D6370015 04863515
	v_mul_f32_e32 v9, v9, v16                                  // 00000000EFD8: 10122109
	s_mov_b32 vcc_lo, s3                                       // 00000000EFDC: BEEA0003
	s_mul_i32 s3, s12, 0x3000                                  // 00000000EFE0: 9603FF0C 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000000EFE8: BF8701C2
	v_div_fixup_f32 v12, v21, v12, 1.0                         // 00000000EFEC: D627000C 03CA1915
	v_mul_f32_e32 v32, v19, v32                                // 00000000EFF4: 10404113
	v_mul_f32_e32 v19, v19, v34                                // 00000000EFF8: 10264513
	s_add_u32 s3, s6, s3                                       // 00000000EFFC: 80030306
	v_mul_f32_e32 v9, v12, v9                                  // 00000000F000: 1012130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000F004: BF870093
	v_dual_mul_f32 v35, v29, v28 :: v_dual_mul_f32 v22, v32, v10// 00000000F008: C8C6391D 23161520
	v_fma_f32 v40, -v23, v35, v29                              // 00000000F010: D6130028 24764717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000F018: BF870112
	v_mul_f32_e32 v11, v11, v22                                // 00000000F01C: 10162D0B
	v_fmac_f32_e32 v35, v40, v28                               // 00000000F020: 56463928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000F024: BF870091
	v_fma_f32 v23, -v23, v35, v29                              // 00000000F028: D6130017 24764717
	v_div_fmas_f32 v21, v23, v28, v35                          // 00000000F030: D6370015 048E3917
	s_mov_b32 vcc_lo, s4                                       // 00000000F038: BEEA0004
	s_mul_hi_i32 s4, s12, 0x3000                               // 00000000F03C: 9704FF0C 00003000
	v_div_fmas_f32 v23, v24, v30, v38                          // 00000000F044: D6370017 049A3D18
	s_addc_u32 s4, s7, s4                                      // 00000000F04C: 82040407
	v_div_fixup_f32 v17, v21, v17, 1.0                         // 00000000F050: D6270011 03CA2315
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000000F058: 84808100
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000F05C: BF870002
	v_div_fixup_f32 v12, v23, v18, 1.0                         // 00000000F060: D627000C 03CA2517
	v_mul_f32_e32 v18, v19, v14                                // 00000000F068: 10241D13
	v_bfe_u32 v19, v9, 16, 1                                   // 00000000F06C: D6100013 02052109
	s_add_u32 s0, s3, s0                                       // 00000000F074: 80000003
	s_addc_u32 s1, s4, s1                                      // 00000000F078: 82010104
	v_mul_f32_e32 v8, v12, v8                                  // 00000000F07C: 1010110C
	v_bfe_u32 v12, v11, 16, 1                                  // 00000000F080: D610000C 0205210B
	v_mul_f32_e32 v17, v17, v18                                // 00000000F088: 10222511
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000000F08C: D6550009 03FE2709 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000F098: BF870214
	v_bfe_u32 v18, v8, 16, 1                                   // 00000000F09C: D6100012 02052108
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000000F0A4: D655000B 03FE190B 00007FFF
	.long 0x7f183880                                           // 00000000F0B0: 7F183880
	v_bfe_u32 v19, v17, 16, 1                                  // 00000000F0B4: D6100013 02052111
	.long 0x7e183989                                           // 00000000F0BC: 7E183989
	v_add3_u32 v8, v8, v18, 0x7fff                             // 00000000F0C0: D6550008 03FE2508 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000F0CC: BF870193
	v_add3_u32 v17, v17, v19, 0x7fff                           // 00000000F0D0: D6550011 03FE2711 00007FFF
	v_and_or_b32 v9, 0xffff0000, v11, v12                      // 00000000F0DC: D6570009 043216FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000F0E8: BF870123
	.long 0x7e183988                                           // 00000000F0EC: 7E183988
	v_lshlrev_b32_e32 v11, 1, v13                              // 00000000F0F0: 30161A81
	v_and_or_b32 v8, 0xffff0000, v17, v12                      // 00000000F0F4: D6570008 043222FF FFFF0000
	global_store_b64 v11, v[8:9], s[0:1]                       // 00000000F100: DC6E0000 0000080B
	s_or_b32 s0, s8, s13                                       // 00000000F108: 8C000D08
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000F10C: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000F110: 8B6A007E
	s_cbranch_vccnz 65129                                      // 00000000F114: BFA4FE69 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x65bc>
	v_lshlrev_b32_e32 v9, 16, v5                               // 00000000F118: 30120A90
	v_lshlrev_b32_e32 v8, 16, v4                               // 00000000F11C: 30100890
	s_mul_f32 s0, s14, 0x3c000000                              // 00000000F120: A200FF0E 3C000000
	s_waitcnt lgkmcnt(1)                                       // 00000000F128: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v7                              // 00000000F12C: 302E0E90
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000000F130: 101212FF BFB8AA3B
	s_add_f32 s0, s0, 0x358637bd                               // 00000000F138: A000FF00 358637BD
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000000F140: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000000F148: BF870002
	v_exp_f32_e32 v9, v9                                       // 00000000F14C: 7E124B09
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000000F150: 360808FF FFFF0000
	s_mul_f32 s1, s0, 0x4b800000                               // 00000000F158: A201FF00 4B800000
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000000F160: 360A0AFF FFFF0000
	v_exp_f32_e32 v8, v8                                       // 00000000F168: 7E104B08
	s_cmp_lt_f32 s0, 0x800000                                  // 00000000F16C: BF41FF00 00800000
	v_dual_mov_b32 v12, s1 :: v_dual_lshlrev_b32 v11, 16, v6   // 00000000F174: CA220001 0C0A0C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000000F17C: BF870322
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000000F180: 100A0AFF BFB8AA3B
	s_cselect_b32 vcc_lo, -1, 0                                // 00000000F188: 986A80C1
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 00000000F18C: C90612F2 090408FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000000F198: BF870312
	v_exp_f32_e32 v5, v5                                       // 00000000F19C: 7E0A4B05
	v_add_f32_e32 v8, 1.0, v8                                  // 00000000F1A0: 061010F2
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000000F1A4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000000F1AC: BF8701C3
	v_exp_f32_e32 v4, v4                                       // 00000000F1B0: 7E084B04
	v_div_scale_f32 v19, null, v9, v9, 1.0                     // 00000000F1B4: D6FC7C13 03CA1309
	v_div_scale_f32 v29, s3, 1.0, v9, 1.0                      // 00000000F1BC: D6FC031D 03CA12F2
	v_div_scale_f32 v17, null, v8, v8, 1.0                     // 00000000F1C4: D6FC7C11 03CA1108
	v_rcp_f32_e32 v24, v19                                     // 00000000F1CC: 7E305513
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000F1D0: BF870117
	v_add_f32_e32 v5, 1.0, v5                                  // 00000000F1D4: 060A0AF2
	v_rcp_f32_e32 v20, v17                                     // 00000000F1D8: 7E285511
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000F1DC: BF870117
	v_add_f32_e32 v4, 1.0, v4                                  // 00000000F1E0: 060808F2
	v_div_scale_f32 v22, null, v5, v5, 1.0                     // 00000000F1E4: D6FC7C16 03CA0B05
	v_div_scale_f32 v32, s4, 1.0, v5, 1.0                      // 00000000F1EC: D6FC0420 03CA0AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000000F1F4: BF870223
	v_div_scale_f32 v18, null, v4, v4, 1.0                     // 00000000F1F8: D6FC7C12 03CA0904
	v_div_scale_f32 v26, s1, 1.0, v4, 1.0                      // 00000000F200: D6FC011A 03CA08F2
	v_rcp_f32_e32 v27, v22                                     // 00000000F208: 7E365516
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000F20C: BF870196
	v_fma_f32 v30, -v17, v20, 1.0                              // 00000000F210: D613001E 23CA2911
	v_rcp_f32_e32 v21, v18                                     // 00000000F218: 7E2A5512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000F21C: BF8701B5
	v_fma_f32 v31, -v18, v21, 1.0                              // 00000000F220: D613001F 23CA2B12
	v_cndmask_b32_e32 v12, s0, v12, vcc_lo                     // 00000000F228: 02181800
	v_div_scale_f32 v25, s0, 1.0, v8, 1.0                      // 00000000F22C: D6FC0019 03CA10F2
	v_fmac_f32_e32 v21, v31, v21                               // 00000000F234: 562A2B1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000000F238: BF870293
	v_rsq_f32_e32 v12, v12                                     // 00000000F23C: 7E185D0C
	v_dual_mul_f32 v33, v26, v21 :: v_dual_mul_f32 v28, 0x45800000, v12// 00000000F240: C8C62B1A 211C18FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000F24C: BF870001
	v_cndmask_b32_e32 v12, v12, v28, vcc_lo                    // 00000000F250: 0218390C
	v_fma_f32 v28, -v19, v24, 1.0                              // 00000000F254: D613001C 23CA3113
	v_fmac_f32_e32 v20, v30, v20                               // 00000000F25C: 5628291E
	v_fma_f32 v30, -v22, v27, 1.0                              // 00000000F260: D613001E 23CA3716
	s_mov_b32 vcc_lo, s0                                       // 00000000F268: BEEA0000
	v_mul_f32_e32 v11, v12, v11                                // 00000000F26C: 1016170C
	v_mul_f32_e32 v23, v12, v23                                // 00000000F270: 102E2F0C
	v_dual_mul_f32 v6, v12, v6 :: v_dual_mul_f32 v31, v25, v20 // 00000000F274: C8C60D0C 061E2919
	v_dual_fmac_f32 v24, v28, v24 :: v_dual_fmac_f32 v27, v30, v27// 00000000F27C: C800311C 181A371E
	v_fma_f32 v30, -v18, v33, v26                              // 00000000F284: D613001E 246A4312
	v_mul_f32_e32 v11, v11, v15                                // 00000000F28C: 10161F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000F290: BF870214
	v_fma_f32 v28, -v17, v31, v25                              // 00000000F294: D613001C 24663F11
	v_mul_f32_e32 v34, v29, v24                                // 00000000F29C: 1044311D
	v_mul_f32_e32 v6, v6, v14                                  // 00000000F2A0: 100C1D06
	v_dual_fmac_f32 v33, v30, v21 :: v_dual_mul_f32 v30, v32, v27// 00000000F2A4: C8062B1E 211E3720
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000F2AC: BF870214
	v_fmac_f32_e32 v31, v28, v20                               // 00000000F2B0: 563E291C
	v_fma_f32 v28, -v19, v34, v29                              // 00000000F2B4: D613001C 24764513
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000000F2BC: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000F2C4: BF870004
	v_fma_f32 v18, -v18, v33, v26                              // 00000000F2C8: D6130012 246A4312
	s_lshl_b32 s0, s2, 7                                       // 00000000F2D0: 84008702
	v_fma_f32 v17, -v17, v31, v25                              // 00000000F2D4: D6130011 24663F11
	v_fmac_f32_e32 v34, v28, v24                               // 00000000F2DC: 5644311C
	v_fma_f32 v25, -v22, v30, v32                              // 00000000F2E0: D6130019 24823D16
	v_mul_f32_e32 v23, v23, v16                                // 00000000F2E8: 102E2117
	v_mul_f32_e32 v7, v12, v7                                  // 00000000F2EC: 100E0F0C
	v_div_fmas_f32 v17, v17, v20, v31                          // 00000000F2F0: D6370011 047E2911
	v_fma_f32 v19, -v19, v34, v29                              // 00000000F2F8: D6130013 24764513
	v_fmac_f32_e32 v30, v25, v27                               // 00000000F300: 563C3719
	s_mov_b32 vcc_lo, s1                                       // 00000000F304: BEEA0001
	s_ashr_i32 s1, s0, 31                                      // 00000000F308: 86019F00
	v_div_fmas_f32 v18, v18, v21, v33                          // 00000000F30C: D6370012 04862B12
	s_mov_b32 vcc_lo, s3                                       // 00000000F314: BEEA0003
	v_div_fixup_f32 v8, v17, v8, 1.0                           // 00000000F318: D6270008 03CA1111
	v_fma_f32 v12, -v22, v30, v32                              // 00000000F320: D613000C 24823D16
	v_div_fmas_f32 v17, v19, v24, v34                          // 00000000F328: D6370011 048A3113
	s_mov_b32 vcc_lo, s4                                       // 00000000F330: BEEA0004
	v_div_fixup_f32 v4, v18, v4, 1.0                           // 00000000F334: D6270004 03CA0912
	v_dual_mul_f32 v8, v8, v11 :: v_dual_mul_f32 v7, v7, v10   // 00000000F33C: C8C61708 08061507
	v_div_fmas_f32 v11, v12, v27, v30                          // 00000000F344: D637000B 047A370C
	v_div_fixup_f32 v9, v17, v9, 1.0                           // 00000000F34C: D6270009 03CA1311
	s_mul_i32 s3, s9, 0x3000                                   // 00000000F354: 9603FF09 00003000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000000F35C: BF870003
	v_bfe_u32 v12, v8, 16, 1                                   // 00000000F360: D610000C 02052108
	s_mul_hi_i32 s4, s9, 0x3000                                // 00000000F368: 9704FF09 00003000
	v_div_fixup_f32 v5, v11, v5, 1.0                           // 00000000F370: D6270005 03CA0B0B
	v_mul_f32_e32 v4, v4, v6                                   // 00000000F378: 10080D04
	v_mul_f32_e32 v6, v9, v23                                  // 00000000F37C: 100C2F09
	v_add3_u32 v8, v8, v12, 0x7fff                             // 00000000F380: D6550008 03FE1908 00007FFF
	.long 0x7f163880                                           // 00000000F38C: 7F163880
	v_mul_f32_e32 v5, v5, v7                                   // 00000000F390: 100A0F05
	v_bfe_u32 v7, v4, 16, 1                                    // 00000000F394: D6100007 02052104
	v_bfe_u32 v9, v6, 16, 1                                    // 00000000F39C: D6100009 02052106
	.long 0x7e163988                                           // 00000000F3A4: 7E163988
	s_add_u32 s3, s6, s3                                       // 00000000F3A8: 80030306
	v_bfe_u32 v8, v5, 16, 1                                    // 00000000F3AC: D6100008 02052105
	v_add3_u32 v4, v4, v7, 0x7fff                              // 00000000F3B4: D6550004 03FE0F04 00007FFF
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000000F3C0: D6550006 03FE1306 00007FFF
	s_addc_u32 s4, s7, s4                                      // 00000000F3CC: 82040407
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000000F3D0: 84808100
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000000F3D4: D6550005 03FE1105 00007FFF
	v_and_or_b32 v4, 0xffff0000, v4, v11                       // 00000000F3E0: D6570004 042E08FF FFFF0000
	.long 0x7e163986                                           // 00000000F3EC: 7E163986
	v_lshlrev_b32_e32 v6, 1, v13                               // 00000000F3F0: 300C1A81
	s_add_u32 s0, s3, s0                                       // 00000000F3F4: 80000003
	s_addc_u32 s1, s4, s1                                      // 00000000F3F8: 82010104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000000F3FC: BF8704B2
	v_and_or_b32 v5, 0xffff0000, v5, v11                       // 00000000F400: D6570005 042E0AFF FFFF0000
	global_store_b64 v6, v[4:5], s[0:1]                        // 00000000F40C: DC6E0000 00000406
	s_or_b32 s0, s8, s10                                       // 00000000F414: 8C000A08
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000F418: 8B6A007E
	s_cbranch_vccz 64939                                       // 00000000F41C: BFA3FDAB <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x65cc>
	s_branch 65132                                             // 00000000F420: BFA0FE6C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb0ELb1EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x68d4>
		...

